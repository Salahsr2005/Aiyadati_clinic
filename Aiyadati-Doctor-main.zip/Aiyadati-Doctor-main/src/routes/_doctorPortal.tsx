import { useEffect } from "react";
import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { WifiOff } from "lucide-react";
import { Sidebar } from "@/components/shell/Sidebar";
import { Topbar } from "@/components/shell/Topbar";
import { BottomNav } from "@/components/shell/BottomNav";
import logo from "@/assets/logo.svg";
import { useAuthStore } from "@/store/auth";
import { useOnlineStatus } from "@/hooks/useOnlineStatus";
import { useTranslation } from "react-i18next";

/**
 * Doctor portal gate. Auth lives in localStorage, so this subtree is
 * client-rendered and redirects unauthenticated visitors to /login.
 */
export const Route = createFileRoute("/_doctorPortal")({
  ssr: false,
  component: DoctorPortalLayout,
});

function DoctorPortalLayout() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const token = useAuthStore((s) => s.token);
  const hydrated = useAuthStore((s) => s.hydrated);
  const online = useOnlineStatus();

  useEffect(() => {
    if (hydrated && !token) {
      void navigate({ to: "/login", search: { expired: undefined }, replace: true });
    }
  }, [hydrated, token, navigate]);

  if (!hydrated || !token) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="flex flex-col items-center gap-4">
          <img src={logo} alt="Iyadati" className="h-12 w-12" />
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen w-full">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        {!online && (
          <div className="mx-4 mt-3 flex items-center gap-2 rounded-xl bg-warning/15 px-3 py-2 text-xs text-warning">
            <WifiOff className="h-3.5 w-3.5" />
            {t("shell.offline.message")}
          </div>
        )}
        <main className="min-w-0 flex-1 p-4 pb-24 md:pb-4">
          <Outlet />
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
