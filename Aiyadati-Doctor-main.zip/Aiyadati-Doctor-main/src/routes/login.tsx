import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Eye, EyeOff, Loader2, Stethoscope } from "lucide-react";
import { toast } from "sonner";
import { authApi } from "@/api/authApi";
import { useAuthStore } from "@/store/auth";
import logo from "@/assets/logo.svg";

export const Route = createFileRoute("/login")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    expired: search.expired ? true : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Doctor sign in — Iyadati" },
      { name: "description", content: "Sign in to the Iyadati doctor portal to manage your schedule, appointments and earnings." },
      { property: "og:title", content: "Doctor sign in — Iyadati" },
      { property: "og:description", content: "Access your Iyadati doctor self-service portal." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { expired } = Route.useSearch();
  const setSession = useAuthStore((s) => s.setSession);
  const token = useAuthStore((s) => s.token);
  const hydrated = useAuthStore((s) => s.hydrated);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (hydrated && token) void navigate({ to: "/dashboard", replace: true });
  }, [hydrated, token, navigate]);

  useEffect(() => {
    if (expired) toast.info("Your session expired. Please sign in again.");
  }, [expired]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authApi.doctorLogin(email.trim(), password);
      const tok = res.token;
      if (!tok) throw new Error("No token returned");
      setSession(tok, res.user, remember);
      toast.success("Welcome back");
      void navigate({ to: "/dashboard", replace: true });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Sign in failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4">
      <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-primary-500/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-secondary-500/25 blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="glass w-full max-w-md rounded-3xl p-8"
      >
        <div className="flex flex-col items-center text-center">
          <img src={logo} alt="Iyadati" className="h-12 w-12" />
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">Doctor portal</h1>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
            <Stethoscope className="h-3.5 w-3.5" />
            Manage your practice on Iyadati
          </p>
        </div>

        <form onSubmit={onSubmit} className="mt-8 space-y-4">
          <div className="space-y-1.5">
            <label htmlFor="email" className="text-sm font-medium">Email</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="doctor@example.com"
              className="glass w-full rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary-500/40"
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="password" className="text-sm font-medium">Password</label>
            <div className="relative">
              <input
                id="password"
                type={show ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="glass w-full rounded-xl px-3 py-2.5 pe-10 text-sm outline-none focus:ring-2 focus:ring-primary-500/40"
              />
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                className="absolute end-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-accent"
                aria-label={show ? "Hide password" : "Show password"}
              >
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-4 w-4 rounded border-border"
            />
            Keep me signed in
          </label>

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary-500 px-4 py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90 disabled:opacity-60"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Sign in
          </button>
        </form>
      </motion.div>
    </div>
  );
}
