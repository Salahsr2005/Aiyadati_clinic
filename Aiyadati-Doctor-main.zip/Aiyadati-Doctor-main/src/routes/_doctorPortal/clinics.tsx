import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Building2,
  Check,
  Clock3,
  MapPin,
  Stethoscope,
  X,
  Phone,
  Sparkles,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  Clock,
  Send,
  ChevronRight,
  PlusCircle,
  Mail,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { EmptyState } from "@/components/data/EmptyState";
import { StatusBadge } from "@/components/data/StatusBadge";
import { SearchInput } from "@/components/data/SearchInput";
import { SelectMenu } from "@/components/data/SelectMenu";
import { FormModal } from "@/components/data/FormModal";
import { ViewToggle, type ViewMode } from "@/components/data/ViewToggle";
import { EntityMap, type MapPoint } from "@/components/map/EntityMap";
import { ClinicDetailDrawer } from "@/components/clinics/ClinicDetailDrawer";
import { doctorSelfApi } from "@/api/doctorSelfApi";
import { publicClinicsApi, type PublicClinicRow } from "@/api/publicApi";
import type { ClinicRow } from "@/api/clinicsApi";
import { useClinicInvitations } from "@/hooks/useClinicInvitations";
import { useWilayas } from "@/hooks/useWilayas";
import { resolveMediaUrl } from "@/components/users/UserAvatar";
import { useEntityMutation } from "@/lib/mutations";
import { qk } from "@/lib/queryKeys";
import { centroidFor } from "@/lib/wilayaCentroids";
import { clinicPlaceholderUrl } from "@/lib/assetFallbacks";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_doctorPortal/clinics")({
  head: () => ({
    meta: [
      { title: "Clinics & Affiliations — Iyadati Doctor Portal" },
      {
        name: "description",
        content: "Manage clinic affiliations, room allocations, pending invitations, and marketplace joining requests.",
      },
      { property: "og:title", content: "Clinics — Iyadati Doctor Portal" },
      { property: "og:description", content: "Clinic affiliations and practice management." },
    ],
  }),
  component: ClinicsPage,
});

type TabView = "all" | "affiliated" | "invitations" | "pending_requests" | "marketplace";
type SortOption = "name" | "recent";

function clinicLogo(url?: string | null) {
  return resolveMediaUrl(url) || clinicPlaceholderUrl;
}

function clinicLocation(c?: { wilaya?: { nameFr?: string; nameAr?: string } | null; baladya?: { nameFr?: string; nameAr?: string } | null } | null) {
  if (!c) return "Location N/A";
  const parts = [c.baladya?.nameFr, c.wilaya?.nameFr].filter(Boolean);
  return parts.length ? parts.join(", ") : "Location N/A";
}

function ClinicsPage() {
  const [activeTab, setActiveTab] = useState<TabView>("all");
  const [search, setSearch] = useState("");
  const [wilayaFilter, setWilayaFilter] = useState<string | undefined>(undefined);
  const [sortBy, setSortBy] = useState<SortOption>("recent");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");

  const [requestTarget, setRequestTarget] = useState<PublicClinicRow | null>(null);
  const [message, setMessage] = useState("");
  const [selectedClinicId, setSelectedClinicId] = useState<string | null>(null);
  const [selectedFallback, setSelectedFallback] = useState<Partial<ClinicRow> | null>(null);

  // Optimistic local overrides so accepted/declined invitations leave the pending
  // lists instantly, before the invalidated query refetches from the server.
  const [localResolved, setLocalResolved] = useState<Record<string, "ACCEPTED" | "REJECTED">>({});

  const { data: wilayas } = useWilayas();

  const { all: invitationsData, myClinics: myClinicsRaw, pendingIncoming: pendingIncomingRaw, pendingOutgoing: pendingOutgoingRaw, isLoading: invitationsLoading } =
    useClinicInvitations();

  const myClinics = useMemo(
    () => [...myClinicsRaw, ...invitationsData.filter((i) => localResolved[i.id] === "ACCEPTED" && !myClinicsRaw.some((m) => m.id === i.id))],
    [myClinicsRaw, invitationsData, localResolved],
  );
  const pendingIncoming = useMemo(
    () => pendingIncomingRaw.filter((i) => !localResolved[i.id]),
    [pendingIncomingRaw, localResolved],
  );
  const pendingOutgoing = useMemo(
    () => pendingOutgoingRaw.filter((i) => !localResolved[i.id]),
    [pendingOutgoingRaw, localResolved],
  );

  const clinicsMarketplace = useQuery({
    queryKey: qk.publicClinics.list({ search, wilayaId: wilayaFilter, limit: 50 }),
    queryFn: () => publicClinicsApi.list({ search: search || undefined, wilayaId: wilayaFilter, limit: 50 }),
  });

  const accept = useEntityMutation<string>({
    mutationFn: (id) => doctorSelfApi.clinicInvitations.accept(id),
    invalidate: [qk.doctorSelf.invitations(), qk.doctorSelf.profile()],
    successMessage: "Invitation accepted successfully!",
    onSuccess: (_data, id) => {
      setLocalResolved((prev) => ({ ...prev, [id]: "ACCEPTED" }));
      setActiveTab("affiliated");
      toast("You've joined the clinic", {
        description: "It now appears under My Clinics.",
        action: {
          label: "View in My Clinics",
          onClick: () => setActiveTab("affiliated"),
        },
      });
    },
  });

  const reject = useEntityMutation<string>({
    mutationFn: (id) => doctorSelfApi.clinicInvitations.reject(id),
    invalidate: [qk.doctorSelf.invitations()],
    successMessage: "Invitation declined",
    onSuccess: (_data, id) => setLocalResolved((prev) => ({ ...prev, [id]: "REJECTED" })),
  });

  const cancelRequest = useEntityMutation<string>({
    mutationFn: (id) => doctorSelfApi.clinicInvitations.reject(id),
    invalidate: [qk.doctorSelf.invitations()],
    successMessage: "Request cancelled",
    onSuccess: (_data, id) => setLocalResolved((prev) => ({ ...prev, [id]: "REJECTED" })),
  });

  const request = useEntityMutation<{ clinicId: string }>({
    mutationFn: (payload) => doctorSelfApi.requestClinic(payload),
    invalidate: [qk.doctorSelf.invitations()],
    successMessage: "Join request sent to clinic management",
    onSuccess: () => {
      setRequestTarget(null);
      setMessage("");
    },
  });

  const filteredMarketplace = useMemo(() => {
    let items = clinicsMarketplace.data?.items ?? [];

    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (c) =>
          c.nameFr?.toLowerCase().includes(q) ||
          c.nameAr?.toLowerCase().includes(q) ||
          c.wilaya?.nameFr?.toLowerCase().includes(q),
      );
    }

    if (wilayaFilter) {
      items = items.filter((c) => c.wilaya?.id === wilayaFilter);
    }

    if (sortBy === "name") {
      items = [...items].sort((a, b) => (a.nameFr ?? "").localeCompare(b.nameFr ?? ""));
    }

    return items;
  }, [clinicsMarketplace.data, search, wilayaFilter, sortBy]);

  const marketplaceMapPoints: MapPoint[] = useMemo(() => {
    return filteredMarketplace
      .map((c) => {
        const centroid = centroidFor(c.wilaya?.code);
        const lat = c.latitude ?? (centroid ? centroid[1] : undefined);
        const lng = c.longitude ?? (centroid ? centroid[0] : undefined);
        if (lat == null || lng == null) return null;
        return {
          id: c.id,
          latitude: lat,
          longitude: lng,
          title: c.nameFr || c.nameAr || "Clinic",
          subtitle: clinicLocation(c),
          imageUrl: clinicLogo(c.logoUrl) ?? undefined,
          badgeLabel: c.isCompleted ? "Active" : undefined,
          badgeTone: (c.isCompleted ? "success" : "info") as MapPoint["badgeTone"],
          type: "clinic" as const,
        } satisfies MapPoint;
      })
      .filter((p) => p !== null) as MapPoint[];
  }, [filteredMarketplace]);

  const handleResetFilters = () => {
    setSearch("");
    setWilayaFilter(undefined);
    setSortBy("recent");
  };

  const openClinicDetail = (id: string, fallback?: Record<string, unknown> | null) => {
    setSelectedClinicId(id);
    setSelectedFallback((fallback ?? null) as Partial<ClinicRow> | null);
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <PageHeader
        title="Clinic Affiliations & Practice Rooms"
        subtitle="Manage active clinic partnerships, respond to invitations, or request access to new facilities across Algeria."
        actions={
          <button
            onClick={() => setActiveTab("marketplace")}
            className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-3.5 py-2 text-xs font-semibold text-primary-foreground shadow-sm hover:bg-primary-600 transition"
          >
            <PlusCircle className="h-4 w-4" /> Explore Marketplace
          </button>
        }
      />

      {/* METRICS & SUMMARY CARDS */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <GlassCard className="p-4 space-y-1 border-l-4 border-l-primary-500">
          <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
            <span>Active Affiliations</span>
            <Building2 className="h-4 w-4 text-primary-500" />
          </div>
          <div className="text-2xl font-bold text-foreground tabular-nums">{myClinics.length}</div>
          <div className="text-[11px] text-muted-foreground">Facilities where you practice</div>
        </GlassCard>

        <GlassCard className="p-4 space-y-1 border-l-4 border-l-warning font-medium">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Pending Invitations</span>
            <Clock className="h-4 w-4 text-warning" />
          </div>
          <div className="text-2xl font-bold text-foreground tabular-nums">{pendingIncoming.length}</div>
          <div className="text-[11px] text-muted-foreground">Awaiting your response</div>
        </GlassCard>

        <GlassCard className="p-4 space-y-1 border-l-4 border-l-info">
          <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
            <span>Outgoing Requests</span>
            <Send className="h-4 w-4 text-info" />
          </div>
          <div className="text-2xl font-bold text-foreground tabular-nums">{pendingOutgoing.length}</div>
          <div className="text-[11px] text-muted-foreground">Under review by clinics</div>
        </GlassCard>

        <GlassCard className="p-4 space-y-1 border-l-4 border-l-success">
          <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
            <span>Available Marketplace</span>
            <Sparkles className="h-4 w-4 text-success" />
          </div>
          <div className="text-2xl font-bold text-foreground tabular-nums">
            {clinicsMarketplace.data?.items.length ?? 0}
          </div>
          <div className="text-[11px] text-muted-foreground">Clinics open for doctors</div>
        </GlassCard>
      </div>

      {/* CONTROLS & NAVIGATION TABS */}
      <GlassCard className="p-4 space-y-3.5 border border-border/40">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-border/30">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium">
            {(
              [
                { id: "all", label: "All Overview" },
                { id: "affiliated", label: `My Clinics (${myClinics.length})` },
                { id: "invitations", label: `Invitations (${pendingIncoming.length})` },
                { id: "pending_requests", label: `Sent Requests (${pendingOutgoing.length})` },
                { id: "marketplace", label: "Explore Marketplace" },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-xs transition font-semibold",
                  activeTab === tab.id
                    ? "bg-primary-500 text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {(activeTab === "all" || activeTab === "marketplace") && (
              <ViewToggle value={viewMode} onChange={setViewMode} modes={["grid", "map"]} />
            )}
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition"
            >
              <RotateCcw className="h-3 w-3" /> Reset
            </button>
          </div>
        </div>

        {/* SEARCH & FILTERS BAR */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
          <div className="sm:col-span-1">
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder="Search clinic name, wilaya..."
            />
          </div>

          <div>
            <SelectMenu
              value={wilayaFilter}
              onChange={setWilayaFilter}
              options={[
                { value: "", label: "All Wilayas" },
                ...(wilayas ?? []).map((w) => ({ value: w.id, label: w.nameFr ?? w.nameAr ?? w.id })),
              ]}
              placeholder="Filter by Wilaya"
              searchable
              className="w-full text-xs"
            />
          </div>

          <div>
            <SelectMenu
              value={sortBy}
              onChange={(v) => v && setSortBy(v as SortOption)}
              options={[
                { value: "recent", label: "Sort by: Default / Recent" },
                { value: "name", label: "Sort by: Name (A-Z)" },
              ]}
              className="w-full text-xs"
            />
          </div>
        </div>
      </GlassCard>

      {/* SECTION 1: MY CLINICS AFFILIATIONS */}
      {(activeTab === "all" || activeTab === "affiliated") && (
        <GlassCard className="p-5 space-y-4 border border-border/40">
          <div className="flex items-center justify-between border-b border-border/30 pb-3">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Building2 className="h-4 w-4 text-primary-500" /> Active Clinic Affiliations
              </h2>
              <p className="text-xs text-muted-foreground">
                Facilities where your profile is active, allowing appointments and room allocations.
              </p>
            </div>
            <span className="rounded-full bg-primary-500/10 px-2.5 py-0.5 text-xs font-bold text-primary-500">
              {myClinics.length} Active
            </span>
          </div>

          {invitationsLoading ? (
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-32 rounded-2xl" />
              ))}
            </div>
          ) : myClinics.length === 0 ? (
            <EmptyState
              icon={Building2}
              title="No active affiliations"
              description="You have not joined any clinic yet. Accept an invitation below or request to join a medical center from the marketplace."
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-3">
              {myClinics.map((inv) => {
                const clinic = inv.clinic;
                return (
                  <div
                    key={inv.id}
                    className="glass flex flex-col justify-between rounded-2xl p-4 space-y-3 border border-border/40 hover:border-primary-500/40 transition shadow-sm"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <img
                            src={clinicLogo(clinic?.logoUrl)}
                            alt=""
                            onError={(e) => {
                              (e.currentTarget as HTMLImageElement).src = clinicPlaceholderUrl;
                            }}
                            className="h-12 w-12 shrink-0 rounded-xl object-cover border border-border/40"
                          />
                          <div className="min-w-0">
                            <h3 className="truncate text-sm font-bold text-foreground">
                              {clinic?.nameFr || clinic?.nameAr || "Clinic"}
                            </h3>
                            <div className="truncate text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                              <MapPin className="h-3 w-3 text-primary-500" />
                              {clinicLocation(clinic)}
                            </div>
                          </div>
                        </div>
                        <StatusBadge value="ACCEPTED" tone="success" />
                      </div>

                      {/* Additional Details */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] bg-muted/30 p-2.5 rounded-xl border border-border/20">
                        <div>
                          <span className="text-muted-foreground block">Phone Contact</span>
                          {clinic?.phone ? (
                            <a href={`tel:${clinic.phone}`} className="font-semibold text-primary-500 hover:underline">
                              {clinic.phone}
                            </a>
                          ) : (
                            <span className="font-semibold text-foreground">N/A</span>
                          )}
                        </div>
                        <div>
                          <span className="text-muted-foreground block">Affiliated Since</span>
                          <span className="font-semibold text-foreground tabular-nums">
                            {inv.joinedAt?.slice(0, 10) ?? "Recent"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-border/30 flex items-center justify-between">
                      <button
                        onClick={() => openClinicDetail(inv.clinicId, clinic as unknown as Partial<ClinicRow> | null)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-primary-500 hover:underline"
                      >
                        View Facility & Schedule <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </GlassCard>
      )}

      {/* SECTION 2: INCOMING INVITATIONS — actionable, warning-toned */}
      {(activeTab === "all" || activeTab === "invitations") && (
        <GlassCard className="p-5 space-y-4 border border-border/40">
          <div className="flex items-center justify-between border-b border-border/30 pb-3">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Mail className="h-4 w-4 text-warning" /> Incoming Clinic Invitations
              </h2>
              <p className="text-xs text-muted-foreground">
                Clinics that have invited you to join their medical team and practice in their rooms.
              </p>
            </div>
            <span className="rounded-full bg-warning/10 px-2.5 py-0.5 text-xs font-bold text-warning">
              {pendingIncoming.length} Pending
            </span>
          </div>

          {invitationsLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))}
            </div>
          ) : pendingIncoming.length === 0 ? (
            <EmptyState
              icon={Building2}
              title="No pending invitations"
              description="You have no active invitations from clinics right now."
            />
          ) : (
            <div className="space-y-3">
              {pendingIncoming.map((inv) => (
                <div
                  key={inv.id}
                  className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl border border-warning/30 bg-warning/5"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={clinicLogo(inv.clinic?.logoUrl)}
                      alt=""
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = clinicPlaceholderUrl;
                      }}
                      className="h-12 w-12 shrink-0 rounded-xl object-cover border border-border/40"
                    />
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="truncate text-sm font-bold text-foreground">
                          {inv.clinic?.nameFr || inv.clinic?.nameAr || "Clinic"}
                        </h3>
                        <StatusBadge value="PENDING" />
                      </div>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        {clinicLocation(inv.clinic)}
                      </p>
                      {inv.clinic?.phone && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Phone className="h-3.5 w-3.5" />
                          <a href={`tel:${inv.clinic.phone}`} className="hover:text-primary-500">{inv.clinic.phone}</a>
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                    <button
                      onClick={() => accept.mutate(inv.id)}
                      disabled={accept.isPending}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-success px-3.5 py-1.5 text-xs font-semibold text-success-foreground hover:bg-success/90 transition shadow-sm disabled:opacity-50"
                    >
                      <Check className="h-3.5 w-3.5" /> Accept Invitation
                    </button>
                    <button
                      onClick={() => reject.mutate(inv.id)}
                      disabled={reject.isPending}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-danger/10 px-3.5 py-1.5 text-xs font-semibold text-danger hover:bg-danger/20 transition disabled:opacity-50"
                    >
                      <X className="h-3.5 w-3.5" /> Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      )}

      {/* SECTION 3: SENT REQUESTS — quiet status timeline */}
      {(activeTab === "all" || activeTab === "pending_requests") && (
        <GlassCard className="p-5 space-y-4 border border-border/40">
          <div className="flex items-center justify-between border-b border-border/30 pb-3">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Clock3 className="h-4 w-4 text-info" /> Pending Requests Sent by You
              </h2>
              <p className="text-xs text-muted-foreground">
                Join requests you have sent to clinics that are awaiting manager approval.
              </p>
            </div>
            <span className="rounded-full bg-info/10 px-2.5 py-0.5 text-xs font-bold text-info">
              {pendingOutgoing.length} Sent
            </span>
          </div>

          {invitationsLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))}
            </div>
          ) : pendingOutgoing.length === 0 ? (
            <EmptyState
              icon={Clock3}
              title="No pending requests sent"
              description="You have not requested to join any clinic recently."
            />
          ) : (
            <div className="space-y-3">
              {pendingOutgoing.map((inv) => (
                <div
                  key={inv.id}
                  className="glass flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl border border-border/40"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={clinicLogo(inv.clinic?.logoUrl)}
                      alt=""
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = clinicPlaceholderUrl;
                      }}
                      className="h-10 w-10 shrink-0 rounded-xl object-cover border border-border/40"
                    />
                    <div className="min-w-0">
                      <h3 className="truncate text-sm font-bold text-foreground">
                        {inv.clinic?.nameFr || inv.clinic?.nameAr || "Clinic"}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {clinicLocation(inv.clinic)}
                      </p>
                    </div>
                  </div>

                  {/* Status timeline: sent -> under review -> accepted/declined */}
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground shrink-0">
                    <span className="flex items-center gap-1 text-success">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Sent
                    </span>
                    <ArrowRight className="h-3 w-3" />
                    <span className="flex items-center gap-1 text-info">
                      <Clock className="h-3.5 w-3.5" /> Under review
                    </span>
                    <ArrowRight className="h-3 w-3" />
                    <span className="flex items-center gap-1 text-muted-foreground/60">
                      <Clock3 className="h-3.5 w-3.5" /> Accepted / Declined
                    </span>
                  </div>

                  <button
                    onClick={() => cancelRequest.mutate(inv.id)}
                    disabled={cancelRequest.isPending}
                    className="inline-flex items-center gap-1 rounded-xl bg-danger/10 px-3 py-1.5 text-xs font-semibold text-danger hover:bg-danger/20 transition shrink-0 self-start sm:self-center"
                  >
                    <X className="h-3.5 w-3.5" /> Cancel Request
                  </button>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      )}

      {/* SECTION 4: CLINIC MARKETPLACE & DIRECT REQUEST */}
      {(activeTab === "all" || activeTab === "marketplace") && (
        <GlassCard className="p-5 space-y-4 border border-border/40">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/30 pb-3">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-primary-500" /> Clinic Marketplace
              </h2>
              <p className="text-xs text-muted-foreground">
                Browse medical facilities across Algeria and request consultation space.
              </p>
            </div>
            <div className="text-xs font-semibold text-muted-foreground">
              Showing {filteredMarketplace.length} clinics
            </div>
          </div>

          {clinicsMarketplace.isLoading ? (
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-40 rounded-2xl" />
              ))}
            </div>
          ) : filteredMarketplace.length === 0 ? (
            <EmptyState
              icon={Building2}
              title="No clinics match your search"
              description="Try adjusting your keyword or wilaya filter to find available clinics."
            />
          ) : viewMode === "map" ? (
            <EntityMap
              points={marketplaceMapPoints}
              onSelect={(id) => {
                const clinic = filteredMarketplace.find((c) => c.id === id);
                if (clinic) openClinicDetail(clinic.id, clinic as unknown as Partial<ClinicRow>);
              }}
              height={480}
              emptyLabel="No clinic location data available"
              showUserLocation
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-3">
              {filteredMarketplace.map((c) => {
                const isAlreadyAffiliated = myClinics.some((inv) => inv.clinicId === c.id);
                const isAlreadyRequested = pendingOutgoing.some((inv) => inv.clinicId === c.id);

                return (
                  <div
                    key={c.id}
                    className="glass flex flex-col justify-between rounded-2xl p-4 border border-border/40 hover:border-primary-500/30 transition space-y-3"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-start gap-3">
                        <img
                          src={clinicLogo(c.logoUrl)}
                          alt=""
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src = clinicPlaceholderUrl;
                          }}
                          className="h-12 w-12 shrink-0 rounded-xl object-cover border border-border/40"
                        />
                        <div className="min-w-0 flex-1">
                          <h3 className="truncate text-sm font-bold text-foreground">
                            {c.nameFr || c.nameAr}
                          </h3>
                          <div className="truncate text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                            <MapPin className="h-3.5 w-3.5 text-primary-500" />
                            {clinicLocation(c)}
                          </div>
                          {c.phone && (
                            <a
                              href={`tel:${c.phone}`}
                              className="truncate text-xs text-primary-500 hover:underline flex items-center gap-1 mt-0.5"
                            >
                              <Phone className="h-3.5 w-3.5" /> {c.phone}
                            </a>
                          )}
                        </div>
                      </div>

                      {(c.descriptionFr || c.descriptionAr) && (
                        <p className="text-[11px] text-muted-foreground line-clamp-2">
                          {c.descriptionFr || c.descriptionAr}
                        </p>
                      )}

                      <div className="grid grid-cols-1 gap-2 text-[11px] bg-muted/30 p-2.5 rounded-xl border border-border/20">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <ShieldCheck className={cn("h-3 w-3", c.isCompleted ? "text-success" : "text-muted-foreground")} />
                          <span className="font-medium text-foreground">
                            {c.isCompleted ? "Active profile" : "Profile incomplete"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-border/30 flex items-center justify-between gap-2">
                      <button
                        onClick={() => openClinicDetail(c.id, c as unknown as Partial<ClinicRow>)}
                        className="text-xs font-semibold text-primary-500 hover:underline"
                      >
                        Details
                      </button>

                      {isAlreadyAffiliated ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-success bg-success/10 px-2.5 py-1 rounded-lg">
                          <CheckCircle2 className="h-3 w-3" /> Affiliated
                        </span>
                      ) : isAlreadyRequested ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-info bg-info/10 px-2.5 py-1 rounded-lg">
                          <Clock className="h-3 w-3" /> Requested
                        </span>
                      ) : (
                        <button
                          onClick={() => setRequestTarget(c)}
                          className="inline-flex items-center gap-1 rounded-xl bg-primary-500 px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary-600 transition shadow-sm"
                        >
                          Request to Join
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </GlassCard>
      )}

      {/* REQUEST TO JOIN FORM MODAL */}
      <FormModal
        id="clinic-request"
        open={!!requestTarget}
        onClose={() => setRequestTarget(null)}
        title={`Request Affiliation with ${requestTarget?.nameFr ?? requestTarget?.nameAr ?? "Clinic"}`}
        description="Write a brief intro or specify preferred working days to clinic management."
        footer={
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setRequestTarget(null)}
              className="glass rounded-xl px-4 py-2 text-xs font-semibold text-foreground hover:bg-muted transition"
            >
              Cancel
            </button>
            <button
              disabled={request.isPending}
              onClick={() => requestTarget && request.mutate({ clinicId: requestTarget.id })}
              className="rounded-xl bg-primary-500 px-4 py-2 text-xs font-semibold text-primary-foreground hover:bg-primary-600 transition shadow-sm disabled:opacity-50"
            >
              Send Request
            </button>
          </div>
        }
      >
        <div className="space-y-3">
          <label className="text-xs font-semibold text-foreground block">
            Message / Practice Schedule Request (kept locally, for your own notes):
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            maxLength={500}
            placeholder="I am interested in conducting general consultations at your clinic during weekday mornings (e.g., Sunday & Tuesday, 09:00 - 13:00)..."
            className="glass w-full rounded-xl p-3 text-xs text-foreground outline-none border border-border/40 focus:border-primary-500 transition"
          />
          <div className="text-[11px] text-muted-foreground italic">
            * Note: Clinic administrators will review your practitioner profile and qualifications prior to approval.
          </div>
        </div>
      </FormModal>

      {/* CLINIC DETAIL DRAWER */}
      <ClinicDetailDrawer
        clinicId={selectedClinicId}
        fallback={selectedFallback}
        open={!!selectedClinicId}
        onClose={() => {
          setSelectedClinicId(null);
          setSelectedFallback(null);
        }}
      />
    </div>
  );
}
