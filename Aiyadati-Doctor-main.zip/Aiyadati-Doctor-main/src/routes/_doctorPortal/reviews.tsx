import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import {
  Award,
  HeartHandshake,
  Filter,
  MessageSquare,
  Calendar as CalendarIcon,
  ShieldCheck,
  Building2,
  Sliders,
  ArrowUpDown,
} from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { EmptyState } from "@/components/data/EmptyState";
import { StarRating } from "@/components/reviews/StarRating";
import { reviewsApi, type ReviewRow } from "@/api/reviewsApi";
import { useDoctorProfile } from "@/hooks/useDoctorProfile";
import { useEntityMutation } from "@/lib/mutations";
import { qk } from "@/lib/queryKeys";
import { cn } from "@/lib/utils";
import { translateEnum } from "@/lib/enumLabel";
import confirmedImg from "@/assets/appointments/confirmed.png";

export const Route = createFileRoute("/_doctorPortal/reviews")({
  head: () => ({
    meta: [
      { title: "Patient Reviews — Iyadati Doctor Portal" },
      {
        name: "description",
        content: "Read every rating and comment patients left after their consultation with you.",
      },
      { property: "og:title", content: "Patient Reviews — Iyadati Doctor Portal" },
      { property: "og:description", content: "Ratings, comments and score distribution." },
    ],
  }),
  component: ReviewsPage,
});

type SortMode = "newest" | "highest" | "lowest";

export function ReviewsPage() {
  const { t, i18n } = useTranslation();
  const { data: profile } = useDoctorProfile();
  const doctorId = profile?.id;
  const [filterRating, setFilterRating] = useState<number | "all">("all");
  const [sortMode, setSortMode] = useState<SortMode>("newest");
  const [visibilitySetting, setVisibilitySetting] = useState<"BOTH" | "RATING_ONLY" | "REVIEW_ONLY" | "NONE">("BOTH");

  const reviews = useQuery({
    queryKey: qk.doctorSelf.reviews(doctorId ?? ""),
    queryFn: () => reviewsApi.doctor(doctorId!),
    enabled: !!doctorId,
  });

  const stats = useQuery({
    queryKey: qk.doctorSelf.reviewStats(doctorId ?? ""),
    queryFn: () => reviewsApi.doctorStats(doctorId!),
    enabled: !!doctorId,
  });

  const updateVisibility = useEntityMutation<{ reviewVisibility: string }>({
    mutationFn: (payload) => reviewsApi.setVisibility(payload),
    invalidate: [qk.doctorSelf.reviewStats(doctorId ?? "")],
    successMessage: "Review visibility updated",
  });

  const items: ReviewRow[] = Array.isArray(reviews.data) ? reviews.data : [];
  const average =
    stats.data?.average ??
    stats.data?.avgRating ??
    (items.length ? items.reduce((s, r) => s + (r.rating ?? 0), 0) / items.length : 5.0);
  const count = stats.data?.count ?? stats.data?.totalReviews ?? items.length;

  const distribution = (() => {
    const base: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    const d = stats.data?.distribution;
    if (Array.isArray(d)) d.forEach((x) => (base[x.stars] = x.count));
    else if (d && typeof d === "object")
      Object.entries(d).forEach(([k, v]) => (base[Number(k)] = Number(v)));
    else items.forEach((r) => (base[Math.round(r.rating ?? 0)] = (base[Math.round(r.rating ?? 0)] ?? 0) + 1));
    return base;
  })();

  const maxBar = Math.max(1, ...Object.values(distribution));

  const isLoading = reviews.isLoading || stats.isLoading;

  const visibleItems = useMemo(() => {
    const filtered =
      filterRating === "all" ? items : items.filter((r) => Math.round(r.rating ?? 0) === filterRating);

    const sorted = [...filtered].sort((a, b) => {
      if (sortMode === "highest") return (b.rating ?? 0) - (a.rating ?? 0);
      if (sortMode === "lowest") return (a.rating ?? 0) - (b.rating ?? 0);
      return new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime();
    });

    return sorted;
  }, [items, filterRating, sortMode]);

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <PageHeader
        title="Patient Feedback & Reviews"
        subtitle="Patient satisfaction scores, detailed comments, and review visibility settings"
        actions={
          <div className="glass flex flex-wrap items-center gap-2 rounded-2xl px-3.5 py-1.5 border border-border/40 text-xs font-semibold">
            <Sliders className="h-4 w-4 text-primary-500 shrink-0" />
            <span className="text-muted-foreground">Visibility Mode:</span>
            <select
              value={visibilitySetting}
              onChange={(e) => {
                const val = e.target.value as any;
                setVisibilitySetting(val);
                updateVisibility.mutate({ reviewVisibility: val });
              }}
              className="bg-transparent font-bold text-primary-500 outline-none cursor-pointer"
            >
              <option value="BOTH" className="bg-popover text-foreground">Rating & Review (Public)</option>
              <option value="RATING_ONLY" className="bg-popover text-foreground">Rating Only</option>
              <option value="REVIEW_ONLY" className="bg-popover text-foreground">Text Review Only</option>
              <option value="NONE" className="bg-popover text-foreground">Hidden (Private)</option>
            </select>
          </div>
        }
      />

      <div className="grid gap-4 md:grid-cols-3">
        {/* Score Summary Hero */}
        {isLoading ? (
          <GlassCard className="p-6 border border-border/40 shadow-xl">
            <Skeleton className="h-40 rounded-2xl" />
          </GlassCard>
        ) : (
          <GlassCard className="p-6 text-center border border-border/40 shadow-xl flex flex-col justify-center items-center">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-warning/10 text-warning mb-3">
              <Award className="h-6 w-6" />
            </div>
            <div className="text-5xl font-extrabold tracking-tight text-foreground">{average.toFixed(1)}</div>
            <div className="mt-2.5 flex justify-center">
              <StarRating value={average} size="h-5 w-5" />
            </div>
            <p className="mt-2 text-xs font-semibold text-muted-foreground">
              Based on {count} patient review{count === 1 ? "" : "s"}
            </p>
          </GlassCard>
        )}

        {/* Rating Breakdown */}
        {isLoading ? (
          <GlassCard className="p-6 lg:col-span-2 border border-border/40 shadow-xl">
            <Skeleton className="h-40 rounded-2xl" />
          </GlassCard>
        ) : (
          <GlassCard className="p-6 lg:col-span-2 border border-border/40 shadow-xl space-y-3">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
              <HeartHandshake className="h-4 w-4 text-primary-500" />
              Rating Distribution
            </h2>
            <div className="space-y-2.5">
              {[5, 4, 3, 2, 1].map((star) => {
                const cnt = distribution[star] ?? 0;
                const pct = count > 0 ? Math.round((cnt / count) * 100) : 0;
                return (
                  <button
                    key={star}
                    onClick={() => setFilterRating(filterRating === star ? "all" : star)}
                    className={cn(
                      "flex w-full items-center gap-2 sm:gap-3 text-xs font-semibold rounded-xl px-1.5 py-1 transition",
                      filterRating === star ? "bg-primary-500/10" : "hover:bg-muted/30",
                    )}
                  >
                    <span className="flex w-14 sm:w-16 shrink-0 items-center gap-0.5 text-muted-foreground font-bold">
                      {star}
                      <StarRating value={star} size="h-3 w-3" />
                    </span>
                    <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-muted/60">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-warning to-amber-500 transition-all duration-500"
                        style={{ width: `${(cnt / maxBar) * 100}%` }}
                      />
                    </div>
                    <span className="w-14 sm:w-16 text-right text-muted-foreground font-bold tabular-nums">
                      {cnt} ({pct}%)
                    </span>
                  </button>
                );
              })}
            </div>
          </GlassCard>
        )}
      </div>

      {/* Reviews List */}
      <GlassCard className="p-4 sm:p-6 border border-border/40 shadow-xl space-y-4">
        <div className="flex flex-col gap-3 pb-3 border-b border-border/30 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
          <h2 className="text-sm sm:text-base font-bold text-foreground flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary-500 shrink-0" />
            Patient Reviews Roster ({visibleItems.length})
          </h2>

          <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center sm:gap-3">
            {/* Rating filter pills */}
            <div className="flex flex-wrap items-center gap-1 text-xs font-semibold">
              <span className="text-muted-foreground me-1 flex items-center gap-1"><Filter className="h-3.5 w-3.5" /> Filter:</span>
              <button
                onClick={() => setFilterRating("all")}
                className={cn(
                  "rounded-full px-3 py-1 transition",
                  filterRating === "all" ? "bg-primary-500 text-primary-foreground font-bold" : "text-muted-foreground hover:bg-muted"
                )}
              >
                All
              </button>
              {[5, 4, 3, 2, 1].map((s) => (
                <button
                  key={s}
                  onClick={() => setFilterRating(s)}
                  className={cn(
                    "rounded-full px-2.5 py-1 transition",
                    filterRating === s ? "bg-primary-500 text-primary-foreground font-bold" : "text-muted-foreground hover:bg-muted"
                  )}
                >
                  {s}★
                </button>
              ))}
            </div>

            {/* Sort control */}
            <div className="flex items-center gap-1.5 text-xs font-semibold">
              <ArrowUpDown className="h-3.5 w-3.5 text-muted-foreground" />
              <select
                value={sortMode}
                onChange={(e) => setSortMode(e.target.value as SortMode)}
                className="rounded-full border border-border/40 bg-muted/20 px-2.5 py-1 text-xs font-bold text-foreground outline-none cursor-pointer"
              >
                <option value="newest">Newest first</option>
                <option value="highest">Highest rated</option>
                <option value="lowest">Lowest rated</option>
              </select>
            </div>
          </div>
        </div>

        {reviews.isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-28 rounded-2xl" />
            ))}
          </div>
        ) : visibleItems.length === 0 ? (
          <EmptyState
            image={confirmedImg}
            title="No patient reviews found"
            description={
              filterRating === "all"
                ? "Reviews left by patients after completing their consultation will be displayed here with full details."
                : `No reviews with a ${filterRating}★ rating yet. Try a different filter.`
            }
          />
        ) : (
          <div className="space-y-3">
            {visibleItems.map((r) => {
              const p = r.patient ?? r.user;
              const pName = [p?.firstName, p?.lastName].filter(Boolean).join(" ") || "Verified Patient";
              const initials = pName.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
              const reviewText = r.review ?? r.comment;

              return (
                <div
                  key={r.id}
                  className="glass rounded-2xl p-3.5 sm:p-4 border border-border/40 hover:border-primary-500/30 transition space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-500/10 text-xs font-extrabold text-primary-500">
                        {initials}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-foreground flex flex-wrap items-center gap-1.5">
                          <span>{pName}</span>
                          <span className="inline-flex items-center gap-0.5 rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-extrabold text-success border border-success/30">
                            <ShieldCheck className="h-3 w-3" /> Verified Visit
                          </span>
                        </div>
                        <div className="text-[10px] font-medium text-muted-foreground flex flex-wrap items-center gap-2 mt-0.5">
                          {r.patientId && <span>Patient ID: <code className="font-mono">{r.patientId.slice(0, 8)}</code></span>}
                          {r.createdAt && (
                            <span className="flex items-center gap-1">
                              <CalendarIcon className="h-3 w-3" />
                              {new Date(r.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 sm:gap-3">
                      <StarRating value={r.rating ?? 5} />
                      <span className="text-xs font-bold text-foreground font-mono">{(r.rating ?? 5).toFixed(1)}/5</span>
                    </div>
                  </div>

                  {reviewText ? (
                    <p className="text-xs text-foreground/90 leading-relaxed font-medium bg-muted/20 rounded-xl p-3 border border-border/30">
                      "{reviewText}"
                    </p>
                  ) : (
                    <p className="text-xs text-muted-foreground italic bg-muted/10 rounded-xl p-2.5">
                      No written comment left (Star rating only).
                    </p>
                  )}

                  {/* Additional Metadata Footer */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-border/30 text-[10px] text-muted-foreground font-medium">
                    <div className="flex flex-wrap items-center gap-3">
                      {r.clinicId && (
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3 text-primary-500" /> Clinic ID: <code className="font-mono">{r.clinicId.slice(0, 8)}</code>
                        </span>
                      )}
                      <span>Review ID: <code className="font-mono">{r.id.slice(0, 8)}</code></span>
                    </div>
                    {r.updatedAt && r.updatedAt !== r.createdAt && (
                      <span>Updated: {new Date(r.updatedAt).toLocaleDateString()}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </GlassCard>
    </div>
  );
}
