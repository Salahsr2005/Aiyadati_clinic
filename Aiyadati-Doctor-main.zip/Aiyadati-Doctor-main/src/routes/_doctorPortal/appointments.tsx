import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Calendar as CalendarIcon, CalendarCheck2, Check, Clock, Plus, RefreshCw, X } from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { DataTable, type Column } from "@/components/data/DataTable";
import { SelectMenu } from "@/components/data/SelectMenu";
import { StatusBadge } from "@/components/data/StatusBadge";
import { EmptyState } from "@/components/data/EmptyState";
import { ViewToggle, type ViewMode } from "@/components/data/ViewToggle";
import { AppointmentKanban } from "@/components/appointments/AppointmentKanban";
import { AppointmentDetailDrawer } from "@/components/appointments/AppointmentDetailDrawer";
import { CreateAppointmentModal } from "@/components/appointments/CreateAppointmentModal";
import { ConfirmDialog } from "@/components/data/ConfirmDialog";
import { ActivityHeatmap, aggregateByDate } from "@/components/data/ActivityHeatmap";
import { EntityMap } from "@/components/map/EntityMap";
import { ModernDatePickerModal } from "@/components/ui/ModernDatePickerModal";
import { doctorAppointmentsApi } from "@/api/doctorSelfApi";
import { fullPatientName, getPatientPhone, getCancellationOrigin, type AppointmentRow } from "@/api/appointmentsApi";
import { useMyPatientsMapPoints } from "@/hooks/useMyPatientsMapPoints";
import { useEntityMutation } from "@/lib/mutations";
import { qk } from "@/lib/queryKeys";
import { canTransitionTo, isTerminalStatus } from "@/lib/statusLifecycle";
import { translateEnum } from "@/lib/enumLabel";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_doctorPortal/appointments")({
  head: () => ({
    meta: [
      { title: "Appointments — Iyadati Doctor Portal" },
      {
        name: "description",
        content:
          "Review, confirm and update every appointment request booked with you, day by day.",
      },
      { property: "og:title", content: "Appointments — Iyadati Doctor Portal" },
      { property: "og:description", content: "Confirm requests and manage patient visits." },
    ],
  }),
  component: AppointmentsPage,
});

type DisplayMode = "today" | "week" | "month" | "custom" | "all";
type SortBy = "date_asc" | "date_desc" | "name_asc" | "status" | "created_desc" | "created_asc";

function useAppointmentsOptions(t: (key: string) => string) {
  const STATUS_OPTIONS = [
    { value: "PENDING", label: t("appointments.status.pending") },
    { value: "CONFIRMED", label: t("appointments.status.confirmed") },
    { value: "IN_PROGRESS", label: t("appointments.status.inProgress") },
    { value: "COMPLETED", label: t("appointments.status.completed") },
    { value: "CANCELLED", label: t("appointments.status.cancelled") },
    { value: "NO_SHOW", label: t("appointments.status.noShow") },
  ];

  const NEXT_STATUS: { value: string; label: string }[] = [
    { value: "IN_PROGRESS", label: t("appointments.action.startConsultation") },
    { value: "COMPLETED", label: t("appointments.action.markCompleted") },
    { value: "NO_SHOW", label: t("appointments.action.markNoShow") },
    { value: "CANCELLED", label: t("appointments.action.cancelAppointment") },
  ];

  const DISPLAY_MODE_OPTIONS: { value: DisplayMode; label: string }[] = [
    { value: "today", label: t("appointments.displayMode.today") },
    { value: "week", label: t("appointments.displayMode.week") },
    { value: "month", label: t("appointments.displayMode.month") },
    { value: "custom", label: t("appointments.displayMode.custom") },
    { value: "all", label: t("appointments.displayMode.all") },
  ];

  const SORT_OPTIONS: { value: SortBy; label: string }[] = [
    { value: "date_desc", label: t("appointments.sort.dateDesc") },
    { value: "date_asc", label: t("appointments.sort.dateAsc") },
    { value: "name_asc", label: t("appointments.sort.nameAsc") },
    { value: "status", label: t("appointments.sort.status") },
    { value: "created_desc", label: t("appointments.sort.createdDesc") },
    { value: "created_asc", label: t("appointments.sort.createdAsc") },
  ];

  return { STATUS_OPTIONS, NEXT_STATUS, DISPLAY_MODE_OPTIONS, SORT_OPTIONS };
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <GlassCard className="p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </GlassCard>
  );
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function addDaysISO(iso: string, days: number) {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function startOfWeekISO(iso: string) {
  const d = new Date(iso);
  const dow = d.getDay();
  d.setDate(d.getDate() - dow);
  return d.toISOString().slice(0, 10);
}

function startOfMonthISO(iso: string) {
  const d = new Date(iso);
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

function endOfMonthISO(iso: string) {
  const d = new Date(iso);
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10);
}

/** Compute the [start, end] ISO date window (inclusive) for a display mode. */
function computeRange(
  mode: DisplayMode,
  customStart: string,
  customEnd: string,
): { start?: string; end?: string } {
  const today = todayISO();
  switch (mode) {
    case "today":
      return { start: today, end: today };
    case "week":
      return { start: startOfWeekISO(today), end: addDaysISO(startOfWeekISO(today), 6) };
    case "month":
      return { start: startOfMonthISO(today), end: endOfMonthISO(today) };
    case "custom":
      return { start: customStart || undefined, end: customEnd || (customStart || undefined) };
    case "all":
    default:
      return {};
  }
}

function AppointmentsPage() {
  const { t, i18n } = useTranslation();
  const { STATUS_OPTIONS, NEXT_STATUS, DISPLAY_MODE_OPTIONS, SORT_OPTIONS } = useAppointmentsOptions(t);
  const [displayMode, setDisplayMode] = useState<DisplayMode>("today");
  const [customStart, setCustomStart] = useState<string>(todayISO());
  const [customEnd, setCustomEnd] = useState<string>(todayISO());
  const [status, setStatus] = useState<string | undefined>(undefined);
  const [sortBy, setSortBy] = useState<SortBy>("date_desc");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [view, setView] = useState<ViewMode>("table");
  const [selected, setSelected] = useState<AppointmentRow | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [confirmTarget, setConfirmTarget] = useState<{ row: AppointmentRow; status: string } | null>(
    null,
  );

  const range = useMemo(
    () => computeRange(displayMode, customStart, customEnd),
    [displayMode, customStart, customEnd],
  );

  // The doctor appointments API only supports filtering by a single `date`, so for
  // week/month/custom/all we pull a wide window and filter/sort/paginate client-side.
  const windowParams = useMemo(
    () => (displayMode === "today" ? { date: todayISO(), status } : { status, limit: 500 }),
    [displayMode, status],
  );

  const list = useQuery({
    queryKey: qk.doctorSelf.appointments(windowParams),
    queryFn: () => doctorAppointmentsApi.list(windowParams),
  });

  const filteredSortedRows = useMemo(() => {
    let rows = list.data?.items ?? [];

    if (range.start || range.end) {
      rows = rows.filter((r) => {
        const d = r.slot?.date?.slice(0, 10);
        if (!d) return false;
        if (range.start && d < range.start) return false;
        if (range.end && d > range.end) return false;
        return true;
      });
    }

    const sorted = [...rows].sort((a, b) => {
      switch (sortBy) {
        case "date_asc":
          return (a.slot?.date ?? "").localeCompare(b.slot?.date ?? "") ||
            (a.slot?.startTime ?? "").localeCompare(b.slot?.startTime ?? "");
        case "date_desc":
          return (b.slot?.date ?? "").localeCompare(a.slot?.date ?? "") ||
            (b.slot?.startTime ?? "").localeCompare(a.slot?.startTime ?? "");
        case "name_asc":
          return (fullPatientName(a) || "").localeCompare(fullPatientName(b) || "");
        case "status":
          return String(a.status ?? "").localeCompare(String(b.status ?? ""));
        case "created_desc":
          return (b.createdAt ?? "").localeCompare(a.createdAt ?? "");
        case "created_asc":
          return (a.createdAt ?? "").localeCompare(b.createdAt ?? "");
        default:
          return 0;
      }
    });

    return sorted;
  }, [list.data, range, sortBy]);

  const isServerPaged = displayMode === "today";

  const pagedRows = useMemo(() => {
    if (isServerPaged) return filteredSortedRows;
    const start = (page - 1) * limit;
    return filteredSortedRows.slice(start, start + limit);
  }, [filteredSortedRows, page, limit, isServerPaged]);

  const totalCount = isServerPaged ? list.data?.total ?? 0 : filteredSortedRows.length;
  const totalPages = isServerPaged
    ? list.data?.totalPages ?? 1
    : Math.max(1, Math.ceil(filteredSortedRows.length / limit));

  const heatmapData = useMemo(() => {
    const items = list.data?.items ?? [];
    return aggregateByDate(items, (a) => a.slot?.date ?? a.createdAt);
  }, [list.data]);


  const { mapPoints } = useMyPatientsMapPoints();

  const statsDate = displayMode === "today" ? todayISO() : undefined;
  const stats = useQuery({
    queryKey: qk.doctorSelf.stats(statsDate || "all"),
    queryFn: () => doctorAppointmentsApi.stats(statsDate),
  });

  const pending = useQuery({
    queryKey: qk.doctorSelf.pending(),
    queryFn: doctorAppointmentsApi.pending,
  });

  const cancellationStats = useMemo(() => {
    const items = list.data?.items ?? [];
    let byPatient = 0;
    let byDoctor = 0;
    let byOther = 0;
    let totalCancelled = 0;

    for (const item of items) {
      if (String(item.status).toUpperCase() === "CANCELLED") {
        totalCancelled++;
        const origin = getCancellationOrigin(item, i18n.language);
        if (origin.role === "PATIENT") {
          byPatient++;
        } else if (origin.role === "DOCTOR" || origin.role === "CLINIC" || origin.role === "ADMIN") {
          byDoctor++;
        } else {
          byOther++;
        }
      }
    }

    return { totalCancelled, byPatient, byDoctor, byOther };
  }, [list.data?.items, i18n.language]);

  const strictlyPendingRequests = useMemo(() => {
    return (pending.data || []).filter(
      (a) => String(a.status).toUpperCase() === "PENDING"
    );
  }, [pending.data]);

  const invalidate = [
    qk.doctorSelf.appointmentsAll(),
    qk.doctorSelf.pending(),
    qk.doctorSelf.stats(statsDate || "all"),
  ];

  const confirmAppt = useEntityMutation<string>({
    mutationFn: (id) => doctorAppointmentsApi.confirm(id),
    invalidate,
    successMessage: "Appointment confirmed",
    onError: (err: any) => {
      void list.refetch();
      void pending.refetch();
      toast.error(err?.message || "Cannot confirm appointment (it may have been cancelled or updated).");
    },
  });

  const changeStatus = useEntityMutation<{ id: string; status: string }>({
    mutationFn: ({ id, status: s }) => doctorAppointmentsApi.updateStatus(id, s),
    invalidate,
    successMessage: "Status updated",
    onSuccess: () => setSelected(null),
    onError: (err: any) => {
      void list.refetch();
      void pending.refetch();
      toast.error(err?.message || "Status update failed.");
    },
  });

  const columns: Column<AppointmentRow>[] = [
    {
      key: "time",
      header: "Time",
      render: (r) => (
        <div className="font-medium">
          {r.slot?.startTime?.slice(0, 5) ?? "--:--"}
          <div className="text-xs text-muted-foreground">{r.slot?.date ?? ""}</div>
        </div>
      ),
    },
    {
      key: "patient",
      header: "Patient",
      render: (r) => {
        const name = fullPatientName(r);
        const phone = getPatientPhone(r);
        return (
          <div className="min-w-0">
            <div className="truncate font-bold text-sm text-foreground">{name || "Walk-In Patient"}</div>
            <div className="truncate text-xs text-muted-foreground font-mono">{phone}</div>
          </div>
        );
      },
    },
    {
      key: "type",
      header: "Type",
      render: (r) => <span className="text-xs font-semibold">{translateEnum(t, i18n, "type", r.type)}</span>,
    },
    {
      key: "payment",
      header: "Payment",
      render: (r) => <span className="text-xs font-semibold">{translateEnum(t, i18n, "payment", r.paymentMethod)}</span>,
    },
    {
      key: "status",
      header: "Status",
      render: (r) => {
        const isCancelled = String(r.status).toUpperCase() === "CANCELLED";
        const origin = getCancellationOrigin(r, i18n.language);
        return (
          <div className="space-y-0.5">
            <StatusBadge value={String(r.status ?? "")} />
            {isCancelled && (
              <div className="text-[10px] text-danger font-bold truncate">
                {origin.label}
              </div>
            )}
          </div>
        );
      },
    },
    {
      key: "actions",
      header: "",
      align: "end",
      render: (r) => {
        const st = String(r.status ?? "").toUpperCase();
        return (
          <div className="flex justify-end items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {canTransitionTo(st, "CONFIRMED") && (
              <button
                onClick={() => confirmAppt.mutate(r.id)}
                className="inline-flex items-center gap-1 rounded-xl bg-success/15 px-2.5 py-1 text-xs font-bold text-success hover:bg-success/25 transition"
              >
                <Check className="h-3 w-3" /> Confirm
              </button>
            )}
            {canTransitionTo(st, "IN_PROGRESS") && (
              <button
                onClick={() => changeStatus.mutate({ id: r.id, status: "IN_PROGRESS" })}
                className="inline-flex items-center gap-1 rounded-xl bg-warning/15 px-2.5 py-1 text-xs font-bold text-warning hover:bg-warning/25 transition"
              >
                Start
              </button>
            )}
            {canTransitionTo(st, "COMPLETED") && (
              <button
                onClick={() => changeStatus.mutate({ id: r.id, status: "COMPLETED" })}
                className="inline-flex items-center gap-1 rounded-xl bg-success px-2.5 py-1 text-xs font-bold text-success-foreground hover:bg-success/90 transition"
              >
                Complete
              </button>
            )}
            {canTransitionTo(st, "CANCELLED") && (
              <button
                onClick={() => setConfirmTarget({ row: r, status: "CANCELLED" })}
                className="inline-flex items-center gap-1 rounded-xl bg-danger/15 px-2.5 py-1 text-xs font-bold text-danger hover:bg-danger/25 transition"
              >
                <X className="h-3 w-3" /> Cancel
              </button>
            )}
          </div>
        );
      },
    },
  ];

  const rows = pagedRows;

  let mainContent;
  if (view === "heatmap") {
    mainContent = (
      <ActivityHeatmap
        data={heatmapData}
        weeks={26}
        title="Booking activity"
        subtitle="Click a cell to inspect bookings for that date"
        tone="primary"
        onCellClick={(d) => {
          setDisplayMode("custom");
          setCustomStart(d.date);
          setCustomEnd(d.date);
          setView("table");
        }}
      />
    );
  } else if (view === "map") {
    mainContent = (
      <GlassCard className="overflow-hidden p-0">
        <div className="p-4 border-b border-border/40">
          <h2 className="text-sm font-semibold">Where your patients come from</h2>
          <p className="text-xs text-muted-foreground">Patient distribution by wilaya</p>
        </div>
        <EntityMap
          points={mapPoints}
          height={500}
          emptyLabel="No patient location data available"
          showUserLocation
        />
      </GlassCard>
    );
  } else if (view === "kanban") {
    mainContent = rows.length === 0 ? (
      <GlassCard className="p-4">
        <EmptyState icon={CalendarCheck2} title="No appointments" description="Try another date or status filter." />
      </GlassCard>
    ) : (
      <AppointmentKanban rows={rows} onOpen={setSelected} hideDoctor />
    );
  } else {
    mainContent = (
      <DataTable
        columns={columns}
        rows={rows}
        loading={list.isLoading}
        error={list.error as Error | null}
        page={page}
        totalPages={totalPages}
        total={totalCount}
        limit={limit}
        onPage={setPage}
        onLimit={(n) => {
          setLimit(n);
          setPage(1);
        }}
        onRowClick={setSelected}
        emptyTitle="No appointments"
        emptyDescription="Nothing matches this filter."
      />
    );
  }

  return (
    <div className="space-y-5 overflow-x-hidden">
      <PageHeader
        title="Appointments"
        subtitle="Confirm requests and keep every visit up to date"
        actions={
          <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
            <div className="flex flex-wrap items-center gap-2">
              <SelectMenu
                value={displayMode}
                onChange={(v) => {
                  setDisplayMode((v as DisplayMode) ?? "today");
                  setPage(1);
                }}
                options={DISPLAY_MODE_OPTIONS}
                placeholder="Today"
                className="w-40"
              />

              {displayMode === "custom" && (
                <ModernDatePickerModal
                  mode="range"
                  startDate={customStart}
                  endDate={customEnd}
                  onSelectRange={(start, end) => {
                    setCustomStart(start);
                    setCustomEnd(end);
                    setPage(1);
                  }}
                  label="Select Date Range"
                  placeholder="Select Date Range"
                />
              )}

              <SelectMenu
                value={status}
                onChange={(v) => {
                  setStatus(v);
                  setPage(1);
                }}
                options={STATUS_OPTIONS}
                placeholder="All statuses"
                className="w-44"
              />

              <SelectMenu
                value={sortBy}
                onChange={(v) => setSortBy((v as SortBy) ?? "date_desc")}
                options={SORT_OPTIONS}
                placeholder="Sort by"
                className="w-48"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setCreateModalOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-3.5 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition shrink-0"
              >
                <Plus className="h-4 w-4" /> Book Walk-In
              </button>
              <ViewToggle value={view} onChange={setView} modes={["table", "kanban", "heatmap", "map"]} />
              <button
                onClick={() => void list.refetch()}
                className="glass grid h-9 w-9 shrink-0 place-items-center rounded-xl"
                aria-label="refresh"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>
          </div>
        }
      />

      {/* Date Quick Filter Pills Bar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-2xl bg-muted/20 border border-border/30">
          {[
            { id: "today" as const, label: "Today" },
            { id: "week" as const, label: "This Week" },
            { id: "month" as const, label: "This Month" },
            { id: "all" as const, label: "All Time" },
          ].map((pill) => (
            <button
              key={pill.id}
              onClick={() => {
                setDisplayMode(pill.id);
                setPage(1);
              }}
              className={cn(
                "rounded-xl px-3.5 py-1 text-xs font-bold transition",
                displayMode === pill.id
                  ? "bg-primary-500 text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/30",
              )}
            >
              {pill.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-muted-foreground font-semibold">
          Showing <span className="font-bold text-foreground font-mono">{filteredSortedRows.length}</span> appointments
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-4 xl:grid-cols-8">
        <Stat label="Total" value={stats.data?.total ?? 0} />
        <Stat label="Pending" value={stats.data?.pending ?? 0} />
        <Stat label="Confirmed" value={stats.data?.confirmed ?? 0} />
        <Stat label="In progress" value={stats.data?.in_progress ?? 0} />
        <Stat label="Completed" value={stats.data?.completed ?? 0} />
        <Stat label="No show" value={stats.data?.no_show ?? 0} />
        <Stat label="Canceled (Patient)" value={cancellationStats.byPatient} />
        <Stat label="Canceled (Doctor)" value={cancellationStats.byDoctor} />
      </div>

      {strictlyPendingRequests.length > 0 && (
        <GlassCard className="p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-foreground">
              <Clock className="h-4 w-4 text-warning animate-pulse" />
              {strictlyPendingRequests.length} request{strictlyPendingRequests.length === 1 ? "" : "s"} awaiting your confirmation
            </div>
          </div>
          <ul className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
            {strictlyPendingRequests.slice(0, 6).map((a) => (
              <li
                key={a.id}
                className="glass flex items-center gap-2 rounded-2xl p-3 hover:bg-muted/30 transition"
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold text-foreground">
                    {fullPatientName(a) || "Patient"}
                  </div>
                  <div className="truncate text-xs text-muted-foreground font-mono">
                    {a.slot?.date} · {a.slot?.startTime?.slice(0, 5)}
                  </div>
                </div>
                <button
                  onClick={() => confirmAppt.mutate(a.id)}
                  disabled={confirmAppt.isPending}
                  className="rounded-xl bg-success px-3.5 py-1.5 text-xs font-bold text-success-foreground hover:bg-success/90 transition shadow-xs disabled:opacity-50"
                >
                  {confirmAppt.isPending ? "Confirming…" : "Confirm"}
                </button>
              </li>
            ))}
          </ul>
        </GlassCard>
      )}

      <div className="min-w-0 overflow-x-auto">{mainContent}</div>

      <AppointmentDetailDrawer appt={selected} open={!!selected} onClose={() => setSelected(null)} hideDoctor />

      {selected && !isTerminalStatus(selected.status) && (
        <div className="fixed bottom-4 left-1/2 z-50 flex w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 flex-wrap justify-center gap-2 rounded-2xl bg-card/95 border border-border/50 p-2.5 shadow-2xl backdrop-blur">
          {canTransitionTo(selected.status, "CONFIRMED") && (
            <button
              onClick={() => confirmAppt.mutate(selected.id)}
              className="rounded-xl bg-success px-3.5 py-1.5 text-xs font-bold text-success-foreground hover:bg-success/90 transition shadow-xs"
            >
              Confirm Appointment
            </button>
          )}
          {canTransitionTo(selected.status, "IN_PROGRESS") && (
            <button
              onClick={() => changeStatus.mutate({ id: selected.id, status: "IN_PROGRESS" })}
              className="rounded-xl bg-warning px-3.5 py-1.5 text-xs font-bold text-warning-foreground hover:bg-warning/90 transition shadow-xs"
            >
              Start Visit
            </button>
          )}
          {canTransitionTo(selected.status, "COMPLETED") && (
            <button
              onClick={() => changeStatus.mutate({ id: selected.id, status: "COMPLETED" })}
              className="rounded-xl bg-primary-500 px-3.5 py-1.5 text-xs font-bold text-primary-foreground hover:bg-primary-600 transition shadow-xs"
            >
              Complete Visit
            </button>
          )}
          {canTransitionTo(selected.status, "NO_SHOW") && (
            <button
              onClick={() => setConfirmTarget({ row: selected, status: "NO_SHOW" })}
              className="glass rounded-xl px-3.5 py-1.5 text-xs font-bold border border-border hover:bg-muted/40 transition"
            >
              Mark No-Show
            </button>
          )}
          {canTransitionTo(selected.status, "CANCELLED") && (
            <button
              onClick={() => setConfirmTarget({ row: selected, status: "CANCELLED" })}
              className="rounded-xl bg-danger/15 text-danger border border-danger/30 px-3.5 py-1.5 text-xs font-bold hover:bg-danger/25 transition"
            >
              Cancel
            </button>
          )}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmTarget}
        onClose={() => setConfirmTarget(null)}
        onConfirm={() => {
          if (confirmTarget) changeStatus.mutate({ id: confirmTarget.row.id, status: confirmTarget.status });
          setConfirmTarget(null);
        }}
        title={`Set status to ${confirmTarget?.status ?? ""}?`}
        description={`This updates the appointment for ${fullPatientName(confirmTarget?.row) || "the patient"}.`}
        danger={confirmTarget?.status === "CANCELLED" || confirmTarget?.status === "NO_SHOW"}
        confirmLabel="Update status"
      />

      <CreateAppointmentModal
        open={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
      />
    </div>
  );
}
