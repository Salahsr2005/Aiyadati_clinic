import { useMemo, useState, useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Users,
  Search,
  Phone,
  Mail,
  Calendar,
  CreditCard,
  CheckCircle2,
  XCircle,
  Award,
  FileText,
  Save,
  Clock,
  Sparkles,
  ArrowUpDown,
  Filter,
  FileIcon,
  Eye,
  Download,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Building,
  MapPin,
  Trash2,
  ExternalLink,
  X,
  RotateCcw,
} from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { DataTable, type Column } from "@/components/data/DataTable";
import { SearchInput } from "@/components/data/SearchInput";
import { SelectMenu } from "@/components/data/SelectMenu";
import { Drawer } from "@/components/data/Drawer";
import { StatusBadge } from "@/components/data/StatusBadge";
import { EmptyState } from "@/components/data/EmptyState";
import { doctorAppointmentsApi } from "@/api/doctorSelfApi";
import { fullPatientName, type AppointmentRow } from "@/api/appointmentsApi";
import { qk } from "@/lib/queryKeys";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { MedicalDocsDrawer } from "@/components/patients/MedicalDocsDrawer";

export const Route = createFileRoute("/_doctorPortal/patients")({
  head: () => ({
    meta: [
      { title: "My Patients — Iyadati Doctor Portal" },
      {
        name: "description",
        content:
          "Everyone who has booked with you, with their full visit history, contact details, medical documents, and clinical notes.",
      },
      { property: "og:title", content: "My Patients — Iyadati Doctor Portal" },
      { property: "og:description", content: "Patient roster and consultation history." },
    ],
  }),
  component: PatientsPage,
});

export interface UserDocument {
  id: string;
  userId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  title?: string;
  description?: string;
  docDate?: string;
  tags?: string;
  accessUrl: string;
  createdAt: string;
}

interface PatientAggregate {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  wilaya?: string;
  baladya?: string;
  trustLevel?: number;
  trustPoints?: number;
  isSuspended?: boolean;
  visits: number;
  completed: number;
  cancelled: number;
  totalSpent: number;
  completionRate: number;
  lastVisit?: string;
  tier: "VIP" | "Frequent" | "Returning" | "New";
  appointments: AppointmentRow[];
  documents: UserDocument[];
}

type SortOption = "recent" | "visits" | "revenue" | "name";
type CategoryFilter = "all" | "frequent" | "completed" | "has_notes" | "has_docs" | "suspended";
type DetailTab = "overview" | "notes" | "documents" | "history";

function getPatientTier(visits: number): PatientAggregate["tier"] {
  if (visits >= 5) return "VIP";
  if (visits >= 3) return "Frequent";
  if (visits >= 2) return "Returning";
  return "New";
}

function formatBytes(bytes: number, decimals = 1) {
  if (!bytes || bytes === 0) return "0 B";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function PatientsPage() {
  const { t } = useTranslation();
  // Global & Field Search
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<CategoryFilter>("all");
  const [selectedWilaya, setSelectedWilaya] = useState<string>("all");
  const [selectedTier, setSelectedTier] = useState<string>("all");
  
  // Date Range Filters
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");

  const [sortBy, setSortBy] = useState<SortOption>("recent");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [selected, setSelected] = useState<PatientAggregate | null>(null);
  const [activeTab, setActiveTab] = useState<DetailTab>("overview");
  const [previewDoc, setPreviewDoc] = useState<UserDocument | null>(null);
  const [medicalDocsPatient, setMedicalDocsPatient] = useState<{ id: string; name: string } | null>(null);

  // Clinical Notes local state & version bump for re-render triggering
  const [patientNote, setPatientNote] = useState("");
  const [notesVersion, setNotesVersion] = useState(0);

  // Sync clinical note whenever selected patient changes
  useEffect(() => {
    if (selected?.id) {
      try {
        const saved = localStorage.getItem(`iyadati_patient_note_${selected.id}`) || "";
        setPatientNote(saved);
      } catch (err) {
        console.error("Failed to load note from localStorage", err);
        setPatientNote("");
      }
      setActiveTab("overview");
    }
  }, [selected?.id]);

  const handleSaveNote = () => {
    if (!selected?.id) return;
    try {
      localStorage.setItem(`iyadati_patient_note_${selected.id}`, patientNote);
      setNotesVersion((v) => v + 1); // Trigger update
      toast.success(t("patients.notes.savedToast"));
    } catch (err) {
      toast.error(t("patients.notes.saveErrorToast"));
    }
  };

  const handleClearNote = () => {
    if (!selected?.id) return;
    try {
      localStorage.removeItem(`iyadati_patient_note_${selected.id}`);
      setPatientNote("");
      setNotesVersion((v) => v + 1); // Trigger update
      toast.info(t("patients.notes.clearedToast"));
    } catch (err) {
      toast.error(t("patients.notes.clearErrorToast"));
    }
  };

  const handleResetFilters = () => {
    setSearch("");
    setCategory("all");
    setSelectedWilaya("all");
    setSelectedTier("all");
    setDateFrom("");
    setDateTo("");
    setPage(1);
  };

  const history = useQuery({
    queryKey: qk.doctorSelf.appointments({ scope: "patients", limit: 1000 }),
    queryFn: () => doctorAppointmentsApi.list({ limit: 1000 }),
  });

  const patients = useMemo<PatientAggregate[]>(() => {
    const map = new Map<string, PatientAggregate>();
    (history.data?.items ?? []).forEach((a) => {
      const p = a.patient ?? a.contactUser;
      const id = p?.id ?? a.patientId;
      if (!id) return;

      const userObj = a.patient as any;

      const existing: PatientAggregate = map.get(id) ?? {
        id,
        name: fullPatientName(p) || t("patients.table.name"),
        phone: p?.phone,
        email: p?.email,
        wilaya: userObj?.wilaya?.nameFr ?? (p as any)?.wilaya?.nameFr,
        baladya: userObj?.baladya?.nameFr,
        trustLevel: userObj?.trustLevel ?? 1,
        trustPoints: userObj?.trustPoints ?? 0,
        isSuspended: userObj?.isSuspended ?? false,
        visits: 0,
        completed: 0,
        cancelled: 0,
        totalSpent: 0,
        completionRate: 0,
        tier: "New",
        appointments: [],
        documents: (userObj?.documents ?? []) as UserDocument[],
      };

      existing.visits += 1;
      const st = String(a.status ?? "").toUpperCase();
      if (st === "COMPLETED") {
        existing.completed += 1;
        existing.totalSpent += 1500;
      }
      if (st === "CANCELLED" || st === "NO_SHOW") existing.cancelled += 1;

      const date = a.slot?.date ?? a.createdAt?.slice(0, 10);
      if (date && (!existing.lastVisit || date > existing.lastVisit)) existing.lastVisit = date;

      existing.appointments.push(a);
      existing.tier = getPatientTier(existing.visits);
      existing.completionRate = Math.round((existing.completed / existing.visits) * 100);

      map.set(id, existing);
    });

    return Array.from(map.values());
  }, [history.data]);

  const wilayaOptions = useMemo(() => {
    const set = new Set<string>();
    patients.forEach((p) => {
      if (p.wilaya) set.add(p.wilaya);
    });
    return [
      { value: "all", label: t("patients.filters.allWilayas") },
      ...Array.from(set).map((w) => ({ value: w, label: w })),
    ];
  }, [patients]);

  const filteredAndSorted = useMemo(() => {
    let result = [...patients];

    const q = search.trim().toLowerCase();
    if (q) {
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.phone ?? "").toLowerCase().includes(q) ||
          (p.email ?? "").toLowerCase().includes(q) ||
          (p.wilaya ?? "").toLowerCase().includes(q) ||
          (p.baladya ?? "").toLowerCase().includes(q),
      );
    }

    if (category === "frequent") {
      result = result.filter((p) => p.visits >= 3);
    } else if (category === "completed") {
      result = result.filter((p) => p.completed > 0);
    } else if (category === "has_notes") {
      result = result.filter((p) => !!localStorage.getItem(`iyadati_patient_note_${p.id}`));
    } else if (category === "has_docs") {
      result = result.filter((p) => p.documents && p.documents.length > 0);
    } else if (category === "suspended") {
      result = result.filter((p) => p.isSuspended);
    }

    if (selectedWilaya !== "all") {
      result = result.filter((p) => p.wilaya === selectedWilaya);
    }

    if (selectedTier !== "all") {
      result = result.filter((p) => p.tier === selectedTier);
    }

    if (dateFrom) {
      result = result.filter((p) => p.lastVisit && p.lastVisit >= dateFrom);
    }
    if (dateTo) {
      result = result.filter((p) => p.lastVisit && p.lastVisit <= dateTo);
    }

    if (sortBy === "recent") {
      result.sort((a, b) => (b.lastVisit ?? "").localeCompare(a.lastVisit ?? ""));
    } else if (sortBy === "visits") {
      result.sort((a, b) => b.visits - a.visits);
    } else if (sortBy === "revenue") {
      result.sort((a, b) => b.totalSpent - a.totalSpent);
    } else if (sortBy === "name") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    }

    return result;
  }, [patients, search, category, selectedWilaya, selectedTier, dateFrom, dateTo, sortBy, notesVersion]);

  const totalPages = Math.max(1, Math.ceil(filteredAndSorted.length / limit));
  const rows = filteredAndSorted.slice((page - 1) * limit, page * limit);

  const columns: Column<PatientAggregate>[] = [
    {
      key: "name",
      header: t("patients.table.name"),
      render: (r) => (
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-500/10 text-primary-500 font-bold text-xs shadow-sm">
            {r.name.slice(0, 2).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="truncate font-semibold text-foreground">{r.name}</span>
              <TierBadge tier={r.tier} />
              {r.isSuspended && (
                <span className="rounded bg-danger/10 px-1.5 py-0.5 text-[10px] font-bold text-danger">
                  {t("patients.badge.suspended")}
                </span>
              )}
            </div>
            <div className="truncate text-xs text-muted-foreground">{r.email ?? t("patients.table.noEmail")}</div>
          </div>
        </div>
      ),
    },
    {
      key: "phone",
      header: "Contact / Location",
      render: (r) => (
        <div className="text-xs space-y-0.5">
          <div className="font-medium text-foreground tabular-nums">{r.phone ?? "—"}</div>
          {r.wilaya && <div className="text-muted-foreground text-[11px]">{r.wilaya}</div>}
        </div>
      ),
    },
    {
      key: "visits",
      header: "Visits & Status",
      render: (r) => (
        <div className="font-medium text-xs space-y-0.5">
          <div>
            {r.visits} {r.visits === 1 ? "visit" : "visits"}{" "}
            <span className="text-muted-foreground">({r.completed} completed)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-success rounded-full"
                style={{ width: `${r.completionRate}%` }}
              />
            </div>
            <span className="text-[10px] font-bold tabular-nums text-muted-foreground">
              {r.completionRate}%
            </span>
          </div>
        </div>
      ),
    },
    {
      key: "spent",
      header: "Est. Revenue",
      render: (r) => (
        <span className="text-sm font-bold text-success tabular-nums">
          {r.totalSpent.toLocaleString()} DZD
        </span>
      ),
    },
    {
      key: "last",
      header: "Last Visit",
      render: (r) => (
        <div className="text-xs tabular-nums text-foreground">
          {r.lastVisit ? r.lastVisit : <span className="text-muted-foreground">Never</span>}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <PageHeader
        title="My Patients"
        subtitle={`${patients.length} unique patient${
          patients.length === 1 ? "" : "s"
        } recorded across your consultation history`}
        actions={
          <div className="w-72">
            <SearchInput
              value={search}
              onChange={(v) => {
                setSearch(v);
                setPage(1);
              }}
              placeholder="Search name, phone, email, wilaya..."
            />
          </div>
        }
      />

      <GlassCard className="p-4 space-y-3.5 border border-border/40">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-border/30">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium">
            <span className="text-muted-foreground mr-1 flex items-center gap-1 font-semibold">
              <Filter className="h-3.5 w-3.5" /> Category:
            </span>
            {(
              [
                { id: "all", label: "All Patients" },
                { id: "frequent", label: "Frequent (3+)" },
                { id: "completed", label: "Completed" },
                { id: "has_notes", label: "Has Notes" },
                { id: "has_docs", label: "Has Docs" },
                { id: "suspended", label: "Suspended" },
              ] as const
            ).map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setCategory(c.id);
                  setPage(1);
                }}
                className={cn(
                  "rounded-full px-3 py-1 text-xs transition font-medium",
                  category === c.id
                    ? "bg-primary-500 text-primary-foreground font-semibold shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                {c.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleResetFilters}
            className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition"
          >
            <RotateCcw className="h-3 w-3" /> Reset Filters
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 items-center">
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" /> Visit From:
            </label>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => {
                setDateFrom(e.target.value);
                setPage(1);
              }}
              className="glass w-full rounded-xl px-3 py-1.5 text-xs text-foreground outline-none border border-border/40 focus:border-primary-500 transition"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" /> Visit To:
            </label>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => {
                setDateTo(e.target.value);
                setPage(1);
              }}
              className="glass w-full rounded-xl px-3 py-1.5 text-xs text-foreground outline-none border border-border/40 focus:border-primary-500 transition"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <MapPin className="h-3 w-3" /> Wilaya:
            </label>
            <SelectMenu
              value={selectedWilaya}
              onChange={(v) => {
                if (v) setSelectedWilaya(v);
                setPage(1);
              }}
              options={wilayaOptions}
              className="w-full text-xs"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <Award className="h-3 w-3" /> Tier / Status:
            </label>
            <SelectMenu
              value={selectedTier}
              onChange={(v) => {
                if (v) setSelectedTier(v);
                setPage(1);
              }}
              options={[
                { value: "all", label: "All Tiers" },
                { value: "VIP", label: "VIP (5+ Visits)" },
                { value: "Frequent", label: "Frequent (3-4 Visits)" },
                { value: "Returning", label: "Returning (2 Visits)" },
                { value: "New", label: "New (1 Visit)" },
              ]}
              className="w-full text-xs"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <ArrowUpDown className="h-3 w-3" /> Sort By:
            </label>
            <SelectMenu
              value={sortBy}
              onChange={(v) => v && setSortBy(v as SortOption)}
              options={[
                { value: "recent", label: "Most recent visit" },
                { value: "visits", label: "Most total visits" },
                { value: "revenue", label: "Highest revenue" },
                { value: "name", label: "Alphabetical (A-Z)" },
              ]}
              className="w-full text-xs"
            />
          </div>
        </div>
      </GlassCard>

      {!history.isLoading && patients.length === 0 ? (
        <GlassCard className="p-8">
          <EmptyState
            icon={Users}
            title="No patients found"
            description="Patients will automatically appear here once they complete or schedule consultations with you."
          />
        </GlassCard>
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          loading={history.isLoading}
          error={history.error as Error | null}
          page={page}
          totalPages={totalPages}
          total={filteredAndSorted.length}
          limit={limit}
          onPage={setPage}
          onLimit={(n) => {
            setLimit(n);
            setPage(1);
          }}
          onRowClick={setSelected}
          emptyTitle="No matching patients match your filter criteria"
          mobileCard
        />
      )}

      {/* Patient Detail Drawer */}
      <Drawer
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected?.name}
        subtitle={[selected?.phone, selected?.email].filter(Boolean).join(" · ")}
      >
        {selected && (
          <div className="space-y-5">
            {/* Patient Header */}
            <div className="glass rounded-2xl p-4 border border-border/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary-500 text-primary-foreground font-bold text-base shadow-md">
                    {selected.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-base text-foreground">{selected.name}</h3>
                      <TierBadge tier={selected.tier} />
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-2 mt-0.5">
                      {selected.wilaya && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" /> {selected.wilaya}
                          {selected.baladya ? `, ${selected.baladya}` : ""}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setMedicalDocsPatient({ id: selected.id, name: selected.name })}
                    className="grid h-9 w-9 place-items-center rounded-xl bg-primary-500/15 text-primary-500 hover:bg-primary-500/25 transition"
                    title="View Patient Consent Records"
                  >
                    <FileText className="h-4 w-4" />
                  </button>
                  {selected.phone && (
                    <a
                      href={`tel:${selected.phone}`}
                      className="grid h-9 w-9 place-items-center rounded-xl bg-success/15 text-success hover:bg-success/25 transition"
                      title="Call Patient"
                    >
                      <Phone className="h-4 w-4" />
                    </a>
                  )}
                  {selected.email && (
                    <a
                      href={`mailto:${selected.email}`}
                      className="grid h-9 w-9 place-items-center rounded-xl bg-info/15 text-info hover:bg-info/25 transition"
                      title="Send Email"
                    >
                      <Mail className="h-4 w-4" />
                    </a>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-border/30 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground font-medium">Trust Level:</span>
                  <TrustLevelBadge level={selected.trustLevel ?? 1} points={selected.trustPoints} />
                </div>

                <div>
                  {selected.isSuspended ? (
                    <span className="inline-flex items-center gap-1 font-bold text-danger text-[11px]">
                      <ShieldAlert className="h-3.5 w-3.5" /> Suspended Account
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 font-bold text-success text-[11px]">
                      <ShieldCheck className="h-3.5 w-3.5" /> Active Patient
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <GlassCard className="p-3">
                <div className="text-base font-bold text-foreground">{selected.visits}</div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase">Total Visits</div>
              </GlassCard>
              <GlassCard className="p-3">
                <div className="text-base font-bold text-success">{selected.completed}</div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase">Completed</div>
              </GlassCard>
              <GlassCard className="p-3">
                <div className="text-base font-bold text-danger">{selected.cancelled}</div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase">Cancelled</div>
              </GlassCard>
              <GlassCard className="p-3">
                <div className="text-base font-bold text-primary-500 tabular-nums">
                  {selected.totalSpent.toLocaleString()}
                </div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase">Est. DZD</div>
              </GlassCard>
            </div>

            {/* FULL-WIDTH STRETCHED TABS */}
            <div className="grid grid-cols-4 w-full bg-muted/40 p-1 rounded-xl gap-1 text-xs font-semibold">
              <button
                onClick={() => setActiveTab("overview")}
                className={cn(
                  "py-2 px-1 text-center rounded-lg transition-all",
                  activeTab === "overview"
                    ? "bg-background text-primary-500 shadow-sm font-bold"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab("notes")}
                className={cn(
                  "py-2 px-1 text-center rounded-lg transition-all flex items-center justify-center gap-1",
                  activeTab === "notes"
                    ? "bg-background text-primary-500 shadow-sm font-bold"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <span>Clinical Notes</span>
                {patientNote && <span className="h-1.5 w-1.5 rounded-full bg-primary-500" />}
              </button>
              <button
                onClick={() => setActiveTab("documents")}
                className={cn(
                  "py-2 px-1 text-center rounded-lg transition-all truncate",
                  activeTab === "documents"
                    ? "bg-background text-primary-500 shadow-sm font-bold"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                Medical Docs ({selected.documents?.length ?? 0})
              </button>
              <button
                onClick={() => setActiveTab("history")}
                className={cn(
                  "py-2 px-1 text-center rounded-lg transition-all",
                  activeTab === "history"
                    ? "bg-background text-primary-500 shadow-sm font-bold"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                History ({selected.appointments.length})
              </button>
            </div>

            {/* TAB: OVERVIEW */}
            {activeTab === "overview" && (
              <div className="space-y-4">
                <GlassCard className="p-4 space-y-3 border border-border/40">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <UserCheck className="h-3.5 w-3.5 text-primary-500" /> Patient Summary
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-muted-foreground block text-[11px]">Full Name</span>
                      <span className="font-semibold text-foreground">{selected.name}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground block text-[11px]">Phone Number</span>
                      <span className="font-semibold text-foreground tabular-nums">
                        {selected.phone ?? "N/A"}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground block text-[11px]">Email</span>
                      <span className="font-semibold text-foreground">{selected.email ?? "N/A"}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground block text-[11px]">Last Visit Date</span>
                      <span className="font-semibold text-foreground tabular-nums">
                        {selected.lastVisit ?? "N/A"}
                      </span>
                    </div>
                  </div>
                </GlassCard>

                {patientNote && (
                  <GlassCard className="p-4 space-y-2 border border-primary-500/30 bg-primary-500/5">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-primary-500 flex items-center gap-1.5">
                        <FileText className="h-3.5 w-3.5" /> Recent Clinical Note Highlight
                      </h4>
                      <button
                        onClick={() => setActiveTab("notes")}
                        className="text-[11px] font-semibold text-primary-500 hover:underline"
                      >
                        Edit Note
                      </button>
                    </div>
                    <p className="text-xs text-foreground italic whitespace-pre-wrap">{patientNote}</p>
                  </GlassCard>
                )}
              </div>
            )}

            {/* TAB: PRIVATE CLINICAL NOTES (FIXED SAVE ACTION) */}
            {activeTab === "notes" && (
              <GlassCard className="p-4 space-y-3 border border-border/40">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-foreground">
                    <FileText className="h-4 w-4 text-primary-500" />
                    Doctor's Private Clinical Notes
                  </div>
                  <div className="flex items-center gap-2">
                    {patientNote && (
                      <button
                        type="button"
                        onClick={handleClearNote}
                        className="inline-flex items-center gap-1 rounded-xl bg-danger/10 px-2.5 py-1 text-xs font-semibold text-danger hover:bg-danger/20 transition"
                      >
                        <Trash2 className="h-3 w-3" /> Clear
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleSaveNote}
                      className="inline-flex items-center gap-1 rounded-xl bg-primary-500 px-3 py-1 text-xs font-semibold text-primary-foreground hover:bg-primary-600 transition shadow-sm"
                    >
                      <Save className="h-3.5 w-3.5" /> Save Note
                    </button>
                  </div>
                </div>

                <textarea
                  rows={6}
                  value={patientNote}
                  onChange={(e) => setPatientNote(e.target.value)}
                  placeholder="Record private clinical observations, medical history, allergies, chronic conditions, prescriptions, or follow-up reminders for this patient..."
                  className="glass w-full rounded-xl p-3 text-xs text-foreground outline-none border border-border/40 focus:border-primary-500 transition leading-relaxed"
                />
                <div className="text-[11px] text-muted-foreground italic">
                  * Note: Notes saved here are linked to this patient ID and preserved in your local workspace.
                </div>
              </GlassCard>
            )}

            {/* TAB: MEDICAL DOCUMENTS */}
            {activeTab === "documents" && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <FileIcon className="h-3.5 w-3.5 text-primary-500" />
                    Patient Uploaded Documents ({selected.documents?.length ?? 0})
                  </h4>
                </div>

                {!selected.documents || selected.documents.length === 0 ? (
                  <GlassCard className="p-6 text-center space-y-2">
                    <EmptyState
                      icon={FileIcon}
                      title="No medical documents"
                      description="This patient has not shared or uploaded any medical files or prescriptions yet."
                    />
                  </GlassCard>
                ) : (
                  <div className="space-y-2.5">
                    {selected.documents.map((doc) => (
                      <GlassCard
                        key={doc.id}
                        className="p-3.5 border border-border/40 flex items-center justify-between hover:border-primary-500/30 transition"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-500/15 text-primary-500 font-bold text-xs">
                            <FileIcon className="h-5 w-5" />
                          </div>
                          <div className="min-w-0 space-y-0.5">
                            <h5 className="font-semibold text-xs text-foreground truncate">
                              {doc.title || doc.fileName}
                            </h5>
                            <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                              <span>{formatBytes(doc.fileSize)}</span>
                              <span>·</span>
                              <span>{doc.docDate || doc.createdAt?.slice(0, 10)}</span>
                              {doc.tags && (
                                <>
                                  <span>·</span>
                                  <span className="rounded bg-muted px-1.5 py-0.2 text-[9px] font-semibold text-muted-foreground">
                                    {doc.tags}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setPreviewDoc(doc)}
                            className="inline-flex items-center gap-1 rounded-xl bg-primary-500/10 px-2.5 py-1.5 text-xs font-semibold text-primary-500 hover:bg-primary-500/20 transition"
                            title="Preview file"
                          >
                            <Eye className="h-3.5 w-3.5" /> Preview
                          </button>
                          {doc.accessUrl && (
                            <a
                              href={doc.accessUrl}
                              target="_blank"
                              rel="noreferrer"
                              download
                              className="inline-flex items-center gap-1 rounded-xl bg-muted px-2.5 py-1.5 text-xs font-semibold text-foreground hover:bg-muted/80 transition"
                              title="Download document"
                            >
                              <Download className="h-3.5 w-3.5" />
                            </a>
                          )}
                        </div>
                      </GlassCard>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: APPOINTMENT HISTORY */}
            {activeTab === "history" && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-primary-500" />
                  Appointment History ({selected.appointments.length})
                </h4>

                <ul className="space-y-2.5">
                  {selected.appointments.map((a) => (
                    <li
                      key={a.id}
                      className="glass rounded-2xl p-3.5 border border-border/40 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-foreground flex items-center gap-2">
                          <Calendar className="h-3.5 w-3.5 text-primary-500" />
                          {a.slot?.date ?? a.createdAt?.slice(0, 10)}
                          <span className="text-muted-foreground font-normal">
                            at {a.slot?.startTime?.slice(0, 5) ?? "--:--"}
                          </span>
                        </div>
                        <StatusBadge value={String(a.status ?? "")} />
                      </div>

                      <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t border-border/30">
                        <span>
                          Type: <b className="text-foreground font-medium">{a.type ?? "Consultation"}</b>
                        </span>
                        <span>
                          Payment Method:{" "}
                          <b className="text-foreground font-medium">{a.paymentMethod ?? "On Site"}</b>
                        </span>
                      </div>

                      {a.notes && (
                        <div className="rounded-xl bg-muted/40 p-2.5 text-[11px] text-muted-foreground italic">
                          "{a.notes}"
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </Drawer>

      {/* Document Preview Modal */}
      {previewDoc && (
        <DocumentPreviewModal doc={previewDoc} onClose={() => setPreviewDoc(null)} />
      )}

      {/* Patient Consent Medical Documents Drawer */}
      <MedicalDocsDrawer
        patientId={medicalDocsPatient?.id || null}
        patientName={medicalDocsPatient?.name}
        open={!!medicalDocsPatient}
        onClose={() => setMedicalDocsPatient(null)}
      />
    </div>
  );
}

function TierBadge({ tier }: { tier: PatientAggregate["tier"] }) {
  const { t } = useTranslation();
  const styles = {
    VIP: "bg-warning/15 text-warning border-warning/30",
    Frequent: "bg-primary-500/15 text-primary-500 border-primary-500/30",
    Returning: "bg-info/15 text-info border-info/30",
    New: "bg-muted text-muted-foreground border-border/40",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold",
        styles[tier],
      )}
    >
      {tier === "VIP" && <Sparkles className="h-2.5 w-2.5" />}
      {t(`patients.tier.${tier}`)}
    </span>
  );
}

function TrustLevelBadge({ level, points }: { level: number; points?: number }) {
  const { t } = useTranslation();
  const colors: Record<number, string> = {
    0: "bg-danger/15 text-danger border-danger/30",
    1: "bg-muted text-muted-foreground border-border/40",
    2: "bg-success/15 text-success border-success/30",
    3: "bg-warning/15 text-warning border-warning/30",
  };

  const color = colors[level] ?? colors[1];
  const label = t(`patients.trust.${level in colors ? level : 1}`);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold",
        color,
      )}
    >
      {label} {points !== undefined && t("patients.trust.points", { points })}
    </span>
  );
}

function DocumentPreviewModal({ doc, onClose }: { doc: UserDocument; onClose: () => void }) {
  const { t } = useTranslation();
  const isImage = doc.fileType?.startsWith("image/");
  const isPdf = doc.fileType?.includes("pdf");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="glass w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl border border-border/40 shadow-2xl overflow-hidden">
        <div className="p-4 border-b border-border/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary-500/15 text-primary-500">
              <FileIcon className="h-4 w-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-foreground">{doc.title || doc.fileName}</h3>
              <p className="text-xs text-muted-foreground">
                {formatBytes(doc.fileSize)} · {t("patients.documents.uploaded", { date: doc.docDate || doc.createdAt?.slice(0, 10) })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {doc.accessUrl && (
              <a
                href={doc.accessUrl}
                target="_blank"
                rel="noreferrer"
                download
                className="inline-flex items-center gap-1 rounded-xl bg-primary-500 px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary-600 transition shadow-sm"
              >
                <Download className="h-3.5 w-3.5" /> {t("patients.documents.download")}
              </a>
            )}
            <button
              onClick={onClose}
              className="grid h-8 w-8 place-items-center rounded-xl hover:bg-muted text-muted-foreground hover:text-foreground transition"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 bg-muted/20 flex items-center justify-center min-h-[400px]">
          {isImage ? (
            <img
              src={doc.accessUrl}
              alt={doc.title || doc.fileName}
              className="max-w-full max-h-[70vh] object-contain rounded-xl shadow-md"
            />
          ) : isPdf ? (
            <iframe
              src={doc.accessUrl}
              title={doc.title || doc.fileName}
              className="w-full h-[70vh] rounded-xl border border-border/40"
            />
          ) : (
            <div className="text-center space-y-3 p-6">
              <FileIcon className="h-16 w-16 text-muted-foreground mx-auto" />
              <div className="text-sm font-semibold text-foreground">
                {t("patients.documents.notAvailable", { type: doc.fileType })}
              </div>
              {doc.accessUrl && (
                <a
                  href={doc.accessUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary-500 hover:underline"
                >
                  {t("patients.documents.openOrDownload")} <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}