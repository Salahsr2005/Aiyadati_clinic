import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Wallet } from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { KPICard } from "@/components/overview/KPICard";
import { EmptyState } from "@/components/data/EmptyState";
import { analyticsV2Api, type AnalyticsPeriod } from "@/api/analyticsV2Api";
import { useDoctorProfile } from "@/hooks/useDoctorProfile";
import { qk } from "@/lib/queryKeys";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_doctorPortal/earnings")({
  head: () => ({
    meta: [
      { title: "Earnings — Iyadati Doctor Portal" },
      {
        name: "description",
        content: "Track consultation revenue, average value per visit and monthly earning trends.",
      },
      { property: "og:title", content: "Earnings — Iyadati Doctor Portal" },
      { property: "og:description", content: "Revenue trends and payment breakdown." },
    ],
  }),
  component: EarningsPage,
});

const PERIODS: { value: AnalyticsPeriod; label: string }[] = [
  { value: "last7days", label: "7 days" },
  { value: "last30days", label: "30 days" },
  { value: "last90days", label: "90 days" },
  { value: "thisMonth", label: "This month" },
  { value: "lastMonth", label: "Last month" },
];

const money = (n: number) => `${Math.round(n).toLocaleString()} DZD`;

function EarningsPage() {
  const [period, setPeriod] = useState<AnalyticsPeriod>("last30days");
  const { data: profile } = useDoctorProfile();
  const doctorId = profile?.id;

  const revenue = useQuery({
    queryKey: qk.doctorSelf.revenue(doctorId ?? "", period),
    queryFn: () => analyticsV2Api.doctorRevenue(doctorId!, { period }),
    enabled: !!doctorId,
  });

  const details = useQuery({
    queryKey: qk.doctorSelf.analytics(doctorId ?? "", period),
    queryFn: () => analyticsV2Api.doctorDetails(doctorId!, { period }),
    enabled: !!doctorId,
  });

  const monthly = useMemo(() => {
    const fromRevenue = revenue.data?.byMonth ?? [];
    if (fromRevenue.length) return fromRevenue.map((m) => ({ month: m.month, revenue: m.revenue, appointments: m.appointments ?? 0 }));
    return (details.data?.monthlyTrends ?? []).map((m) => ({
      month: m.month,
      revenue: m.revenue,
      appointments: m.appointments,
    }));
  }, [revenue.data, details.data]);

  const byMethod = useMemo(() => {
    const src = revenue.data?.byPaymentMethod ?? {};
    return Object.entries(src).map(([method, amount]) => ({ method, amount: Number(amount) }));
  }, [revenue.data]);

  const total = revenue.data?.totalRevenue ?? details.data?.totalRevenue ?? 0;
  const avg = revenue.data?.avgRevenuePerAppointment ?? details.data?.avgRevenuePerAppointment ?? 0;
  const loading = revenue.isLoading || details.isLoading;

  return (
    <div className="space-y-5 pb-24 md:pb-8">
      <PageHeader
        title="Earnings"
        subtitle="Consultation revenue across your practice"
        actions={
          <div className="glass flex items-center gap-1 rounded-full p-1">
            {PERIODS.map((p) => (
              <button
                key={p.value}
                onClick={() => setPeriod(p.value)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-medium transition",
                  period === p.value
                    ? "bg-primary-500 text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
        }
      />

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-4">
          <KPICard label="Total revenue" value={total} format={money} tone="success" />
          <KPICard label="Average per visit" value={avg} format={money} tone="info" />
          <KPICard
            label="Completed visits"
            value={details.data?.completedAppointments ?? 0}
            subLabel={`${details.data?.totalAppointments ?? 0} total`}
            tone="primary"
          />
          <KPICard
            label="Unique patients"
            value={details.data?.uniquePatients ?? 0}
            subLabel={`${details.data?.returningPatients ?? 0} returning`}
            tone="warning"
          />
        </div>
      )}

      <GlassCard className="p-4">
        <h2 className="mb-3 text-sm font-semibold">Revenue trend</h2>
        {monthly.length === 0 ? (
          <EmptyState
            icon={Wallet}
            title="No revenue data yet"
            description="Your monthly earnings chart appears after your first completed, paid consultations."
          />
        ) : (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthly}>
                <defs>
                  <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-primary-500)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--color-primary-500)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} width={70} />
                <Tooltip formatter={(v: number) => money(Number(v))} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="var(--color-primary-500)"
                  fill="url(#revFill)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </GlassCard>

      <div className="grid gap-4 md:grid-cols-2">
        <GlassCard className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Revenue by payment method</h2>
          {byMethod.length === 0 ? (
            <EmptyState icon={Wallet} title="No payment breakdown" description="Nothing recorded for this period." />
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={byMethod}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                  <XAxis dataKey="method" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} width={70} />
                  <Tooltip formatter={(v: number) => money(Number(v))} />
                  <Bar dataKey="amount" fill="var(--color-primary-500)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </GlassCard>

        <GlassCard className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Visit outcomes</h2>
          <div className="space-y-3">
            {[
              { label: "Completion rate", value: details.data?.completionRate ?? 0, tone: "bg-success" },
              { label: "Cancellation rate", value: details.data?.cancellationRate ?? 0, tone: "bg-danger" },
              { label: "No-show rate", value: details.data?.noShowRate ?? 0, tone: "bg-warning" },
              { label: "Retention rate", value: details.data?.retentionRate ?? 0, tone: "bg-info" },
            ].map((row) => (
              <div key={row.label}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{row.label}</span>
                  <span className="font-medium">{Math.round(row.value)}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted/40">
                  <div
                    className={cn("h-full rounded-full", row.tone)}
                    style={{ width: `${Math.min(100, row.value)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
