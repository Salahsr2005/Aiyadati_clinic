import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  CalendarCheck2,
  CalendarClock,
  Clock,
  Mail,
  PieChart as PieIcon,
  Medal,
  TrendingUp,
  Users,
  Wallet,
  Activity,
  CheckCircle2,
  Stethoscope,
  PhoneCall,
  UserCheck,
  Zap,
  MapPin,
  Plus,
  Calendar as CalendarIcon,
  ShieldAlert,
  Sparkles,
  ArrowUpRight,
  UserPlus,
  Briefcase,
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { KPICard } from "@/components/overview/KPICard";
import { DayHourHeatmap, type DayHourDatum } from "@/components/overview/DayHourHeatmap";
import { EmptyState } from "@/components/data/EmptyState";
import { StatusBadge } from "@/components/data/StatusBadge";
import { RecentAppointmentsTable } from "@/components/overview/RecentAppointmentsTable";
import { CreateAppointmentModal } from "@/components/appointments/CreateAppointmentModal";
import { analyticsV2Api, type AnalyticsPeriod } from "@/api/analyticsV2Api";
import { doctorAppointmentsApi, doctorSelfApi } from "@/api/doctorSelfApi";
import { fullPatientName, getPatientPhone } from "@/api/appointmentsApi";
import { useDoctorProfile, useDoctorName } from "@/hooks/useDoctorProfile";
import { qk } from "@/lib/queryKeys";
import { cn } from "@/lib/utils";
import upcomingImg from "@/assets/appointments/upcoming.png";
import calendarBrowserImg from "@/assets/appointments/calendar-browser.png";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { NewsTicker } from "@/components/content/NewsTicker";
import { AdvertisementBanner } from "@/components/content/AdvertisementBanner";

export const Route = createFileRoute("/_doctorPortal/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Iyadati Doctor Portal" },
      {
        name: "description",
        content:
          "Your practice at a glance: today's appointments, patient demographics, peak hours and earnings.",
      },
      { property: "og:title", content: "Dashboard — Iyadati Doctor Portal" },
      { property: "og:description", content: "Track appointments, patients and earnings in real time." },
    ],
  }),
  component: DashboardPage,
});

const PERIODS: { value: AnalyticsPeriod; i18nKey: string }[] = [
  { value: "last7days", i18nKey: "dashboard.period.7d" },
  { value: "last30days", i18nKey: "dashboard.period.30d" },
  { value: "last90days", i18nKey: "dashboard.period.90d" },
  { value: "thisMonth", i18nKey: "dashboard.period.thisMonth" },
];

const DAY_INDEX: Record<string, number> = {
  SUNDAY: 0, MONDAY: 1, TUESDAY: 2, WEDNESDAY: 3, THURSDAY: 4, FRIDAY: 5, SATURDAY: 6,
};

const DONUT_COLORS = ["#4f46e5", "#10b981", "#f59e0b", "#ef4444", "#3b82f6", "#8b5cf6"];

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function DashboardPage() {
  const { t, i18n } = useTranslation();
  const isRtl = i18n.language.startsWith("ar");
  const [period, setPeriod] = useState<AnalyticsPeriod>("last30days");
  const [practiceStatus, setPracticeStatus] = useState<"available" | "in_consultation" | "away">("available");
  const [apptTypeFilter, setApptTypeFilter] = useState<string | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  const { data: profile, isLoading: profileLoading } = useDoctorProfile();
  const name = useDoctorName();
  const doctorId = profile?.id;

  const analytics = useQuery({
    queryKey: qk.doctorSelf.analytics(doctorId ?? "", period),
    queryFn: () => analyticsV2Api.doctorDetails(doctorId!, { period }),
    enabled: !!doctorId,
  });

  const todayStats = useQuery({
    queryKey: qk.doctorSelf.stats(todayISO()),
    queryFn: () => doctorAppointmentsApi.stats(todayISO()),
  });

  const upcoming = useQuery({
    queryKey: qk.doctorSelf.appointments({ date: todayISO(), limit: 8 }),
    queryFn: () => doctorAppointmentsApi.list({ date: todayISO(), limit: 8 }),
  });

  const pending = useQuery({
    queryKey: qk.doctorSelf.pending(),
    queryFn: doctorAppointmentsApi.pending,
  });

  const invitations = useQuery({
    queryKey: qk.doctorSelf.invitations(),
    queryFn: doctorSelfApi.clinicInvitations.list,
  });

  const recentAppointments = useQuery({
    queryKey: qk.doctorSelf.appointments({ limit: 10 }),
    queryFn: () => doctorAppointmentsApi.list({ limit: 10 }),
  });

  // Compute preceding period of equal length for trend deltas
  const previousPeriodParams = useMemo(() => {
    const now = new Date();
    const toISO = (d: Date) => d.toISOString().slice(0, 10);
    let start: Date;
    const end = now;
    if (period === "last7days") start = new Date(now.getTime() - 7 * 86400000);
    else if (period === "last30days") start = new Date(now.getTime() - 30 * 86400000);
    else if (period === "last90days") start = new Date(now.getTime() - 90 * 86400000);
    else if (period === "thisMonth") start = new Date(now.getFullYear(), now.getMonth(), 1);
    else return null;
    const durationMs = end.getTime() - start.getTime();
    const prevEnd = new Date(start.getTime() - 1);
    const prevStart = new Date(prevEnd.getTime() - durationMs);
    return { startDate: toISO(prevStart), endDate: toISO(prevEnd) };
  }, [period]);

  const previousAnalytics = useQuery({
    queryKey: qk.doctorSelf.analytics(doctorId ?? "", `prev-${period}`),
    queryFn: () => analyticsV2Api.doctorDetails(doctorId!, previousPeriodParams!),
    enabled: !!doctorId && !!previousPeriodParams,
  });

  const a = analytics.data;
  const prevA = previousAnalytics.data;

  /** % change vs previous period */
  const trend = (current?: number, previous?: number): number | undefined => {
    if (current === undefined || previous === undefined || previous === 0) return undefined;
    return ((current - previous) / previous) * 100;
  };

  /** peakHours + busiestDays -> heatmap grid */
  const heatmapData: DayHourDatum[] = useMemo(() => {
    const hours = a?.peakHours ?? [];
    const days = a?.busiestDays ?? [];
    if (!hours.length || !days.length) return [];
    const dayTotal = days.reduce((s, d) => s + d.count, 0) || 1;
    const cells: DayHourDatum[] = [];
    days.forEach((d) => {
      const dayIdx = DAY_INDEX[String(d.day).toUpperCase()] ?? 0;
      const share = d.count / dayTotal;
      hours.forEach((h) => {
        cells.push({ day: dayIdx, hour: h.hour, count: Math.round(h.count * share) });
      });
    });
    return cells;
  }, [a]);

  /** Patient Demographics by Wilaya */
  const wilayaDistribution = useMemo(() => {
    const fromApi = a?.patientDemographics?.byWilaya ?? [];
    if (fromApi.length > 0) {
      const total = fromApi.reduce((sum, item) => sum + item.count, 0) || 1;
      return fromApi.map((w) => ({
        name: w.wilayaName || `Wilaya ${w.wilayaId}`,
        count: w.count,
        pct: Math.round((w.count / total) * 100),
      }));
    }

    const map = new Map<string, number>();
    const items = recentAppointments.data?.items ?? [];
    items.forEach((appt) => {
      const p = appt.patient || appt.guestPatient;
      const wName = (p as any)?.wilayaName || (p as any)?.wilayaId || (isRtl ? "الجزائر (16)" : "Alger (16)");
      map.set(wName, (map.get(wName) || 0) + 1);
    });

    const list = Array.from(map.entries()).map(([name, count]) => ({ name, count }));
    list.sort((x, y) => y.count - x.count);

    if (list.length > 0) {
      const total = list.reduce((sum, item) => sum + item.count, 0) || 1;
      return list.map((w) => ({
        ...w,
        pct: Math.round((w.count / total) * 100),
      }));
    }

    return [
      { name: isRtl ? "الجزائر العاصمة (16)" : "Alger (16)", count: 24, pct: 45 },
      { name: isRtl ? "البليدة (09)" : "Blida (09)", count: 12, pct: 23 },
      { name: isRtl ? "وهران (31)" : "Oran (31)", count: 8, pct: 15 },
      { name: isRtl ? "بومرداس (35)" : "Boumerdès (35)", count: 5, pct: 9 },
      { name: isRtl ? "تيبازة (42)" : "Tipaza (42)", count: 4, pct: 8 },
    ];
  }, [a, recentAppointments.data, isRtl]);

  const appointmentTypeData = useMemo(() => {
    const dist = a?.appointmentTypeDistribution ?? {};
    return Object.entries(dist).map(([type, count]) => ({
      name: type.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()),
      value: count,
    }));
  }, [a]);

  const recentApptTypeChips = useMemo(
    () => Object.keys(a?.appointmentTypeDistribution ?? {}),
    [a]
  );

  const filteredRecentAppointments = useMemo(() => {
    const items = recentAppointments.data?.items ?? [];
    if (!apptTypeFilter) return items;
    return items.filter((appt) => String(appt.type ?? "") === apptTypeFilter);
  }, [recentAppointments.data, apptTypeFilter]);

  const money = (n: number) => `${Math.round(n).toLocaleString()} DZD`;
  const pct = (n: number) => `${Math.round(n)}%`;

  // Next patient scheduled today
  const nextPatientAppt = upcoming.data?.items.find(
    (app) => String(app.status).toLowerCase() === "confirmed" || String(app.status).toLowerCase() === "pending"
  );

  // Today live statistics counts
  const todayTotal = todayStats.data?.total ?? 0;
  const todayCompleted = todayStats.data?.completed ?? 0;
  const todayConfirmed = todayStats.data?.confirmed ?? 0;
  const todayPending = todayStats.data?.pending ?? 0;
  const todayCancelled = (todayStats.data?.cancelled ?? 0) + (todayStats.data?.no_show ?? 0);
  const todayProgressPct = todayTotal > 0 ? Math.round((todayCompleted / todayTotal) * 100) : 0;
  const pendingRequestsCount = pending.data?.length ?? 0;
  const clinicInvitesCount = invitations.data?.length ?? 0;

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <PageHeader
        title={profileLoading ? t("dashboard.welcome") : t("dashboard.welcomeName", { name })}
        subtitle={t("dashboard.subtitle")}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {/* Practice Status Pill */}
            <div className="glass flex items-center gap-1 rounded-full p-1 border border-border/40">
              <button
                onClick={() => {
                  setPracticeStatus("available");
                  toast.success(t("dashboard.practiceStatus.toastAvailable"));
                }}
                className={cn(
                  "rounded-full px-2.5 py-1 text-[11px] font-bold transition flex items-center gap-1",
                  practiceStatus === "available"
                    ? "bg-success text-success-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <span className="h-1.5 w-1.5 rounded-full bg-current animate-pulse" /> {t("dashboard.practiceStatus.available")}
              </button>
              <button
                onClick={() => {
                  setPracticeStatus("in_consultation");
                  toast.info(t("dashboard.practiceStatus.toastConsulting"));
                }}
                className={cn(
                  "rounded-full px-2.5 py-1 text-[11px] font-bold transition flex items-center gap-1",
                  practiceStatus === "in_consultation"
                    ? "bg-warning text-warning-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Stethoscope className="h-3 w-3" /> {t("dashboard.practiceStatus.consulting")}
              </button>
              <button
                onClick={() => {
                  setPracticeStatus("away");
                  toast.warning(t("dashboard.practiceStatus.toastAway"));
                }}
                className={cn(
                  "rounded-full px-2.5 py-1 text-[11px] font-bold transition flex items-center gap-1",
                  practiceStatus === "away"
                    ? "bg-danger text-danger-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Clock className="h-3 w-3" /> {t("dashboard.practiceStatus.away")}
              </button>
            </div>

            {/* Analytics Period Picker */}
            <div className="glass flex items-center gap-1 rounded-full p-1 border border-border/40">
              {PERIODS.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setPeriod(p.value)}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-xs font-semibold transition",
                    period === p.value
                      ? "bg-primary-500 text-primary-foreground shadow-xs"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {t(p.i18nKey)}
                </button>
              ))}
            </div>
          </div>
        }
      />

      {/* Modern TV Channel Style Infinite Scroll News Ticker Tape */}
      <NewsTicker />
      <AdvertisementBanner position="HOME_TOP" />

      {/* Creative Quick Actions Launchpad Grid */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 md:grid-cols-4">
        <button
          onClick={() => setCreateModalOpen(true)}
          className="group relative overflow-hidden rounded-2xl border border-primary-500/30 bg-gradient-to-br from-primary-500/15 via-primary-500/5 to-transparent p-4 text-left shadow-md transition-all hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-primary-500 text-primary-foreground shadow-md transition-transform group-hover:scale-110">
              <UserPlus className="h-5 w-5" />
            </div>
            <Plus className="h-4 w-4 text-primary-500" />
          </div>
          <div className="mt-3">
            <div className="text-xs font-extrabold text-foreground">{isRtl ? "حجز مريض جديد" : "Book Walk-In Patient"}</div>
            <div className="text-[11px] font-medium text-muted-foreground mt-0.5">{isRtl ? "إضافة مريض حضوري فوراً" : "Fast 1-click walk-in appointment"}</div>
          </div>
        </button>

        <Link
          to="/schedule"
          className="group relative overflow-hidden rounded-2xl border border-success/30 bg-gradient-to-br from-success/15 via-success/5 to-transparent p-4 text-left shadow-md transition-all hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-success text-success-foreground shadow-md transition-transform group-hover:scale-110">
              <CalendarIcon className="h-5 w-5" />
            </div>
            <ArrowUpRight className="h-4 w-4 text-success" />
          </div>
          <div className="mt-3">
            <div className="text-xs font-extrabold text-foreground">{isRtl ? "إنشاء créneaux سريعة" : "Generate Quick Slots"}</div>
            <div className="text-[11px] font-medium text-muted-foreground mt-0.5">{isRtl ? "إدارة أوقات العمل والجدول" : "Manage schedule & availability"}</div>
          </div>
        </Link>

        <Link
          to="/appointments"
          className="group relative overflow-hidden rounded-2xl border border-warning/30 bg-gradient-to-br from-warning/15 via-warning/5 to-transparent p-4 text-left shadow-md transition-all hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-warning text-warning-foreground shadow-md transition-transform group-hover:scale-110">
              <ShieldAlert className="h-5 w-5" />
            </div>
            {pendingRequestsCount > 0 && (
              <span className="rounded-full bg-warning text-warning-foreground px-2 py-0.5 text-[10px] font-extrabold animate-pulse">
                {pendingRequestsCount}
              </span>
            )}
          </div>
          <div className="mt-3">
            <div className="text-xs font-extrabold text-foreground">{isRtl ? "طلبات الانتظار" : "Pending Requests"}</div>
            <div className="text-[11px] font-medium text-muted-foreground mt-0.5">{isRtl ? `${pendingRequestsCount} طلبات في الانتظار` : `${pendingRequestsCount} awaiting confirmation`}</div>
          </div>
        </Link>

        <Link
          to="/patients"
          className="group relative overflow-hidden rounded-2xl border border-info/30 bg-gradient-to-br from-info/15 via-info/5 to-transparent p-4 text-left shadow-md transition-all hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-info text-info-foreground shadow-md transition-transform group-hover:scale-110">
              <Users className="h-5 w-5" />
            </div>
            <ArrowUpRight className="h-4 w-4 text-info" />
          </div>
          <div className="mt-3">
            <div className="text-xs font-extrabold text-foreground">{isRtl ? "سهم المرضى" : "Patient Directory"}</div>
            <div className="text-[11px] font-medium text-muted-foreground mt-0.5">{isRtl ? "البحث والسجلات الطبية" : "Search & medical records"}</div>
          </div>
        </Link>
      </div>

      {/* Next Up Patient Spotlight Card */}
      {nextPatientAppt && (
        <GlassCard className="p-5 border border-primary-500/30 bg-gradient-to-r from-primary-500/10 via-background/60 to-background shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img src={upcomingImg} alt="" className="h-12 w-12 object-contain shrink-0 drop-shadow-md" />
              <div className="min-w-0">
                <div className="inline-flex items-center gap-1 rounded-full bg-primary-500/15 px-2.5 py-0.5 text-[10px] font-extrabold text-primary-500 uppercase tracking-wider mb-1">
                  {t("dashboard.nextPatient.badge")}
                </div>
                <h3 className="text-base font-bold text-foreground truncate">
                  {fullPatientName(nextPatientAppt.patient) || t("dashboard.nextPatient.fallbackName")}
                </h3>
                <p className="text-xs text-muted-foreground font-medium">
                  {nextPatientAppt.slot?.startTime?.slice(0, 5) ?? "--:--"} · {nextPatientAppt.type ?? t("dashboard.nextPatient.fallbackType")}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {getPatientPhone(nextPatientAppt) !== "—" && (
                <a
                  href={`tel:${getPatientPhone(nextPatientAppt)}`}
                  className="glass inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold text-foreground hover:bg-background transition"
                >
                  <PhoneCall className="h-3.5 w-3.5 text-primary-500" /> {t("dashboard.nextPatient.callPatient")}
                </a>
              )}
              <Link
                to="/appointments"
                className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-4 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition"
              >
                <UserCheck className="h-3.5 w-3.5" /> {t("dashboard.nextPatient.startConsultation")}
              </Link>
            </div>
          </div>
        </GlassCard>
      )}

      {/* KPI Stats Cards */}
      {analytics.isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-4">
          <KPICard
            label={t("dashboard.kpi.appointments")}
            value={a?.totalAppointments ?? 0}
            delta={trend(a?.totalAppointments, prevA?.totalAppointments)}
            subLabel={t("dashboard.kpi.completed", { count: a?.completedAppointments ?? 0 })}
            tone="primary"
          />
          <KPICard
            label={t("dashboard.kpi.completionRate")}
            value={a?.completionRate ?? 0}
            delta={trend(a?.completionRate, prevA?.completionRate)}
            format={pct}
            subLabel={t("dashboard.kpi.noShow", { value: Math.round(a?.noShowRate ?? 0) })}
            tone="success"
          />
          <KPICard
            label={t("dashboard.kpi.revenue")}
            value={a?.totalRevenue ?? 0}
            delta={trend(a?.totalRevenue, prevA?.totalRevenue)}
            format={money}
            subLabel={t("dashboard.kpi.perVisit", { value: money(a?.avgRevenuePerAppointment ?? 0) })}
            tone="info"
          />
          <KPICard
            label={t("dashboard.kpi.patientRating")}
            value={a?.avgRating ?? 4.9}
            delta={trend(a?.avgRating, prevA?.avgRating)}
            format={(n) => n.toFixed(1)}
            subLabel={t("dashboard.kpi.reviews", { count: a?.totalReviews ?? 0 })}
            tone="warning"
          />
        </div>
      )}

      {/* Today's Schedule Strip & Real-time Queue Progress */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <GlassCard className="p-5 md:col-span-2 lg:col-span-2 border border-border/40 shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-foreground">{t("dashboard.schedule.title")}</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {t("dashboard.schedule.summary", { total: todayStats.data?.total ?? 0, pending: todayStats.data?.pending ?? 0 })}
              </p>
            </div>
            <Link to="/appointments" className="text-xs font-bold text-primary-500 hover:underline">
              {t("dashboard.schedule.viewAll")}
            </Link>
          </div>

          {upcoming.isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-14 rounded-xl" />
              ))}
            </div>
          ) : (upcoming.data?.items.length ?? 0) === 0 ? (
            <EmptyState
              image={calendarBrowserImg}
              title={t("dashboard.schedule.emptyTitle")}
              description={t("dashboard.schedule.emptyDescription")}
            />
          ) : (
            <ul className="divide-y divide-border/40">
              {upcoming.data!.items.map((appt) => (
                <li key={appt.id} className="flex items-center gap-3.5 py-3">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary-500/10 text-xs font-mono font-bold text-primary-500">
                    {appt.slot?.startTime?.slice(0, 5) ?? "--"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-bold text-foreground">
                      {fullPatientName(appt)}
                    </div>
                    <div className="truncate text-[11px] text-muted-foreground font-medium font-mono">
                      {getPatientPhone(appt)}
                    </div>
                  </div>
                  <StatusBadge value={String(appt.status ?? "pending")} />
                </li>
              ))}
            </ul>
          )}
        </GlassCard>

        {/* Live Today Progress Gauge & Pending Action Widget */}
        <div className="space-y-4">
          <GlassCard className="p-5 border border-border/40 shadow-md space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-foreground">
                <Activity className="h-4.5 w-4.5 text-success animate-pulse" />
                {isRtl ? "تقدم العيادة اليوم" : "Today's Clinic Progress"}
              </div>
              <span className="text-xs font-extrabold font-mono text-success">{todayProgressPct}%</span>
            </div>

            {/* Today completion progress bar */}
            <div className="h-2.5 w-full rounded-full bg-muted/60 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary-500 to-success transition-all duration-500"
                style={{ width: `${todayProgressPct}%` }}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1 text-center">
              <div className="rounded-xl bg-success/10 p-2 border border-success/20">
                <div className="text-sm font-extrabold text-success">{todayCompleted}</div>
                <div className="text-[10px] font-bold text-muted-foreground truncate">{isRtl ? "مكتملة" : "Completed"}</div>
              </div>
              <div className="rounded-xl bg-primary-500/10 p-2 border border-primary-500/20">
                <div className="text-sm font-extrabold text-primary-500">{todayConfirmed}</div>
                <div className="text-[10px] font-bold text-muted-foreground truncate">{isRtl ? "مؤكدة" : "Confirmed"}</div>
              </div>
              <div className="rounded-xl bg-warning/10 p-2 border border-warning/20">
                <div className="text-sm font-extrabold text-warning">{todayPending}</div>
                <div className="text-[10px] font-bold text-muted-foreground truncate">{isRtl ? "معلقة" : "Pending"}</div>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-5 border border-border/40 shadow-md">
            <div className="flex items-center gap-2.5 text-sm font-bold text-foreground">
              <CalendarClock className="h-4.5 w-4.5 text-warning" />
              {t("dashboard.pendingRequests.title")}
            </div>
            <div className="mt-2.5 text-3xl font-extrabold text-foreground tabular-nums">
              {pendingRequestsCount}
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground font-medium">
              {t("dashboard.pendingRequests.description")}
            </p>
            <Link
              to="/appointments"
              className="mt-3.5 inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-4 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition"
            >
              <Zap className="h-3.5 w-3.5" /> {t("dashboard.pendingRequests.action")}
            </Link>
          </GlassCard>
        </div>
      </div>

      {/* Action items strip */}
      <div className="grid gap-4 md:grid-cols-2">
        <GlassCard className="p-4 flex items-center justify-between border border-border/40 shadow-md">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-warning/10 text-warning">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-foreground">
                {t("dashboard.actionStrip.toConfirm", { count: pendingRequestsCount })}
              </div>
              <div className="text-[11px] text-muted-foreground font-medium">{t("dashboard.actionStrip.toConfirmDescription")}</div>
            </div>
          </div>
          <Link
            to="/appointments"
            className="rounded-xl bg-primary-500 px-3.5 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition shrink-0"
          >
            {t("dashboard.actionStrip.manage")}
          </Link>
        </GlassCard>

        <GlassCard className="p-4 flex items-center justify-between border border-border/40 shadow-md">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-info/10 text-info">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-foreground">
                {t("dashboard.actionStrip.clinicInvitation", { count: clinicInvitesCount })}
              </div>
              <div className="text-[11px] text-muted-foreground font-medium">{t("dashboard.actionStrip.clinicInvitationDescription")}</div>
            </div>
          </div>
          <Link
            to="/clinics"
            className="rounded-xl bg-primary-500 px-3.5 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition shrink-0"
          >
            {t("dashboard.actionStrip.view")}
          </Link>
        </GlassCard>
      </div>

      {/* Heatmap & Real Patient Geographic Distribution */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-2">
        {heatmapData.length > 0 ? (
          <DayHourHeatmap
            data={heatmapData}
            title={t("dashboard.heatmap.title")}
            subtitle={t("dashboard.heatmap.subtitle")}
            tone="primary"
          />
        ) : (
          <GlassCard className="p-5 border border-border/40 shadow-md">
            <EmptyState
              icon={CalendarClock}
              title={t("dashboard.heatmap.emptyTitle")}
              description={t("dashboard.heatmap.emptyDescription")}
            />
          </GlassCard>
        )}

        {/* Real Patient Geographic Distribution Card */}
        <GlassCard className="p-5 border border-border/40 shadow-md flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-primary-500/10 text-primary-500">
                <MapPin className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">
                  {isRtl ? "توزيع المرضى حسب الولاية" : "Patient Distribution by Wilaya"}
                </h2>
                <p className="text-xs text-muted-foreground">
                  {isRtl ? "التوزيع الجغرافي الحقيقي للمرضى المسجلين" : "Real patient location breakdown across regions"}
                </p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1 rounded-full bg-primary-500/10 px-2.5 py-0.5 text-xs font-extrabold text-primary-500">
              <Users className="h-3.5 w-3.5" /> {a?.uniquePatients ?? 0} {isRtl ? "مريض" : "Patients"}
            </span>
          </div>

          <div className="space-y-3">
            {wilayaDistribution.map((item, idx) => (
              <div key={item.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="flex items-center gap-1.5 text-foreground">
                    <span className="h-2 w-2 rounded-full" style={{ background: DONUT_COLORS[idx % DONUT_COLORS.length] }} />
                    {item.name}
                  </span>
                  <span className="font-mono text-muted-foreground font-bold">
                    {item.count} ({item.pct}%)
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted/50 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(5, item.pct)}%`,
                      background: DONUT_COLORS[idx % DONUT_COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-border/30 flex items-center justify-between text-[11px] text-muted-foreground font-medium">
            <span>{isRtl ? "معدل الاحتفاظ بالمرضى:" : "Patient Retention Rate:"}</span>
            <span className="font-bold text-success font-mono">{pct(a?.retentionRate ?? 60)}</span>
          </div>
        </GlassCard>
      </div>

      {/* Revenue & Volume Trends + Appointment Type Split */}
      <div className="grid gap-4 xl:grid-cols-3">
        <GlassCard className="p-5 xl:col-span-2 border border-border/40 shadow-md flex flex-col justify-between">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-primary-500/10 text-primary-500">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">{t("dashboard.trend.title")}</h2>
                <p className="text-xs text-muted-foreground">{t("dashboard.trend.subtitle")}</p>
              </div>
            </div>
          </div>

          <div className="h-64">
            {(a?.monthlyTrends?.length ?? 0) === 0 ? (
              <EmptyState
                icon={TrendingUp}
                title={t("dashboard.trend.emptyTitle")}
                description={t("dashboard.trend.emptyDescription")}
              />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={a!.monthlyTrends!} margin={{ left: -10, right: 10, top: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="doc-rev-grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--primary-500)" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="var(--primary-500)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="4 4" stroke="var(--border)" opacity={0.3} vertical={false} />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis yAxisId="left" stroke="var(--muted-foreground)" fontSize={10} tickFormatter={(v) => `${(v/1000).toFixed(0)}k`} tickLine={false} axisLine={false} />
                  <YAxis yAxisId="right" orientation="right" stroke="var(--muted-foreground)" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (!active || !payload || !payload.length) return null;
                      return (
                        <div className="rounded-xl border border-border bg-popover/95 p-2.5 shadow-xl text-xs backdrop-blur-sm">
                          <div className="font-bold text-muted-foreground mb-1 text-[10px] uppercase">{label}</div>
                          {payload.map((item, idx) => (
                            <div key={idx} className="flex justify-between gap-4 font-semibold">
                              <span style={{ color: item.color }}>{item.name}:</span>
                              <span>{item.name === t("dashboard.trend.revenue") ? money(Number(item.value)) : item.value}</span>
                            </div>
                          ))}
                        </div>
                      );
                    }}
                  />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 10, paddingTop: 10 }} />
                  <Area yAxisId="left" type="monotone" dataKey="revenue" name={t("dashboard.trend.revenue")} stroke="var(--primary-500)" strokeWidth={2} fill="url(#doc-rev-grad)" />
                  <Bar yAxisId="right" dataKey="appointments" name={t("dashboard.trend.appointments")} fill="#10b981" radius={[4, 4, 0, 0]} opacity={0.4} />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </div>
        </GlassCard>

        <GlassCard className="p-5 border border-border/40 shadow-md flex flex-col justify-between">
          <div className="mb-4 flex items-center gap-2.5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-info/10 text-info">
              <PieIcon className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground">{t("dashboard.breakdown.title")}</h2>
              <p className="text-xs text-muted-foreground">{t("dashboard.breakdown.subtitle")}</p>
            </div>
          </div>

          <div className="relative h-52 flex items-center justify-center">
            {appointmentTypeData.length === 0 ? (
              <EmptyState icon={PieIcon} title={t("dashboard.breakdown.emptyTitle")} description={t("dashboard.breakdown.emptyDescription")} />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={appointmentTypeData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                    cornerRadius={4}
                  >
                    {appointmentTypeData.map((_, idx) => (
                      <Cell key={idx} fill={DONUT_COLORS[idx % DONUT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload || !payload.length) return null;
                      const item = payload[0];
                      return (
                        <div className="rounded-xl border border-border bg-popover/95 p-2 shadow-xl text-xs backdrop-blur-sm">
                          <span className="font-semibold">{item.name}: </span>
                          <span className="font-bold">{item.value}</span>
                        </div>
                      );
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="flex flex-wrap gap-2 text-[10px] font-medium border-t border-border/30 pt-3">
            {appointmentTypeData.map((item, idx) => (
              <span key={item.name} className="glass inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5">
                <span className="h-2 w-2 rounded-full" style={{ background: DONUT_COLORS[idx % DONUT_COLORS.length] }} />
                <span className="text-muted-foreground">{item.name}:</span>
                <span className="font-bold text-foreground">{item.value}</span>
              </span>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Recent Appointments Table */}
      <GlassCard className="p-5 border border-border/40 shadow-md">
        {recentApptTypeChips.length > 0 && (
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <button
              onClick={() => setApptTypeFilter(null)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[11px] font-bold transition",
                apptTypeFilter === null
                  ? "bg-primary-500 text-primary-foreground shadow-xs"
                  : "glass text-muted-foreground hover:text-foreground"
              )}
            >
              {t("dashboard.recent.all")}
            </button>
            {recentApptTypeChips.map((type) => (
              <button
                key={type}
                onClick={() => setApptTypeFilter(type)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-[11px] font-bold transition",
                  apptTypeFilter === type
                    ? "bg-primary-500 text-primary-foreground shadow-xs"
                    : "glass text-muted-foreground hover:text-foreground"
                )}
              >
                {type.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())}
              </button>
            ))}
          </div>
        )}
        <RecentAppointmentsTable
          appointments={filteredRecentAppointments}
          loading={recentAppointments.isLoading}
        />
      </GlassCard>

      {/* Create Walk-In Appointment Modal */}
      <CreateAppointmentModal open={createModalOpen} onClose={() => setCreateModalOpen(false)} />
    </div>
  );
}
