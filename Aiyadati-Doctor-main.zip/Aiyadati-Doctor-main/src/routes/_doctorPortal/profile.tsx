import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { BadgeCheck, Calendar, FileText, Mail, MapPin, Phone, ShieldAlert, Star, Trash2, Upload, User } from "lucide-react";
import { EntityMap } from "@/components/map/EntityMap";
import { ShareProfileButton } from "@/components/profile/ShareProfileButton";
import { resolveMediaUrl } from "@/components/users/UserAvatar";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { EmptyState } from "@/components/data/EmptyState";
import { SelectMenu } from "@/components/data/SelectMenu";
import { ConfirmDialog } from "@/components/data/ConfirmDialog";
import { DocumentViewerModal } from "@/components/data/DocumentViewerModal";
import { LocationPicker } from "@/components/data/LocationPicker";
import { doctorSelfApi, type DoctorDocumentRow } from "@/api/doctorSelfApi";
import { doctorPlaceholderUrl } from "@/lib/assetFallbacks";
import { specialtyApi } from "@/api/specialtyApi";
import { useWilayas } from "@/hooks/useWilayas";
import { useBaladyas } from "@/hooks/useBaladyas";
import { useDoctorProfile } from "@/hooks/useDoctorProfile";
import { useEntityMutation } from "@/lib/mutations";
import { qk } from "@/lib/queryKeys";
import { translateEnum } from "@/lib/enumLabel";

export const Route = createFileRoute("/_doctorPortal/profile")({
  head: () => ({
    meta: [
      { title: "My Profile — Iyadati Doctor Portal" },
      {
        name: "description",
        content: "Keep your professional profile, specialties, biography and verification documents up to date.",
      },
      { property: "og:title", content: "My Profile — Iyadati Doctor Portal" },
      { property: "og:description", content: "Profile details, specialties and documents." },
    ],
  }),
  component: ProfilePage,
});

const DOC_TYPE_KEYS = ["degree", "license", "id_card", "cv", "certificate", "other"];
const PRACTICE_TYPE_KEYS = ["SOLO", "CLINIC", "BOTH", "GROUP", "HOSPITAL"];

function formatBytes(bytes?: number): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function ProfilePage() {
  const { t, i18n } = useTranslation();
  const { data: profile, isLoading } = useDoctorProfile();
  const { data: wilayas } = useWilayas();
  const qc = useQueryClient();
  const [photoErrored, setPhotoErrored] = useState(false);

  const docTypeOptions = useMemo(
    () => DOC_TYPE_KEYS.map((k) => ({ value: k, label: translateEnum(t, i18n, "docType", k) })),
    [t, i18n],
  );

  const practiceTypeOptions = useMemo(
    () => PRACTICE_TYPE_KEYS.map((k) => ({ value: k, label: translateEnum(t, i18n, "practiceType", k) })),
    [t, i18n],
  );

  const [selectedWilayaId, setSelectedWilayaId] = useState<string>("");
  const { data: baladyat } = useBaladyas(selectedWilayaId);

  const specialties = useQuery({
    queryKey: ["specialties-lookup"],
    queryFn: () => specialtyApi.list({ limit: 100 }),
    staleTime: 5 * 60 * 1000,
  });

  const documents = useQuery({
    queryKey: qk.doctorSelf.documents(),
    queryFn: doctorSelfApi.documents.list,
  });

  const [form, setForm] = useState({
    bioFr: "",
    bioAr: "",
    baladyaId: "",
    practiceType: "SOLO",
    yearsOfExp: 0,
    specialtyId: "",
    latitude: undefined as number | undefined,
    longitude: undefined as number | undefined,
  });
  const [photo, setPhoto] = useState<File | null>(null);

  useEffect(() => {
    if (!profile) return;
    const initialWilaya =
      profile.wilayaId ||
      (profile.baladya as { wilayaId?: string } | undefined)?.wilayaId ||
      "";
    setSelectedWilayaId(initialWilaya);

    setForm({
      bioFr: profile.bioFr ?? "",
      bioAr: profile.bioAr ?? "",
      baladyaId: profile.baladyaId ?? "",
      practiceType: String(profile.practiceType ?? "SOLO"),
      yearsOfExp: profile.yearsOfExp ?? 0,
      specialtyId: profile.specialties?.[0]?.specialty?.id ?? profile.specialties?.[0]?.specialtyId ?? "",
      latitude: profile.latitude,
      longitude: profile.longitude,
    });
  }, [profile]);

  const completeness = useMemo(() => {
    let score = 0;
    const total = 7;
    if (profile?.photoUrl || photo) score++;
    if (form.bioFr || form.bioAr) score++;
    if (form.specialtyId) score++;
    if (form.yearsOfExp > 0) score++;
    if (form.baladyaId) score++;
    if (form.latitude && form.longitude) score++;
    if ((documents.data?.length ?? 0) > 0) score++;
    return { score, total, percentage: Math.round((score / total) * 100) };
  }, [profile, photo, form, documents.data]);

  const save = useEntityMutation<typeof form>({
    mutationFn: (values) => {
      qc.setQueryData(qk.doctorSelf.profile(), (old: typeof profile) =>
        old ? { ...old, ...values } : old,
      );
      const fd = new FormData();
      if (values.bioFr) fd.append("bioFr", values.bioFr);
      if (values.bioAr) fd.append("bioAr", values.bioAr);
      if (values.yearsOfExp) fd.append("yearsOfExp", String(values.yearsOfExp));
      if (values.practiceType) fd.append("practiceType", values.practiceType);
      if (values.baladyaId) fd.append("baladyaId", values.baladyaId);
      if (values.latitude != null) fd.append("latitude", String(values.latitude));
      if (values.longitude != null) fd.append("longitude", String(values.longitude));

      if (values.specialtyId) fd.append("specialtyIds[]", values.specialtyId);
      if (photo) fd.append("logo", photo);

      return doctorSelfApi.complete(fd);
    },
    invalidate: [qk.doctorSelf.profile()],
    successMessage: "Profile updated",
    onSuccess: () => setPhoto(null),
  });

  /* --------------------------- documents --------------------------- */
  const fileRef = useRef<HTMLInputElement>(null);
  const [docType, setDocType] = useState<string | undefined>("license");
  const [docToDelete, setDocToDelete] = useState<DoctorDocumentRow | null>(null);
  const [viewing, setViewing] = useState<DoctorDocumentRow | null>(null);

  const upload = useEntityMutation<File>({
    mutationFn: (file) => {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("docType", docType ?? "other");
      return doctorSelfApi.documents.upload(fd);
    },
    invalidate: [qk.doctorSelf.documents()],
    successMessage: "Document uploaded",
  });

  const removeDoc = useEntityMutation<string>({
    mutationFn: (id) => doctorSelfApi.documents.remove(id),
    invalidate: [qk.doctorSelf.documents()],
    successMessage: "Document removed",
  });

  return (
    <div className="space-y-5 pb-24 md:pb-8">
      <PageHeader
        title="My profile"
        subtitle="Your public profile as patients see it"
        actions={
          <>
            <ShareProfileButton
              doctorId={profile?.id}
              name={[profile?.firstNameFr, profile?.lastNameFr].filter(Boolean).join(" ")}
            />
            <button
              disabled={save.isPending}
              onClick={() => save.mutate(form)}
              className="rounded-xl bg-primary-500 px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
            >
              {save.isPending ? "Saving…" : "Save changes"}
            </button>
          </>
        }
      />

      {/* 1. Identity Header Card */}
      {isLoading ? (
        <Skeleton className="h-28 rounded-2xl" />
      ) : (
        <GlassCard className="p-5 space-y-4">
          <div className="flex flex-wrap items-center gap-4">
            <img
              src={
                photo
                  ? URL.createObjectURL(photo)
                  : !photoErrored
                    ? (resolveMediaUrl(profile?.photoUrl) ?? doctorPlaceholderUrl)
                    : doctorPlaceholderUrl
              }
              alt={`Portrait of Dr. ${profile?.firstNameFr ?? ""} ${profile?.lastNameFr ?? ""}`}
              onError={() => setPhotoErrored(true)}
              className="h-20 w-20 rounded-2xl object-cover bg-muted"
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h2 className="truncate text-lg font-semibold">
                  Dr. {[profile?.firstNameFr, profile?.lastNameFr].filter(Boolean).join(" ")}
                </h2>
                {profile?.isVerified ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-success/15 px-2 py-0.5 text-[11px] text-success">
                    <BadgeCheck className="h-3 w-3" /> Verified
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 rounded-full bg-warning/15 px-2 py-0.5 text-[11px] text-warning">
                    <ShieldAlert className="h-3 w-3" /> Pending verification
                  </span>
                )}
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                <span>{profile?.email}</span>
                {profile?.phone && <span>· {profile.phone}</span>}
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground/80 italic">
                To change your registered name or phone number, please contact support.
              </p>
              {profile?.rejectionReason && (
                <p className="mt-1 text-xs text-danger font-semibold">Verification feedback: {profile.rejectionReason}</p>
              )}
            </div>
            <label className="glass cursor-pointer rounded-xl px-3 py-2 text-xs font-medium shrink-0">
              Change photo
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>

          <div className="border-t border-border/40 pt-3 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Profile Completeness: <b>{completeness.score}/{completeness.total}</b> ({completeness.percentage}%)</span>
            <div className="w-48 h-2 rounded-full bg-muted/40 overflow-hidden">
              <div className="h-full bg-primary-500 rounded-full transition-all" style={{ width: `${completeness.percentage}%` }} />
            </div>
          </div>

          <div className="grid gap-3 border-t border-border/40 pt-3 text-xs sm:grid-cols-2 xl:grid-cols-4">
            <div>
              <div className="text-muted-foreground">Name (AR)</div>
              <div dir="rtl" className="mt-0.5 font-medium">
                {[profile?.firstNameAr, profile?.lastNameAr].filter(Boolean).join(" ") || "—"}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground"><Phone className="h-3 w-3" /> Phone</div>
              <div className="mt-0.5 font-medium">{profile?.phone || "—"}</div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground"><Mail className="h-3 w-3" /> Email</div>
              <div className="mt-0.5 truncate font-medium">{profile?.email || "—"}</div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground"><Star className="h-3 w-3" /> Rating</div>
              <div className="mt-0.5 font-medium">{profile?.rating != null ? profile.rating.toFixed(1) : "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Wilaya / Baladya</div>
              <div className="mt-0.5 font-medium">
                {[profile?.wilaya?.nameFr, profile?.baladya?.nameFr].filter(Boolean).join(" · ") || "—"}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" /> Member since</div>
              <div className="mt-0.5 font-medium">{profile?.createdAt ? profile.createdAt.slice(0, 10) : "—"}</div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" /> Last updated</div>
              <div className="mt-0.5 font-medium">{profile?.updatedAt ? profile.updatedAt.slice(0, 10) : "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Registration status</div>
              <div className="mt-0.5 font-medium">
                {profile?.isCompleted ? "Completed" : profile?.isRegistered ? "Registered" : "Incomplete"}
                {profile?.isSuspended ? " · Suspended" : ""}
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      {/* 2. Professional Details Card */}
      <GlassCard className="p-5 space-y-4">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-primary-500" />
          <h2 className="text-sm font-semibold">Professional Details</h2>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          <label className="text-xs text-muted-foreground">
            Years of experience
            <input
              type="number"
              min={0}
              value={form.yearsOfExp}
              onChange={(e) => setForm({ ...form, yearsOfExp: Number(e.target.value) })}
              className="glass mt-1 w-full rounded-xl px-3 py-2 text-sm text-foreground outline-none"
            />
          </label>

          <div className="text-xs text-muted-foreground">
            Specialty
            <SelectMenu
              value={form.specialtyId || undefined}
              onChange={(v) => setForm({ ...form, specialtyId: v ?? "" })}
              options={(specialties.data?.items ?? []).map((s) => ({
                value: s.id,
                label: s.nameFr ?? s.nameAr ?? s.id,
              }))}
              placeholder="Select specialty"
              searchable
              className="mt-1"
            />
          </div>

          <div className="text-xs text-muted-foreground">
            Practice type
            <SelectMenu
              value={form.practiceType}
              onChange={(v) => setForm({ ...form, practiceType: v ?? "SOLO" })}
              options={practiceTypeOptions}
              className="mt-1"
            />
          </div>

          <label className="text-xs text-muted-foreground sm:col-span-2 xl:col-span-3">
            Biography (FR)
            <textarea
              rows={3}
              maxLength={1000}
              value={form.bioFr}
              onChange={(e) => setForm({ ...form, bioFr: e.target.value })}
              className="glass mt-1 w-full rounded-xl px-3 py-2 text-sm text-foreground outline-none"
            />
          </label>

          <label className="text-xs text-muted-foreground sm:col-span-2 xl:col-span-3">
            Biography (AR)
            <textarea
              rows={3}
              maxLength={1000}
              dir="rtl"
              value={form.bioAr}
              onChange={(e) => setForm({ ...form, bioAr: e.target.value })}
              className="glass mt-1 w-full rounded-xl px-3 py-2 text-sm text-foreground outline-none"
            />
          </label>
        </div>
      </GlassCard>

      {/* 3. Practice Location Card */}
      <GlassCard className="p-5 space-y-4">
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-primary-500" />
          <div>
            <h2 className="text-sm font-semibold">Practice Location</h2>
            <p className="text-xs text-muted-foreground">Commune location and map coordinate pin for patient search</p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="text-xs text-muted-foreground">
            Wilaya (Province)
            <SelectMenu
              value={selectedWilayaId || undefined}
              onChange={(v) => {
                setSelectedWilayaId(v ?? "");
                setForm({ ...form, baladyaId: "" });
              }}
              options={(wilayas ?? []).map((w) => ({ value: w.id, label: w.nameFr ?? w.nameAr ?? w.id }))}
              placeholder="Select wilaya"
              searchable
              className="mt-1"
            />
          </div>

          <div className="text-xs text-muted-foreground">
            Baladya (Commune)
            <SelectMenu
              value={form.baladyaId || undefined}
              onChange={(v) => setForm({ ...form, baladyaId: v ?? "" })}
              options={(baladyat ?? []).map((b) => ({ value: b.id, label: b.nameFr ?? b.nameAr ?? b.id }))}
              placeholder={selectedWilayaId ? "Select baladya" : "Select wilaya first"}
              searchable
              className="mt-1"
            />
          </div>
        </div>

        <div className="space-y-1.5 pt-2">
          <label className="text-xs text-muted-foreground font-medium">Pinpoint Practice Location on Map</label>
          <LocationPicker
            latitude={form.latitude}
            longitude={form.longitude}
            onChange={(lat, lng) => setForm({ ...form, latitude: lat, longitude: lng })}
            height={280}
          />
          {form.latitude && form.longitude && (
            <>
              <p className="text-[11px] text-muted-foreground tabular-nums">
                Selected coordinates: {form.latitude.toFixed(6)}, {form.longitude.toFixed(6)}
              </p>
              <div className="pt-2">
                <label className="text-xs text-muted-foreground font-medium">Practice location preview</label>
                <div className="mt-1.5">
                  <EntityMap
                    height={220}
                    showUserLocation
                    points={[
                      {
                        id: profile?.id ?? "me",
                        latitude: form.latitude,
                        longitude: form.longitude,
                        title: `Dr. ${[profile?.firstNameFr, profile?.lastNameFr].filter(Boolean).join(" ")}`,
                        subtitle: profile?.baladya?.nameFr ?? profile?.wilaya?.nameFr,
                        type: "doctor",
                      },
                    ]}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </GlassCard>

      {/* 4. Verification Documents Card */}
      <GlassCard className="p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold">Verification documents</h2>
            <p className="text-xs text-muted-foreground">
              Upload your medical licence, diploma, and ID for account verification.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <SelectMenu
              value={docType}
              onChange={setDocType}
              options={docTypeOptions}
              placeholder="Type"
              className="w-44"
            />
            <button
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-3 py-2 text-xs font-medium text-primary-foreground"
            >
              <Upload className="h-3.5 w-3.5" /> Upload
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*,application/pdf"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload.mutate(f);
                e.target.value = "";
              }}
            />
          </div>
        </div>

        {documents.isLoading ? (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-2xl" />
            ))}
          </div>
        ) : (documents.data?.length ?? 0) === 0 ? (
          <EmptyState icon={FileText} title="No documents uploaded" description="Upload your licence to complete verification." />
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {documents.data!.map((d) => (
              <div key={d.id} className="glass flex items-center gap-3 rounded-2xl p-3">
                <FileText className="h-5 w-5 shrink-0 text-primary-500" />
                <button
                  onClick={() => setViewing(d)}
                  className="min-w-0 flex-1 text-left"
                >
                  <div className="truncate text-sm font-medium">
                    {d.fileName ?? translateEnum(t, i18n, "docType", d.docType)}
                  </div>
                  <div className="truncate text-xs text-muted-foreground">
                    {translateEnum(t, i18n, "docType", d.docType)} · {d.uploadedAt?.slice(0, 10) ?? ""}
                    {d.fileSize ? ` · ${formatBytes(d.fileSize)}` : ""}
                  </div>
                </button>
                <button
                  onClick={() => setDocToDelete(d)}
                  className="grid h-8 w-8 place-items-center rounded-lg text-danger hover:bg-danger/10"
                  aria-label="delete document"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </GlassCard>

      <DocumentViewerModal
        open={!!viewing}
        onClose={() => setViewing(null)}
        url={viewing?.accessUrl}
        mimeType={viewing?.fileType}
        title={viewing?.fileName ?? translateEnum(t, i18n, "docType", viewing?.docType)}
      />

      <ConfirmDialog
        open={!!docToDelete}
        onClose={() => setDocToDelete(null)}
        onConfirm={() => {
          if (docToDelete) removeDoc.mutate(docToDelete.id);
          setDocToDelete(null);
        }}
        title="Delete this document?"
        description="You will need to upload it again for verification."
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
