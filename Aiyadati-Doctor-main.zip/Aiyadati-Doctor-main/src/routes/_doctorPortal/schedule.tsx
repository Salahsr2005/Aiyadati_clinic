import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueries, useQueryClient } from "@tanstack/react-query";
import {
  CalendarRange,
  Clock,
  Trash2,
  Save,
  Sliders,
  Users,
  Plus,
  AlertTriangle,
  RefreshCw,
  Calendar as CalendarIcon,
  Layers,
  CalendarPlus2,
  Loader2,
  CalendarDays,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/data/PageHeader";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { EmptyState } from "@/components/data/EmptyState";
import { StatusBadge } from "@/components/data/StatusBadge";
import { ConfirmDialog } from "@/components/data/ConfirmDialog";
import { ScheduleHeatmap, type WeeklySchedule } from "@/components/forms/ScheduleHeatmap";
import { TimePillPicker } from "@/components/data/TimePillPicker";
import { ModernDatePickerModal } from "@/components/ui/ModernDatePickerModal";
import { Slider } from "@/components/ui/slider";
import { ViewToggle, type ViewMode } from "@/components/data/ViewToggle";
import { ActivityHeatmap, type HeatmapDatum } from "@/components/data/ActivityHeatmap";
import { EntityMap } from "@/components/map/EntityMap";
import { SlotAggregateSummary } from "@/components/schedule/SlotAggregateSummary";
import { DateRangeInspector } from "@/components/schedule/DateRangeInspector";
import { SlotGridInspector } from "@/components/schedule/SlotGridInspector";
import { OptimalSlotsTab } from "@/components/schedule/OptimalSlotsTab";
import { ScheduleVisualizer } from "@/components/schedule/ScheduleVisualizer";
import { RegenerateConfirmDialog } from "@/components/schedule/RegenerateConfirmDialog";
import { BreakConflictModal } from "@/components/schedule/BreakConflictModal";
import { useSlotAvailabilityMapPoints } from "@/hooks/useSlotAvailabilityMapPoints";
import {
  doctorSelfApi,
  doctorAppointmentsApi,
  type AvailabilityRow,
  type AvailabilitySlotInput,
  type BreakRow,
  type BreakConflict,
  type SlotRow,
} from "@/api/doctorSelfApi";
import { useEntityMutation } from "@/lib/mutations";
import { qk } from "@/lib/queryKeys";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  findBookedDatesFromSlots,
  splitDateRangeExcludingBooked,
  checkBreakOverlapsBookedSlots,
} from "@/lib/slotPlanning";

export const Route = createFileRoute("/_doctorPortal/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule & Slots — Iyadati Doctor Portal" },
      {
        name: "description",
        content:
          "Set your weekly availability, block time off, configure slot duration and generate bookable slots.",
      },
      { property: "og:title", content: "Schedule & Slots — Iyadati Doctor Portal" },
      { property: "og:description", content: "Weekly availability, breaks and slot generation." },
    ],
  }),
  component: SchedulePage,
});

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function toISO(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const HEATMAP_DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
const API_DAY_MAP: Record<string, string> = {
  mon: "MONDAY",
  tue: "TUESDAY",
  wed: "WEDNESDAY",
  thu: "THURSDAY",
  fri: "FRIDAY",
  sat: "SATURDAY",
  sun: "SUNDAY",
};
const REVERSE_DAY_MAP: Record<string, (typeof HEATMAP_DAYS)[number]> = {
  MONDAY: "mon",
  TUESDAY: "tue",
  WEDNESDAY: "wed",
  THURSDAY: "thu",
  FRIDAY: "fri",
  SATURDAY: "sat",
  SUNDAY: "sun",
};

function toWeeklySchedule(rows: AvailabilityRow[]): WeeklySchedule {
  const out: WeeklySchedule = {};
  HEATMAP_DAYS.forEach((d) => (out[d] = { closed: true, open: "08:00", close: "16:00" }));
  rows.forEach((r) => {
    const key = REVERSE_DAY_MAP[String(r.dayOfWeek).toUpperCase()];
    if (key) {
      out[key] = {
        closed: false,
        open: r.startTime ? r.startTime.slice(0, 5) : "08:00",
        close: r.endTime ? r.endTime.slice(0, 5) : "16:00",
      };
    }
  });
  return out;
}

function fromWeeklySchedule(ws: WeeklySchedule): AvailabilitySlotInput[] {
  const result: AvailabilitySlotInput[] = [];
  HEATMAP_DAYS.forEach((d) => {
    const val = ws[d];
    if (val && !val.closed) {
      const apiDay = API_DAY_MAP[d];
      if (apiDay) {
        result.push({
          dayOfWeek: apiDay,
          startTime: val.open,
          endTime: val.close,
        });
      }
    }
  });
  return result;
}

type TabMode = "template" | "breaks" | "generate" | "slots";

function SchedulePage() {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<TabMode>("template");

  const availability = useQuery({
    queryKey: qk.doctorSelf.availability(),
    queryFn: doctorSelfApi.availability.get,
  });
  const breaks = useQuery({ queryKey: qk.doctorSelf.breaks(), queryFn: doctorSelfApi.breaks.list });
  const config = useQuery({ queryKey: qk.doctorSelf.config(), queryFn: doctorAppointmentsApi.config.get });

  const [heatmapVal, setHeatmapVal] = useState<WeeklySchedule>(() => toWeeklySchedule([]));
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (availability.data && !dirty) {
      setHeatmapVal(toWeeklySchedule(availability.data));
    }
  }, [availability.data, dirty]);

  /* ------------------------- automatic slot regeneration ------------------------- */
  const [isRegenerating, setIsRegenerating] = useState(false);
  const regeneratingRef = useState(() => ({ current: false }))[0];
  const [pendingRegen, setPendingRegen] = useState<{ reason: string } | null>(null);

  const performRegeneration = (reasonLabel: string, fromDate?: string) => {
    const regenStart = fromDate ?? range.startDate;
    const regenEnd = range.endDate;
    const today = todayISO();

    if (!(regenEnd >= regenStart) || regenEnd < today) {
      toast.info(`${reasonLabel} saved. Select a future date range below and click "Generate Slots" to apply.`);
      return;
    }

    if (regeneratingRef.current) {
      toast.info("A slot regeneration is already in progress — it will pick up this change too.");
      return;
    }

    const effectiveStart = regenStart > today ? regenStart : today;
    const bookedDates = findBookedDatesFromSlots(slotsByDate);
    const safeSubRanges = splitDateRangeExcludingBooked(effectiveStart, regenEnd, bookedDates);

    if (safeSubRanges.length === 0) {
      toast.warning("All dates in the selected range have booked appointments. No unbooked slots to regenerate.");
      return;
    }

    regeneratingRef.current = true;
    setIsRegenerating(true);

    const regenPromise = (async () => {
      for (const sub of safeSubRanges) {
        await doctorAppointmentsApi.slots.generate({ startDate: sub.startDate, endDate: sub.endDate });
      }
      void queryClient.invalidateQueries({ queryKey: qk.doctorSelf.slotsAll() });
      void queryClient.invalidateQueries({ queryKey: qk.doctorSelf.slots(slotDate) });
    })();

    toast.promise(
      regenPromise.finally(() => {
        regeneratingRef.current = false;
        setIsRegenerating(false);
      }),
      {
        loading: `${reasonLabel} saved — regenerating unbooked slots…`,
        success: bookedDates.size > 0
          ? `Regenerated slots for unbooked dates (${bookedDates.size} date(s) with appointments preserved)`
          : "Bookable slots regenerated for the upcoming window",
        error: (err: Error) =>
          err?.message || "Slots regeneration failed — use 'Generate Slots' below to retry",
      },
    );
  };

  const triggerRegeneration = (reasonLabel: string) => {
    if (futureAvailableTotal > 0 || futureBookedTotal > 0) {
      setPendingRegen({ reason: reasonLabel });
      return;
    }
    performRegeneration(reasonLabel);
  };

  const saveAvailability = useEntityMutation<AvailabilitySlotInput[]>({
    mutationFn: (slots) => doctorSelfApi.availability.set(slots),
    invalidate: [qk.doctorSelf.availability(), qk.doctorSelf.slotsAll()],
    loadingMessage: "Saving availability…",
    successMessage: "Weekly availability saved",
    onSuccess: () => {
      setDirty(false);
      triggerRegeneration("Weekly availability");
    },
  });

  const saveConfig = useEntityMutation<{ slotDuration: number; bufferTime: number; maxPerSlot: number }>({
    mutationFn: (payload) => doctorAppointmentsApi.config.set(payload),
    invalidate: [qk.doctorSelf.config(), qk.doctorSelf.slotsAll()],
    loadingMessage: "Saving slot settings…",
    successMessage: "Slot settings updated",
    onSuccess: () => triggerRegeneration("Slot settings"),
  });

  /* ------------------------------ time off & break conflicts ------------------------------ */
  const [breakForm, setBreakForm] = useState({
    startDate: todayISO(),
    endDate: todayISO(),
    reason: "",
    isAllDay: true,
    startTime: "09:00",
    endTime: "12:00",
  });
  const [breakToDelete, setBreakToDelete] = useState<BreakRow | null>(null);
  const [conflictPreview, setConflictPreview] = useState<{ conflicts: BreakConflict[]; showModal: boolean } | null>(null);
  const [isCheckingBreak, setIsCheckingBreak] = useState(false);

  /* Check break conflict preview */
  const handleCheckBreakConflicts = async () => {
    setIsCheckingBreak(true);
    try {
      const res = await doctorSelfApi.breaks.preview(breakForm);
      if (res.conflicts.length > 0) {
        setConflictPreview({ conflicts: res.conflicts, showModal: true });
      } else {
        // No conflicts -> submit directly
        createBreak.mutate({ ...breakForm, conflictStrategy: "BLOCK" });
      }
    } catch {
      createBreak.mutate({ ...breakForm, conflictStrategy: "BLOCK" });
    } finally {
      setIsCheckingBreak(false);
    }
  };

  const createBreak = useEntityMutation({
    mutationFn: (payload: typeof breakForm & { conflictStrategy?: "BLOCK" | "CANCEL_AND_REFUND" }) =>
      doctorSelfApi.breaks.create(payload),
    invalidate: [qk.doctorSelf.breaks(), qk.doctorSelf.slotsAll()],
    loadingMessage: "Scheduling time off…",
    successMessage: "Time off scheduled",
    onSuccess: () => {
      setConflictPreview(null);
      setBreakForm({
        startDate: todayISO(),
        endDate: todayISO(),
        reason: "",
        isAllDay: true,
        startTime: "09:00",
        endTime: "12:00",
      });
      triggerRegeneration("Time off");
    },
  });

  const deleteBreak = useEntityMutation<string>({
    mutationFn: (id) => doctorSelfApi.breaks.remove(id),
    invalidate: [qk.doctorSelf.breaks(), qk.doctorSelf.slotsAll()],
    successMessage: "Time off removed",
    onSuccess: () => triggerRegeneration("Time off update"),
  });

  /* ------------------------------- slots ------------------------------ */
  const [slotDate, setSlotDate] = useState(todayISO());
  const [range, setRange] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const weekOut = new Date();
    weekOut.setDate(weekOut.getDate() + 7);
    return {
      startDate: toISO(tomorrow),
      endDate: toISO(weekOut),
    };
  });
  const [slotFilter, setSlotFilter] = useState<"all" | "available" | "full" | "cancelled">("all");

  const slots = useQuery({
    queryKey: qk.doctorSelf.slots(slotDate),
    queryFn: () => doctorAppointmentsApi.slots.listByDate(slotDate),
  });

  const generate = useEntityMutation<{ startDate: string; endDate: string }>({
    mutationFn: (p) => doctorAppointmentsApi.slots.generate(p),
    invalidate: [qk.doctorSelf.slotsAll(), qk.doctorSelf.slots(slotDate)],
    loadingMessage: "Generating bookable slots…",
    successMessage: "Bookable slots generated",
  });
  const cancelDate = useEntityMutation<string>({
    mutationFn: (date) => doctorAppointmentsApi.slots.cancelDate({ date }),
    invalidate: [qk.doctorSelf.slotsAll(), qk.doctorSelf.slots(slotDate)],
    loadingMessage: "Cancelling slots…",
    successMessage: "Slots for date cancelled",
  });
  const removeSlot = useEntityMutation<string>({
    mutationFn: (id) => doctorAppointmentsApi.slots.remove(id),
    invalidate: [qk.doctorSelf.slotsAll(), qk.doctorSelf.slots(slotDate)],
    successMessage: "Slot removed",
  });

  const [cfg, setCfg] = useState({ slotDuration: 30, bufferTime: 5, maxPerSlot: 1 });
  useEffect(() => {
    if (config.data) {
      setCfg({
        slotDuration: config.data.slotDuration ?? 30,
        bufferTime: config.data.bufferTime ?? 5,
        maxPerSlot: config.data.maxPerSlot ?? 1,
      });
    }
  }, [config.data]);

  /* --------------------- "My slots" view toggle --------------------- */
  const [slotsView, setSlotsView] = useState<ViewMode>("grid");
  const SLOT_HEATMAP_WEEKS = 6;

  const slotHeatmapDates = useMemo(() => {
    const start = todayISO();
    const days = SLOT_HEATMAP_WEEKS * 7;
    return Array.from({ length: days }, (_, i) => {
      const d = new Date(start);
      d.setDate(d.getDate() + i);
      return toISO(d);
    });
  }, []);

  const slotHeatmapQueries = useQueries({
    queries: slotHeatmapDates.map((date) => ({
      queryKey: qk.doctorSelf.slots(date),
      queryFn: () => doctorAppointmentsApi.slots.listByDate(date),
      staleTime: 60_000,
    })),
  });

  const slotHeatmapLoading = slotHeatmapQueries.some((q) => q.isLoading);

  const { availableHeatmapData, fullyBookedTotal, availableTotal, cancelledTotal } = useMemo(() => {
    const data: HeatmapDatum<SlotRow>[] = [];
    let booked = 0;
    let avail = 0;
    let cancelled = 0;
    slotHeatmapDates.forEach((date, i) => {
      const rows = (slotHeatmapQueries[i]?.data ?? []) as SlotRow[];
      const availableSlots = rows.filter((r) => String(r.status).toLowerCase() === "available");
      const fullSlots = rows.filter((r) => String(r.status).toLowerCase() === "full");
      booked += fullSlots.length;
      avail += availableSlots.length;
      cancelled += rows.filter((r) => String(r.status).toLowerCase() === "cancelled").length;
      if (rows.length > 0) {
        data.push({ date, count: availableSlots.length, appointments: availableSlots });
      }
    });
    return {
      availableHeatmapData: data,
      fullyBookedTotal: booked,
      availableTotal: avail,
      cancelledTotal: cancelled,
    };
  }, [slotHeatmapDates, slotHeatmapQueries]);

  const futureAvailableTotal = availableTotal;
  const futureBookedTotal = fullyBookedTotal;

  /* date-range slot inspector */
  const [inspectRange, setInspectRange] = useState(() => {
    const today = todayISO();
    const end = new Date();
    end.setDate(end.getDate() + 6);
    return { startDate: today, endDate: toISO(end) };
  });

  const inspectDates = useMemo(() => {
    const out: string[] = [];
    const start = new Date(inspectRange.startDate + "T00:00:00");
    const end = new Date(inspectRange.endDate + "T00:00:00");
    for (let i = 0; i < 92; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      if (d > end) break;
      out.push(toISO(d));
    }
    return out;
  }, [inspectRange]);

  const inspectQueries = useQueries({
    queries: inspectDates.map((date) => ({
      queryKey: qk.doctorSelf.slots(date),
      queryFn: () => doctorAppointmentsApi.slots.listByDate(date),
      staleTime: 30_000,
    })),
  });

  const inspectLoading = inspectQueries.some((q) => q.isLoading);
  const slotsByDate = useMemo(() => {
    const map: Record<string, SlotRow[]> = {};
    inspectDates.forEach((date, i) => {
      map[date] = (inspectQueries[i]?.data ?? []) as SlotRow[];
    });
    return map;
  }, [inspectDates, inspectQueries]);

  const { mapPoints: slotMapPoints, isLoading: slotMapLoading } = useSlotAvailabilityMapPoints();

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <PageHeader
        title="Schedule & Bookable Slots"
        subtitle="Manage consultation duration, weekly availability, time off, and daily slots"
        actions={
          <button
            onClick={() => {
              void availability.refetch();
              void breaks.refetch();
              void config.refetch();
              void slots.refetch();
            }}
            className="glass flex items-center gap-1.5 rounded-2xl px-3.5 py-2 text-xs font-bold text-foreground hover:bg-background transition border border-border/40 shadow-xs"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Refresh Schedule
          </button>
        }
      />

      {/* 4 PRODUCTIVE NAVIGATION TABS */}
      <GlassCard className="p-2 border border-border/40 shadow-sm">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1">
          {(
            [
              { id: "template", label: "Weekly Template", icon: CalendarRange },
              { id: "breaks", label: `Time Off (${breaks.data?.length ?? 0})`, icon: AlertTriangle },
              { id: "generate", label: "Generate Slots", icon: CalendarPlus2 },
              { id: "slots", label: `My Slots (${availableTotal})`, icon: CalendarDays },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-xl py-2.5 px-3 text-xs font-bold transition",
                  activeTab === tab.id
                    ? "bg-primary-500 text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:bg-muted/40 hover:text-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </GlassCard>

      {/* TAB 1: WEEKLY TEMPLATE & CONFIG */}
      {activeTab === "template" && (
        <div className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            {/* Slot Settings Config */}
            <GlassCard className="p-6 space-y-5 border border-border/40 shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2.5 pb-3 border-b border-border/30">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-primary-500/10 text-primary-500">
                    <Sliders className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-foreground">Slot Settings</h2>
                    <p className="text-xs text-muted-foreground">Duration, buffer, and capacity</p>
                  </div>
                </div>

                <div className="space-y-5 mt-4">
                  <div>
                    <div className="flex justify-between text-xs font-bold mb-2">
                      <span className="text-foreground flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-primary-500" /> Duration
                      </span>
                      <span className="text-primary-500 font-mono">{cfg.slotDuration} minutes</span>
                    </div>
                    <Slider
                      value={[cfg.slotDuration]}
                      min={5}
                      max={120}
                      step={5}
                      onValueChange={([val]) => setCfg((c) => ({ ...c, slotDuration: val }))}
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-2">
                      <span className="text-foreground flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-warning" /> Buffer Time
                      </span>
                      <span className="text-warning font-mono">{cfg.bufferTime} minutes</span>
                    </div>
                    <Slider
                      value={[cfg.bufferTime]}
                      min={0}
                      max={60}
                      step={5}
                      onValueChange={([val]) => setCfg((c) => ({ ...c, bufferTime: val }))}
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-2">
                      <span className="text-foreground flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5 text-success" /> Max Per Slot
                      </span>
                      <span className="text-success font-mono">{cfg.maxPerSlot} patient{cfg.maxPerSlot === 1 ? "" : "s"}</span>
                    </div>
                    <Slider
                      value={[cfg.maxPerSlot]}
                      min={1}
                      max={10}
                      step={1}
                      onValueChange={([val]) => setCfg((c) => ({ ...c, maxPerSlot: val }))}
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={() => saveConfig.mutate(cfg)}
                disabled={saveConfig.isPending}
                className="w-full mt-4 inline-flex items-center justify-center gap-2 rounded-2xl bg-primary-500 px-4 py-2.5 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition disabled:opacity-50"
              >
                <Save className="h-4 w-4" /> Save Settings
              </button>
            </GlassCard>

            {/* Weekly Availability Heatmap Editor */}
            <GlassCard className="p-6 md:col-span-2 space-y-4 border border-border/40 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-border/30">
                <div>
                  <h2 className="text-base font-bold text-foreground flex items-center gap-2">
                    <CalendarRange className="h-5 w-5 text-primary-500" />
                    Weekly Availability Pattern
                  </h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Paint your standard working hours for each day of the week.
                  </p>
                </div>
                <button
                  onClick={() => saveAvailability.mutate(fromWeeklySchedule(heatmapVal))}
                  disabled={saveAvailability.isPending}
                  className="inline-flex items-center gap-1.5 rounded-2xl bg-primary-500 px-5 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition disabled:opacity-50"
                >
                  <Save className="h-4 w-4" /> Save Pattern
                </button>
              </div>

              <ScheduleHeatmap
                value={heatmapVal}
                onChange={(val) => {
                  setHeatmapVal(val);
                  setDirty(true);
                }}
              />
            </GlassCard>
          </div>
        </div>
      )}

      {/* TAB 2: TIME OFF & BREAKS WITH LIVE CONFLICT PREVIEW */}
      {activeTab === "breaks" && (
        <div className="space-y-6">
          <GlassCard className="p-6 space-y-5 border border-border/40 shadow-xl">
            <div className="flex items-center gap-2.5 pb-3 border-b border-border/30">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-danger/10 text-danger">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">Schedule Time Off & Vacations</h2>
                <p className="text-xs text-muted-foreground">Block out dates when you are unavailable for consultations</p>
              </div>
            </div>

            {/* Time Off Form */}
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block mb-1">
                  Start Date
                </label>
                <ModernDatePickerModal
                  mode="single"
                  value={breakForm.startDate}
                  onSelect={(d) => setBreakForm((f) => ({ ...f, startDate: d }))}
                  className="w-full"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block mb-1">
                  End Date
                </label>
                <ModernDatePickerModal
                  mode="single"
                  value={breakForm.endDate}
                  onSelect={(d) => setBreakForm((f) => ({ ...f, endDate: d }))}
                  className="w-full"
                />
              </div>
              <div className="sm:col-span-2">
                <input
                  type="text"
                  placeholder="Reason (e.g. Medical Conference, Vacation, Personal Leave)"
                  value={breakForm.reason}
                  onChange={(e) => setBreakForm((f) => ({ ...f, reason: e.target.value }))}
                  className="w-full rounded-2xl border border-border/40 bg-muted/20 px-3.5 py-2 text-xs font-semibold placeholder:text-muted-foreground/60 outline-none focus:border-primary-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-border/30">
              <button
                onClick={handleCheckBreakConflicts}
                disabled={isCheckingBreak || createBreak.isPending}
                className="inline-flex items-center gap-1.5 rounded-2xl bg-danger/15 text-danger border border-danger/30 px-5 py-2 text-xs font-bold hover:bg-danger/25 transition disabled:opacity-50"
              >
                {isCheckingBreak ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Add Time Off Block
              </button>
              <span className="text-xs font-bold text-muted-foreground">
                {breaks.data?.length ?? 0} active break block{(breaks.data?.length ?? 0) === 1 ? "" : "s"}
              </span>
            </div>
          </GlassCard>

          {/* Active Breaks Roster */}
          <GlassCard className="p-6 space-y-4 border border-border/40 shadow-xl">
            <h3 className="text-sm font-bold text-foreground">Scheduled Time Off Blocks</h3>
            {(breaks.data?.length ?? 0) === 0 ? (
              <EmptyState
                icon={AlertTriangle}
                title="No time off scheduled"
                description="Your calendar has no active vacation or break blocks."
              />
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {breaks.data!.map((b) => (
                  <div key={b.id} className="glass flex items-center justify-between p-3.5 rounded-2xl border border-border/40">
                    <div>
                      <div className="text-xs font-bold text-foreground">{b.startDate} → {b.endDate}</div>
                      <div className="text-[11px] text-muted-foreground italic mt-0.5">{b.reason || "Time off"}</div>
                    </div>
                    <button
                      onClick={() => setBreakToDelete(b)}
                      className="grid h-8 w-8 place-items-center rounded-xl text-danger hover:bg-danger/10 transition"
                      title="Remove break"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
        </div>
      )}

      {/* TAB 3: GENERATE SLOTS */}
      {activeTab === "generate" && (
        <div className="space-y-6">
          <GlassCard className="p-6 space-y-5 border border-border/40 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-border/30">
              <div>
                <h2 className="text-base font-bold text-foreground flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary-500" />
                  Batch Slot Generator
                </h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Select date range to generate slots based on your weekly pattern. Slots also
                  regenerate automatically whenever availability, settings, or time off change.
                </p>
                {isRegenerating && (
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-primary-500/10 px-3 py-1 text-[11px] font-bold text-primary-500">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Slots regenerating…
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <ModernDatePickerModal
                  mode="range"
                  startDate={range.startDate}
                  endDate={range.endDate}
                  onSelectRange={(start, end) => setRange({ startDate: start, endDate: end })}
                  label="Select Slot Generation Range"
                />
                <button
                  onClick={() => triggerRegeneration("Manual Generator")}
                  disabled={generate.isPending || isRegenerating}
                  className="inline-flex items-center gap-1.5 rounded-2xl bg-primary-500 px-5 py-2 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition disabled:opacity-50"
                >
                  <CalendarPlus2 className="h-4 w-4" />
                  {generate.isPending ? "Generating…" : "Generate Slots"}
                </button>
              </div>
            </div>

            {/* Visualizer */}
            <div className="rounded-3xl border border-border/40 bg-muted/5 p-4 space-y-3">
              <div>
                <h3 className="text-sm font-bold text-foreground">{t("schedule.visualizer.title")}</h3>
                <p className="text-xs text-muted-foreground">{t("schedule.visualizer.subtitle")}</p>
              </div>
              <ScheduleVisualizer
                weeklyAvailability={availability.data ?? []}
                breaksData={breaks.data ?? []}
                slotDuration={cfg.slotDuration}
              />
            </div>
          </GlassCard>
        </div>
      )}

      {/* TAB 4: MY SLOTS (OPTIMAL VIEW) */}
      {activeTab === "slots" && (
        <OptimalSlotsTab
          onGoToGenerate={() => setActiveTab("generate")}
          onRemoveSlot={(id) => removeSlot.mutate(id)}
          onCancelDate={(date) => cancelDate.mutate(date)}
        />
      )}

      {/* Break Conflict Modal */}
      {conflictPreview && (
        <BreakConflictModal
          open={conflictPreview.showModal}
          onClose={() => setConflictPreview(null)}
          conflicts={conflictPreview.conflicts}
          startDate={breakForm.startDate}
          endDate={breakForm.endDate}
          onConfirm={(strategy) => {
            createBreak.mutate({ ...breakForm, conflictStrategy: strategy });
          }}
          isSubmitting={createBreak.isPending}
        />
      )}

      {/* Regenerate Confirm Dialog */}
      <RegenerateConfirmDialog
        open={!!pendingRegen}
        onClose={() => setPendingRegen(null)}
        onConfirm={(fromDate) => {
          const reason = pendingRegen?.reason ?? "Schedule";
          setPendingRegen(null);
          performRegeneration(reason, fromDate);
        }}
        reasonLabel={pendingRegen?.reason ?? ""}
        rangeStart={range.startDate}
        rangeEnd={range.endDate}
        futureAvailableCount={futureAvailableTotal}
        futureBookedCount={futureBookedTotal}
        isPending={isRegenerating}
      />

      {/* Remove Break Confirm Dialog */}
      <ConfirmDialog
        open={!!breakToDelete}
        onClose={() => setBreakToDelete(null)}
        onConfirm={() => {
          if (breakToDelete) deleteBreak.mutate(breakToDelete.id);
          setBreakToDelete(null);
        }}
        title="Remove this time off?"
        description="Patients will be able to book during this period again."
        danger
        confirmLabel="Remove"
      />
    </div>
  );
}
