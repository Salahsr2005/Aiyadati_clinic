import { useMemo } from "react";
import { SelectMenu } from "@/components/data/SelectMenu";

interface TimePillPickerProps {
  value?: string;
  onChange: (value: string) => void;
  label?: string;
  className?: string;
  placeholder?: string;
}

export function TimePillPicker({
  value,
  onChange,
  label,
  className,
  placeholder = "Select time",
}: TimePillPickerProps) {
  const options = useMemo(() => {
    const list: { value: string; label: string }[] = [];
    for (let h = 0; h < 24; h++) {
      for (let m = 0; m < 60; m += 15) {
        const hh = String(h).padStart(2, "0");
        const mm = String(m).padStart(2, "0");
        const timeStr = `${hh}:${mm}`;
        list.push({ value: timeStr, label: timeStr });
      }
    }
    return list;
  }, []);

  return (
    <div className={className}>
      {label && <label className="text-xs text-muted-foreground block mb-1">{label}</label>}
      <SelectMenu
        value={value}
        onChange={(v) => v && onChange(v)}
        options={options}
        placeholder={placeholder}
        searchable
      />
    </div>
  );
}
