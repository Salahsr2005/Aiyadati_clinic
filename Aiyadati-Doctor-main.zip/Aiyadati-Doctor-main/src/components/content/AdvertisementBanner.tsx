import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { ExternalLink, Sparkles } from "lucide-react";
import { advertisementsApi, pickContent, type AdvertisementRow } from "@/api/contentApi";
import { qk } from "@/lib/queryKeys";

interface AdvertisementBannerProps {
  position?: "HOME_TOP" | "HOME_MIDDLE" | "HOME_BOTTOM" | "CUSTOM";
  className?: string;
}

export function AdvertisementBanner({ position = "HOME_TOP", className }: AdvertisementBannerProps) {
  const { i18n } = useTranslation();
  const locale = i18n.language || "fr";

  const { data: ads } = useQuery({
    queryKey: qk.content.ads(position),
    queryFn: () => advertisementsApi.active({ position }),
    staleTime: 5 * 60 * 1000,
  });

  const activeAds = ads || [];
  const currentAd: AdvertisementRow | undefined = activeAds[0];

  useEffect(() => {
    if (currentAd?.id) {
      void advertisementsApi.trackView(currentAd.id);
    }
  }, [currentAd?.id]);

  if (!currentAd) return null;

  const title = pickContent(locale, {
    ar: currentAd.titleAr,
    fr: currentAd.titleFr,
    en: currentAd.titleEn,
    fallback: currentAd.title,
  });

  const description = pickContent(locale, {
    ar: currentAd.descriptionAr,
    fr: currentAd.descriptionFr,
    en: currentAd.descriptionEn,
    fallback: currentAd.description || "",
  });

  const handleClick = () => {
    if (currentAd.id) {
      void advertisementsApi.trackClick(currentAd.id);
    }
    if (currentAd.link) {
      window.open(currentAd.link, "_blank", "noopener,noreferrer");
    }
  };

  /* Fallback compact layout if image is missing */
  if (!currentAd.imageUrl) {
    return (
      <div
        onClick={handleClick}
        className={`group relative cursor-pointer overflow-hidden rounded-2xl border border-border/40 bg-card p-4 shadow-lg transition hover:shadow-xl ${className || ""}`}
      >
        <div className="flex flex-wrap items-center gap-4">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[10px] font-extrabold text-amber-500 uppercase tracking-wider">
                <Sparkles className="h-3 w-3" /> Sponsored
              </span>
            </div>
            <h4 className="text-sm font-bold text-foreground truncate group-hover:text-primary-500 transition-colors">
              {title}
            </h4>
            {description && (
              <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                {description}
              </p>
            )}
          </div>
          {currentAd.link && (
            <div className="shrink-0">
              <span className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-3 py-2 text-xs font-bold text-primary-foreground shadow-sm group-hover:bg-primary-600 transition">
                Visit <ExternalLink className="h-3.5 w-3.5" />
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* Hero visual layout with full-bleed image and gradient scrim */
  return (
    <div
      onClick={handleClick}
      className={`group relative cursor-pointer overflow-hidden rounded-3xl border border-border/40 shadow-xl transition-all duration-300 hover:shadow-2xl aspect-[16/9] sm:aspect-[21/9] min-h-[190px] sm:min-h-[230px] ${className || ""}`}
    >
      {/* Background Image */}
      <img
        src={currentAd.imageUrl}
        crossOrigin="anonymous"
        alt={title}
        className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
      />

      {/* Scrim Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

      {/* Content Overlay */}
      <div className="relative z-10 flex h-full flex-col justify-end p-5 sm:p-6 text-white space-y-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/90 backdrop-blur-md px-2.5 py-0.5 text-[10px] font-extrabold text-black uppercase tracking-wider shadow-sm">
            <Sparkles className="h-3 w-3" /> Sponsored
          </span>
        </div>

        <div className="flex items-end justify-between gap-4">
          <div className="max-w-xl space-y-1">
            <h4 className="text-base sm:text-lg font-extrabold tracking-tight text-white drop-shadow-sm line-clamp-1 group-hover:text-amber-300 transition-colors">
              {title}
            </h4>
            {description && (
              <p className="text-xs sm:text-sm text-zinc-200 line-clamp-2 leading-relaxed opacity-90 drop-shadow-xs font-medium">
                {description}
              </p>
            )}
          </div>

          {currentAd.link && (
            <div className="shrink-0">
              <span className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500 px-4 py-2 text-xs font-bold text-primary-foreground shadow-lg group-hover:bg-primary-400 transition hover:scale-105">
                Visit <ExternalLink className="h-3.5 w-3.5" />
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
