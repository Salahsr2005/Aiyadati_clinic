import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Radio, ExternalLink, Sparkles, Activity, ShieldAlert, Zap, Calendar, Stethoscope, HeartPulse } from "lucide-react";
import { newsApi, pickContent } from "@/api/contentApi";
import { doctorAppointmentsApi } from "@/api/doctorSelfApi";
import { qk } from "@/lib/queryKeys";

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function NewsTicker() {
  const { i18n } = useTranslation();
  const locale = i18n.language || "fr";
  const isRtl = locale.startsWith("ar");

  const { data: newsItems } = useQuery({
    queryKey: qk.content.news(),
    queryFn: () => newsApi.active(),
    staleTime: 5 * 60 * 1000,
  });

  const todayStats = useQuery({
    queryKey: qk.doctorSelf.stats(todayISO()),
    queryFn: () => doctorAppointmentsApi.stats(todayISO()),
    staleTime: 60 * 1000,
  });

  const pending = useQuery({
    queryKey: qk.doctorSelf.pending(),
    queryFn: doctorAppointmentsApi.pending,
    staleTime: 60 * 1000,
  });

  const activeNews = newsItems || [];
  const stats = todayStats.data;
  const pendingCount = pending.data?.length ?? 0;

  // Build ticker items array (combining active news & live clinic metrics)
  const tickerItems: { id: string; category: string; text: string; link?: string; icon: any }[] = [];

  // 1. Live clinic metrics & real stats
  if (isRtl) {
    tickerItems.push({
      id: "stat-today",
      category: "مباشر",
      text: `مواعيد اليوم: ${stats?.total ?? 0} (مكتملة: ${stats?.completed ?? 0} | مؤكدة: ${stats?.confirmed ?? 0})`,
      icon: Calendar,
    });
    if (pendingCount > 0) {
      tickerItems.push({
        id: "stat-pending",
        category: "تنبيه هام",
        text: `لديك ${pendingCount} مواعيد جديدة بانتظار التأكيد السريع!`,
        icon: ShieldAlert,
      });
    }
    tickerItems.push({
      id: "tip-quick",
      category: "تلميح العيادة",
      text: "يمكنك إنشاء مواعيد فورية سريعة بنقرة واحدة من جدول المواعيد.",
      icon: Zap,
    });
    tickerItems.push({
      id: "news-health",
      category: "تحديث طبي",
      text: "تحديث بروتوكولات الوصفات الطبية الإلكترونية وتأكيد الهوية الوطنية للمريض متوفر الآن.",
      icon: HeartPulse,
    });
  } else if (locale.startsWith("en")) {
    tickerItems.push({
      id: "stat-today",
      category: "LIVE METRICS",
      text: `Today's Appointments: ${stats?.total ?? 0} (${stats?.completed ?? 0} completed, ${stats?.confirmed ?? 0} confirmed)`,
      icon: Calendar,
    });
    if (pendingCount > 0) {
      tickerItems.push({
        id: "stat-pending",
        category: "ACTION REQ",
        text: `You have ${pendingCount} pending appointment requests awaiting confirmation!`,
        icon: ShieldAlert,
      });
    }
    tickerItems.push({
      id: "tip-quick",
      category: "CLINIC TIP",
      text: "Create quick 1-click slots directly from the Schedule visualizer.",
      icon: Zap,
    });
    tickerItems.push({
      id: "news-health",
      category: "MEDICAL UPDATE",
      text: "Digital prescription verification & electronic health record sync is now active.",
      icon: HeartPulse,
    });
  } else {
    tickerItems.push({
      id: "stat-today",
      category: "EN DIRECT",
      text: `Rendez-vous du jour: ${stats?.total ?? 0} (${stats?.completed ?? 0} terminés, ${stats?.confirmed ?? 0} confirmés)`,
      icon: Calendar,
    });
    if (pendingCount > 0) {
      tickerItems.push({
        id: "stat-pending",
        category: "URGENT",
        text: `Vous avez ${pendingCount} demande(s) de rendez-vous en attente de confirmation!`,
        icon: ShieldAlert,
      });
    }
    tickerItems.push({
      id: "tip-quick",
      category: "ASTUCE CLINIQUE",
      text: "Générez des créneaux rapides en 1 clic directement dans le menu Planning.",
      icon: Zap,
    });
    tickerItems.push({
      id: "news-health",
      category: "SANTÉ INFO",
      text: "Mise à jour des ordonnances numériques & vérification d'assurance CNAS disponible.",
      icon: HeartPulse,
    });
  }

  // 2. Active news items from backend API
  activeNews.forEach((news) => {
    const text = pickContent(locale, {
      ar: news.contentAr,
      fr: news.contentFr,
      en: news.contentEn,
      fallback: news.content,
    });
    const category = pickContent(locale, {
      ar: news.titleAr,
      fr: news.titleFr,
      en: news.titleEn,
      fallback: news.title || "NEWS",
    });
    if (text) {
      tickerItems.push({
        id: news.id,
        category: category || (isRtl ? "خبر عاجل" : "UPDATE"),
        text,
        link: news.link,
        icon: Sparkles,
      });
    }
  });

  if (tickerItems.length === 0) return null;

  // Quadruple items array so marquee scrolls continuously and infinitely without gaps
  const quadrupledItems = [...tickerItems, ...tickerItems, ...tickerItems, ...tickerItems];

  const liveBadgeLabel = isRtl ? "الأخبار المباشرة" : locale.startsWith("en") ? "LIVE TICKER" : "FIL D'INFO";

  return (
    <div className="relative overflow-hidden rounded-2xl border border-primary-500/30 bg-gradient-to-r from-slate-950 via-primary-950 to-slate-900 text-white shadow-xl">
      <div className="flex items-center">
        {/* TV Badge (Static Header Tag) */}
        <div className="relative z-10 flex shrink-0 items-center gap-2 bg-gradient-to-r from-red-600 via-rose-600 to-primary-600 px-3.5 py-2.5 shadow-md">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-white" />
          </span>
          <Radio className="h-3.5 w-3.5 animate-pulse text-white" />
          <span className="text-[11px] font-black uppercase tracking-wider text-white">
            {liveBadgeLabel}
          </span>
        </div>

        {/* Continuous Infinite Ticker Tape Ribbon */}
        <div className="relative min-w-0 flex-1 overflow-hidden py-2.5">
          {/* Left & Right Gradient Edge Fades */}
          <div className="pointer-events-none absolute left-0 top-0 bottom-0 z-10 w-10 bg-gradient-to-r from-slate-950 to-transparent" />
          <div className="pointer-events-none absolute right-0 top-0 bottom-0 z-10 w-10 bg-gradient-to-l from-slate-900 to-transparent" />

          <div
            className={`pause-on-hover flex w-max items-center gap-8 ${
              isRtl ? "animate-ticker-rtl" : "animate-ticker-ltr"
            }`}
          >
            {quadrupledItems.map((item, idx) => {
              const Icon = item.icon || Activity;
              return (
                <div key={`${item.id}-${idx}`} className="flex shrink-0 items-center gap-2.5 text-xs">
                  <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider text-primary-200 border border-white/10">
                    <Icon className="h-3 w-3 text-primary-300" />
                    {item.category}
                  </span>
                  <span className="font-semibold text-slate-100">{item.text}</span>
                  {item.link && (
                    <a
                      href={item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-0.5 font-bold text-primary-300 hover:text-white hover:underline text-[11px] ms-1"
                    >
                      {isRtl ? "المزيد" : "Voir"} <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                  <span className="ms-4 text-white/25 font-bold">•</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
