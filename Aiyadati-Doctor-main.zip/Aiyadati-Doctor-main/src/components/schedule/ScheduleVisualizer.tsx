import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useQueries } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, LayoutGrid } from "lucide-react";
import { cn } from "@/lib/utils";
import { qk } from "@/lib/queryKeys";
import { doctorAppointmentsApi, type AvailabilityRow, type BreakRow, type SlotRow } from "@/api/doctorSelfApi";

function toISO(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseTime(t?: string | null): number | null {
  if (!t) return null;
  const [h, m] = t.split(":").map(Number);
  if (Number.isNaN(h)) return null;
  return h + (m || 0) / 60;
}
const API_DAY_ORDER = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"];

export function ScheduleVisualizer({
  weeklyAvailability,
  breaksData,
  slotDuration = 30,
  className,
}: {
  weeklyAvailability: AvailabilityRow[];
  breaksData: BreakRow[];
  slotDuration?: number;
  className?: string;
}) {
  const { t } = useTranslation();
  const [weekOffset, setWeekOffset] = useState(0);

  const weekDates = useMemo(() => {
    const today = new Date();
    const dow = (today.getDay() + 6) % 7; // 0 = Monday
    const monday = new Date(today);
    monday.setDate(today.getDate() - dow + weekOffset * 7);
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return d;
    });
  }, [weekOffset]);

  const weekIso = weekDates.map(toISO);

  const slotQueries = useQueries({
    queries: weekIso.map((date) => ({
      queryKey: qk.doctorSelf.slots(date),
      queryFn: () => doctorAppointmentsApi.slots.listByDate(date),
      staleTime: 30_000,
    })),
  });

  const [hover, setHover] = useState<{ x: number; y: number; text: string } | null>(null);

  const ticks = [0, 6, 12, 18, 24];

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <LayoutGrid className="h-4 w-4 text-primary-500" />
          <span className="text-xs font-bold text-muted-foreground">
            {weekIso[0]} → {weekIso[6]}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setWeekOffset((w) => w - 1)}
            className="grid h-7 w-7 place-items-center rounded-lg hover:bg-muted transition"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => setWeekOffset(0)}
            className="rounded-lg px-2 py-1 text-[11px] font-bold text-primary-500 hover:bg-primary-500/10 transition"
          >
            {t("schedule.visualizer.thisWeek")}
          </button>
          <button
            onClick={() => setWeekOffset((w) => w + 1)}
            className="grid h-7 w-7 place-items-center rounded-lg hover:bg-muted transition"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="overflow-x-auto custom-scrollbar pb-1">
        <div className="min-w-[720px] space-y-1.5">
          <div className="flex pl-16 text-[10px] font-semibold text-muted-foreground/70">
            {ticks.map((h) => (
              <div key={h} style={{ position: "relative", width: `${100 / 4}%` }}>
                {h}:00
              </div>
            ))}
          </div>

          {weekDates.map((d, i) => {
            const iso = weekIso[i];
            const apiDay = API_DAY_ORDER[i];
            const template = weeklyAvailability.filter((a) => String(a.dayOfWeek).toUpperCase() === apiDay);
            const rows: SlotRow[] = Array.isArray(slotQueries[i]?.data) ? (slotQueries[i]!.data as SlotRow[]) : [];
            const dayBreaks = breaksData.filter((b) => iso >= b.startDate && iso <= b.endDate);
            const isFullDayOff = dayBreaks.some((b) => b.isAllDay);

            return (
              <div key={iso} className="flex items-center gap-2">
                <div className="w-16 shrink-0 text-[10px] font-bold uppercase tracking-wide text-foreground">
                  {d.toLocaleDateString(undefined, { weekday: "short" })}
                  <div className="text-[9px] font-normal text-muted-foreground/70">
                    {d.getDate()}/{d.getMonth() + 1}
                  </div>
                </div>
                <div
                  className={cn(
                    "relative flex-1 overflow-hidden rounded-lg bg-muted/30 transition-all",
                    slotDuration <= 15 ? "h-12" : slotDuration <= 30 ? "h-10" : "h-8"
                  )}
                >
                  <div className="pointer-events-none absolute inset-0 flex">
                    {Array.from({ length: 24 }).map((_, h) => (
                      <div key={h} className="flex-1 border-e border-border/20 last:border-e-0" />
                    ))}
                  </div>

                  {/* weekly template band */}
                  {template.map((t2, ti) => {
                    const from = parseTime(t2.startTime);
                    const to = parseTime(t2.endTime);
                    if (from === null || to === null) return null;
                    return (
                      <div
                        key={`t-${ti}`}
                        className="absolute top-0 h-full bg-primary-500/10 border-x border-primary-500/20"
                        style={{ left: `${(from / 24) * 100}%`, width: `${((to - from) / 24) * 100}%` }}
                      />
                    );
                  })}

                  {/* generated slots */}
                  {rows.map((s) => {
                    const from = parseTime(s.startTime);
                    const to = parseTime(s.endTime);
                    if (from === null || to === null) return null;
                    const status = String(s.status).toLowerCase();
                    const color =
                      status === "available" ? "bg-success" : status === "full" ? "bg-danger" : "bg-muted-foreground/40";
                    return (
                      <div
                        key={s.id}
                        className={cn("absolute top-1 bottom-1 rounded-[4px] cursor-pointer", color)}
                        style={{ left: `${(from / 24) * 100}%`, width: `${Math.max(0.6, ((to - from) / 24) * 100)}%` }}
                        onMouseMove={(e) =>
                          setHover({
                            x: e.clientX,
                            y: e.clientY,
                            text: `${s.startTime?.slice(0, 5)}–${s.endTime?.slice(0, 5)} · ${t(`schedule.legend.${status === "available" ? "available" : status === "full" ? "booked" : "blocked"}`)}`,
                          })
                        }
                        onMouseLeave={() => setHover(null)}
                      />
                    );
                  })}

                  {/* time-off overlay */}
                  {isFullDayOff && (
                    <div
                      className="absolute inset-0 bg-warning/25 [background-image:repeating-linear-gradient(45deg,transparent,transparent_4px,rgba(0,0,0,0.06)_4px,rgba(0,0,0,0.06)_8px)]"
                      onMouseMove={(e) =>
                        setHover({ x: e.clientX, y: e.clientY, text: t("schedule.legend.timeOff") })
                      }
                      onMouseLeave={() => setHover(null)}
                    />
                  )}

                  {template.length === 0 && !isFullDayOff && (
                    <div className="absolute inset-0 grid place-items-center text-[9px] uppercase tracking-wider text-muted-foreground/60">
                      {t("schedule.visualizer.noTemplate")}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-border/30 text-[11px] font-semibold text-muted-foreground">
        <LegendItem colorClass="bg-primary-500/20 border border-primary-500/30" label={t("schedule.legend.template")} />
        <LegendItem colorClass="bg-success" label={t("schedule.legend.available")} />
        <LegendItem colorClass="bg-danger" label={t("schedule.legend.booked")} />
        <LegendItem colorClass="bg-muted-foreground/40" label={t("schedule.legend.blocked")} />
        <LegendItem colorClass="bg-warning/50" label={t("schedule.legend.timeOff")} />
      </div>

      {hover && (
        <div
          className="pointer-events-none fixed z-50 rounded-lg border border-border/60 bg-popover/95 px-2.5 py-1.5 text-[11px] font-semibold shadow-xl"
          style={{ left: hover.x + 12, top: hover.y + 12 }}
        >
          {hover.text}
        </div>
      )}
    </div>
  );
}

function LegendItem({ colorClass, label }: { colorClass: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn("h-2.5 w-2.5 rounded-full", colorClass)} />
      {label}
    </span>
  );
}
