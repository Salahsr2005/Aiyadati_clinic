import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { CalendarRange, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { GlassCard } from "@/components/glass/GlassCard";
import { StatusBadge } from "@/components/data/StatusBadge";
import { EmptyState } from "@/components/data/EmptyState";
import { Skeleton } from "@/components/glass/Skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import type { SlotRow } from "@/api/doctorSelfApi";

function toISO(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export interface DateRangeInspectorProps {
  startDate: string;
  endDate: string;
  onRangeChange: (start: string, end: string) => void;
  slotsByDate: Record<string, SlotRow[]>;
  isLoading?: boolean;
  filter: "all" | "available" | "full" | "cancelled";
  onFilterChange: (f: "all" | "available" | "full" | "cancelled") => void;
  onCancelDate: (date: string) => void;
  onRemoveSlot: (id: string) => void;
  cancellingDate?: string | null;
}

export function DateRangeInspector({
  startDate,
  endDate,
  onRangeChange,
  slotsByDate,
  isLoading,
  filter,
  onFilterChange,
  onCancelDate,
  onRemoveSlot,
  cancellingDate,
}: DateRangeInspectorProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);

  const applyPreset = (preset: "today" | "week" | "next7" | "month") => {
    const today = new Date();
    if (preset === "today") {
      onRangeChange(toISO(today), toISO(today));
    } else if (preset === "week") {
      const dow = (today.getDay() + 6) % 7; // 0 = Monday
      const monday = new Date(today);
      monday.setDate(today.getDate() - dow);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      onRangeChange(toISO(monday), toISO(sunday));
    } else if (preset === "next7") {
      const end = new Date(today);
      end.setDate(today.getDate() + 6);
      onRangeChange(toISO(today), toISO(end));
    } else if (preset === "month") {
      const first = new Date(today.getFullYear(), today.getMonth(), 1);
      const last = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      onRangeChange(toISO(first), toISO(last));
    }
    setOpen(false);
  };

  const sortedDates = useMemo(
    () => Object.keys(slotsByDate).filter((d) => (slotsByDate[d]?.length ?? 0) > 0).sort(),
    [slotsByDate],
  );

  const aggregate = useMemo(() => {
    let available = 0, full = 0, cancelled = 0;
    for (const rows of Object.values(slotsByDate)) {
      for (const r of rows) {
        const s = String(r.status).toLowerCase();
        if (s === "available") available++;
        else if (s === "full") full++;
        else if (s === "cancelled") cancelled++;
      }
    }
    return { available, full, cancelled, total: available + full + cancelled };
  }, [slotsByDate]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-muted-foreground">{t("schedule.inspector.label")}</span>
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <button className="glass inline-flex items-center gap-2 rounded-xl border border-border/40 px-3 py-2 text-xs font-bold hover:border-primary-500/40 transition">
                <CalendarRange className="h-3.5 w-3.5 text-primary-500" />
                {startDate} – {endDate}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 border-none bg-transparent shadow-none">
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1.5 text-[11px] font-bold">
                  {(
                    [
                      { id: "today", label: t("schedule.inspector.presetToday") },
                      { id: "week", label: t("schedule.inspector.presetThisWeek") },
                      { id: "next7", label: t("schedule.inspector.presetNext7") },
                      { id: "month", label: t("schedule.inspector.presetThisMonth") },
                    ] as const
                  ).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => applyPreset(p.id)}
                      className="rounded-full bg-primary-500/10 px-3 py-1 text-primary-500 hover:bg-primary-500 hover:text-primary-foreground transition"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <Calendar
                  mode="range"
                  startDate={startDate}
                  endDate={endDate}
                  onSelectRange={(s, e) => onRangeChange(s, e)}
                />
              </div>
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex items-center gap-1 text-xs font-semibold">
          {(
            [
              { id: "all", label: t("schedule.filters.all") },
              { id: "available", label: t("schedule.filters.available") },
              { id: "full", label: t("schedule.filters.full") },
              { id: "cancelled", label: t("schedule.filters.cancelled") },
            ] as const
          ).map((f) => (
            <button
              key={f.id}
              onClick={() => onFilterChange(f.id)}
              className={cn(
                "rounded-full px-3 py-1 transition font-bold",
                filter === f.id ? "bg-primary-500 text-primary-foreground shadow-xs" : "text-muted-foreground hover:bg-muted",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Aggregate summary for the selected range */}
      <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-border/40 bg-muted/10 px-4 py-2.5 text-[11px] font-bold text-muted-foreground">
        <span>{t("schedule.inspector.rangeTotal", { count: aggregate.total })}</span>
        <span className="inline-flex items-center gap-1.5 text-success"><span className="h-2 w-2 rounded-full bg-success" /> {t("schedule.inspector.rangeAvailable", { count: aggregate.available })}</span>
        <span className="inline-flex items-center gap-1.5 text-danger"><span className="h-2 w-2 rounded-full bg-danger" /> {t("schedule.inspector.rangeBooked", { count: aggregate.full })}</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-muted-foreground/40" /> {t("schedule.inspector.rangeCancelled", { count: aggregate.cancelled })}</span>
      </div>

      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-2xl" />
          ))}
        </div>
      ) : sortedDates.length === 0 ? (
        <EmptyState
          icon={CalendarRange}
          title={t("schedule.inspector.emptyTitle")}
          description={t("schedule.inspector.emptyDescription")}
        />
      ) : (
        <div className="space-y-4 max-h-[520px] overflow-y-auto custom-scrollbar pe-1">
          {sortedDates.map((date) => {
            const rows = (slotsByDate[date] ?? []).filter((s) =>
              filter === "all" ? true : String(s.status).toLowerCase() === filter,
            );
            if (rows.length === 0) return null;
            return (
              <GlassCard key={date} className="p-4 border border-border/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-foreground">
                    {new Date(date + "T00:00:00").toLocaleDateString(undefined, {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                  <button
                    onClick={() => onCancelDate(date)}
                    disabled={cancellingDate === date}
                    className="rounded-lg bg-danger/10 text-danger border border-danger/30 px-2.5 py-1 text-[10px] font-bold hover:bg-danger/20 transition disabled:opacity-50"
                  >
                    {t("schedule.inspector.cancelDay")}
                  </button>
                </div>
                <div className="grid gap-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
                  {rows.map((s) => (
                    <div
                      key={s.id}
                      className="glass rounded-xl p-2.5 border border-border/40 hover:border-primary-500/40 transition space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold font-mono">{s.startTime?.slice(0, 5)}–{s.endTime?.slice(0, 5)}</span>
                        <button
                          onClick={() => onRemoveSlot(s.id)}
                          className="text-muted-foreground hover:text-danger p-0.5 rounded hover:bg-danger/10 transition"
                          aria-label={t("schedule.inspector.deleteSlot")}
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                      <StatusBadge value={String(s.status ?? "available").toUpperCase()} />
                    </div>
                  ))}
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}
    </div>
  );
}
