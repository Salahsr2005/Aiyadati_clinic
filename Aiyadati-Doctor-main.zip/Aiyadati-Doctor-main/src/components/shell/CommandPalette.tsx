import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CalendarClock, LayoutDashboard, Search, User } from "lucide-react";
import { doctorAppointmentsApi } from "@/api/doctorSelfApi";
import { fullPatientName } from "@/api/appointmentsApi";
import { useTranslation } from "react-i18next";
import { doctorNavItems } from "@/components/shell/Sidebar";
import { qk } from "@/lib/queryKeys";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/** Doctor-scoped quick search: navigation + today's appointments/patients. */
export function CommandPalette({ open, onOpenChange }: Props) {
  const { t } = useTranslation();
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  useEffect(() => {
    if (!open) setQ("");
  }, [open]);

  const { data } = useQuery({
    queryKey: qk.doctorSelf.appointments({ limit: 50 }),
    queryFn: () => doctorAppointmentsApi.list({ limit: 50 }),
    enabled: open,
    staleTime: 30_000,
  });

  const term = q.trim().toLowerCase();

  const navMatches = useMemo(
    () =>
      doctorNavItems
        .filter((i) => {
          const label = i.i18nKey ? t(i.i18nKey, { defaultValue: i.label }) : i.label;
          return !term || label.toLowerCase().includes(term);
        })
        .slice(0, 5),
    [term, t],
  );

  const apptMatches = useMemo(() => {
    const items = data?.items ?? [];
    if (!term) return items.slice(0, 5);
    return items
      .filter((a) => {
        const name = fullPatientName(a.patient).toLowerCase();
        return name.includes(term) || (a.notes ?? "").toLowerCase().includes(term);
      })
      .slice(0, 6);
  }, [data, term]);

  if (!open) return null;

  const go = (to: string) => {
    onOpenChange(false);
    void navigate({ to });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-background/40 p-4 pt-24 backdrop-blur-sm"
      onClick={() => onOpenChange(false)}
    >
      <div
        className="glass w-full max-w-lg overflow-hidden rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 border-b border-border/50 px-4 py-3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("shell.commandPalette.placeholder")}
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>

        <div className="max-h-80 overflow-y-auto p-2">
          {navMatches.length > 0 && (
            <div className="mb-1">
              <div className="px-2 py-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                {t("shell.commandPalette.pages")}
              </div>
              {navMatches.map((i) => (
                <button
                  key={i.to}
                  onClick={() => go(i.to)}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-start text-sm hover:bg-accent/60"
                >
                  <LayoutDashboard className="h-4 w-4 text-muted-foreground" />
                  {i.i18nKey ? t(i.i18nKey, { defaultValue: i.label }) : i.label}
                </button>
              ))}
            </div>
          )}

          {apptMatches.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                {t("shell.commandPalette.appointments")}
              </div>
              {apptMatches.map((a) => {
                const name = fullPatientName(a.patient) || t("shell.commandPalette.patientFallback");
                return (
                  <button
                    key={a.id}
                    onClick={() => go("/appointments")}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-start text-sm hover:bg-accent/60"
                  >
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="truncate">{name}</span>
                    <span className="ms-auto flex items-center gap-1 text-xs text-muted-foreground">
                      <CalendarClock className="h-3 w-3" />
                      {a.slot?.date ?? ""} {a.slot?.startTime ?? ""}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {navMatches.length === 0 && apptMatches.length === 0 && (
            <div className="px-3 py-6 text-center text-sm text-muted-foreground">{t("shell.commandPalette.noResults")}</div>
          )}
        </div>
      </div>
    </div>
  );
}
