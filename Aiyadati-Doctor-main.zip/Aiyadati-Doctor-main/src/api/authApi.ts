import { api } from "@/lib/api";
import type { AuthResponse, AuthUser } from "@/types/api";

export const authApi = {
  login: (email: string, password: string) =>
    api.post<AuthResponse | { user: AuthUser; token: string }>("/auth/v1/login", { email, password })
      .then((r) => r.data as AuthResponse),
  doctorLogin: (email: string, password: string) =>
    api
      .post<AuthResponse>("/auth/v1/doctor/login", { email, password })
      .then((r) => r.data as AuthResponse),
  me: () =>
    api
      .get<AuthUser | { user: AuthUser }>("/auth/v1/me")
      .then((r) => {
        const d = r.data as AuthUser | { user: AuthUser };
        return (d && typeof d === "object" && "user" in d ? (d as { user: AuthUser }).user : d) as AuthUser;
      }),
  logout: () => api.post("/auth/v1/logout").then((r) => r.data),
};