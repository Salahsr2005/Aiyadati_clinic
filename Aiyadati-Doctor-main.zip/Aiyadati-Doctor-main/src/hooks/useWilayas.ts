import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface WilayaLite {
  id: string;
  code?: number;
  nameFr?: string;
  nameAr?: string;
}

async function fetchWilayas(): Promise<WilayaLite[]> {
  const res = await api.get("/location/v1/wilayas", { params: { limit: 100 } });
  const d = res.data as unknown;
  if (Array.isArray(d)) return d as WilayaLite[];
  if (d && typeof d === "object") {
    const p = d as Record<string, unknown>;
    const arr = (p.items as WilayaLite[]) ?? (p.data as WilayaLite[]) ?? [];
    return Array.isArray(arr) ? arr : [];
  }
  return [];
}

export function useWilayas() {
  return useQuery({
    queryKey: ["wilayas-lookup"],
    queryFn: fetchWilayas,
    staleTime: 5 * 60 * 1000,
  });
}

export function useWilayaMap() {
  const q = useQuery({
    queryKey: ["wilayas-lookup"],
    queryFn: fetchWilayas,
    staleTime: 5 * 60 * 1000,
  });
  const map = new Map<string, WilayaLite>();
  (q.data ?? []).forEach((w) => map.set(w.id, w));
  return { map, wilayas: q.data ?? [], isLoading: q.isLoading };
}