# Doctor Connect

Aiyadati — Doctor Dashboard (Self-Service Portal)

Implementation plan for Lovable · reusing Aiyadati-admin-main's UI/UX, components, and data layer against the Doctor self-service API surface

0. What this actually is

This is not the admin dashboard with a new skin — it's a new persona-scoped portal inside the same codebase, built for the DOCTOR role, that reuses the admin app's design system and already-built components (glass cards, EntityMap, heatmaps, DataTable, Drawer, WeeklyScheduleGrid/InteractiveScheduleGrid/ScheduleHeatmap) but is wired entirely against doctor self-service endpoints (/doctor/v1/me/, /appointment/v1/doctor/) instead of the staff/admin endpoints. A doctor should never see other doctors' data, and the API doesn't let them — every "me"/"doctor" scoped endpoint below is already scoped server-side to the authenticated doctor.

I verified this against the real code, not assumptions:

src/types/api.ts already defines Role = "SUPER_ADMIN" | "ADMIN" | "USER" | "DOCTOR" | "CLINIC" | string. The auth model was designed for multiple personas from day one — it's just never been routed for DOCTOR.

api-documentation-2026-07-26.json has a full doctor self-service surface that the admin app has never touched: GET/PUT /doctor/v1/me/availability, GET/POST/PATCH/DELETE /doctor/v1/me/breaks, GET /doctor/v1/me/profile, GET/POST/DELETE /doctor/v1/me/documents, GET /doctor/v1/me/clinic-invitations (+ accept/reject), POST /doctor/v1/me/clinics/request, PATCH /doctor/v1/me/complete, plus a parallel appointment surface: GET /appointment/v1/doctor/appointments, /pending, /stats, GET/PUT /appointment/v1/doctor/config, GET /appointment/v1/doctor/slots, POST .../slots/generate, POST .../slots/cancel-date, DELETE .../slots/{id}. Auth has a dedicated POST /auth/v1/doctor/login.

Analytics V2 has a doctor-scoped analytics endpoint that returns exactly the shape a personal dashboard needs — DoctorDetailedStats: totalAppointments, completedAppointments, cancelledAppointments, noShowAppointments, completionRate, cancellationRate, noShowRate, avgRating, totalReviews, totalRevenue, avgRevenuePerAppointment, uniquePatients, returningPatients, retentionRate, appointmentTypeDistribution, monthlyTrends, patientDemographics.byWilaya, peakHours, busiestDays. peakHours/busiestDays drive the heatmap, patientDemographics.byWilaya drives the map — same shape the admin dashboard uses, just doctor-scoped.

The exact schedule components a doctor's availability screen needs already exist and are already used for this purpose in the admin app's drawers: src/components/data/WeeklyScheduleGrid.tsx, src/components/data/InteractiveScheduleGrid.tsx, src/components/forms/ScheduleHeatmap.tsx (currently read-only inside DoctorDetailDrawer/ClinicDetailDrawer/ClinicFormModal). This plan turns them into editable self-service controls for the doctor themself.

1. Guardrails

Reuse, don't rebuild. Every screen below names the exact existing component to reuse. If a screen doesn't have a documented match, it's called out explicitly as new.

Same visual language. GlassCard, KPICard, MiniStat, Skeleton, EmptyState, Drawer, DataTable, the existing Tailwind/glass tokens, i18n (en/fr/ar) and RTL — identical to the admin app, not a redesign.

Strict data scoping. Every query must use a me/doctor-scoped endpoint. Never call the admin/staff /doctor/v1 (list-all), /appointment/v1/admin/appointments, etc. from this portal — those require staff auth and would 403 anyway, but the point is architectural: this portal's API module should physically be unable to fetch another doctor's data.

Type-check after every wave.

2. Wave 1 — Doctor auth + route scaffold + hardened state layer

1.1 Auth

src/api/authApi.ts → add loginDoctor: (email, password) => api.post("/auth/v1/doctor/login", { email, password }), reusing the exact same response handling as the existing login.

src/store/auth.ts needs no structural change — role is already on AuthUser. Add a useAuthStore selector helper isDoctor()/isAdmin() used by route guards instead of inlining role checks everywhere.

New src/routes/doctor-login.tsx (sibling of src/routes/login.tsx, same visual treatment, posts to authApi.loginDoctor).

New route-group guard src/routes/_doctorPortal.tsx (mirrors _authenticated.tsx's pattern — check src/routes/_authenticated.tsx for the existing redirect-if-unauthenticated logic and copy it) that additionally redirects to /login (not /doctor-login) if user.role !== "DOCTOR", so an admin session can't wander into the doctor portal and vice versa.

Handle the two edge states the API explicitly models: a doctor who hasn't finished PATCH /doctor/v1/me/complete (isCompleted: false on DoctorRow, already typed) gets routed to a profile-completion step instead of the dashboard; a doctor pending admin verification (isVerified: false) sees a calm "Your account is under review" state reusing the existing EmptyState/Alert pattern — not a broken dashboard full of empty widgets.

1.2 Route scaffold — mirror the admin structure, not the admin routes

Create src/routes/_doctorPortal.dashboard.tsx, _doctorPortal.appointments.tsx, _doctorPortal.schedule.tsx, _doctorPortal.patients.tsx, _doctorPortal.reviews.tsx, _doctorPortal.wallet.tsx, _doctorPortal.profile.tsx, _doctorPortal.clinics.tsx — same file-based routing convention as _authenticated.*.tsx.

New src/components/shell/DoctorSidebar.tsx / reuse src/components/shell/Sidebar.tsx with a nav items prop instead of forking it wholesale — check whether Sidebar.tsx's nav list is hardcoded or prop-driven; if hardcoded, refactor it to accept an items prop (small, low-risk change) so both admin and doctor shells share one component instead of diverging.

Reuse Topbar.tsx, CommandPalette.tsx (rescope its search to the doctor's own appointments/patients instead of global admin search), ModalRoot, Toaster as-is via AppProviders.

1.3 State management & error handling — identical discipline to the admin hardening pass

Apply the same production-grade layer (if not already done for the admin app, do it once, shared by both personas):

Configured QueryClient (staleTime, gcTime, smart retry that skips 401/403/404/4xx, global QueryCache/MutationCache onError → toast + reportError).

RootErrorBoundary wrapping both the admin Outlet and the new doctor-portal Outlet.

useOnlineStatus offline banner shared across both shells.

src/lib/mutations.ts's useEntityMutation used for every doctor action below (slot generation, break create/delete, appointment confirm, document upload) — optimistic update + rollback + toast + invalidate, consistent with admin mutations.

New qk.doctorSelf. query-key namespace in src/lib/queryKeys.ts, kept separate from qk.doctors. (the admin, list-all namespace) so cache invalidation can never cross-contaminate between "admin viewing doctor X" and "doctor viewing themself."

Lovable prompt — Wave 1:

Add a DOCTOR-role self-service portal alongside the existing admin app, reusing its shell and design system. In src/api/authApi.ts add loginDoctor calling POST /auth/v1/doctor/login. Create src/routes/doctor-login.tsx (same visual treatment as src/routes/login.tsx) and a route guard src/routes/_doctorPortal.tsx mirroring src/routes/_authenticated.tsx's auth-redirect logic, but redirecting non-DOCTOR roles to /login and redirecting to /doctor-login when unauthenticated. Handle two states explicitly: isCompleted: false → a profile-completion step; isVerified: false → a calm "under review" screen using the existing EmptyState/Alert components, not an empty dashboard. Scaffold _doctorPortal.dashboard.tsx, .appointments.tsx, .schedule.tsx, .patients.tsx, .reviews.tsx, .wallet.tsx, .profile.tsx, .clinics.tsx as file routes matching the existing _authenticated..tsx convention. If src/components/shell/Sidebar.tsx's nav items are hardcoded, refactor it to accept an items prop so both the admin and doctor shells share the same component; otherwise reuse it directly with a doctor-specific nav config. Reuse Topbar, ModalRoot, and Toaster via AppProviders unchanged. If not already present from prior hardening work, configure the QueryClient in src/router.tsx with staleTime/gcTime/smart retry (skip 401/403/404/4xx) and global QueryCache/MutationCache onError → toast + reportError; add RootErrorBoundary around both the admin and doctor Outlets; add an offline banner via useOnlineStatus; add src/lib/mutations.ts's useEntityMutation helper if missing. Add a qk.doctorSelf. namespace to src/lib/queryKeys.ts, kept separate from the existing admin qk.doctors.*. No visual redesign — reuse existing tokens and components. Type-check before finishing.

3. Wave 2 — Doctor Dashboard home (KPIs, map, heatmap — the core ask)

New src/api/doctorSelfApi.ts:

export const doctorSelfApi = {

  profile: () => api.get("/doctor/v1/me/profile").then(r => r.data),

  complete: (payload: FormData | Record<string, unknown>) =>

    api.patch("/doctor/v1/me/complete", payload, {

      headers: payload instanceof FormData ? { "Content-Type": "multipart/form-data" } : undefined,

    }).then(r => r.data),

  availability: {

    get: () => api.get("/doctor/v1/me/availability").then(r => r.data),

    set: (payload: unknown) => api.put("/doctor/v1/me/availability", payload).then(r => r.data),

    remove: (id: string) => api.delete(`/doctor/v1/me/availability/${id}`).then(r => r.data),

  },

  breaks: {

    list: () => api.get("/doctor/v1/me/breaks").then(r => r.data),

    create: (payload: unknown) => api.post("/doctor/v1/me/breaks", payload).then(r => r.data),

    update: (id: string, payload: unknown) => api.patch(`/doctor/v1/me/breaks/${id}`, payload).then(r => r.data),

    remove: (id: string) => api.delete(`/doctor/v1/me/breaks/${id}`).then(r => r.data),

  },

  documents: {

    list: () => api.get("/doctor/v1/me/documents").then(r => r.data),

    upload: (formData: FormData) =>

      api.post("/doctor/v1/me/documents", formData, { headers: { "Content-Type": "multipart/form-data" } }).then(r => r.data),

    remove: (id: string) => api.delete(`/doctor/v1/me/documents/${id}`).then(r => r.data),

  },

  clinicInvitations: {

    list: () => api.get("/doctor/v1/me/clinic-invitations").then(r => r.data),

    accept: (id: string) => api.post(`/doctor/v1/me/clinic-invitations/${id}/accept`, {}).then(r => r.data),

    reject: (id: string) => api.post(`/doctor/v1/me/clinic-invitations/${id}/reject`, {}).then(r => r.data),

  },

  requestClinic: (payload: { clinicId: string; message?: string }) =>

    api.post("/doctor/v1/me/clinics/request", payload).then(r => r.data),

};

export const doctorAppointmentsSelfApi = {

  list: (params: Record<string, unknown>) => api.get("/appointment/v1/doctor/appointments", { params }).then(r => r.data),

  pending: () => api.get("/appointment/v1/doctor/appointments/pending").then(r => r.data),

  stats: () => api.get("/appointment/v1/doctor/appointments/stats").then(r => r.data), // { pending, confirmed, in_progress, completed, cancelled, no_show, total }

  confirm: (id: string) => api.post(`/appointment/v1/appointments/${id}/confirm`, {}).then(r => r.data),

  updateStatus: (id: string, status: string) => api.patch(`/appointment/v1/${id}/status`, { status }).then(r => r.data),

  config: {

    get: () => api.get("/appointment/v1/doctor/config").then(r => r.data),

    set: (payload: unknown) => api.put("/appointment/v1/doctor/config", payload).then(r => r.data),

  },

  slots: {

    list: (params?: Record<string, unknown>) => api.get("/appointment/v1/doctor/slots", { params }).then(r => r.data),

    generate: (payload: unknown) => api.post("/appointment/v1/doctor/slots/generate", payload).then(r => r.data),

    cancelDate: (payload: { date: string }) => api.post("/appointment/v1/doctor/slots/cancel-date", payload).then(r => r.data),

    remove: (id: string) => api.delete(`/appointment/v1/doctor/slots/${id}`).then(r => r.data),

  },

};

analyticsV2Api.doctorDetails(myDoctorId, ...) / .doctorRevenue(myDoctorId, ...) / .doctorRetention(myDoctorId) from the admin plan's analyticsV2Api are reused as-is — same functions, called with the authenticated doctor's own ID pulled from useAuthStore().user. No new analytics API module needed here.

Dashboard composition (_doctorPortal.dashboard.tsx) — reusing the exact admin widgets:

Widget Reused component Data source KPI row (appointments today, pending, revenue this month, avg rating) KPICard, MiniStat doctorAppointmentsSelfApi.stats() + analyticsV2Api.doctorDetails(id) Booking pattern heatmap (best/worst hours & days) DayHourHeatmap / OptimalBookingTime (same components, new data source) DoctorDetailedStats.peakHours + .busiestDays — already shaped exactly like the admin's day/hour data, zero client aggregation "My patients" map EntityMap (unmodified) via a doctor-scoped wrapper MyPatientsMapSection.tsx (new, mirrors MapDashboardSection.tsx's pattern) DoctorDetailedStats.patientDemographics.byWilaya, resolved to lat/lng via the existing src/lib/wilayaCentroids.ts — same technique as the admin's wilaya-weighted heat layer Revenue trend recharts line chart, same styling as AppointmentAnalytics/PatientAnalytics in overview/ DoctorDetailedStats.monthlyTrends Appointment type split reuse the donut pattern from ResponseTimeDistribution DoctorDetailedStats.appointmentTypeDistribution Pending action items ("3 appointments to confirm", "1 clinic invitation") InsightCards pattern doctorAppointmentsSelfApi.pending(), doctorSelfApi.clinicInvitations.list() Recent appointments RecentAppointmentsTable (same component, doctor-scoped query) doctorAppointmentsSelfApi.list({ limit: 10 })

Note on the map: unlike the admin's platform-wide map (clinics + doctors + booking-density layers), the doctor's map has one meaningful layer — their own patients' home wilayas, weighted by count. Reuse EntityMap's existing type: "appointment"/heatmap layer for this (it already renders a single weighted heat layer correctly) and skip the clinic/doctor marker layers/toggles that don't apply here — pass an empty array for those MapPoint types rather than modifying EntityMap.tsx.

Lovable prompt — Wave 2:

Create src/api/doctorSelfApi.ts and doctorAppointmentsSelfApi (can live in the same file or src/api/appointmentsApi.ts) wrapping every /doctor/v1/me/ and /appointment/v1/doctor/ endpoint from api-documentation-2026-07-26.json (profile, complete, availability get/set/remove, breaks CRUD, documents CRUD, clinic-invitations list/accept/reject, clinics/request, appointments list/pending/stats/confirm/status, config get/set, slots list/generate/cancel-date/remove). Add matching qk.doctorSelf.* keys. Build _doctorPortal.dashboard.tsx reusing existing components with doctor-scoped data: KPICard/MiniStat fed by doctorAppointmentsSelfApi.stats() and analyticsV2Api.doctorDetails(myId) (reuse the existing analyticsV2Api module, call it with the authenticated doctor's own ID from useAuthStore); DayHourHeatmap/OptimalBookingTime fed directly by DoctorDetailedStats.peakHours/.busiestDays (no client aggregation); a new MyPatientsMapSection.tsx (mirroring MapDashboardSection.tsx's structure) rendering patientDemographics.byWilaya through EntityMap as a single weighted heat layer, resolved via wilayaCentroids.ts, with the clinic/doctor marker layers passed empty arrays rather than modifying EntityMap.tsx; a revenue trend chart from monthlyTrends styled like the existing overview/AppointmentAnalytics; an appointment-type donut from appointmentTypeDistribution styled like ResponseTimeDistribution; an action-items section (pending appointments to confirm + pending clinic invitations) styled like InsightCards; and RecentAppointmentsTable reused as-is with a doctor-scoped query. Match existing skeleton/empty/error states throughout. Type-check before finishing.

4. Wave 3 — Schedule & availability (turn the existing read-only schedule components into self-service editors)

Weekly availability editor (_doctorPortal.schedule.tsx, "Availability" tab): reuse src/components/data/WeeklyScheduleGrid.tsx in edit mode — check its current props (likely read-only render from ClinicFormModal's working-hours flow); add an editable/onChange prop if it doesn't already support one, following the same interaction pattern already built into InteractiveScheduleGrid.tsx. Wire onChange → doctorSelfApi.availability.set() through useEntityMutation with optimistic update.

Breaks manager (same tab): a compact list (reuse DataTable or a simple card list matching InfoCard.tsx) over doctorSelfApi.breaks.list(), with add/edit/delete wired to breaks.create/update/remove.

Slot configuration ("Booking rules" tab): a form (reuse FormModal/FormSlideOver patterns) over doctorAppointmentsSelfApi.config.get/set — appointment duration, buffer time, max patients per slot, booking window (exact fields per whatever SlotConfig schema defines — read it from the OpenAPI doc before building the form so every field maps 1:1, don't guess).

Slot generation & calendar ("My slots" tab): reuse src/components/forms/ScheduleHeatmap.tsx — it's already a calendar-style density view — repointed at doctorAppointmentsSelfApi.slots.list() to show generated slots (green = open, filled = booked), with a "Generate slots" action (slots.generate) and per-date "Cancel all" (slots.cancelDate) / per-slot delete (slots.remove) reusing ConfirmDialog for destructive actions, consistent with how suspend/reject confirmations work in the admin app.

Lovable prompt — Wave 3:

Before building, read the SlotConfig/availability/break schemas for /appointment/v1/doctor/config, /doctor/v1/me/availability, and /doctor/v1/me/breaks in api-documentation-2026-07-26.json so every form field maps exactly to a real backend field. In _doctorPortal.schedule.tsx, build an "Availability" tab reusing src/components/data/WeeklyScheduleGrid.tsx in editable mode (add an editable/onChange prop if missing, matching the interaction pattern in InteractiveScheduleGrid.tsx) wired to doctorSelfApi.availability.set() via useEntityMutation with optimistic update; a breaks list (reuse DataTable or InfoCard) wired to doctorSelfApi.breaks CRUD; a "Booking rules" tab as a form (reuse FormModal/FormSlideOver styling) wired to doctorAppointmentsSelfApi.config.get/set; and a "My slots" tab reusing src/components/forms/ScheduleHeatmap.tsx repointed at doctorAppointmentsSelfApi.slots.list(), with "Generate slots" and per-date "Cancel all"/per-slot delete actions using the existing ConfirmDialog pattern for destructive actions. Match existing loading/empty/error states. Type-check before finishing.

5. Wave 4 — Appointments, patients, reviews, wallet, profile, clinics

Screen Reused component(s) Endpoints _doctorPortal.appointments.tsx — full list with filters, status update, confirm pending ResourceListPage/DataTable pattern (same as admin's _authenticated.appointments.tsx, but resource-scoped) doctorAppointmentsSelfApi.list, .pending, .confirm, .updateStatus _doctorPortal.patients.tsx — the doctor's unique patients, derived from their own appointment history (no admin "all users" endpoint should be called here) DataTable + UserAvatar/UserCard styling Derived client-side from doctorAppointmentsSelfApi.list({ limit: large, distinct patients }) or, if the backend patient list needs pagination beyond what's practical to derive client-side, flag this back — there's no dedicated "my patients list" endpoint in the doc; only uniquePatients/returningPatients counts exist via analytics. Ship the derived-list version now; note the missing dedicated endpoint as a backend ask rather than faking pagination. _doctorPortal.reviews.tsx Existing reviewsApi.doctor(id) / .doctorStats(id) (already built for the admin drawer — reuse directly, called with the doctor's own ID) /review/v1/doctor/{id}, /review/v1/doctor/{id}/stats _doctorPortal.wallet.tsx Existing wallet components/patterns from _authenticated.wallet.tsx, scoped down (a doctor sees their own transactions only — confirm which wallet endpoint applies to a doctor persona vs. patient credits; if none exists for doctors in the current doc, this tab surfaces earnings from analyticsV2Api.doctorRevenue instead of a transaction ledger) analyticsV2Api.doctorRevenue(myId, ...) _doctorPortal.profile.tsx DoctorFormModal's field set, repurposed as an inline editable profile page instead of a modal doctorSelfApi.profile(), .complete(), documents CRUD _doctorPortal.clinics.tsx — invitations + join requests New, small screen: list of invitations (accept/reject) + a "request to join a clinic" search (reuse clinicsApi.list for the picker, same SearchInput/SelectMenu components) doctorSelfApi.clinicInvitations.*, .requestClinic

Lovable prompt — Wave 4:

Build the remaining doctor portal screens, reusing existing admin components scoped to the doctor's own data only. _doctorPortal.appointments.tsx: reuse the ResourceListPage/DataTable pattern from src/routes/_authenticated.appointments.tsx, sourced from doctorAppointmentsSelfApi.list/pending, with confirm/status-update actions via useEntityMutation. _doctorPortal.patients.tsx: derive a unique-patient list client-side from the doctor's own appointment history (there is no dedicated "my patients" list endpoint in the API docs — do not invent one; use the existing uniquePatients/returningPatients counts from analyticsV2Api.doctorDetails for the summary stats and a derived table for the list), styled with UserAvatar/UserCard. _doctorPortal.reviews.tsx: reuse the existing reviewsApi.doctor/doctorStats calls with the authenticated doctor's own ID. _doctorPortal.wallet.tsx: surface analyticsV2Api.doctorRevenue(myId) styled like the existing wallet screen — confirm with me before building if there turns out to be no doctor-facing wallet/transactions endpoint distinct from the admin one. _doctorPortal.profile.tsx: adapt DoctorFormModal's field set into an inline editable profile page wired to doctorSelfApi.profile/complete plus document upload/delete. _doctorPortal.clinics.tsx: clinic invitations list with accept/reject, plus a "request to join a clinic" flow reusing clinicsApi.list for the picker and existing SearchInput/SelectMenu components. Match every existing loading/empty/error/toast convention from the admin app. Type-check before finishing.

6. Execution order

Wave 1 — auth, routing, shared shell, hardened state/error layer.

Wave 2 — dashboard home (this is the map/heatmap/KPI ask, prioritize it right after auth works).

Wave 3 — schedule/availability self-service (turns the portal from "view-only" into something a doctor actually uses daily).

Wave 4 — the remaining CRUD screens.

Paste each wave into Lovable separately, review the diff, confirm the type-checker is clean, then continue — same discipline as the admin plan.

implement all waves at once using the most modern and prfessional liquid glass styling for dashboards
NOTE:USE THE PROVIDED ADMIN CIDEBASE ONLY FOR INSPIRING THE UI/UX BUT THIS DASHOBOARD IS FOR DOCTORS ONLY SO IMPLEMENT API INTEGRATION FOR DOCTORS TO MANAGE SLOTS AND PATIENTS AND APPOINTMENTS IN THE BEST UI/UX AND MAKE IT PRODUCTION READY AND ALSO USE THE ASSESTS FROM ADMIN CODEBASE LIKE LOGO AND ILLUSTRATIONS AND ALSO IMPLEMENT MAP VIEW USING MAP BOX CREDENTIALS:
EXPO_MAPBOX_TOKEN = pk.eyJ1Ijoic2FsYWgwNSIsImEiOiJjbXFwMmlkMDAwMjBwMnlzOHJjb3I0MWswIn0.8aDxg1IQfeiKANbJTjjG9w

EXPO_PUBLIC_MAPBOX_TOKEN = pk.eyJ1Ijoic2FsYWgwNSIsImEiOiJjbXFwMmlkMDAwMjBwMnlzOHJjb3I0MWswIn0.8aDxg1IQfeiKANbJTjjG9w

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e3faab99-f224-482f-8b90-2431a910fc8d).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
