import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import {
  FileText,
  Upload,
  Download,
  ShieldAlert,
  ShieldCheck,
  X,
  Loader2,
  FileCheck,
  Calendar,
  HardDrive,
  AlertTriangle,
  Lock,
  Clock,
  Sparkles,
} from "lucide-react";
import {
  doctorConsentApi,
  type PatientDocumentRow,
  type ConsentPatientRow,
  type ConsentError,
  type ConsentLevel,
} from "@/api/consentApi";
import { qk } from "@/lib/queryKeys";
import { GlassCard } from "@/components/glass/GlassCard";
import { Skeleton } from "@/components/glass/Skeleton";
import { ConfirmDialog } from "@/components/data/ConfirmDialog";
import { toast } from "sonner";

interface MedicalDocsDrawerProps {
  patientId: string | null;
  patientName?: string;
  open: boolean;
  onClose: () => void;
  appointmentId?: string;
  initialConsentRow?: ConsentPatientRow | null;
}

export function MedicalDocsDrawer({
  patientId,
  patientName = "Patient",
  open,
  onClose,
  appointmentId,
  initialConsentRow,
}: MedicalDocsDrawerProps) {
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [docTitle, setDocTitle] = useState("");
  const [docDescription, setDocDescription] = useState("");
  const [docDate, setDocDate] = useState("");
  const [docTags, setDocTags] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [showConfirmUpload, setShowConfirmUpload] = useState(false);

  // Fetch all consent records for doctor to find this patient's level & doc count
  const consentPatientsQuery = useQuery({
    queryKey: qk.consent.patients(),
    queryFn: doctorConsentApi.patients,
    enabled: open && !!patientId,
  });

  const consentRow =
    initialConsentRow ||
    (consentPatientsQuery.data || []).find(
      (c) => c.patientId === patientId || c.patient?.id === patientId,
    );

  const level: ConsentLevel = consentRow?.level || "NONE";
  const documentCount = consentRow?.documentCount ?? 0;
  const expiresAt = consentRow?.expiresAt;
  const isExpired = expiresAt ? new Date(expiresAt) < new Date() : false;
  const isActiveConsent = (consentRow?.isActive ?? true) && !isExpired && level !== "NONE";

  // Upload is allowed ONLY if consent level is FULL or CUSTOM and consent is active
  const isUploadAllowed = (level === "FULL" || level === "CUSTOM") && isActiveConsent;

  // Documents query: only execute if patient consent is active AND documentCount > 0
  const docsQuery = useQuery({
    queryKey: qk.consent.documents(patientId || ""),
    queryFn: () => doctorConsentApi.documents(patientId!),
    enabled: !!patientId && open && isActiveConsent && documentCount > 0,
  });

  if (!open || !patientId) return null;

  const isNoConsentError = (docsQuery.error as ConsentError)?.noConsent || !isActiveConsent;
  const documents = docsQuery.data?.documents || [];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileToUpload || !patientId || !isUploadAllowed) return;

    if (fileToUpload.size > 20 * 1024 * 1024) {
      toast.error("File size exceeds 20MB limit.");
      return;
    }

    setShowConfirmUpload(true);
  };

  const executeUpload = async () => {
    if (!fileToUpload || !patientId || !isUploadAllowed) return;

    setIsUploading(true);
    setShowConfirmUpload(false);

    try {
      const uploadedDoc = await doctorConsentApi.upload(patientId, {
        file: fileToUpload,
        title: docTitle.trim() || undefined,
        description: docDescription.trim() || undefined,
        docDate: docDate || undefined,
        tags: docTags.trim() || undefined,
        appointmentId: appointmentId || undefined,
      });

      toast.success("Medical document attached to patient file successfully");

      setFileToUpload(null);
      setDocTitle("");
      setDocDescription("");
      setDocDate("");
      setDocTags("");

      // Optimistically update query cache or invalidate
      void queryClient.invalidateQueries({ queryKey: qk.consent.documents(patientId) });
      void queryClient.invalidateQueries({ queryKey: qk.consent.patients() });
    } catch (err: any) {
      const errorMsg =
        err?.response?.data?.message || err?.message || "Failed to upload document";
      toast.error(errorMsg);
    } finally {
      setIsUploading(false);
    }
  };

  const formatSize = (bytes: number) => {
    if (!bytes) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex justify-end bg-background/80 backdrop-blur-sm animate-in fade-in duration-200">
        <div
          className="w-full max-w-xl border-l border-border/40 bg-card p-6 shadow-2xl overflow-y-auto flex flex-col justify-between"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary-500/10 text-primary-500">
                  <FileText className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-foreground">Medical Records Access</h3>
                    <ConsentBadge level={level} isExpired={isExpired} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{patientName}</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="grid h-8 w-8 place-items-center rounded-xl hover:bg-muted/30 text-muted-foreground hover:text-foreground transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Consent Status Details */}
            {consentRow && (
              <GlassCard className="p-3.5 space-y-2 border border-border/40 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-muted-foreground flex items-center gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-primary-500" /> Patient Grant Status:
                  </span>
                  <span className="font-bold text-foreground capitalize">
                    {level === "FULL"
                      ? "Full Access (All Records)"
                      : level === "APPOINTMENT_ONLY"
                        ? "Appointment-Only Access"
                        : level === "CUSTOM"
                          ? "Custom Allow-List"
                          : "No Access Granted"}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1.5 border-t border-border/30 text-[11px]">
                  <span className="text-muted-foreground">Accessible Records Count:</span>
                  <span className="font-mono font-bold text-foreground">{documentCount}</span>
                </div>

                {expiresAt && (
                  <div className="flex items-center justify-between pt-1.5 border-t border-border/30 text-[11px]">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3 text-warning" /> Consent Expiration:
                    </span>
                    <span
                      className={`font-semibold ${isExpired ? "text-danger" : "text-foreground"}`}
                    >
                      {new Date(expiresAt).toLocaleDateString()} {isExpired ? "(Expired)" : ""}
                    </span>
                  </div>
                )}
              </GlassCard>
            )}

            {/* No Consent / Expired Warning State */}
            {isNoConsentError && documentCount === 0 && (
              <div className="rounded-3xl border border-amber-500/30 bg-amber-500/10 p-6 text-center space-y-3">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-amber-500/20 text-amber-500">
                  <ShieldAlert className="h-6 w-6" />
                </div>
                <h4 className="text-sm font-bold text-foreground">
                  {isExpired ? "Patient Access Consent Expired" : "Patient Consent Required"}
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {isExpired
                    ? "The consent window granted by this patient has expired. Ask the patient to renew access from their mobile app."
                    : "This patient has not granted consent to share their medical documents with your profile yet. Ask the patient to share access from their application."}
                </p>
              </div>
            )}

            {/* Document List */}
            {isActiveConsent && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center justify-between">
                  <span>Accessible Records ({documentCount})</span>
                  {appointmentId && (
                    <span className="text-[10px] text-primary-500 font-semibold normal-case">
                      Linked to current appointment
                    </span>
                  )}
                </h4>

                {docsQuery.isLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded-2xl" />
                    ))}
                  </div>
                ) : documents.length === 0 ? (
                  <div className="rounded-2xl border border-border/40 p-6 text-center text-xs text-muted-foreground space-y-1.5">
                    <p className="font-semibold text-foreground">No medical documents available yet</p>
                    <p className="text-[11px]">
                      {level === "APPOINTMENT_ONLY"
                        ? "Documents tied to confirmed or completed appointments will appear here."
                        : "No documents have been uploaded to this patient's profile yet."}
                    </p>
                  </div>
                ) : (
                  <ul className="space-y-2.5">
                    {documents.map((doc: PatientDocumentRow) => (
                      <li
                        key={doc.id}
                        className="glass flex items-center justify-between gap-3 rounded-2xl border border-border/40 p-3.5 hover:bg-muted/20 transition"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary-500/10 text-primary-500">
                            <FileCheck className="h-4.5 w-4.5" />
                          </div>
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-foreground truncate">
                              {doc.title || doc.fileName}
                            </h5>
                            <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground mt-0.5">
                              <span className="flex items-center gap-1">
                                <HardDrive className="h-3 w-3" /> {formatSize(doc.fileSize)}
                              </span>
                              {doc.docDate && (
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" /> {doc.docDate.slice(0, 10)}
                                </span>
                              )}
                              {doc.tags && (
                                <span className="rounded bg-muted px-1.5 py-0.2 text-[9px] font-bold text-muted-foreground">
                                  {doc.tags}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {doc.accessUrl && (
                          <a
                            href={doc.accessUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-primary-500/15 px-3 py-1.5 text-xs font-bold text-primary-500 hover:bg-primary-500/25 transition shrink-0"
                          >
                            <Download className="h-3.5 w-3.5" /> View
                          </a>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {/* Upload Document Section */}
            {isUploadAllowed ? (
              <GlassCard className="p-4 border border-border/40 space-y-3">
                <h4 className="text-xs font-bold text-foreground flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Upload className="h-4 w-4 text-primary-500" /> Attach Medical Record
                  </span>
                  <span className="text-[10px] text-muted-foreground font-semibold">
                    Allowed under {level} level
                  </span>
                </h4>

                <form onSubmit={handleFormSubmit} className="space-y-3">
                  <div>
                    <input
                      type="text"
                      placeholder="Document Title (e.g., Blood Test Result, Prescription)"
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      className="w-full rounded-xl border border-border/40 bg-muted/20 px-3 py-2 text-xs font-semibold outline-none focus:border-primary-500 transition"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      value={docDate}
                      onChange={(e) => setDocDate(e.target.value)}
                      className="w-full rounded-xl border border-border/40 bg-muted/20 px-3 py-2 text-xs font-semibold outline-none focus:border-primary-500 transition"
                      title="Document Date"
                    />
                    <input
                      type="text"
                      placeholder="Tags (e.g., lab, x-ray)"
                      value={docTags}
                      onChange={(e) => setDocTags(e.target.value)}
                      className="w-full rounded-xl border border-border/40 bg-muted/20 px-3 py-2 text-xs font-semibold outline-none focus:border-primary-500 transition"
                    />
                  </div>

                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => setFileToUpload(e.target.files?.[0] || null)}
                    className="w-full text-xs text-muted-foreground file:mr-3 file:rounded-xl file:border-0 file:bg-primary-500/15 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-primary-500 hover:file:bg-primary-500/25 cursor-pointer"
                  />

                  <button
                    type="submit"
                    disabled={!fileToUpload || isUploading}
                    className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary-500 px-4 py-2.5 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary-600 transition disabled:opacity-50"
                  >
                    {isUploading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4" />
                    )}
                    Upload Document to Patient File
                  </button>
                </form>
              </GlassCard>
            ) : (
              <div className="rounded-2xl border border-border/40 bg-muted/20 p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-foreground">
                  <Lock className="h-4 w-4 text-muted-foreground" /> Document Upload Unavailable
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {level === "APPOINTMENT_ONLY"
                    ? "Patient consent is set to Appointment-Only access. Uploading new medical documents requires the patient to grant Full or Custom consent."
                    : "Doctor document uploads are not permitted without active Full or Custom patient consent."}
                </p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="pt-4 border-t border-border/30 mt-6">
            <button
              onClick={onClose}
              className="w-full rounded-2xl border border-border/40 py-2.5 text-xs font-bold text-foreground hover:bg-muted/20 transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog for Upload */}
      <ConfirmDialog
        open={showConfirmUpload}
        onClose={() => setShowConfirmUpload(false)}
        onConfirm={executeUpload}
        title="Confirm Document Upload"
        description={`Are you sure you want to attach "${fileToUpload?.name}" to ${patientName}'s permanent medical file? Uploaded documents cannot be deleted or modified by doctor accounts.`}
        confirmLabel="Confirm & Attach"
        danger={false}
      />
    </>
  );
}

function ConsentBadge({ level, isExpired }: { level: ConsentLevel; isExpired?: boolean }) {
  if (isExpired) {
    return (
      <span className="rounded-full bg-danger/15 px-2.5 py-0.5 text-[10px] font-bold text-danger border border-danger/30">
        EXPIRED
      </span>
    );
  }

  switch (level) {
    case "FULL":
      return (
        <span className="rounded-full bg-success/15 px-2.5 py-0.5 text-[10px] font-bold text-success border border-success/30 flex items-center gap-1">
          <Sparkles className="h-2.5 w-2.5" /> FULL ACCESS
        </span>
      );
    case "APPOINTMENT_ONLY":
      return (
        <span className="rounded-full bg-info/15 px-2.5 py-0.5 text-[10px] font-bold text-info border border-info/30">
          APPOINTMENT ONLY
        </span>
      );
    case "CUSTOM":
      return (
        <span className="rounded-full bg-warning/15 px-2.5 py-0.5 text-[10px] font-bold text-warning border border-warning/30">
          CUSTOM LIST
        </span>
      );
    case "NONE":
    default:
      return (
        <span className="rounded-full bg-muted px-2.5 py-0.5 text-[10px] font-bold text-muted-foreground border border-border/40">
          NO CONSENT
        </span>
      );
  }
}

