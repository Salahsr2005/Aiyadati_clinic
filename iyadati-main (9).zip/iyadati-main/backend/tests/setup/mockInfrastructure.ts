// backend/tests/setup/mockInfrastructure.ts
//
// Loaded via `setupFiles` BEFORE the test framework and BEFORE any test file
// imports the app. It replaces every module that would otherwise open a network
// connection (Redis / BullMQ / Firebase / email / S3).
//
// Must be require-safe: no top-level awaits, no imports of the real modules.

/* eslint-disable @typescript-eslint/no-var-requires */

// ============================================================
// Redis client (src/infrastructure/redis/client)
// ============================================================

jest.mock('../../src/infrastructure/redis/client', () => {
  const mockRedis: any = {
    get: jest.fn().mockResolvedValue(null),
    set: jest.fn().mockResolvedValue('OK'),
    setex: jest.fn().mockResolvedValue('OK'),
    del: jest.fn().mockResolvedValue(1),
    exists: jest.fn().mockResolvedValue(0),
    ttl: jest.fn().mockResolvedValue(-1),
    expire: jest.fn().mockResolvedValue(1),
    incr: jest.fn().mockResolvedValue(1),
    decr: jest.fn().mockResolvedValue(0),
    hget: jest.fn().mockResolvedValue(null),
    hset: jest.fn().mockResolvedValue(1),
    hgetall: jest.fn().mockResolvedValue({}),
    hdel: jest.fn().mockResolvedValue(1),
    keys: jest.fn().mockResolvedValue([]),
    scan: jest.fn().mockResolvedValue(['0', []]),
    flushdb: jest.fn().mockResolvedValue('OK'),
    ping: jest.fn().mockResolvedValue('PONG'),
    quit: jest.fn().mockResolvedValue('OK'),
    disconnect: jest.fn().mockResolvedValue(undefined),
    duplicate: jest.fn(),
    on: jest.fn(),
    once: jest.fn(),
    off: jest.fn(),
    status: 'ready',
  };
  mockRedis.duplicate.mockReturnValue(mockRedis);

  return {
    redis: mockRedis,
    default: mockRedis,
    getRedis: () => mockRedis,
    closeRedis: jest.fn().mockResolvedValue(undefined),
  };
});

// ============================================================
// Redis config (src/infrastructure/redis)
// ============================================================

jest.mock('../../src/infrastructure/redis', () => {
  const mockRedis: any = {
    get: jest.fn().mockResolvedValue(null),
    set: jest.fn().mockResolvedValue('OK'),
    del: jest.fn().mockResolvedValue(1),
    quit: jest.fn().mockResolvedValue('OK'),
    disconnect: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    duplicate: jest.fn(),
    status: 'ready',
  };
  mockRedis.duplicate.mockReturnValue(mockRedis);

  return {
    redis: mockRedis,
    default: mockRedis,
    redisConfig: {
      host: 'localhost',
      port: 6379,
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
    },
    closeRedis: jest.fn().mockResolvedValue(undefined),
  };
});

// ============================================================
// IORedis (BullMQ depends on it)
// ============================================================

jest.mock('ioredis', () => {
  const mockInstance: any = {
    get: jest.fn().mockResolvedValue(null),
    set: jest.fn().mockResolvedValue('OK'),
    del: jest.fn().mockResolvedValue(1),
    quit: jest.fn().mockResolvedValue('OK'),
    disconnect: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    once: jest.fn(),
    duplicate: jest.fn(),
    status: 'ready',
    options: {},
  };
  mockInstance.duplicate.mockReturnValue(mockInstance);

  const IORedisMock: any = jest.fn(() => mockInstance);
  IORedisMock.default = IORedisMock;
  IORedisMock.Cluster = jest.fn(() => mockInstance);

  return IORedisMock;
});

// ============================================================
// BullMQ connection
// ============================================================

jest.mock('../../src/infrastructure/queues/connection', () => ({
  bullMqConnection: {
    on: jest.fn(),
    once: jest.fn(),
    quit: jest.fn().mockResolvedValue('OK'),
    disconnect: jest.fn().mockResolvedValue(undefined),
    status: 'ready',
  },
  closeBullMqConnection: jest.fn().mockResolvedValue(undefined),
}));

// ============================================================
// bullmq module — replaces Queue / Worker / QueueEvents
// ============================================================

jest.mock('bullmq', () => {
  const makeQueue = () => ({
    add: jest.fn().mockResolvedValue({ id: 'mock-job-id' }),
    addBulk: jest.fn().mockResolvedValue([]),
    removeRepeatable: jest.fn().mockResolvedValue(true),
    removeRepeatableByKey: jest.fn().mockResolvedValue(true),
    remove: jest.fn().mockResolvedValue(true),
    getJob: jest.fn().mockResolvedValue(null),
    getJobs: jest.fn().mockResolvedValue([]),
    getRepeatableJobs: jest.fn().mockResolvedValue([]),
    clean: jest.fn().mockResolvedValue([]),
    close: jest.fn().mockResolvedValue(undefined),
    drain: jest.fn().mockResolvedValue(undefined),
    pause: jest.fn().mockResolvedValue(undefined),
    resume: jest.fn().mockResolvedValue(undefined),
    obliterate: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    once: jest.fn(),
    name: 'mock-queue',
  });

  const makeWorker = () => ({
    close: jest.fn().mockResolvedValue(undefined),
    pause: jest.fn().mockResolvedValue(undefined),
    resume: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    once: jest.fn(),
    name: 'mock-worker',
  });

  const makeQueueEvents = () => ({
    close: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    once: jest.fn(),
  });

  return {
    Queue: jest.fn(() => makeQueue()),
    Worker: jest.fn(() => makeWorker()),
    QueueEvents: jest.fn(() => makeQueueEvents()),
    Job: jest.fn(),
  };
});

// ============================================================
// Concrete queue singletons
// ============================================================

jest.mock('../../src/infrastructure/queues/email/email.queue', () => ({
  emailQueue: {
    enqueueOtp: jest.fn().mockResolvedValue(undefined),
    enqueuePasswordSetup: jest.fn().mockResolvedValue(undefined),
    enqueueApplicationRejection: jest.fn().mockResolvedValue(undefined),
    enqueueAdminNotification: jest.fn().mockResolvedValue(undefined),
    enqueuePasswordReset: jest.fn().mockResolvedValue(undefined),
    getQueue: jest.fn().mockReturnValue({ add: jest.fn() }),
    close: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('../../src/infrastructure/queues/notification/notification.queue', () => ({
  notificationQueue: {
    enqueue: jest.fn().mockResolvedValue(undefined),
    getQueue: jest.fn().mockReturnValue({ add: jest.fn() }),
    close: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('../../src/infrastructure/queues/reminder/reminder.queue', () => ({
  reminderQueue: {
    enqueueReminder: jest.fn().mockResolvedValue(undefined),
    enqueueReminders: jest.fn().mockResolvedValue(undefined),
    cancelRemindersByIds: jest.fn().mockResolvedValue({ removed: 0, total: 0 }),
    getQueue: jest.fn().mockReturnValue({ add: jest.fn(), remove: jest.fn() }),
    close: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('../../src/infrastructure/queues/slot-generation/slot-generation.queue', () => ({
  SlotGenerationJobName: {
    GENERATE_SLOTS: 'generate-slots',
    CHECK_RULES: 'check-rules',
    CLEAN_EXPIRED_SLOTS: 'clean-expired-slots',
  },
  slotGenerationQueue: {
    enqueueGenerateSlots: jest.fn().mockResolvedValue(undefined),
    enqueueCheckRules: jest.fn().mockResolvedValue(undefined),
    enqueueCleanExpiredSlots: jest.fn().mockResolvedValue(undefined),
    getQueue: jest.fn().mockReturnValue({ add: jest.fn() }),
    close: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('../../src/infrastructure/queues/account-deletion/account-deletion.queue', () => ({
  AccountDeletionJobName: {
    DELETE_USER: 'delete-user',
    CHECK_PENDING: 'check-pending',
  },
  accountDeletionQueue: {
    enqueueUserDeletion: jest.fn().mockResolvedValue(undefined),
    scheduleRecurringCheck: jest.fn().mockResolvedValue(undefined),
    getQueue: jest.fn().mockReturnValue({ add: jest.fn() }),
    close: jest.fn().mockResolvedValue(undefined),
  },
}));

// ============================================================
// Workers — prevent real Worker construction
// ============================================================

jest.mock('../../src/infrastructure/queues/email/email.worker', () => ({
  emailWorker: { close: jest.fn().mockResolvedValue(undefined) },
}));

jest.mock('../../src/infrastructure/queues/notification/notification.worker', () => ({
  notificationWorker: { close: jest.fn().mockResolvedValue(undefined) },
}));

jest.mock('../../src/infrastructure/queues/reminder/reminder.worker', () => ({
  reminderWorker: { close: jest.fn().mockResolvedValue(undefined) },
}));

jest.mock('../../src/infrastructure/queues/slot-generation/slot-generation.worker', () => ({
  slotGenerationWorker: { close: jest.fn().mockResolvedValue(undefined) },
}));

jest.mock('../../src/infrastructure/queues/account-deletion/account-deletion.worker', () => ({
  accountDeletionWorker: { close: jest.fn().mockResolvedValue(undefined) },
}));

// ============================================================
// Firebase
// ============================================================

jest.mock('../../src/config/firebase', () => ({
  sendPushNotification: jest.fn().mockResolvedValue(true),
  initializeFirebase: jest.fn(),
}));

// ============================================================
// Email sender
// ============================================================

jest.mock('../../src/core/utils/email', () => ({
  sendEmail: jest.fn().mockResolvedValue(true),
}));

// ============================================================
// File storage (SeaweedFS)
// ============================================================

jest.mock(
  '../../src/infrastructure/storage/seaweedfs',
  () => ({
    seaweedfsClient: {
      upload: jest.fn().mockResolvedValue({ fileId: 'mock-file-id' }),
      delete: jest.fn().mockResolvedValue(true),
      getUrl: jest.fn().mockReturnValue('http://mock-url'),
    },
    uploadFile: jest.fn().mockResolvedValue({ fileId: 'mock-file-id' }),
    deleteFile: jest.fn().mockResolvedValue(true),
    getFileUrl: jest.fn().mockReturnValue('http://mock-url'),
  }),
  { virtual: true },
);

