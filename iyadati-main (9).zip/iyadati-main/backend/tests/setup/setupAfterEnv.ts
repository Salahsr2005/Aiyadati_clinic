// backend/tests/setup/setupAfterEnv.ts
//
// Infrastructure is mocked via `setupFiles` (mockInfrastructure.ts).
// This file only handles per-test cleanup. No real connections are opened.

beforeEach(() => {
  jest.clearAllMocks();
});

afterEach(() => {
  // Do NOT call jest.restoreAllMocks() here — it would undo module-level mocks.
  // Suites that need restoration can call it locally.
});

afterAll(() => {
  // Nothing to close — every queue/redis/worker is a mock.
});


