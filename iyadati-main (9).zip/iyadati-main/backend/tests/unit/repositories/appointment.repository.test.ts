import { AppointmentRepository } from '../../../src/repositories/appointment.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    appointment: {
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
      update: jest.fn(),
    },
  },
}));

// ============================================================
// Per-method include shapes
//
// The repository is NOT uniform — it returns different include
// shapes depending on the read method, because each caller already
// has some of the relations in hand.
// ============================================================

// Base shape used by findById / findByPatientId
const BASE_INCLUDES = {
  slot: { include: { service: { include: { gallery: true } } } },
  doctor: true,
  patient: true,
  clinic: true,
  contactUser: true,
  guestPatient: true,
  service: { include: { gallery: true } },
};

// findByDoctorId does NOT include `doctor` (you already know the doctor)
const DOCTOR_LIST_INCLUDES = {
  slot: { include: { service: { include: { gallery: true } } } },
  patient: true,
  clinic: true,
  contactUser: true,
  guestPatient: true,
  service: { include: { gallery: true } },
};

// findByClinicId does NOT include `clinic` (you already know the clinic)
const CLINIC_LIST_INCLUDES = {
  slot: { include: { service: { include: { gallery: true } } } },
  doctor: true,
  patient: true,
  contactUser: true,
  guestPatient: true,
  service: { include: { gallery: true } },
};

// findAll does NOT include `contactUser` (admin listing doesn't need it)
const ADMIN_LIST_INCLUDES = {
  slot: { include: { service: { include: { gallery: true } } } },
  doctor: true,
  patient: true,
  clinic: true,
  guestPatient: true,
  service: { include: { gallery: true } },
};

describe('AppointmentRepository', () => {
  let repository: AppointmentRepository;

  const mockAppointment = {
    id: 'appointment-123',
    slotId: 'slot-123',
    doctorId: 'doctor-123',
    patientId: 'user-123',
    guestPatientId: null,
    patientType: 'REGISTERED',
    clinicId: null,
    serviceId: null,
    type: 'IN_PERSON',
    paymentMethod: 'CREDIT',
    status: 'PENDING',
    notes: 'Test notes',
    createdBy: 'user-123',
    createdByType: 'user',
    creditPriceAtBooking: 10,
    creditPriceId: 'price-123',
    confirmedAt: null,
    confirmedBy: null,
    cancelledAt: null,
    cancelledBy: null,
    cancelReason: null,
    idempotencyKey: null,
    createdAt: new Date('2026-08-20T10:00:00.000Z'),
    updatedAt: new Date('2026-08-20T10:00:00.000Z'),
  };

  beforeEach(() => {
    repository = new AppointmentRepository();
    jest.clearAllMocks();
  });

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find an appointment by id with all relations (including guestPatient and service)', async () => {
      const appointmentWithRelations = {
        ...mockAppointment,
        slot: {
          id: 'slot-123',
          service: { id: 'svc-1', gallery: [] },
        },
        doctor: { id: 'doctor-123' },
        patient: { id: 'user-123' },
        clinic: null,
        contactUser: null,
        guestPatient: null,
        service: { id: 'svc-1', gallery: [] },
      };

      (prisma.appointment.findUnique as jest.Mock).mockResolvedValue(
        appointmentWithRelations,
      );

      const result = await repository.findById('appointment-123');

      expect(prisma.appointment.findUnique).toHaveBeenCalledWith({
        where: { id: 'appointment-123' },
        include: BASE_INCLUDES,
      });

      expect(result).toEqual(appointmentWithRelations);
      expect(result?.id).toBe('appointment-123');
    });

    it('should return null when appointment does not exist', async () => {
      (prisma.appointment.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('non-existent-id');

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // findBySlotId
  // ============================================================

  describe('findBySlotId', () => {
    it('should find first appointment by slot id', async () => {
      (prisma.appointment.findFirst as jest.Mock).mockResolvedValue(
        mockAppointment,
      );

      const result = await repository.findBySlotId('slot-123');

      expect(prisma.appointment.findFirst).toHaveBeenCalledWith({
        where: { slotId: 'slot-123' },
        include: {
          slot: { include: { service: { include: { gallery: true } } } },
          service: { include: { gallery: true } },
        },
      });

      expect(result).toEqual(mockAppointment);
    });

    it('should return null when no appointment found for slot', async () => {
      (prisma.appointment.findFirst as jest.Mock).mockResolvedValue(null);

      const result = await repository.findBySlotId('slot-456');

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    const createData = {
      slotId: 'slot-123',
      doctorId: 'doctor-123',
      patientId: 'user-123',
      contactUserId: 'contact-123',
      clinicId: 'clinic-123',
      type: 'IN_PERSON',
      paymentMethod: 'CREDIT',
      notes: 'Test appointment',
      createdBy: 'user-123',
      createdByType: 'user',
    };

    it('should create an appointment with all data', async () => {
      const createdAppointment = { ...mockAppointment, ...createData };

      (prisma.appointment.create as jest.Mock).mockResolvedValue(
        createdAppointment,
      );

      const result = await repository.create(createData);

      expect(prisma.appointment.create).toHaveBeenCalledWith({
        data: createData,
      });

      expect(result).toEqual(createdAppointment);
    });

    it('should create an appointment with minimal data', async () => {
      const minimalData = {
        slotId: 'slot-123',
        doctorId: 'doctor-123',
        patientId: 'user-123',
        createdBy: 'user-123',
        createdByType: 'user',
      };

      (prisma.appointment.create as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        ...minimalData,
        contactUserId: null,
        clinicId: null,
        type: 'IN_PERSON',
        paymentMethod: 'CREDIT',
        notes: null,
      });

      const result = await repository.create(minimalData);

      expect(prisma.appointment.create).toHaveBeenCalledWith({
        data: minimalData,
      });

      expect(result.slotId).toBe('slot-123');
    });
  });

  // ============================================================
  // findByPatientId
  // ============================================================

  describe('findByPatientId', () => {
    const mockAppointments = [
      { ...mockAppointment, id: 'app-1' },
      { ...mockAppointment, id: 'app-2' },
    ];

    beforeEach(() => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue(
        mockAppointments,
      );
      (prisma.appointment.count as jest.Mock).mockResolvedValue(2);
    });

    it('should return appointments for a patient with pagination', async () => {
      const result = await repository.findByPatientId('user-123', 1, 10);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith({
        where: { patientId: 'user-123' },
        skip: 0,
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: BASE_INCLUDES,
      });

      expect(prisma.appointment.count).toHaveBeenCalledWith({
        where: { patientId: 'user-123' },
      });

      expect(result).toEqual({ appointments: mockAppointments, total: 2 });
    });

    it('should use default pagination values', async () => {
      await repository.findByPatientId('user-123');

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 0, take: 10 }),
      );
    });

    it('should calculate pagination correctly', async () => {
      await repository.findByPatientId('user-123', 3, 5);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 10, take: 5 }),
      );
    });

    it('should return empty array when no appointments', async () => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(0);

      const result = await repository.findByPatientId('user-456');

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // findByDoctorId
  // ============================================================

  describe('findByDoctorId', () => {
    const mockAppointments = [
      { ...mockAppointment, id: 'app-1' },
      { ...mockAppointment, id: 'app-2' },
    ];

    beforeEach(() => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue(
        mockAppointments,
      );
      (prisma.appointment.count as jest.Mock).mockResolvedValue(2);
    });

    it('should return appointments for a doctor with pagination', async () => {
      const result = await repository.findByDoctorId('doctor-123', 1, 10);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
        skip: 0,
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: DOCTOR_LIST_INCLUDES,
      });

      expect(prisma.appointment.count).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
      });

      expect(result).toEqual({ appointments: mockAppointments, total: 2 });
    });

    it('should filter by date when provided', async () => {
      await repository.findByDoctorId('doctor-123', 1, 10, '2026-08-20');

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            doctorId: 'doctor-123',
            slot: { date: new Date('2026-08-20') },
          },
        }),
      );

      expect(prisma.appointment.count).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          slot: { date: new Date('2026-08-20') },
        },
      });
    });

    it('should use default pagination values', async () => {
      await repository.findByDoctorId('doctor-123');

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 0, take: 10 }),
      );
    });

    it('should handle date filter with null/undefined date', async () => {
      await repository.findByDoctorId('doctor-123', 1, 10, undefined);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { doctorId: 'doctor-123' } }),
      );
    });

    it('should return empty array when no appointments', async () => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(0);

      const result = await repository.findByDoctorId('doctor-456');

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // findByClinicId
  // ============================================================

  describe('findByClinicId', () => {
    const mockAppointments = [
      { ...mockAppointment, id: 'app-1' },
      { ...mockAppointment, id: 'app-2' },
    ];

    beforeEach(() => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue(
        mockAppointments,
      );
      (prisma.appointment.count as jest.Mock).mockResolvedValue(2);
    });

    it('should return appointments for a clinic with pagination', async () => {
      const result = await repository.findByClinicId('clinic-123', 1, 10);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith({
        where: { clinicId: 'clinic-123' },
        skip: 0,
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: CLINIC_LIST_INCLUDES,
      });

      expect(result).toEqual({ appointments: mockAppointments, total: 2 });
    });

    it('should filter by date when provided', async () => {
      await repository.findByClinicId('clinic-123', 1, 10, '2026-08-20');

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            clinicId: 'clinic-123',
            slot: { date: new Date('2026-08-20') },
          },
        }),
      );
    });

    it('should use default pagination values', async () => {
      await repository.findByClinicId('clinic-123');

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 0, take: 10 }),
      );
    });

    it('should return empty array when no appointments', async () => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(0);

      const result = await repository.findByClinicId('clinic-456');

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // findAll
  // ============================================================

  describe('findAll', () => {
    const mockAppointments = [
      { ...mockAppointment, id: 'app-1' },
      { ...mockAppointment, id: 'app-2' },
      { ...mockAppointment, id: 'app-3' },
    ];

    beforeEach(() => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue(
        mockAppointments,
      );
      (prisma.appointment.count as jest.Mock).mockResolvedValue(3);
    });

    it('should return all appointments with default pagination', async () => {
      const result = await repository.findAll();

      expect(prisma.appointment.findMany).toHaveBeenCalledWith({
        where: {},
        skip: 0,
        take: 20,
        orderBy: { createdAt: 'desc' },
        include: ADMIN_LIST_INCLUDES,
      });

      expect(prisma.appointment.count).toHaveBeenCalledWith({ where: {} });

      expect(result).toEqual({ appointments: mockAppointments, total: 3 });
    });

    it('should filter by date', async () => {
      await repository.findAll(1, 20, { date: '2026-08-20' });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { slot: { date: new Date('2026-08-20') } },
        }),
      );
    });

    it('should filter by doctorId', async () => {
      await repository.findAll(1, 20, { doctorId: 'doctor-123' });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { doctorId: 'doctor-123' } }),
      );
    });

    it('should filter by clinicId', async () => {
      await repository.findAll(1, 20, { clinicId: 'clinic-123' });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { clinicId: 'clinic-123' } }),
      );
    });

    it('should filter by status', async () => {
      await repository.findAll(1, 20, { status: 'PENDING' });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { status: 'PENDING' } }),
      );
    });

    it('should filter by patientType (guest vs registered)', async () => {
      await repository.findAll(1, 20, { patientType: 'GUEST' });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { patientType: 'GUEST' } }),
      );
    });

    it('should apply multiple filters together', async () => {
      await repository.findAll(1, 20, {
        date: '2026-08-20',
        doctorId: 'doctor-123',
        clinicId: 'clinic-123',
        status: 'CONFIRMED',
        patientType: 'REGISTERED',
      });

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            doctorId: 'doctor-123',
            clinicId: 'clinic-123',
            status: 'CONFIRMED',
            patientType: 'REGISTERED',
            slot: { date: new Date('2026-08-20') },
          },
        }),
      );
    });

    it('should use custom pagination', async () => {
      await repository.findAll(2, 5);

      expect(prisma.appointment.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 5, take: 5 }),
      );
    });

    it('should handle empty result set', async () => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(0);

      const result = await repository.findAll(999, 10);

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // updateStatus
  // ============================================================

  describe('updateStatus', () => {
    it('should update appointment status', async () => {
      (prisma.appointment.update as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        status: 'CONFIRMED',
      });

      const result = await repository.updateStatus(
        'appointment-123',
        'CONFIRMED',
      );

      expect(prisma.appointment.update).toHaveBeenCalledWith({
        where: { id: 'appointment-123' },
        data: { status: 'CONFIRMED' },
      });

      expect(result.status).toBe('CONFIRMED');
    });

    it('should update status with extra data', async () => {
      const extraData = {
        confirmedAt: new Date('2026-08-20T10:05:00.000Z'),
        confirmedBy: 'doctor-123',
      };

      (prisma.appointment.update as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        status: 'CONFIRMED',
        ...extraData,
      });

      const result = await repository.updateStatus(
        'appointment-123',
        'CONFIRMED',
        extraData,
      );

      expect(prisma.appointment.update).toHaveBeenCalledWith({
        where: { id: 'appointment-123' },
        data: { status: 'CONFIRMED', ...extraData },
      });

      expect(result.confirmedBy).toBe('doctor-123');
    });

    it('should update to CANCELLED status with extra data', async () => {
      const extraData = {
        cancelledAt: new Date('2026-08-20T10:05:00.000Z'),
        cancelledBy: 'user-123',
        cancelReason: 'Patient request',
      };

      (prisma.appointment.update as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        status: 'CANCELLED',
        ...extraData,
      });

      const result = await repository.updateStatus(
        'appointment-123',
        'CANCELLED',
        extraData,
      );

      expect(result.status).toBe('CANCELLED');
      expect(result.cancelReason).toBe('Patient request');
    });

    it('should update to NO_SHOW status', async () => {
      (prisma.appointment.update as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        status: 'NO_SHOW',
      });

      const result = await repository.updateStatus(
        'appointment-123',
        'NO_SHOW',
      );

      expect(result.status).toBe('NO_SHOW');
    });

    it('should update to COMPLETED status', async () => {
      (prisma.appointment.update as jest.Mock).mockResolvedValue({
        ...mockAppointment,
        status: 'COMPLETED',
      });

      const result = await repository.updateStatus(
        'appointment-123',
        'COMPLETED',
      );

      expect(result.status).toBe('COMPLETED');
    });
  });

  // ============================================================
  // Edge cases
  // ============================================================

  describe('Edge Cases', () => {
    it('should handle findById with invalid id gracefully', async () => {
      (prisma.appointment.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('');

      expect(result).toBeNull();
    });

    it('should handle findBySlotId with invalid slot id', async () => {
      (prisma.appointment.findFirst as jest.Mock).mockResolvedValue(null);

      const result = await repository.findBySlotId('');

      expect(result).toBeNull();
    });

    it('should handle findAll with empty filters', async () => {
      (prisma.appointment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(0);

      const result = await repository.findAll(1, 20, {});

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });
});

