// backend/tests/unit/modules/appointment/v1/reminder.service.test.ts

import { ReminderService } from '../../../../../src/modules/appointment/v1/reminder.service';
import { reminderRepository } from '../../../../../src/repositories/reminder.repository';
import { prisma } from '../../../../../src/core/utils/prisma';
import { nowAlgeria } from '../../../../../src/core/utils/timezone';
import { logger } from '../../../../../src/core/utils/logger';

jest.mock('../../../../../src/repositories/reminder.repository');
jest.mock('../../../../../src/core/utils/prisma', () => ({
  prisma: {
    appointment: {
      findUnique: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));
jest.mock('../../../../../src/core/utils/timezone', () => ({
  nowAlgeria: jest.fn(),
  getSlotStartDateTimeAlgeria: jest.fn(),
  isSlotInPastAlgeria: jest.fn(),
}));
jest.mock('../../../../../src/core/utils/logger', () => ({
  logger: { info: jest.fn(), warn: jest.fn(), error: jest.fn(), debug: jest.fn() },
}));

const mockPrisma = prisma as any;

describe('ReminderService', () => {
  let service: ReminderService;

  const mockTx = {
    appointment: {
      findUnique: jest.fn(),
    },
  } as any;

  beforeEach(() => {
    service = new ReminderService();
    jest.clearAllMocks();

    (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));
  });

  // ============================================================
  // scheduleReminders
  // ============================================================

  describe('scheduleReminders', () => {
    const baseAppointment = {
      id: 'appointment-123',
      doctorId: 'doctor-123',
      patientId: 'user-123',
      patientType: 'REGISTERED',
      guestPatientId: null,
      doctor: { id: 'doctor-123', firstNameFr: 'Ahmed', lastNameFr: 'Benali' },
      patient: { id: 'user-123', firstName: 'John', lastName: 'Doe' },
      guestPatient: null,
    };

    it('should schedule 4 patient reminders + 2 doctor reminders when far in the future', async () => {
      mockTx.appointment.findUnique.mockResolvedValue(baseAppointment);
      (reminderRepository.createMany as jest.Mock).mockResolvedValue({ count: 6 });
      (reminderRepository.findPendingByAppointmentAndTypes as jest.Mock).mockResolvedValue([
        { id: 'r1', reminderType: '3_DAYS', scheduledAt: new Date() },
      ]);

      // Appointment 10 days in future so all reminders are future
      const appointmentAt = new Date('2026-08-29T10:00:00.000Z');

      await service.scheduleReminders('appointment-123', appointmentAt, mockTx);

      expect(reminderRepository.createMany).toHaveBeenCalledWith(
        expect.arrayContaining([
          // Patient reminders
          expect.objectContaining({ recipientType: 'PATIENT', reminderType: '3_DAYS' }),
          expect.objectContaining({ recipientType: 'PATIENT', reminderType: '1_DAY' }),
          expect.objectContaining({ recipientType: 'PATIENT', reminderType: '2_HOURS' }),
          expect.objectContaining({ recipientType: 'PATIENT', reminderType: '1_HOUR' }),
          // Doctor reminders
          expect.objectContaining({ recipientType: 'DOCTOR', reminderType: '1_DAY' }),
          expect.objectContaining({ recipientType: 'DOCTOR', reminderType: '1_HOUR' }),
        ]),
        mockTx,
      );
    });

    it('should NOT schedule patient reminders for GUEST patients', async () => {
      mockTx.appointment.findUnique.mockResolvedValue({
        ...baseAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
        patient: null,
      });
      (reminderRepository.createMany as jest.Mock).mockResolvedValue({ count: 2 });
      (reminderRepository.findPendingByAppointmentAndTypes as jest.Mock).mockResolvedValue([]);

      const appointmentAt = new Date('2026-08-29T10:00:00.000Z');

      await service.scheduleReminders('appointment-123', appointmentAt, mockTx);

      const [createdData] = (reminderRepository.createMany as jest.Mock).mock.calls[0];

      // All created reminders must be DOCTOR-only
      createdData.forEach((r: any) => {
        expect(r.recipientType).toBe('DOCTOR');
      });
    });

    it('should skip reminders that would be in the past', async () => {
      mockTx.appointment.findUnique.mockResolvedValue(baseAppointment);
      (reminderRepository.createMany as jest.Mock).mockResolvedValue({ count: 0 });
      (reminderRepository.findPendingByAppointmentAndTypes as jest.Mock).mockResolvedValue([]);

      // Appointment in 2 hours → only "1_HOUR" and "2_HOURS" reminders would exist,
      // but "3_DAYS" and "1_DAY" would be in the past → filtered out
      const appointmentAt = new Date('2026-08-19T12:00:00.000Z');
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));

      await service.scheduleReminders('appointment-123', appointmentAt, mockTx);

      const [createdData] = (reminderRepository.createMany as jest.Mock).mock.calls[0];

      createdData.forEach((r: any) => {
        expect(r.scheduledAt.getTime()).toBeGreaterThan(
          new Date('2026-08-19T10:00:00.000Z').getTime(),
        );
      });
    });

    it('should return empty when no reminders can be scheduled (too soon)', async () => {
      mockTx.appointment.findUnique.mockResolvedValue(baseAppointment);

      const appointmentAt = new Date('2026-08-19T10:30:00.000Z'); // 30 min away

      const result = await service.scheduleReminders('appointment-123', appointmentAt, mockTx);

      expect(result).toEqual([]);
      expect(reminderRepository.createMany).not.toHaveBeenCalled();
    });

    it('should throw when appointment not found in tx', async () => {
      mockTx.appointment.findUnique.mockResolvedValue(null);

      await expect(
        service.scheduleReminders('appointment-123', new Date(), mockTx),
      ).rejects.toThrow('Appointment appointment-123 not found');
    });
  });

  // ============================================================
  // cancelReminders
  // ============================================================

  describe('cancelReminders', () => {
    it('should cancel pending reminders and return IDs', async () => {
      (reminderRepository.findPendingByAppointmentId as jest.Mock).mockResolvedValue([
        { id: 'r1' },
        { id: 'r2' },
      ]);
      (reminderRepository.cancelByAppointmentId as jest.Mock).mockResolvedValue({ count: 2 });

      const result = await service.cancelReminders('appointment-123', mockTx);

      expect(result).toEqual(['r1', 'r2']);
      expect(reminderRepository.cancelByAppointmentId).toHaveBeenCalledWith(
        'appointment-123',
        mockTx,
      );
    });

    it('should return empty when no pending reminders', async () => {
      (reminderRepository.findPendingByAppointmentId as jest.Mock).mockResolvedValue([]);

      const result = await service.cancelReminders('appointment-123', mockTx);

      expect(result).toEqual([]);
      expect(reminderRepository.cancelByAppointmentId).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // cancelRemindersStandalone
  // ============================================================

  describe('cancelRemindersStandalone', () => {
    it('should wrap cancelReminders in a transaction', async () => {
      const innerTx = {} as any;
      mockPrisma.$transaction.mockImplementation((cb: any) => cb(innerTx));

      (reminderRepository.findPendingByAppointmentId as jest.Mock).mockResolvedValue([]);

      await service.cancelRemindersStandalone('appointment-123');

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });
  });

  // ============================================================
  // pass-through methods
  // ============================================================

  describe('pass-through repository methods', () => {
    it('getRemindersForAppointment calls repository', async () => {
      (reminderRepository.findByAppointmentId as jest.Mock).mockResolvedValue([]);

      await service.getRemindersForAppointment('appointment-123');

      expect(reminderRepository.findByAppointmentId).toHaveBeenCalledWith(
        'appointment-123',
      );
    });

    it('getRemindersByStatus calls repository with status and limit', async () => {
      (reminderRepository.findByStatus as jest.Mock).mockResolvedValue([]);

      await service.getRemindersByStatus('PENDING', 50);

      expect(reminderRepository.findByStatus).toHaveBeenCalledWith('PENDING', 50);
    });

    it('markReminderAsSent delegates', async () => {
      await service.markReminderAsSent('r1');
      expect(reminderRepository.markAsSent).toHaveBeenCalledWith('r1', undefined);
    });

    it('updateReminderWithError delegates', async () => {
      await service.updateReminderWithError('r1', 'boom');
      expect(reminderRepository.updateWithError).toHaveBeenCalledWith(
        'r1',
        'boom',
        undefined,
      );
    });

    it('markReminderAsFailed delegates', async () => {
      await service.markReminderAsFailed('r1', 'boom');
      expect(reminderRepository.markAsFailed).toHaveBeenCalledWith(
        'r1',
        'boom',
        undefined,
      );
    });

    it('markReminderAsCancelled delegates', async () => {
      await service.markReminderAsCancelled('r1');
      expect(reminderRepository.markAsCancelled).toHaveBeenCalledWith('r1', undefined);
    });
  });
});

