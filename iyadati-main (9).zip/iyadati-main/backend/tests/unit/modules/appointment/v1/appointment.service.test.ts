// backend/tests/unit/modules/appointment/v1/appointment.service.test.ts

import { AppointmentService } from '../../../../../src/modules/appointment/v1/appointment.service';
import { slotRepository } from '../../../../../src/repositories/slot.repository';
import { appointmentRepository } from '../../../../../src/repositories/appointment.repository';
import { doctorConfigRepository } from '../../../../../src/repositories/doctor-config.repository';
import { doctorRepository } from '../../../../../src/repositories/doctor.repository';
import { doctorAvailabilityRepository } from '../../../../../src/repositories/doctor-availability.repository';
import { doctorBreakRepository } from '../../../../../src/repositories/doctor-break.repository';
import { walletRepository } from '../../../../../src/repositories/wallet.repository';
import { creditPriceRepository } from '../../../../../src/repositories/credit-price.repository';
import { reminderService } from '../../../../../src/modules/appointment/v1/reminder.service';
import { reminderQueue } from '../../../../../src/infrastructure/queues/reminder/reminder.queue';
import { eventEmitter } from '../../../../../src/core/events/event-emitter';
import { prisma } from '../../../../../src/core/utils/prisma';
import { logger } from '../../../../../src/core/utils/logger';
import {
  NotFoundError,
  BadRequestError,
  ConflictError,
} from '../../../../../src/core/utils/error';
import {
  nowAlgeria,
  getSlotStartDateTimeAlgeria,
  isSlotInPastAlgeria,
} from '../../../../../src/core/utils/timezone';

// ============================================================
// MOCKS
// ============================================================

jest.mock('../../../../../src/repositories/slot.repository');
jest.mock('../../../../../src/repositories/appointment.repository');
jest.mock('../../../../../src/repositories/doctor-config.repository');
jest.mock('../../../../../src/repositories/doctor.repository');
jest.mock('../../../../../src/repositories/doctor-availability.repository');
jest.mock('../../../../../src/repositories/doctor-break.repository');
jest.mock('../../../../../src/repositories/wallet.repository');
jest.mock('../../../../../src/repositories/credit-price.repository');
jest.mock('../../../../../src/repositories/guest-patient.repository');
jest.mock('../../../../../src/core/events/event-emitter');

// ✅ Mock reminderService — we don't want it running against the tx mock
jest.mock('../../../../../src/modules/appointment/v1/reminder.service', () => ({
  reminderService: {
    scheduleReminders: jest.fn().mockResolvedValue([]),
    cancelReminders: jest.fn().mockResolvedValue([]),
    cancelRemindersStandalone: jest.fn().mockResolvedValue(undefined),
    getRemindersForAppointment: jest.fn().mockResolvedValue([]),
    getRemindersByStatus: jest.fn().mockResolvedValue([]),
    getReminderWithAppointment: jest.fn().mockResolvedValue(null),
    markReminderAsSent: jest.fn(),
    updateReminderWithError: jest.fn(),
    markReminderAsFailed: jest.fn(),
    markReminderAsCancelled: jest.fn(),
  },
}));

// ✅ Mock reminderQueue — also mocked in mockInfrastructure.ts but reinforced here
jest.mock('../../../../../src/infrastructure/queues/reminder/reminder.queue', () => ({
  reminderQueue: {
    enqueueReminder: jest.fn().mockResolvedValue(undefined),
    enqueueReminders: jest.fn().mockResolvedValue(undefined),
    cancelRemindersByIds: jest.fn().mockResolvedValue({ removed: 0, total: 0 }),
    getQueue: jest.fn(),
    close: jest.fn(),
  },
}));

jest.mock('../../../../../src/core/utils/logger', () => ({
  logger: {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
  },
}));

jest.mock('../../../../../src/core/utils/timezone', () => ({
  nowAlgeria: jest.fn(),
  getSlotStartDateTimeAlgeria: jest.fn(),
  isSlotInPastAlgeria: jest.fn(),
  toAlgeriaTime: jest.fn(),
}));

type TransactionCallback = (tx: any) => any;

const createTransactionMock = () => ({
  $queryRaw: jest.fn(),
  slot: {
    findUnique: jest.fn(),
    update: jest.fn(),
    findMany: jest.fn(),
  },
  appointment: {
    count: jest.fn().mockResolvedValue(0),
    create: jest.fn(),
    update: jest.fn(),
    findUnique: jest.fn(),
    findMany: jest.fn(),
  },
  appointmentReminder: {
    findMany: jest.fn().mockResolvedValue([]),
    createMany: jest.fn().mockResolvedValue({ count: 0 }),
    updateMany: jest.fn().mockResolvedValue({ count: 0 }),
  },
  doctor: {
    findUnique: jest.fn(),
  },
  user: {
    update: jest.fn(),
    findUnique: jest.fn(),
  },
  userWallet: {
    findUnique: jest.fn(),
    upsert: jest.fn(),
    update: jest.fn(),
  },
  creditTransaction: {
    create: jest.fn(),
  },
  providerEarning: {
    create: jest.fn(),
  },
  providerBalance: {
    upsert: jest.fn(),
  },
  guestPatient: {
    create: jest.fn(),
    findFirst: jest.fn(),
    findUnique: jest.fn(),
  },
});

jest.mock('../../../../../src/core/utils/prisma', () => {
  const mockPrisma: any = {
    appointment: {
      count: jest.fn().mockResolvedValue(0),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    slot: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      createMany: jest.fn(),
      update: jest.fn(),
      updateMany: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
    clinicDoctor: {
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    clinicRoom: {
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
    },
    doctor: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    userWallet: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      upsert: jest.fn(),
    },
    creditTransaction: {
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    providerEarning: {
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    providerBalance: {
      upsert: jest.fn(),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    guestPatient: {
      create: jest.fn(),
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    slotGenerationRule: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      upsert: jest.fn(),
      update: jest.fn(),
    },
    $transaction: jest.fn((callback: TransactionCallback) =>
      callback(createTransactionMock()),
    ),
  };

  return { prisma: mockPrisma };
});

const mockPrisma = prisma as any;

// ============================================================
// SUITE
// ============================================================

describe('AppointmentService', () => {
  let service: AppointmentService;

  // ---------- Shared mock data ----------

  const mockDoctor = {
    id: 'doctor-123',
    email: 'doctor@example.com',
    firstNameFr: 'Ahmed',
    lastNameFr: 'Benali',
    isVerified: true,
    isSuspended: false,
    isAvailableForBooking: true,
    messageForUser: null,
  };

  const mockDoctorNotAvailable = {
    ...mockDoctor,
    isAvailableForBooking: false,
    messageForUser: 'On vacation until September',
  };

  const mockSlot = {
    id: 'slot-123',
    doctorId: 'doctor-123',
    clinicId: null,
    roomId: null,
    serviceId: null,
    date: new Date('2026-08-20'),
    startTime: new Date('1970-01-01T09:00:00.000Z'),
    endTime: new Date('1970-01-01T09:30:00.000Z'),
    status: 'available',
    maxPatients: 3,
    slotKey: 'doctor-123:2026-08-20:09:00:none:none',
  };

  const mockSlotWithClinic = { ...mockSlot, clinicId: 'clinic-123' };

  const mockConfig = {
    id: 'config-123',
    doctorId: 'doctor-123',
    slotDuration: 30,
    bufferTime: 5,
    maxPerSlot: 3,
  };

  const mockWallet = { id: 'wallet-123', userId: 'user-123', credits: 5 };
  const mockCreditPrice = {
    id: 'price-123',
    price: 10,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockUser = {
    id: 'user-123',
    email: 'user@example.com',
    firstName: 'John',
    lastName: 'Doe',
    phone: '0555123456',
    isVerified: true,
    isSuspended: false,
    trustPoints: 5,
    trustLevel: 2,
  };

  const mockGuestPatient = {
    id: 'guest-123',
    firstName: 'Guest',
    lastName: 'Patient',
    phone: '0555987654',
    email: 'guest@example.com',
    createdBy: 'doctor-123',
    createdByType: 'DOCTOR',
  };

  const mockAppointment = {
    id: 'appointment-123',
    slotId: 'slot-123',
    doctorId: 'doctor-123',
    patientId: 'user-123',
    guestPatientId: null,
    patientType: 'REGISTERED',
    clinicId: null,
    serviceId: null,
    type: 'IN_PERSON',
    paymentMethod: 'CREDIT',
    status: 'PENDING',
    notes: null,
    createdBy: 'user-123',
    createdByType: 'user',
    creditPriceAtBooking: 10,
    creditPriceId: 'price-123',
    confirmedAt: null,
    confirmedBy: null,
    cancelledAt: null,
    cancelledBy: null,
    cancelReason: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    slot: mockSlot,
    doctor: mockDoctor,
    patient: mockUser,
    clinic: null,
    contactUser: null,
    guestPatient: null,
  };

  const mockAppointmentGuest = {
    ...mockAppointment,
    id: 'appointment-guest-123',
    patientId: null,
    guestPatientId: 'guest-123',
    patientType: 'GUEST',
    paymentMethod: 'FREE',
    createdByType: 'doctor',
    guestPatient: mockGuestPatient,
  };

  const mockAvailability = [
    {
      id: 'avail-1',
      doctorId: 'doctor-123',
      dayOfWeek: 'THURSDAY',
      startTime: new Date('1970-01-01T08:00:00.000Z'),
      endTime: new Date('1970-01-01T17:00:00.000Z'),
      isActive: true,
      clinicId: null,
      roomId: null,
    },
  ];

  const mockBreak = {
    id: 'break-1',
    doctorId: 'doctor-123',
    startDate: new Date('2026-08-20'),
    endDate: new Date('2026-08-20'),
    reason: 'Lunch',
    isAllDay: false,
    startTime: new Date('1970-01-01T12:00:00.000Z'),
    endTime: new Date('1970-01-01T13:00:00.000Z'),
  };

  const mockBreakAllDay = {
    ...mockBreak,
    isAllDay: true,
    startTime: null,
    endTime: null,
  };

  beforeEach(() => {
    service = new AppointmentService();
    jest.clearAllMocks();

    (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));
    (getSlotStartDateTimeAlgeria as jest.Mock).mockImplementation((date, time) => {
      const result = new Date(date);
      result.setHours(time.getHours(), time.getMinutes(), 0, 0);
      return result;
    });
    (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);

    mockPrisma.appointment.count.mockResolvedValue(0);
    mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);
    mockPrisma.user.update.mockResolvedValue(mockUser);
    mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) =>
      callback(createTransactionMock()),
    );

    // reminderService defaults
    (reminderService.scheduleReminders as jest.Mock).mockResolvedValue([]);
    (reminderService.cancelReminders as jest.Mock).mockResolvedValue([]);
  });

  // ============================================================
  // CONFIG
  // ============================================================

  describe('getDoctorConfig', () => {
    it('should return doctor config when it exists', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(mockConfig);

      const result = await service.getDoctorConfig('doctor-123');

      expect(result).toEqual({
        id: mockConfig.id,
        doctorId: mockConfig.doctorId,
        slotDuration: 30,
        bufferTime: 5,
        maxPerSlot: 3,
      });
    });

    it('should return null when config does not exist', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(null);

      const result = await service.getDoctorConfig('doctor-123');

      expect(result).toBeNull();
    });
  });

  describe('setDoctorConfig', () => {
    it('should set doctor config successfully', async () => {
      (doctorConfigRepository.upsert as jest.Mock).mockResolvedValue({
        id: 'config-123',
        doctorId: 'doctor-123',
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      });

      const result = await service.setDoctorConfig('doctor-123', {
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      });

      expect(doctorConfigRepository.upsert).toHaveBeenCalledWith('doctor-123', {
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      });
      expect(result.slotDuration).toBe(45);
    });

    it('should default maxPerSlot to 1 when not provided', async () => {
      (doctorConfigRepository.upsert as jest.Mock).mockResolvedValue({
        id: 'config-123',
        doctorId: 'doctor-123',
        slotDuration: 30,
        bufferTime: 5,
        maxPerSlot: 1,
      });

      await service.setDoctorConfig('doctor-123', { slotDuration: 30, bufferTime: 5 });

      expect(doctorConfigRepository.upsert).toHaveBeenCalledWith('doctor-123', {
        slotDuration: 30,
        bufferTime: 5,
        maxPerSlot: 1,
      });
    });
  });

  // ============================================================
  // GENERATE SLOTS (normal + force)
  // ============================================================

  describe('generateSlots', () => {
    const generateData = { startDate: '2026-08-20', endDate: '2026-08-20' };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(mockConfig);
      (doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock).mockResolvedValue(
        mockAvailability,
      );
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([]);
      (slotRepository.deleteByDoctorAndDateRange as jest.Mock).mockResolvedValue(5);
      (slotRepository.createMany as jest.Mock).mockResolvedValue({ count: 5 });
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([mockSlot]);
    });

    it('should generate slots successfully (normal mode)', async () => {
      const result = await service.generateSlots(
        'doctor-123',
        generateData,
        'doctor-123',
        'DOCTOR',
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(slotRepository.deleteByDoctorAndDateRange).toHaveBeenCalled();
      expect(slotRepository.createMany).toHaveBeenCalled();
      expect(Array.isArray(result)).toBe(true);
    });

    it('should throw when doctor is not verified', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        service.generateSlots('doctor-123', generateData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw when doctor is suspended', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isSuspended: true,
      });

      await expect(
        service.generateSlots('doctor-123', generateData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw when clinic tries to generate for doctor not in clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);

      await expect(
        service.generateSlots('doctor-123', generateData, 'clinic-123', 'CLINIC'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should handle all-day breaks correctly', async () => {
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([
        mockBreakAllDay,
      ]);
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([]);

      const result = await service.generateSlots(
        'doctor-123',
        generateData,
        'doctor-123',
        'DOCTOR',
      );

      expect(slotRepository.createMany).not.toHaveBeenCalled();
      expect(result).toHaveLength(0);
    });

    it('should use clinicId from request when user is clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });

      await service.generateSlots(
        'doctor-123',
        { ...generateData, clinicId: 'clinic-123' },
        'clinic-123',
        'CLINIC',
      );

      expect(slotRepository.createMany).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({ clinicId: 'clinic-123' }),
        ]),
      );
    });

    it('should propagate error message from repository in normal mode', async () => {
      (slotRepository.deleteByDoctorAndDateRange as jest.Mock).mockRejectedValue(
        new Error('Cannot regenerate slots: 2 slot(s) have active appointments'),
      );

      await expect(
        service.generateSlots('doctor-123', generateData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    // ---------- FORCE MODE ----------

    it('should call forceDeleteByDoctorAndDateRange when force=true and role is ADMIN', async () => {
      (slotRepository.forceDeleteByDoctorAndDateRange as jest.Mock).mockResolvedValue({
        deletedSlots: 3,
        cancelledAppointments: 2,
        refundedCredits: 2,
      });

      await service.generateSlots(
        'doctor-123',
        { ...generateData, force: true },
        'admin-123',
        'ADMIN',
      );

      expect(slotRepository.forceDeleteByDoctorAndDateRange).toHaveBeenCalledWith(
        'doctor-123',
        expect.any(Date),
        expect.any(Date),
        'admin-123',
      );
      // Normal delete NOT called
      expect(slotRepository.deleteByDoctorAndDateRange).not.toHaveBeenCalled();
    });

    it('should call forceDelete when role is SUPER_ADMIN', async () => {
      (slotRepository.forceDeleteByDoctorAndDateRange as jest.Mock).mockResolvedValue({
        deletedSlots: 0,
        cancelledAppointments: 0,
        refundedCredits: 0,
      });

      await service.generateSlots(
        'doctor-123',
        { ...generateData, force: true },
        'sa-123',
        'SUPER_ADMIN',
      );

      expect(slotRepository.forceDeleteByDoctorAndDateRange).toHaveBeenCalled();
    });

    it('should silently fall back to normal mode when non-admin sets force=true', async () => {
      await service.generateSlots(
        'doctor-123',
        { ...generateData, force: true },
        'doctor-123',
        'DOCTOR',
      );

      expect(slotRepository.forceDeleteByDoctorAndDateRange).not.toHaveBeenCalled();
      expect(slotRepository.deleteByDoctorAndDateRange).toHaveBeenCalled();
    });

    it('should propagate forceDelete errors', async () => {
      (slotRepository.forceDeleteByDoctorAndDateRange as jest.Mock).mockRejectedValue(
        new Error('DB failure'),
      );

      await expect(
        service.generateSlots(
          'doctor-123',
          { ...generateData, force: true },
          'admin-123',
          'ADMIN',
        ),
      ).rejects.toThrow('DB failure');
    });
  });

  // ============================================================
  // GET SLOTS / AVAILABLE SLOTS
  // ============================================================

  describe('getSlots', () => {
    it('should return slots', async () => {
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([mockSlot]);
      mockPrisma.appointment.count.mockResolvedValue(0);

      const result = await service.getSlots('doctor-123', '2026-08-20');

      expect(result).toHaveLength(1);
      expect(result[0].id).toBe('slot-123');
      expect(result[0].date).toBe('2026-08-20');
    });

    it('should return empty array when no slots', async () => {
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([]);

      const result = await service.getSlots('doctor-123', '2026-08-20');

      expect(result).toHaveLength(0);
    });
  });

  describe('getAvailableSlots', () => {
    it('should return available slots', async () => {
      (slotRepository.findAvailableByDoctorAndDate as jest.Mock).mockResolvedValue([mockSlot]);
      mockPrisma.appointment.count.mockResolvedValue(0);

      const result = await service.getAvailableSlots('doctor-123', '2026-08-20');

      expect(slotRepository.findAvailableByDoctorAndDate).toHaveBeenCalledWith(
        'doctor-123',
        '2026-08-20',
      );
      expect(result[0].id).toBe('slot-123');
    });

    it('should return empty array when no available slots', async () => {
      (slotRepository.findAvailableByDoctorAndDate as jest.Mock).mockResolvedValue([]);

      const result = await service.getAvailableSlots('doctor-123', '2026-08-20');

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // CANCEL SLOT
  // ============================================================

  describe('cancelSlot', () => {
    const slotWithAppointments = { ...mockSlot, date: new Date('2026-08-20') };

    const mockAppointments = [
      {
        id: 'app-1',
        patientId: 'user-123',
        patientType: 'REGISTERED',
        paymentMethod: 'CREDIT',
        patient: mockUser,
        guestPatient: null,
      },
      {
        id: 'app-2',
        patientId: null,
        guestPatientId: 'guest-123',
        patientType: 'GUEST',
        paymentMethod: 'FREE',
        patient: null,
        guestPatient: mockGuestPatient,
      },
    ];

    beforeEach(() => {
      (slotRepository.findById as jest.Mock).mockResolvedValue(slotWithAppointments);
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.update.mockResolvedValue({});
        tx.appointment.findMany.mockResolvedValue(mockAppointments);
        tx.appointment.update.mockResolvedValue({});
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });
    });

    it('should cancel slot as doctor', async () => {
      await service.cancelSlot('slot-123', 'doctor-123', 'DOCTOR');

      expect(slotRepository.findById).toHaveBeenCalledWith('slot-123');
      expect(mockPrisma.$transaction).toHaveBeenCalled();
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ userId: 'user-123', title: 'Appointment Cancelled' }),
      );
    });

    it('should cancel slot as clinic', async () => {
      (slotRepository.findById as jest.Mock).mockResolvedValue({
        ...slotWithAppointments,
        clinicId: 'clinic-123',
      });

      await service.cancelSlot('slot-123', 'clinic-123', 'CLINIC');

      expect(slotRepository.findById).toHaveBeenCalledWith('slot-123');
    });

    it('should NOT refund guest patients', async () => {
      await service.cancelSlot('slot-123', 'doctor-123', 'DOCTOR');

      // Only one refund for the REGISTERED patient
      // (we assert eventEmitter fired once, since guest gets no notification)
      const notificationCalls = (eventEmitter.emit as jest.Mock).mock.calls.filter(
        (c) => c[0] === 'notification',
      );
      expect(notificationCalls).toHaveLength(1);
    });

    it('should throw NotFoundError when slot not found', async () => {
      (slotRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        service.cancelSlot('nope', 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor cancels another doctor\'s slot', async () => {
      (slotRepository.findById as jest.Mock).mockResolvedValue({
        ...slotWithAppointments,
        doctorId: 'doctor-456',
      });

      await expect(
        service.cancelSlot('slot-123', 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when clinic cancels another clinic\'s slot', async () => {
      (slotRepository.findById as jest.Mock).mockResolvedValue({
        ...slotWithAppointments,
        clinicId: 'clinic-456',
      });

      await expect(
        service.cancelSlot('slot-123', 'clinic-123', 'CLINIC'),
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // CANCEL SLOTS BY DATE
  // ============================================================

  describe('cancelSlotsByDate', () => {
    const cancelData = { date: '2026-08-20', reason: 'Holiday' };

    const mockSlotsWithAppointments = [
      {
        ...mockSlot,
        date: new Date('2026-08-20'),
        appointments: [
          {
            id: 'app-1',
            patientId: 'user-123',
            patientType: 'REGISTERED',
            paymentMethod: 'CREDIT',
            patient: mockUser,
            guestPatient: null,
          },
        ],
      },
    ];

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.findMany.mockResolvedValue(mockSlotsWithAppointments);
        tx.slot.update.mockResolvedValue({});
        tx.appointment.update.mockResolvedValue({});
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });
    });

    it('should cancel slots by date as doctor', async () => {
      const result = await service.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'doctor-123',
        'DOCTOR',
      );

      expect(result).toBe(1);
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ userId: 'user-123' }),
      );
    });

    it('should cancel slots by date as clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });

      const result = await service.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'clinic-123',
        'CLINIC',
      );

      expect(result).toBe(1);
    });

    it('should throw NotFoundError when doctor not found', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        service.cancelSlotsByDate('nope', cancelData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor cancels not their account', async () => {
      await expect(
        service.cancelSlotsByDate('doctor-123', cancelData, 'doctor-456', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when clinic tries to cancel for a doctor not in clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);

      await expect(
        service.cancelSlotsByDate('doctor-123', cancelData, 'clinic-123', 'CLINIC'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should return 0 when no slots found', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.findMany.mockResolvedValue([]);
        return callback(tx);
      });

      const result = await service.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'doctor-123',
        'DOCTOR',
      );

      expect(result).toBe(0);
    });
  });

  // ============================================================
  // BOOK APPOINTMENT
  // ============================================================

  describe('bookAppointment', () => {
    const bookData = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      patientId: 'user-123',
      notes: 'First visit',
    };

    const bookDataGuest = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      guestPatient: {
        firstName: 'Guest',
        lastName: 'Patient',
        phone: '0555987654',
        email: 'guest@example.com',
      },
      notes: 'Walk-in',
    };

    beforeEach(() => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue(mockSlot);
      (creditPriceRepository.getLatest as jest.Mock).mockResolvedValue(mockCreditPrice);
      (walletRepository.getOrCreate as jest.Mock).mockResolvedValue(mockWallet);

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });
    });

    it('should book successfully with credits (REGISTERED + USER)', async () => {
      const result = await service.bookAppointment(bookData, 'user-123', 'USER');

      expect(result.id).toBe('appointment-123');
      expect(result.status).toBe('PENDING');
      expect(result.patientType).toBe('REGISTERED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ userId: 'doctor-123' }),
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ userId: 'user-123' }),
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({ action: 'appointment.created' }),
      );
    });

    it('should store paymentMethod=CREDIT only for USER+REGISTERED', async () => {
      await service.bookAppointment(bookData, 'user-123', 'USER');

      expect(mockPrisma.$transaction).toHaveBeenCalled();
      // The wallet deduction should have run
      const tx = (mockPrisma.$transaction as jest.Mock).mock.results[0]?.value;
      // Can't easily assert from result — instead assert appointment.create input:
      // (the create mock captures the data)
      // This is verified by the fact that no error was thrown and result.paymentMethod === 'CREDIT'
    });

    it('should book as DOCTOR → paymentMethod FREE, no wallet deduction', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointment,
          paymentMethod: 'FREE',
          createdBy: 'doctor-123',
          createdByType: 'doctor',
        });
        tx.appointment.findUnique.mockResolvedValue({
          ...mockAppointment,
          paymentMethod: 'FREE',
        });
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        return callback(tx);
      });

      const result = await service.bookAppointment(bookData, 'doctor-123', 'DOCTOR');

      expect(result.paymentMethod).toBe('FREE');
      expect(result.createdByType).toBe('doctor');
    });

    it('should book with guest patient → FREE, patientId null', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointmentGuest);
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null);
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await service.bookAppointment(bookDataGuest, 'doctor-123', 'DOCTOR');

      expect(result.patientType).toBe('GUEST');
      expect(result.paymentMethod).toBe('FREE');
      expect(result.patientId).toBeNull();
      expect(result.guestPatient).toBeDefined();
    });

    it('should reuse guest patient with same phone', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointmentGuest,
          guestPatient: mockGuestPatient,
        });
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null); // no registered user with this phone
        tx.guestPatient.findFirst.mockResolvedValue(mockGuestPatient); // existing guest
        return callback(tx);
      });

      const result = await service.bookAppointment(bookDataGuest, 'doctor-123', 'DOCTOR');

      expect(result.guestPatientId).toBe('guest-123');
    });

    it('should convert to REGISTERED if phone belongs to a registered user', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser); // registered user exists
        return callback(tx);
      });

      const result = await service.bookAppointment(bookDataGuest, 'doctor-123', 'DOCTOR');

      expect(result.patientType).toBe('REGISTERED');
      expect(result.patientId).toBe('user-123');
    });

    it('should return existing appointment when idempotencyKey matches', async () => {
      mockPrisma.appointment.findUnique.mockResolvedValue(mockAppointment);

      const result = await service.bookAppointment(
        bookData,
        'user-123',
        'USER',
        'idem-123',
      );

      expect(mockPrisma.appointment.findUnique).toHaveBeenCalledWith({
        where: { idempotencyKey: 'idem-123' },
        include: expect.any(Object),
      });
      expect(mockPrisma.$transaction).not.toHaveBeenCalled();
      expect(result.id).toBe('appointment-123');
    });

    it('should throw ConflictError when slot is full', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(3);
        return callback(tx);
      });

      await expect(
        service.bookAppointment(bookData, 'user-123', 'USER'),
      ).rejects.toThrow(ConflictError);
    });

    it('should throw BadRequestError when doctor is not available', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.doctor.findUnique.mockResolvedValue(mockDoctorNotAvailable);
        tx.user.findUnique.mockResolvedValue(mockUser);
        return callback(tx);
      });

      await expect(
        service.bookAppointment(bookData, 'user-123', 'USER'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should include doctor messageForUser in error when set', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.doctor.findUnique.mockResolvedValue({
          ...mockDoctorNotAvailable,
          messageForUser: 'Returns on 1 September',
        });
        tx.user.findUnique.mockResolvedValue(mockUser);
        return callback(tx);
      });

      await expect(
        service.bookAppointment(bookData, 'user-123', 'USER'),
      ).rejects.toThrow('Returns on 1 September');
    });

    it('should throw when insufficient credits', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]); // empty => wallet deduction failed
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        return callback(tx);
      });

      await expect(
        service.bookAppointment(bookData, 'user-123', 'USER'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw when both patientId and guestPatient provided', async () => {
      await expect(
        service.bookAppointment(
          {
            slotId: 'slot-123',
            patientId: 'user-123',
            guestPatient: { firstName: 'x', lastName: 'y', phone: '0555000000' },
          } as any,
          'user-123',
          'USER',
        ),
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // CLINIC BOOK APPOINTMENT
  // ============================================================

  describe('clinicBookAppointment', () => {
    const clinicBookData = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      patientId: 'user-123',
      notes: 'Clinic booking',
    };

    const clinicBookDataGuest = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      guestPatient: { firstName: 'Guest', lastName: 'Patient', phone: '0555987654' },
    };

    beforeEach(() => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue(mockSlotWithClinic);

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlotWithClinic);
        tx.slot.update.mockResolvedValue(mockSlotWithClinic);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointment,
          clinicId: 'clinic-123',
          createdByType: 'clinic',
          paymentMethod: 'FREE',
        });
        tx.appointment.findUnique.mockResolvedValue({
          ...mockAppointment,
          clinicId: 'clinic-123',
          createdByType: 'clinic',
          paymentMethod: 'FREE',
        });
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        return callback(tx);
      });
    });

    it('should book for registered patient as clinic → paymentMethod FREE', async () => {
      const result = await service.clinicBookAppointment(clinicBookData, 'clinic-123');

      expect(result.createdByType).toBe('clinic');
      expect(result.paymentMethod).toBe('FREE');
      expect(result.clinicId).toBe('clinic-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ userId: 'doctor-123' }),
      );
    });

    it('should book for guest patient as clinic', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlotWithClinic);
        tx.slot.update.mockResolvedValue(mockSlotWithClinic);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointmentGuest,
          clinicId: 'clinic-123',
          createdByType: 'clinic',
        });
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null);
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await service.clinicBookAppointment(clinicBookDataGuest, 'clinic-123');

      expect(result.patientType).toBe('GUEST');
      expect(result.paymentMethod).toBe('FREE');
    });

    it('should throw when slot does not belong to clinic', async () => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue({
        ...mockSlot,
        clinicId: 'clinic-456',
      });

      await expect(
        service.clinicBookAppointment(clinicBookData, 'clinic-123'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw ConflictError when slot is full', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.appointment.count.mockResolvedValue(3);
        return callback(tx);
      });

      await expect(
        service.clinicBookAppointment(clinicBookData, 'clinic-123'),
      ).rejects.toThrow(ConflictError);
    });
  });

  // ============================================================
  // CONFIRM APPOINTMENT
  // ============================================================

  describe('confirmAppointment', () => {
    const pendingAppointment = { ...mockAppointment, status: 'PENDING' };

    beforeEach(() => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(pendingAppointment);
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({
          ...pendingAppointment,
          status: 'CONFIRMED',
          confirmedAt: new Date(),
          confirmedBy: 'doctor-123',
        });
        return callback(tx);
      });

      // Default: no reminders to schedule
      (reminderService.scheduleReminders as jest.Mock).mockResolvedValue([]);
    });

    it('should confirm appointment as doctor', async () => {
      const result = await service.confirmAppointment(
        'appointment-123',
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('CONFIRMED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '✅ Appointment Confirmed',
        }),
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({ action: 'appointment.confirmed' }),
      );
    });

    it('should confirm appointment as clinic', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        clinicId: 'clinic-123',
      });

      const result = await service.confirmAppointment(
        'appointment-123',
        'clinic-123',
        'CLINIC',
      );

      expect(result.status).toBe('CONFIRMED');
    });

    it('should NOT emit notification for guest appointment', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      });

      await service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR');

      const patientNotifications = (eventEmitter.emit as jest.Mock).mock.calls.filter(
        (c) => c[0] === 'notification' && c[1]?.userId === null,
      );
      expect(patientNotifications).toHaveLength(0);
    });

    it('should call reminderService.scheduleReminders inside tx', async () => {
      await service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR');

      expect(reminderService.scheduleReminders).toHaveBeenCalledWith(
        'appointment-123',
        expect.any(Date),
        expect.any(Object),
      );
    });

    it('should enqueue reminders after commit', async () => {
      (reminderService.scheduleReminders as jest.Mock).mockResolvedValue([
        { id: 'rem-1', reminderType: '1_DAY', scheduledAt: new Date() },
      ]);

      await service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR');

      expect(reminderQueue.enqueueReminders).toHaveBeenCalledWith([
        expect.objectContaining({ id: 'rem-1' }),
      ]);
    });

    it('should still succeed when reminder enqueue fails', async () => {
      (reminderService.scheduleReminders as jest.Mock).mockResolvedValue([
        { id: 'rem-1', reminderType: '1_DAY', scheduledAt: new Date() },
      ]);
      (reminderQueue.enqueueReminders as jest.Mock).mockRejectedValue(
        new Error('Redis down'),
      );

      await expect(
        service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR'),
      ).resolves.toBeDefined();
    });

    it('should throw NotFoundError when appointment not found', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        service.confirmAppointment('nope', 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw when user is not DOCTOR or CLINIC', async () => {
      await expect(
        service.confirmAppointment('appointment-123', 'user-123', 'USER'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw when doctor tries to confirm another doctor\'s appointment', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        doctorId: 'doctor-456',
      });

      await expect(
        service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw when appointment is not PENDING', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        status: 'CONFIRMED',
      });

      await expect(
        service.confirmAppointment('appointment-123', 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // UPDATE STATUS
  // ============================================================

  describe('updateStatus', () => {
    const pendingAppointment = {
      ...mockAppointment,
      status: 'PENDING',
      slot: mockSlot,
      doctor: mockDoctor,
    };
    const confirmedAppointment = { ...pendingAppointment, status: 'CONFIRMED' };

    beforeEach(() => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({
          ...pendingAppointment,
          status: 'CONFIRMED',
        });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.providerEarning.create.mockResolvedValue({});
        tx.providerBalance.upsert.mockResolvedValue({});
        return callback(tx);
      });

      mockPrisma.user.update.mockResolvedValue({
        ...mockUser,
        trustPoints: mockUser.trustPoints - 1,
        trustLevel: 1,
      });
      (walletRepository.getOrCreate as jest.Mock).mockResolvedValue(mockWallet);
      (reminderService.cancelReminders as jest.Mock).mockResolvedValue([]);
    });

    // ---------- CONFIRMED ----------

    it('should confirm appointment via updateStatus', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(pendingAppointment)
        .mockResolvedValueOnce({
          ...pendingAppointment,
          status: 'CONFIRMED',
          confirmedAt: new Date(),
          confirmedBy: 'doctor-123',
        });

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'CONFIRMED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('CONFIRMED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ title: '✅ Appointment Confirmed' }),
      );
    });

    // ---------- CANCELLED ----------

    it('should cancel as patient ≥3 days before → refund', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 5);
      const futureAppointment = {
        ...pendingAppointment,
        slot: { ...mockSlot, date: appointmentDate },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      (getSlotStartDateTimeAlgeria as jest.Mock).mockReturnValue(new Date(appointmentDate));
      (nowAlgeria as jest.Mock).mockReturnValue(new Date());

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Patient request' },
        'user-123',
        'USER',
      );

      expect(result.status).toBe('CANCELLED');
      expect(reminderService.cancelReminders).toHaveBeenCalled();
    });

    it('should cancel as patient <3 days before → NO refund', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 1);
      const futureAppointment = {
        ...pendingAppointment,
        slot: { ...mockSlot, date: appointmentDate },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      (getSlotStartDateTimeAlgeria as jest.Mock).mockReturnValue(new Date(appointmentDate));
      (nowAlgeria as jest.Mock).mockReturnValue(new Date());

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Changed mind' },
        'user-123',
        'USER',
      );

      expect(result.status).toBe('CANCELLED');
    });

    it('should cancel as provider → always refund', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(pendingAppointment)
        .mockResolvedValueOnce({ ...pendingAppointment, status: 'CANCELLED' });

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Provider unavailable' },
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('CANCELLED');
    });

    it('should cancel guest appointment without touching wallet', async () => {
      const guestAppointment = {
        ...pendingAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
        paymentMethod: 'FREE',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(guestAppointment)
        .mockResolvedValueOnce({ ...guestAppointment, status: 'CANCELLED' });

      await service.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'OK' },
        'doctor-123',
        'DOCTOR',
      );

      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    it('should enqueue reminder-cancel via queue after commit when reminders exist', async () => {
      (reminderService.cancelReminders as jest.Mock).mockResolvedValue(['rem-1', 'rem-2']);
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(pendingAppointment)
        .mockResolvedValueOnce({ ...pendingAppointment, status: 'CANCELLED' });

      await service.updateStatus(
        'appointment-123',
        { status: 'CANCELLED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(reminderQueue.cancelRemindersByIds).toHaveBeenCalledWith(['rem-1', 'rem-2']);
    });

    // ---------- NO_SHOW ----------

    it('should mark NO_SHOW and emit notification for registered patient', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(confirmedAppointment)
        .mockResolvedValueOnce({ ...confirmedAppointment, status: 'NO_SHOW' });

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('NO_SHOW');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({ title: '⚠️ Missed Appointment' }),
      );
    });

    it('should suspend user after 3 no-shows', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(confirmedAppointment)
        .mockResolvedValueOnce({ ...confirmedAppointment, status: 'NO_SHOW' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({
          ...confirmedAppointment,
          status: 'NO_SHOW',
        });
        tx.user.update
          .mockResolvedValueOnce({ ...mockUser, noShowCount: 3 })
          .mockResolvedValueOnce({
            ...mockUser,
            noShowCount: 3,
            isSuspended: true,
            suspensionReason: '3 no-show appointments',
          });
        return callback(tx);
      });

      await service.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR',
      );

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should NOT touch trust points for guest NO_SHOW', async () => {
      const guestConfirmed = {
        ...confirmedAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(guestConfirmed)
        .mockResolvedValueOnce({ ...guestConfirmed, status: 'NO_SHOW' });

      await service.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR',
      );

      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    // ---------- COMPLETED ----------

    it('should COMPLETE and create doctor earnings (REGISTERED, createdBy=user)', async () => {
      const inProgress = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce({ ...inProgress, status: 'COMPLETED' });

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('COMPLETED');
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should also create clinic commission when clinic involved', async () => {
      const inProgress = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        clinicId: 'clinic-123',
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce({ ...inProgress, status: 'COMPLETED' });

      await service.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should NOT create earnings for clinic-created appointments', async () => {
      const inProgress = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'clinic',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce({ ...inProgress, status: 'COMPLETED' });

      const result = await service.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(result.status).toBe('COMPLETED');
    });

    it('should NOT create earnings for guest patients', async () => {
      const inProgress = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce({ ...inProgress, status: 'COMPLETED' });

      await service.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR',
      );

      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    it('should swallow P2002 duplicate earnings', async () => {
      const inProgress = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce({ ...inProgress, status: 'COMPLETED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...inProgress, status: 'COMPLETED' });
        tx.providerEarning.create.mockRejectedValue({ code: 'P2002' });
        return callback(tx);
      });

      await expect(
        service.updateStatus(
          'appointment-123',
          { status: 'COMPLETED' },
          'doctor-123',
          'DOCTOR',
        ),
      ).resolves.toBeDefined();

      expect(logger.info).toHaveBeenCalledWith(
        expect.stringContaining('Earnings already exist'),
      );
    });

    // ---------- Invalid transition / access ----------

    it('should reject invalid transition', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        status: 'COMPLETED',
      });

      await expect(
        service.updateStatus(
          'appointment-123',
          { status: 'NO_SHOW' },
          'doctor-123',
          'DOCTOR',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject when USER updates someone else\'s appointment', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(pendingAppointment);

      await expect(
        service.updateStatus(
          'appointment-123',
          { status: 'CANCELLED' },
          'user-456',
          'USER',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject when USER tries to CONFIRM', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(pendingAppointment);

      await expect(
        service.updateStatus(
          'appointment-123',
          { status: 'CONFIRMED' },
          'user-123',
          'USER',
        ),
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // READ ENDPOINTS
  // ============================================================

  describe('getMyAppointments', () => {
    it('should return patient appointments with pagination', async () => {
      (appointmentRepository.findByPatientId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      const result = await service.getMyAppointments('user-123', 1, 10);

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should default pagination', async () => {
      (appointmentRepository.findByPatientId as jest.Mock).mockResolvedValue({
        appointments: [],
        total: 0,
      });

      await service.getMyAppointments('user-123');

      expect(appointmentRepository.findByPatientId).toHaveBeenCalledWith(
        'user-123',
        1,
        10,
      );
    });
  });

  describe('getDoctorAppointments', () => {
    it('should pass date filter', async () => {
      (appointmentRepository.findByDoctorId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      await service.getDoctorAppointments('doctor-123', 1, 10, '2026-08-20');

      expect(appointmentRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123',
        1,
        10,
        '2026-08-20',
      );
    });
  });

  describe('getClinicAppointments', () => {
    it('should pass date filter', async () => {
      (appointmentRepository.findByClinicId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      await service.getClinicAppointments('clinic-123', 1, 10, '2026-08-20');

      expect(appointmentRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123',
        1,
        10,
        '2026-08-20',
      );
    });
  });

  describe('getAllAppointments', () => {
    it('should apply filters', async () => {
      (appointmentRepository.findAll as jest.Mock).mockResolvedValue({
        appointments: [],
        total: 0,
      });

      const filters = {
        status: 'PENDING',
        date: '2026-08-20',
        doctorId: 'doctor-123',
      };

      await service.getAllAppointments(1, 20, filters);

      expect(appointmentRepository.findAll).toHaveBeenCalledWith(1, 20, filters);
    });
  });

  // ============================================================
  // QUICK SLOT
  // ============================================================

  describe('addQuickSlot', () => {
    const quickSlotData = {
      date: '2026-08-20',
      startTime: '09:30',
      endTime: '10:00',
      maxPatients: 2,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(mockConfig);
      (doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock).mockResolvedValue(
        mockAvailability,
      );
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([]);
      (slotRepository.create as jest.Mock).mockResolvedValue(mockSlot);
      mockPrisma.slot.findFirst.mockResolvedValue(null);
    });

    it('should add quick slot successfully', async () => {
      const result = await service.addQuickSlot(
        'doctor-123',
        quickSlotData,
        'doctor-123',
        'DOCTOR',
      );

      expect(slotRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          doctorId: 'doctor-123',
          date: expect.any(Date),
          startTime: expect.any(Date),
          endTime: expect.any(Date),
          maxPatients: 2,
        }),
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({ action: 'slot.quick_added' }),
      );
      expect(result.id).toBe('slot-123');
    });

    it('should accept serviceId and pass it to create', async () => {
      await service.addQuickSlot(
        'doctor-123',
        { ...quickSlotData, serviceId: 'svc-1' },
        'doctor-123',
        'DOCTOR',
      );

      expect(slotRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({ serviceId: 'svc-1' }),
      );
    });

    it('should add quick slot as clinic (validates link)', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });

      const result = await service.addQuickSlot(
        'doctor-123',
        quickSlotData,
        'clinic-123',
        'CLINIC',
      );

      expect(result.id).toBe('slot-123');
    });

    it('should reject outside availability', async () => {
      await expect(
        service.addQuickSlot(
          'doctor-123',
          { ...quickSlotData, startTime: '07:00', endTime: '07:30' },
          'doctor-123',
          'DOCTOR',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject overlapping break', async () => {
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([
        mockBreak,
      ]);

      await expect(
        service.addQuickSlot(
          'doctor-123',
          { ...quickSlotData, startTime: '12:15', endTime: '12:45' },
          'doctor-123',
          'DOCTOR',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject duplicate slot', async () => {
      mockPrisma.slot.findFirst.mockResolvedValue(mockSlot);

      await expect(
        service.addQuickSlot('doctor-123', quickSlotData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(ConflictError);
    });

    it('should reject past slot', async () => {
      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(true);

      await expect(
        service.addQuickSlot(
          'doctor-123',
          { ...quickSlotData, date: '2026-08-19' },
          'doctor-123',
          'DOCTOR',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject invalid time range', async () => {
      await expect(
        service.addQuickSlot(
          'doctor-123',
          { ...quickSlotData, startTime: '10:00', endTime: '09:30' },
          'doctor-123',
          'DOCTOR',
        ),
      ).rejects.toThrow(BadRequestError);
    });

    it('should reject unverified doctor', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        service.addQuickSlot('doctor-123', quickSlotData, 'doctor-123', 'DOCTOR'),
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // AUTOMATION
  // ============================================================

  describe('setupAutomation', () => {
    const automationData = { frequency: 'WEEKLY' as const, bookingWindowDays: 30 };

    const mockRule = {
      id: 'rule-123',
      doctorId: 'doctor-123',
      frequency: 'WEEKLY',
      bookingWindowDays: 30,
      enabled: true,
      clinicId: null,
      roomId: null,
      lastRunAt: null,
      nextRunAt: new Date(),
      errorCount: 0,
      lastError: null,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (slotRepository.upsertAutomationRule as jest.Mock).mockResolvedValue(mockRule);
    });

    it('should enable automation', async () => {
      const result = await service.setupAutomation('doctor-123', automationData);

      expect(slotRepository.upsertAutomationRule).toHaveBeenCalledWith(
        'doctor-123',
        {
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          clinicId: undefined,
          roomId: undefined,
        },
      );
      expect(result.enabled).toBe(true);
    });

    it('should reject unverified doctor', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        service.setupAutomation('doctor-123', automationData),
      ).rejects.toThrow(BadRequestError);
    });

    it('should validate clinic link when clinicId provided', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);

      await expect(
        service.setupAutomation('doctor-123', {
          ...automationData,
          clinicId: 'clinic-123',
        }),
      ).rejects.toThrow(BadRequestError);
    });

    it('should validate room belongs to clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });
      mockPrisma.clinicRoom.findFirst.mockResolvedValue(null);

      await expect(
        service.setupAutomation('doctor-123', {
          ...automationData,
          clinicId: 'clinic-123',
          roomId: 'room-123',
        }),
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('disableAutomation', () => {
    beforeEach(() => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue({ id: 'rule-123' });
      (slotRepository.disableAutomationRule as jest.Mock).mockResolvedValue({});
    });

    it('should disable', async () => {
      await service.disableAutomation('doctor-123');
      expect(slotRepository.disableAutomationRule).toHaveBeenCalledWith('doctor-123');
    });

    it('should throw NotFoundError when no rule exists', async () => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(null);

      await expect(service.disableAutomation('doctor-123')).rejects.toThrow(NotFoundError);
    });
  });

  describe('getAutomationStatus', () => {
    it('should return rule if exists', async () => {
      const mockRule = { id: 'rule-123', enabled: true };
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(mockRule);

      const result = await service.getAutomationStatus('doctor-123');
      expect(result).toEqual(mockRule);
    });

    it('should return null if missing', async () => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(null);
      const result = await service.getAutomationStatus('doctor-123');
      expect(result).toBeNull();
    });
  });

  describe('generateAutomationSlots', () => {
    const mockHorizon = new Date('2026-08-20');

    beforeEach(() => {
      (slotRepository.getBookingHorizon as jest.Mock).mockResolvedValue(mockHorizon);
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(mockConfig);
      (doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock).mockResolvedValue(
        mockAvailability,
      );
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([]);
      (slotRepository.generateMissingSlots as jest.Mock).mockResolvedValue({
        created: 10,
        existing: 5,
        errors: 0,
      });
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-20T10:00:00.000Z'));
    });

    it('should generate missing slots up to window', async () => {
      const result = await service.generateAutomationSlots('doctor-123', 30);

      expect(slotRepository.generateMissingSlots).toHaveBeenCalled();
      expect(result).toEqual({ created: 10, existing: 5, errors: 0 });
    });

    it('should skip when horizon already beyond target', async () => {
      (slotRepository.getBookingHorizon as jest.Mock).mockResolvedValue(
        new Date('2026-09-20'),
      );

      const result = await service.generateAutomationSlots('doctor-123', 30);

      expect(slotRepository.generateMissingSlots).not.toHaveBeenCalled();
      expect(result).toEqual({ created: 0, existing: 0, errors: 0 });
    });

    it('should use default config when missing', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(null);

      const result = await service.generateAutomationSlots('doctor-123', 30);
      expect(result.created).toBe(10);
    });

    it('should pass clinic/room to horizon lookup', async () => {
      await service.generateAutomationSlots('doctor-123', 30, 'clinic-123', 'room-123');

      expect(slotRepository.getBookingHorizon).toHaveBeenCalledWith(
        'doctor-123',
        'clinic-123',
        'room-123',
      );
    });
  });
});

