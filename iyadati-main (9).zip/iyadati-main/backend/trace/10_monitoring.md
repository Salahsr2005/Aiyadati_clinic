http://localhost:3975/admin/queues

Alertmanager: http://localhost:9093 — no login, shows active/silenced alerts.

Prometheus: http://localhost:9090 — no login. Use the "Alerts" tab to see rule states, "Graph" to run ad-hoc queries.

Grafana: http://localhost:3001 — login is admin / change_this_password (from your compose.yml's GF_SECURITY_ADMIN_USER/GF_SECURITY_ADMIN_PASSWORD).










































Prometheus — http://localhost:9090

Prometheus is the raw data collector and rule engine. It doesn't try to look nice — it's a working tool, not a report.

Alerts tab — the most useful page for you right now. Shows every alert rule you've defined (IYADITIAPIDown, IyadatiHighLatency, IyadatiServerErrors, the host ones) grouped by file, with a live state per rule: green/inactive, yellow/pending, red/firing. This is what you've been checking via curl .../api/v1/rules — same data, just visual.
Targets tab (under Status → Targets) — every scrape job Prometheus knows about (iyadati-api, node-exporter, and later postgres, pgbouncer, seaweedfs) with up/down health, last scrape time, last error. This is your first stop whenever something isn't showing data — if a target is down here, nothing downstream (alerts, Grafana panels) will work either.
Graph tab — a query box where you type a metric name or PromQL expression and get a table or a plotted line. E.g. typing up shows every target's current up/down state; rate(http_requests_total[5m]) shows request rate over time. This is where you'd poke around to sanity-check a metric before writing an alert rule around it.
Rules tab (Status → Rules) — the raw rule definitions and their evaluation stats (how long each one takes to evaluate, any errors — this is where that "health":"err" from the clock-skew incident would have shown up visually instead of via curl).

You will not find pretty dashboards here — no historical trend charts with nice colors, no combining multiple metrics into one view. That's Grafana's job.

Alertmanager — http://localhost:9093

Alertmanager only cares about alerts that are currently firing or recently fired — it's not a general metrics browser at all.

Main page — a list of currently active alerts (what you were checking with curl .../api/v2/alerts), grouped the way your group_by config groups them. Each shows labels, annotations, and how long it's been firing.
Silences tab — lets you manually mute an alert for a set time window (e.g. "I know the DB will be down for maintenance for the next hour, don't page me"). Useful once you're doing planned maintenance.
Status tab — shows the actual loaded config (your alertmanager.yml as Alertmanager currently sees it) and cluster/peer info if you ever run more than one Alertmanager instance.

There's no history here beyond "currently firing / recently resolved" — once an alert resolves and its retention window passes, it's gone from this UI. If you want a permanent history of "the API went down at 3am for 4 minutes last Tuesday," that lives in Prometheus's time-series data (queryable via Graph), not in Alertmanager.

Grafana — http://localhost:3001

Grafana is the only one of the three built for humans to actually look at over time. It doesn't collect anything itself — it queries Prometheus and draws what it finds.

Dashboards — collections of panels (graphs, gauges, tables) built from PromQL queries. Right now you have zero dashboards; Grafana is a blank slate until you either build one or import one. There are ready-made community dashboards for exactly your stack — e.g. the standard "Node Exporter Full" dashboard (ID 1860) would immediately give you CPU/RAM/disk graphs once node-exporter is scraping, without you writing a single query.
Explore — a single ad-hoc query view, similar to Prometheus's Graph tab but with better time controls and the ability to quickly overlay a couple of queries. Good for investigating "what did latency look like around 2pm yesterday" without committing to a permanent panel.
Alerting (Grafana has its own alerting engine, separate from Prometheus/Alertmanager) — you're not using this; your alerts live in Prometheus's alerts.yml and route through Alertmanager. Worth knowing it exists so you don't accidentally configure the same alert twice in two places.
Data sources (Connections → Data sources) — where you point Grafana at Prometheus (http://prometheus:9090). One-time setup.










