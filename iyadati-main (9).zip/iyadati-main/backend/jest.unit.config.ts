import type { Config } from 'jest';

const config: Config = {
  displayName: 'unit',
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '.',

  testMatch: ['<rootDir>/tests/unit/**/*.test.ts'],

  // ✅ Loaded BEFORE the test framework — mocks Redis/BullMQ at module resolution time
  setupFiles: ['<rootDir>/tests/setup/mockInfrastructure.ts'],

  setupFilesAfterEnv: ['<rootDir>/tests/setup/setupAfterEnv.ts'],

  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },

  transform: {
    '^.+\\.tsx?$': [
      'ts-jest',
      { tsconfig: '<rootDir>/tsconfig.test.json' },
    ],
  },

  maxWorkers: '50%',
  testTimeout: 30000,
  verbose: true,
};

export default config;

