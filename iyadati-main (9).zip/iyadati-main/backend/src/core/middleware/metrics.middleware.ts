import { Request, Response, NextFunction } from 'express';
import {
  httpRequestsTotal,
  httpRequestDuration,
} from '../../infrastructure/monitoring/prometheus';

export function metricsMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  // Skip /metrics endpoint to avoid self-scraping feedback loop
  if (req.path === '/metrics') {
    return next();
  }

  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const duration =
      Number(process.hrtime.bigint() - start) / 1_000_000_000;

    const route = req.route?.path
      ? `${req.baseUrl}${req.route.path}`
      : 'unknown';

    const labels = {
      method: req.method,
      route,
      status_code: String(res.statusCode),
    };

    httpRequestsTotal.inc(labels);
    httpRequestDuration.observe(labels, duration);
  });

  next();
}


