import { Router } from 'express';
import { UserController } from './user.controller';
import {
  validateSuspendUser,
  validateUserFilters,
  validateCreateContactUser,
  validateUpdateContactUser,
  validateCreateUserDocument,
  validateUpdateUserDocument,
  validateRequestDeletion,
} from './user.validation';

import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import { uploadUserDocument } from '../../../core/middleware/upload.middleware';
import { checkDeletionStatus } from '../../../core/middleware/deletionCheck.middleware';

const router = Router();
const userController = new UserController();

// ============================================================
// ⚠️ DELETION MANAGEMENT ROUTES - MUST COME FIRST
// ============================================================
//
// These routes:
// - REQUIRE authentication
// - REQUIRE USER role
// - DO NOT use checkDeletionStatus
//
// This is intentional: a user with a pending deletion must
// still be able to check their status or cancel the deletion.
//

router.post(
  '/me/delete/request',
  authenticate,
  authorize('USER'),
  validateRequestDeletion,
  userController.requestDeletion
);

router.post(
  '/me/delete/cancel',
  authenticate,
  authorize('USER'),
  userController.cancelDeletion
);

router.get(
  '/me/delete/status',
  authenticate,
  authorize('USER'),
  userController.getDeletionStatus
);


// ============================================================
// 🔒 USER SELF-SERVICE ROUTES
// ============================================================
//
// Every route inside this router:
// 1. Must be authenticated
// 2. Must have USER role
// 3. Must NOT have a pending deletion
//
// IMPORTANT:
// We use a separate router so this USER-only middleware does
// not affect the staff/admin routes below.
//

const selfServiceRouter = Router();

selfServiceRouter.use(authenticate);
selfServiceRouter.use(authorize('USER'));
selfServiceRouter.use(checkDeletionStatus);


// ============================================================
// Contacts
// ============================================================

selfServiceRouter.get(
  '/me/contacts',
  userController.getMyContacts
);

selfServiceRouter.post(
  '/me/contacts',
  validateCreateContactUser,
  userController.createContact
);

selfServiceRouter.patch(
  '/me/contacts/:id',
  validateUpdateContactUser,
  userController.updateContact
);

selfServiceRouter.delete(
  '/me/contacts/:id',
  userController.deleteContact
);


// ============================================================
// Medical Documents
// ============================================================

selfServiceRouter.get(
  '/me/documents',
  userController.getMyDocuments
);

selfServiceRouter.post(
  '/me/documents',
  uploadUserDocument,
  validateCreateUserDocument,
  userController.uploadDocument
);

selfServiceRouter.patch(
  '/me/documents/:id',
  validateUpdateUserDocument,
  userController.updateDocument
);

selfServiceRouter.delete(
  '/me/documents/:id',
  userController.deleteDocument
);


// Register all self-service routes
router.use(selfServiceRouter);


// ============================================================
// 👨‍⚕️ STAFF ROUTES
// ============================================================
//
// These routes are NOT affected by checkDeletionStatus.
//
// Each route has its own authentication + authorization.
//
// Allowed roles:
// - SUPER_ADMIN
// - ADMIN
// - DOCTOR
// - CLINIC
//
// Suspension/unsuspension is restricted further to:
// - SUPER_ADMIN
// - ADMIN
// ============================================================


// ------------------------------------------------------------
// Get all users
// ------------------------------------------------------------

router.get(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  validateUserFilters,
  userController.getUsers
);


// ------------------------------------------------------------
// Get user by ID
// ------------------------------------------------------------

router.get(
  '/id/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  userController.getUserById
);


// ------------------------------------------------------------
// Get user by email
// ------------------------------------------------------------

router.get(
  '/email/:email',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  userController.getUserByEmail
);


// ------------------------------------------------------------
// Get user by phone
// ------------------------------------------------------------

router.get(
  '/phone/:phone',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  userController.getUserByPhone
);


// ============================================================
// 🔨 USER SUSPENSION
// ============================================================

// Suspend user
router.post(
  '/:id/suspend',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({
    windowMinutes: 15,
    maxRequests: 20,
    message: 'Too many suspension requests',
  }),
  validateSuspendUser,
  userController.suspendUser
);


// Unsuspend user
router.post(
  '/:id/unsuspend',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({
    windowMinutes: 15,
    maxRequests: 20,
    message: 'Too many unsuspension requests',
  }),
  userController.unsuspendUser
);


export default router;

