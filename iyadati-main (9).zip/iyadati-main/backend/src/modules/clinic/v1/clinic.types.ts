export interface ClinicResponse {
  id: string;
  nameFr: string;
  nameAr: string;
  descriptionAr: string | null;
  descriptionFr: string | null;
  wilayaId: string;
  wilaya?: { id: string; code: number; name: string };
  baladyaId: string | null;
  baladya?: { id: string; name: string } | null;
  latitude: number | null;
  longitude: number | null;
  phone: string;
  email: string;
  logoPath: string | null;
  logoUrl: string | null;
  facilityType: string;
  isVerified: boolean;
  isSuspended: boolean;
  isCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateClinicDTO {
  nameFr: string;
  nameAr: string;
  email: string;
  phone: string;
  password: string;
  wilayaId: string;
  baladyaId?: string;
  facilityType?: 'CLINIC' | 'HOSPITAL';
  descriptionAr?: string;
  descriptionFr?: string;
  latitude?: number;
  longitude?: number;
}

export interface ClinicDocumentResponse {
  id: string;
  clinicId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  accessUrl: string; // ✅ Now uses fileId-based URL
  createdAt: string;
}

export interface SuspendClinicDTO {
  reason: string;
}

export interface UpdateClinicDTO {
  nameFr?: string;
  nameAr?: string;
  descriptionAr?: string;
  descriptionFr?: string;
  phone?: string;
  email?: string;
  wilayaId?: string;
  baladyaId?: string;
  latitude?: number;
  longitude?: number;
  facilityType?: 'CLINIC' | 'HOSPITAL';
}

export interface CompleteClinicDTO {
  descriptionAr?: string;
  descriptionFr?: string;
  baladyaId?: string;
  latitude?: number;
  longitude?: number;
}

export interface WorkingHoursDTO {
  dayOfWeek: 'SUNDAY' | 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
  openTime: string;  // HH:mm
  closeTime: string; // HH:mm
  isOpen: boolean;
}

export interface WorkingHoursResponse {
  id: string;
  clinicId: string;
  dayOfWeek: string;
  openTime: string;
  closeTime: string;
  isOpen: boolean;
}

export interface CreateRoomDTO {
  name: string;
  specialtyId?: string;
}

export interface UpdateRoomDTO {
  name?: string;
  specialtyId?: string | null;
}

export interface RoomResponse {
  id: string;
  clinicId: string;
  name: string;
  specialtyId: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface InviteDoctorDTO {
  doctorId: string;
}

export interface ClinicDoctorResponse {
  id: string;
  clinicId: string;
  doctorId: string;
  status: string;
  invitedBy: string;
  isActive: boolean;
  joinedAt: string;
  doctor?: {
    id: string;
    email: string;
    firstNameFr: string;
    firstNameAr: string;
    lastNameFr: string;
    lastNameAr: string;
    phone: string;
    photoUrl: string | null;
    specialties: { id: string; nameFr: string; nameAr: string }[];
    yearsOfExp: number | null;
    isVerified: boolean;
    isSuspended: boolean;
    isCompleted: boolean;
    rejectionReason: string | null;
    verificationStatus: DoctorVerificationStatus;
  };
  clinic?: {
    id: string;
    nameFr: string;
    nameAr: string;
    email: string;
    phone: string;
    logoUrl: string | null;
  };
}

export interface GalleryImageResponse {
  id: string;
  clinicId: string;
  imagePath: string;
  imageUrl: string; // ✅ Now uses fileId-based public URL
  captionFr: string | null;
  captionAr: string | null;
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
}

export interface UpdateGalleryImageDTO {
  captionFr?: string;
  captionAr?: string;
  sortOrder?: number;
}



// ============================================================
// CLINIC-CREATED DOCTOR (pending admin verification)
// ============================================================

export type DoctorVerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

export interface CreateClinicDoctorDTO {
  // Required basic info
  email: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;

  // Required specialties (min 1)
  specialtyIds: string[] | string;

  // Optional profile details
  bioFr?: string;
  bioAr?: string;
  yearsOfExp?: number;
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  latitude?: number;
  longitude?: number;
  baladyaId?: string;
}

export interface ClinicCreatedDoctorResponse {
  id: string;
  email: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
  baladyaId: string | null;
  photoUrl: string | null;
  photoFileId: string | null;
  yearsOfExp: number | null;
  practiceType: string;
  specialties: { id: string; nameFr: string; nameAr: string }[];

  // Status
  isVerified: boolean;
  isSuspended: boolean;
  isCompleted: boolean;
  rejectionReason: string | null;

  // Derived convenience field for the clinic UI
  verificationStatus: DoctorVerificationStatus;

  // Relationship
  clinicId: string;
  clinicLinkId: string;
  linkStatus: string;

  // Meta
  message: string;
  createdAt: string;
  updatedAt: string;
}

