import { clinicRepository } from '../../../repositories/clinic.repository';
import { clinicDocumentRepository } from '../../../repositories/clinic-document.repository';
import { clinicGalleryRepository } from '../../../repositories/clinic-gallery.repository';
import { NotFoundError, ConflictError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { generateSignedUrl, generatePublicUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { ClinicResponse, CreateClinicDTO, ClinicDocumentResponse, UpdateClinicDTO, SuspendClinicDTO, CompleteClinicDTO, InviteDoctorDTO, ClinicDoctorResponse, GalleryImageResponse, UpdateGalleryImageDTO } from './clinic.types';
import { clinicWorkingHoursRepository } from '../../../repositories/clinic-working-hours.repository';
import { clinicRoomRepository } from '../../../repositories/clinic-room.repository';
import { env } from '../../../config/env';
import { clinicDoctorRepository } from '../../../repositories/clinic-doctor.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { fileService } from '../../../modules/file/v1/file.service';
import { StorageFactory } from '../../../core/storage/storage.factory';
import { passwordSetupTokenRepository } from '../../../repositories/password-setup-token.repository';
import { CreateClinicDoctorDTO, ClinicCreatedDoctorResponse, DoctorVerificationStatus } from './clinic.types';
import { doctorLogoRepository } from '../../../repositories/doctor-logo.repository';
import crypto from 'crypto';

import bcrypt from 'bcryptjs';

import {
  WorkingHoursDTO,
  WorkingHoursResponse,
  CreateRoomDTO,
  UpdateRoomDTO,
  RoomResponse,
} from './clinic.types';

export class ClinicService {
  private toResponse(clinic: any): ClinicResponse {
    return {
      id: clinic.id,
      nameFr: clinic.nameFr,
      nameAr: clinic.nameAr,
      descriptionAr: clinic.descriptionAr,
      descriptionFr: clinic.descriptionFr,
      wilayaId: clinic.wilayaId,
      wilaya: clinic.wilaya ? { id: clinic.wilaya.id, code: clinic.wilaya.code, name: clinic.wilaya.name } : undefined,
      baladyaId: clinic.baladyaId,
      baladya: clinic.baladya ? { id: clinic.baladya.id, name: clinic.baladya.name } : null,
      latitude: clinic.latitude,
      longitude: clinic.longitude,
      phone: clinic.phone,
      email: clinic.email,
      logoPath: clinic.logoPath,
      logoUrl: clinic.logoFileId
        ? generatePublicUrl(clinic.logoFileId)
        : clinic.logoPath
          ? `${env.BASE_URL}/uploads/${clinic.logoPath}`
          : null,
      facilityType: clinic.facilityType,
      isVerified: clinic.isVerified,
      isSuspended: clinic.isSuspended,
      isCompleted: clinic.isCompleted,
      createdAt: clinic.createdAt.toISOString(),
      updatedAt: clinic.updatedAt.toISOString(),
    };
  }

  private deriveVerificationStatus(doctor: {
    isVerified: boolean;
    rejectionReason: string | null;
  }): DoctorVerificationStatus {
    if (doctor.isVerified) return 'VERIFIED';
    if (doctor.rejectionReason) return 'REJECTED';
    return 'PENDING';
  }

  private toCreatedDoctorResponse(
    doctor: any,
    link: any,
  ): ClinicCreatedDoctorResponse {
    const latestLogo = doctor.logos?.[0] ?? null;
    return {
      id: doctor.id,
      email: doctor.email,
      firstNameFr: doctor.firstNameFr,
      firstNameAr: doctor.firstNameAr,
      lastNameFr: doctor.lastNameFr,
      lastNameAr: doctor.lastNameAr,
      phone: doctor.phone,
      wilayaId: doctor.wilayaId,
      baladyaId: doctor.baladyaId,
      photoUrl: doctor.photoFileId
        ? generatePublicUrl(doctor.photoFileId)
        : latestLogo?.fileId
          ? generatePublicUrl(latestLogo.fileId)
          : null,
      photoFileId: doctor.photoFileId ?? latestLogo?.fileId ?? null,
      yearsOfExp: doctor.yearsOfExp,
      practiceType: doctor.practiceType,
      specialties: doctor.specialties?.map((s: any) => ({
        id: s.specialty.id,
        nameFr: s.specialty.nameFr,
        nameAr: s.specialty.nameAr,
      })) ?? [],
      isVerified: doctor.isVerified,
      isSuspended: doctor.isSuspended,
      isCompleted: doctor.isCompleted,
      rejectionReason: doctor.rejectionReason,
      verificationStatus: this.deriveVerificationStatus(doctor),
      clinicId: link.clinicId,
      clinicLinkId: link.id,
      linkStatus: link.status,
      message:
        'Doctor created and linked to your clinic. Awaiting admin verification before the doctor can log in.',
      createdAt: doctor.createdAt.toISOString(),
      updatedAt: doctor.updatedAt.toISOString(),
    };
  }

  /**
   * Shared shape for clinic↔doctor link responses.
   * Used by inviteDoctor, respondToDoctorRequest, and getClinicDoctors
   * so the frontend always gets the same structure.
   */
  private toClinicDoctorResponse(link: any): ClinicDoctorResponse {
    return {
      id: link.id,
      clinicId: link.clinicId,
      doctorId: link.doctorId,
      status: link.status,
      invitedBy: link.invitedBy,
      isActive: link.isActive,
      joinedAt: link.joinedAt.toISOString(),
      doctor: link.doctor
        ? {
            id: link.doctor.id,
            email: link.doctor.email,
            firstNameFr: link.doctor.firstNameFr,
            firstNameAr: link.doctor.firstNameAr,
            lastNameFr: link.doctor.lastNameFr,
            lastNameAr: link.doctor.lastNameAr,
            phone: link.doctor.phone,
            photoUrl: link.doctor.photoFileId
              ? generatePublicUrl(link.doctor.photoFileId)
              : link.doctor.photoPath
                ? `${env.BASE_URL}/uploads/${link.doctor.photoPath}`
                : null,
            specialties:
              link.doctor.specialties?.map((s: any) => ({
                id: s.specialty.id,
                nameFr: s.specialty.nameFr,
                nameAr: s.specialty.nameAr,
              })) || [],
            yearsOfExp: link.doctor.yearsOfExp,
            isVerified: link.doctor.isVerified,
            isSuspended: link.doctor.isSuspended,
            isCompleted: link.doctor.isCompleted,
            rejectionReason: link.doctor.rejectionReason,
            verificationStatus: this.deriveVerificationStatus(link.doctor),
          }
        : undefined,
      clinic: link.clinic
        ? {
            id: link.clinic.id,
            nameFr: link.clinic.nameFr,
            nameAr: link.clinic.nameAr,
            email: link.clinic.email,
            phone: link.clinic.phone,
            logoUrl: link.clinic.logoFileId
              ? generatePublicUrl(link.clinic.logoFileId)
              : link.clinic.logoPath
                ? `${env.BASE_URL}/uploads/${link.clinic.logoPath}`
                : null,
          }
        : undefined,
    };
  }

  // === Clinic CRUD (Staff) ===

  async findAll(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      wilayaId: params.wilayaId || undefined,
      baladyaId: params.baladyaId || undefined,
      facilityType: params.facilityType || undefined,
      isVerified: params.isVerified !== undefined ? params.isVerified === 'true' : undefined,
      isSuspended: params.isSuspended !== undefined ? params.isSuspended === 'true' : undefined,
      isCompleted: params.isCompleted !== undefined ? params.isCompleted === 'true' : undefined,
      search: params.search || undefined,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };

    const { clinics, total } = await clinicRepository.findAll(parsedParams);
    return {
      clinics: clinics.map((c: any) => this.toResponse(c)),
      total,
    };
  }

  async create(data: CreateClinicDTO, performedBy: string, ip?: string): Promise<ClinicResponse> {
    const emailExists = await clinicRepository.emailExists(data.email);
    if (emailExists) throw new ConflictError('Email already in use');

    const phoneExists = await clinicRepository.phoneExists(data.phone);
    if (phoneExists) throw new ConflictError('Phone already in use');

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const clinic = await clinicRepository.create({
      nameFr: data.nameFr,
      nameAr: data.nameAr,
      email: data.email,
      phone: data.phone,
      password: hashedPassword,
      wilaya: { connect: { id: data.wilayaId } },
      baladya: data.baladyaId ? { connect: { id: data.baladyaId } } : undefined,
      facilityType: data.facilityType || 'HOSPITAL',
      descriptionAr: data.descriptionAr,
      descriptionFr: data.descriptionFr,
      latitude: data.latitude,
      longitude: data.longitude,
      isVerified: true,
    });

    eventEmitter.emit('audit', {
      action: 'clinic.created',
      entity: 'Clinic',
      entityId: clinic.id,
      performedBy,
      details: { clinic },
      ip,
    });

    eventEmitter.emit('notification', {
      userId: clinic.id,
      title: 'Welcome to Iyadati!',
      body: 'Your clinic has been created by an administrator. You can now log in and complete your profile.',
      type: 'system',
      data: { type: 'welcome' },
    });

    logger.info(`Clinic created: ${clinic.nameFr} by ${performedBy}`);

    return this.toResponse(clinic);
  }

  async findById(id: string): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');
    return this.toResponse(clinic);
  }

  async update(id: string, data: UpdateClinicDTO, performedBy: string, ip?: string): Promise<ClinicResponse> {
    const existing = await clinicRepository.findById(id);
    if (!existing) throw new NotFoundError('Clinic');

    if (data.email && data.email !== existing.email) {
      const emailExists = await clinicRepository.emailExists(data.email, id);
      if (emailExists) throw new ConflictError('Email already in use');
    }

    if (data.phone && data.phone !== existing.phone) {
      const phoneExists = await clinicRepository.phoneExists(data.phone, id);
      if (phoneExists) throw new ConflictError('Phone already in use');
    }

    const updateData: any = {};
    if (data.nameFr !== undefined) updateData.nameFr = data.nameFr;
    if (data.nameAr !== undefined) updateData.nameAr = data.nameAr;
    if (data.descriptionAr !== undefined) updateData.descriptionAr = data.descriptionAr;
    if (data.descriptionFr !== undefined) updateData.descriptionFr = data.descriptionFr;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.facilityType !== undefined) updateData.facilityType = data.facilityType;
    if (data.wilayaId) updateData.wilaya = { connect: { id: data.wilayaId } };
    if (data.baladyaId !== undefined) {
      updateData.baladya = data.baladyaId ? { connect: { id: data.baladyaId } } : { disconnect: true };
    }
    if (data.latitude !== undefined) updateData.latitude = data.latitude;
    if (data.longitude !== undefined) updateData.longitude = data.longitude;

    const clinic = await clinicRepository.update(id, updateData);

    eventEmitter.emit('audit', { action: 'clinic.updated', entity: 'Clinic', entityId: id, performedBy, details: { changes: data }, ip });

    return this.toResponse(clinic);
  }

  // === Verification (Staff) ===

  async verify(id: string, performedBy: string, ip?: string): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');
    if (clinic.isVerified) throw new BadRequestError('Clinic is already verified');

    const updated = await clinicRepository.verify(id);

    eventEmitter.emit('audit', { action: 'clinic.verified', entity: 'Clinic', entityId: id, performedBy, ip });

    logger.info(`Clinic verified: ${clinic.nameFr} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Clinic Verified!',
      body: 'Your clinic has been verified. You can now complete your profile and start operating.',
      type: 'system',
      data: { type: 'account_verified' },
    });

    return this.toResponse(updated);
  }

  // === Suspend/Unsuspend (Staff) ===

  async suspend(id: string, data: SuspendClinicDTO, performedBy: string, ip?: string): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');
    if (clinic.isSuspended) throw new BadRequestError('Clinic is already suspended');

    const updated = await clinicRepository.suspend(id);

    eventEmitter.emit('audit', { action: 'clinic.suspended', entity: 'Clinic', entityId: id, performedBy, details: { reason: data.reason }, ip });

    logger.info(`Clinic suspended: ${clinic.nameFr} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Clinic Suspended',
      body: `Your clinic has been suspended. Reason: ${data.reason}. Please contact support for more information.`,
      type: 'system',
      data: { type: 'account_suspended' },
    });

    return this.toResponse(updated);
  }

  async unsuspend(id: string, performedBy: string, ip?: string): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');
    if (!clinic.isSuspended) throw new BadRequestError('Clinic is not suspended');

    const updated = await clinicRepository.unsuspend(id);

    eventEmitter.emit('audit', { action: 'clinic.unsuspended', entity: 'Clinic', entityId: id, performedBy, ip });

    logger.info(`Clinic unsuspended: ${clinic.nameFr} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Clinic Reinstated',
      body: 'Your clinic has been unsuspended. Welcome back!',
      type: 'system',
      data: { type: 'account_unsuspended' },
    });

    return this.toResponse(updated);
  }

  // ============================================================
  // LOGO
  // ============================================================

  async uploadLogo(id: string, file: Express.Multer.File): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'public/logos',
        isPublic: true,
        contentType: file.mimetype,
        cacheControl: 'public, max-age=31536000',
        metadata: {
          clinicId: id,
          originalName: file.originalname,
        },
      }
    );

    const updated = await clinicRepository.updateLogo(id, uploadResult.key, uploadResult.id);
    return this.toResponse(updated);
  }

  // ============================================================
  // DOCUMENTS
  // ============================================================

  async getDocuments(clinicId: string): Promise<ClinicDocumentResponse[]> {
    const docs = await clinicDocumentRepository.findByClinicId(clinicId);
    return docs.map((d: any) => ({
      id: d.id,
      clinicId: d.clinicId,
      fileName: d.fileName,
      fileType: d.fileType,
      fileSize: d.fileSize,
      accessUrl: generateSignedUrl(d.fileId),
      createdAt: d.createdAt.toISOString(),
    }));
  }

  async uploadDocument(clinicId: string, file: Express.Multer.File, uploadedBy: string): Promise<ClinicDocumentResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'private/clinic-documents',
        isPublic: false,
        contentType: file.mimetype,
        metadata: {
          clinicId,
          originalName: file.originalname,
        },
      }
    );

    const doc = await clinicDocumentRepository.create({
      clinicId,
      fileName: file.originalname,
      filePath: uploadResult.key,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: uploadResult.key,
      uploadedBy,
      storageType: 'private',
      category: 'document',
      docType: 'other',
    });

    return {
      id: doc.id,
      clinicId: doc.clinicId,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      accessUrl: generateSignedUrl(doc.fileId),
      createdAt: doc.createdAt.toISOString(),
    };
  }

  async deleteDocument(clinicId: string, documentId: string, performedBy: string, ip?: string): Promise<void> {
    const doc = await clinicDocumentRepository.findById(documentId);
    if (!doc) throw new NotFoundError('Document');
    if (doc.clinicId !== clinicId) throw new BadRequestError('Document does not belong to this clinic');

    await fileService.deleteFile(doc.fileId, performedBy, 'ADMIN', false);

    eventEmitter.emit('audit', {
      action: 'clinic.document_deleted_by_staff',
      entity: 'Clinic',
      entityId: clinicId,
      performedBy,
      details: { documentId, fileName: doc.fileName },
      ip,
    });

    logger.info(`Staff ${performedBy} deleted document for clinic ${clinicId}`);
  }

  async deleteMyDocument(clinicId: string, documentId: string): Promise<void> {
    const doc = await clinicDocumentRepository.findById(documentId);
    if (!doc) throw new NotFoundError('Document');
    if (doc.clinicId !== clinicId) throw new BadRequestError('Document does not belong to this clinic');

    await fileService.deleteFile(doc.fileId, clinicId, 'CLINIC', false);
  }

  // ============================================================
  // GALLERY
  // ============================================================

  async getGallery(clinicId: string): Promise<GalleryImageResponse[]> {
    const images = await clinicGalleryRepository.findByClinicId(clinicId);
    return images.map((img: any) => ({
      id: img.id,
      clinicId: img.clinicId,
      imagePath: img.imagePath,
      imageUrl: generatePublicUrl(img.fileId),
      captionFr: img.captionFr,
      captionAr: img.captionAr,
      sortOrder: img.sortOrder,
      isActive: img.isActive,
      createdAt: img.createdAt.toISOString(),
    }));
  }

  async uploadGalleryImage(
    clinicId: string,
    file: Express.Multer.File,
    captionFr?: string,
    captionAr?: string
  ): Promise<GalleryImageResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'public/gallery',
        isPublic: true,
        contentType: file.mimetype,
        cacheControl: 'public, max-age=31536000',
        metadata: {
          clinicId,
          originalName: file.originalname,
        },
      }
    );

    const maxOrder = await clinicGalleryRepository.getMaxSortOrder(clinicId);

    const img = await clinicGalleryRepository.create({
      clinicId,
      imagePath: uploadResult.key,
      filePath: uploadResult.key,
      fileName: file.originalname,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: uploadResult.key,
      captionFr,
      captionAr,
      sortOrder: maxOrder + 1,
    });

    return {
      id: img.id,
      clinicId: img.clinicId,
      imagePath: img.imagePath,
      imageUrl: generatePublicUrl(img.fileId),
      captionFr: img.captionFr,
      captionAr: img.captionAr,
      sortOrder: img.sortOrder,
      isActive: img.isActive,
      createdAt: img.createdAt.toISOString(),
    };
  }

  async updateGalleryImage(
    imageId: string,
    clinicId: string,
    data: UpdateGalleryImageDTO,
  ): Promise<GalleryImageResponse> {
    const img = await clinicGalleryRepository.findById(imageId);
    if (!img) throw new NotFoundError('Gallery image not found');
    if (img.clinicId !== clinicId) throw new ForbiddenError('Gallery image does not belong to your clinic');

    const updated = await clinicGalleryRepository.update(imageId, data);

    return {
      id: updated.id,
      clinicId: updated.clinicId,
      imagePath: updated.imagePath,
      imageUrl: generatePublicUrl(updated.fileId),
      captionFr: updated.captionFr,
      captionAr: updated.captionAr,
      sortOrder: updated.sortOrder,
      isActive: updated.isActive,
      createdAt: updated.createdAt.toISOString(),
    };
  }

  async deleteGalleryImage(imageId: string, clinicId: string): Promise<void> {
    const img = await clinicGalleryRepository.findById(imageId);
    if (!img) throw new NotFoundError('Gallery image not found');
    if (img.clinicId !== clinicId) throw new ForbiddenError('Gallery image does not belong to your clinic');

    await fileService.deleteFile(img.fileId, clinicId, 'CLINIC', true);
    await clinicGalleryRepository.softDelete(imageId);
  }

  // ============================================================
  // COMPLETE PROFILE
  // ============================================================

  async completeProfile(id: string, data: CompleteClinicDTO, file?: Express.Multer.File): Promise<ClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic) throw new NotFoundError('Clinic');
    if (!clinic.isVerified) throw new BadRequestError('Clinic must be verified before completing profile');
    if (clinic.isCompleted) throw new BadRequestError('Clinic profile is already completed');

    const updateData: any = { isCompleted: true };

    if (data.descriptionAr !== undefined) updateData.descriptionAr = data.descriptionAr;
    if (data.descriptionFr !== undefined) updateData.descriptionFr = data.descriptionFr;

    if (data.latitude !== undefined) {
      updateData.latitude = typeof data.latitude === 'string'
        ? parseFloat(data.latitude)
        : data.latitude;
    }
    if (data.longitude !== undefined) {
      updateData.longitude = typeof data.longitude === 'string'
        ? parseFloat(data.longitude)
        : data.longitude;
    }

    if (file) {
      const storage = StorageFactory.getInstance();

      const uploadResult = await storage.upload(
        {
          buffer: file.buffer,
          originalName: file.originalname,
          mimeType: file.mimetype,
          size: file.size,
        },
        {
          path: 'public/logos',
          isPublic: true,
          contentType: file.mimetype,
          cacheControl: 'public, max-age=31536000',
          metadata: {
            clinicId: id,
            originalName: file.originalname,
          },
        }
      );

      updateData.logoPath = uploadResult.key;
      updateData.logoFileId = uploadResult.id;
    }

    if (data.baladyaId) updateData.baladya = { connect: { id: data.baladyaId } };

    const updated = await clinicRepository.update(id, updateData);

    logger.info(`Clinic profile completed: ${updated.nameFr}`);

    return this.toResponse(updated);
  }

  // ============================================================
  // WORKING HOURS
  // ============================================================

  async setWorkingHours(clinicId: string, hours: WorkingHoursDTO[]): Promise<WorkingHoursResponse[]> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const results = await Promise.all(
      hours.map(h => {
        const [openHour, openMin] = h.openTime.split(':').map(Number);
        const [closeHour, closeMin] = h.closeTime.split(':').map(Number);

        const openTime = new Date();
        openTime.setHours(openHour, openMin, 0, 0);

        const closeTime = new Date();
        closeTime.setHours(closeHour, closeMin, 0, 0);

        return clinicWorkingHoursRepository.upsert(clinicId, h.dayOfWeek, {
          openTime,
          closeTime,
          isOpen: h.isOpen,
        });
      })
    );

    return results.map(r => ({
      id: r.id,
      clinicId: r.clinicId,
      dayOfWeek: r.dayOfWeek,
      openTime: r.openTime.toISOString().slice(11, 16),
      closeTime: r.closeTime.toISOString().slice(11, 16),
      isOpen: r.isOpen,
    }));
  }

  async getWorkingHours(clinicId: string): Promise<WorkingHoursResponse[]> {
    const hours = await clinicWorkingHoursRepository.findByClinicId(clinicId);
    return hours.map(h => ({
      id: h.id,
      clinicId: h.clinicId,
      dayOfWeek: h.dayOfWeek,
      openTime: h.openTime.toISOString().slice(11, 16),
      closeTime: h.closeTime.toISOString().slice(11, 16),
      isOpen: h.isOpen,
    }));
  }

  // ============================================================
  // ROOMS
  // ============================================================

  async createRoom(clinicId: string, data: CreateRoomDTO): Promise<RoomResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const room = await clinicRoomRepository.create({
      clinicId,
      name: data.name,
      specialtyId: data.specialtyId,
    });

    return {
      id: room.id,
      clinicId: room.clinicId,
      name: room.name,
      specialtyId: room.specialtyId,
      isActive: room.isActive,
      createdAt: room.createdAt.toISOString(),
      updatedAt: room.updatedAt.toISOString(),
    };
  }

  async getRooms(clinicId: string): Promise<RoomResponse[]> {
    const rooms = await clinicRoomRepository.findByClinicId(clinicId);
    return rooms.map(r => ({
      id: r.id,
      clinicId: r.clinicId,
      name: r.name,
      specialtyId: r.specialtyId,
      isActive: r.isActive,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
    }));
  }

  async updateRoom(roomId: string, clinicId: string, data: UpdateRoomDTO): Promise<RoomResponse> {
    const room = await clinicRoomRepository.findById(roomId);
    if (!room) throw new NotFoundError('Room');
    if (room.clinicId !== clinicId) throw new ForbiddenError('Room does not belong to your clinic');

    const updated = await clinicRoomRepository.update(roomId, data);
    return {
      id: updated.id,
      clinicId: updated.clinicId,
      name: updated.name,
      specialtyId: updated.specialtyId,
      isActive: updated.isActive,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    };
  }

  async deleteRoom(roomId: string, clinicId: string): Promise<void> {
    const room = await clinicRoomRepository.findById(roomId);
    if (!room) throw new NotFoundError('Room');
    if (room.clinicId !== clinicId) throw new ForbiddenError('Room does not belong to your clinic');

    await clinicRoomRepository.softDelete(roomId);
  }

  // ============================================================
  // DOCTORS
  // ============================================================

  /**
   * Invite an EXISTING doctor to join the clinic.
   * - Creates a PENDING link if none exists.
   * - If a link exists and is PENDING → 400 "already pending".
   * - If a link exists and is ACCEPTED + active → 400 "already in clinic".
   * - If a link exists but was REJECTED or is inactive → reset to PENDING (reactivate).
   */
  async inviteDoctor(
    clinicId: string,
    doctorId: string,
    invitedBy: string,
  ): Promise<ClinicDoctorResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const existing = await clinicDoctorRepository.findByClinicAndDoctor(clinicId, doctorId);

    if (existing) {
      if (existing.status === 'PENDING' && existing.isActive) {
        throw new BadRequestError('An invitation is already pending');
      }
      if (existing.status === 'ACCEPTED' && existing.isActive) {
        throw new BadRequestError('Doctor is already in this clinic');
      }

      // Rejected or inactive → reactivate as PENDING
      const reactivated = await clinicDoctorRepository.reactivate(existing.id, 'clinic');
      const hydrated = await clinicDoctorRepository.findById(reactivated.id);
      return this.toClinicDoctorResponse(hydrated);
    }

    const link = await clinicDoctorRepository.create({
      clinicId,
      doctorId,
      invitedBy: 'clinic',
    });

    const hydrated = await clinicDoctorRepository.findById(link.id);
    return this.toClinicDoctorResponse(hydrated);
  }

  /**
   * Clinic accepts/rejects a doctor's request to join (invitedBy = 'doctor').
   * Enforces ownership: the link must belong to the calling clinic.
   */
  async respondToDoctorRequest(
    linkId: string,
    clinicId: string,
    action: 'ACCEPTED' | 'REJECTED',
  ): Promise<ClinicDoctorResponse> {
    const link = await clinicDoctorRepository.findById(linkId);
    if (!link) throw new NotFoundError('Request not found');
    if (link.clinicId !== clinicId) {
      throw new ForbiddenError('This request does not belong to your clinic');
    }
    if (link.status !== 'PENDING') {
      throw new BadRequestError('Request is no longer pending');
    }
    if (link.invitedBy !== 'doctor') {
      throw new BadRequestError('This is not a doctor request');
    }

    await clinicDoctorRepository.updateStatus(linkId, action);

    const hydrated = await clinicDoctorRepository.findById(linkId);
    return this.toClinicDoctorResponse(hydrated);
  }

  async removeDoctorFromClinic(clinicId: string, linkId: string): Promise<void> {
    const link = await clinicDoctorRepository.findById(linkId);
    if (!link || link.clinicId !== clinicId) {
      throw new NotFoundError('Doctor link not found');
    }
    await clinicDoctorRepository.remove(linkId);
  }

  async createDoctorForClinic(
    clinicId: string,
    data: CreateClinicDoctorDTO,
    file?: Express.Multer.File,
  ): Promise<ClinicCreatedDoctorResponse> {
    // 1. Clinic must be verified, completed, and not suspended
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');
    if (!clinic.isVerified)
      throw new BadRequestError('Your clinic must be verified before adding doctors');
    if (clinic.isSuspended)
      throw new BadRequestError('Your clinic is suspended');
    if (!clinic.isCompleted)
      throw new BadRequestError('Please complete your clinic profile first');

    // 2. Normalize specialtyIds
    let specialtyIdsArray: string[] = [];
    if (Array.isArray(data.specialtyIds)) {
      specialtyIdsArray = data.specialtyIds;
    } else if (typeof data.specialtyIds === 'string') {
      try {
        const parsed = JSON.parse(data.specialtyIds);
        specialtyIdsArray = Array.isArray(parsed)
          ? parsed
          : data.specialtyIds.split(',').map(s => s.trim()).filter(Boolean);
      } catch {
        specialtyIdsArray = data.specialtyIds.split(',').map(s => s.trim()).filter(Boolean);
      }
    }
    if (specialtyIdsArray.length === 0) {
      throw new BadRequestError('At least one specialty is required');
    }

    // 3. Uniqueness checks
    const [emailExists, phoneExists] = await Promise.all([
      doctorRepository.emailExists(data.email),
      doctorRepository.phoneExists(data.phone),
    ]);
    if (emailExists) throw new ConflictError('A doctor with this email already exists');
    if (phoneExists) throw new ConflictError('A doctor with this phone already exists');

    // 4. Random placeholder password
    const randomPassword = crypto.randomBytes(32).toString('hex');
    const hashedPassword = await bcrypt.hash(randomPassword, 12);

    // 5. Create doctor — awaiting admin verification
    const doctor = await doctorRepository.create({
      email: data.email,
      password: hashedPassword,
      firstNameFr: data.firstNameFr,
      firstNameAr: data.firstNameAr,
      lastNameFr: data.lastNameFr,
      lastNameAr: data.lastNameAr,
      phone: data.phone,
      wilayaId: data.wilayaId,
      isRegistered: false,
      isVerified: false,
      isCompleted: true,
    });

    // 6. Optional profile fields
    const profileUpdate: any = {};
    if (data.bioFr !== undefined) profileUpdate.bioFr = data.bioFr;
    if (data.bioAr !== undefined) profileUpdate.bioAr = data.bioAr;
    if (data.yearsOfExp !== undefined && data.yearsOfExp !== null) {
      profileUpdate.yearsOfExp = typeof data.yearsOfExp === 'string' ? parseInt(data.yearsOfExp, 10) : data.yearsOfExp;
    }
    if (data.practiceType !== undefined) profileUpdate.practiceType = data.practiceType;
    if (data.latitude !== undefined) profileUpdate.latitude = data.latitude;
    if (data.longitude !== undefined) profileUpdate.longitude = data.longitude;
    if (data.baladyaId) profileUpdate.baladya = { connect: { id: data.baladyaId } };
    if (Object.keys(profileUpdate).length > 0) {
      await doctorRepository.update(doctor.id, profileUpdate);
    }

    // 7. Optional logo
    if (file) {
      const storage = StorageFactory.getInstance();
      const uploadResult = await storage.upload(
        {
          buffer: file.buffer,
          originalName: file.originalname,
          mimeType: file.mimetype,
          size: file.size,
        },
        {
          path: 'public/logos',
          isPublic: true,
          contentType: file.mimetype,
          cacheControl: 'public, max-age=31536000',
          metadata: { doctorId: doctor.id, originalName: file.originalname },
        }
      );

      const logo = await doctorLogoRepository.create({
        doctorId: doctor.id,
        filePath: uploadResult.key,
        fileName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        storageKey: uploadResult.key,
      });

      await doctorRepository.update(doctor.id, {
        photoPath: uploadResult.key,
        photoFileId: logo.fileId,
      });
    }

    // 8. Specialties
    await doctorRepository.setSpecialties(doctor.id, specialtyIdsArray);

    // 9. Link doctor ↔ clinic
    const link = await clinicDoctorRepository.createWithStatus({
      clinicId,
      doctorId: doctor.id,
      invitedBy: 'clinic',
      status: 'ACCEPTED',
    });

    // 10. Password setup token + email
    const token = await passwordSetupTokenRepository.create(doctor.id, 'DOCTOR', 72);
    const setupUrl = `${env.BASE_URL}/set-password?token=${token.token}`;

    eventEmitter.emit('send-password-setup-email', {
      email: doctor.email,
      name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
      type: 'DOCTOR',
      setupUrl,
    });

    // 11. Audit
    eventEmitter.emit('audit', {
      action: 'doctor.created_by_clinic',
      entity: 'Doctor',
      entityId: doctor.id,
      performedBy: clinicId,
      details: {
        email: doctor.email,
        clinicId,
        specialtiesCount: specialtyIdsArray.length,
        hasLogo: !!file,
      },
    });

    // 12. Notify admins
    eventEmitter.emit('admin-notification', {
      type: 'doctor_pending_verification',
      doctorId: doctor.id,
      clinicId,
      message: `New doctor "${doctor.firstNameFr} ${doctor.lastNameFr}" created by clinic "${clinic.nameFr}" — awaiting verification`,
    });

    // 13. Notify doctor
    eventEmitter.emit('notification', {
      userId: doctor.id,
      title: '👋 Welcome to Iyadati',
      body: 'Your account has been created by a clinic. Please check your email to set your password. Your account is pending admin verification.',
      type: 'system',
      data: { type: 'doctor_pending_verification', clinicId },
    });

    logger.info(`Doctor created by clinic ${clinic.nameFr}: ${doctor.email}`);

    // 14. Re-fetch with relations
    const freshDoctor = await doctorRepository.findById(doctor.id);
    return this.toCreatedDoctorResponse(freshDoctor, link);
  }

  async getClinicDoctors(clinicId: string): Promise<ClinicDoctorResponse[]> {
    const links = await clinicDoctorRepository.findByClinicId(clinicId);
    return links.map((l: any) => this.toClinicDoctorResponse(l));
  }
}

export const clinicService = new ClinicService();

