import { prisma } from '../core/utils/prisma';

export class ClinicDoctorRepository {
  async findByClinicAndDoctor(clinicId: string, doctorId: string) {
    return prisma.clinicDoctor.findUnique({
      where: { clinicId_doctorId: { clinicId, doctorId } },
      include: { clinic: true, doctor: true },
    });
  }

  async findById(id: string) {
    return prisma.clinicDoctor.findUnique({
      where: { id },
      include: {
        clinic: true,
        doctor: {
          include: {
            specialties: { include: { specialty: true } },
            wilaya: true,
          },
        },
      },
    });
  }

  async findByClinicId(clinicId: string, status?: string) {
    const where: any = { clinicId, isActive: true };
    if (status) where.status = status;

    return prisma.clinicDoctor.findMany({
      where,
      include: {
        doctor: {
          include: { specialties: { include: { specialty: true } }, wilaya: true },
        },
      },
      orderBy: { joinedAt: 'desc' },
    });
  }

  async findByDoctorId(doctorId: string, status?: string) {
    const where: any = { doctorId, isActive: true };
    if (status) where.status = status;

    return prisma.clinicDoctor.findMany({
      where,
      include: { clinic: true },
      orderBy: { joinedAt: 'desc' },
    });
  }

  async create(data: { clinicId: string; doctorId: string; invitedBy: string }) {
    return prisma.clinicDoctor.create({
      data: {
        ...data,
        status: 'PENDING',
      },
      include: { clinic: true, doctor: true },
    });
  }

  /**
   * Update status. When a link is REJECTED, also deactivate it so it
   * disappears from "active doctors" listings on both clinic and doctor sides.
   */
  async updateStatus(id: string, status: string) {
    const data: any = { status };
    if (status === 'REJECTED') {
      data.isActive = false;
    }

    return prisma.clinicDoctor.update({
      where: { id },
      data,
      include: { clinic: true, doctor: true },
    });
  }

  /**
   * Reactivate an existing link and reset it to PENDING.
   * Used when re-inviting a doctor whose previous link was REJECTED/inactive.
   */
  async reactivate(id: string, invitedBy: string) {
    return prisma.clinicDoctor.update({
      where: { id },
      data: {
        status: 'PENDING',
        isActive: true,
        invitedBy,
        joinedAt: new Date(),
      },
      include: { clinic: true, doctor: true },
    });
  }

  async remove(id: string) {
    return prisma.clinicDoctor.update({
      where: { id },
      data: { isActive: false },
    });
  }

  /**
   * Create a clinic-doctor link with an explicit status.
   * Used when the CLINIC itself creates the doctor account — the relationship
   * is already mutually agreed, so status goes straight to ACCEPTED.
   * Admin verification is tracked separately on Doctor.isVerified.
   */
  async createWithStatus(data: {
    clinicId: string;
    doctorId: string;
    invitedBy: string;
    status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  }) {
    return prisma.clinicDoctor.create({
      data: {
        clinicId: data.clinicId,
        doctorId: data.doctorId,
        invitedBy: data.invitedBy,
        status: data.status as any,
      },
      include: { clinic: true, doctor: true },
    });
  }
}

export const clinicDoctorRepository = new ClinicDoctorRepository();

