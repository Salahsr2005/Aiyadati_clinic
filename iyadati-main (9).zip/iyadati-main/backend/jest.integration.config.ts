import type { Config } from 'jest';

const config: Config = {
  displayName: 'integration',
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '.',

  testMatch: ['<rootDir>/tests/integration/**/*.test.ts'],

  // ✅ Redis/BullMQ mocked at boot — the app can import freely
  setupFiles: ['<rootDir>/tests/setup/mockInfrastructure.ts'],

  setupFilesAfterEnv: ['<rootDir>/tests/setup/setupAfterEnv.ts'],

  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },

  transform: {
    '^.+\\.tsx?$': [
      'ts-jest',
      { tsconfig: '<rootDir>/tsconfig.test.json' },
    ],
  },

  // Testcontainers + migrations can be slow
  testTimeout: 300000,
  maxWorkers: 1, // one container at a time
  verbose: true,
};

export default config;

