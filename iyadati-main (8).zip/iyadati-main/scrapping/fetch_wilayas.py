# scrapping/fetch_wilayas.py
import requests
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_wilayas():
    """Fetch wilayas and baladyat from the API"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "Sec-Ch-Ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Brave";v="144"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Linux"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "Sec-Gpc": "1",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getBaladiya4appdoc"
    
    try:
        logger.info("📥 Fetching wilayas and baladyat data...")
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"✅ Successfully fetched wilayas data")
            
            # Save raw data
            with open('data/raw/wilayas_raw.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            # Parse and structure
            wilayas = parse_wilayas(data)
            
            # Save structured data
            with open('data/mappings/wilayas.json', 'w', encoding='utf-8') as f:
                json.dump(wilayas, f, ensure_ascii=False, indent=2)
            
            logger.info(f"✅ Saved {len(wilayas)} wilayas to data/mappings/wilayas.json")
            
            # Print sample
            print("\n📋 Sample Wilayas:")
            for code, info in list(wilayas.items())[:10]:
                baladyat_count = len(info.get('baladyat', []))
                print(f"  {code}: {info['name']} ({baladyat_count} municipalities)")
            
            return wilayas
        else:
            logger.error(f"❌ Failed to fetch wilayas: Status {response.status_code}")
            return create_fallback_wilayas()
            
    except Exception as e:
        logger.error(f"❌ Error fetching wilayas: {e}")
        return create_fallback_wilayas()

def parse_wilayas(data: List[Dict]) -> Dict:
    """Parse wilayas and baladyat data"""
    wilayas = {}
    
    for item in data:
        # Find wilaya code
        wilaya_code = None
        for field in ['Num_wilaya', 'code', 'wilaya_code', 'id']:
            if field in item and item[field]:
                wilaya_code = str(item[field]).zfill(2)
                break
        
        # Find wilaya name
        wilaya_name = None
        for field in ['Wilaya_name', 'name', 'wilaya_name', 'label']:
            if field in item and item[field]:
                wilaya_name = str(item[field]).strip()
                break
        
        if wilaya_code:
            # Get baladyat
            baladyat = []
            if 'Baladyat' in item and isinstance(item['Baladyat'], list):
                baladyat = item['Baladyat']
            elif 'baladyat' in item and isinstance(item['baladyat'], list):
                baladyat = item['baladyat']
            elif 'municipalities' in item and isinstance(item['municipalities'], list):
                baladyat = item['municipalities']
            
            wilayas[wilaya_code] = {
                'code': wilaya_code,
                'name': wilaya_name or f"Wilaya {wilaya_code}",
                'baladyat': baladyat,
                'baladyat_count': len(baladyat)
            }
    
    return wilayas

def create_fallback_wilayas():
    """Create fallback wilaya mapping"""
    # Algerian wilayas with codes
    wilaya_names = {
        '01': 'Adrar', '02': 'Chlef', '03': 'Laghouat', '04': 'Oum El Bouaghi',
        '05': 'Batna', '06': 'Bejaia', '07': 'Biskra', '08': 'Bechar',
        '09': 'Blida', '10': 'Bouira', '11': 'Tamanrasset', '12': 'Tebessa',
        '13': 'Tlemcen', '14': 'Tiaret', '15': 'Tizi Ouzou', '16': 'Alger',
        '17': 'Djelfa', '18': 'Jijel', '19': 'Setif', '20': 'Saida',
        '21': 'Skikda', '22': 'Sidi Bel Abbes', '23': 'Annaba', '24': 'Guelma',
        '25': 'Constantine', '26': 'Medea', '27': 'Mostaganem', '28': 'M\'sila',
        '29': 'Mascara', '30': 'Ouargla', '31': 'Oran', '32': 'El Bayadh',
        '33': 'Illizi', '34': 'Bordj Bou Arreridj', '35': 'Boumerdes',
        '36': 'El Tarf', '37': 'Tindouf', '38': 'Tissemsilt', '39': 'El Oued',
        '40': 'Khenchela', '41': 'Souk Ahras', '42': 'Tipaza', '43': 'Mila',
        '44': 'Ain Defla', '45': 'Naama', '46': 'Ain Temouchent', '47': 'Ghardaia',
        '48': 'Relizane', '49': 'El M\'ghair', '50': 'El Menia', '51': 'Ouled Djellal',
        '52': 'Bordj Baji Mokhtar', '53': 'Béni Abbès', '54': 'Timimoun',
        '55': 'Touggourt', '56': 'Djanet', '57': 'In Salah', '58': 'In Guezzam'
    }
    
    wilayas = {}
    for code, name in wilaya_names.items():
        wilayas[code] = {
            'code': code,
            'name': name,
            'baladyat': [],
            'baladyat_count': 0
        }
    
    return wilayas

if __name__ == "__main__":
    import os
    os.makedirs('data/raw', exist_ok=True)
    os.makedirs('data/mappings', exist_ok=True)
    
    fetch_wilayas()