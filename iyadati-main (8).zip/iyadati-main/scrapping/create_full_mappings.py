# scrapping/create_full_mappings.py
import requests
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_and_create_mappings():
    """Fetch specialties and create full mapping with real names"""
    
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    # Fetch specialties
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    response = requests.get(url, headers=headers, timeout=30)
    
    if response.status_code == 200:
        data = response.json()
        logger.info(f"✅ Fetched {len(data)} specialties")
        
        # Create mapping
        specialties = {}
        for item in data:
            code = str(item.get('num_sp', '')).zfill(2)
            name_ar = item.get('name_sp', '')
            name_fr = item.get('name_spfr', '')
            
            if code:
                specialties[code] = {
                    'code': code,
                    'name': name_fr or name_ar or f"Spécialité {code}",
                    'name_ar': name_ar,
                    'name_fr': name_fr,
                    'order': item.get('ordersp', '')
                }
        
        # Save
        with open('data/mappings/specialties_full.json', 'w', encoding='utf-8') as f:
            json.dump(specialties, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✅ Saved {len(specialties)} specialties")
        
        # Print all specialties with names
        print("\n" + "=" * 60)
        print("🏥 ALL SPECIALTIES WITH REAL NAMES")
        print("=" * 60)
        for code, info in sorted(specialties.items()):
            print(f"  {code}: {info['name']} ({info['name_ar']})")
        
        return specialties
    else:
        logger.error(f"❌ Failed: Status {response.status_code}")
        return {}

def create_wilaya_mapping():
    """Create wilaya mapping with real names"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getBaladiya4appdoc"
    response = requests.get(url, headers=headers, timeout=30)
    
    if response.status_code == 200:
        data = response.json()
        logger.info(f"✅ Fetched {len(data)} wilaya records")
        
        wilayas = {}
        for item in data:
            code = str(item.get('MatWilaya', '')).zfill(2)
            name_ar = item.get('NOM', '')
            name_fr = item.get('Nomfr', '')
            
            if code and code not in wilayas:
                wilayas[code] = {
                    'code': code,
                    'name': name_fr or name_ar or f"Wilaya {code}",
                    'name_ar': name_ar,
                    'name_fr': name_fr
                }
        
        # Save
        with open('data/mappings/wilayas_full.json', 'w', encoding='utf-8') as f:
            json.dump(wilayas, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✅ Saved {len(wilayas)} wilayas")
        
        # Print all wilayas
        print("\n" + "=" * 60)
        print("🏙️ ALL WILAYAS WITH REAL NAMES")
        print("=" * 60)
        for code, info in sorted(wilayas.items()):
            print(f"  {code}: {info['name']} ({info['name_ar']})")
        
        return wilayas
    else:
        logger.error(f"❌ Failed: Status {response.status_code}")
        return {}

if __name__ == "__main__":
    import os
    os.makedirs('data/mappings', exist_ok=True)
    
    print("🚀 Creating full mappings...")
    specialties = fetch_and_create_mappings()
    wilayas = create_wilaya_mapping()
    
    # Create combined mappings
    mappings = {
        'specialties': specialties,
        'wilayas': wilayas
    }
    
    with open('data/mappings/mappings_full.json', 'w', encoding='utf-8') as f:
        json.dump(mappings, f, ensure_ascii=False, indent=2)
    
    print("\n✅ All mappings saved to data/mappings/mappings_full.json")