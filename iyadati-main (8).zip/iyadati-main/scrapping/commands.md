
python3 machrou3.py
python3 -c "import json; d=json.load(open('doctors.json')); print(type(d)); print(len(d)); print(d[0] if isinstance(d, list) else list(d.keys()))"
python3 json_to_csv.py

python3 -m venv .venv
source .venv/bin/activate
python3 -c "import pandas as pd; df=pd.read_csv('doctors.csv'); print(df.shape); print(df.columns.tolist()); print(df.head())"
pip install pandas
pip install matplotlib
pip install streamlit
