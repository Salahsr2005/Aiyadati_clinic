# scrapping/convert_fixed.py
import json
import pandas as pd
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def convert_doctors():
    """Convert doctors JSON to CSV"""
    try:
        # Check if file exists in the right location
        input_file = 'doctors_enhanced_v2.json'
        
        if not os.path.exists(input_file):
            logger.error(f"❌ File not found: {input_file}")
            return None
        
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        logger.info(f"✅ Loaded {len(data):,} records")
        
        # Convert to DataFrame
        df = pd.DataFrame(data)
        
        # Create directory if needed
        os.makedirs('data/processed', exist_ok=True)
        
        # Save to CSV
        output_file = 'data/processed/doctors_enhanced.csv'
        df.to_csv(output_file, index=False, encoding='utf-8')
        
        logger.info(f"✅ Saved {len(df):,} records to {output_file}")
        logger.info(f"📋 Columns: {', '.join(df.columns)}")
        
        # Show sample
        print("\n📋 Sample Data:")
        print(df[['name', 'city', 'specialty', 'phone']].head(5))
        
        return df
        
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    convert_doctors()

