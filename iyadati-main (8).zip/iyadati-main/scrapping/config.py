# scrapping/config.py
import os
from datetime import datetime

# Data paths
DATA_PATHS = {
    'raw': 'data/raw/',
    'mappings': 'data/mappings/',
    'processed': 'data/processed/',
    'dashboard': 'data/dashboard/',
}

# API Headers
API_HEADERS = {
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.6",
    "Origin": "https://machrou3.com",
    "Referer": "https://machrou3.com/",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    "Sec-Ch-Ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Brave";v="144"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Linux"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "Sec-Gpc": "1",
}

# API URLs
API_URLS = {
    'doctors': 'https://doctorsdz.machrou3.com/user/getinfoAppDoc',
    'specialties': 'https://doctorsdz.machrou3.com/user/getsp4appdoc',
    'wilayas': 'https://doctorsdz.machrou3.com/user/getBaladiya4appdoc',
}

def ensure_directories():
    """Create all necessary directories"""
    for path in DATA_PATHS.values():
        os.makedirs(path, exist_ok=True)
    print("✅ Directories created")

def get_output_filename(base_name, extension='json'):
    """Generate filename with timestamp"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{base_name}_{timestamp}.{extension}"