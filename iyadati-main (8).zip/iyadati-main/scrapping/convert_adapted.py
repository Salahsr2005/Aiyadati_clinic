# scrapping/convert_adapted.py
import json
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def convert_adapted_json_to_csv(input_file="doctors_enhanced.json", output_file="doctors_enhanced.csv"):
    """Convert adapted JSON to CSV"""
    try:
        logger.info(f"📖 Reading {input_file}...")
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        if not data:
            logger.warning("Empty data")
            return
        
        # Convert to DataFrame
        df = pd.DataFrame(data)
        
        logger.info(f"✅ Loaded {len(df):,} records")
        logger.info(f"📋 Columns: {', '.join(df.columns)}")
        
        # Save to CSV
        df.to_csv(output_file, index=False, encoding='utf-8')
        logger.info(f"✅ Saved to {output_file}")
        
        # Show summary
        print("\n📊 Data Summary:")
        print(f"  Total records: {len(df):,}")
        print(f"  With coordinates: {df['latitude'].notna().sum():,} ({df['latitude'].notna().sum()/len(df)*100:.1f}%)")
        print(f"  With city: {df['city'].notna().sum():,} ({df['city'].notna().sum()/len(df)*100:.1f}%)")
        print(f"  With specialty: {df['specialty'].notna().sum():,} ({df['specialty'].notna().sum()/len(df)*100:.1f}%)")
        print(f"  With phone: {df['phone'].notna().sum():,} ({df['phone'].notna().sum()/len(df)*100:.1f}%)")
        
        return df
        
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    convert_adapted_json_to_csv()