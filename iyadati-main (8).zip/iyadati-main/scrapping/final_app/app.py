import os
import subprocess
import sys
from datetime import datetime

import pandas as pd
import plotly.express as px
import streamlit as st


# ============================================================
# Page configuration
# ============================================================

st.set_page_config(
    page_title="Algerian Doctors Directory",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# Custom CSS
# ============================================================

st.markdown(
"""
<style>
.main-header {
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
padding: 2rem;
border-radius: 10px;
color: white;
text-align: center;
margin-bottom: 2rem;
}
.stat-card {
background: white;
padding: 1.5rem;
border-radius: 10px;
box-shadow: 0 2px 10px rgba(0,0,0,0.1);
text-align: center;
transition: transform 0.2s;
}
.stat-card:hover {
transform: translateY(-5px);
box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}
.stat-number {
font-size: 2.5rem;
font-weight: bold;
color: #667eea;
}
.stat-label {
color: #666;
font-size: 0.9rem;
margin-top: 0.5rem;
}
.doctor-card {
background: white;
padding: 1rem;
border-radius: 8px;
border-left: 4px solid #667eea;
margin-bottom: 0.5rem;
box-shadow: 0 1px 3px rgba(0,0,0,0.1);
transition: transform 0.2s;
}
.doctor-card:hover {
transform: translateX(5px);
box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.doctor-name {
font-weight: bold;
color: #2c3e50;
font-size: 1.1rem;
}
.doctor-detail {
color: #666;
font-size: 0.9rem;
margin: 2px 0;
}
.badge {
display: inline-block;
padding: 0.2rem 0.6rem;
border-radius: 20px;
font-size: 0.8rem;
margin: 0.2rem;
}
.badge-blue { background: #667eea; color: white; }
.badge-green { background: #27ae60; color: white; }
.badge-orange { background: #f39c12; color: white; }
.badge-red { background: #e74c3c; color: white; }
.badge-purple { background: #9b59b6; color: white; }
.badge-teal { background: #1abc9c; color: white; }
.section-title {
font-size: 1.5rem;
font-weight: bold;
color: #2c3e50;
margin: 1.5rem 0 1rem 0;
padding-bottom: 0.5rem;
border-bottom: 3px solid #667eea;
}
.data-status {
padding: 1rem;
border-radius: 8px;
margin: 1rem 0;
text-align: center;
}
.data-status.success {
background: #d4edda;
color: #155724;
border: 1px solid #c3e6cb;
}
.data-status.warning {
background: #fff3cd;
color: #856404;
border: 1px solid #ffc107;
}
.data-status.info {
background: #d1ecf1;
color: #0c5460;
border: 1px solid #bee5eb;
}
</style>
""",
    unsafe_allow_html=True,
)


# ============================================================
# Data paths
# ============================================================

DATA_DIR = "data"
DOCTORS_CSV = os.path.join(DATA_DIR, "doctors.csv")
SPECIALTIES_CSV = os.path.join(DATA_DIR, "specialties.csv")
CITIES_CSV = os.path.join(DATA_DIR, "cities.csv")
MUNICIPALITIES_CSV = os.path.join(DATA_DIR, "municipalities.csv")


# ============================================================
# Helpers
# ============================================================

def safe_value(value, default=""):
    """Convert NaN/None values to safe strings."""
    if value is None or pd.isna(value):
        return default
    return str(value)


def render_html(html: str):
    """Render an HTML snippet with st.markdown safely."""
    flattened = "".join(line.strip() for line in html.strip().splitlines())
    st.markdown(flattened, unsafe_allow_html=True)


# ============================================================
# Data loading
# ============================================================

@st.cache_data
def load_data():
    """Load data from CSV files and map specialty/city/municipality codes."""

    try:
        df_doctors = (
            pd.read_csv(DOCTORS_CSV, encoding="utf-8")
            if os.path.exists(DOCTORS_CSV)
            else pd.DataFrame()
        )

        df_specialties = (
            pd.read_csv(SPECIALTIES_CSV, encoding="utf-8")
            if os.path.exists(SPECIALTIES_CSV)
            else pd.DataFrame()
        )

        df_cities = (
            pd.read_csv(CITIES_CSV, encoding="utf-8")
            if os.path.exists(CITIES_CSV)
            else pd.DataFrame()
        )

        df_municipalities = (
            pd.read_csv(MUNICIPALITIES_CSV, encoding="utf-8")
            if os.path.exists(MUNICIPALITIES_CSV)
            else pd.DataFrame()
        )

        # Map specialty codes to names
        if (
            not df_doctors.empty
            and not df_specialties.empty
            and "code" in df_specialties.columns
            and "name" in df_specialties.columns
            and "specialty_code" in df_doctors.columns
        ):
            specialty_map = (
                df_specialties
                .set_index("code")["name"]
                .to_dict()
            )

            df_doctors["specialty"] = (
                df_doctors["specialty_code"]
                .map(specialty_map)
                .fillna(df_doctors["specialty_code"])
            )

        # Map wilaya codes to city names
        if (
            not df_doctors.empty
            and not df_cities.empty
            and "code" in df_cities.columns
            and "name" in df_cities.columns
            and "wilaya_code" in df_doctors.columns
        ):
            city_map = (
                df_cities
                .set_index("code")["name"]
                .to_dict()
            )

            df_doctors["city"] = (
                df_doctors["wilaya_code"]
                .map(city_map)
                .fillna(df_doctors["wilaya_code"])
            )

        # Map municipality IDs to names
        if (
            not df_doctors.empty
            and not df_municipalities.empty
            and "municipality_id" in df_municipalities.columns
            and "municipality_name" in df_municipalities.columns
            and "municipality_id" in df_doctors.columns
        ):
            df_doctors["municipality_id"] = df_doctors["municipality_id"].astype(str)
            df_municipalities["municipality_id"] = df_municipalities["municipality_id"].astype(str)

            mun_map = (
                df_municipalities
                .set_index("municipality_id")["municipality_name"]
                .to_dict()
            )

            df_doctors["municipality"] = (
                df_doctors["municipality_id"]
                .map(mun_map)
                .fillna(df_doctors["municipality_id"])
            )

        return df_doctors, df_specialties, df_cities, df_municipalities

    except Exception as e:
        st.error(f"❌ Error loading data: {e}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()


# ============================================================
# Doctor card
# ============================================================

def display_doctor_card(row, idx=None):
    """Display a single doctor as a card."""

    name = safe_value(row.get("name"), "Unknown")
    city = safe_value(row.get("city"), "N/A")
    municipality = safe_value(row.get("municipality"))
    specialty = safe_value(row.get("specialty"))
    phone = safe_value(row.get("phone"))
    email = safe_value(row.get("email"))
    address = safe_value(row.get("address"))
    doctor_id = safe_value(row.get("id"))

    latitude = row.get("latitude")

    specialty_badge = (
        f'<span class="badge badge-blue">{specialty}</span>'
        if specialty
        else ""
    )

    municipality_badge = (
        f'<span class="badge badge-teal">🏛️ {municipality}</span>'
        if municipality
        else ""
    )

    phone_badge = (
        f'<span class="badge badge-green">📞 {phone}</span>'
        if phone
        else ""
    )

    email_badge = (
        f'<span class="badge badge-orange">✉️ {email}</span>'
        if email
        else ""
    )

    coords_badge = (
        '<span class="badge badge-red">📍</span>'
        if pd.notna(latitude)
        else ""
    )

    id_badge = (
        f'<span class="badge badge-purple">ID: {doctor_id}</span>'
        if doctor_id
        else ""
    )

    if len(address) > 60:
        address = address[:60] + "..."

    html = (
        f'<div class="doctor-card">'
        f'<div class="doctor-name">{name}</div>'
        f'<div class="doctor-detail">📍 {city}{f" — {municipality}" if municipality else ""}</div>'
        f'<div class="doctor-detail">{specialty_badge}{municipality_badge}</div>'
        f'<div class="doctor-detail">{phone_badge}{email_badge}{coords_badge}</div>'
        f'<div class="doctor-detail" style="font-size:0.8rem;color:#999;margin-top:0.3rem;">'
        f'{id_badge} {address}'
        f'</div>'
        f'</div>'
    )

    st.markdown(html, unsafe_allow_html=True)


# ============================================================
# Search helper
# ============================================================

def search_dataframe(df, query):
    """Search across all columns of a DataFrame."""

    if not query or df.empty:
        return df

    mask = pd.Series(False, index=df.index)

    for column in df.columns:
        mask |= (
            df[column]
            .astype(str)
            .str.contains(
                query,
                case=False,
                na=False,
                regex=False,
            )
        )

    return df[mask]


# ============================================================
# Main application
# ============================================================

def main():

    # --------------------------------------------------------
    # Header
    # --------------------------------------------------------

    header_html = (
        '<div class="main-header">'
        '<h1>🏥 Algerian Doctors Directory</h1>'
        '<p style="margin:0;opacity:0.9;">'
        'Complete database of medical professionals in Algeria'
        '</p>'
        '</div>'
    )
    st.markdown(header_html, unsafe_allow_html=True)

    # --------------------------------------------------------
    # Check data
    # --------------------------------------------------------

    data_exists = all(
        [
            os.path.exists(DOCTORS_CSV),
            os.path.exists(SPECIALTIES_CSV),
            os.path.exists(CITIES_CSV),
        ]
    )

    if not data_exists:

        no_data_html = (
            '<div class="data-status warning">'
            '⚠️ <strong>No data found</strong><br>'
            'Please run the data fetch script first:'
            '<code style="background:#f8f9fa;padding:0.2rem 0.5rem;'
            'border-radius:4px;display:inline-block;margin-top:0.5rem;">'
            'python3 fetch_data.py'
            '</code>'
            '</div>'
        )
        st.markdown(no_data_html, unsafe_allow_html=True)

        st.info(
            "### 📥 How to load data:\n\n"
            "1. Open a terminal in this directory.\n"
            "2. Run:\n\n"
            "```bash\n"
            "python3 fetch_data.py\n"
            "```\n\n"
            "3. Wait for it to complete.\n"
            "4. Refresh this page."
        )

        if st.button(
            "🔄 Fetch Data Now",
            type="primary",
        ):
            with st.spinner(
                "Fetching data... Please wait..."
            ):
                try:
                    result = subprocess.run(
                        [
                            sys.executable,
                            "fetch_data.py",
                        ],
                        capture_output=True,
                        text=True,
                    )

                    if result.returncode == 0:
                        st.success(
                            "✅ Data fetched successfully! Refreshing..."
                        )
                        st.cache_data.clear()
                        st.rerun()
                    else:
                        st.error(
                            "❌ Error fetching data:"
                        )
                        st.code(result.stderr)

                except Exception as e:
                    st.error(
                        f"❌ Failed to run fetch_data.py: {e}"
                    )

        return

    # --------------------------------------------------------
    # Data status
    # --------------------------------------------------------

    last_modified = datetime.fromtimestamp(
        os.path.getmtime(DOCTORS_CSV)
    )

    status_html = (
        '<div class="data-status success">'
        '✅ <strong>Data loaded successfully</strong><br>'
        f'Data fetched on: {last_modified.strftime("%Y-%m-%d %H:%M:%S")}'
        '</div>'
    )
    st.markdown(status_html, unsafe_allow_html=True)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    with st.spinner("📊 Loading data..."):
        (
            df_doctors,
            df_specialties,
            df_cities,
            df_municipalities,
        ) = load_data()

    if df_doctors.empty:
        st.warning(
            "No data loaded. Please run fetch_data.py"
        )
        return

    # ========================================================
    # Statistics
    # ========================================================

    def stat_card(number, label):
        return (
            '<div class="stat-card">'
            f'<div class="stat-number">{number}</div>'
            f'<div class="stat-label">{label}</div>'
            '</div>'
        )

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        st.markdown(
            stat_card(f"{len(df_doctors):,}", "👨‍⚕️ Doctors"),
            unsafe_allow_html=True,
        )

    with col2:
        cities_count = (
            df_doctors["city"].nunique()
            if "city" in df_doctors.columns
            else 0
        )
        st.markdown(
            stat_card(cities_count, "🏙️ Cities"),
            unsafe_allow_html=True,
        )

    with col3:
        specialties_count = (
            df_doctors["specialty"].nunique()
            if "specialty" in df_doctors.columns
            else 0
        )
        st.markdown(
            stat_card(specialties_count, "🏥 Specialties"),
            unsafe_allow_html=True,
        )

    with col4:
        with_coords = (
            df_doctors["latitude"].notna().sum()
            if "latitude" in df_doctors.columns
            else 0
        )
        st.markdown(
            stat_card(f"{with_coords:,}", "📍 With Location"),
            unsafe_allow_html=True,
        )

    with col5:
        with_phone = (
            df_doctors["phone"].notna().sum()
            if "phone" in df_doctors.columns
            else 0
        )
        st.markdown(
            stat_card(f"{with_phone:,}", "📞 With Phone"),
            unsafe_allow_html=True,
        )

    st.divider()

    # ========================================================
    # Sidebar filters
    # ========================================================

    st.sidebar.header("🔍 Filters")

    search = st.sidebar.text_input(
        "🔎 Search",
        placeholder="Name, specialty, city...",
    )

    if "city" in df_doctors.columns:
        city_options = ["All"] + sorted(
            df_doctors["city"]
            .dropna()
            .astype(str)
            .unique()
            .tolist()
        )

        selected_city = st.sidebar.selectbox(
            "🏙️ City",
            city_options,
        )
    else:
        selected_city = "All"

    if "municipality" in df_doctors.columns:
        municipality_options = ["All"] + sorted(
            df_doctors["municipality"]
            .dropna()
            .astype(str)
            .unique()
            .tolist()
        )

        selected_municipality = st.sidebar.selectbox(
            "🏛️ Municipality",
            municipality_options,
        )
    else:
        selected_municipality = "All"

    if "specialty" in df_doctors.columns:
        specialty_options = ["All"] + sorted(
            df_doctors["specialty"]
            .dropna()
            .astype(str)
            .unique()
            .tolist()
        )

        selected_specialty = st.sidebar.selectbox(
            "🏥 Specialty",
            specialty_options,
        )
    else:
        selected_specialty = "All"

    st.sidebar.markdown("---")
    st.sidebar.markdown("📞 **Contact**")

    has_phone = st.sidebar.checkbox("Has Phone")
    has_email = st.sidebar.checkbox("Has Email")

    # ========================================================
    # Apply filters
    # ========================================================

    filtered_df = df_doctors.copy()

    if search:
        search_columns = [
            "name",
            "specialty",
            "city",
            "municipality",
            "phone",
            "email",
            "address",
            "id",
        ]

        available_columns = [
            column
            for column in search_columns
            if column in filtered_df.columns
        ]

        mask = pd.Series(
            False,
            index=filtered_df.index,
        )

        for column in available_columns:
            mask |= (
                filtered_df[column]
                .astype(str)
                .str.contains(
                    search,
                    case=False,
                    na=False,
                    regex=False,
                )
            )

        filtered_df = filtered_df[mask]

    if (
        selected_city != "All"
        and "city" in filtered_df.columns
    ):
        filtered_df = filtered_df[
            filtered_df["city"].astype(str)
            == selected_city
        ]

    if (
        selected_municipality != "All"
        and "municipality" in filtered_df.columns
    ):
        filtered_df = filtered_df[
            filtered_df["municipality"].astype(str)
            == selected_municipality
        ]

    if (
        selected_specialty != "All"
        and "specialty" in filtered_df.columns
    ):
        filtered_df = filtered_df[
            filtered_df["specialty"].astype(str)
            == selected_specialty
        ]

    if has_phone and "phone" in filtered_df.columns:
        filtered_df = filtered_df[
            filtered_df["phone"].notna()
            & filtered_df["phone"].astype(str).str.strip().ne("")
        ]

    if has_email and "email" in filtered_df.columns:
        filtered_df = filtered_df[
            filtered_df["email"].notna()
            & filtered_df["email"].astype(str).str.strip().ne("")
        ]

    st.info(
        f"📊 Showing **{len(filtered_df):,}** doctors "
        f"out of **{len(df_doctors):,}**"
    )

    # ========================================================
    # Tabs
    # ========================================================

    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
        [
            "📋 Doctors",
            "🗺️ Map",
            "🏥 Specialties",
            "🏙️ Cities",
            "📊 Statistics",
            "🏛️ Municipalities",
        ]
    )

    # ========================================================
    # TAB 1: Doctors + Pagination
    # ========================================================

    with tab1:

        st.markdown(
            '<div class="section-title">👨‍⚕️ Doctor Directory</div>',
            unsafe_allow_html=True,
        )

        if filtered_df.empty:

            st.warning(
                "No doctors match your filters."
            )

        else:

            total_records = len(filtered_df)

            page_size = st.selectbox(
                "Rows per page:",
                [10, 20, 50, 100, 200],
                index=2,
                key="page_size",
            )

            total_pages = max(
                1,
                (total_records + page_size - 1)
                // page_size,
            )

            if (
                "current_page" not in st.session_state
                or st.session_state.current_page > total_pages
            ):
                st.session_state.current_page = 1

            current_page = st.session_state.current_page

            col1, col2, col3 = st.columns(
                [1, 2, 1]
            )

            with col1:
                if st.button(
                    "◀ Previous",
                    disabled=current_page <= 1,
                    key="previous_page",
                ):
                    st.session_state.current_page -= 1
                    st.rerun()

            with col2:
                page_info_html = (
                    '<div style="text-align:center;color:#666;padding:0.5rem;">'
                    f'Page {current_page} of {total_pages}'
                    f'<span style="margin-left:0.5rem;color:#999;">'
                    f'({total_records:,} records)</span>'
                    '</div>'
                )
                st.markdown(page_info_html, unsafe_allow_html=True)

            with col3:
                if st.button(
                    "Next ▶",
                    disabled=current_page >= total_pages,
                    key="next_page",
                ):
                    st.session_state.current_page += 1
                    st.rerun()

            start_idx = (
                current_page - 1
            ) * page_size

            end_idx = min(
                start_idx + page_size,
                total_records,
            )

            page_df = filtered_df.iloc[
                start_idx:end_idx
            ]

            cols = st.columns(2)

            for i, (idx, row) in enumerate(
                page_df.iterrows()
            ):
                with cols[i % 2]:
                    display_doctor_card(row, idx)

            st.caption(
                f"Showing records "
                f"{start_idx + 1} to {end_idx} "
                f"of {total_records:,}"
            )

        # ----------------------------------------------------
        # Export
        # ----------------------------------------------------

        st.markdown("---")

        col1, col2, col3 = st.columns(3)

        with col1:
            csv_data = filtered_df.to_csv(
                index=False
            )

            st.download_button(
                label="📥 Download Filtered Doctors (CSV)",
                data=csv_data,
                file_name=(
                    f"doctors_"
                    f"{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
                ),
                mime="text/csv",
                use_container_width=True,
            )

        with col2:
            json_data = filtered_df.to_json(
                orient="records",
                force_ascii=False,
                indent=2,
            )

            st.download_button(
                label="📥 Download Filtered Doctors (JSON)",
                data=json_data,
                file_name=(
                    f"doctors_"
                    f"{datetime.now().strftime('%Y%m%d_%H%M')}.json"
                ),
                mime="application/json",
                use_container_width=True,
            )

        with col3:
            db_cols = [
                "id", "name", "specialty", "city", "municipality",
                "address", "phone", "phone2", "email",
                "description", "latitude", "longitude",
                "specialty_code", "wilaya_code", "municipality_id",
                "created_at", "updated_at", "newinfo", "iduser",
            ]
            available_db_cols = [c for c in db_cols if c in filtered_df.columns]
            db_df = filtered_df[available_db_cols].copy()

            rename_map = {
                "specialty": "specialty_name",
                "city": "city_name",
                "municipality": "municipality_name",
            }
            db_df = db_df.rename(columns={k: v for k, v in rename_map.items() if k in db_df.columns})

            st.download_button(
                label="📥 Download DB-Ready Doctors (CSV)",
                data=db_df.to_csv(index=False),
                file_name=(
                    f"doctors_db_ready_"
                    f"{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
                ),
                mime="text/csv",
                use_container_width=True,
            )

    # ========================================================
    # TAB 2: Map
    # ========================================================

    with tab2:

        st.markdown(
            '<div class="section-title">🗺️ Geographic Distribution</div>',
            unsafe_allow_html=True,
        )

        if {
            "latitude",
            "longitude",
        }.issubset(filtered_df.columns):

            map_df = filtered_df[
                filtered_df["latitude"].notna()
                & filtered_df["longitude"].notna()
            ].copy()

        else:
            map_df = pd.DataFrame()

        if not map_df.empty:

            hover_data = {
                column: True
                for column in [
                    "specialty",
                    "city",
                    "municipality",
                    "phone",
                    "address",
                ]
                if column in map_df.columns
            }

            fig = px.scatter_map(
                map_df,
                lat="latitude",
                lon="longitude",
                hover_name=(
                    "name"
                    if "name" in map_df.columns
                    else None
                ),
                hover_data=hover_data,
                color=(
                    "specialty"
                    if "specialty" in map_df.columns
                    else None
                ),
                zoom=5,
                height=600,
                title=(
                    f"📍 {len(map_df)} Doctors "
                    "with Location Data"
                ),
            )

            fig.update_layout(
                map_style="open-street-map",
                margin={
                    "r": 0,
                    "t": 50,
                    "l": 0,
                    "b": 0,
                },
            )

            st.plotly_chart(
                fig,
                use_container_width=True,
            )

            map_columns = [
                column
                for column in [
                    "name",
                    "city",
                    "municipality",
                    "specialty",
                    "latitude",
                    "longitude",
                    "address",
                ]
                if column in map_df.columns
            ]

            map_export = map_df[
                map_columns
            ].copy()

            st.download_button(
                label="📥 Download Map Data (CSV)",
                data=map_export.to_csv(
                    index=False
                ),
                file_name=(
                    f"map_data_"
                    f"{datetime.now().strftime('%Y%m%d')}.csv"
                ),
                mime="text/csv",
            )

        else:
            st.warning(
                "No doctors with location data "
                "in the filtered results."
            )

    # ========================================================
    # TAB 3: Specialties
    # ========================================================

    with tab3:

        st.markdown(
            '<div class="section-title">🏥 All Specialties</div>',
            unsafe_allow_html=True,
        )

        if not df_specialties.empty:

            if "specialty" in df_doctors.columns:

                specialty_counts = (
                    df_doctors["specialty"]
                    .value_counts()
                    .reset_index()
                )

                specialty_counts.columns = [
                    "specialty",
                    "count",
                ]

            else:

                specialty_counts = pd.DataFrame(
                    columns=[
                        "specialty",
                        "count",
                    ]
                )

            specialty_data = (
                df_specialties
                .merge(
                    specialty_counts,
                    left_on="name",
                    right_on="specialty",
                    how="left",
                )
            )

            specialty_data["count"] = (
                pd.to_numeric(
                    specialty_data["count"],
                    errors="coerce",
                )
                .fillna(0)
                .astype(int)
            )

            specialty_data = specialty_data.sort_values(
                "count",
                ascending=False,
            )

            search_specialty = st.text_input(
                "🔎 Search Specialties",
                placeholder="Search by name or code...",
                key="search_specialty",
            )

            display_specialties = search_dataframe(
                specialty_data,
                search_specialty,
            )

            st.info(
                f"Showing {len(display_specialties)} "
                "specialties"
            )

            for _, row in display_specialties.iterrows():

                name = safe_value(
                    row.get("name")
                )

                name_ar = safe_value(
                    row.get("name_ar")
                )

                code = safe_value(
                    row.get("code")
                )

                count = row.get(
                    "count",
                    0,
                )

                row_html = (
                    '<div style="display:flex;justify-content:space-between;'
                    'padding:0.7rem;border-bottom:1px solid #eee;align-items:center;">'
                    '<div>'
                    f'<strong>{name}</strong>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">{name_ar}</span>'
                    '</div>'
                    '<div>'
                    f'<span class="badge badge-blue">{int(count):,} doctors</span>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">Code: {code}</span>'
                    '</div>'
                    '</div>'
                )
                st.markdown(row_html, unsafe_allow_html=True)

            st.download_button(
                label="📥 Download Specialties (CSV)",
                data=specialty_data.to_csv(
                    index=False
                ),
                file_name=(
                    f"specialties_"
                    f"{datetime.now().strftime('%Y%m%d')}.csv"
                ),
                mime="text/csv",
            )

        else:
            st.info(
                "No specialty data available."
            )

    # ========================================================
    # TAB 4: Cities
    # ========================================================

    with tab4:

        st.markdown(
            '<div class="section-title">🏙️ All Cities &amp; Municipalities</div>',
            unsafe_allow_html=True,
        )

        if not df_cities.empty:

            if "city" in df_doctors.columns:

                city_counts = (
                    df_doctors["city"]
                    .value_counts()
                    .reset_index()
                )

                city_counts.columns = [
                    "city",
                    "doctors",
                ]

            else:

                city_counts = pd.DataFrame(
                    columns=[
                        "city",
                        "doctors",
                    ]
                )

            city_data = (
                df_cities
                .merge(
                    city_counts,
                    left_on="name",
                    right_on="city",
                    how="left",
                )
            )

            city_data["doctors"] = (
                pd.to_numeric(
                    city_data["doctors"],
                    errors="coerce",
                )
                .fillna(0)
                .astype(int)
            )

            city_data = city_data.sort_values(
                "doctors",
                ascending=False,
            )

            search_city = st.text_input(
                "🔎 Search Cities",
                placeholder="Search by name or code...",
                key="search_city",
            )

            display_cities = search_dataframe(
                city_data,
                search_city,
            )

            st.info(
                f"Showing {len(display_cities)} cities"
            )

            for _, row in display_cities.iterrows():

                name = safe_value(
                    row.get("name")
                )

                name_ar = safe_value(
                    row.get("name_ar")
                )

                code = safe_value(
                    row.get("code")
                )

                doctors = row.get(
                    "doctors",
                    0,
                )

                municipalities = row.get(
                    "municipalities",
                    0,
                )

                try:
                    municipalities = int(
                        municipalities
                    )
                except (
                    ValueError,
                    TypeError,
                ):
                    municipalities = 0

                row_html = (
                    '<div style="display:flex;justify-content:space-between;'
                    'padding:0.7rem;border-bottom:1px solid #eee;align-items:center;">'
                    '<div>'
                    f'<strong>{name}</strong>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">{name_ar}</span>'
                    '</div>'
                    '<div>'
                    f'<span class="badge badge-blue">{int(doctors):,} doctors</span>'
                    f'<span class="badge badge-green">{municipalities} municipalities</span>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">Code: {code}</span>'
                    '</div>'
                    '</div>'
                )
                st.markdown(row_html, unsafe_allow_html=True)

            st.download_button(
                label="📥 Download Cities (CSV)",
                data=city_data.to_csv(
                    index=False
                ),
                file_name=(
                    f"cities_"
                    f"{datetime.now().strftime('%Y%m%d')}.csv"
                ),
                mime="text/csv",
            )

        else:
            st.info(
                "No city data available."
            )

    # ========================================================
    # TAB 5: Statistics
    # ========================================================

    with tab5:

        st.markdown(
            '<div class="section-title">📊 Statistics &amp; Insights</div>',
            unsafe_allow_html=True,
        )

        col1, col2 = st.columns(2)

        with col1:

            st.subheader("🏙️ Top Cities")

            if "city" in filtered_df.columns:

                city_counts = (
                    filtered_df["city"]
                    .value_counts()
                    .head(15)
                )

            else:

                city_counts = pd.Series(
                    dtype="int64"
                )

            if not city_counts.empty:

                fig = px.bar(
                    x=city_counts.values,
                    y=city_counts.index,
                    orientation="h",
                    labels={
                        "x": "Doctors",
                        "y": "",
                    },
                    color=city_counts.values,
                    color_continuous_scale="Blues",
                )

                fig.update_layout(
                    height=400,
                    showlegend=False,
                )

                st.plotly_chart(
                    fig,
                    use_container_width=True,
                )

        with col2:

            st.subheader("🏥 Top Specialties")

            if "specialty" in filtered_df.columns:

                specialty_counts = (
                    filtered_df["specialty"]
                    .value_counts()
                    .head(15)
                )

            else:

                specialty_counts = pd.Series(
                    dtype="int64"
                )

            if not specialty_counts.empty:

                fig = px.bar(
                    x=specialty_counts.values,
                    y=specialty_counts.index,
                    orientation="h",
                    labels={
                        "x": "Doctors",
                        "y": "",
                    },
                    color=specialty_counts.values,
                    color_continuous_scale="Viridis",
                )

                fig.update_layout(
                    height=400,
                    showlegend=False,
                )

                st.plotly_chart(
                    fig,
                    use_container_width=True,
                )

        st.subheader("📊 Data Completeness")

        completeness_data = []

        for field in [
            "name",
            "specialty",
            "city",
            "municipality",
            "phone",
            "email",
            "address",
            "latitude",
        ]:

            if field in df_doctors.columns:

                completeness_data.append(
                    {
                        "Field": field.title(),
                        "Complete %": (
                            df_doctors[field]
                            .notna()
                            .sum()
                            / len(df_doctors)
                            * 100
                        ),
                    }
                )

        if completeness_data:

            completeness_df = pd.DataFrame(
                completeness_data
            )

            fig = px.bar(
                completeness_df,
                x="Field",
                y="Complete %",
                color="Complete %",
                color_continuous_scale="RdYlGn",
                text=(
                    completeness_df["Complete %"]
                    .round(1)
                    .astype(str)
                    + "%"
                ),
            )

            fig.update_traces(
                textposition="outside"
            )

            fig.update_layout(
                height=400
            )

            st.plotly_chart(
                fig,
                use_container_width=True,
            )

    # ========================================================
    # TAB 6: Municipalities
    # ========================================================

    with tab6:

        st.markdown(
            '<div class="section-title">🏛️ Municipalities</div>',
            unsafe_allow_html=True,
        )

        if not df_municipalities.empty:

            if (
                "municipality_id" in df_doctors.columns
                and "municipality_id" in df_municipalities.columns
            ):
                mun_counts = (
                    df_doctors["municipality_id"]
                    .value_counts()
                    .reset_index()
                )
                mun_counts.columns = [
                    "municipality_id",
                    "doctors",
                ]

                mun_data = df_municipalities.merge(
                    mun_counts,
                    on="municipality_id",
                    how="left",
                )
            else:
                mun_data = df_municipalities.copy()
                mun_data["doctors"] = 0

            mun_data["doctors"] = (
                pd.to_numeric(
                    mun_data["doctors"],
                    errors="coerce",
                )
                .fillna(0)
                .astype(int)
            )

            mun_city_options = ["All"] + sorted(
                mun_data["wilaya_name"]
                .dropna()
                .astype(str)
                .unique()
                .tolist()
            )

            selected_mun_city = st.selectbox(
                "🏙️ Filter by City",
                mun_city_options,
                key="mun_city_filter",
            )

            if selected_mun_city != "All":
                mun_data = mun_data[
                    mun_data["wilaya_name"].astype(str)
                    == selected_mun_city
                ]

            search_mun = st.text_input(
                "🔎 Search Municipalities",
                placeholder="Name, Arabic name, or ID...",
                key="search_mun",
            )

            if search_mun:
                mun_data = search_dataframe(mun_data, search_mun)

            st.info(
                f"Showing {len(mun_data)} municipalities"
            )

            for _, row in mun_data.iterrows():

                name = safe_value(
                    row.get("municipality_name")
                )

                name_ar = safe_value(
                    row.get("municipality_name_ar")
                )

                city = safe_value(
                    row.get("wilaya_name")
                )

                code = safe_value(
                    row.get("municipality_id")
                )

                count = int(row.get("doctors", 0))

                row_html = (
                    '<div style="display:flex;justify-content:space-between;'
                    'padding:0.7rem;border-bottom:1px solid #eee;align-items:center;">'
                    '<div>'
                    f'<strong>{name}</strong>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">{name_ar}</span>'
                    f'<div style="font-size:0.8rem;color:#666;">🏙️ {city}</div>'
                    '</div>'
                    '<div>'
                    f'<span class="badge badge-blue">{count:,} doctors</span>'
                    f'<span style="font-size:0.8rem;color:#999;margin-left:0.5rem;">ID: {code}</span>'
                    '</div>'
                    '</div>'
                )
                st.markdown(row_html, unsafe_allow_html=True)

            st.markdown("---")
            col1, col2 = st.columns(2)

            with col1:
                st.download_button(
                    label="📥 Download Municipalities (CSV)",
                    data=mun_data.to_csv(index=False),
                    file_name=(
                        f"municipalities_"
                        f"{datetime.now().strftime('%Y%m%d')}.csv"
                    ),
                    mime="text/csv",
                    use_container_width=True,
                )

            with col2:
                cities_mun = df_municipalities.merge(
                    df_cities[["code", "name", "name_ar"]],
                    left_on="wilaya_code",
                    right_on="code",
                    how="left",
                    suffixes=("", "_city"),
                )
                st.download_button(
                    label="📥 Download Cities + Municipalities (CSV)",
                    data=cities_mun.to_csv(index=False),
                    file_name=(
                        f"cities_with_municipalities_"
                        f"{datetime.now().strftime('%Y%m%d')}.csv"
                    ),
                    mime="text/csv",
                    use_container_width=True,
                )

        else:
            st.info(
                "No municipality data available."
            )

    # ========================================================
    # Footer
    # ========================================================

    st.divider()

    data_updated = (
        datetime.fromtimestamp(
            os.path.getmtime(DOCTORS_CSV)
        ).strftime("%Y-%m-%d %H:%M:%S")
        if os.path.exists(DOCTORS_CSV)
        else "Never"
    )

    total_cities = (
        df_doctors["city"].nunique()
        if "city" in df_doctors.columns
        else 0
    )

    total_specialties = (
        df_doctors["specialty"].nunique()
        if "specialty" in df_doctors.columns
        else 0
    )

    total_coordinates = (
        df_doctors["latitude"].notna().sum()
        if "latitude" in df_doctors.columns
        else 0
    )

    total_municipalities = (
        df_doctors["municipality"].nunique()
        if "municipality" in df_doctors.columns
        else 0
    )

    st.caption(
        f"📅 Data Updated: {data_updated} | "
        f"📊 Total: {len(df_doctors):,} doctors | "
        f"🏙️ {total_cities} cities | "
        f"🏛️ {total_municipalities} municipalities | "
        f"🏥 {total_specialties} specialties | "
        f"📍 {total_coordinates:,} with coordinates"
    )


# ============================================================
# Entry point
# ============================================================

if __name__ == "__main__":
    main()