# scrapping/dashboard.py
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json
import requests
import numpy as np

# Page config
st.set_page_config(
    page_title="Doctors Dashboard - Algeria",
    page_icon="🏥",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        color: #2c3e50;
        text-align: center;
        margin-bottom: 2rem;
    }
    .stat-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        text-align: center;
    }
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: #2c3e50;
    }
    .dataframe-container {
        max-height: 600px;
        overflow-y: auto;
    }
    </style>
""", unsafe_allow_html=True)

# Title
st.markdown('<h1 class="main-header">🏥 Algerian Doctors Dashboard</h1>', unsafe_allow_html=True)

# Load data
@st.cache_data
def load_data():
    try:
        df = pd.read_csv('doctors.csv')
        return df
    except:
        # If CSV doesn't exist, try loading from JSON
        try:
            with open('doctors.json', 'r') as f:
                data = json.load(f)
            df = pd.DataFrame(data)
            df.to_csv('doctors.csv', index=False)
            return df
        except:
            st.error("⚠️ No data found. Please run the scraper first.")
            return None

df = load_data()

if df is not None:
    # Clean and prepare data
    # Convert numeric columns if needed
    for col in df.columns:
        if col in ['rating', 'reviews', 'price']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Display raw data info
    st.sidebar.header("📊 Data Controls")
    
    # Show data statistics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(f"""
            <div class="stat-card">
                <div>Total Doctors</div>
                <div class="stat-number">{len(df):,}</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        # Count unique specialties
        if 'specialty' in df.columns:
            specialties = df['specialty'].nunique()
            st.markdown(f"""
                <div class="stat-card">
                    <div>Specialties</div>
                    <div class="stat-number">{specialties:,}</div>
                </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
                <div class="stat-card">
                    <div>Cities</div>
                    <div class="stat-number">{df['city'].nunique() if 'city' in df.columns else 'N/A'}</div>
                </div>
            """, unsafe_allow_html=True)
    
    with col3:
        if 'city' in df.columns:
            top_city = df['city'].mode()[0]
            st.markdown(f"""
                <div class="stat-card">
                    <div>Most Common City</div>
                    <div class="stat-number">{top_city}</div>
                </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
                <div class="stat-card">
                    <div>Data Points</div>
                    <div class="stat-number">{len(df.columns)}</div>
                </div>
            """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
            <div class="stat-card">
                <div>Last Updated</div>
                <div class="stat-number" style="font-size: 1rem;">{datetime.now().strftime('%Y-%m-%d %H:%M')}</div>
            </div>
        """, unsafe_allow_html=True)
    
    st.divider()
    
    # Create tabs for different visualizations
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "📊 Overview", 
        "📍 Geographic", 
        "🏥 Specialties", 
        "📈 Analytics",
        "🔍 Data Explorer",
        "📋 Full Dataset"
    ])
    
    with tab1:
        st.header("📊 Overview Dashboard")
        
        # Show data info
        st.subheader(f"Dataset Overview - {len(df):,} Doctors")
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Records", f"{len(df):,}")
            st.metric("Total Columns", len(df.columns))
        with col2:
            st.metric("Missing Values", f"{df.isnull().sum().sum():,}")
            st.metric("Memory Usage", f"{df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
        
        # Basic statistics
        st.subheader("Data Types & Missing Values")
        info_df = pd.DataFrame({
            'Column': df.columns,
            'Data Type': df.dtypes.astype(str),
            'Non-Null': df.count().values,
            'Null': df.isnull().sum().values,
            'Null %': (df.isnull().sum() / len(df) * 100).round(2).values
        })
        st.dataframe(info_df, use_container_width=True)
        
        # Show first few rows of raw data
        st.subheader("Sample of Raw Data (First 10 Rows)")
        st.dataframe(df.head(10), use_container_width=True)
    
    with tab2:
        st.header("📍 Geographic Distribution")
        
        if 'city' in df.columns:
            # City distribution
            city_counts = df['city'].value_counts()
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Top cities bar chart
                top_cities = city_counts.head(20)
                fig = px.bar(
                    x=top_cities.values,
                    y=top_cities.index,
                    orientation='h',
                    title=f'Top 20 Cities by Doctor Count (Total: {len(df):,} doctors)',
                    labels={'x': 'Number of Doctors', 'y': 'City'},
                    color=top_cities.values,
                    color_continuous_scale='blues',
                    text=top_cities.values
                )
                fig.update_traces(textposition='outside')
                fig.update_layout(height=600)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Show city statistics
                st.subheader("City Statistics")
                city_stats = pd.DataFrame({
                    'City': city_counts.index[:20],
                    'Doctors': city_counts.values[:20],
                    'Percentage': (city_counts.values[:20] / len(df) * 100).round(2)
                })
                st.dataframe(city_stats, use_container_width=True)
                
                # Show all cities in a table
                with st.expander("Show All Cities"):
                    all_cities = pd.DataFrame({
                        'City': city_counts.index,
                        'Doctors': city_counts.values,
                        'Percentage': (city_counts.values / len(df) * 100).round(2)
                    })
                    st.dataframe(all_cities, use_container_width=True)
        else:
            st.info("City data not available")
    
    with tab3:
        st.header("🏥 Specialty Analysis")
        
        if 'specialty' in df.columns:
            # Top specialties
            specialty_counts = df['specialty'].value_counts()
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Top specialties bar chart
                top_specialties = specialty_counts.head(15)
                fig = px.bar(
                    x=top_specialties.values,
                    y=top_specialties.index,
                    orientation='h',
                    title=f'Top 15 Specialties (Total: {len(df):,} doctors)',
                    labels={'x': 'Number of Doctors', 'y': 'Specialty'},
                    color=top_specialties.values,
                    color_continuous_scale='viridis',
                    text=top_specialties.values
                )
                fig.update_traces(textposition='outside')
                fig.update_layout(height=600)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Pie chart
                fig = px.pie(
                    values=top_specialties.head(10).values,
                    names=top_specialties.head(10).index,
                    title='Specialty Distribution (Top 10)'
                )
                fig.update_layout(height=500)
                st.plotly_chart(fig, use_container_width=True)
            
            # Show all specialties
            with st.expander("Show All Specialties"):
                all_specialties = pd.DataFrame({
                    'Specialty': specialty_counts.index,
                    'Doctors': specialty_counts.values,
                    'Percentage': (specialty_counts.values / len(df) * 100).round(2)
                })
                st.dataframe(all_specialties, use_container_width=True)
                
                # Download all specialties
                csv = all_specialties.to_csv(index=False)
                st.download_button(
                    label="📥 Download All Specialties as CSV",
                    data=csv,
                    file_name="all_specialties.csv",
                    mime="text/csv"
                )
        else:
            st.info("Specialty data not available")
    
    with tab4:
        st.header("📈 Analytics")
        
        # Rating distribution if available
        if 'rating' in df.columns and df['rating'].notna().any():
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.histogram(
                    df['rating'].dropna(),
                    nbins=20,
                    title='Rating Distribution',
                    labels={'value': 'Rating', 'count': 'Number of Doctors'},
                    color_discrete_sequence=['blue']
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Rating statistics
                rating_stats = df['rating'].describe()
                st.subheader("Rating Statistics")
                st.dataframe(pd.DataFrame(rating_stats).T, use_container_width=True)
        
        # Show correlations if numeric columns exist
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
        if len(numeric_cols) > 1:
            st.subheader("Correlation Matrix")
            corr = df[numeric_cols].corr()
            fig = px.imshow(
                corr,
                text_auto=True,
                title='Correlation Matrix of Numeric Features',
                color_continuous_scale='RdBu_r',
                aspect='auto'
            )
            fig.update_layout(height=600)
            st.plotly_chart(fig, use_container_width=True)
        
        # Data quality report
        st.subheader("Data Quality Report")
        quality_df = pd.DataFrame({
            'Column': df.columns,
            'Missing %': (df.isnull().sum() / len(df) * 100).round(2),
            'Unique Values': df.nunique(),
            'Most Common': [df[col].mode().iloc[0] if not df[col].mode().empty else 'N/A' for col in df.columns],
            'Most Common Count': [df[col].value_counts().iloc[0] if not df[col].value_counts().empty else 0 for col in df.columns]
        })
        st.dataframe(quality_df, use_container_width=True)
    
    with tab5:
        st.header("🔍 Data Explorer")
        
        # Filters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if 'city' in df.columns:
                city_filter = st.multiselect(
                    "Filter by City",
                    options=sorted(df['city'].unique()),
                    default=[]
                )
            else:
                city_filter = []
        
        with col2:
            if 'specialty' in df.columns:
                specialty_filter = st.multiselect(
                    "Filter by Specialty",
                    options=sorted(df['specialty'].unique()),
                    default=[]
                )
            else:
                specialty_filter = []
        
        with col3:
            if 'rating' in df.columns:
                rating_min = float(df['rating'].min()) if not pd.isna(df['rating'].min()) else 0
                rating_max = float(df['rating'].max()) if not pd.isna(df['rating'].max()) else 5
                rating_filter = st.slider(
                    "Minimum Rating",
                    min_value=0.0,
                    max_value=5.0,
                    value=0.0,
                    step=0.1
                )
            else:
                rating_filter = 0
        
        # Apply filters
        filtered_df = df.copy()
        if city_filter:
            filtered_df = filtered_df[filtered_df['city'].isin(city_filter)]
        if specialty_filter:
            filtered_df = filtered_df[filtered_df['specialty'].isin(specialty_filter)]
        if 'rating' in df.columns:
            filtered_df = filtered_df[filtered_df['rating'] >= rating_filter]
        
        st.subheader(f"Filtered Data: {len(filtered_df):,} records out of {len(df):,}")
        
        # Show filtered data
        st.dataframe(filtered_df, use_container_width=True, height=400)
        
        # Download filtered data
        col1, col2 = st.columns(2)
        with col1:
            csv = filtered_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Filtered Data as CSV",
                data=csv,
                file_name=f"filtered_doctors_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
        
        with col2:
            # Show summary of filtered data
            st.json({
                "Total Records": len(filtered_df),
                "Columns": len(filtered_df.columns),
                "Unique Cities": filtered_df['city'].nunique() if 'city' in filtered_df.columns else 0,
                "Unique Specialties": filtered_df['specialty'].nunique() if 'specialty' in filtered_df.columns else 0,
                "Average Rating": round(filtered_df['rating'].mean(), 2) if 'rating' in filtered_df.columns else 'N/A'
            })
    
    with tab6:
        st.header("📋 Full Dataset")
        
        # Search functionality
        st.subheader("Search & Browse Full Dataset")
        
        # Search box
        search_term = st.text_input("🔍 Search across all columns:", placeholder="Type to search...")
        
        if search_term:
            # Search across all columns
            mask = df.astype(str).apply(lambda x: x.str.contains(search_term, case=False, na=False)).any(axis=1)
            search_df = df[mask]
            st.info(f"Found {len(search_df):,} matching records")
            st.dataframe(search_df, use_container_width=True, height=500)
        else:
            # Show all data with pagination
            page_size = st.selectbox("Rows per page:", [50, 100, 200, 500, 1000], index=1)
            total_pages = max(1, (len(df) + page_size - 1) // page_size)
            page = st.number_input("Page", min_value=1, max_value=total_pages, value=1)
            
            start_idx = (page - 1) * page_size
            end_idx = min(start_idx + page_size, len(df))
            
            st.info(f"Showing rows {start_idx + 1} to {end_idx} of {len(df):,} total rows")
            st.dataframe(df.iloc[start_idx:end_idx], use_container_width=True, height=500)
        
        # Export full dataset
        st.subheader("Export Full Dataset")
        col1, col2 = st.columns(2)
        with col1:
            csv_full = df.to_csv(index=False)
            st.download_button(
                label="📥 Download Full Dataset as CSV",
                data=csv_full,
                file_name=f"full_doctors_dataset_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
                use_container_width=True
            )
        
        with col2:
            # Show dataset statistics
            st.metric("Total Size", f"{df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

    # Data refresh section
    st.sidebar.divider()
    st.sidebar.header("🔄 Data Management")
    
    if st.sidebar.button("🔄 Refresh Data (Scrape New)"):
        with st.spinner("Scraping new data..."):
            try:
                import subprocess
                import sys
                subprocess.run([sys.executable, "machrou3.py"], check=True)
                subprocess.run([sys.executable, "json_to_csv.py"], check=True)
                st.success("✅ Data refreshed successfully!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error refreshing data: {e}")
    
    if st.sidebar.button("📊 Show Raw JSON Sample"):
        try:
            with open('doctors.json', 'r') as f:
                data = json.load(f)
            st.sidebar.json(data[:3])
        except:
            st.sidebar.error("No JSON file found")
    
    # Footer
    st.sidebar.divider()
    st.sidebar.caption("Built with Streamlit | Doctors Data from machrou3.com")
    st.sidebar.caption(f"Total Records: {len(df):,}")

else:
    st.warning("""
    ### No data available
    
    Please run the scraper first:
    1. Make sure you have Python installed
    2. Run the scraper: `python3 machrou3.py`
    3. Convert to CSV: `python3 json_to_csv.py`
    4. Refresh this dashboard
    """)

# Additional requirements file
requirements = """
streamlit>=1.25.0
pandas>=2.0.0
plotly>=5.14.0
matplotlib>=3.7.0
seaborn>=0.12.0
requests>=2.28.0
numpy>=1.24.0
"""

# Create a requirements.txt
with open('requirements.txt', 'w') as f:
    f.write(requirements)