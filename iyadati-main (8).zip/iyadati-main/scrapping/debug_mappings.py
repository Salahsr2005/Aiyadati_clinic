# scrapping/debug_mappings.py
import requests
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def debug_specialties():
    """Debug specialties API response"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Data type: {type(data)}")
            print(f"Data length: {len(data) if isinstance(data, list) else 'not a list'}")
            
            if data and isinstance(data, list):
                print("\n📋 First 3 records structure:")
                for i, item in enumerate(data[:3]):
                    print(f"\nRecord {i+1}:")
                    print(f"  Keys: {list(item.keys())}")
                    print(f"  Content: {json.dumps(item, indent=2, ensure_ascii=False)[:500]}")
        else:
            print(f"Response: {response.text[:500]}")
            
    except Exception as e:
        print(f"Error: {e}")

def debug_wilayas():
    """Debug wilayas API response"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getBaladiya4appdoc"
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Data type: {type(data)}")
            print(f"Data length: {len(data) if isinstance(data, list) else 'not a list'}")
            
            if data and isinstance(data, list):
                print("\n📋 First 3 records structure:")
                for i, item in enumerate(data[:3]):
                    print(f"\nRecord {i+1}:")
                    print(f"  Keys: {list(item.keys())}")
                    print(f"  Content: {json.dumps(item, indent=2, ensure_ascii=False)[:500]}")
        else:
            print(f"Response: {response.text[:500]}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("=" * 50)
    print("🔍 DEBUGGING SPECIALTIES")
    print("=" * 50)
    debug_specialties()
    
    print("\n" + "=" * 50)
    print("🔍 DEBUGGING WILAYAS")
    print("=" * 50)
    debug_wilayas()