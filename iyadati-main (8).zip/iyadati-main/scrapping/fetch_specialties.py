# scrapping/fetch_specialties.py
import requests
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_specialties():
    """Fetch specialties from the API"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "Sec-Ch-Ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Brave";v="144"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Linux"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "Sec-Gpc": "1",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    
    try:
        logger.info("📥 Fetching specialties data...")
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"✅ Successfully fetched {len(data) if isinstance(data, list) else 'data'} specialties")
            
            # Save raw data
            with open('data/raw/specialties_raw.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            # Parse and structure
            specialties = parse_specialties(data)
            
            # Save structured data
            with open('data/mappings/specialties.json', 'w', encoding='utf-8') as f:
                json.dump(specialties, f, ensure_ascii=False, indent=2)
            
            logger.info(f"✅ Saved {len(specialties)} specialties to data/mappings/specialties.json")
            
            # Print sample
            print("\n📋 Sample Specialties:")
            for code, info in list(specialties.items())[:10]:
                print(f"  {code}: {info['name']}")
            
            return specialties
        else:
            logger.error(f"❌ Failed to fetch specialties: Status {response.status_code}")
            logger.info(f"Response: {response.text[:200]}")
            
            # Try the alternative endpoint
            return fetch_specialties_alternative()
            
    except Exception as e:
        logger.error(f"❌ Error fetching specialties: {e}")
        return fetch_specialties_alternative()

def fetch_specialties_alternative():
    """Try alternative approach to get specialties"""
    logger.info("🔄 Trying alternative method...")
    
    # Try with different headers
    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code == 200:
            data = response.json()
            logger.info(f"✅ Alternative method worked! Fetched {len(data)} specialties")
            return parse_specialties(data)
    except:
        pass
    
    # If all fails, use fallback mapping
    logger.warning("⚠️ Using fallback specialty mapping")
    return create_fallback_specialties()

def parse_specialties(data: List[Dict]) -> Dict:
    """Parse specialties data from API"""
    specialties = {}
    
    for item in data:
        # Try different possible field names
        code = None
        name = None
        
        # Find code
        for field in ['Num_sp', 'code', 'id', 'specialty_id']:
            if field in item and item[field]:
                code = str(item[field]).zfill(2)
                break
        
        # Find name
        for field in ['Name_sp', 'name', 'specialty_name', 'label']:
            if field in item and item[field]:
                name = str(item[field]).strip()
                break
        
        if code:
            specialties[code] = {
                'code': code,
                'name': name or f"Spécialité {code}",
                'raw': item
            }
    
    return specialties

def create_fallback_specialties():
    """Create fallback specialty mapping"""
    fallback = {
        '01': 'Médecine Générale',
        '02': 'Cardiologie',
        '03': 'Dermatologie',
        '04': 'Endocrinologie',
        '05': 'Gastro-entérologie',
        '06': 'Gynécologie',
        '07': 'Hématologie',
        '08': 'Néphrologie',
        '09': 'Neurologie',
        '10': 'Ophtalmologie',
        '11': 'Orthopédie',
        '12': 'ORL',
        '13': 'Pédiatrie',
        '14': 'Pneumologie',
        '15': 'Psychiatrie',
        '16': 'Rhumatologie',
        '17': 'Urologie',
        '18': 'Chirurgie générale',
        '19': 'Anesthésie',
        '20': 'Radiologie',
        '21': 'Biologie',
        '22': 'Pharmacie',
        '23': 'Dentiste',
        '24': 'Kinésithérapie',
        '25': 'Nutrition',
        '26': 'Dermatologue',
        '27': 'Allergologie',
        '28': 'Médecine du travail',
        '29': 'Médecine légale',
        '30': 'Chirurgie maxillo-faciale',
        '31': 'Neurochirurgie',
        '32': 'Chirurgie cardiaque',
        '33': 'Chirurgie pédiatrique',
        '34': 'Chirurgie vasculaire',
        '35': 'Chirurgie thoracique',
        '36': 'Chirurgie digestive',
        '37': 'Chirurgie cancérologique',
        '38': 'Imagerie médicale',
        '39': 'Médecine nucléaire',
        '40': 'Autre'
    }
    
    specialties = {}
    for code, name in fallback.items():
        specialties[code] = {
            'code': code,
            'name': name
        }
    
    # Save fallback
    with open('data/mappings/specialties_fallback.json', 'w', encoding='utf-8') as f:
        json.dump(specialties, f, ensure_ascii=False, indent=2)
    
    return specialties

if __name__ == "__main__":
    # Create directories
    import os
    os.makedirs('data/raw', exist_ok=True)
    os.makedirs('data/mappings', exist_ok=True)
    
    fetch_specialties()