# scrapping/dashboard_enhanced.py
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json
import numpy as np

st.set_page_config(
    page_title="Doctors Dashboard - Algeria",
    page_icon="🏥",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        color: #2c3e50;
        text-align: center;
        margin-bottom: 1rem;
    }
    .stat-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: #2c3e50;
    }
    .stat-label {
        font-size: 0.9rem;
        color: #7f8c8d;
    }
    .doctor-card {
        background-color: white;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #3498db;
        margin-bottom: 0.5rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .doctor-card:hover {
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .doctor-name {
        font-weight: bold;
        color: #2c3e50;
        font-size: 1.1rem;
    }
    .doctor-detail {
        color: #7f8c8d;
        font-size: 0.9rem;
    }
    .filter-section {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    .list-item {
        padding: 0.5rem;
        border-bottom: 1px solid #ecf0f1;
        cursor: pointer;
        transition: background-color 0.2s;
    }
    .list-item:hover {
        background-color: #e8f4f8;
    }
    .list-item.active {
        background-color: #3498db;
        color: white;
    }
    .badge {
        background-color: #3498db;
        color: white;
        padding: 0.2rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        margin-left: 0.5rem;
    }
    .badge-secondary {
        background-color: #95a5a6;
    }
    </style>
""", unsafe_allow_html=True)

# Load data
@st.cache_data
def load_data():
    """Load the enhanced doctor data"""
    try:
        df = pd.read_csv('data/processed/doctors_enhanced.csv')
        return df
    except:
        try:
            # Try alternative location
            df = pd.read_csv('doctors_enhanced_v2.csv')
            return df
        except:
            try:
                with open('doctors_enhanced_v2.json', 'r') as f:
                    data = json.load(f)
                df = pd.DataFrame(data)
                return df
            except:
                st.error("⚠️ No data found. Please run the pipeline first.")
                return None

@st.cache_data
def load_mappings():
    """Load mappings for specialties and wilayas"""
    try:
        with open('data/mappings/mappings.json', 'r') as f:
            return json.load(f)
    except:
        return {'specialties': {}, 'wilayas': {}}

df = load_data()
mappings = load_mappings()
specialties_map = mappings.get('specialties', {})
wilayas_map = mappings.get('wilayas', {})

if df is not None:
    # Create a clean city name mapping
    city_map = {}
    for code, info in wilayas_map.items():
        city_map[code] = info.get('name', f"Wilaya {code}")
    
    # Convert wilaya_code to city name if not already
    if 'wilaya_code' in df.columns and 'city' in df.columns:
        # If city is still a code, map it
        df['city_display'] = df['wilaya_code'].map(city_map)
        df['city_display'] = df['city_display'].fillna(df['city'])
    else:
        df['city_display'] = df.get('city', 'Unknown')
    
    # Clean specialty names
    if 'specialty_code' in df.columns and 'specialty' in df.columns:
        # If specialty is still a code, use the mapped name
        df['specialty_display'] = df['specialty_code'].map(
            {k: v.get('name', '') for k, v in specialties_map.items()}
        )
        df['specialty_display'] = df['specialty_display'].fillna(df['specialty'])
        # Replace the specialty column with display name
        df['specialty'] = df['specialty_display']
    
    st.markdown('<h1 class="main-header">🏥 Doctors Dashboard - Algeria</h1>', unsafe_allow_html=True)
    
    # Statistics
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{len(df):,}</div>
                <div class="stat-label">Total Doctors</div>
            </div>
        """, unsafe_allow_html=True)
    with col2:
        cities = df['city_display'].nunique() if 'city_display' in df.columns else df['city'].nunique()
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{cities}</div>
                <div class="stat-label">Cities/Wilayas</div>
            </div>
        """, unsafe_allow_html=True)
    with col3:
        specialties = df['specialty'].nunique() if 'specialty' in df.columns else 0
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{specialties}</div>
                <div class="stat-label">Specialties</div>
            </div>
        """, unsafe_allow_html=True)
    with col4:
        with_coords = df['latitude'].notna().sum() if 'latitude' in df.columns else 0
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{with_coords:,}</div>
                <div class="stat-label">With Coordinates</div>
            </div>
        """, unsafe_allow_html=True)
    with col5:
        with_phone = df['phone'].notna().sum() if 'phone' in df.columns else 0
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{with_phone:,}</div>
                <div class="stat-label">With Phone</div>
            </div>
        """, unsafe_allow_html=True)
    
    st.divider()
    
    # Main layout: Sidebar filters + Main content
    st.sidebar.header("🔍 Filters")
    
    # Initialize session state for selected items
    if 'selected_city' not in st.session_state:
        st.session_state.selected_city = None
    if 'selected_specialty' not in st.session_state:
        st.session_state.selected_specialty = None
    
    # ---- SIDEBAR FILTERS ----
    
    # Search box
    search_query = st.sidebar.text_input("🔎 Search Doctor", placeholder="Name, address, phone...")
    
    # City filter
    st.sidebar.subheader("🏙️ Cities")
    city_options = ['All'] + sorted(df['city_display'].unique().tolist()) if 'city_display' in df.columns else ['All']
    
    # Display as clickable list in sidebar
    selected_city = st.sidebar.selectbox(
        "Select City",
        options=city_options,
        index=0
    )
    
    # Specialty filter
    st.sidebar.subheader("🏥 Specialties")
    specialty_options = ['All'] + sorted(df['specialty'].dropna().unique().tolist()) if 'specialty' in df.columns else ['All']
    
    selected_specialty = st.sidebar.selectbox(
        "Select Specialty",
        options=specialty_options,
        index=0
    )
    
    # Additional filters
    st.sidebar.subheader("📞 Contact")
    has_phone = st.sidebar.checkbox("Has Phone Number", value=False)
    has_email = st.sidebar.checkbox("Has Email", value=False)
    
    # Rating filter if available
    if 'rating' in df.columns:
        st.sidebar.subheader("⭐ Rating")
        min_rating = st.sidebar.slider(
            "Minimum Rating",
            min_value=0.0,
            max_value=5.0,
            value=0.0,
            step=0.5
        )
    else:
        min_rating = 0
    
    # Apply filters
    filtered_df = df.copy()
    
    if search_query:
        mask = filtered_df.astype(str).apply(
            lambda x: x.str.contains(search_query, case=False, na=False)
        ).any(axis=1)
        filtered_df = filtered_df[mask]
    
    if selected_city != 'All' and 'city_display' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['city_display'] == selected_city]
    
    if selected_specialty != 'All' and 'specialty' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['specialty'] == selected_specialty]
    
    if has_phone and 'phone' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['phone'].notna()]
    
    if has_email and 'email' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['email'].notna()]
    
    if 'rating' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['rating'].fillna(0) >= min_rating]
    
    # ---- MAIN CONTENT ----
    
    # Show filter summary
    st.info(f"📊 Showing {len(filtered_df):,} doctors out of {len(df):,}")
    
    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🗺️ Map View",
        "📋 Doctors List",
        "📊 Statistics",
        "🏥 Specialties & Cities"
    ])
    
    with tab1:
        st.header("🗺️ Doctor Locations")
        
        if 'latitude' in filtered_df.columns and 'longitude' in filtered_df.columns:
            map_df = filtered_df[filtered_df['latitude'].notna() & filtered_df['longitude'].notna()]
            
            if len(map_df) > 0:
                # Create hover data
                hover_data = {}
                if 'city_display' in map_df.columns:
                    hover_data['City'] = map_df['city_display']
                if 'specialty' in map_df.columns:
                    hover_data['Specialty'] = map_df['specialty']
                if 'phone' in map_df.columns:
                    hover_data['Phone'] = map_df['phone']
                if 'address' in map_df.columns:
                    hover_data['Address'] = map_df['address']
                
                fig = px.scatter_map(
                    map_df,
                    lat='latitude',
                    lon='longitude',
                    hover_name='name' if 'name' in map_df.columns else None,
                    hover_data=hover_data,
                    color='specialty' if 'specialty' in map_df.columns else None,
                    zoom=5,
                    height=600,
                    title='📍 Doctor Locations in Algeria'
                )
                
                fig.update_layout(
                    map_style="open-street-map",
                    margin={"r":0,"t":50,"l":0,"b":0},
                    legend=dict(
                        yanchor="top",
                        y=0.99,
                        xanchor="left",
                        x=0.01
                    )
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("No doctors with coordinates in the filtered results")
        else:
            st.warning("Latitude/Longitude data not available")
    
    with tab2:
        st.header("📋 Doctors List")
        
        # Display doctors as cards
        cols_per_row = 2
        cols = st.columns(cols_per_row)
        
        for i, (idx, row) in enumerate(filtered_df.iterrows()):
            col = cols[i % cols_per_row]
            
            with col:
                with st.container():
                    st.markdown(f"""
                        <div class="doctor-card">
                            <div class="doctor-name">{row.get('name', 'Unknown')}</div>
                            <div class="doctor-detail">🏥 {row.get('specialty', 'N/A')}</div>
                            <div class="doctor-detail">📍 {row.get('city_display', row.get('city', 'N/A'))}</div>
                            <div class="doctor-detail">📞 {row.get('phone', 'No phone')}</div>
                            <div class="doctor-detail">✉️ {row.get('email', 'No email')}</div>
                            <div class="doctor-detail" style="font-size:0.8rem;color:#95a5a6;">
                                ID: {row.get('id', 'N/A')}
                            </div>
                        </div>
                    """, unsafe_allow_html=True)
        
        # Show number of doctors
        st.caption(f"Showing {len(filtered_df)} doctors")
        
        # Option to expand to table view
        with st.expander("📊 View as Table"):
            display_cols = ['name', 'specialty', 'city_display', 'phone', 'email', 'address']
            available_cols = [col for col in display_cols if col in filtered_df.columns]
            st.dataframe(filtered_df[available_cols], use_container_width=True)
        
        # Export button
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Filtered Data as CSV",
            data=csv,
            file_name=f"doctors_filtered_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv"
        )
    
    with tab3:
        st.header("📊 Statistics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # City distribution
            st.subheader("🏙️ City Distribution")
            city_counts = filtered_df['city_display'].value_counts().head(15)
            fig = px.bar(
                x=city_counts.values,
                y=city_counts.index,
                orientation='h',
                labels={'x': 'Doctors', 'y': 'City'},
                color=city_counts.values,
                color_continuous_scale='Blues'
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Specialty distribution
            st.subheader("🏥 Specialty Distribution")
            specialty_counts = filtered_df['specialty'].value_counts().head(15)
            fig = px.bar(
                x=specialty_counts.values,
                y=specialty_counts.index,
                orientation='h',
                labels={'x': 'Doctors', 'y': 'Specialty'},
                color=specialty_counts.values,
                color_continuous_scale='Viridis'
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        # Data completeness
        st.subheader("📊 Data Completeness")
        completeness = pd.DataFrame({
            'Field': ['Name', 'Specialty', 'City', 'Address', 'Phone', 'Email', 'Coordinates'],
            'Available': [
                filtered_df['name'].notna().sum(),
                filtered_df['specialty'].notna().sum() if 'specialty' in filtered_df.columns else 0,
                filtered_df['city_display'].notna().sum(),
                filtered_df['address'].notna().sum() if 'address' in filtered_df.columns else 0,
                filtered_df['phone'].notna().sum() if 'phone' in filtered_df.columns else 0,
                filtered_df['email'].notna().sum() if 'email' in filtered_df.columns else 0,
                filtered_df['latitude'].notna().sum() if 'latitude' in filtered_df.columns else 0
            ],
            'Percentage': [
                filtered_df['name'].notna().sum()/len(filtered_df)*100,
                filtered_df['specialty'].notna().sum()/len(filtered_df)*100 if 'specialty' in filtered_df.columns else 0,
                filtered_df['city_display'].notna().sum()/len(filtered_df)*100,
                filtered_df['address'].notna().sum()/len(filtered_df)*100 if 'address' in filtered_df.columns else 0,
                filtered_df['phone'].notna().sum()/len(filtered_df)*100 if 'phone' in filtered_df.columns else 0,
                filtered_df['email'].notna().sum()/len(filtered_df)*100 if 'email' in filtered_df.columns else 0,
                filtered_df['latitude'].notna().sum()/len(filtered_df)*100 if 'latitude' in filtered_df.columns else 0
            ]
        })
        
        fig = px.bar(
            completeness,
            x='Field',
            y='Percentage',
            title='Data Completeness',
            color='Percentage',
            color_continuous_scale='Viridis',
            text=completeness['Percentage'].round(1).astype(str) + '%'
        )
        fig.update_traces(textposition='outside')
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.header("🏥 Specialties & Cities")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🏥 All Specialties")
            specialty_counts = df['specialty'].value_counts()
            
            # Display as a list with counts
            for specialty, count in specialty_counts.items():
                st.markdown(f"""
                    <div class="list-item">
                        {specialty} <span class="badge">{count:,}</span>
                    </div>
                """, unsafe_allow_html=True)
            
            # Download button for specialties
            specialty_df = pd.DataFrame({
                'Specialty': specialty_counts.index,
                'Doctors': specialty_counts.values,
                'Percentage': (specialty_counts.values / len(df) * 100).round(2)
            })
            csv = specialty_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Specialties",
                data=csv,
                file_name="specialties_list.csv",
                mime="text/csv"
            )
        
        with col2:
            st.subheader("🏙️ All Cities")
            city_counts = df['city_display'].value_counts()
            
            # Display as a list with counts
            for city, count in city_counts.items():
                st.markdown(f"""
                    <div class="list-item">
                        {city} <span class="badge">{count:,}</span>
                    </div>
                """, unsafe_allow_html=True)
            
            # Download button for cities
            city_df = pd.DataFrame({
                'City': city_counts.index,
                'Doctors': city_counts.values,
                'Percentage': (city_counts.values / len(df) * 100).round(2)
            })
            csv = city_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Cities",
                data=csv,
                file_name="cities_list.csv",
                mime="text/csv"
            )
    
    # Footer
    st.divider()
    st.caption(f"🔄 Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 📊 Total records: {len(df):,} | 🏥 Data from machrou3.com")
    
else:
    st.warning("""
    ### ⚠️ No data available
    
    Please run the pipeline first:
    
    ```bash
    # Activate virtual environment
    source .venv/bin/activate
    
    # Fetch mappings
    python3 fetch_mappings_fixed.py
    
    # Scrape doctors with mappings
    python3 machrou3_with_mappings.py
    
    # Convert to CSV
    python3 convert_fixed.py
    
    # Launch dashboard
    streamlit run dashboard_enhanced.py
""")

