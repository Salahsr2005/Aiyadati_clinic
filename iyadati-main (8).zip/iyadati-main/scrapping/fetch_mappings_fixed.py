# scrapping/fetch_mappings_fixed.py
import requests
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_specialties():
    """Fetch specialties from the API - FIXED with correct field names"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    
    try:
        logger.info("📥 Fetching specialties...")
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"✅ Fetched {len(data)} records")
            
            # Save raw for debugging
            with open('data/raw/specialties_raw.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            # Parse specialties - USING CORRECT FIELD NAMES
            specialties = {}
            for item in data:
                # The API uses lowercase fields: num_sp, name_sp, name_spfr
                code = str(item.get('num_sp', '')).zfill(2) if item.get('num_sp') else None
                name_ar = item.get('name_sp', '')
                name_fr = item.get('name_spfr', '')
                
                if code:
                    specialties[code] = {
                        'code': code,
                        'name': name_fr or name_ar or f"Specialty {code}",
                        'name_ar': name_ar,
                        'name_fr': name_fr,
                        'order': item.get('ordersp', ''),
                        'raw': item
                    }
            
            logger.info(f"✅ Parsed {len(specialties)} specialties")
            
            # Save structured
            with open('data/mappings/specialties.json', 'w', encoding='utf-8') as f:
                json.dump(specialties, f, ensure_ascii=False, indent=2)
            
            # Print sample
            if specialties:
                print("\n📋 Sample Specialties:")
                for code, info in list(specialties.items())[:10]:
                    print(f"  {code}: {info['name']} ({info['name_ar']})")
            
            return specialties
        else:
            logger.error(f"❌ Failed: Status {response.status_code}")
            return {}
            
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return {}

def fetch_wilayas():
    """Fetch wilayas from the API - FIXED with correct field names"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getBaladiya4appdoc"
    
    try:
        logger.info("📥 Fetching wilayas...")
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"✅ Fetched {len(data)} records")
            
            # Save raw for debugging
            with open('data/raw/wilayas_raw.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            # Parse wilayas - USING CORRECT FIELD NAMES
            wilayas = {}
            for item in data:
                # The API uses: MatWilaya, NOM, Nomfr
                wilaya_code = str(item.get('MatWilaya', '')).zfill(2) if item.get('MatWilaya') else None
                name_ar = item.get('NOM', '')
                name_fr = item.get('Nomfr', '')
                is_capital = item.get('wlycaptal') == '1'
                
                if wilaya_code:
                    # Group by wilaya code - multiple records per wilaya (each baladiya)
                    if wilaya_code not in wilayas:
                        wilayas[wilaya_code] = {
                            'code': wilaya_code,
                            'name': name_fr or name_ar or f"Wilaya {wilaya_code}",
                            'name_ar': name_ar,
                            'name_fr': name_fr,
                            'baladyat': [],
                            'baladyat_count': 0
                        }
                    
                    # Add baladiya if it's not the wilaya capital entry
                    if not is_capital and name_ar:
                        wilayas[wilaya_code]['baladyat'].append({
                            'id': item.get('ID', ''),
                            'name_ar': name_ar,
                            'name_fr': name_fr
                        })
            
            # Update counts
            for code, info in wilayas.items():
                info['baladyat_count'] = len(info['baladyat'])
            
            logger.info(f"✅ Parsed {len(wilayas)} wilayas with municipalities")
            
            # Save structured
            with open('data/mappings/wilayas.json', 'w', encoding='utf-8') as f:
                json.dump(wilayas, f, ensure_ascii=False, indent=2)
            
            # Print sample
            if wilayas:
                print("\n📋 Sample Wilayas:")
                for code, info in list(wilayas.items())[:5]:
                    print(f"  {code}: {info['name']} ({info['baladyat_count']} municipalities)")
            
            return wilayas
        else:
            logger.error(f"❌ Failed: Status {response.status_code}")
            return {}
            
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return {}

def main():
    """Main function"""
    import os
    os.makedirs('data/raw', exist_ok=True)
    os.makedirs('data/mappings', exist_ok=True)
    
    print("=" * 50)
    print("🚀 Fetching Mappings")
    print("=" * 50)
    
    specialties = fetch_specialties()
    wilayas = fetch_wilayas()
    
    print("\n" + "=" * 50)
    print("📊 SUMMARY")
    print("=" * 50)
    print(f"Specialties: {len(specialties)}")
    print(f"Wilayas: {len(wilayas)}")
    
    # Save combined mappings
    mappings = {
        'specialties': specialties,
        'wilayas': wilayas,
        'fetched_at': datetime.now().isoformat()
    }
    
    with open('data/mappings/mappings.json', 'w', encoding='utf-8') as f:
        json.dump(mappings, f, ensure_ascii=False, indent=2)
    
    print("✅ All mappings saved to data/mappings/mappings.json")
    
    # Show some examples
    if specialties:
        print("\n📋 Example Specialties:")
        for code, info in list(specialties.items())[:5]:
            print(f"  {code}: {info['name']}")
    
    if wilayas:
        print("\n📋 Example Wilayas:")
        for code, info in list(wilayas.items())[:5]:
            print(f"  {code}: {info['name']}")

if __name__ == "__main__":
    main()

