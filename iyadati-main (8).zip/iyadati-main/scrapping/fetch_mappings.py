# scrapping/fetch_mappings.py
import requests
import json
import logging
from typing import Dict, List, Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_with_headers(url: str, headers: Dict) -> Any:
    """Fetch data with proper headers"""
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Failed to fetch {url}: Status {response.status_code}")
            return None
    except Exception as e:
        logger.error(f"Error fetching {url}: {e}")
        return None

def fetch_wilayas_and_baladyat():
    """Fetch wilayas and municipalities"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    # Try to get wilayas and baladyat
    url = "https://doctorsdz.machrou3.com/user/getBaladiya4appdoc"
    data = fetch_with_headers(url, headers)
    
    if data:
        logger.info(f"✅ Successfully fetched wilayas and baladyat data")
        # Save the raw data
        with open('wilayas_baladyat_raw.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        # Parse and structure the data
        structured = parse_wilayas_baladyat(data)
        with open('wilayas_baladyat.json', 'w', encoding='utf-8') as f:
            json.dump(structured, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✅ Saved structured wilayas data")
        return structured
    else:
        # Fallback: Create mapping from our existing data
        logger.warning("Could not fetch wilayas data, creating from existing data...")
        return create_wilayas_from_existing()

def parse_wilayas_baladyat(data: List[Dict]) -> Dict:
    """Parse and structure wilayas and baladyat data"""
    wilayas = {}
    
    for item in data:
        wilaya_code = str(item.get('Num_wilaya', '')).zfill(2)
        wilaya_name = item.get('Wilaya_name', '')
        baladyat = item.get('Baladyat', [])
        
        if wilaya_code and wilaya_name:
            wilayas[wilaya_code] = {
                'code': wilaya_code,
                'name': wilaya_name,
                'baladyat': baladyat if isinstance(baladyat, list) else []
            }
    
    return wilayas

def create_wilayas_from_existing():
    """Create wilaya mapping from doctors data if available"""
    try:
        with open('doctors.json', 'r') as f:
            doctors = json.load(f)
        
        # Extract unique wilayas
        wilaya_codes = set()
        for doc in doctors:
            if 'Wilaya_doct' in doc and doc['Wilaya_doct']:
                wilaya_codes.add(str(doc['Wilaya_doct']).zfill(2))
        
        # Create basic mapping (will need to be updated)
        wilayas = {}
        for code in wilaya_codes:
            wilayas[code] = {
                'code': code,
                'name': f"Wilaya {code}",
                'baladyat': []
            }
        
        return wilayas
    except:
        return {}

def fetch_specialties():
    """Fetch specialties mapping"""
    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.6",
        "Origin": "https://machrou3.com",
        "Referer": "https://machrou3.com/",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    }
    
    url = "https://doctorsdz.machrou3.com/user/getsp4appdoc"
    data = fetch_with_headers(url, headers)
    
    if data:
        logger.info(f"✅ Successfully fetched specialties data")
        # Save the raw data
        with open('specialties_raw.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        # Parse and structure
        structured = parse_specialties(data)
        with open('specialties.json', 'w', encoding='utf-8') as f:
            json.dump(structured, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✅ Saved {len(structured)} specialties")
        return structured
    else:
        # Fallback: Create from existing data
        logger.warning("Could not fetch specialties, creating from existing data...")
        return create_specialties_from_existing()

def parse_specialties(data: List[Dict]) -> Dict:
    """Parse and structure specialties data"""
    specialties = {}
    
    for item in data:
        code = str(item.get('Num_sp', '')).zfill(2)
        name = item.get('Name_sp', '')
        # Also try other possible field names
        if not name and 'sp_name' in item:
            name = item['sp_name']
        if not name and 'specialty_name' in item:
            name = item['specialty_name']
        
        if code:
            specialties[code] = {
                'code': code,
                'name': name or f"Specialty {code}",
                'raw': item
            }
    
    return specialties

def create_specialties_from_existing():
    """Create specialty mapping from doctors data"""
    try:
        with open('doctors.json', 'r') as f:
            doctors = json.load(f)
        
        # Extract unique specialty codes
        specialty_codes = set()
        for doc in doctors:
            if 'Num_sp' in doc and doc['Num_sp']:
                specialty_codes.add(str(doc['Num_sp']).zfill(2))
        
        # Create mapping
        specialties = {}
        specialty_names = {
            '01': 'Médecine Générale', '02': 'Cardiologie', '03': 'Dermatologie',
            '04': 'Endocrinologie', '05': 'Gastro-entérologie', '06': 'Gynécologie',
            '07': 'Hématologie', '08': 'Néphrologie', '09': 'Neurologie',
            '10': 'Ophtalmologie', '11': 'Orthopédie', '12': 'ORL',
            '13': 'Pédiatrie', '14': 'Pneumologie', '15': 'Psychiatrie',
            '16': 'Rhumatologie', '17': 'Urologie', '18': 'Chirurgie générale',
            '19': 'Anesthésie', '20': 'Radiologie', '21': 'Biologie',
            '22': 'Pharmacie', '23': 'Dentiste', '24': 'Kinésithérapie',
            '25': 'Nutrition', '26': 'Dermatologue', '27': 'Allergologie',
            '28': 'Médecine du travail', '29': 'Médecine légale', '30': 'Chirurgie maxillo-faciale',
            '31': 'Neurochirurgie', '32': 'Chirurgie cardiaque', '33': 'Chirurgie pédiatrique',
            '34': 'Chirurgie vasculaire', '35': 'Chirurgie thoracique', '36': 'Chirurgie digestive',
            '37': 'Chirurgie cancérologique', '38': 'Imagerie médicale', '39': 'Médecine nucléaire',
            '40': 'Autre'
        }
        
        for code in specialty_codes:
            specialties[code] = {
                'code': code,
                'name': specialty_names.get(code, f"Spécialité {code}")
            }
        
        return specialties
    except:
        return {}

def main():
    """Main function to fetch all mappings"""
    logger.info("🚀 Starting to fetch mappings...")
    
    # Fetch wilayas and baladyat
    wilayas = fetch_wilayas_and_baladyat()
    logger.info(f"📊 Wilayas: {len(wilayas)}")
    
    # Fetch specialties
    specialties = fetch_specialties()
    logger.info(f"🏥 Specialties: {len(specialties)}")
    
    # Create a unified mapping file
    mappings = {
        'wilayas': wilayas,
        'specialties': specialties,
        'fetched_at': datetime.now().isoformat()
    }
    
    with open('mappings.json', 'w', encoding='utf-8') as f:
        json.dump(mappings, f, ensure_ascii=False, indent=2)
    
    logger.info("✅ All mappings saved to mappings.json")
    return mappings

if __name__ == "__main__":
    from datetime import datetime
    main()
