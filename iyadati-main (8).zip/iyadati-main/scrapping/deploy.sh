#!/bin/bash
# deploy.sh

echo "🚀 Deploying Doctors Data System..."
echo "====================================="

# Create virtual environment if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Install requirements
echo "📦 Installing requirements..."
pip install -r requirements.txt

# Setup directories
echo "📁 Setting up directories..."
mkdir -p data/{raw,mappings,processed,dashboard}

# Run the pipeline
echo "🔄 Running data pipeline..."
python3 run_pipeline.py

# Check if data was created
if [ -f "data/processed/doctors_enhanced.csv" ]; then
    echo "✅ Data pipeline completed successfully!"
    echo "📊 Data summary:"
    python3 -c "
import pandas as pd
df = pd.read_csv('data/processed/doctors_enhanced.csv')
print(f'  Total doctors: {len(df):,}')
print(f'  Cities: {df[\"city\"].nunique() if \"city\" in df.columns else 0}')
print(f'  Specialties: {df[\"specialty\"].nunique() if \"specialty\" in df.columns else 0}')
"
    
    # Ask to launch dashboard
    echo ""
    read -p "🚀 Launch dashboard? (y/n): " launch
    if [[ $launch == "y" || $launch == "Y" ]]; then
        echo "Launching dashboard..."
        streamlit run dashboard_enhanced.py --server.port 8501
    fi
else
    echo "❌ Failed to create data"
fi

echo "✅ Done!"