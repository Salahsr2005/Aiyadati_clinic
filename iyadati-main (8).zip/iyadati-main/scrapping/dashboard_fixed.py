# scrapping/dashboard_fixed.py
import streamlit as st
import pandas as pd
import plotly.express as px
import json
from datetime import datetime

st.set_page_config(
    page_title="Doctors Dashboard - Algeria",
    page_icon="🏥",
    layout="wide"
)

@st.cache_data
def load_data():
    """Load the fixed doctor data with real names"""
    try:
        # Try to load fixed data
        df = pd.read_csv('data/processed/doctors_fixed.csv')
        return df
    except:
        try:
            # If not, load from JSON and fix
            with open('data/processed/doctors_fixed.json', 'r') as f:
                data = json.load(f)
            df = pd.DataFrame(data)
            return df
        except:
            # Fallback to original
            df = pd.read_csv('data/processed/doctors_enhanced.csv')
            return df

@st.cache_data
def load_specialties():
    """Load specialties mapping"""
    try:
        with open('data/mappings/specialties_full.json', 'r') as f:
            return json.load(f)
    except:
        try:
            with open('data/mappings/specialties.json', 'r') as f:
                return json.load(f)
        except:
            return {}

@st.cache_data
def load_wilayas():
    """Load wilayas mapping"""
    try:
        with open('data/mappings/wilayas_full.json', 'r') as f:
            return json.load(f)
    except:
        try:
            with open('data/mappings/wilayas.json', 'r') as f:
                return json.load(f)
        except:
            return {}

df = load_data()
specialties_map = load_specialties()
wilayas_map = load_wilayas()

if df is not None and not df.empty:
    st.title("🏥 Doctors Dashboard - Algeria")
    
    # Statistics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Doctors", f"{len(df):,}")
    with col2:
        cities = df['city'].nunique() if 'city' in df.columns else 0
        st.metric("Cities", cities)
    with col3:
        specialties = df['specialty'].nunique() if 'specialty' in df.columns else 0
        st.metric("Specialties", specialties)
    with col4:
        with_coords = df['latitude'].notna().sum() if 'latitude' in df.columns else 0
        st.metric("With Coordinates", f"{with_coords:,}")
    
    st.divider()
    
    # Sidebar filters
    st.sidebar.header("🔍 Filters")
    
    # City filter
    cities = ['All'] + sorted(df['city'].dropna().unique().tolist()) if 'city' in df.columns else ['All']
    selected_city = st.sidebar.selectbox("🏙️ Select City", cities)
    
    # Specialty filter
    specialties = ['All'] + sorted(df['specialty'].dropna().unique().tolist()) if 'specialty' in df.columns else ['All']
    selected_specialty = st.sidebar.selectbox("🏥 Select Specialty", specialties)
    
    # Search
    search = st.sidebar.text_input("🔎 Search Doctor", placeholder="Name, address, phone...")
    
    # Apply filters
    filtered_df = df.copy()
    
    if selected_city != 'All' and 'city' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['city'] == selected_city]
    
    if selected_specialty != 'All' and 'specialty' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['specialty'] == selected_specialty]
    
    if search:
        mask = filtered_df.astype(str).apply(
            lambda x: x.str.contains(search, case=False, na=False)
        ).any(axis=1)
        filtered_df = filtered_df[mask]
    
    st.info(f"📊 Showing {len(filtered_df):,} doctors out of {len(df):,}")
    
    # Tabs
    tab1, tab2, tab3 = st.tabs(["📋 Doctors", "🗺️ Map", "📊 Statistics"])
    
    with tab1:
        # Display doctors as cards
        cols = st.columns(2)
        for i, (idx, row) in enumerate(filtered_df.iterrows()):
            with cols[i % 2]:
                with st.container():
                    st.markdown(f"""
                        <div style="background:white;padding:1rem;border-radius:8px;border-left:4px solid #3498db;margin-bottom:0.5rem;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                            <div style="font-weight:bold;font-size:1.1rem;">{row.get('name', 'Unknown')}</div>
                            <div style="color:#7f8c8d;font-size:0.9rem;">🏥 {row.get('specialty', 'N/A')}</div>
                            <div style="color:#7f8c8d;font-size:0.9rem;">📍 {row.get('city', 'N/A')}</div>
                            <div style="color:#7f8c8d;font-size:0.9rem;">📞 {row.get('phone', 'No phone')}</div>
                            <div style="color:#7f8c8d;font-size:0.9rem;">✉️ {row.get('email', 'No email')}</div>
                        </div>
                    """, unsafe_allow_html=True)
        
        # Export
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Data",
            data=csv,
            file_name=f"doctors_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )
    
    with tab2:
        if 'latitude' in filtered_df.columns and 'longitude' in filtered_df.columns:
            map_df = filtered_df[filtered_df['latitude'].notna() & filtered_df['longitude'].notna()]
            if len(map_df) > 0:
                fig = px.scatter_map(
                    map_df,
                    lat='latitude',
                    lon='longitude',
                    hover_name='name',
                    hover_data={
                        'specialty': True,
                        'city': True,
                        'phone': True
                    },
                    color='specialty',
                    zoom=5,
                    height=600
                )
                fig.update_layout(map_style="open-street-map")
                st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        col1, col2 = st.columns(2)
        
        with col1:
            if 'city' in filtered_df.columns:
                city_counts = filtered_df['city'].value_counts().head(15)
                fig = px.bar(
                    x=city_counts.values,
                    y=city_counts.index,
                    orientation='h',
                    labels={'x': 'Doctors', 'y': 'City'},
                    color=city_counts.values,
                    color_continuous_scale='Blues'
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            if 'specialty' in filtered_df.columns:
                specialty_counts = filtered_df['specialty'].value_counts().head(15)
                fig = px.bar(
                    x=specialty_counts.values,
                    y=specialty_counts.index,
                    orientation='h',
                    labels={'x': 'Doctors', 'y': 'Specialty'},
                    color=specialty_counts.values,
                    color_continuous_scale='Viridis'
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
        
        # Show all specialties
        with st.expander("🏥 All Specialties with Real Names"):
            if 'specialty' in df.columns:
                all_specialties = df['specialty'].value_counts()
                specialty_df = pd.DataFrame({
                    'Specialty': all_specialties.index,
                    'Doctors': all_specialties.values,
                    'Percentage': (all_specialties.values / len(df) * 100).round(2)
                })
                st.dataframe(specialty_df, use_container_width=True)
        
        with st.expander("🏙️ All Cities with Real Names"):
            if 'city' in df.columns:
                all_cities = df['city'].value_counts()
                city_df = pd.DataFrame({
                    'City': all_cities.index,
                    'Doctors': all_cities.values,
                    'Percentage': (all_cities.values / len(df) * 100).round(2)
                })
                st.dataframe(city_df, use_container_width=True)

if __name__ == "__main__":
    st.caption(f"Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")