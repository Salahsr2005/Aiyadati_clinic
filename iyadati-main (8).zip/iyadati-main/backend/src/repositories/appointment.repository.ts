import { prisma } from '../core/utils/prisma';

export class AppointmentRepository {
  async findById(id: string) {
    return prisma.appointment.findUnique({
      where: { id },
      include: { 
        slot: { include: { service: { include: { gallery: true } } } }, 
        doctor: true, 
        patient: true, 
        clinic: true, 
        contactUser: true,
        guestPatient: true,
        service: { include: { gallery: true } },
      },
    });
  }

  async findBySlotId(slotId: string) {
    return prisma.appointment.findFirst({
      where: { slotId },
      include: { 
        slot: { include: { service: { include: { gallery: true } } } },
        service: { include: { gallery: true } },
      },
    });
  }

  async create(data: {
    slotId: string;
    doctorId: string;
    patientId: string;
    contactUserId?: string;
    clinicId?: string;
    type?: string;
    paymentMethod?: string;
    notes?: string;
    createdBy: string;
    createdByType: string;
  }) {
    return prisma.appointment.create({ data: data as any });
  }

  async findByPatientId(patientId: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [appointments, total] = await Promise.all([
      prisma.appointment.findMany({
        where: { patientId },
        skip, 
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { 
          slot: { include: { service: { include: { gallery: true } } } }, 
          doctor: true, 
          clinic: true, 
          contactUser: true,
          patient: true,
          guestPatient: true,
          service: { include: { gallery: true } },
        },
      }),
      prisma.appointment.count({ where: { patientId } }),
    ]);
    return { appointments, total };
  }

  async findByDoctorId(doctorId: string, page = 1, limit = 10, date?: string) {
    const where: any = { doctorId };
    if (date) {
      where.slot = { date: new Date(date) };
    }
    const skip = (page - 1) * limit;
    const [appointments, total] = await Promise.all([
      prisma.appointment.findMany({
        where, 
        skip, 
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { 
          slot: { include: { service: { include: { gallery: true } } } }, 
          patient: true, 
          clinic: true, 
          contactUser: true,
          guestPatient: true,
          service: { include: { gallery: true } },
        },
      }),
      prisma.appointment.count({ where }),
    ]);
    return { appointments, total };
  }

  async findByClinicId(clinicId: string, page = 1, limit = 10, date?: string) {
    const where: any = { clinicId };
    if (date) {
      where.slot = { date: new Date(date) };
    }
    const skip = (page - 1) * limit;
    const [appointments, total] = await Promise.all([
      prisma.appointment.findMany({
        where, 
        skip, 
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { 
          slot: { include: { service: { include: { gallery: true } } } }, 
          doctor: true, 
          patient: true, 
          contactUser: true,
          guestPatient: true,
          service: { include: { gallery: true } },
        },
      }),
      prisma.appointment.count({ where }),
    ]);
    return { appointments, total };
  }

  async findAll(page = 1, limit = 20, filters?: { 
    date?: string; 
    doctorId?: string; 
    clinicId?: string; 
    status?: string;
    patientId?: string;
    patientType?: string;
  }) {
    const where: any = {};
    if (filters?.date) where.slot = { date: new Date(filters.date) };
    if (filters?.doctorId) where.doctorId = filters.doctorId;
    if (filters?.clinicId) where.clinicId = filters.clinicId;
    if (filters?.status) where.status = filters.status;
    if (filters?.patientId) where.patientId = filters.patientId;
    if (filters?.patientType) where.patientType = filters.patientType;

    const skip = (page - 1) * limit;
    const [appointments, total] = await Promise.all([
      prisma.appointment.findMany({
        where, 
        skip, 
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { 
          slot: { include: { service: { include: { gallery: true } } } }, 
          doctor: true, 
          patient: true, 
          clinic: true,
          guestPatient: true,
          service: { include: { gallery: true } },
        },
      }),
      prisma.appointment.count({ where }),
    ]);
    return { appointments, total };
  }

  async updateStatus(id: string, status: string, extra?: any) {
    return prisma.appointment.update({ 
      where: { id }, 
      data: { status: status as any, ...extra } 
    });
  }
}

export const appointmentRepository = new AppointmentRepository();

