// backend/src/repositories/reminder.repository.ts

import { prisma } from '../core/utils/prisma';
import { Prisma, ReminderStatus, RecipientType } from '@prisma/client';

export type ReminderType = '3_DAYS' | '1_DAY' | '2_HOURS' | '1_HOUR';

export interface CreateReminderData {
  appointmentId: string;
  recipientId: string;
  recipientType: RecipientType;
  reminderType: string;
  scheduledAt: Date;
}

export interface ScheduledReminder {
  id: string;
  reminderType: ReminderType;
  scheduledAt: Date;
}

export class ReminderRepository {
  /**
   * Create multiple reminders with skipDuplicates for idempotency
   */
  async createMany(data: CreateReminderData[], tx?: Prisma.TransactionClient) {
    const client = tx || prisma;
    return client.appointmentReminder.createMany({
      data: data.map(d => ({
        appointmentId: d.appointmentId,
        recipientId: d.recipientId,
        recipientType: d.recipientType,
        reminderType: d.reminderType,
        scheduledAt: d.scheduledAt,
      })),
      skipDuplicates: true,
    });
  }

  /**
   * Find pending reminders by appointment ID and reminder types
   */
  async findPendingByAppointmentAndTypes(
    appointmentId: string,
    reminderTypes: string[],
    tx?: Prisma.TransactionClient
  ): Promise<ScheduledReminder[]> {
    const client = tx || prisma;
    const reminders = await client.appointmentReminder.findMany({
      where: {
        appointmentId,
        status: 'PENDING',
        reminderType: { in: reminderTypes },
      },
      select: {
        id: true,
        reminderType: true,
        scheduledAt: true,
      },
    });

    return reminders.map(r => ({
      id: r.id,
      reminderType: r.reminderType as ReminderType,
      scheduledAt: r.scheduledAt,
    }));
  }

  /**
   * Find pending reminders by appointment ID (for cancellation)
   */
  async findPendingByAppointmentId(
    appointmentId: string,
    tx?: Prisma.TransactionClient
  ) {
    const client = tx || prisma;
    return client.appointmentReminder.findMany({
      where: {
        appointmentId,
        status: 'PENDING',
      },
      select: { id: true },
    });
  }

  /**
   * Cancel all pending reminders for an appointment
   * Returns the count of cancelled reminders
   */
  async cancelByAppointmentId(
    appointmentId: string,
    tx?: Prisma.TransactionClient
  ) {
    const client = tx || prisma;
    return client.appointmentReminder.updateMany({
      where: {
        appointmentId,
        status: 'PENDING',
      },
      data: { status: 'CANCELLED' },
    });
  }

  /**
   * Find a reminder by ID with full appointment details
   */
  async findByIdWithAppointment(id: string) {
    return prisma.appointmentReminder.findUnique({
      where: { id },
      include: {
        appointment: {
          include: {
            doctor: true,
            patient: true,
            guestPatient: true,
            slot: true,
          },
        },
      },
    });
  }

  /**
   * Find a reminder by ID
   */
  async findById(id: string) {
    return prisma.appointmentReminder.findUnique({
      where: { id },
    });
  }

  /**
   * Update reminder status to SENT
   */
  async markAsSent(id: string, tx?: Prisma.TransactionClient) {
    const client = tx || prisma;
    return client.appointmentReminder.update({
      where: { id },
      data: {
        status: 'SENT',
        sentAt: new Date(),
      },
    });
  }

  /**
   * Update reminder with error (increments attempts, keeps PENDING)
   */
  async updateWithError(id: string, errorMessage: string, tx?: Prisma.TransactionClient) {
    const client = tx || prisma;
    return client.appointmentReminder.update({
      where: { id },
      data: {
        attempts: { increment: 1 },
        lastError: errorMessage,
      },
    });
  }

  /**
   * Mark reminder as FAILED (after max retries)
   */
  async markAsFailed(id: string, errorMessage: string, tx?: Prisma.TransactionClient) {
    const client = tx || prisma;
    return client.appointmentReminder.update({
      where: { id },
      data: {
        status: 'FAILED',
        lastError: errorMessage,
      },
    });
  }

  /**
   * Mark reminder as CANCELLED
   */
  async markAsCancelled(id: string, tx?: Prisma.TransactionClient) {
    const client = tx || prisma;
    return client.appointmentReminder.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });
  }

  /**
   * Find reminders by appointment ID (for debugging/admin)
   */
  async findByAppointmentId(appointmentId: string) {
    return prisma.appointmentReminder.findMany({
      where: { appointmentId },
      orderBy: { scheduledAt: 'asc' },
    });
  }

  /**
   * Find reminders by status (for reconciliation)
   */
  async findByStatus(status: ReminderStatus, limit = 100) {
    return prisma.appointmentReminder.findMany({
      where: { status },
      take: limit,
      orderBy: { scheduledAt: 'asc' },
    });
  }

  /**
   * Count reminders by status for an appointment
   */
  async countByAppointmentAndStatus(appointmentId: string, status: ReminderStatus) {
    return prisma.appointmentReminder.count({
      where: {
        appointmentId,
        status,
      },
    });
  }
}

export const reminderRepository = new ReminderRepository();

