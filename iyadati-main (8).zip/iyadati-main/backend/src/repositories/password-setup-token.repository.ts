import { prisma } from '../config/database';
import crypto from 'crypto';
import { Prisma } from '@prisma/client';

export const passwordSetupTokenRepository = {
  /**
   * Create a password setup token
   */
  create: async (ownerId: string, ownerType: string, expiresInHours = 72) => {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + expiresInHours * 60 * 60 * 1000);

    return prisma.passwordSetupToken.create({
      data: {
        token,
        ownerId,
        ownerType,
        expiresAt,
      },
    });
  },

  /**
   * Find token by value
   */
  findByToken: async (token: string) => {
    return prisma.passwordSetupToken.findUnique({
      where: { token },
    });
  },

  /**
   * Mark token as used
   */
  markAsUsed: async (token: string) => {
    return prisma.passwordSetupToken.update({
      where: { token },
      data: { usedAt: new Date() },
    });
  },

  /**
   * Delete expired tokens
   */
  deleteExpired: async () => {
    return prisma.passwordSetupToken.deleteMany({
      where: {
        expiresAt: { lt: new Date() },
        usedAt: null,
      },
    });
  },
};

