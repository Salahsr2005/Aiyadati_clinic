import { prisma } from '../config/database';
import { Prisma, ApplicationStatus, ApplicationType } from '@prisma/client';

export const applicationRepository = {
  /**
   * Create a new application
   */
  create: async (data: Prisma.RegistrationApplicationCreateInput) => {
    return prisma.registrationApplication.create({ data });
  },

  /**
   * Find by ID
   */
  findById: async (id: string) => {
    return prisma.registrationApplication.findUnique({
      where: { id },
    });
  },

  /**
   * Find by email and type (check duplicates)
   */
  findByEmailAndType: async (email: string, type: ApplicationType) => {
    const where: any = {
      status: 'PENDING',
    };

    if (type === 'DOCTOR') where.doctorEmail = email;
    else if (type === 'CLINIC') where.clinicEmail = email;
    else if (type === 'SELLER') where.sellerEmail = email;

    return prisma.registrationApplication.findFirst({ where });
  },

  /**
   * Find all with pagination and filters
   */
  findAll: async (params: {
    page?: number;
    limit?: number;
    status?: ApplicationStatus;
    type?: ApplicationType;
  }) => {
    const { page = 1, limit = 20, status, type } = params;
    const skip = (page - 1) * limit;

    const where: Prisma.RegistrationApplicationWhereInput = {};
    if (status) where.status = status;
    if (type) where.type = type;

    const [applications, total] = await Promise.all([
      prisma.registrationApplication.findMany({
        where,
        skip,
        take: limit,
        orderBy: { submittedAt: 'desc' },
      }),
      prisma.registrationApplication.count({ where }),
    ]);

    return { applications, total };
  },

  /**
   * Update application status (reject)
   */
  reject: async (id: string, data: {
    reviewedBy: string;
    reviewedAt: Date;
    rejectionReason?: string;
    notes?: string;
  }) => {
    return prisma.registrationApplication.update({
      where: { id },
      data: {
        status: 'REJECTED',
        reviewedBy: data.reviewedBy,
        reviewedAt: data.reviewedAt,
        rejectionReason: data.rejectionReason,
        notes: data.notes,
      },
    });
  },

  /**
   * Update application with created entity (approve)
   */
  approveWithEntity: async (id: string, data: {
    entityId: string;
    entityType: string;
    reviewedBy: string;
    reviewedAt: Date;
  }) => {
    return prisma.registrationApplication.update({
      where: { id },
      data: {
        status: 'APPROVED',
        reviewedBy: data.reviewedBy,
        reviewedAt: data.reviewedAt,
        createdEntityId: data.entityId,
        createdEntityType: data.entityType,
      },
    });
  },

  /**
   * Count pending applications
   */
  countPending: async () => {
    return prisma.registrationApplication.count({
      where: { status: 'PENDING' },
    });
  },

  /**
   * Count by type
   */
  countByType: async (type: ApplicationType) => {
    return prisma.registrationApplication.count({
      where: { type },
    });
  },
};

