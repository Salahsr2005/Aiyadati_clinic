// backend/src/repositories/slot.repository.ts

import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';
import { nowAlgeria, isSlotInPastAlgeria } from '../core/utils/timezone';

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Generate a unique key for a slot
 * Respects clinicId and roomId properly
 */
function generateSlotKey(
  doctorId: string,
  date: Date,
  startTime: Date,
  clinicId?: string | null,
  roomId?: string | null
): string {
  const dateStr = date.toISOString().slice(0, 10);
  const timeStr = startTime.toISOString().slice(11, 16);
  
  const clinicPart = clinicId || 'none';
  const roomPart = roomId || 'none';
  
  return `${doctorId}:${dateStr}:${timeStr}:${clinicPart}:${roomPart}`;
}

// ============================================================
// REPOSITORY
// ============================================================

export class SlotRepository {
  
  // ======================== FINDERS ========================

  async findById(id: string) {
    return prisma.slot.findUnique({
      where: { id },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });
  }

  async findByDoctorAndDate(doctorId: string, date: string) {
    const targetDate = new Date(date);
    return prisma.slot.findMany({
      where: {
        doctorId,
        date: targetDate,
      },
      orderBy: {
        startTime: 'asc',
      },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });
  }

  /**
   * Get available slots for a doctor on a specific date
   * - Excludes cancelled slots
   * - Filters out slots that have already passed (using Algeria timezone)
   */
  async findAvailableByDoctorAndDate(
    doctorId: string,
    date: string,
  ) {
    const targetDate = new Date(date);

    const slots = await prisma.slot.findMany({
      where: {
        doctorId,
        date: targetDate,
        status: {
          not: 'cancelled',
        },
      },
      orderBy: {
        startTime: 'asc',
      },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });

    const now = nowAlgeria();

    return slots.filter(
      (slot) => !isSlotInPastAlgeria(slot.date, slot.startTime, now),
    );
  }

  /**
   * Validates that a slot is bookable (exists, not cancelled, not expired)
   * Can be called inside a transaction by passing the transaction client
   * @throws Error with descriptive message if validation fails
   */
  async validateSlotIsBookable(
    slotId: string,
    now = nowAlgeria(),
    tx?: Prisma.TransactionClient,
  ) {
    const client = tx || prisma;

    const slot = await client.slot.findUnique({
      where: { id: slotId },
    });

    if (!slot) {
      throw new Error('Slot not found');
    }

    if (slot.status === 'cancelled') {
      throw new Error('This slot has been cancelled');
    }

    if (isSlotInPastAlgeria(slot.date, slot.startTime, now)) {
      throw new Error('This slot has already passed');
    }

    return slot;
  }

  /**
   * Refreshes the slot status based on active appointments
   * Should be called after booking or cancellation
   */
  async refreshSlotStatus(
    slotId: string,
    tx?: Prisma.TransactionClient,
  ) {
    const client = tx || prisma;

    const slot = await client.slot.findUnique({
      where: { id: slotId },
    });

    if (!slot) {
      return null;
    }

    const activeCount = await client.appointment.count({
      where: {
        slotId,
        status: {
          notIn: ['CANCELLED', 'NO_SHOW'],
        },
      },
    });

    const newStatus = activeCount >= slot.maxPatients ? 'full' : 'available';

    if (slot.status !== newStatus) {
      return client.slot.update({
        where: { id: slotId },
        data: { status: newStatus },
      });
    }

    return slot;
  }

  // ======================== CREATION ========================

  async create(data: {
    doctorId: string;
    clinicId?: string;
    roomId?: string;
    serviceId?: string;
    date: Date;
    startTime: Date;
    endTime: Date;
    maxPatients?: number;
  }) {
    const slotKey = generateSlotKey(
      data.doctorId,
      data.date,
      data.startTime,
      data.clinicId,
      data.roomId
    );

    return prisma.slot.create({
      data: {
        ...data,
        slotKey,
        maxPatients: data.maxPatients || 1,
      },
    });
  }

  async createMany(
    slots: Array<{
      doctorId: string;
      clinicId?: string;
      roomId?: string;
      serviceId?: string;
      date: Date;
      startTime: Date;
      endTime: Date;
      maxPatients: number;
    }>,
  ) {
    const slotsWithKeys = slots.map(slot => ({
      ...slot,
      slotKey: generateSlotKey(
        slot.doctorId,
        slot.date,
        slot.startTime,
        slot.clinicId,
        slot.roomId
      ),
    }));

    return prisma.slot.createMany({
      data: slotsWithKeys,
      skipDuplicates: true,
    });
  }

  // ======================== UPDATES ========================

  async updateStatus(id: string, status: string) {
    return prisma.slot.update({
      where: { id },
      data: { status },
    });
  }

  async cancelSlot(id: string) {
    return prisma.slot.update({
      where: { id },
      data: { status: 'cancelled' },
    });
  }

  async cancelByDoctorAndDate(doctorId: string, date: string) {
    return prisma.slot.updateMany({
      where: {
        doctorId,
        date: new Date(date),
        status: {
          in: ['available', 'full'],
        },
      },
      data: {
        status: 'cancelled',
      },
    });
  }

  // ======================== DELETION ========================

  /**
   * Delete slots by doctor and date range (NORMAL MODE)
   * @throws Error if any slot has active appointments
   * @returns Number of deleted slots
   */
  async deleteByDoctorAndDateRange(
    doctorId: string,
    startDate: Date,
    endDate: Date,
  ): Promise<number> {
    const slotsWithAppointments = await prisma.slot.findMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          some: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      select: {
        id: true,
        date: true,
        startTime: true,
        _count: {
          select: {
            appointments: {
              where: {
                status: {
                  notIn: ['CANCELLED', 'NO_SHOW'],
                },
              },
            },
          },
        },
      },
    });

    if (slotsWithAppointments.length > 0) {
      const slotDetails = slotsWithAppointments
        .map(s => {
          const dateStr = s.date.toISOString().slice(0, 10);
          const timeStr = s.startTime.toISOString().slice(11, 16);
          return `${dateStr} at ${timeStr} (${s._count.appointments} appointment${s._count.appointments > 1 ? 's' : ''})`;
        })
        .join('; ');
      
      throw new Error(
        `Cannot regenerate slots: ${slotsWithAppointments.length} slot(s) have active appointments (${slotDetails}). ` +
        `Please cancel or complete these appointments first.`
      );
    }

    const result = await prisma.slot.deleteMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          none: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
    });

    return result.count;
  }

  /**
   * Force delete slots by doctor and date range (ADMIN ONLY)
   * Cancels all active appointments and refunds credits before deleting
   * @returns Object with deleted slots count and cancelled appointments count
   */
  async forceDeleteByDoctorAndDateRange(
    doctorId: string,
    startDate: Date,
    endDate: Date,
    cancelledBy: string,
  ): Promise<{ deletedSlots: number; cancelledAppointments: number; refundedCredits: number }> {
    const slotsWithAppointments = await prisma.slot.findMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          some: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      include: {
        appointments: {
          where: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
          include: {
            patient: true,
            guestPatient: true,
          },
        },
      },
    });

    let cancelledAppointments = 0;
    let refundedCredits = 0;

    for (const slot of slotsWithAppointments) {
      for (const appointment of slot.appointments) {
        if (appointment.patientType === 'REGISTERED' && appointment.paymentMethod === 'CREDIT' && appointment.patientId) {
          await prisma.$transaction(async (tx) => {
            const wallet = await tx.userWallet.upsert({
              where: { userId: appointment.patientId! },
              create: { userId: appointment.patientId!, credits: 1 },
              update: { credits: { increment: 1 } },
            });
            
            await tx.creditTransaction.create({
              data: {
                walletId: wallet.id,
                amount: 1,
                type: 'refund',
                description: 'Force regeneration - admin action',
                referenceId: appointment.id,
              },
            });
          });
          refundedCredits++;
        }

        await prisma.appointment.update({
          where: { id: appointment.id },
          data: {
            status: 'CANCELLED',
            cancelledAt: new Date(),
            cancelledBy: cancelledBy,
            cancelReason: 'Force regeneration - admin action',
          },
        });
        cancelledAppointments++;
      }
    }

    const result = await prisma.slot.deleteMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    return {
      deletedSlots: result.count,
      cancelledAppointments,
      refundedCredits,
    };
  }

  // ======================== BACKGROUND CLEANUP ========================

  async markExpiredSlots() {
    const now = nowAlgeria();
    
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    
    const where: any = {
      status: {
        in: ['available', 'full'],
      },
    };
    
    where.OR = [
      {
        date: {
          lt: today,
        },
      },
      {
        date: today,
        startTime: {
          lt: now,
        },
      },
    ];

    const result = await prisma.slot.updateMany({
      where,
      data: {
        status: 'expired',
      },
    });

    return result.count;
  }

  // ======================== IDEMPOTENT GENERATION ========================

  async generateMissingSlots(
    doctorId: string,
    slots: Array<{
      clinicId?: string;
      roomId?: string;
      date: Date;
      startTime: Date;
      endTime: Date;
      maxPatients: number;
    }>
  ): Promise<{ created: number; existing: number; errors: number }> {
    const result = { created: 0, existing: 0, errors: 0 };

    const slotsWithKeys = slots.map(slot => ({
      ...slot,
      slotKey: generateSlotKey(
        doctorId,
        slot.date,
        slot.startTime,
        slot.clinicId,
        slot.roomId
      ),
      doctorId,
    }));

    try {
      const createResult = await prisma.slot.createMany({
        data: slotsWithKeys,
        skipDuplicates: true,
      });

      result.created = createResult.count;
      result.existing = slots.length - createResult.count;
    } catch (error: any) {
      result.errors = slots.length;
      throw error;
    }

    return result;
  }

  // ============================================================
  // GET BOOKING HORIZON
  // ============================================================

  async getBookingHorizon(
    doctorId: string,
    clinicId?: string | null,
    roomId?: string | null
  ): Promise<Date | null> {
    const where: any = { doctorId };
    
    if (clinicId !== undefined && clinicId !== null) {
      where.clinicId = clinicId;
    }
    
    if (roomId !== undefined && roomId !== null) {
      where.roomId = roomId;
    }

    const farthestSlot = await prisma.slot.findFirst({
      where,
      orderBy: { date: 'desc' },
      select: { date: true },
    });

    return farthestSlot?.date || null;
  }

  // ============================================================
  // AUTOMATION RULES
  // ============================================================

  async upsertAutomationRule(
    doctorId: string,
    data: {
      frequency: string;
      bookingWindowDays: number;
      clinicId?: string;
      roomId?: string;
    }
  ) {
    const nextRunAt = this.calculateNextRun(data.frequency);

    const clinicIdValue = data.clinicId !== undefined ? data.clinicId : null;
    const roomIdValue = data.roomId !== undefined ? data.roomId : null;

    return prisma.slotGenerationRule.upsert({
      where: { doctorId },
      update: {
        frequency: data.frequency as any,
        bookingWindowDays: data.bookingWindowDays,
        clinicId: clinicIdValue,
        roomId: roomIdValue,
        enabled: true,
        nextRunAt,
        errorCount: 0,
        lastError: null,
      },
      create: {
        doctorId,
        frequency: data.frequency as any,
        bookingWindowDays: data.bookingWindowDays,
        clinicId: clinicIdValue,
        roomId: roomIdValue,
        nextRunAt,
      },
    });
  }

  async disableAutomationRule(doctorId: string) {
    return prisma.slotGenerationRule.update({
      where: { doctorId },
      data: { enabled: false },
    });
  }

  // ======================== SERVICE-BASED QUERIES ========================

  /**
   * Find available slots for a specific service on a given date
   */
  async findAvailableByServiceAndDate(
    serviceId: string,
    date: string,
    clinicId?: string
  ) {
    const targetDate = new Date(date);
    
    const where: any = {
      serviceId,
      date: targetDate,
      status: {
        not: 'cancelled',
      },
    };
    
    if (clinicId) {
      where.clinicId = clinicId;
    }

    const slots = await prisma.slot.findMany({
      where,
      orderBy: {
        startTime: 'asc',
      },
      include: {
        doctor: {
          include: {
            specialties: {
              include: {
                specialty: true,
              },
            },
          },
        },
        clinic: true,
        room: true,
        service: {
          include: {
            clinic: {
              select: {
                id: true,
                nameFr: true,
                nameAr: true,
                logoFileId: true,
                logoPath: true,
              },
            },
          },
        },
      },
    });

    const now = nowAlgeria();

    return slots.filter(
      (slot) => !isSlotInPastAlgeria(slot.date, slot.startTime, now)
    );
  }

  /**
   * Find doctors offering a specific service with available slots
   * This is the core patient-facing query
   */
  async findDoctorsByServiceWithAvailability(
    serviceId: string,
    date: string,
    clinicId?: string,
    limit = 50
  ) {
    const targetDate = new Date(date);
    const now = nowAlgeria();

    // First, get all doctors who offer this service
    const serviceDoctors = await prisma.clinicServiceDoctor.findMany({
      where: {
        serviceId,
      },
      include: {
        doctor: {
          include: {
            specialties: {
              include: {
                specialty: true,
              },
            },
            clinicLinks: {
              where: {
                isActive: true,
                status: 'ACCEPTED',
                ...(clinicId && { clinicId }),
              },
              include: {
                clinic: {
                  select: {
                    id: true,
                    nameFr: true,
                    nameAr: true,
                    logoFileId: true,
                    logoPath: true,
                  },
                },
              },
            },
          },
        },
        service: {
          include: {
            clinic: {
              select: {
                id: true,
                nameFr: true,
                nameAr: true,
              },
            },
          },
        },
      },
      take: limit,
    });

    // For each doctor, get their available slots for this service
    const results = await Promise.all(
      serviceDoctors.map(async (sd) => {
        // Get all slots for this service on this date
        const allSlots = await this.findAvailableByServiceAndDate(
          serviceId,
          date,
          sd.doctor.clinicLinks[0]?.clinicId || clinicId
        );

        // Filter slots for this specific doctor
        const doctorSlots = allSlots.filter(
          (slot) => slot.doctorId === sd.doctorId
        );

        // Get the clinic from the doctor's clinic links
        const clinic = sd.doctor.clinicLinks && sd.doctor.clinicLinks.length > 0
          ? sd.doctor.clinicLinks[0].clinic
          : null;

        return {
          doctor: sd.doctor,
          clinic: clinic,
          service: sd.service,
          isPrimary: sd.isPrimary,
          slots: doctorSlots.map((slot) => ({
            id: slot.id,
            startTime: slot.startTime,
            endTime: slot.endTime,
            isAvailable: slot.status === 'available',
            clinicId: slot.clinicId,
            roomId: slot.roomId,
          })),
          availableSlotsCount: doctorSlots.length,
        };
      })
    );

    // Return only doctors with available slots
    return results.filter((r) => r.slots.length > 0);
  }

  /**
   * Get all services for a doctor with slot counts
   */
  async getDoctorServicesWithSlotCounts(
    doctorId: string,
    date?: string
  ) {
    const where: any = {
      doctorId,
    };

    if (date) {
      const targetDate = new Date(date);
      where.date = targetDate;
    }

    const slots = await prisma.slot.findMany({
      where,
      include: {
        service: {
          include: {
            clinic: {
              select: {
                id: true,
                nameFr: true,
                nameAr: true,
              },
            },
          },
        },
      },
    });

    // Group by service
    const serviceMap = new Map<
      string,
      {
        service: any;
        totalSlots: number;
        availableSlots: number;
      }
    >();

    const now = nowAlgeria();

    for (const slot of slots) {
      if (!slot.serviceId || !slot.service) continue;

      const isPast = isSlotInPastAlgeria(slot.date, slot.startTime, now);
      const isAvailable = slot.status === 'available' && !isPast;

      if (!serviceMap.has(slot.serviceId)) {
        serviceMap.set(slot.serviceId, {
          service: slot.service,
          totalSlots: 0,
          availableSlots: 0,
        });
      }

      const entry = serviceMap.get(slot.serviceId)!;
      entry.totalSlots++;
      if (isAvailable) {
        entry.availableSlots++;
      }
    }

    return Array.from(serviceMap.values());
  }

  private calculateNextRun(frequency: string): Date {
    const now = new Date();
    switch (frequency) {
      case 'DAILY':
        now.setDate(now.getDate() + 1);
        now.setHours(0, 0, 0, 0);
        break;
      case 'WEEKLY':
        now.setDate(now.getDate() + 7);
        now.setHours(0, 0, 0, 0);
        break;
      case 'MONTHLY':
        now.setMonth(now.getMonth() + 1);
        now.setDate(1);
        now.setHours(0, 0, 0, 0);
        break;
    }
    return now;
  }

  async getAutomationRule(doctorId: string) {
    return prisma.slotGenerationRule.findUnique({
      where: { doctorId },
    });
  }
}

// ============================================================
// ✅ EXPORT THE REPOSITORY INSTANCE
// ============================================================

export const slotRepository = new SlotRepository();

