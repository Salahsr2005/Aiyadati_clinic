import { PrismaClient, Wilaya, Baladya } from '@prisma/client';

const prisma = new PrismaClient();

export class WilayaRepository {
  async findAll(): Promise<Wilaya[]> {
    return prisma.wilaya.findMany({
      include: {
        _count: {
          select: { baladyat: true },
        },
      },
      orderBy: { code: 'asc' },
    });
  }

  async findById(id: string): Promise<(Wilaya & { baladyat: Baladya[] }) | null> {
    return prisma.wilaya.findUnique({
      where: { id },
      include: {
        baladyat: {
          orderBy: { nameFr: 'asc' },
        },
      },
    });
  }

  async findByCode(code: number): Promise<(Wilaya & { baladyat: Baladya[] }) | null> {
    return prisma.wilaya.findUnique({
      where: { code },
      include: {
        baladyat: true,
      },
    });
  }

  async findBaladyatByWilayaId(wilayaId: string): Promise<Baladya[]> {
    return prisma.baladya.findMany({
      where: { wilayaId },
      orderBy: { nameFr: 'asc' },
    });
  }

  async findBaladyaById(id: string): Promise<Baladya | null> {
    return prisma.baladya.findUnique({
      where: { id },
      include: { wilaya: true },
    });
  }

  async createBaladya(data: { 
    nameFr: string; 
    nameAr: string; 
    wilayaId: string 
  }): Promise<Baladya> {
    return prisma.baladya.create({
      data: {
        nameFr: data.nameFr,
        nameAr: data.nameAr,
        wilayaId: data.wilayaId,
      },
      include: { wilaya: true },
    });
  }

  async updateBaladya(id: string, data: { 
    nameFr?: string; 
    nameAr?: string;
  }): Promise<Baladya> {
    return prisma.baladya.update({
      where: { id },
      data: {
        ...(data.nameFr && { nameFr: data.nameFr }),
        ...(data.nameAr && { nameAr: data.nameAr }),
      },
      include: { wilaya: true },
    });
  }

  async checkBaladyaNameExistsInWilaya(
    wilayaId: string, 
    nameFr: string, 
    excludeId?: string
  ): Promise<boolean> {
    const existing = await prisma.baladya.findFirst({
      where: {
        wilayaId,
        nameFr,
        NOT: excludeId ? { id: excludeId } : undefined,
      },
    });
    return !!existing;
  }

  async checkBaladyaArNameExistsInWilaya(
    wilayaId: string, 
    nameAr: string, 
    excludeId?: string
  ): Promise<boolean> {
    const existing = await prisma.baladya.findFirst({
      where: {
        wilayaId,
        nameAr,
        NOT: excludeId ? { id: excludeId } : undefined,
      },
    });
    return !!existing;
  }

  async findBaladyaByCode(code: number): Promise<Baladya | null> {
    return prisma.baladya.findUnique({
      where: { code },
    });
  }
}

export const wilayaRepository = new WilayaRepository();

