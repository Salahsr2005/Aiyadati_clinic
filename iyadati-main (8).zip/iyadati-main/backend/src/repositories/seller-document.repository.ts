// src/repositories/seller-document.repository.ts

import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';
import { SellerDocumentStatus, SellerDocumentType } from '@prisma/client';

interface CreateSellerDocumentDTO {
  sellerId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  docType?: SellerDocumentType;
}

interface UpdateSellerDocumentDTO {
  docType?: SellerDocumentType;
  status?: SellerDocumentStatus;
  rejectionReason?: string;
}

class SellerDocumentRepository extends BaseRepository<any> {
  protected modelName = 'sellerDocument';

  async findBySellerId(sellerId: string, filters?: {
    docType?: SellerDocumentType;
    status?: SellerDocumentStatus;
  }) {
    const where: any = { sellerId };

    if (filters?.docType) where.docType = filters.docType;
    if (filters?.status) where.status = filters.status;

    return this.prisma.sellerDocument.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.sellerDocument.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.sellerDocument.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateSellerDocumentDTO) {
    return this.prisma.sellerDocument.create({
      data: {
        sellerId: data.sellerId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        docType: data.docType || SellerDocumentType.OTHER,
        status: SellerDocumentStatus.PENDING,
        storageType: 'private',
      },
    });
  }

  async update(id: string, data: UpdateSellerDocumentDTO) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    return this.prisma.sellerDocument.delete({
      where: { id },
    });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.sellerDocument.delete({
      where: { fileId },
    });
  }

  async deleteBySellerId(sellerId: string) {
    return this.prisma.sellerDocument.deleteMany({
      where: { sellerId },
    });
  }

  async verify(id: string, adminId: string) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data: {
        status: SellerDocumentStatus.APPROVED,
        verifiedBy: adminId,
        verifiedAt: new Date(),
      },
    });
  }

  async reject(id: string, adminId: string, reason: string) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data: {
        status: SellerDocumentStatus.REJECTED,
        verifiedBy: adminId,
        verifiedAt: new Date(),
        rejectionReason: reason,
      },
    });
  }

  async unverify(id: string) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data: {
        status: SellerDocumentStatus.PENDING,
        verifiedBy: null,
        verifiedAt: null,
        rejectionReason: null,
      },
    });
  }

  async findByDocType(sellerId: string, docType: SellerDocumentType) {
    return this.prisma.sellerDocument.findMany({
      where: {
        sellerId,
        docType,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Find all pending documents (for admin review)
   */
  async findPendingDocuments(limit: number = 50) {
    return this.prisma.sellerDocument.findMany({
      where: {
        status: SellerDocumentStatus.PENDING,
      },
      include: {
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            phone: true,
            businessName: true,
          },
        },
      },
      orderBy: { createdAt: 'asc' },
      take: limit,
    });
  }

  async incrementAccessCount(fileId: string): Promise<void> {
    await this.prisma.sellerDocument.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }
}

export const sellerDocumentRepository = new SellerDocumentRepository();

