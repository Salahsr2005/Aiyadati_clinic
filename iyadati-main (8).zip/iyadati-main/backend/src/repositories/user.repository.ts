import { prisma } from '../core/utils/prisma';
import { Prisma, User } from '@prisma/client';

export class UserRepository {
  async findById(id: string) {
    return prisma.user.findUnique({
      where: { id },
      include: { wilaya: true },
    });
  }

  async findByEmail(email: string) {
    return prisma.user.findUnique({ where: { email } });
  }

  async findByPhone(phone: string) {
    return prisma.user.findUnique({ where: { phone } });
  }

  async create(data: Prisma.UserCreateInput) {
    return prisma.user.create({ data });
  }

  async update(id: string, data: Prisma.UserUpdateInput) {
    return prisma.user.update({ where: { id }, data });
  }

  async delete(id: string) {
    return prisma.user.delete({ where: { id } });
  }

  async findAllWithFilters(params: {
    search?: string;
    email?: string;
    phone?: string;
    firstName?: string;
    lastName?: string;
    wilayaId?: string;
    isVerified?: boolean;
    isSuspended?: boolean;
    dateOfBirthFrom?: string;
    dateOfBirthTo?: string;
    createdAtFrom?: string;
    createdAtTo?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      search, email, phone, firstName, lastName, wilayaId,
      isVerified, isSuspended, dateOfBirthFrom, dateOfBirthTo,
      createdAtFrom, createdAtTo, page = 1, limit = 10,
      sortBy = 'createdAt', sortOrder = 'desc',
    } = params;

    const where: any = {};

    // Search by name, email, or phone
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    // Exact filters
    if (email) where.email = { contains: email, mode: 'insensitive' };
    if (phone) where.phone = { contains: phone };
    if (firstName) where.firstName = { contains: firstName, mode: 'insensitive' };
    if (lastName) where.lastName = { contains: lastName, mode: 'insensitive' };
    if (wilayaId) where.wilayaId = wilayaId;
    if (isVerified !== undefined) where.isVerified = isVerified;
    if (isSuspended !== undefined) where.isSuspended = isSuspended;

    // Date range filters
    if (dateOfBirthFrom || dateOfBirthTo) {
      where.dateOfBirth = {};
      if (dateOfBirthFrom) where.dateOfBirth.gte = new Date(dateOfBirthFrom);
      if (dateOfBirthTo) where.dateOfBirth.lte = new Date(dateOfBirthTo);
    }

    if (createdAtFrom || createdAtTo) {
      where.createdAt = {};
      if (createdAtFrom) where.createdAt.gte = new Date(createdAtFrom);
      if (createdAtTo) where.createdAt.lte = new Date(createdAtTo);
    }

    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: { wilaya: true },
      }),
      prisma.user.count({ where }),
    ]);

    return { users, total };
  }

  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return false;
    if (excludeId && user.id === excludeId) return false;
    return true;
  }

  async phoneExists(phone: string, excludeId?: string): Promise<boolean> {
    const user = await prisma.user.findUnique({ where: { phone } });
    if (!user) return false;
    if (excludeId && user.id === excludeId) return false;
    return true;
  }

  async updatePassword(id: string, hashedPassword: string) {
    return prisma.user.update({ where: { id }, data: { password: hashedPassword } });
  }

  async setVerificationCode(id: string, code: string, expiresAt: Date) {
    return prisma.user.update({
      where: { id },
      data: { verificationCode: code, otpExpiresAt: expiresAt },
    });
  }

  async verifyUser(id: string) {
    return prisma.user.update({
      where: { id },
      data: { isVerified: true, verificationCode: null, otpExpiresAt: null },
    });
  }

  async suspend(id: string, reason: string) {
    return prisma.user.update({
      where: { id },
      data: { isSuspended: true, suspensionReason: reason },
    });
  }

  async unsuspend(id: string) {
    return prisma.user.update({
      where: { id },
      data: { isSuspended: false, suspensionReason: null },
    });
  }

  async findByQrCode(qrCode: string) {
    return prisma.user.findUnique({
      where: { qrCode },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        trustLevel: true,
        trustPoints: true,
        isSuspended: true,
        wallet: {
          select: { id: true, credits: true },
        },
      },
    });
  }

  async regenerateQrCode(id: string) {
    const user = await prisma.user.update({
      where: { id },
      data: { qrCode: crypto.randomUUID() },
      select: { qrCode: true },
    });
    return { qrCode: user.qrCode as string };
  }

  /**
   * Request account deletion
   */
  async requestDeletion(id: string, reason?: string): Promise<User> {
    const now = new Date();
    const scheduledDate = new Date(now);
    scheduledDate.setDate(scheduledDate.getDate() + 30); // 30 days from now
    
    const reversibleUntil = new Date(now);
    reversibleUntil.setDate(reversibleUntil.getDate() + 1); // Can cancel within first 24 hours

    return prisma.user.update({
      where: { id },
      data: {
        deletionRequestedAt: now,
        deletionScheduledAt: scheduledDate,
        deletionStatus: 'pending',
        deletionReason: reason,
        deletionReversibleUntil: reversibleUntil,
        isSuspended: true, // Prevent login immediately
        suspensionReason: 'Account deletion requested - pending permanent deletion',
      },
    });
  }

  /**
   * Cancel account deletion request
   */
  async cancelDeletion(id: string): Promise<User> {
    return prisma.user.update({
      where: { id },
      data: {
        deletionRequestedAt: null,
        deletionScheduledAt: null,
        deletionStatus: 'active',
        deletionReason: null,
        deletionReversibleUntil: null,
        isSuspended: false,
        suspensionReason: null,
      },
    });
  }

  /**
   * Get users pending deletion for cleanup job
   */
  async getUsersPendingDeletion(): Promise<User[]> {
    const now = new Date();
    return prisma.user.findMany({
      where: {
        deletionStatus: 'pending',
        deletionScheduledAt: {
          lte: now, // Scheduled date has passed
        },
      },
      include: {
        wallet: true,
        appointments: {
          where: {
            status: { in: ['PENDING', 'CONFIRMED', 'IN_PROGRESS'] }
          },
          select: {
            id: true,
            status: true,
          }
        }
      }
    });
  }


  /**
   * Permanently delete user (called by cleanup job)
   */
  async permanentDeleteUser(id: string): Promise<void> {
    await prisma.$transaction(async (tx) => {
      // Clean up related records
      await tx.userDocument.updateMany({
        where: { userId: id },
        data: { 
          deletedAt: new Date(), 
          deletedById: 'system', 
          deletedByType: 'system' 
        }
      });
      
      // The actual user deletion will cascade to most relations
      await tx.user.delete({
        where: { id },
      });
    });
  }


}

export const userRepository = new UserRepository();

