import { prisma } from '../core/utils/prisma';
import { Seller, SellerStatus, Prisma } from '@prisma/client';

export class SellerRepository {
  async findById(id: string) {
    return prisma.seller.findUnique({
      where: { id },
      include: {
        wilaya: true,
        baladya: true,
        documents: {
          orderBy: { createdAt: 'desc' },
        },
        products: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          include: {
            images: {
              take: 1,
              where: { isPrimary: true },
            },
          },
        },
        orders: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          include: {
            buyer: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                phone: true,
              },
            },
            items: {
              include: {
                product: {
                  select: {
                    id: true,
                    titleFr: true,
                    titleAr: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  async findByEmail(email: string) {
    return prisma.seller.findUnique({
      where: { email },
    });
  }

  async findByPhone(phone: string) {
    return prisma.seller.findUnique({
      where: { phone },
    });
  }

  // ✅ FIX: Remove findByFileId and findByStorageKey - Seller doesn't have these fields
  // The Seller model doesn't have fileId or storageKey fields

  async create(data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone: string;
    wilayaId: string;
    baladyaId?: string;
    businessName?: string;
    businessType?: string;
    taxNumber?: string;
    registrationNumber?: string;
    address?: string;
  }) {
    return prisma.seller.create({
      data: {
        email: data.email,
        password: data.password,
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        wilayaId: data.wilayaId,
        baladyaId: data.baladyaId,
        businessName: data.businessName,
        businessType: data.businessType as any, // ✅ FIX: Cast to any to avoid enum issues
        taxNumber: data.taxNumber,
        registrationNumber: data.registrationNumber,
        address: data.address,
        status: 'PENDING' as SellerStatus,
        isVerified: false,
        isSuspended: false,
      },
      include: {
        wilaya: true,
        baladya: true,
      },
    });
  }

  async update(id: string, data: Prisma.SellerUpdateInput) {
    return prisma.seller.update({
      where: { id },
      data,
      include: {
        wilaya: true,
        baladya: true,
      },
    });
  }

  async updatePassword(id: string, hashedPassword: string) {
    return prisma.seller.update({
      where: { id },
      data: { password: hashedPassword },
    });
  }

  async updateStatus(id: string, status: SellerStatus) {
    return prisma.seller.update({
      where: { id },
      data: { status },
    });
  }

  async verify(id: string) {
    return prisma.seller.update({
      where: { id },
      data: {
        isVerified: true,
        status: 'ACTIVE' as SellerStatus,
        verifiedAt: new Date(),
      },
    });
  }

    async reject(id: string, reason: string) {
    return prisma.seller.update({
        where: { id },
        data: {
        status: 'BANNED' as SellerStatus,
        rejectionReason: reason,
        isVerified: false,
        },
    });
  }

  async suspend(id: string, reason?: string) {
    return prisma.seller.update({
      where: { id },
      data: {
        isSuspended: true,
        suspensionReason: reason,
        status: 'SUSPENDED' as SellerStatus,
      },
    });
  }

  async unsuspend(id: string) {
    return prisma.seller.update({
      where: { id },
      data: {
        isSuspended: false,
        suspensionReason: null,
        status: 'ACTIVE' as SellerStatus,
      },
    });
  }

  async findAll(params: {
    page?: number;
    limit?: number;
    status?: SellerStatus;
    isVerified?: boolean;
    isSuspended?: boolean;
    search?: string;
    wilayaId?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      page = 1,
      limit = 10,
      status,
      isVerified,
      isSuspended,
      search,
      wilayaId,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;

    const where: any = {};

    if (status) where.status = status;
    if (isVerified !== undefined) where.isVerified = isVerified;
    if (isSuspended !== undefined) where.isSuspended = isSuspended;
    if (wilayaId) where.wilayaId = wilayaId;

    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { businessName: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (page - 1) * limit;

    const [items, total] = await Promise.all([
      prisma.seller.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: {
          wilaya: true,
          baladya: true,
          _count: {
            select: {
              products: true,
              orders: true,
            },
          },
        },
      }),
      prisma.seller.count({ where }),
    ]);

    return { items, total };
  }

  async getStats() {
    const [total, pending, active, suspended, banned] = await Promise.all([
      prisma.seller.count(),
      prisma.seller.count({ where: { status: 'PENDING' as SellerStatus } }),
      prisma.seller.count({ where: { status: 'ACTIVE' as SellerStatus } }),
      prisma.seller.count({ where: { status: 'SUSPENDED' as SellerStatus } }),
      prisma.seller.count({ where: { status: 'BANNED' as SellerStatus } }),
    ]);

    return { total, pending, active, suspended, banned };
  }

  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const seller = await prisma.seller.findUnique({ where: { email } });
    if (!seller) return false;
    if (excludeId && seller.id === excludeId) return false;
    return true;
  }

  async phoneExists(phone: string, excludeId?: string): Promise<boolean> {
    const seller = await prisma.seller.findUnique({ where: { phone } });
    if (!seller) return false;
    if (excludeId && seller.id === excludeId) return false;
    return true;
  }

  async delete(id: string) {
    return prisma.seller.delete({
      where: { id },
    });
  }

  async getPendingCount(): Promise<number> {
    return prisma.seller.count({
      where: { status: 'PENDING' as SellerStatus },
    });
  }

  async getRecent(limit: number = 10) {
    return prisma.seller.findMany({
      where: { status: 'PENDING' as SellerStatus },
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        wilaya: true,
      },
    });
  }
}

export const sellerRepository = new SellerRepository();

