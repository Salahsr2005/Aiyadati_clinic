import dotenv from 'dotenv';

dotenv.config({
  path: process.env.NODE_ENV === 'test' ? '.env.test' : '.env',
});

const storageUseSSL = process.env.STORAGE_USE_SSL === 'true';

export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: parseInt(process.env.PORT || '3975', 10),
  DATABASE_URL : process.env.DATABASE_URL! || '',
  DATABASE_URL_PGBOUNCER : process.env.DATABASE_URL_PGBOUNCER! || '',
  DIRECT_DATABASE_URL : process.env.DIRECT_DATABASE_URL! || '' ,

  // Mail
  MAILTRAP_HOST: process.env.MAILTRAP_HOST || '',
  MAILTRAP_PORT: parseInt(process.env.MAILTRAP_PORT || '2525', 10),
  MAILTRAP_USER: process.env.MAILTRAP_USER || '',
  MAILTRAP_PASS: process.env.MAILTRAP_PASS || '',
  MAIL_FROM: process.env.MAIL_FROM || 'noreply@iyadati.com',

  // Files
  UPLOAD_DIR: process.env.UPLOAD_DIR || 'uploads',
  FILE_SECRET: process.env.FILE_SECRET || 'default-secret',
  BASE_URL: process.env.BASE_URL || 'http://localhost:3975',

  MAILTRAP_TOKEN: process.env.MAILTRAP_TOKEN || '',

  CHARGILY_SECRET_KEY: process.env.CHARGILY_SECRET_KEY || '',
  CHARGILY_PUBLIC_KEY: process.env.CHARGILY_PUBLIC_KEY || '',
  CHARGILY_MODE: (process.env.CHARGILY_MODE as 'test' | 'live') || 'test',

  // Helpers
  isDevelopment: process.env.NODE_ENV !== 'production',
  isProduction: process.env.NODE_ENV === 'production',
  isTest: process.env.NODE_ENV === 'test',

  JWT_SECRET: process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production',

  FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID || '',
  FIREBASE_SERVICE_ACCOUNT: process.env.FIREBASE_SERVICE_ACCOUNT || '',

  // ============================================================
  // STORAGE CONFIGURATION
  // ============================================================
  
  STORAGE_TYPE: process.env.STORAGE_TYPE || 'local',
  
  // S3/SeaweedFS Configuration
  STORAGE_ENDPOINT: process.env.STORAGE_ENDPOINT || '',
  STORAGE_PORT: parseInt(process.env.STORAGE_PORT || '8333', 10),
  STORAGE_PUBLIC_ENDPOINT: process.env.STORAGE_PUBLIC_ENDPOINT || process.env.STORAGE_ENDPOINT || '',
  STORAGE_PUBLIC_PORT: parseInt(process.env.STORAGE_PUBLIC_PORT || process.env.STORAGE_PORT || '8333', 10),
  STORAGE_ACCESS_KEY: process.env.STORAGE_ACCESS_KEY || '',
  STORAGE_SECRET_KEY: process.env.STORAGE_SECRET_KEY || '',
  STORAGE_USE_SSL: storageUseSSL,
  // ✅ NEW: Separate SSL flag for public/presign client
  STORAGE_PUBLIC_USE_SSL: process.env.STORAGE_PUBLIC_USE_SSL !== undefined
    ? process.env.STORAGE_PUBLIC_USE_SSL === 'true'
    : storageUseSSL,
  STORAGE_REGION: process.env.STORAGE_REGION || 'us-east-1',
  STORAGE_BUCKET_PUBLIC: process.env.STORAGE_BUCKET_PUBLIC || 'iyadati-public',
  STORAGE_BUCKET_PRIVATE: process.env.STORAGE_BUCKET_PRIVATE || 'iyadati-private',
  STORAGE_PRESIGN_THRESHOLD: parseInt(process.env.STORAGE_PRESIGN_THRESHOLD || '10485760', 10),
  ENABLE_LEGACY_FILES: process.env.ENABLE_LEGACY_FILES === 'true',
  CDN_URL: process.env.CDN_URL || '',

  // Redis
  REDIS_HOST: process.env.REDIS_HOST || 'redis',
  REDIS_PORT: parseInt(process.env.REDIS_PORT || '6379', 10),
  REDIS_USERNAME: process.env.REDIS_USERNAME || '',
  REDIS_PASSWORD: process.env.REDIS_PASSWORD || '',

  // Computed helpers
  isS3Compatible: process.env.STORAGE_TYPE === 's3-compatible',
  isLocalStorage: process.env.STORAGE_TYPE === 'local',
};
