import express, { Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
// import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import path from 'path';

import swaggerUi from 'swagger-ui-express';

import { notFoundHandler, globalErrorHandler } from './core/middleware/errorHandler.middleware';

import { swaggerSpec } from './config/swagger';
import { swaggerUiOptions } from './config/swaggerOptions';
import { swaggerCustomJs } from './config/swaggerCustomJs';
import { serverAdapter } from "./infrastructure/queues/dashboard";

// Import modules
import { healthModule } from './modules/health/health.module';
import { authModule } from './modules/auth/auth.module';
import { adminModule } from './modules/admin/admin.module';
import { locationModule } from './modules/location/location.module';
import { clinicModule } from './modules/clinic/clinic.module';
import { userModule } from './modules/user/user.module';
import { fileModule } from './modules/file/file.module';
import { specialtyModule } from './modules/specialty/specialty.module';
import { doctorModule } from './modules/doctor/doctor.module';
import { publicModule } from './modules/public/public.module';
import { walletModule } from './modules/wallet/wallet.module';
import { appointmentModule } from './modules/appointment/appointment.module';
import { reviewModule } from './modules/review/review.module';
import { analyticsModule } from './modules/analytics/analytics.module';
import { chatModule } from './modules/chat/chat.module';
import { notificationModule } from './modules/notification/notification.module';
import { creditModule } from './modules/credit/credit.module';
import { clinicServiceModule } from './modules/clinic-service/clinic-service.module';
import { creditTransferModule } from './modules/credit-transfer/credit-transfer.module';
import { ecommerceModule } from './modules/ecommerce/ecommerce.module';
import { searchModule } from './modules/search/search.module';
import { consentModule } from './modules/consent/consent.module';
import { advertisementModule } from './modules/advertisement/advertisement.module';
import { newsModule } from './modules/news/news.module';
import { slotServiceModule } from './modules/slot-service/slot-service.module';
import { sellerModule } from './modules/seller/seller.module';
import { applicationModule } from './modules/application/application.module';


import webhookRoutes from './core/webhooks/webhook.routes';

import { registerAllListeners } from './core/events/register-listeners';
import './infrastructure/queues/workers';

const app = express();

app.use('/api/v1/webhooks', express.raw({ type: 'application/json' }), webhookRoutes);

// Security middleware
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Logging with morgan
// if (process.env.NODE_ENV !== 'production') {
//   app.use(morgan('dev'));
// }

// Swagger custom JS
app.get('/swagger-custom.js', (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/javascript');
  res.send(swaggerCustomJs);
});

// Swagger documentation
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  ...swaggerUiOptions,
  customJs: '/swagger-custom.js',
}));

app.get('/api-docs.json', (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

registerAllListeners();


app.use("/admin/queues", serverAdapter.getRouter());


// ============================================================
// API v1 Routes (double v1 - router level + module level)
// ============================================================
const v1Router = express.Router();
v1Router.use('/health', healthModule);
v1Router.use('/auth', authModule);
v1Router.use('/admin', adminModule);
v1Router.use('/location', locationModule);
v1Router.use('/clinic', clinicModule);
v1Router.use('/user', userModule);
v1Router.use('/files', fileModule);
v1Router.use('/specialty', specialtyModule);
v1Router.use('/doctor', doctorModule);
v1Router.use('/public', publicModule);
v1Router.use('/wallet', walletModule);
v1Router.use('/appointment', appointmentModule);
v1Router.use('/review', reviewModule);
v1Router.use('/analytics', analyticsModule);
v1Router.use('/chat', chatModule);
v1Router.use('/notification', notificationModule);
v1Router.use('/credit', creditModule);
v1Router.use('/clinic-services', clinicServiceModule);
v1Router.use('/credit-transfer', creditTransferModule);
v1Router.use('/ecommerce', ecommerceModule)
v1Router.use('/search',searchModule)
v1Router.use('/consent', consentModule)
v1Router.use('/advertisements', advertisementModule)
v1Router.use('/news', newsModule)
v1Router.use('/slot-service', slotServiceModule);
v1Router.use('/seller', sellerModule);
v1Router.use('/applications', applicationModule);

app.use('/api/v1', v1Router);

// Future v2:
// const v2Router = express.Router();
// v2Router.use('/health', healthModuleV2);
// v2Router.use('/auth', authModuleV2);
// app.use('/api/v2', v2Router);

// ============================================================

// Root health check
app.get('/', (_req: Request, res: Response) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// no : app.use('/uploads', express.static(path.resolve('uploads')));
// Files are now served securely through the file module:
//    - Public files: /api/v1/files/public/:fileId
//    - Private files: /api/v1/files/private/:fileId?expires=&signature=

// 404 handler
app.use(notFoundHandler);

// Global error handler
app.use(globalErrorHandler);


// Import background job but 3ndk just when we are ready note dhork rahom fi bullmq
// import './jobs/clean-expired-slots';
// import './jobs/account-deletion.job';


export default app;

