import { Router } from 'express';
import { AppointmentController } from './appointment.controller';
import { 
  validateDoctorConfig, 
  validateGenerateSlots, 
  validateBookAppointment, 
  validateClinicBook, 
  validateCancelSlots, 
  validateUpdateStatus,
  validateConfirmAppointment,
  validateGuestPatient,
  validateUpdateGuestPatient,
  validateGuestPatientSearch,
  validateQuickSlot,
  validateSlotAutomation
} from './appointment.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const c = new AppointmentController();

// ============================================================
// PUBLIC ROUTES
// ============================================================

// Get available slots for a doctor (public)
router.get('/slots/:doctorId', c.getAvailableSlots);

// ============================================================
// USER ROUTES
// ============================================================

router.get('/me', authenticate, authorize('USER'), c.getMyAppointments);
router.post('/book', authenticate, authorize('USER', 'DOCTOR'), validateBookAppointment, c.bookAppointment);
router.patch('/:id/status', authenticate, authorize('USER', 'DOCTOR', 'CLINIC'), validateUpdateStatus, c.updateStatus);

// ============================================================
// DOCTOR ROUTES
// ============================================================

// ============================================================
// ⚠️ IMPORTANT: Specific routes MUST come before wildcard routes!
// ============================================================

// Slots - Specific routes (no :id wildcard) - MUST BE FIRST
router.get('/doctor/slots', authenticate, authorize('DOCTOR'), c.getSlots);
router.post('/doctor/slots/generate', authenticate, authorize('DOCTOR'), validateGenerateSlots, c.generateSlots);
router.post('/doctor/slots/cancel-date', authenticate, authorize('DOCTOR'), validateCancelSlots, c.cancelSlotsByDate);
router.post('/doctor/slots/quick', authenticate, authorize('DOCTOR'), validateQuickSlot, c.addQuickSlot);

// Slot Automation routes - BEFORE the wildcard :id route
router.post('/doctor/slots/automation', authenticate, authorize('DOCTOR'), validateSlotAutomation, c.enableAutomation);
router.delete('/doctor/slots/automation', authenticate, authorize('DOCTOR'), c.disableAutomation);
router.get('/doctor/slots/automation', authenticate, authorize('DOCTOR'), c.getAutomation);

// Wildcard route - MUST BE LAST (so it doesn't capture /automation, /quick, etc.)
router.delete('/doctor/slots/:id', authenticate, authorize('DOCTOR'), c.cancelSlot);

// Appointments
router.get('/doctor/appointments', authenticate, authorize('DOCTOR'), c.getDoctorAppointments);

// Config
router.get('/doctor/config', authenticate, authorize('DOCTOR'), c.getMyConfig);
router.put('/doctor/config', authenticate, authorize('DOCTOR'), validateDoctorConfig, c.setMyConfig);

// ============================================================
// CLINIC ROUTES
// ============================================================

// Slots - Specific routes first
router.post('/clinic/doctors/:doctorId/slots/generate', authenticate, authorize('CLINIC'), validateGenerateSlots, c.generateSlots);
router.post('/clinic/doctors/:doctorId/slots/cancel-date', authenticate, authorize('CLINIC'), validateCancelSlots, c.cancelSlotsByDate);
router.post('/clinic/doctors/:doctorId/slots/quick', authenticate, authorize('CLINIC'), validateQuickSlot, c.addQuickSlot);

// Then generic routes
router.get('/clinic/doctors/:doctorId/slots', authenticate, authorize('CLINIC'), c.getSlots);

// Appointments
router.get('/clinic/appointments', authenticate, authorize('CLINIC'), c.getClinicAppointments);
router.post('/clinic/book', authenticate, authorize('CLINIC'), validateClinicBook, c.clinicBook);
router.patch('/clinic/appointments/:id/status', authenticate, authorize('CLINIC'), validateUpdateStatus, c.updateStatus);

// ============================================================
// CONFIRM APPOINTMENT (Doctor or Clinic)
// ============================================================

router.post('/appointments/:id/confirm', authenticate, authorize('DOCTOR', 'CLINIC'), validateConfirmAppointment, c.confirmAppointment);

// ============================================================
// ADMIN ROUTES
// ============================================================

router.get('/admin/appointments', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), c.getAllAppointments);

// ============================================================
// GUEST PATIENT MANAGEMENT (Doctor & Clinic only)
// ============================================================

// Get all guest patients created by the authenticated user
router.get(
  '/guest-patients', 
  authenticate, 
  authorize('DOCTOR', 'CLINIC'), 
  c.getMyGuestPatients
);

// Search guest patients by name or phone
router.get(
  '/guest-patients/search', 
  authenticate, 
  authorize('DOCTOR', 'CLINIC'), 
  validateGuestPatientSearch, 
  c.searchGuestPatients
);

// Get a specific guest patient by ID
router.get(
  '/guest-patients/:id', 
  authenticate, 
  authorize('DOCTOR', 'CLINIC'), 
  c.getGuestPatient
);

// Update a guest patient
router.patch(
  '/guest-patients/:id', 
  authenticate, 
  authorize('DOCTOR', 'CLINIC'), 
  validateUpdateGuestPatient, 
  c.updateGuestPatient
);

// Create a guest patient independently (without booking)
router.post(
  '/guest-patients', 
  authenticate, 
  authorize('DOCTOR', 'CLINIC'), 
  validateGuestPatient, 
  c.createGuestPatient
);

export default router;

