import { Prisma, RecipientType } from '@prisma/client';
import { prisma } from '../../../core/utils/prisma';
import { reminderRepository, ScheduledReminder } from '../../../repositories/reminder.repository';
import { reminderQueue } from '../../../infrastructure/queues/reminder/reminder.queue';
import { nowAlgeria } from '../../../core/utils/timezone';
import { logger } from '../../../core/utils/logger';

export type ReminderType = '3_DAYS' | '1_DAY' | '2_HOURS' | '1_HOUR';

export { ScheduledReminder } from '../../../repositories/reminder.repository';

export class ReminderService {
  /**
   * Schedule reminders for a confirmed appointment
   * Called inside a transaction in appointment.service.ts
   * Returns reminder data so Redis jobs can be enqueued AFTER transaction commits
   */
  async scheduleReminders(
    appointmentId: string,
    appointmentDateTime: Date,
    tx: Prisma.TransactionClient
  ): Promise<ScheduledReminder[]> {
    const appointment = await tx.appointment.findUnique({
      where: { id: appointmentId },
      include: {
        doctor: { select: { id: true, firstNameFr: true, lastNameFr: true } },
        patient: { select: { id: true, firstName: true, lastName: true } },
        guestPatient: { select: { id: true, firstName: true, lastName: true } },
      },
    });

    if (!appointment) {
      throw new Error(`Appointment ${appointmentId} not found`);
    }

    const now = nowAlgeria();
    const appointmentTime = new Date(appointmentDateTime);

    // Define reminder configurations
    const reminderConfigs: Array<{ type: ReminderType; offsetMs: number }> = [
      { type: '3_DAYS', offsetMs: 3 * 24 * 60 * 60 * 1000 },
      { type: '1_DAY', offsetMs: 1 * 24 * 60 * 60 * 1000 },
      { type: '2_HOURS', offsetMs: 2 * 60 * 60 * 1000 },
      { type: '1_HOUR', offsetMs: 1 * 60 * 60 * 1000 },
    ];

    const remindersToCreate: any[] = [];

    // ============================================================
    // 1. Patient reminders (only if registered)
    // ============================================================
    if (appointment.patientType === 'REGISTERED' && appointment.patientId) {
      for (const config of reminderConfigs) {
        const scheduledAt = new Date(appointmentTime.getTime() - config.offsetMs);
        if (scheduledAt > now) {
          remindersToCreate.push({
            appointmentId,
            recipientId: appointment.patientId,
            recipientType: 'PATIENT' as RecipientType,
            reminderType: config.type,
            scheduledAt,
          });
        }
      }
    }

    // ============================================================
    // 2. Doctor reminders (fewer, less frequent)
    // ============================================================
    const doctorConfigs: Array<{ type: ReminderType; offsetMs: number }> = [
      { type: '1_DAY', offsetMs: 1 * 24 * 60 * 60 * 1000 },
      { type: '1_HOUR', offsetMs: 1 * 60 * 60 * 1000 },
    ];

    for (const config of doctorConfigs) {
      const scheduledAt = new Date(appointmentTime.getTime() - config.offsetMs);
      if (scheduledAt > now) {
        remindersToCreate.push({
          appointmentId,
          recipientId: appointment.doctorId,
          recipientType: 'DOCTOR' as RecipientType,
          reminderType: config.type,
          scheduledAt,
        });
      }
    }

    if (remindersToCreate.length === 0) {
      logger.info(`No reminders to schedule for appointment ${appointmentId} (too soon)`);
      return [];
    }

    // ============================================================
    // 3. Create reminders in DB using repository (skip duplicates)
    // ============================================================
    await reminderRepository.createMany(remindersToCreate, tx);

    // ============================================================
    // 4. Fetch created reminders and return them for Redis enqueuing
    // ============================================================
    const reminderTypes = remindersToCreate.map(r => r.reminderType);
    const createdReminders = await reminderRepository.findPendingByAppointmentAndTypes(
      appointmentId,
      reminderTypes,
      tx
    );

    logger.info(
      `Created ${createdReminders.length} reminders for appointment ${appointmentId} ` +
      `(${remindersToCreate.length - createdReminders.length} duplicates skipped)`
    );

    return createdReminders.map(r => ({
      id: r.id,
      reminderType: r.reminderType as ReminderType,
      scheduledAt: r.scheduledAt,
    }));
  }

  /**
   * Cancel all reminders for an appointment
   * Called inside a transaction in appointment.service.ts
   * Returns reminder IDs so Redis cleanup can happen AFTER transaction commits
   */
  async cancelReminders(
    appointmentId: string,
    tx: Prisma.TransactionClient
  ): Promise<string[]> {
    // 1. Get pending reminder IDs BEFORE updating
    const toCancel = await reminderRepository.findPendingByAppointmentId(appointmentId, tx);

    if (toCancel.length === 0) {
      return [];
    }

    const reminderIds = toCancel.map(r => r.id);

    // 2. Mark as cancelled in DB using repository
    await reminderRepository.cancelByAppointmentId(appointmentId, tx);

    logger.info(`Cancelled ${reminderIds.length} reminders for appointment ${appointmentId}`);

    return reminderIds;
  }

  /**
   * Cancel reminders without a transaction (standalone)
   * Used when you don't have an existing transaction
   */
  async cancelRemindersStandalone(appointmentId: string): Promise<void> {
    return prisma.$transaction(async (tx) => {
      await this.cancelReminders(appointmentId, tx);
    });
  }

  /**
   * Get all reminders for an appointment (for debugging/admin)
   */
  async getRemindersForAppointment(appointmentId: string) {
    return reminderRepository.findByAppointmentId(appointmentId);
  }

  /**
   * Get reminders by status (for reconciliation)
   */
  async getRemindersByStatus(status: string, limit = 100) {
    return reminderRepository.findByStatus(status as any, limit);
  }

  /**
   * Get a reminder by ID with full appointment details
   */
  async getReminderWithAppointment(reminderId: string) {
    return reminderRepository.findByIdWithAppointment(reminderId);
  }

  /**
   * Mark a reminder as sent
   */
  async markReminderAsSent(reminderId: string, tx?: Prisma.TransactionClient) {
    return reminderRepository.markAsSent(reminderId, tx);
  }

  /**
   * Update reminder with error (increments attempts)
   */
  async updateReminderWithError(reminderId: string, errorMessage: string, tx?: Prisma.TransactionClient) {
    return reminderRepository.updateWithError(reminderId, errorMessage, tx);
  }

  /**
   * Mark reminder as failed (after max retries)
   */
  async markReminderAsFailed(reminderId: string, errorMessage: string, tx?: Prisma.TransactionClient) {
    return reminderRepository.markAsFailed(reminderId, errorMessage, tx);
  }

  /**
   * Mark reminder as cancelled
   */
  async markReminderAsCancelled(reminderId: string, tx?: Prisma.TransactionClient) {
    return reminderRepository.markAsCancelled(reminderId, tx);
  }
}

export const reminderService = new ReminderService();

