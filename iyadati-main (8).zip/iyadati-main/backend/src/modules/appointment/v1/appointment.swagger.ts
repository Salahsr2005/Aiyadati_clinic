/**
 * @swagger
 * tags:
 *   name: Appointment
 *   description: Appointment booking and management endpoints with PENDING -> CONFIRMED workflow
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     DoctorConfigResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         slotDuration:
 *           type: integer
 *           example: 30
 *           description: Duration of each slot in minutes
 *         bufferTime:
 *           type: integer
 *           example: 5
 *           description: Buffer time between slots in minutes
 *         maxPerSlot:
 *           type: integer
 *           example: 3
 *           description: Maximum patients allowed per slot
 *     
 *     DoctorConfigRequest:
 *       type: object
 *       required:
 *         - slotDuration
 *         - bufferTime
 *       properties:
 *         slotDuration:
 *           type: integer
 *           minimum: 5
 *           maximum: 120
 *           example: 30
 *         bufferTime:
 *           type: integer
 *           minimum: 0
 *           maximum: 60
 *           example: 5
 *         maxPerSlot:
 *           type: integer
 *           minimum: 1
 *           maximum: 20
 *           default: 1
 *           example: 3
 *           description: Maximum patients per slot
 *     
 *     SlotResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *         clinicId:
 *           type: string
 *           nullable: true
 *         roomId:
 *           type: string
 *           nullable: true
 *         date:
 *           type: string
 *           format: date
 *         startTime:
 *           type: string
 *           example: "08:00"
 *         endTime:
 *           type: string
 *           example: "08:30"
 *         status:
 *           type: string
 *           enum: [available, full, cancelled]
 *           description: available=has spots, full=all spots taken, cancelled=disabled
 *         maxPatients:
 *           type: integer
 *           example: 3
 *           description: Total capacity of this slot
 *         currentPatients:
 *           type: integer
 *           example: 1
 *           description: Currently booked patients
 *         serviceId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: ID of the service if this slot is for a specific service, null for plain doctor visits
 *     
 *     GenerateSlotsRequest:
 *       type: object
 *       required:
 *         - startDate
 *         - endDate
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *           description: Start date for slot generation (YYYY-MM-DD)
 *         endDate:
 *           type: string
 *           format: date
 *           description: End date for slot generation (YYYY-MM-DD)
 *         clinicId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Clinic ID (optional)
 *         roomId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Room ID (optional)
 *         force:
 *           type: boolean
 *           default: false
 *           description: |
 *             Force regeneration (ADMIN ONLY). When true, cancels all active appointments, 
 *             refunds credits, and deletes all slots in the date range before regenerating.
 *             WARNING: This will cancel ALL appointments in the date range!
 *     
 *     CancelSlotsRequest:
 *       type: object
 *       required:
 *         - date
 *       properties:
 *         date:
 *           type: string
 *           format: date
 *         reason:
 *           type: string
 *           nullable: true
 *     
 *     GuestPatientRequest:
 *       type: object
 *       required:
 *         - firstName
 *         - lastName
 *         - phone
 *       properties:
 *         firstName:
 *           type: string
 *           maxLength: 100
 *           example: "Ahmed"
 *         lastName:
 *           type: string
 *           maxLength: 100
 *           example: "Benali"
 *         phone:
 *           type: string
 *           pattern: "^[0-9]{10,15}$"
 *           example: "0555123456"
 *         email:
 *           type: string
 *           format: email
 *           nullable: true
 *           example: "ahmed@example.com"
 *         dateOfBirth:
 *           type: string
 *           format: date
 *           nullable: true
 *           example: "1990-05-15"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         notes:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *     
 *     GuestPatientResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         email:
 *           type: string
 *           nullable: true
 *         dateOfBirth:
 *           type: string
 *           format: date
 *           nullable: true
 *         wilayaId:
 *           type: string
 *           nullable: true
 *         wilaya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         createdBy:
 *           type: string
 *         createdByType:
 *           type: string
 *           enum: [DOCTOR, CLINIC]
 *         convertedToUserId:
 *           type: string
 *           nullable: true
 *         convertedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         notes:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *     
 *     PaginatedGuestPatientResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         data:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/GuestPatientResponse'
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *               example: 1
 *             limit:
 *               type: integer
 *               example: 20
 *             total:
 *               type: integer
 *               example: 50
 *             totalPages:
 *               type: integer
 *               example: 3
 *         message:
 *           type: string
 *           example: Guest patients retrieved
 *     
 *     BookAppointmentRequest:
 *       type: object
 *       required:
 *         - slotId
 *       properties:
 *         slotId:
 *           type: string
 *           format: uuid
 *         type:
 *           type: string
 *           enum: [IN_PERSON, VIDEO, HOME_VISIT]
 *           default: IN_PERSON
 *         patientId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: ID of registered patient (use either patientId OR guestPatient)
 *         guestPatient:
 *           $ref: '#/components/schemas/GuestPatientRequest'
 *           description: Guest patient data (use either patientId OR guestPatient)
 *         contactUserId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         notes:
 *           type: string
 *           nullable: true
 *     
 *     ClinicBookRequest:
 *       allOf:
 *         - $ref: '#/components/schemas/BookAppointmentRequest'
 *         - type: object
 *           properties:
 *             patientId:
 *               type: string
 *               format: uuid
 *               nullable: true
 *               description: ID of registered patient (optional if guestPatient provided)
 *             guestPatient:
 *               $ref: '#/components/schemas/GuestPatientRequest'
 *               description: Guest patient data (use either patientId OR guestPatient)
 *     
 *     ConfirmAppointmentRequest:
 *       type: object
 *       properties:
 *         notes:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           description: Optional notes when confirming appointment
 *     
 *     UpdateStatusRequest:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: [CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *           description: |
 *             Valid transitions:
 *             - PENDING -> CONFIRMED (doctor/clinic only)
 *             - PENDING -> CANCELLED
 *             - CONFIRMED -> IN_PROGRESS
 *             - CONFIRMED -> CANCELLED
 *             - CONFIRMED -> NO_SHOW
 *             - IN_PROGRESS -> COMPLETED
 *             - IN_PROGRESS -> CANCELLED
 *         cancelReason:
 *           type: string
 *           nullable: true
 *           description: Required when status is CANCELLED
 *     
 *     AppointmentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         slotId:
 *           type: string
 *         slot:
 *           $ref: '#/components/schemas/SlotResponse'
 *         doctorId:
 *           type: string
 *         doctor:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             firstNameFr:
 *               type: string
 *             lastNameFr:
 *               type: string
 *             photoUrl:
 *               type: string
 *               nullable: true
 *         patientId:
 *           type: string
 *           nullable: true
 *           description: ID of registered patient (null if guest)
 *         patient:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             phone:
 *               type: string
 *             isGuest:
 *               type: boolean
 *               enum: [false]
 *         guestPatientId:
 *           type: string
 *           nullable: true
 *           description: ID of guest patient (null if registered)
 *         guestPatient:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             phone:
 *               type: string
 *             email:
 *               type: string
 *               nullable: true
 *             isGuest:
 *               type: boolean
 *               enum: [true]
 *         patientType:
 *           type: string
 *           enum: [REGISTERED, GUEST]
 *           description: Type of patient (REGISTERED or GUEST)
 *         contactUserId:
 *           type: string
 *           nullable: true
 *         contactUser:
 *           type: object
 *           nullable: true
 *         clinicId:
 *           type: string
 *           nullable: true
 *         clinic:
 *           type: object
 *           nullable: true
 *         serviceId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: ID of the service if this appointment is for a service, null for plain doctor visit
 *         service:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             descriptionFr:
 *               type: string
 *               nullable: true
 *             descriptionAr:
 *               type: string
 *               nullable: true
 *             imageUrl:
 *               type: string
 *               nullable: true
 *               description: URL of the first gallery image for this service, if any
 *         type:
 *           type: string
 *         paymentMethod:
 *           type: string
 *         status:
 *           type: string
 *           enum: [PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *           description: |
 *             - PENDING: Awaiting doctor/clinic confirmation
 *             - CONFIRMED: Approved by provider
 *             - IN_PROGRESS: Currently in session
 *             - COMPLETED: Finished successfully
 *             - CANCELLED: Cancelled by either party
 *             - NO_SHOW: Patient didn't show up
 *         notes:
 *           type: string
 *           nullable: true
 *         createdBy:
 *           type: string
 *         createdByType:
 *           type: string
 *         confirmedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           description: When the appointment was confirmed by provider
 *         confirmedBy:
 *           type: string
 *           nullable: true
 *           description: ID of the user who confirmed the appointment
 *         cancelledAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         cancelledBy:
 *           type: string
 *           nullable: true
 *         cancelReason:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *     
 *     PaginatedAppointmentResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *         data:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/AppointmentResponse'
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *             limit:
 *               type: integer
 *             total:
 *               type: integer
 *             totalPages:
 *               type: integer
 *     
 *     Error:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         error:
 *           type: object
 *           properties:
 *             code:
 *               type: integer
 *             message:
 *               type: string
 *             details:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   field:
 *                     type: string
 *                   message:
 *                     type: string
 *     
 *     Notification:
 *       type: object
 *       properties:
 *         userId:
 *           type: string
 *         title:
 *           type: string
 *         body:
 *           type: string
 *         type:
 *           type: string
 *           enum: [appointment, chat, payment, system]
 *         data:
 *           type: object
 *     
 *     AuditLog:
 *       type: object
 *       properties:
 *         action:
 *           type: string
 *         entity:
 *           type: string
 *         entityId:
 *           type: string
 *         performedBy:
 *           type: string
 *         details:
 *           type: object
 *         ip:
 *           type: string
 *         createdAt:
 *           type: string
 *           format: date-time
 */

// ============================================================
// PUBLIC ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/slots/{doctorId}:
 *   get:
 *     summary: Get available slots (Public)
 *     tags: [Appointment]
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to check availability (YYYY-MM-DD)
 *     responses:
 *       200:
 *         description: Slots retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotResponse'
 *       404:
 *         description: Doctor not found
 *       500:
 *         description: Server error
 */

// ============================================================
// BOOK APPOINTMENT
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/book:
 *   post:
 *     summary: Book an appointment (creates PENDING appointment)
 *     description: |
 *       Creates a new appointment with PENDING status. Requires doctor/clinic confirmation.
 *       
 *       **Patient Types:**
 *       - **Registered**: Provide `patientId` (existing user)
 *       - **Guest**: Provide `guestPatient` object (new walk-in patient)
 *       
 *       Exactly one of `patientId` or `guestPatient` must be provided.
 *       
 *       **Payment:**
 *       - Registered patients are charged 1 credit from their wallet
 *       - Guest patients (created by doctor/clinic) are FREE
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/BookAppointmentRequest'
 *     responses:
 *       201:
 *         description: Appointment requested successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentResponse'
 *                 message:
 *                   type: string
 *                   example: Appointment requested. Awaiting provider confirmation.
 *       400:
 *         description: Insufficient credits or validation error
 *       404:
 *         description: Slot or doctor not found
 *       409:
 *         description: Slot is full or cancelled
 *       500:
 *         description: Server error
 *     examples:
 *       BookWithCredits:
 *         summary: Book with credits (registered patient)
 *         value:
 *           slotId: "123e4567-e89b-12d3-a456-426614174000"
 *           patientId: "223e4567-e89b-12d3-a456-426614174000"
 *           type: "IN_PERSON"
 *           notes: "First visit"
 *       BookGuestPatient:
 *         summary: Book with guest patient (walk-in) - FREE
 *         value:
 *           slotId: "123e4567-e89b-12d3-a456-426614174000"
 *           guestPatient:
 *             firstName: "Ahmed"
 *             lastName: "Benali"
 *             phone: "0555123456"
 *             email: "ahmed@example.com"
 *             dateOfBirth: "1990-05-15"
 *           type: "IN_PERSON"
 *           notes: "Walk-in patient"
 */

// ============================================================
// CONFIRM APPOINTMENT
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/appointments/{id}/confirm:
 *   post:
 *     summary: Confirm a pending appointment (Doctor or Clinic)
 *     description: Only doctors or clinics can confirm pending appointments. Changes status from PENDING to CONFIRMED.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Appointment ID
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ConfirmAppointmentRequest'
 *     responses:
 *       200:
 *         description: Appointment confirmed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentResponse'
 *                 message:
 *                   type: string
 *                   example: Appointment confirmed
 *       400:
 *         description: Cannot confirm - not pending or not authorized
 *       404:
 *         description: Appointment not found
 *       403:
 *         description: Insufficient permissions (user role must be DOCTOR or CLINIC)
 *       500:
 *         description: Server error
 */

// ============================================================
// USER APPOINTMENTS
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/me:
 *   get:
 *     summary: Get my appointments (User)
 *     description: Retrieves all appointments for the authenticated user
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *         description: Filter by status
 *     responses:
 *       200:
 *         description: Appointments retrieved
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

// ============================================================
// UPDATE STATUS
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/{id}/status:
 *   patch:
 *     summary: Update appointment status
 *     description: |
 *       Update status of an appointment. Users can cancel their own appointments.
 *       Doctors can update status for their appointments.
 *       
 *       **Note:** Guest patients do NOT receive trust points or no-show tracking.
 *       
 *       Valid transitions:
 *       - PENDING → CONFIRMED (doctor/clinic only)
 *       - PENDING → CANCELLED
 *       - CONFIRMED → IN_PROGRESS
 *       - CONFIRMED → CANCELLED
 *       - CONFIRMED → NO_SHOW
 *       - IN_PROGRESS → COMPLETED
 *       - IN_PROGRESS → CANCELLED
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Appointment ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateStatusRequest'
 *     responses:
 *       200:
 *         description: Status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentResponse'
 *       400:
 *         description: Invalid transition or validation error
 *       404:
 *         description: Appointment not found
 *       403:
 *         description: Not authorized to update this appointment
 *       500:
 *         description: Server error
 *     examples:
 *       ConfirmAppointment:
 *         summary: Confirm appointment (doctor/clinic)
 *         value:
 *           status: "CONFIRMED"
 *       CancelAppointment:
 *         summary: Cancel appointment
 *         value:
 *           status: "CANCELLED"
 *           cancelReason: "Patient requested cancellation"
 *       MarkAsCompleted:
 *         summary: Mark appointment as completed
 *         value:
 *           status: "COMPLETED"
 *       MarkAsNoShow:
 *         summary: Mark patient as no-show
 *         value:
 *           status: "NO_SHOW"
 */

// ============================================================
// DOCTOR ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots:
 *   get:
 *     summary: Get my slots (Doctor)
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to retrieve slots
 *     responses:
 *       200:
 *         description: Slots retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotResponse'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots/generate:
 *   post:
 *     summary: Generate slots (Doctor)
 *     description: |
 *       Generates time slots for the doctor based on availability and breaks.
 *       Any existing slots in the date range will be deleted and regenerated.
 *       
 *       **Slot Protection:**
 *       - By default, slots with active appointments CANNOT be deleted.
 *       - You must cancel or complete appointments before regenerating.
 *       
 *       **Force Mode (Admin Only):**
 *       - Set `force: true` to override protection.
 *       - This will CANCEL all active appointments and refund credits.
 *       - ⚠️ WARNING: This action cannot be undone!
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GenerateSlotsRequest'
 *     responses:
 *       201:
 *         description: Slots generated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotResponse'
 *                 message:
 *                   type: string
 *                   example: Slots generated
 *       400:
 *         description: Validation error, doctor not available, or slots have active appointments
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               SlotsBlocked:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Cannot regenerate slots: 3 slot(s) have active appointments (2026-08-20 at 09:00 (2 appointments); 2026-08-20 at 14:30 (1 appointment)). Please cancel or complete these appointments first."
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (force mode requires ADMIN)
 *       500:
 *         description: Server error
 *     examples:
 *       GenerateWeekly:
 *         summary: Generate slots for a week (normal mode)
 *         value:
 *           startDate: "2026-07-13"
 *           endDate: "2026-07-19"
 *       GenerateWeeklyForce:
 *         summary: Force regenerate slots (ADMIN ONLY - cancels all appointments)
 *         value:
 *           startDate: "2026-07-13"
 *           endDate: "2026-07-19"
 *           force: true
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots/{id}:
 *   delete:
 *     summary: Cancel a slot (Doctor)
 *     description: Cancels a specific slot and all appointments booked in it. Credits are refunded to registered patients.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Slot ID
 *     responses:
 *       200:
 *         description: Slot cancelled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: null
 *                 message:
 *                   type: string
 *                   example: Slot cancelled
 *       400:
 *         description: Not your slot or slot already cancelled
 *       404:
 *         description: Slot not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots/cancel-date:
 *   post:
 *     summary: Cancel all slots on a date (Doctor)
 *     description: Cancels all slots and appointments for a specific date. Credits are refunded to registered patients.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CancelSlotsRequest'
 *     responses:
 *       200:
 *         description: Slots cancelled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     cancelledCount:
 *                       type: integer
 *                       description: Number of slots cancelled
 *                 message:
 *                   type: string
 *                   example: Slots cancelled
 *       400:
 *         description: Validation error
 *       404:
 *         description: Doctor not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 *     examples:
 *       CancelDay:
 *         summary: Cancel all slots for a day
 *         value:
 *           date: "2026-07-15"
 *           reason: "Holiday"
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/appointments:
 *   get:
 *     summary: Get my appointments (Doctor)
 *     description: Retrieves all appointments for the authenticated doctor. Can filter by date.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by specific date
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *         description: Filter by status
 *     responses:
 *       200:
 *         description: Appointments retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/config:
 *   get:
 *     summary: Get slot configuration (Doctor)
 *     description: Get the current slot configuration (duration, buffer time, max per slot)
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Configuration retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorConfigResponse'
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: No configuration found (returns null)
 *       500:
 *         description: Server error
 *   
 *   put:
 *     summary: Set slot configuration (Doctor)
 *     description: Update the slot configuration (duration, buffer time, max per slot)
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/DoctorConfigRequest'
 *     responses:
 *       200:
 *         description: Configuration updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorConfigResponse'
 *                 message:
 *                   type: string
 *                   example: Config updated
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 *     examples:
 *       UpdateConfig:
 *         summary: Update to 15-minute slots with 5-min buffer
 *         value:
 *           slotDuration: 15
 *           bufferTime: 5
 *           maxPerSlot: 2
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots/quick:
 *   post:
 *     summary: Add a single quick slot (Doctor)
 *     description: |
 *       Add a single time slot without affecting existing slots.
 *       
 *       **Use cases:**
 *       - Add an emergency slot
 *       - Add a one-time extra appointment
 *       - Fill a cancelled slot
 *       
 *       **Validation:**
 *       - Slot must be within doctor's availability hours
 *       - Slot must not overlap with breaks
 *       - Slot must not be in the past
 *       - No duplicate slots at the same time
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - date
 *               - startTime
 *               - endTime
 *             properties:
 *               date:
 *                 type: string
 *                 format: date
 *                 description: Date for the slot (YYYY-MM-DD)
 *                 example: "2026-08-20"
 *               startTime:
 *                 type: string
 *                 pattern: "^([0-1][0-9]|2[0-3]):[0-5][0-9]$"
 *                 description: Start time in 24h format (HH:MM)
 *                 example: "09:30"
 *               endTime:
 *                 type: string
 *                 pattern: "^([0-1][0-9]|2[0-3]):[0-5][0-9]$"
 *                 description: End time in 24h format (HH:MM)
 *                 example: "10:00"
 *               clinicId:
 *                 type: string
 *                 format: uuid
 *                 nullable: true
 *                 description: Clinic ID (if doctor has multiple clinics)
 *               roomId:
 *                 type: string
 *                 format: uuid
 *                 nullable: true
 *                 description: Room ID
 *               maxPatients:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 20
 *                 default: 1
 *                 description: Maximum patients for this slot
 *     responses:
 *       201:
 *         description: Quick slot added successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SlotResponse'
 *                 message:
 *                   type: string
 *                   example: Quick slot added successfully
 *       400:
 *         description: Validation error - invalid time, outside availability, overlaps break, or in past
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               InvalidTime:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Start time must be before end time"
 *               OutsideAvailability:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Slot time is outside doctor's availability hours for this day"
 *               OverlapsBreak:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Slot overlaps with a break"
 *               PastDate:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Cannot create a slot in the past"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions
 *       404:
 *         description: Doctor not found
 *       409:
 *         description: A slot already exists at this time
 *       500:
 *         description: Server error
 *     examples:
 *       QuickSlotExample:
 *         summary: Add a 30-minute emergency slot
 *         value:
 *           date: "2026-08-20"
 *           startTime: "09:30"
 *           endTime: "10:00"
 *           maxPatients: 2
 */

// ============================================================
// CLINIC ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/doctors/{doctorId}/slots:
 *   get:
 *     summary: Get doctor slots (Clinic)
 *     description: Get slots for a specific doctor in the clinic
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to check
 *     responses:
 *       200:
 *         description: Slots retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotResponse'
 *       400:
 *         description: Doctor not in your clinic
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Doctor not found
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/doctors/{doctorId}/slots/generate:
 *   post:
 *     summary: Generate slots for doctor (Clinic)
 *     description: |
 *       Generate time slots for a doctor in the clinic.
 *       
 *       **Slot Protection:**
 *       - By default, slots with active appointments CANNOT be deleted.
 *       - You must cancel or complete appointments before regenerating.
 *       
 *       **Force Mode (Admin Only):**
 *       - Set `force: true` to override protection.
 *       - This will CANCEL all active appointments and refund credits.
 *       - ⚠️ WARNING: This action cannot be undone!
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GenerateSlotsRequest'
 *     responses:
 *       201:
 *         description: Slots generated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotResponse'
 *       400:
 *         description: Doctor not in your clinic, validation error, or slots have active appointments
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (force mode requires ADMIN)
 *       404:
 *         description: Doctor not found
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/doctors/{doctorId}/slots/cancel-date:
 *   post:
 *     summary: Cancel doctor slots on date (Clinic)
 *     description: Cancel all slots and appointments for a specific doctor on a date
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CancelSlotsRequest'
 *     responses:
 *       200:
 *         description: Slots cancelled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     cancelledCount:
 *                       type: integer
 *                 message:
 *                   type: string
 *                   example: Slots cancelled
 *       400:
 *         description: Doctor not in your clinic or validation error
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Doctor not found
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/doctors/{doctorId}/slots/quick:
 *   post:
 *     summary: Add a single quick slot for a doctor (Clinic)
 *     description: Add a single time slot for a specific doctor in the clinic without affecting existing slots.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - date
 *               - startTime
 *               - endTime
 *             properties:
 *               date:
 *                 type: string
 *                 format: date
 *                 example: "2026-08-20"
 *               startTime:
 *                 type: string
 *                 example: "14:30"
 *               endTime:
 *                 type: string
 *                 example: "15:00"
 *               roomId:
 *                 type: string
 *                 format: uuid
 *                 nullable: true
 *               maxPatients:
 *                 type: integer
 *                 default: 1
 *     responses:
 *       201:
 *         description: Quick slot added successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SlotResponse'
 *                 message:
 *                   type: string
 *                   example: Quick slot added successfully
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Doctor not in your clinic
 *       404:
 *         description: Doctor not found
 *       409:
 *         description: A slot already exists at this time
 *       500:
 *         description: Server error
 *     examples:
 *       ClinicQuickSlot:
 *         summary: Clinic adds a quick slot
 *         value:
 *           date: "2026-08-20"
 *           startTime: "14:30"
 *           endTime: "15:00"
 *           maxPatients: 1
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/appointments:
 *   get:
 *     summary: Get clinic appointments (Clinic)
 *     description: Retrieves all appointments for the authenticated clinic
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by specific date
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *         description: Filter by status
 *     responses:
 *       200:
 *         description: Appointments retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/book:
 *   post:
 *     summary: Book appointment for a patient (Clinic)
 *     description: |
 *       Clinic books an appointment on behalf of a patient. Creates PENDING appointment.
 *       
 *       **Patient Types:**
 *       - **Registered**: Provide `patientId` (existing user)
 *       - **Guest**: Provide `guestPatient` object (new walk-in patient)
 *       
 *       Exactly one of `patientId` or `guestPatient` must be provided.
 *       
 *       **Payment:**
 *       - Registered patients are charged 1 credit from their wallet
 *       - Guest patients (created by clinic) are FREE
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ClinicBookRequest'
 *     responses:
 *       201:
 *         description: Appointment booked successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentResponse'
 *                 message:
 *                   type: string
 *                   example: Appointment requested
 *       400:
 *         description: Validation error or slot not in clinic
 *       404:
 *         description: Slot or patient not found
 *       409:
 *         description: Slot full or cancelled
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 *     examples:
 *       ClinicBookRegistered:
 *         summary: Book for a registered patient
 *         value:
 *           slotId: "123e4567-e89b-12d3-a456-426614174000"
 *           patientId: "223e4567-e89b-12d3-a456-426614174000"
 *           type: "IN_PERSON"
 *           notes: "Patient registered with us"
 *       ClinicBookGuest:
 *         summary: Book for a guest patient (walk-in) - FREE
 *         value:
 *           slotId: "123e4567-e89b-12d3-a456-426614174000"
 *           guestPatient:
 *             firstName: "Fatima"
 *             lastName: "Zahra"
 *             phone: "0555987654"
 *             dateOfBirth: "1985-10-20"
 *           type: "IN_PERSON"
 *           notes: "New walk-in patient - FREE booking"
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/appointments/{id}/status:
 *   patch:
 *     summary: Update appointment status (Clinic)
 *     description: |
 *       Clinic updates appointment status. Can confirm PENDING appointments.
 *       Valid transitions same as doctor endpoint.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Appointment ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateStatusRequest'
 *     responses:
 *       200:
 *         description: Status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentResponse'
 *       400:
 *         description: Invalid transition or not your appointment
 *       404:
 *         description: Appointment not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */

// ============================================================
// ADMIN ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/admin/appointments:
 *   get:
 *     summary: Get all appointments (Admin)
 *     description: Admin endpoint to retrieve all appointments with advanced filtering
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: doctorId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by doctor
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by clinic
 *       - in: query
 *         name: patientId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by patient
 *       - in: query
 *         name: patientType
 *         schema:
 *           type: string
 *           enum: [REGISTERED, GUEST]
 *         description: Filter by patient type
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED, NO_SHOW]
 *         description: Filter by status
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by specific date
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *           minimum: 1
 *           maximum: 100
 *     responses:
 *       200:
 *         description: Appointments retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires SUPER_ADMIN or ADMIN)
 *       500:
 *         description: Server error
 *     examples:
 *       FilterByDoctor:
 *         summary: Get appointments for a specific doctor
 *         value:
 *           doctorId: "123e4567-e89b-12d3-a456-426614174000"
 *           status: "CONFIRMED"
 *       FilterByDate:
 *         summary: Get all appointments for a specific date
 *         value:
 *           date: "2026-07-15"
 *       FilterByPatient:
 *         summary: Get appointments for a patient
 *         value:
 *           patientId: "223e4567-e89b-12d3-a456-426614174000"
 *       FilterByGuest:
 *         summary: Get all guest appointments
 *         value:
 *           patientType: "GUEST"
 */

// ============================================================
// GUEST PATIENT MANAGEMENT ROUTES (FULL CRUD)
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/guest-patients:
 *   get:
 *     summary: Get all guest patients (Doctor/Clinic)
 *     description: Get all guest patients created by the authenticated doctor or clinic. Only returns patients you created.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *           minimum: 1
 *           maximum: 100
 *         description: Items per page
 *     responses:
 *       200:
 *         description: Guest patients retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedGuestPatientResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       500:
 *         description: Server error
 *   
 *   post:
 *     summary: Create a guest patient (Doctor/Clinic)
 *     description: |
 *       Create a new guest patient independently (without booking an appointment).
 *       
 *       **Note:** Only the creator (doctor/clinic) can view and manage this guest patient.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GuestPatientRequest'
 *     responses:
 *       201:
 *         description: Guest patient created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GuestPatientResponse'
 *                 message:
 *                   type: string
 *                   example: Guest patient created
 *       400:
 *         description: Validation error (phone already exists, missing required fields, etc.)
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       409:
 *         description: Phone number already exists as a registered user or guest patient
 *       500:
 *         description: Server error
 *     examples:
 *       CreateGuestPatient:
 *         summary: Create a new guest patient
 *         value:
 *           firstName: "Mourad"
 *           lastName: "Larbi"
 *           phone: "0555789012"
 *           email: "mourad@example.com"
 *           dateOfBirth: "1978-03-12"
 *           wilayaId: "123e4567-e89b-12d3-a456-426614174000"
 *           notes: "Referred by Dr. Ahmed"
 */

/**
 * @swagger
 * /api/v1/appointment/v1/guest-patients/search:
 *   get:
 *     summary: Search guest patients (Doctor/Clinic)
 *     description: Search guest patients by name or phone. Only searches patients you created.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: q
 *         required: true
 *         schema:
 *           type: string
 *           minLength: 2
 *         description: Search query (minimum 2 characters)
 *         example: "Mourad"
 *     responses:
 *       200:
 *         description: Guest patients found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/GuestPatientResponse'
 *                 message:
 *                   type: string
 *                   example: Guest patients found
 *       400:
 *         description: Search query must be at least 2 characters
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       500:
 *         description: Server error
 *     examples:
 *       SearchByName:
 *         summary: Search by name
 *         value:
 *           q: "Mourad"
 *       SearchByPhone:
 *         summary: Search by phone
 *         value:
 *           q: "0555789012"
 */

/**
 * @swagger
 * /api/v1/appointment/v1/guest-patients/{id}:
 *   get:
 *     summary: Get a specific guest patient (Doctor/Clinic)
 *     description: Get detailed information about a specific guest patient. You can only access patients you created.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Guest patient ID
 *     responses:
 *       200:
 *         description: Guest patient retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GuestPatientResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       404:
 *         description: Guest patient not found (or you don't have access)
 *       500:
 *         description: Server error
 *   
 *   patch:
 *     summary: Update a guest patient (Doctor/Clinic)
 *     description: Update information for a specific guest patient. You can only update patients you created.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Guest patient ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               firstName:
 *                 type: string
 *                 maxLength: 100
 *                 description: Updated first name
 *               lastName:
 *                 type: string
 *                 maxLength: 100
 *                 description: Updated last name
 *               phone:
 *                 type: string
 *                 pattern: "^[0-9]{10,15}$"
 *                 description: Updated phone number
 *               email:
 *                 type: string
 *                 format: email
 *                 nullable: true
 *                 description: Updated email
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *                 nullable: true
 *                 description: Updated date of birth
 *               wilayaId:
 *                 type: string
 *                 format: uuid
 *                 nullable: true
 *                 description: Updated wilaya ID
 *               notes:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *                 description: Updated notes
 *     responses:
 *       200:
 *         description: Guest patient updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GuestPatientResponse'
 *                 message:
 *                   type: string
 *                   example: Guest patient updated
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       404:
 *         description: Guest patient not found (or you don't have access)
 *       409:
 *         description: Phone number already exists for another patient
 *       500:
 *         description: Server error
 *     examples:
 *       UpdateGuestPatient:
 *         summary: Update guest patient
 *         value:
 *           firstName: "Mourad"
 *           lastName: "Ben Larbi"
 *           phone: "0555789012"
 *           notes: "Updated contact info"
 *   
 *   delete:
 *     summary: Delete a guest patient (Doctor/Clinic)
 *     description: |
 *       Permanently delete a guest patient. 
 *       
 *       **Warning:** This will delete all associated appointments and data.
 *       You can only delete patients you created.
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Guest patient ID
 *     responses:
 *       200:
 *         description: Guest patient deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Guest patient deleted
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR or CLINIC)
 *       404:
 *         description: Guest patient not found (or you don't have access)
 *       500:
 *         description: Server error
 */

// ============================================================
// CONVENIENCE ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/appointments/pending:
 *   get:
 *     summary: Get pending appointments (Doctor)
 *     description: Convenience endpoint to get all PENDING appointments for the doctor
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Pending appointments retrieved
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/appointments/pending:
 *   get:
 *     summary: Get pending appointments (Clinic)
 *     description: Convenience endpoint to get all PENDING appointments for the clinic
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Pending appointments retrieved
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedAppointmentResponse'
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/appointments/stats:
 *   get:
 *     summary: Get appointment statistics (Doctor)
 *     description: Get counts of appointments by status for the doctor
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to get stats for (defaults to today)
 *     responses:
 *       200:
 *         description: Statistics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     pending:
 *                       type: integer
 *                     confirmed:
 *                       type: integer
 *                     in_progress:
 *                       type: integer
 *                     completed:
 *                       type: integer
 *                     cancelled:
 *                       type: integer
 *                     no_show:
 *                       type: integer
 *                     total:
 *                       type: integer
 */

/**
 * @swagger
 * /api/v1/appointment/v1/clinic/appointments/stats:
 *   get:
 *     summary: Get appointment statistics (Clinic)
 *     description: Get counts of appointments by status for the clinic
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to get stats for (defaults to today)
 *     responses:
 *       200:
 *         description: Statistics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     pending:
 *                       type: integer
 *                     confirmed:
 *                       type: integer
 *                     in_progress:
 *                       type: integer
 *                     completed:
 *                       type: integer
 *                     cancelled:
 *                       type: integer
 *                     no_show:
 *                       type: integer
 *                     total:
 *                       type: integer
 */

// ============================================================
// SLOT AUTOMATION
// ============================================================

/**
 * @swagger
 * components:
 *   schemas:
 *     SlotAutomationRequest:
 *       type: object
 *       required:
 *         - frequency
 *       properties:
 *         frequency:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY]
 *           description: |
 *             How often to check and extend the booking horizon:
 *             - DAILY: Check every day and extend slots
 *             - WEEKLY: Check every week and extend slots
 *             - MONTHLY: Check every month and extend slots
 *           example: "WEEKLY"
 *         bookingWindowDays:
 *           type: integer
 *           default: 30
 *           minimum: 1
 *           maximum: 365
 *           description: Number of days ahead to generate slots
 *           example: 30
 *         clinicId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Clinic ID (optional - if doctor has multiple clinics)
 *         roomId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Room ID (optional)
 *     
 *     SlotAutomationResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         frequency:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY]
 *         bookingWindowDays:
 *           type: integer
 *         enabled:
 *           type: boolean
 *         clinicId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         roomId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         lastRunAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         nextRunAt:
 *           type: string
 *           format: date-time
 *         errorCount:
 *           type: integer
 *         lastError:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 */

/**
 * @swagger
 * /api/v1/appointment/v1/doctor/slots/automation:
 *   post:
 *     summary: Enable slot automation (Doctor)
 *     description: |
 *       Automatically generate slots on a recurring basis.
 *       
 *       **How it works:**
 *       1. The system checks the doctor's weekly availability (DoctorAvailability)
 *       2. It ensures slots exist X days ahead (bookingWindowDays)
 *       3. Only missing slots are created - NEVER deletes existing/booked slots
 *       
 *       **Frequency meanings:**
 *       - DAILY: Check every day and extend the horizon
 *       - WEEKLY: Check every week and extend the horizon  
 *       - MONTHLY: Check every month and extend the horizon
 *       
 *       **Example:**
 *       - frequency: WEEKLY, bookingWindowDays: 30
 *       - Today is Aug 17, system ensures slots exist until Sep 16
 *       - Next week (Aug 24), system extends until Sep 23
 *       
 *       **Important:** 
 *       - Slots with appointments are NEVER deleted
 *       - The system only creates missing slots
 *       - If a slot already exists (even if booked), it's preserved
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SlotAutomationRequest'
 *     responses:
 *       200:
 *         description: Automation enabled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SlotAutomationResponse'
 *                 message:
 *                   type: string
 *                   example: Slot automation enabled
 *       400:
 *         description: Validation error or doctor not available
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               InvalidFrequency:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Frequency must be DAILY, WEEKLY, or MONTHLY"
 *               DoctorNotAvailable:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Doctor not available"
 *               ClinicNotLinked:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Doctor is not affiliated with this clinic"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR)
 *       500:
 *         description: Server error
 *     examples:
 *       EnableWeekly:
 *         summary: Enable weekly automation with 30-day horizon
 *         value:
 *           frequency: "WEEKLY"
 *           bookingWindowDays: 30
 *       EnableDaily:
 *         summary: Enable daily automation with 60-day horizon
 *         value:
 *           frequency: "DAILY"
 *           bookingWindowDays: 60
 *       EnableMonthly:
 *         summary: Enable monthly automation with 90-day horizon
 *         value:
 *           frequency: "MONTHLY"
 *           bookingWindowDays: 90
 *       EnableWithClinic:
 *         summary: Enable automation for a specific clinic
 *         value:
 *           frequency: "WEEKLY"
 *           bookingWindowDays: 30
 *           clinicId: "clinic-uuid-here"
 *           roomId: "room-uuid-here"
 *   
 *   get:
 *     summary: Get automation status (Doctor)
 *     description: Returns the current automation configuration for the doctor
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Automation status retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SlotAutomationResponse'
 *                 message:
 *                   type: string
 *                   example: Automation status retrieved
 *       404:
 *         description: No automation rule found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: null
 *                 message:
 *                   type: string
 *                   example: Automation status retrieved
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR)
 *       500:
 *         description: Server error
 *   
 *   delete:
 *     summary: Disable slot automation (Doctor)
 *     description: Disables automatic slot generation for the doctor
 *     tags: [Appointment]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Automation disabled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: null
 *                 message:
 *                   type: string
 *                   example: Slot automation disabled
 *       404:
 *         description: No automation rule found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               RuleNotFound:
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 404
 *                     message: "No automation rule found for this doctor"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Insufficient permissions (requires DOCTOR)
 *       500:
 *         description: Server error
 */