import { clinicServiceRepository } from '../../../repositories/clinic-service.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { NotFoundError, ConflictError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { generatePublicUrl } from '../../../core/utils/signed-url';
import { env } from '../../../config/env';
import { fileService } from '../../../modules/file/v1/file.service';
import { StorageFactory } from '../../../core/storage/storage.factory';
import {
  ClinicServiceResponse,
  CreateServiceDTO,
  UpdateServiceDTO,
  ServiceImageResponse,
  AssignDoctorDTO,
  ServiceDoctorResponse,
} from './clinic-service.types';

export class ClinicServiceService {
  private toResponse(service: any): ClinicServiceResponse {
    return {
      id: service.id,
      clinicId: service.clinicId,
      clinic: service.clinic
        ? {
            id: service.clinic.id,
            nameFr: service.clinic.nameFr,
            nameAr: service.clinic.nameAr,
            logoUrl: service.clinic.logoPath ? `${env.BASE_URL}/uploads/${service.clinic.logoPath}` : null,
            wilaya: service.clinic.wilaya,
            baladya: service.clinic.baladya,
          }
        : undefined,
      nameFr: service.nameFr,
      nameAr: service.nameAr,
      descriptionFr: service.descriptionFr,
      descriptionAr: service.descriptionAr,
      isActive: service.isActive,
      sortOrder: service.sortOrder,
      gallery: service.gallery?.map((img: any) => this.toImageResponse(img)) || [],
      doctors: service.doctors?.map((d: any) => this.toDoctorResponse(d)) || [],
      createdAt: service.createdAt.toISOString(),
      updatedAt: service.updatedAt.toISOString(),
    };
  }

  private toImageResponse(img: any): ServiceImageResponse {
    return {
      id: img.id,
      serviceId: img.serviceId,
      imagePath: img.imagePath,
      imageUrl: generatePublicUrl(img.fileId),
      captionFr: img.captionFr,
      captionAr: img.captionAr,
      sortOrder: img.sortOrder,
      isActive: img.isActive,
      createdAt: img.createdAt.toISOString(),
    };
  }

  private toDoctorResponse(link: any): ServiceDoctorResponse {
    return {
      id: link.id,
      serviceId: link.serviceId,
      doctorId: link.doctorId,
      isPrimary: link.isPrimary,
      doctor: {
        id: link.doctor.id,
        firstNameFr: link.doctor.firstNameFr,
        firstNameAr: link.doctor.firstNameAr,
        lastNameFr: link.doctor.lastNameFr,
        lastNameAr: link.doctor.lastNameAr,
        photoUrl: link.doctor.photoPath ? `${env.BASE_URL}/uploads/${link.doctor.photoPath}` : null,
        specialties: link.doctor.specialties?.map((s: any) => ({
          id: s.specialty.id,
          nameFr: s.specialty.nameFr,
          nameAr: s.specialty.nameAr,
        })),
      },
      createdAt: link.createdAt.toISOString(),
    };
  }

  // === CRUD ===

  async getByClinicId(clinicId: string): Promise<ClinicServiceResponse[]> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const services = await clinicServiceRepository.findByClinicId(clinicId);
    return services.map((s: any) => this.toResponse(s));
  }

  async getById(id: string): Promise<ClinicServiceResponse> {
    const service = await clinicServiceRepository.findById(id);
    if (!service) throw new NotFoundError('Service');
    return this.toResponse(service);
  }

  async create(clinicId: string, data: CreateServiceDTO): Promise<ClinicServiceResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const service = await clinicServiceRepository.create({
      nameFr: data.nameFr,
      nameAr: data.nameAr,
      descriptionFr: data.descriptionFr,
      descriptionAr: data.descriptionAr,
      sortOrder: data.sortOrder || 0,
      clinic: { connect: { id: clinicId } },
    });

    return this.toResponse({ ...service, gallery: [], doctors: [] });
  }

  async update(id: string, data: UpdateServiceDTO): Promise<ClinicServiceResponse> {
    const existing = await clinicServiceRepository.findById(id);
    if (!existing) throw new NotFoundError('Service');

    const updateData: any = {};
    if (data.nameFr !== undefined) updateData.nameFr = data.nameFr;
    if (data.nameAr !== undefined) updateData.nameAr = data.nameAr;
    if (data.descriptionFr !== undefined) updateData.descriptionFr = data.descriptionFr;
    if (data.descriptionAr !== undefined) updateData.descriptionAr = data.descriptionAr;
    if (data.sortOrder !== undefined) updateData.sortOrder = data.sortOrder;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;

    const updated = await clinicServiceRepository.update(id, updateData);
    return this.toResponse(updated);
  }

  async delete(id: string): Promise<void> {
    const existing = await clinicServiceRepository.findById(id);
    if (!existing) throw new NotFoundError('Service');
    await clinicServiceRepository.delete(id);
  }

  // === Public Search ===

  async searchPublic(params: any) {
    const { services, total } = await clinicServiceRepository.searchPublic({
      query: params.query,
      wilayaId: params.wilayaId,
      clinicId: params.clinicId,
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
    });

    return {
      services: services.map((s: any) => this.toResponse(s)),
      total,
    };
  }

  // ============================================================
  // GALLERY METHODS
  // ============================================================

  async uploadImage(
    serviceId: string, 
    file: Express.Multer.File,
    captionFr?: string, 
    captionAr?: string
  ): Promise<ServiceImageResponse> {
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) throw new NotFoundError('Service');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'public/service-images',
        isPublic: true,
        contentType: file.mimetype,
        cacheControl: 'public, max-age=31536000',
        metadata: {
          serviceId,
          originalName: file.originalname,
        },
      }
    );

    const maxOrder = await clinicServiceRepository.getMaxSortOrder(serviceId);

    const img = await clinicServiceRepository.addImage({
      imagePath: uploadResult.key,
      filePath: uploadResult.key,
      fileName: file.originalname,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: uploadResult.key,
      captionFr,
      captionAr,
      sortOrder: maxOrder + 1,
      service: { connect: { id: serviceId } },
    });

    return this.toImageResponse(img);
  }

  // ============================================================
  // UPDATED: Delete image from both DB and disk
  // ============================================================

  async deleteImage(imageId: string, clinicId: string): Promise<void> {
    const img = await clinicServiceRepository.findImageById(imageId);
    if (!img) throw new NotFoundError('Image');

    // Get the service to check ownership
    const service = await clinicServiceRepository.findById(img.serviceId);
    if (!service || service.clinicId !== clinicId) {
      throw new ForbiddenError('You can only delete images from your clinic services');
    }

    // Delete from disk (public file)
    await fileService.deleteFile(img.fileId, clinicId, 'CLINIC', true);

    // Delete from database
    await clinicServiceRepository.deleteImage(imageId);
  }

  // === Doctors ===

  async assignDoctor(serviceId: string, data: AssignDoctorDTO): Promise<ServiceDoctorResponse> {
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) throw new NotFoundError('Service');

    const doctor = await doctorRepository.findById(data.doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const existing = await clinicServiceRepository.findServiceDoctor(serviceId, data.doctorId);
    if (existing) throw new ConflictError('Doctor already assigned to this service');

    const link = await clinicServiceRepository.assignDoctor({
      isPrimary: data.isPrimary || false,
      service: { connect: { id: serviceId } },
      doctor: { connect: { id: data.doctorId } },
    });

    return this.toDoctorResponse(link);
  }

  async removeDoctor(serviceId: string, doctorId: string): Promise<void> {
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) throw new NotFoundError('Service');

    const link = await clinicServiceRepository.findServiceDoctor(serviceId, doctorId);
    if (!link) throw new NotFoundError('Doctor assignment');

    await clinicServiceRepository.removeDoctor(serviceId, doctorId);
  }

  async getServiceDoctors(serviceId: string): Promise<ServiceDoctorResponse[]> {
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) throw new NotFoundError('Service');

    const doctors = await clinicServiceRepository.getServiceDoctors(serviceId);
    return doctors.map((d: any) => this.toDoctorResponse(d));
  }
}

export const clinicServiceService = new ClinicServiceService();

