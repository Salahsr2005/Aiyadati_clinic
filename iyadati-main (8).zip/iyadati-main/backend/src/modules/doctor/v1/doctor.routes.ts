import { Router } from 'express';
import { DoctorController } from './doctor.controller';
import { validateCompleteDoctor, validateUpdateDoctor, validateRejectDoctor } from './doctor.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { uploadLogo, uploadDoctorDocument } from '../../../core/middleware/upload.middleware';
import { validateRequestClinic } from './doctor.validation';
import { validateSetAvailability } from './doctor.validation';
import { validateCreateBreak, validateUpdateBreak , validateCreateCompleteDoctor } from './doctor.validation';
import { validateCreateDoctor } from './doctor.validation';
import { validateUpdateBookingAvailability } from './doctor.validation';





const router = Router();
const doctorController = new DoctorController();

// Self-service routes (MUST be before /:id)
router.get('/me/profile', authenticate, authorize('DOCTOR'), doctorController.getMyProfile);
router.patch('/me/complete', authenticate, authorize('DOCTOR'), uploadLogo, validateCompleteDoctor, doctorController.completeMyProfile);
router.get('/me/documents', authenticate, authorize('DOCTOR'), doctorController.getMyDocuments);
router.post('/me/documents', authenticate, authorize('DOCTOR'), uploadDoctorDocument, doctorController.uploadMyDocument);
router.delete('/me/documents/:id', authenticate, authorize('DOCTOR'), doctorController.deleteMyDocument);

// Staff - create doctor
router.post('/', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateCreateDoctor, doctorController.create);
router.post(
  '/create-complete',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  uploadLogo,
  validateCreateCompleteDoctor,
  doctorController.createComplete
);



// Staff routes
router.get('/', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.findAll);
router.get('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.findById);
router.patch('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateDoctor, doctorController.update);
router.post('/:id/verify', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.verify);
router.post('/:id/reject', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateRejectDoctor, doctorController.reject);
router.post('/:id/suspend', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.suspend);
router.post('/:id/unsuspend', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.unsuspend);
router.get('/:id/documents', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.getDocuments);
router.post('/me/clinics/request', authenticate, authorize('DOCTOR'), validateRequestClinic, doctorController.requestToJoinClinic);
router.get('/me/clinic-invitations', authenticate, authorize('DOCTOR'), doctorController.getMyInvitations);
router.post('/me/clinic-invitations/:id/accept', authenticate, authorize('DOCTOR'), doctorController.respondToInvitation);
router.post('/me/clinic-invitations/:id/reject', authenticate, authorize('DOCTOR'), doctorController.respondToInvitation);
// Self-service - before /:id
router.get('/me/availability', authenticate, authorize('DOCTOR'), doctorController.getMyAvailability);
router.put('/me/availability', authenticate, authorize('DOCTOR'), validateSetAvailability, doctorController.setMyAvailability);
router.delete('/me/availability/:id', authenticate, authorize('DOCTOR'), doctorController.deleteAvailabilitySlot);

// Staff - after /:id routes
router.get('/:id/availability', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), doctorController.getDoctorAvailability);
router.post('/:id/documents',authenticate,authorize('SUPER_ADMIN', 'ADMIN'),uploadDoctorDocument,doctorController.uploadDocumentForDoctor);
router.delete('/:id/documents/:documentId',authenticate,authorize('SUPER_ADMIN', 'ADMIN'),doctorController.deleteDoctorDocument);
// Delete doctor (Staff)
router.delete('/:id',authenticate,authorize('SUPER_ADMIN', 'ADMIN'),doctorController.delete);

// NEW: Update booking availability (Staff)
router.patch(
  '/:id/booking-availability',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateBookingAvailability,
  doctorController.updateBookingAvailability
);

// Self-service breaks - before /:id
router.get('/me/breaks', authenticate, authorize('DOCTOR'), doctorController.getMyBreaks);
router.post('/me/breaks', authenticate, authorize('DOCTOR'), validateCreateBreak, doctorController.createBreak);
router.patch('/me/breaks/:id', authenticate, authorize('DOCTOR'), validateUpdateBreak, doctorController.updateBreak);
router.delete('/me/breaks/:id', authenticate, authorize('DOCTOR'), doctorController.deleteBreak);



export default router;

