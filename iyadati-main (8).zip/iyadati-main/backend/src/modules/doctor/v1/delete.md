Checks if doctor exists

Checks for active appointments

If active appointments exist and force=false → Returns 409 Conflict with warning

If no active appointments OR force=true → Proceeds with cleanup:

Deletes all documents (with file service)

Deletes all logos (with file service)

Deletes availability slots

Deletes breaks

Deactivates clinic links

Cancels all active appointments

Deletes all slots

Hard deletes the doctor record

Audit log is created

Notification is sent to the doctor

