export interface DoctorResponse {
  id: string;
  email: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
  wilaya?: { id: string; code: number; nameFr: string; nameAr: string };
  baladyaId: string | null;
  baladya?: { id: string; nameFr: string; nameAr: string } | null;
  bioFr: string | null;
  bioAr: string | null;
  photoPath: string | null;
  photoUrl: string | null;
  photoFileId: string | null;
  yearsOfExp: number | null;
  practiceType: string;
  latitude: number | null;
  longitude: number | null;
  specialties: { id: string; nameFr: string; nameAr: string }[];
  isVerified: boolean;
  isSuspended: boolean;
  isRegistered: boolean;
  rejectionReason: string | null;
  isCompleted: boolean;
  // NEW: Booking availability fields
  isAvailableForBooking: boolean;
  messageForUser: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CompleteDoctorDTO {
  bioFr?: string;
  bioAr?: string;
  yearsOfExp?: number;
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  latitude?: number;
  longitude?: number;
  baladyaId?: string;
  specialtyIds?: string[];
}

export interface UpdateDoctorDTO {
  // Basic info
  firstNameFr?: string;
  firstNameAr?: string;
  lastNameFr?: string;
  lastNameAr?: string;
  phone?: string;
  email?: string;
  wilayaId?: string;
  baladyaId?: string | null;
  
  // Profile details
  bioFr?: string | null;
  bioAr?: string | null;
  yearsOfExp?: number | null;
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  latitude?: number | null;
  longitude?: number | null;
  
  // Status fields (admin only)
  isVerified?: boolean;
  isSuspended?: boolean;
  isCompleted?: boolean;
  isRegistered?: boolean;
  rejectionReason?: string | null;
  
  // Specialties (replace all)
  specialtyIds?: string[] | string;
}

export interface RejectDoctorDTO {
  reason: string;
}

export interface DoctorDocumentResponse {
  id: string;
  doctorId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  docType: string;
  accessUrl: string;
  uploadedAt: string;
  fileId?: string;
  storageType?: string;
}

export interface RequestClinicDTO {
  clinicId: string;
}

export interface DoctorClinicResponse {
  id: string;
  clinicId: string;
  doctorId: string;
  status: string;
  invitedBy: string;
  isActive: boolean;
  joinedAt: string;
  clinic?: {
    id: string;
    nameFr: string;
    nameAr: string;
    email: string;
    phone: string;
    logoUrl: string | null;
  };
}

export interface AvailabilitySlotDTO {
  dayOfWeek: 'SUNDAY' | 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
  startTime: string;  // HH:mm
  endTime: string;    // HH:mm
  clinicId?: string;
  roomId?: string;
}

export interface SetAvailabilityDTO {
  slots: AvailabilitySlotDTO[];
}

export interface AvailabilityResponse {
  id: string;
  doctorId: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  isActive: boolean;
  clinicId: string | null;
  clinic?: { id: string; nameFr: string; nameAr: string } | null;
  roomId: string | null;
  room?: { id: string; name: string } | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateBreakDTO {
  startDate: string;  // YYYY-MM-DD
  endDate: string;    // YYYY-MM-DD
  reason?: string;
  isAllDay?: boolean;
  startTime?: string; // HH:mm (if not all day)
  endTime?: string;   // HH:mm (if not all day)
}

export interface UpdateBreakDTO {
  startDate?: string;
  endDate?: string;
  reason?: string;
  isAllDay?: boolean;
  startTime?: string | null;
  endTime?: string | null;
}

export interface BreakResponse {
  id: string;
  doctorId: string;
  startDate: string;
  endDate: string;
  reason: string | null;
  isAllDay: boolean;
  startTime: string | null;
  endTime: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateDoctorDTO {
  email: string;
  password: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
  specialtyIds?: string[];
}

export interface CreateCompleteDoctorDTO {
  // Required basic info
  email: string;
  password: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
  
  // Required specialties - can be string or array
  specialtyIds: string[] | string;
  
  // Optional profile details
  bioFr?: string;
  bioAr?: string;
  yearsOfExp?: number;
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  latitude?: number;
  longitude?: number;
  baladyaId?: string;
}

// NEW: Update booking availability DTO
export interface UpdateBookingAvailabilityDTO {
  isAvailableForBooking: boolean;
  messageForUser?: string | null;
}


export interface DeleteDoctorResponse {
  message: string;
  doctor?: DoctorResponse;
  softDeleted?: boolean;
}


