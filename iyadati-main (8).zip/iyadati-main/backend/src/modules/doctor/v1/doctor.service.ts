import { doctorRepository } from '../../../repositories/doctor.repository';
import { doctorDocumentRepository } from '../../../repositories/doctor-document.repository';
import { doctorLogoRepository } from '../../../repositories/doctor-logo.repository';
import { NotFoundError, ConflictError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { generateSignedUrl, generatePublicUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { CreateDoctorDTO, DoctorResponse, CompleteDoctorDTO, UpdateDoctorDTO, RejectDoctorDTO, DoctorDocumentResponse,RequestClinicDTO,DoctorClinicResponse,AvailabilityResponse,SetAvailabilityDTO ,BreakResponse,UpdateBreakDTO,CreateBreakDTO, CreateCompleteDoctorDTO, UpdateBookingAvailabilityDTO} from './doctor.types';
import { env } from '../../../config/env';
import { clinicDoctorRepository } from '../../../repositories/clinic-doctor.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { doctorAvailabilityRepository } from '../../../repositories/doctor-availability.repository';
import { doctorBreakRepository } from '../../../repositories/doctor-break.repository';
import { fileService } from '../../../modules/file/v1/file.service';
import { StorageFactory } from '../../../core/storage/storage.factory';
import bcrypt from 'bcryptjs';

export class DoctorService {
  private toResponse(doctor: any): DoctorResponse {
    // Get the latest logo if exists
    const latestLogo = doctor.logos && doctor.logos.length > 0 ? doctor.logos[0] : null;
    
    return {
      id: doctor.id,
      email: doctor.email,
      firstNameFr: doctor.firstNameFr,
      firstNameAr: doctor.firstNameAr,
      lastNameFr: doctor.lastNameFr,
      lastNameAr: doctor.lastNameAr,
      phone: doctor.phone,
      wilayaId: doctor.wilayaId,
      wilaya: doctor.wilaya ? { id: doctor.wilaya.id, code: doctor.wilaya.code, nameFr: doctor.wilaya.nameFr, nameAr: doctor.wilaya.nameAr } : undefined,
      baladyaId: doctor.baladyaId,
      baladya: doctor.baladya ? { id: doctor.baladya.id, nameFr: doctor.baladya.nameFr, nameAr: doctor.baladya.nameAr } : null,
      bioFr: doctor.bioFr,
      bioAr: doctor.bioAr,
      photoPath: doctor.photoPath,
      photoUrl: doctor.photoFileId 
        ? generatePublicUrl(doctor.photoFileId) 
        : latestLogo?.fileId 
          ? generatePublicUrl(latestLogo.fileId)
          : doctor.photoPath 
            ? `${env.BASE_URL}/uploads/${doctor.photoPath}` 
            : null,
      photoFileId: doctor.photoFileId,
      yearsOfExp: doctor.yearsOfExp,
      practiceType: doctor.practiceType,
      latitude: doctor.latitude,
      longitude: doctor.longitude,
      specialties: doctor.specialties?.map((s: any) => ({ id: s.specialty.id, nameFr: s.specialty.nameFr, nameAr: s.specialty.nameAr })) || [],
      isVerified: doctor.isVerified,
      isSuspended: doctor.isSuspended,
      isRegistered: doctor.isRegistered,
      rejectionReason: doctor.rejectionReason,
      isCompleted: doctor.isCompleted,
      // NEW: Booking availability fields
      isAvailableForBooking: doctor.isAvailableForBooking,
      messageForUser: doctor.messageForUser,
      createdAt: doctor.createdAt.toISOString(),
      updatedAt: doctor.updatedAt.toISOString(),
    };
  }

  async findAll(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      search: params.search || undefined,
      wilayaId: params.wilayaId || undefined,
      specialtyId: params.specialtyId || undefined,
      practiceType: params.practiceType || undefined,
      isVerified: params.isVerified !== undefined ? params.isVerified === 'true' : undefined,
      isSuspended: params.isSuspended !== undefined ? params.isSuspended === 'true' : undefined,
      isCompleted: params.isCompleted !== undefined ? params.isCompleted === 'true' : undefined,
      isAvailableForBooking: params.isAvailableForBooking !== undefined ? params.isAvailableForBooking === 'true' : undefined,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };

    const { doctors, total } = await doctorRepository.findAll(parsedParams);
    return {
      doctors: doctors.map((d: any) => this.toResponse(d)),
      total,
    };
  }

  async findById(id: string): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');
    return this.toResponse(doctor);
  }

  async update(id: string, data: UpdateDoctorDTO): Promise<DoctorResponse> {
    const existing = await doctorRepository.findById(id);
    if (!existing) throw new NotFoundError('Doctor');

    // Check email/phone uniqueness if being changed
    if (data.email && data.email !== existing.email) {
      const emailExists = await doctorRepository.emailExists(data.email, id);
      if (emailExists) throw new ConflictError('Email already in use');
    }

    if (data.phone && data.phone !== existing.phone) {
      const phoneExists = await doctorRepository.phoneExists(data.phone, id);
      if (phoneExists) throw new ConflictError('Phone already in use');
    }

    // Build update data
    const updateData: any = {};
    
    // === BASIC INFO ===
    if (data.firstNameFr !== undefined) updateData.firstNameFr = data.firstNameFr;
    if (data.firstNameAr !== undefined) updateData.firstNameAr = data.firstNameAr;
    if (data.lastNameFr !== undefined) updateData.lastNameFr = data.lastNameFr;
    if (data.lastNameAr !== undefined) updateData.lastNameAr = data.lastNameAr;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.wilayaId !== undefined) {
      updateData.wilaya = { connect: { id: data.wilayaId } };
    }
    if (data.baladyaId !== undefined) {
      updateData.baladya = data.baladyaId 
        ? { connect: { id: data.baladyaId } } 
        : { disconnect: true };
    }
    
    // === PROFILE DETAILS ===
    if (data.bioFr !== undefined) updateData.bioFr = data.bioFr;
    if (data.bioAr !== undefined) updateData.bioAr = data.bioAr;
    if (data.yearsOfExp !== undefined) updateData.yearsOfExp = data.yearsOfExp;
    if (data.practiceType !== undefined) updateData.practiceType = data.practiceType;
    if (data.latitude !== undefined) updateData.latitude = data.latitude;
    if (data.longitude !== undefined) updateData.longitude = data.longitude;
    
    // === STATUS FIELDS (Admin only) ===
    if (data.isVerified !== undefined) updateData.isVerified = data.isVerified;
    if (data.isSuspended !== undefined) updateData.isSuspended = data.isSuspended;
    if (data.isCompleted !== undefined) updateData.isCompleted = data.isCompleted;
    if (data.isRegistered !== undefined) updateData.isRegistered = data.isRegistered;
    if (data.rejectionReason !== undefined) updateData.rejectionReason = data.rejectionReason;

    // Update doctor
    const doctor = await doctorRepository.update(id, updateData);

    // === UPDATE SPECIALTIES if provided ===
    if (data.specialtyIds !== undefined) {
      let specialtyIds: string[] = [];
      
      if (Array.isArray(data.specialtyIds)) {
        specialtyIds = data.specialtyIds;
      } else if (typeof data.specialtyIds === 'string') {
        specialtyIds = data.specialtyIds
          .split(',')
          .map((s: string) => s.trim())
          .filter((s: string) => s.length > 0);
      }
      
      await doctorRepository.setSpecialties(id, specialtyIds);
    }

    // Fetch updated doctor with all relations
    const updatedDoctor = await doctorRepository.findById(id);
    return this.toResponse(updatedDoctor);
  }

  async verify(id: string, performedBy: string, ip?: string): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');
    if (doctor.isVerified) throw new BadRequestError('Doctor is already verified');

    const updated = await doctorRepository.verify(id);

    eventEmitter.emit('audit', { action: 'doctor.verified', entity: 'Doctor', entityId: id, performedBy, ip });
    logger.info(`Doctor verified: ${doctor.email} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Account Verified!',
      body: 'Your doctor account has been verified. You can now complete your profile and start receiving appointments.',
      type: 'system',
      data: { type: 'account_verified' },
    });

    return this.toResponse(updated);
  }

  async reject(id: string, data: RejectDoctorDTO, performedBy: string, ip?: string): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');

    const updated = await doctorRepository.reject(id, data.reason);

    eventEmitter.emit('audit', { action: 'doctor.rejected', entity: 'Doctor', entityId: id, performedBy, details: { reason: data.reason }, ip });
    logger.info(`Doctor rejected: ${doctor.email} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Account Not Approved',
      body: `Your account was not approved. Reason: ${data.reason}. You can re-upload documents and submit again.`,
      type: 'system',
      data: { type: 'account_rejected' },
    });

    return this.toResponse(updated);
  }

  async suspend(id: string, performedBy: string, ip?: string): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');
    if (doctor.isSuspended) throw new BadRequestError('Doctor is already suspended');

    const updated = await doctorRepository.suspend(id);

    eventEmitter.emit('audit', { action: 'doctor.suspended', entity: 'Doctor', entityId: id, performedBy, ip });

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Account Suspended',
      body: 'Your account has been suspended. Please contact support for more information.',
      type: 'system',
      data: { type: 'account_suspended' },
    });

    // Also disable booking availability when suspended
    await doctorRepository.updateBookingAvailability(id, {
      isAvailableForBooking: false,
      messageForUser: 'Account suspended',
    });

    return this.toResponse(updated);
  }

  async unsuspend(id: string, performedBy: string, ip?: string): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');
    if (!doctor.isSuspended) throw new BadRequestError('Doctor is not suspended');

    const updated = await doctorRepository.unsuspend(id);

    eventEmitter.emit('audit', { action: 'doctor.unsuspended', entity: 'Doctor', entityId: id, performedBy, ip });

    eventEmitter.emit('notification', {
      userId: id,
      title: 'Account Reinstated',
      body: 'Your account has been unsuspended. Welcome back!',
      type: 'system',
      data: { type: 'account_unsuspended' },
    });

    return this.toResponse(updated);
  }

  async completeProfile(id: string, data: any, file?: Express.Multer.File): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');
    if (!doctor.isVerified) throw new BadRequestError('Doctor must be verified before completing profile');

    const updateData: any = { isCompleted: true };
    
    if (data.bioFr !== undefined) updateData.bioFr = data.bioFr;
    if (data.bioAr !== undefined) updateData.bioAr = data.bioAr;
    
    if (data.yearsOfExp !== undefined) {
      updateData.yearsOfExp = typeof data.yearsOfExp === 'string' 
        ? parseInt(data.yearsOfExp, 10) 
        : data.yearsOfExp;
    }
    
    if (data.practiceType) updateData.practiceType = data.practiceType;
    
    if (data.latitude !== undefined) {
      updateData.latitude = typeof data.latitude === 'string' 
        ? parseFloat(data.latitude) 
        : data.latitude;
    }
    
    if (data.longitude !== undefined) {
      updateData.longitude = typeof data.longitude === 'string' 
        ? parseFloat(data.longitude) 
        : data.longitude;
    }
    
    if (file) {
      const storage = StorageFactory.getInstance();

      const uploadResult = await storage.upload(
        {
          buffer: file.buffer,
          originalName: file.originalname,
          mimeType: file.mimetype,
          size: file.size,
        },
        {
          path: 'public/logos',
          isPublic: true,
          contentType: file.mimetype,
          cacheControl: 'public, max-age=31536000',
          metadata: {
            doctorId: id,
            originalName: file.originalname,
          },
        }
      );

      const logo = await doctorLogoRepository.create({
        doctorId: id,
        filePath: uploadResult.key,
        fileName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        storageKey: uploadResult.key,
      });

      updateData.photoPath = uploadResult.key;
      updateData.photoFileId = logo.fileId;
    }

    
    if (data.baladyaId) updateData.baladya = { connect: { id: data.baladyaId } };

    await doctorRepository.update(id, updateData);

    const specialtyIds = data.specialtyIds;
    if (specialtyIds) {
      let ids: string[] = [];
      
      if (Array.isArray(specialtyIds)) {
        ids = specialtyIds;
      } else if (typeof specialtyIds === 'string') {
        try {
          const parsed = JSON.parse(specialtyIds);
          ids = Array.isArray(parsed) ? parsed : specialtyIds.split(',').map((s: string) => s.trim()).filter(Boolean);
        } catch {
          ids = specialtyIds.split(',').map((s: string) => s.trim()).filter(Boolean);
        }
      }
      
      if (ids.length > 0) {
        await doctorRepository.setSpecialties(id, ids);
      }
    }

    const updatedDoctor = await doctorRepository.findById(id);
    logger.info(`Doctor profile completed: ${updatedDoctor?.email}`);
    return this.toResponse(updatedDoctor);
  }

  // ============================================================
  // DOCUMENT METHODS
  // ============================================================

  async getDocuments(doctorId: string): Promise<DoctorDocumentResponse[]> {
    const docs = await doctorDocumentRepository.findByDoctorId(doctorId);
    return docs.map((d: any) => ({
      id: d.id,
      doctorId: d.doctorId,
      fileName: d.fileName,
      fileType: d.fileType,
      fileSize: d.fileSize,
      docType: d.docType,
      accessUrl: generateSignedUrl(d.fileId),
      uploadedAt: d.uploadedAt?.toISOString() || d.createdAt?.toISOString(),
    }));
  }

  async uploadDocument(doctorId: string, file: Express.Multer.File, docType: string): Promise<DoctorDocumentResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'private/doctor-documents',
        isPublic: false,
        contentType: file.mimetype,
        metadata: {
          doctorId,
          originalName: file.originalname,
        },
      }
    );

    const doc = await doctorDocumentRepository.create({
      doctorId,
      fileName: file.originalname,
      filePath: uploadResult.key,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: uploadResult.key,
      docType: docType || 'other',
      storageType: 'private',
      category: 'document',
    });

    return {
      id: doc.id,
      doctorId: doc.doctorId,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      docType: doc.docType,
      accessUrl: generateSignedUrl(doc.fileId),
      uploadedAt: doc.uploadedAt.toISOString(),
    };
  }

  // ============================================================
  // UPDATED: Delete document from both DB and disk
  // ============================================================

  async deleteDocument(documentId: string, userId: string, userRole: string): Promise<void> {
    const doc = await doctorDocumentRepository.findById(documentId);
    if (!doc) throw new NotFoundError('Document');
    
    if (doc.doctorId !== userId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('You can only delete your own documents');
    }
    
    await fileService.deleteFile(doc.fileId, userId, userRole, false);
    // await doctorDocumentRepository.delete(documentId);
    
    logger.info(`Doctor document deleted: ${doc.fileName} by ${userId}`);
  }

  // ============================================================
  // UPLOAD DOCUMENT FOR DOCTOR (Staff)
  // ============================================================

  async uploadDocumentForDoctor(
    doctorId: string,
    file: Express.Multer.File,
    docType: string,
    performedBy: string,
    ip?: string
  ): Promise<DoctorDocumentResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'private/doctor-documents',
        isPublic: false,
        contentType: file.mimetype,
        metadata: {
          doctorId,
          originalName: file.originalname,
        },
      }
    );

    const doc = await doctorDocumentRepository.create({
      doctorId,
      fileName: file.originalname,
      filePath: uploadResult.key,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: uploadResult.key,
      docType: docType || 'other',
      storageType: 'private',
      category: 'document',
    });

    eventEmitter.emit('audit', {
      action: 'doctor.document_uploaded_by_staff',
      entity: 'Doctor',
      entityId: doctorId,
      performedBy,
      details: { documentId: doc.id, fileName: doc.fileName, docType, fileId: doc.fileId },
      ip,
    });

    logger.info(`Staff ${performedBy} uploaded document for doctor ${doctor.email}`);

    eventEmitter.emit('notification', {
      userId: doctorId,
      title: 'New Document Added',
      body: `A new document "${doc.fileName}" has been added to your account by the admin team.`,
      type: 'system',
      data: { type: 'document_added', documentId: doc.id },
    });

    return {
      id: doc.id,
      doctorId: doc.doctorId,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      docType: doc.docType,
      accessUrl: generateSignedUrl(doc.fileId),
      uploadedAt: doc.uploadedAt.toISOString(),
    };
  }

  // ============================================================
  // UPDATED: Delete doctor document (Staff) from both DB and disk
  // ============================================================

  async deleteDoctorDocument(
    doctorId: string,
    documentId: string,
    performedBy: string,
    ip?: string
  ): Promise<void> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const doc = await doctorDocumentRepository.findById(documentId);
    if (!doc) throw new NotFoundError('Document');
    if (doc.doctorId !== doctorId) throw new BadRequestError('Document does not belong to this doctor');

    await fileService.deleteFile(doc.fileId, performedBy, 'ADMIN', false);
    await doctorDocumentRepository.delete(documentId);

    eventEmitter.emit('audit', {
      action: 'doctor.document_deleted_by_staff',
      entity: 'Doctor',
      entityId: doctorId,
      performedBy,
      details: { documentId, fileName: doc.fileName, docType: doc.docType },
      ip,
    });

    logger.info(`Staff ${performedBy} deleted document for doctor ${doctor.email}`);
  }

  // ============================================================
  // REST OF THE METHODS (Unchanged)
  // ============================================================

  async requestToJoinClinic(doctorId: string, clinicId: string): Promise<DoctorClinicResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    const existing = await clinicDoctorRepository.findByClinicAndDoctor(clinicId, doctorId);
    if (existing) {
      if (existing.status === 'PENDING') throw new BadRequestError('A request is already pending');
      if (existing.status === 'ACCEPTED' && existing.isActive) throw new BadRequestError('You are already in this clinic');
    }

    const link = await clinicDoctorRepository.create({ clinicId, doctorId, invitedBy: 'doctor' });

    return {
      id: link.id,
      clinicId: link.clinicId,
      doctorId: link.doctorId,
      status: link.status,
      invitedBy: link.invitedBy,
      isActive: link.isActive,
      joinedAt: link.joinedAt.toISOString(),
    };
  }

  async getMyInvitations(doctorId: string): Promise<DoctorClinicResponse[]> {
    const links = await clinicDoctorRepository.findByDoctorId(doctorId);
    return links.map((l: any) => ({
      id: l.id,
      clinicId: l.clinicId,
      doctorId: l.doctorId,
      status: l.status,
      invitedBy: l.invitedBy,
      isActive: l.isActive,
      joinedAt: l.joinedAt.toISOString(),
      clinic: {
        id: l.clinic.id,
        nameFr: l.clinic.nameFr,
        nameAr: l.clinic.nameAr,
        email: l.clinic.email,
        phone: l.clinic.phone,
        logoUrl: l.clinic.logoPath ? `${env.BASE_URL}/uploads/${l.clinic.logoPath}` : null,
      },
    }));
  }

  async respondToClinicInvitation(linkId: string, doctorId: string, action: 'ACCEPTED' | 'REJECTED'): Promise<DoctorClinicResponse> {
    const link = await clinicDoctorRepository.findById(linkId);
    if (!link) throw new NotFoundError('Invitation not found');
    if (link.doctorId !== doctorId) throw new BadRequestError('This invitation is not for you');
    if (link.status !== 'PENDING') throw new BadRequestError('Invitation is no longer pending');
    if (link.invitedBy !== 'clinic') throw new BadRequestError('This is not a clinic invitation');

    const updated = await clinicDoctorRepository.updateStatus(linkId, action);

    return {
      id: updated.id,
      clinicId: updated.clinicId,
      doctorId: updated.doctorId,
      status: updated.status,
      invitedBy: updated.invitedBy,
      isActive: updated.isActive,
      joinedAt: updated.joinedAt.toISOString(),
    };
  }

  async getMyAvailability(doctorId: string): Promise<AvailabilityResponse[]> {
    const slots = await doctorAvailabilityRepository.findByDoctorId(doctorId);
    return slots.map((s: any) => ({
      id: s.id,
      doctorId: s.doctorId,
      dayOfWeek: s.dayOfWeek,
      startTime: s.startTime.toISOString().slice(11, 16),
      endTime: s.endTime.toISOString().slice(11, 16),
      isActive: s.isActive,
      clinicId: s.clinicId,
      clinic: s.clinic ? { id: s.clinic.id, nameFr: s.clinic.nameFr, nameAr: s.clinic.nameAr } : null,
      roomId: s.roomId,
      room: s.room ? { id: s.room.id, name: s.room.name } : null,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
    }));
  }

  async setMyAvailability(doctorId: string, data: SetAvailabilityDTO): Promise<AvailabilityResponse[]> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const slots = data.slots.map(s => {
      const [startH, startM] = s.startTime.split(':').map(Number);
      const [endH, endM] = s.endTime.split(':').map(Number);
      
      const startTime = new Date();
      startTime.setHours(startH, startM, 0, 0);
      
      const endTime = new Date();
      endTime.setHours(endH, endM, 0, 0);

      return {
        dayOfWeek: s.dayOfWeek,
        startTime,
        endTime,
        clinicId: s.clinicId,
        roomId: s.roomId,
      };
    });

    const created = await doctorAvailabilityRepository.bulkCreate(doctorId, slots);

    return created.map((s: any) => ({
      id: s.id,
      doctorId: s.doctorId,
      dayOfWeek: s.dayOfWeek,
      startTime: s.startTime.toISOString().slice(11, 16),
      endTime: s.endTime.toISOString().slice(11, 16),
      isActive: s.isActive,
      clinicId: s.clinicId,
      clinic: null,
      roomId: s.roomId,
      room: null,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
    }));
  }

  async deleteAvailabilitySlot(slotId: string, doctorId: string): Promise<void> {
    const slot = await doctorAvailabilityRepository.findById(slotId);
    if (!slot || slot.doctorId !== doctorId) throw new NotFoundError('Availability slot not found');
    await doctorAvailabilityRepository.softDelete(slotId);
  }

  async getDoctorAvailability(doctorId: string): Promise<AvailabilityResponse[]> {
    return this.getMyAvailability(doctorId);
  }

  async getMyBreaks(doctorId: string): Promise<BreakResponse[]> {
    const breaks = await doctorBreakRepository.findByDoctorId(doctorId);
    return breaks.map((b: any) => ({
      id: b.id,
      doctorId: b.doctorId,
      startDate: b.startDate.toISOString().slice(0, 10),
      endDate: b.endDate.toISOString().slice(0, 10),
      reason: b.reason,
      isAllDay: b.isAllDay,
      startTime: b.startTime ? b.startTime.toISOString().slice(11, 16) : null,
      endTime: b.endTime ? b.endTime.toISOString().slice(11, 16) : null,
      createdAt: b.createdAt.toISOString(),
      updatedAt: b.updatedAt.toISOString(),
    }));
  }

  async createBreak(doctorId: string, data: CreateBreakDTO): Promise<BreakResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    const b = await doctorBreakRepository.create({
      doctorId,
      startDate: new Date(data.startDate),
      endDate: new Date(data.endDate),
      reason: data.reason,
      isAllDay: data.isAllDay ?? true,
      startTime: data.startTime ? this.parseTime(data.startTime) : undefined,
      endTime: data.endTime ? this.parseTime(data.endTime) : undefined,
    });

    return {
      id: b.id,
      doctorId: b.doctorId,
      startDate: b.startDate.toISOString().slice(0, 10),
      endDate: b.endDate.toISOString().slice(0, 10),
      reason: b.reason,
      isAllDay: b.isAllDay,
      startTime: b.startTime ? b.startTime.toISOString().slice(11, 16) : null,
      endTime: b.endTime ? b.endTime.toISOString().slice(11, 16) : null,
      createdAt: b.createdAt.toISOString(),
      updatedAt: b.updatedAt.toISOString(),
    };
  }

  async updateBreak(doctorId: string, breakId: string, data: UpdateBreakDTO): Promise<BreakResponse> {
    const existing = await doctorBreakRepository.findById(breakId);
    if (!existing || existing.doctorId !== doctorId) throw new NotFoundError('Break not found');

    const updateData: any = {};
    if (data.startDate) updateData.startDate = new Date(data.startDate);
    if (data.endDate) updateData.endDate = new Date(data.endDate);
    if (data.reason !== undefined) updateData.reason = data.reason;
    if (data.isAllDay !== undefined) updateData.isAllDay = data.isAllDay;
    if (data.startTime !== undefined) updateData.startTime = data.startTime ? this.parseTime(data.startTime) : null;
    if (data.endTime !== undefined) updateData.endTime = data.endTime ? this.parseTime(data.endTime) : null;

    const b = await doctorBreakRepository.update(breakId, updateData);

    return {
      id: b.id,
      doctorId: b.doctorId,
      startDate: b.startDate.toISOString().slice(0, 10),
      endDate: b.endDate.toISOString().slice(0, 10),
      reason: b.reason,
      isAllDay: b.isAllDay,
      startTime: b.startTime ? b.startTime.toISOString().slice(11, 16) : null,
      endTime: b.endTime ? b.endTime.toISOString().slice(11, 16) : null,
      createdAt: b.createdAt.toISOString(),
      updatedAt: b.updatedAt.toISOString(),
    };
  }

  async deleteBreak(doctorId: string, breakId: string): Promise<void> {
    const existing = await doctorBreakRepository.findById(breakId);
    if (!existing || existing.doctorId !== doctorId) throw new NotFoundError('Break not found');
    await doctorBreakRepository.delete(breakId);
  }

  private parseTime(time: string): Date {
    const [h, m] = time.split(':').map(Number);
    const d = new Date();
    d.setHours(h, m, 0, 0);
    return d;
  }

  async createDoctor(data: CreateDoctorDTO, performedBy: string, ip?: string): Promise<DoctorResponse> {
    const [emailExists, phoneExists] = await Promise.all([
      doctorRepository.emailExists(data.email),
      doctorRepository.phoneExists(data.phone),
    ]);

    if (emailExists) throw new ConflictError('Email already exists');
    if (phoneExists) throw new ConflictError('Phone already exists');

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const doctor = await doctorRepository.create({
      email: data.email,
      password: hashedPassword,
      firstNameFr: data.firstNameFr,
      firstNameAr: data.firstNameAr,
      lastNameFr: data.lastNameFr,
      lastNameAr: data.lastNameAr,
      phone: data.phone,
      wilayaId: data.wilayaId,
      isRegistered: false,
      isVerified: true,
      isCompleted: false,
    });

    if (data.specialtyIds && data.specialtyIds.length > 0) {
      await doctorRepository.setSpecialties(doctor.id, data.specialtyIds);
    }

    eventEmitter.emit('audit', {
      action: 'doctor.created_by_staff',
      entity: 'Doctor',
      entityId: doctor.id,
      performedBy,
      details: { email: doctor.email },
      ip,
    });

    logger.info(`Doctor created by staff: ${doctor.email}`);
    return this.toResponse(await doctorRepository.findById(doctor.id));
  }

  async createCompleteDoctor(
    data: CreateCompleteDoctorDTO,
    file?: Express.Multer.File,
    performedBy?: string,
    ip?: string
  ): Promise<DoctorResponse> {
    // 1. Validate email/phone uniqueness
    const [emailExists, phoneExists] = await Promise.all([
      doctorRepository.emailExists(data.email),
      doctorRepository.phoneExists(data.phone),
    ]);
    if (emailExists) throw new ConflictError('Email already exists');
    if (phoneExists) throw new ConflictError('Phone already exists');

    // 2. Get specialties (now it's already parsed by validation)
    // But let's double-check it's an array
    let specialtyIdsArray: string[] = [];
    
    if (Array.isArray(data.specialtyIds)) {
      specialtyIdsArray = data.specialtyIds;
    } else if (typeof data.specialtyIds === 'string') {
      // Just in case validation didn't catch it
      try {
        const parsed = JSON.parse(data.specialtyIds);
        if (Array.isArray(parsed)) {
          specialtyIdsArray = parsed;
        }
      } catch {
        specialtyIdsArray = data.specialtyIds
          .split(',')
          .map(id => id.trim())
          .filter(id => id.length > 0);
      }
    }

    // 3. Validate at least one specialty
    if (specialtyIdsArray.length === 0) {
      throw new BadRequestError('At least one specialty is required');
    }

    // 4. Hash password
    const hashedPassword = await bcrypt.hash(data.password, 12);

    // 5. Prepare doctor data
    const doctorData: any = {
      email: data.email,
      password: hashedPassword,
      firstNameFr: data.firstNameFr,
      firstNameAr: data.firstNameAr,
      lastNameFr: data.lastNameFr,
      lastNameAr: data.lastNameAr,
      phone: data.phone,
      wilayaId: data.wilayaId,
      isRegistered: false,
      isVerified: true,
      isCompleted: true,
      isSuspended: false,
    };

    // 6. Add optional fields if provided
    if (data.bioFr) doctorData.bioFr = data.bioFr;
    if (data.bioAr) doctorData.bioAr = data.bioAr;
    if (data.yearsOfExp) doctorData.yearsOfExp = data.yearsOfExp;
    if (data.practiceType) doctorData.practiceType = data.practiceType;
    if (data.latitude) doctorData.latitude = data.latitude;
    if (data.longitude) doctorData.longitude = data.longitude;
    if (data.baladyaId) doctorData.baladya = { connect: { id: data.baladyaId } };

    // 7. Create doctor first to get ID
    const doctor = await doctorRepository.create(doctorData);

    // 8. Handle logo upload if provided
    if (file) {
      const storage = StorageFactory.getInstance();

      const uploadResult = await storage.upload(
        {
          buffer: file.buffer,
          originalName: file.originalname,
          mimeType: file.mimetype,
          size: file.size,
        },
        {
          path: 'public/logos',
          isPublic: true,
          contentType: file.mimetype,
          cacheControl: 'public, max-age=31536000',
          metadata: {
            doctorId: doctor.id,
            originalName: file.originalname,
          },
        }
      );

      const logo = await doctorLogoRepository.create({
        doctorId: doctor.id,
        filePath: uploadResult.key,
        fileName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        storageKey: uploadResult.key,
      });

      await doctorRepository.update(doctor.id, {
        photoPath: uploadResult.key,
        photoFileId: logo.fileId,
      });
    }

    // 9. Assign specialties
    if (specialtyIdsArray.length > 0) {
      await doctorRepository.setSpecialties(doctor.id, specialtyIdsArray);
    }

    // 10. Audit & Notification
    eventEmitter.emit('audit', {
      action: 'doctor.complete_created_by_staff',
      entity: 'Doctor',
      entityId: doctor.id,
      performedBy,
      details: {
        email: doctor.email,
        isCompleted: true,
        specialtiesCount: specialtyIdsArray.length,
        hasLogo: !!file,
      },
      ip,
    });

    logger.info(`Doctor fully created by staff: ${doctor.email}`);

    eventEmitter.emit('notification', {
      userId: doctor.id,
      title: 'Welcome to Iyadati!',
      body: 'Your doctor account has been created and is ready to use. Start managing your practice immediately.',
      type: 'system',
      data: { type: 'account_created', isCompleted: true },
    });

    return this.toResponse(await doctorRepository.findById(doctor.id));
  }

  // ============================================================
  // NEW: Update Booking Availability
  // ============================================================

  async updateBookingAvailability(
    id: string,
    data: UpdateBookingAvailabilityDTO,
    performedBy: string,
    ip?: string
  ): Promise<DoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');

    // If disabling, clear the message
    if (!data.isAvailableForBooking) {
      const updated = await doctorRepository.updateBookingAvailability(id, {
        isAvailableForBooking: false,
        messageForUser: null,
      });

      eventEmitter.emit('audit', {
        action: 'doctor.booking_disabled',
        entity: 'Doctor',
        entityId: id,
        performedBy,
        details: { 
          isAvailableForBooking: false,
          previousMessage: doctor.messageForUser,
        },
        ip,
      });

      logger.info(`Doctor booking disabled: ${doctor.email} by ${performedBy}`);
      return this.toResponse(await doctorRepository.findById(id));
    }

    // If enabling, update with optional message
    const updated = await doctorRepository.updateBookingAvailability(id, {
      isAvailableForBooking: true,
      messageForUser: data.messageForUser || null,
    });

    eventEmitter.emit('audit', {
      action: 'doctor.booking_enabled',
      entity: 'Doctor',
      entityId: id,
      performedBy,
      details: { 
        isAvailableForBooking: true,
        messageForUser: data.messageForUser,
      },
      ip,
    });

    logger.info(`Doctor booking enabled: ${doctor.email} by ${performedBy}`);

    // If there's a message, send notification to doctor
    if (data.messageForUser) {
      eventEmitter.emit('notification', {
        userId: id,
        title: '📅 Booking Availability Updated',
        body: `Your booking availability has been updated. ${data.messageForUser}`,
        type: 'system',
        data: { type: 'booking_availability_updated', message: data.messageForUser },
      });
    }

    return this.toResponse(await doctorRepository.findById(id));
  }

  /**
   * Delete doctor by ID (Admin only)
   * - Checks if doctor exists
   * - Checks if doctor has active appointments
   * - If active appointments exist, suggests soft delete
   * - Hard deletes if no active appointments
   * - Logs audit and sends notification
   */
  async deleteDoctor(
    id: string,
    performedBy: string,
    ip?: string,
    force?: boolean
  ): Promise<{ message: string; doctor?: DoctorResponse; softDeleted?: boolean }> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor) throw new NotFoundError('Doctor');

    // Check for active appointments
    const activeAppointments = await doctorRepository.getActiveAppointmentsCount(id);

    if (activeAppointments > 0 && !force) {
      // Suggest soft delete instead
      return {
        message: `Doctor has ${activeAppointments} active appointment(s). Use force=true to delete anyway, or use suspend endpoint for soft deletion.`,
        softDeleted: false,
      };
    }

    // If force is true or no active appointments, proceed with hard delete
    // First, clean up related data
    await this.cleanupDoctorData(id);

    // Hard delete the doctor
    const deletedDoctor = await doctorRepository.delete(id);

    // Audit log
    eventEmitter.emit('audit', {
      action: 'doctor.deleted',
      entity: 'Doctor',
      entityId: id,
      performedBy,
      details: { 
        email: doctor.email, 
        activeAppointments,
        force: force || false,
      },
      ip,
    });

    logger.info(`Doctor deleted: ${doctor.email} by ${performedBy} (active appointments: ${activeAppointments})`);

    // Send notification to the doctor
    try {
      eventEmitter.emit('notification', {
        userId: doctor.id,
        title: 'Account Deleted',
        body: 'Your doctor account has been permanently deleted. If you believe this is an error, please contact support.',
        type: 'system',
        data: { type: 'account_deleted' },
      });
    } catch (error) {
      logger.warn(`Could not send deletion notification to doctor ${doctor.email}:`, error);
    }

    return {
      message: 'Doctor deleted successfully',
      doctor: this.toResponse(deletedDoctor),
      softDeleted: false,
    };
  }

  /**
   * Clean up doctor-related data before hard delete
   * This ensures we don't leave orphaned records
   * ✅ Uses repositories only - no direct Prisma calls
   */
  private async cleanupDoctorData(doctorId: string): Promise<void> {
    // 1. Delete all doctor documents (files will be deleted by file service)
    const documents = await doctorDocumentRepository.findByDoctorId(doctorId);
    for (const doc of documents) {
      try {
        await fileService.deleteFile(doc.fileId, 'system', 'SYSTEM', false);
      } catch (error) {
        logger.warn(`Failed to delete document ${doc.fileId} for doctor ${doctorId}:`, error);
      }
    }
    // Delete document records from database
    await doctorDocumentRepository.deleteByDoctorId(doctorId);

    // 2. Delete all doctor logos
    const logos = await doctorLogoRepository.findByDoctorId(doctorId);
    if (logos) {
      try {
        await fileService.deleteFile(logos.fileId, 'system', 'SYSTEM', false);
      } catch (error) {
        logger.warn(`Failed to delete logo for doctor ${doctorId}:`, error);
      }
      await doctorLogoRepository.delete(logos.id);
    }

    // 3. Delete availability slots (soft delete them)
    await doctorAvailabilityRepository.deleteByDoctorId(doctorId);
    
    // 4. Delete breaks
    const breaks = await doctorBreakRepository.findByDoctorId(doctorId);
    for (const b of breaks) {
      await doctorBreakRepository.delete(b.id);
    }

    // 5. Deactivate clinic links
    await doctorRepository.deactivateAllClinicLinks(doctorId);

    // 6. Cancel all active appointments
    await doctorRepository.cancelAllActiveAppointments(
      doctorId,
      'system',
      'Doctor account deleted'
    );

    // 7. Delete all slots
    await doctorRepository.deleteAllSlots(doctorId);

    // Note: DoctorSpecialty and DoctorReview will be deleted by Prisma's onDelete: Cascade
    // No need to manually delete them
  }

  /**
   * Force delete doctor (admin only) - bypasses appointment checks
   */
  async forceDeleteDoctor(
    id: string,
    performedBy: string,
    ip?: string
  ): Promise<{ message: string; doctor?: DoctorResponse }> {
    const result = await this.deleteDoctor(id, performedBy, ip, true);
    return {
      message: result.message,
      doctor: result.doctor,
    };
  }


}

export const doctorService = new DoctorService();

