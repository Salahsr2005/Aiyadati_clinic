import { chatRepository } from '../../../repositories/chat.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { eventEmitter } from '../../../core/events/event-emitter';
import { logger } from '../../../core/utils/logger';
import { RoomResponse, MessageResponse } from './chat.types';
import { notificationQueue } from '../../../infrastructure/queues/notification/notification.queue'; 
import { prisma } from '../../../core/utils/prisma';

// Support staff roles constant (matching socket.ts)
const SUPPORT_STAFF_ROLES = ['SUPPORT', 'ADMIN', 'SUPER_ADMIN'];

export class ChatService {

  async getMyRooms(userId: string): Promise<RoomResponse[]> {
    const rooms = await chatRepository.findRoomsByUserId(userId);

    return rooms.map(room => ({
      id: room.id,
      userId: room.userId,
      userRole: room.userRole,
      userName: room.userName,
      userEmail: room.userEmail,
      supportId: room.supportId,
      status: room.status,
      lastMessage: room.lastMessage,
      unreadCount: 0,
      createdAt: room.createdAt.toISOString(),
      updatedAt: room.updatedAt.toISOString(),
    }));
  }

  async createRoom(userId: string, userRole: string, userName: string, userEmail: string, firstMessage: string): Promise<RoomResponse> {
    const existing = await chatRepository.findOpenRoomByUserId(userId);

    if (existing) {
      return {
        id: existing.id, userId: existing.userId, userRole: existing.userRole,
        userName: existing.userName, userEmail: existing.userEmail,
        supportId: existing.supportId, status: existing.status,
        lastMessage: existing.lastMessage, unreadCount: 0,
        createdAt: existing.createdAt.toISOString(), updatedAt: existing.updatedAt.toISOString(),
      };
    }

    const room = await chatRepository.createRoom({ userId, userRole, userName, userEmail });

    await chatRepository.createMessage({
      roomId: room.id,
      senderId: userId,
      senderRole: userRole,
      senderName: userName,
      message: firstMessage,
    });

    await chatRepository.updateRoom(room.id, { lastMessage: firstMessage });

    // ✅ Use notificationQueue instead of eventEmitter
    // 1. Notify support staff about new chat
    const supportUserIds = await this.getSupportUserIds();
    
    for (const supportId of supportUserIds) {
      await notificationQueue.enqueue({
        userId: supportId,
        title: '💬 New Support Request',
        body: `${userName} (${userRole}) needs help: "${firstMessage.substring(0, 50)}${firstMessage.length > 50 ? '...' : ''}"`,
        type: 'chat',
        data: { 
          roomId: room.id, 
          type: 'new_chat', 
          userId, 
          userRole, 
          userName,
          chatType: 'support_request'
        },
      });
    }

    // 2. Notify user that support has been notified
    await notificationQueue.enqueue({
      userId,
      title: '💬 Support Request Sent',
      body: 'Your support request has been sent. A support agent will respond shortly.',
      type: 'chat',
      data: { 
        roomId: room.id, 
        type: 'chat_created',
        chatType: 'confirmation'
      },
    });

    logger.info(`Chat room created for ${userName} (${userRole})`);

    return {
      id: room.id, userId: room.userId, userRole: room.userRole,
      userName: room.userName, userEmail: room.userEmail,
      supportId: room.supportId, status: room.status,
      lastMessage: firstMessage, unreadCount: 0,
      createdAt: room.createdAt.toISOString(), updatedAt: room.updatedAt.toISOString(),
    };
  }

  async getMessages(roomId: string, userId: string, userRole: string): Promise<MessageResponse[]> {
    const room = await chatRepository.findRoomById(roomId);
    if (!room) throw new NotFoundError('Room not found');
    
    // 🆕 FIXED: Allow support staff (SUPPORT, ADMIN, SUPER_ADMIN) to access any room
    // Regular users (USER, DOCTOR, CLINIC) can only access their own rooms
    const isSupportStaff = SUPPORT_STAFF_ROLES.includes(userRole);
    if (!isSupportStaff && room.userId !== userId) {
      throw new BadRequestError('Access denied - you can only view your own rooms');
    }

    const messages = await chatRepository.findMessagesByRoomId(roomId);

    return messages.map(m => ({
      id: m.id, roomId: m.roomId, senderId: m.senderId,
      senderRole: m.senderRole, senderName: m.senderName,
      message: m.message, createdAt: m.createdAt.toISOString(),
    }));
  }

  async getSupportRooms(): Promise<RoomResponse[]> {
    const rooms = await chatRepository.findAllOpenRooms();

    return rooms.map(room => ({
      id: room.id, userId: room.userId, userRole: room.userRole,
      userName: room.userName, userEmail: room.userEmail,
      supportId: room.supportId, status: room.status,
      lastMessage: room.lastMessage, unreadCount: 0,
      createdAt: room.createdAt.toISOString(), updatedAt: room.updatedAt.toISOString(),
    }));
  }

  async closeRoom(roomId: string, supportId: string): Promise<void> {
    const room = await chatRepository.findRoomById(roomId);
    if (!room) throw new NotFoundError('Room not found');

    await chatRepository.updateRoom(roomId, { status: 'closed', supportId });

    // ✅ Use notificationQueue instead of eventEmitter
    // Notify user that chat was closed
    await notificationQueue.enqueue({
      userId: room.userId,
      title: '💬 Support Chat Closed',
      body: 'Your support request has been resolved and closed. If you need further assistance, start a new chat.',
      type: 'chat',
      data: { 
        roomId, 
        type: 'chat_closed',
        chatType: 'closed'
      },
    });

    // Notify support that chat was closed (optional - broadcast to all support staff)
    const supportUserIds = await this.getSupportUserIds();
    for (const supportUserId of supportUserIds) {
      await notificationQueue.enqueue({
        userId: supportUserId,
        title: '📋 Support Chat Closed',
        body: `Chat with ${room.userName} (${room.userRole}) has been closed.`,
        type: 'chat',
        data: { 
          roomId, 
          type: 'chat_closed_by_support',
          chatType: 'closed_by_support',
          userName: room.userName,
        },
      });
    }

    logger.info(`Chat room ${roomId} closed by support ${supportId}`);
  }

  /**
   * 🆕 Get all support staff user IDs (SUPPORT, ADMIN, SUPER_ADMIN)
   * This should be cached for performance
   */
  private async getSupportUserIds(): Promise<string[]> {
    // Get support staff from Admin table
    const admins = await prisma.admin.findMany({
      where: {
        role: { in: ['SUPPORT', 'ADMIN', 'SUPER_ADMIN'] },
      },
      select: { id: true },
    });

    // Get from SuperAdmin table
    const superAdmins = await prisma.superAdmin.findMany({
      select: { id: true },
    });

    // Combine and deduplicate
    const ids = [
      ...admins.map(a => a.id),
      ...superAdmins.map(s => s.id),
    ];

    // Remove duplicates
    return [...new Set(ids)];
  }

  /**
   * 🆕 Send a notification when a new message is sent (called from Socket.io)
   * This should be called from the socket event handler
   */
  async sendMessageNotification(
    roomId: string,
    senderId: string,
    senderName: string,
    senderRole: string,
    message: string,
    recipientUserId: string
  ): Promise<void> {
    // Get the room to check who the recipient is
    const room = await chatRepository.findRoomById(roomId);
    if (!room) return;

    // Determine the recipient (the other party)
    // If sender is the user, recipient is support staff
    // If sender is support staff, recipient is the user
    const isSupportStaff = SUPPORT_STAFF_ROLES.includes(senderRole);
    let recipientId: string;

    if (isSupportStaff) {
      // Sender is support → notify the user
      recipientId = room.userId;
    } else {
      // Sender is user → notify support staff
      // Get all support staff IDs
      const supportIds = await this.getSupportUserIds();
      // We'll send to all support staff (they'll filter by room)
      // But for individual notification, we'd need to know which support is assigned
      // For now, broadcast to all support staff via the socket `new_support_request` event
      // And also send push notifications to all support staff
      for (const supportId of supportIds) {
        await notificationQueue.enqueue({
          userId: supportId,
          title: `💬 New message from ${senderName}`,
          body: `${message.substring(0, 60)}${message.length > 60 ? '...' : ''}`,
          type: 'chat',
          data: {
            roomId,
            type: 'new_chat_message',
            chatType: 'new_message',
            senderId,
            senderName,
            senderRole,
          },
        });
      }
      return;
    }

    // Send notification to the recipient
    await notificationQueue.enqueue({
      userId: recipientId,
      title: `💬 New message from ${senderName}`,
      body: `${message.substring(0, 60)}${message.length > 60 ? '...' : ''}`,
      type: 'chat',
      data: {
        roomId,
        type: 'new_chat_message',
        chatType: 'new_message',
        senderId,
        senderName,
        senderRole,
      },
    });

    logger.info(`Chat notification sent to ${recipientId} from ${senderName}`);
  }
}

export const chatService = new ChatService();

