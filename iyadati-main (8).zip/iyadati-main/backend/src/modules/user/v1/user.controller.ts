import { Request, Response, NextFunction } from 'express';
import { userService } from './user.service';
import { ResponseUtil } from '../../../core/utils/response';
import { uploadUserDocument } from '../../../core/middleware/upload.middleware';


export class UserController {
  getUsers = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await userService.getUsers(req.query as any);
      ResponseUtil.paginated(
        res, result.users, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 10,
        'Users retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  getUserById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await userService.getUserById(req.params.id);
      ResponseUtil.success(res, user, 'User retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  getUserByEmail = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await userService.getUserByEmail(req.params.email);
      ResponseUtil.success(res, user, 'User retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  getUserByPhone = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await userService.getUserByPhone(req.params.phone);
      ResponseUtil.success(res, user, 'User retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  suspendUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await userService.suspendUser(req.params.id, req.body, req.user!.id, req.ip);
      ResponseUtil.success(res, user, 'User suspended successfully');
    } catch (error) {
      next(error);
    }
  };

  unsuspendUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await userService.unsuspendUser(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, user, 'User unsuspended successfully');
    } catch (error) {
      next(error);
    }
  };

  getMyContacts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const contacts = await userService.getMyContacts(req.user!.id);
      ResponseUtil.success(res, contacts, 'Contacts retrieved successfully');
    } catch (error) { next(error); }
  };

  createContact = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const contact = await userService.createContact(req.user!.id, req.body);
      ResponseUtil.created(res, contact, 'Contact created successfully');
    } catch (error) { next(error); }
  };

  updateContact = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const contact = await userService.updateContact(req.user!.id, req.params.id, req.body);
      ResponseUtil.success(res, contact, 'Contact updated successfully');
    } catch (error) { next(error); }
  };

  deleteContact = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await userService.deleteContact(req.user!.id, req.params.id);
      ResponseUtil.success(res, null, 'Contact deleted successfully');
    } catch (error) { next(error); }
  };

  getMyDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { documents, total } = await userService.getMyDocuments(req.user!.id, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10);
      ResponseUtil.paginated(res, documents, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Documents retrieved');
    } catch (error) { next(error); }
  };

  uploadDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Document is required'); return; }
      const doc = await userService.uploadDocument(req.user!.id, req.file, req.body);
      ResponseUtil.created(res, doc, 'Document uploaded');
    } catch (error) { next(error); }
  };

  updateDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doc = await userService.updateDocument(req.user!.id, req.params.id, req.body);
      ResponseUtil.success(res, doc, 'Document updated');
    } catch (error) { next(error); }
  };

  deleteDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await userService.deleteDocument(
        req.user!.id, 
        req.params.id,
        req.user!.role
      );
      ResponseUtil.success(res, null, 'Document deleted');
    } catch (error) { next(error); }
  };

  requestDeletion = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await userService.requestAccountDeletion(req.user!.id, req.body.reason);
      ResponseUtil.success(res, result, 'Account deletion requested');
    } catch (error) {
      next(error);
    }
  };

  cancelDeletion = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await userService.cancelAccountDeletion(req.user!.id);
      ResponseUtil.success(res, result, 'Deletion cancelled');
    } catch (error) {
      next(error);
    }
  };

  getDeletionStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await userService.getDeletionStatus(req.user!.id);
      ResponseUtil.success(res, result, 'Deletion status retrieved');
    } catch (error) {
      next(error);
    }
  };

}
