/**
 * @swagger
 * tags:
 *   name: Users
 *   description: User management endpoints (Staff and User self-service)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     UserResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         email:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         dateOfBirth:
 *           type: string
 *           format: date-time
 *         wilayaId:
 *           type: string
 *         wilaya:
 *           type: object
 *         isVerified:
 *           type: boolean
 *         isSuspended:
 *           type: boolean
 *         suspensionReason:
 *           type: string
 *           nullable: true
 *         noShowCount:
 *           type: integer
 *           example: 0
 *           description: Number of no-show appointments (3 = suspended)
 *         trustPoints:
 *           type: number
 *           example: 5
 *           description: Trust points based on attendance history
 *         trustLevel:
 *           type: integer
 *           example: 2
 *           description: 0=Unreliable, 1=New Patient, 2=Trusted, 3=VIP
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     SuspendUserRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500
 *     CreateContactUserRequest:
 *       type: object
 *       required:
 *         - firstName
 *         - lastName
 *         - phone
 *         - dateOfBirth
 *       properties:
 *         firstName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         lastName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *         dateOfBirth:
 *           type: string
 *           format: date
 *         relationship:
 *           type: string
 *           enum: [parent, child, spouse, sibling, other]
 *     UpdateContactUserRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         dateOfBirth:
 *           type: string
 *         relationship:
 *           type: string
 *           nullable: true
 *     ContactUserResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         userId:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         dateOfBirth:
 *           type: string
 *         relationship:
 *           type: string
 *           nullable: true
 *         isActive:
 *           type: boolean
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     UserDocumentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         userId:
 *           type: string
 *         fileName:
 *           type: string
 *         fileType:
 *           type: string
 *         fileSize:
 *           type: integer
 *         title:
 *           type: string
 *           nullable: true
 *         description:
 *           type: string
 *           nullable: true
 *         docDate:
 *           type: string
 *           nullable: true
 *         tags:
 *           type: string
 *           nullable: true
 *         accessUrl:
 *           type: string
 *           description: |
 *             Signed URL for document access (expires in 30 minutes).
 *             The URL uses a secure UUID (fileId) instead of exposing the file path.
 *             Format: /api/v1/files/private/{fileId}?expires={timestamp}&signature={hash}
 *           example: "http://localhost:3975/api/v1/files/private/550e8400-e29b-41d4-a716-446655440000?expires=1784569353394&signature=44da603063166cc17ad803c8c7b575ae1b273df0fe4532fafc8bc38bdc4c6a56"
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     CreateUserDocumentRequest:
 *       type: object
 *       properties:
 *         title:
 *           type: string
 *           maxLength: 200
 *         description:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         docDate:
 *           type: string
 *           format: date
 *         tags:
 *           type: string
 *           maxLength: 300
 *     UpdateUserDocumentRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         title:
 *           type: string
 *           maxLength: 200
 *         description:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         docDate:
 *           type: string
 *           format: date
 *           nullable: true
 *         tags:
 *           type: string
 *           maxLength: 300
 *           nullable: true
 *     RequestDeletionRequest:
 *       type: object
 *       properties:
 *         reason:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           description: Optional reason for account deletion
 *     AccountDeletionStatusResponse:
 *       type: object
 *       properties:
 *         status:
 *           type: string
 *           enum: [active, pending, deleted, none]
 *           description: Current deletion status
 *         scheduledDate:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           description: Date when account will be permanently deleted (only when pending)
 *         reversibleUntil:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           description: Deadline to cancel deletion (24 hours after request)
 *         daysRemaining:
 *           type: integer
 *           nullable: true
 *           description: Days remaining until permanent deletion
 *     AccountDeletionRequestResponse:
 *       type: object
 *       properties:
 *         message:
 *           type: string
 *           example: "Account deletion requested. Your account will be permanently deleted in 30 days. You can cancel within 24 hours."
 *         scheduledDate:
 *           type: string
 *           format: date-time
 *           description: Date when account will be permanently deleted
 */

/**
 * @swagger
 * /api/v1/user/v1:
 *   get:
 *     summary: Get all users with filters (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *       - in: query
 *         name: email
 *         schema:
 *           type: string
 *       - in: query
 *         name: phone
 *         schema:
 *           type: string
 *       - in: query
 *         name: firstName
 *         schema:
 *           type: string
 *       - in: query
 *         name: lastName
 *         schema:
 *           type: string
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           default: desc
 *     responses:
 *       200:
 *         description: Users retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/UserResponse'
 *                 meta:
 *                   type: object
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/id/{id}:
 *   get:
 *     summary: Get user by ID (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserResponse'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/email/{email}:
 *   get:
 *     summary: Get user by email (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: email
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserResponse'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/phone/{phone}:
 *   get:
 *     summary: Get user by phone (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: phone
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserResponse'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/{id}/suspend:
 *   post:
 *     summary: Suspend a user (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SuspendUserRequest'
 *     responses:
 *       200:
 *         description: Suspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserResponse'
 *       400:
 *         description: User already suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/{id}/unsuspend:
 *   post:
 *     summary: Unsuspend a user (Staff)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Unsuspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserResponse'
 *       400:
 *         description: User is not suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/contacts:
 *   get:
 *     summary: Get my contacts (User)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Contacts retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ContactUserResponse'
 *   post:
 *     summary: Add a contact (User)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateContactUserRequest'
 *     responses:
 *       201:
 *         description: Created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ContactUserResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/contacts/{id}:
 *   patch:
 *     summary: Update a contact (User)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateContactUserRequest'
 *     responses:
 *       200:
 *         description: Updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ContactUserResponse'
 *       404:
 *         description: Contact not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *   delete:
 *     summary: Delete a contact (User)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *       404:
 *         description: Contact not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/documents:
 *   get:
 *     summary: Get my medical documents (User)
 *     description: |
 *       Returns paginated list of user's medical history documents (prescriptions, lab results, etc.).
 *       Each document URL contains a secure UUID (fileId) instead of the file path.
 *       URLs expire after 30 minutes.
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/UserDocumentResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Upload medical document (User)
 *     description: |
 *       Upload a medical document (PDF, JPEG, PNG, max 20MB). Use multipart/form-data field `document`.
 *       
 *       **Security:** Files are stored with UUID filenames and accessed via signed URLs.
 *       The access URL will contain only the file ID, not the file path.
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - document
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *               title:
 *                 type: string
 *                 maxLength: 200
 *                 description: Document title
 *               description:
 *                 type: string
 *                 maxLength: 500
 *                 description: Document description
 *               docDate:
 *                 type: string
 *                 format: date
 *                 description: Date associated with the document
 *               tags:
 *                 type: string
 *                 maxLength: 300
 *                 description: Comma-separated tags
 *           example:
 *             title: "Blood Test Results"
 *             description: "Annual blood test results from lab"
 *             docDate: "2026-07-15"
 *             tags: "lab,blood,annual"
 *     responses:
 *       201:
 *         description: Document uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserDocumentResponse'
 *       400:
 *         description: Invalid file or missing document
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       413:
 *         description: File too large (max 20MB)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/documents/{id}:
 *   patch:
 *     summary: Update document info (User)
 *     description: Update metadata for a medical document. Cannot change the file itself.
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateUserDocumentRequest'
 *     responses:
 *       200:
 *         description: Updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserDocumentResponse'
 *       404:
 *         description: Document not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *   delete:
 *     summary: Delete document (User)
 *     description: |
 *       Deletes a medical document owned by the authenticated user.
 *       Also deletes the physical file from storage.
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to delete
 *     responses:
 *       200:
 *         description: Deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (document doesn't belong to you)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Document not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/delete/request:
 *   post:
 *     summary: Request account deletion (User)
 *     description: |
 *       Initiates the account deletion process.
 *       
 *       **How it works:**
 *       - Account is immediately suspended (cannot login)
 *       - 30-day grace period starts
 *       - User can cancel within the first 24 hours
 *       - After 30 days, account is permanently deleted
 *       - Background job handles permanent deletion
 *       
 *       **Effects:**
 *       - User cannot login
 *       - All authenticated endpoints are blocked
 *       - Only deletion management endpoints remain accessible
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RequestDeletionRequest'
 *           example:
 *             reason: "No longer need the service"
 *     responses:
 *       200:
 *         description: Deletion requested successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Account deletion requested. Your account will be permanently deleted in 30 days. You can cancel within 24 hours.
 *                 data:
 *                   $ref: '#/components/schemas/AccountDeletionRequestResponse'
 *             example:
 *               success: true
 *               message: "Account deletion requested. Your account will be permanently deleted in 30 days. You can cancel within 24 hours."
 *               data:
 *                 message: "Account deletion requested. Your account will be permanently deleted in 30 days. You can cancel within 24 hours."
 *                 scheduledDate: "2026-09-22T00:00:00.000Z"
 *       400:
 *         description: Deletion already requested
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Account deletion already requested"
 *               error: "Account deletion already requested"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Account pending deletion (only if deletion status check fails)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/delete/cancel:
 *   post:
 *     summary: Cancel account deletion (User)
 *     description: |
 *       Cancels a pending account deletion request.
 *       
 *       **Requirements:**
 *       - Must have a pending deletion request
 *       - Must be within the 24-hour cancellation window
 *       
 *       **Effects:**
 *       - Account is unsuspended
 *       - User can login again
 *       - All features are restored
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Deletion cancelled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Account deletion cancelled successfully. Your account is now active.
 *                 data:
 *                   type: object
 *                   properties:
 *                     message:
 *                       type: string
 *                       example: Account deletion cancelled successfully. Your account is now active.
 *             example:
 *               success: true
 *               message: "Account deletion cancelled successfully. Your account is now active."
 *               data:
 *                 message: "Account deletion cancelled successfully. Your account is now active."
 *       400:
 *         description: No pending deletion request found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "No pending deletion request found"
 *               error: "No pending deletion request found"
 *       403:
 *         description: Cancellation window has passed
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "The 24-hour cancellation window has passed. Your account will be deleted on the scheduled date."
 *               error: "The 24-hour cancellation window has passed. Your account will be deleted on the scheduled date."
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/user/v1/me/delete/status:
 *   get:
 *     summary: Get account deletion status (User)
 *     description: |
 *       Returns the current status of the account deletion process.
 *       
 *       **Possible statuses:**
 *       - `active` - Account is active, no deletion request
 *       - `pending` - Deletion requested, waiting for 30-day period
 *       - `deleted` - Account has been permanently deleted
 *       - `none` - No deletion request (same as active)
 *     tags: [Users]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Deletion status retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Deletion status retrieved
 *                 data:
 *                   $ref: '#/components/schemas/AccountDeletionStatusResponse'
 *             examples:
 *               active:
 *                 summary: Account is active
 *                 value:
 *                   success: true
 *                   message: "Deletion status retrieved"
 *                   data:
 *                     status: "active"
 *               pending:
 *                 summary: Deletion pending
 *                 value:
 *                   success: true
 *                   message: "Deletion status retrieved"
 *                   data:
 *                     status: "pending"
 *                     scheduledDate: "2026-09-22T00:00:00.000Z"
 *                     reversibleUntil: "2026-08-24T00:00:00.000Z"
 *                     daysRemaining: 28
 *               deleted:
 *                 summary: Account deleted
 *                 value:
 *                   success: true
 *                   message: "Deletion status retrieved"
 *                   data:
 *                     status: "deleted"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */