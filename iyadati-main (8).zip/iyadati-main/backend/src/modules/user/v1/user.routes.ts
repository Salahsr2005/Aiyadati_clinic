import { Router } from 'express';
import { UserController } from './user.controller';
import { 
  validateSuspendUser, 
  validateUserFilters,
  validateCreateContactUser, 
  validateUpdateContactUser,
  validateCreateUserDocument, 
  validateUpdateUserDocument,
  validateRequestDeletion,
} from './user.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import { uploadUserDocument } from '../../../core/middleware/upload.middleware';
import { checkDeletionStatus } from '../../../core/middleware/deletionCheck.middleware';

const router = Router();
const userController = new UserController();

// ============================================================
// ⚠️ DELETION MANAGEMENT ROUTES - MUST COME FIRST
// ============================================================
// These routes allow users to manage their account deletion
// They are NOT blocked by the deletion check middleware

router.post(
  '/me/delete/request',
  authenticate,
  // authorize('USER'),
  validateRequestDeletion,
  userController.requestDeletion
);

router.post(
  '/me/delete/cancel',
  authenticate,
  // authorize('USER'),
  userController.cancelDeletion
);

router.get(
  '/me/delete/status',
  authenticate,
  // authorize('USER'),
  userController.getDeletionStatus
);

// ============================================================
// 🔒 USER SELF-SERVICE ROUTES - BLOCKED FOR PENDING DELETION
// ============================================================
// These are isolated in their own sub-router so that the
// `authorize('USER')` + `checkDeletionStatus` gate below does
// NOT leak onto the staff routes registered further down.
// (Previously this was done with router.use(...) directly on
// the main router, which applies to every route registered
// afterwards regardless of section headers/comments — that was
// silently blocking SUPER_ADMIN/ADMIN/DOCTOR/CLINIC from the
// staff routes below.)

const selfServiceRouter = Router();

// selfServiceRouter.use(authenticate);
// selfServiceRouter.use(authorize('USER'));
// selfServiceRouter.use(checkDeletionStatus); // ⬅️ Blocks pending deletion users from everything in this sub-router only

// Contacts (blocked for pending deletion)
selfServiceRouter.get('/me/contacts', userController.getMyContacts);
selfServiceRouter.post('/me/contacts', validateCreateContactUser, userController.createContact);
selfServiceRouter.patch('/me/contacts/:id', validateUpdateContactUser, userController.updateContact);
selfServiceRouter.delete('/me/contacts/:id', userController.deleteContact);

// Medical Documents (blocked for pending deletion)
selfServiceRouter.get('/me/documents', userController.getMyDocuments);
selfServiceRouter.post('/me/documents', uploadUserDocument, validateCreateUserDocument, userController.uploadDocument);
selfServiceRouter.patch('/me/documents/:id', validateUpdateUserDocument, userController.updateDocument);
selfServiceRouter.delete('/me/documents/:id', userController.deleteDocument);

router.use(selfServiceRouter);

// ============================================================
// Staff Routes (no deletion check needed - they're admins)
// ============================================================
// These are fully independent of the USER-only gate above —
// each route declares its own authenticate/authorize chain.

router.get(
  '/',
    // authenticate,
    // authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'), 
  validateUserFilters,
  userController.getUsers
);

router.get('/id/:id', // authenticate, // authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  userController.getUserById);
router.get('/email/:email', // authenticate, // authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
  userController.getUserByEmail);
router.get('/phone/:phone', // authenticate, // authorize('SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'CLINIC'),
 userController.getUserByPhone);

router.post(
  '/:id/suspend',
  // authenticate,
  // authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({ windowMinutes: 15, maxRequests: 20, message: 'Too many suspension requests' }),
  validateSuspendUser,
  userController.suspendUser
);

router.post(
  '/:id/unsuspend',
  // authenticate,
  // authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({ windowMinutes: 15, maxRequests: 20, message: 'Too many unsuspension requests' }),
  userController.unsuspendUser
);

export default router;

