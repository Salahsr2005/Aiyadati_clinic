import fs from 'fs/promises';
import path from 'path';
import { prisma } from '../../../core/utils/prisma';
import { 
  generateSignedUrl, 
  generatePublicUrl,
  verifySignedUrl,
  isValidFileId,
  isUrlExpired,
  getFilePath 
} from '../../../core/utils/signed-url';
import { NotFoundError, ForbiddenError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import  { env } from "../../../config/env"

// Storage abstraction imports
import { StorageFactory } from '../../../core/storage/storage.factory';
import { StorageProvider } from '../../../core/interfaces/storage.interface';

// Repository imports
import {
  userDocumentRepository,
} from '../../../repositories/user-document.repository';
import {
  doctorDocumentRepository,
} from '../../../repositories/doctor-document.repository';
import {
  clinicDocumentRepository,
} from '../../../repositories/clinic-document.repository';
import {
  clinicGalleryRepository,
} from '../../../repositories/clinic-gallery.repository';
import {
  clinicServiceImageRepository,
} from '../../../repositories/clinic-service-image.repository';
import { specialtyRepository } from '../../../repositories/specialty.repository';
import { productImageRepository } from '../../../repositories/product-image.repository';
import { sellerDocumentRepository } from '../../../repositories/seller-document.repository';
import { doctorLogoRepository } from '../../../repositories/doctor-logo.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { consentRepository } from '../../../repositories/consent.repository';

import { fileRegistryRepository } from '../../../repositories/file-registry.repository';

import { advertisementRepository } from '../../../repositories/advertisement.repository';

// ✅ NEW IMPORTS FOR OWNERSHIP RESOLUTION
import { productRepository } from '../../../repositories/product.repository';
import { clinicServiceRepository } from '../../../repositories/clinic-service.repository';


type PrivateRepository = typeof userDocumentRepository | typeof doctorDocumentRepository | typeof clinicDocumentRepository | typeof sellerDocumentRepository | typeof fileRegistryRepository;
type PublicRepository = typeof clinicGalleryRepository | typeof clinicServiceImageRepository | typeof productImageRepository | typeof doctorLogoRepository;


const REPOSITORY_MAP: Record<string, PrivateRepository> = {
  user: userDocumentRepository,
  doctor: doctorDocumentRepository,
  clinic: clinicDocumentRepository,
  seller: sellerDocumentRepository,
};

const PUBLIC_REPOSITORY_MAP: Record<string, PublicRepository> = {
  gallery: clinicGalleryRepository,
  serviceImage: clinicServiceImageRepository,
  productImage: productImageRepository,
  doctorLogo: doctorLogoRepository,
};

interface FileRecord {
  _table: string;
  id: string;
  fileId: string;
  filePath: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  doctorId?: string;
  userId?: string;
  clinicId?: string;
  storageType?: string;
  imagePath?: string;
  logoPath?: string;
  storageKey?: string;
  [key: string]: any;
}

export class FileService {
  private storage: StorageProvider;

  constructor() {
    this.storage = StorageFactory.getInstance();
  }

  /**
   * Get the actual storage identifier based on STORAGE_TYPE
   * - When using S3/SeaweedFS: prefers storageKey, falls back to filePath
   * - When using local storage: prefers filePath, falls back to storageKey
   */
  private getStorageIdentifier(file: FileRecord): string {
    const isS3 = env.isS3Compatible;
    const isLocal = env.isLocalStorage;

    // Guard: if no storage type is set, default to local behavior
    const usingS3 = isS3 === true;
    const usingLocal = isLocal === true || (!isS3 && !isLocal);

    if (usingS3) {
      // S3/SeaweedFS mode: use storageKey as primary
      if (file.storageKey && file.storageKey.trim() !== '') {
        return file.storageKey;
      }
      // Fallback to filePath if storageKey doesn't exist (legacy files)
      if (file.filePath && file.filePath.trim() !== '') {
        logger.warn(`File ${file.fileId} has no storageKey, falling back to filePath`);
        return file.filePath;
      }
    }

    if (usingLocal) {
      // Local storage mode: use filePath as primary
      if (file.filePath && file.filePath.trim() !== '') {
        return file.filePath;
      }
      // Fallback to storageKey if filePath doesn't exist (files uploaded via S3)
      if (file.storageKey && file.storageKey.trim() !== '') {
        logger.warn(`File ${file.fileId} has no filePath, falling back to storageKey`);
        return file.storageKey;
      }
    }

    // If we get here, neither exists
    throw new Error(`File ${file.fileId} has no valid storage identifier for STORAGE_TYPE: ${env.STORAGE_TYPE}`);
  }

  /**
   * Get file by ID with access control
   * Uses the appropriate identifier based on STORAGE_TYPE
   */
  async getFile(
    fileId: string,
    userId: string,
    userRole: string,
    isPublic: boolean = false
  ): Promise<{ buffer: Buffer; metadata: any; contentType: string }> {
    if (!isValidFileId(fileId)) {
      throw new BadRequestError('Invalid file ID format');
    }

    const file = await this.findFileById(fileId, isPublic);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    if (!isPublic) {
      await this.checkAccess(file, userId, userRole);
    }

    // Get the storage identifier based on STORAGE_TYPE
    const identifier = this.getStorageIdentifier(file);

    // Check if file exists in storage
    const fileExists = await this.storage.exists(identifier);
    if (!fileExists) {
      logger.warn(`File not found in storage: ${fileId}, clearing database record`);
      await this.deleteFromDatabase(file, fileId, isPublic);
      throw new NotFoundError('File not found');
    }

    // Download the file
    const result = await this.storage.download(identifier);

    if (!isPublic) {
      await this.incrementAccessCount(file, fileId);
      logger.info(`File accessed: ${fileId} by user ${userId}`);
    }

    return {
      buffer: result.buffer,
      metadata: file,
      contentType: file.fileType || 'image/png',
    };
  }

  /**
   * Generate signed URL for private file
   */
  async getSignedUrl(fileId: string, userId: string, userRole: string): Promise<string> {
    const file = await this.findFileById(fileId, false);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    await this.checkAccess(file, userId, userRole);

    return generateSignedUrl(fileId);
  }

  /**
   * Get public URL for public file
   */
  async getPublicUrl(fileId: string): Promise<string> {
    const file = await this.findFileById(fileId, true);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    return generatePublicUrl(fileId);
  }

  /**
   * Delete file by ID
   * Uses the appropriate identifier based on STORAGE_TYPE
   */
  async deleteFile(
    fileId: string,
    userId: string,
    userRole: string,
    isPublic: boolean = false
  ): Promise<void> {
    const file = await this.findFileById(fileId, isPublic);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    await this.checkDeleteAccess(file, userId, userRole);

    // Delete from database first
    await this.deleteFromDatabase(file, fileId, isPublic);

    // Then delete from storage
    try {
      const identifier = this.getStorageIdentifier(file);
      const fileExists = await this.storage.exists(identifier);
      if (!fileExists) {
        logger.warn(`File not found in storage, DB already cleared: ${fileId}`);
        return;
      }
      
      const result = await this.storage.delete(identifier);
      if (!result.success) {
        logger.warn(`Failed to delete file from storage: ${fileId} - ${result.message}`);
      }
    } catch (error) {
      logger.error(`Error deleting file from storage: ${fileId}`, error);
    }

    logger.info(`File deleted: ${fileId} by user ${userId}`);
  }

  /**
   * Get file metadata by ID
   */
  async getFileMetadata(fileId: string, userId: string, userRole: string): Promise<any> {
    const file = await this.findFileById(fileId, false);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    await this.checkAccess(file, userId, userRole);

    const { filePath, _table, ...metadata } = file;
    return metadata;
  }

  /**
   * Find file in all document tables
   * Handles both public and private files with storageKey/fallback
   */
  public async findFileById(fileId: string, isPublic: boolean): Promise<FileRecord | null> {
    if (isPublic) {
      // Check public file tables first
      for (const [key, repo] of Object.entries(PUBLIC_REPOSITORY_MAP)) {
        const file = await repo.findByFileId(fileId);
        if (file) {
          const record = file as any;
          record._table = key;
          // Ensure storageKey is set, fallback to filePath
          if (!record.storageKey && record.filePath) {
            record.storageKey = record.filePath;
          }

          // ✅ FIX: Attach the real owner for tables that only reference it indirectly
          // This allows checkDeleteAccess() to correctly determine ownership
          if (key === 'productImage' && record.productId) {
            const product = await productRepository.findById(record.productId);
            record.userId = product?.sellerId;
          }
          if (key === 'serviceImage' && record.serviceId) {
            const service = await clinicServiceRepository.findById(record.serviceId);
            record.clinicId = service?.clinicId;
          }

          return record as FileRecord;
        }
      }
      
      // Handle specialty separately (reading only, NOT deleting)
      const specialty = await specialtyRepository.findByFileId(fileId);
      if (specialty) {
        const record = specialty as any;
        record._table = 'specialty';
        // ✅ FIXED: imagePath already contains the full path (e.g., "public/logos/uuid.png")
        // No need to add "public/logos/" prefix again
        record.filePath = specialty.imagePath;
        record.fileName = specialty.imagePath;
        // Set storageKey as fallback for specialty
        record.storageKey = specialty.imagePath || `${specialty.id}.jpg`;
        if (specialty.imagePath?.endsWith('.png')) record.fileType = 'image/png';
        else if (specialty.imagePath?.endsWith('.jpg') || specialty.imagePath?.endsWith('.jpeg')) record.fileType = 'image/jpeg';
        else if (specialty.imagePath?.endsWith('.webp')) record.fileType = 'image/webp';
        else if (specialty.imagePath?.endsWith('.svg')) record.fileType = 'image/svg+xml';
        else record.fileType = 'image/jpeg';
        return record as FileRecord;
      }
      
      // Handle clinic separately (reading only, NOT deleting)
      const clinic = await clinicRepository.findByFileId(fileId);
      if (clinic) {
        const record = clinic as any;
        record._table = 'clinic';
        // ✅ FIXED: logoPath already contains the full path (e.g., "public/logos/uuid.png")
        // No need to add "public/logos/" prefix again
        record.filePath = clinic.logoPath;
        record.fileName = clinic.logoPath;
        // Set storageKey as fallback for clinic
        record.storageKey = clinic.logoPath || `${clinic.id}.jpg`;
        if (clinic.logoPath?.endsWith('.png')) record.fileType = 'image/png';
        else if (clinic.logoPath?.endsWith('.jpg') || clinic.logoPath?.endsWith('.jpeg')) record.fileType = 'image/jpeg';
        else if (clinic.logoPath?.endsWith('.webp')) record.fileType = 'image/webp';
        else if (clinic.logoPath?.endsWith('.svg')) record.fileType = 'image/svg+xml';
        else record.fileType = 'image/jpeg';
        return record as FileRecord;
      }
      
      // Handle advertisement separately (reading only, NOT deleting)
      const advertisement = await advertisementRepository.findByFileId(fileId);
      if (advertisement) {
        const record = advertisement as any;
        record._table = 'advertisement';
        record.filePath = advertisement.filePath;
        record.fileName = advertisement.fileName;
        record.fileType = advertisement.fileType;
        record.fileSize = advertisement.fileSize;
        // Set storageKey as fallback for advertisement
        if (!record.storageKey && record.filePath) {
          record.storageKey = record.filePath;
        }
        return record as FileRecord;
      }
      
      return null;
    }

    // Private files
    for (const [key, repo] of Object.entries(REPOSITORY_MAP)) {
      const file = await repo.findByFileId(fileId);
      if (file) {
        const record = file as any;
        record._table = key;
        // Ensure storageKey is set, fallback to filePath
        if (!record.storageKey && record.filePath) {
          record.storageKey = record.filePath;
        }
        return record as FileRecord;
      }
    }
    return null;
  }

  /**
   * Check access permissions for private files
   */
  public async checkAccess(
    file: FileRecord,
    userId: string,
    userRole: string
  ): Promise<void> {
    // Admins can access everything
    if (['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      return;
    }

    // Check if user owns the file
    const ownerId = file.doctorId || file.userId || file.clinicId;
    if (ownerId === userId) {
      return;
    }

    // Check clinic access (doctor in the clinic)
    if (file.clinicId) {
      const hasAccess = await this.checkClinicAccess(file.clinicId, userId);
      if (hasAccess) return;
    }

    // Check consent access (patient allowed doctor to view)
    // Only applies to user documents (patient files)
    if (file.userId) {
      const hasConsent = await this.checkConsentAccess(file, userId);
      if (hasConsent) return;
    }

    throw new ForbiddenError('You do not have access to this file');
  }

  /**
   * Check if user has access to clinic files
   */
  private async checkClinicAccess(clinicId: string, userId: string): Promise<boolean> {
    const clinicDoctor = await prisma.clinicDoctor.findFirst({
      where: {
        clinicId,
        doctorId: userId,
        status: 'ACCEPTED',
        isActive: true,
      },
    });

    return !!clinicDoctor;
  }

  /**
   * Check delete permissions
   */
  private async checkDeleteAccess(
    file: FileRecord,
    userId: string,
    userRole: string
  ): Promise<void> {
    if (['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      return;
    }

    const ownerId = file.doctorId || file.userId || file.clinicId;
    if (ownerId !== userId) {
      throw new ForbiddenError('You can only delete your own files');
    }
  }

  /**
   * Increment access count for a file
   */
  private async incrementAccessCount(
    file: FileRecord,
    fileId: string
  ): Promise<void> {
    const table = file._table;
    
    // advertisement tracking
    if (table === 'advertisement') {
      await advertisementRepository.incrementViewCount(fileId);
      return;
    }
    
    if (REPOSITORY_MAP[table]) {
      const repo = REPOSITORY_MAP[table];
      if (repo && typeof repo.incrementAccessCount === 'function') {
        await repo.incrementAccessCount(fileId);
      }
      return;
    }
    
    if (PUBLIC_REPOSITORY_MAP[table]) {
      const repo = PUBLIC_REPOSITORY_MAP[table];
      if (repo && typeof repo.incrementAccessCount === 'function') {
        await repo.incrementAccessCount(fileId);
      }
    }
  }

  /**
   * Delete from database - Safety check for entity tables
   */
  private async deleteFromDatabase(
    file: FileRecord,
    fileId: string,
    isPublic: boolean
  ): Promise<void> {
    const table = file._table;
    
    // SAFETY: Never delete entity tables or advertisement (handled by service)
    if (table === 'specialty' || table === 'clinic' || table === 'advertisement') {
      logger.warn(`Attempted to delete entity table ${table} via file service - SKIPPED`);
      return;
    }
    
    if (isPublic) {
      if (PUBLIC_REPOSITORY_MAP[table]) {
        const repo = PUBLIC_REPOSITORY_MAP[table];
        if (repo && typeof repo.deleteByFileId === 'function') {
          await repo.deleteByFileId(fileId);
        }
      }
    } else {
      if (REPOSITORY_MAP[table]) {
        const repo = REPOSITORY_MAP[table];
        if (repo && typeof repo.deleteByFileId === 'function') {
          await repo.deleteByFileId(fileId);
        }
      }
    }
  }

  /**
   * Check if a doctor has consent from a patient to access their document
   * Uses consentRepository for clean separation of concerns
   */
  private async checkConsentAccess(
    file: FileRecord,
    userId: string
  ): Promise<boolean> {
    // Only check if the file belongs to a user (patient)
    if (!file.userId) {
      return false;
    }

    const patientId = file.userId;
    const doctorId = userId;

    // Use consent repository instead of direct prisma
    const result = await consentRepository.checkDocumentAccess(
      patientId,
      doctorId,
      file.id
    );

    return result.hasAccess;
  }
}

export const fileService = new FileService();

