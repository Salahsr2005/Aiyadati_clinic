// src/core/controllers/file.controller.ts
import { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import { fileService } from './file.service';
import { 
  isValidFileId, 
  verifySignedUrl, 
  getFilePath,
  fileExists,
  generateSignedUrl 
} from '../../../core/utils/signed-url';
import { NotFoundError, ForbiddenError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { ResponseUtil } from '../../../core/utils/response';
import { StorageFactory } from '../../../core/storage/storage.factory';
import { env } from '../../../config/env';

export class FileController {
  /**
   * Get a fresh signed URL for private file access
   * POST /api/v1/files/private/:fileId/access
   */
  getSignedUrl = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const url = await fileService.getSignedUrl(fileId, userId, role);
      ResponseUtil.success(res, { url, expiresIn: 1800 }, 'Signed URL generated successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get public file URL
   * POST /api/v1/files/public/:fileId/url
   */
  getPublicUrl = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const url = await fileService.getPublicUrl(fileId);
      ResponseUtil.success(res, { url }, 'Public URL generated successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Serve private file with signed URL verification
   * GET /api/v1/files/private/:fileId
   * 
   * IMPROVED: For S3 storage, redirects to SeaweedFS presigned URL
   *    For local storage, proxies the file (fallback for backward compatibility)
   * This removes Express from the file download hot path for S3
   */
  getPrivateFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const { expires, signature } = req.query;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      // Validate required params
      if (!expires || !signature || typeof expires !== 'string' || typeof signature !== 'string') {
        ResponseUtil.badRequest(res, 'Missing expires or signature parameters');
        return;
      }

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      // Validate fileId format
      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      // Verify signed URL (legacy app signature)
      if (!verifySignedUrl(fileId, expires, signature)) {
        ResponseUtil.forbidden(res, 'Invalid or expired link');
        return;
      }

      // Check storage type for fallback
      if (env.isLocalStorage) {
        // Fallback: Proxy the file for local storage (old behavior)
        const { buffer, metadata, contentType } = await fileService.getFile(
          fileId,
          userId,
          role,
          false
        );
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(metadata.fileName)}"`);
        res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');
        res.setHeader('Content-Length', buffer.length);
        res.send(buffer);
        return;
      }

      // S3: Get file metadata only (NOT the file itself)
      const file = await fileService.findFileById(fileId, false);
      if (!file) {
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      // Check access permissions
      await fileService.checkAccess(file, userId, role);

      // Generate real presigned URL from SeaweedFS
      const storage = StorageFactory.getInstance();
      
      // Get the storage identifier (storageKey for S3, filePath for local fallback)
      const identifier = file.storageKey || file.filePath;
      if (!identifier) {
        logger.error(`File ${fileId} has no storageKey or filePath`);
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      const signedUrl = await storage.getSignedUrl(identifier, 1800);

      // Redirect to SeaweedFS instead of proxying through Express
      res.redirect(302, signedUrl);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Serve public file (no authentication required)
   * GET /api/v1/files/public/:fileId
   * 
   * IMPROVED: For S3 storage, redirects to public URL
   *    For local storage, proxies the file (fallback for backward compatibility)
   */
  getPublicFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;

      // Validate fileId format
      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      // Check storage type for fallback
      if (env.isLocalStorage) {
        // Fallback: Proxy the file for local storage (old behavior)
        const { buffer, metadata, contentType } = await fileService.getFile(
          fileId,
          '', // No userId needed for public
          '', // No userRole needed for public
          true
        );
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(metadata.fileName)}"`);
        res.setHeader('Cache-Control', 'public, max-age=86400'); // Cache for 1 day
        res.setHeader('Content-Length', buffer.length);
        res.send(buffer);
        return;
      }

      // S3: Get file metadata only
      const file = await fileService.findFileById(fileId, true);
      if (!file) {
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      // Get public URL from storage provider
      const storage = StorageFactory.getInstance();
      
      // Get the storage identifier (storageKey for S3, filePath for local fallback)
      const identifier = file.storageKey || file.filePath;
      if (!identifier) {
        logger.error(`File ${fileId} has no storageKey or filePath`);
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      const publicUrl = storage.getPublicUrl(identifier);

      // Redirect to public URL
      res.redirect(302, publicUrl);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get file metadata by ID
   * GET /api/v1/files/private/:fileId/metadata
   */
  getFileMetadata = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const metadata = await fileService.getFileMetadata(fileId, userId, role);
      ResponseUtil.success(res, metadata, 'File metadata retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Delete file by ID
   * DELETE /api/v1/files/private/:fileId
   */
  deleteFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      await fileService.deleteFile(fileId, userId, role, false);
      ResponseUtil.success(res, null, 'File deleted successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Legacy support - for backward compatibility during migration
   * GET /api/v1/files/legacy/:fileName
   */
  getLegacyFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileName } = req.params;
      const { expires, signature } = req.query;

      // Only allow if legacy mode is enabled
      if (process.env.ENABLE_LEGACY_FILES !== 'true') {
        ResponseUtil.notFound(res, 'Legacy file access is disabled');
        return;
      }

      if (!expires || !signature || typeof expires !== 'string' || typeof signature !== 'string') {
        ResponseUtil.badRequest(res, 'Missing or invalid parameters');
        return;
      }

      // Verify using legacy verification
      const { verifySignedUrlLegacy } = await import('../../../core/utils/signed-url');
      if (!verifySignedUrlLegacy(fileName, expires, signature)) {
        ResponseUtil.forbidden(res, 'Invalid or expired link');
        return;
      }

      if (!fileExists(fileName)) {
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      const filePath = getFilePath(fileName);
      res.sendFile(filePath);
    } catch (error) {
      next(error);
    }
  };
}

export const fileController = new FileController();

