// src/modules/auth/v1/auth.service.ts

import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';

import { superAdminRepository } from '../../../repositories/super-admin.repository';
import { adminRepository } from '../../../repositories/admin.repository';
import { userRepository } from '../../../repositories/user.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { sellerRepository } from '../../../repositories/seller.repository';
import { walletRepository } from '../../../repositories/wallet.repository';
import { passwordSetupTokenRepository } from '../../../repositories/password-setup-token.repository';

import {
  UnauthorizedError,
  ConflictError,
  BadRequestError,
  NotFoundError,
} from '../../../core/utils/error';

import { eventEmitter } from '../../../core/events/event-emitter';
import { logger } from '../../../core/utils/logger';

import {
  LoginDTO,
  RegisterUserDTO,
  VerifyOtpDTO,
  AuthUser,
  AuthResponse,
  ResendOtpDTO,
  RegisterClinicDTO,
  RegisterDoctorDTO,
  RegisterSellerDTO,
  RequestPasswordResetDTO,
  ResetPasswordDTO,
} from './auth.types';

import { env } from '../../../config/env';

const JWT_SECRET = env.JWT_SECRET || 'iyadati-secret-key-change-in-production';
const JWT_EXPIRES_IN = '7d';

export class AuthService {
  // ============================================================
  // SUPER ADMIN / ADMIN LOGIN
  // ============================================================

  async login(data: LoginDTO): Promise<AuthResponse> {
    const { email, password } = data;

    let user = await superAdminRepository.findByEmail(email);
    let role: 'SUPER_ADMIN' | 'ADMIN' = 'SUPER_ADMIN';

    if (!user) {
      user = await adminRepository.findByEmail(email);
      role = 'ADMIN';
    }

    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role, name: user.name },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role,
      },
    };
  }

  // ============================================================
  // USER LOGIN
  // ============================================================

  async loginUser(data: LoginDTO): Promise<AuthResponse> {
    const { email, password } = data;

    const user = await userRepository.findByEmail(email);
    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    if (!user.isVerified) {
      throw new UnauthorizedError('Please verify your email first');
    }

    if (user.isSuspended) {
      throw new UnauthorizedError('Your account has been suspended');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: 'USER' as const,
        name: `${user.firstName} ${user.lastName}`,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: `${user.firstName} ${user.lastName}`,
        role: 'USER',
      },
    };
  }

  // ============================================================
  // TOKEN VERIFICATION
  // ============================================================

  async verifyToken(token: string): Promise<AuthUser> {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
      return decoded;
    } catch (error) {
      throw new UnauthorizedError('Invalid or expired token');
    }
  }

  // ============================================================
  // USER REGISTRATION
  // ============================================================

  async registerUser(data: RegisterUserDTO): Promise<{ message: string }> {
    const [existingEmail, existingPhone] = await Promise.all([
      userRepository.findByEmail(data.email),
      userRepository.findByPhone(data.phone),
    ]);

    if (existingEmail) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'This email is already in use' },
      ]);
    }

    if (existingPhone) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'This phone number is already in use' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);
    const otp = crypto.randomInt(100000, 999999).toString();
    const hashedOtp = await bcrypt.hash(otp, 10);
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    const user = await userRepository.create({
      email: data.email,
      password: hashedPassword,
      firstName: data.firstName,
      lastName: data.lastName,
      phone: data.phone,
      dateOfBirth: new Date(data.dateOfBirth),
      wilaya: { connect: { id: data.wilayaId } },
      verificationCode: hashedOtp,
      otpExpiresAt,
    });

    await walletRepository.create(user.id);

    eventEmitter.emit('notification', {
      userId: user.id,
      title: '🎉 Welcome to Iyadati!',
      body: 'Your account has been created. Please check your email for the verification code.',
      type: 'system',
      data: { type: 'welcome' },
    });

    eventEmitter.emit('send-otp-email', {
      email: user.email,
      name: user.firstName,
      otp,
    });

    logger.info(`User registered: ${user.email}`);

    return { message: 'Registration successful. Please check your email for the verification code.' };
  }

  async verifyUserOtp(data: VerifyOtpDTO): Promise<{ message: string }> {
    const user = await userRepository.findByEmail(data.email);
    if (!user) {
      throw new BadRequestError('Invalid email or verification code');
    }

    if (user.isVerified) {
      return { message: 'Email already verified' };
    }

    if (!user.verificationCode || !user.otpExpiresAt) {
      throw new BadRequestError('No verification code found. Please register again.');
    }

    if (new Date() > user.otpExpiresAt) {
      throw new BadRequestError('Verification code has expired. Please request a new one.');
    }

    const isValidOtp = await bcrypt.compare(data.otp, user.verificationCode);
    if (!isValidOtp) {
      throw new BadRequestError('Invalid verification code');
    }

    await userRepository.verifyUser(user.id);

    eventEmitter.emit('notification', {
      userId: user.id,
      title: '✅ Email Verified!',
      body: 'Your email has been verified. You can now login and start booking appointments.',
      type: 'system',
      data: { type: 'email_verified' },
    });

    return { message: 'Email verified successfully. You can now login.' };
  }

  async resendOtp(data: ResendOtpDTO): Promise<{ message: string }> {
    const user = await userRepository.findByEmail(data.email);

    if (!user) {
      return { message: 'If your email is registered, a new verification code has been sent.' };
    }

    if (user.isVerified) {
      return { message: 'Email already verified. You can login now.' };
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const hashedOtp = await bcrypt.hash(otp, 10);
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await userRepository.setVerificationCode(user.id, hashedOtp, otpExpiresAt);

    eventEmitter.emit('send-otp-email', {
      email: user.email,
      name: user.firstName,
      otp,
    });

    logger.info(`New OTP sent to ${user.email}`);

    return { message: 'If your email is registered, a new verification code has been sent.' };
  }

  // ============================================================
  // CLINIC REGISTRATION / LOGIN
  // ============================================================

  async registerClinic(data: RegisterClinicDTO, ip?: string): Promise<AuthResponse> {
    const [emailExists, phoneExists] = await Promise.all([
      clinicRepository.emailExists(data.email),
      clinicRepository.phoneExists(data.phone),
    ]);

    if (emailExists) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'A clinic with this email already exists' },
      ]);
    }

    if (phoneExists) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'A clinic with this phone already exists' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const clinic = await clinicRepository.create({
      nameFr: data.nameFr,
      nameAr: data.nameAr,
      password: hashedPassword,
      phone: data.phone,
      email: data.email,
      wilaya: { connect: { id: data.wilayaId } },
    });

    eventEmitter.emit('notification', {
      userId: clinic.id,
      title: '🏥 Welcome to Iyadati!',
      body: 'Your clinic has been registered. Please upload your documents to get verified.',
      type: 'system',
      data: { type: 'welcome' },
    });

    const token = jwt.sign(
      { id: clinic.id, email: clinic.email, role: 'CLINIC' as const, name: clinic.nameFr },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    logger.info(`Clinic registered: ${clinic.nameFr} (${clinic.email})`);

    return {
      token,
      user: {
        id: clinic.id,
        email: clinic.email,
        name: clinic.nameFr,
        role: 'CLINIC',
      },
    };
  }

  async loginClinic(data: LoginDTO): Promise<AuthResponse> {
    const clinic = await clinicRepository.findByEmail(data.email);
    if (!clinic) throw new UnauthorizedError('Clinic not found');

    if (!clinic.isVerified) throw new UnauthorizedError('Clinic is pending verification');
    if (clinic.isSuspended) throw new UnauthorizedError('Clinic has been suspended');

    const isPasswordValid = await bcrypt.compare(data.password, clinic.password);
    if (!isPasswordValid) throw new UnauthorizedError('Invalid email or password');

    const token = jwt.sign(
      { id: clinic.id, email: clinic.email, role: 'CLINIC' as const, name: clinic.nameFr },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: { id: clinic.id, email: clinic.email, name: clinic.nameFr, role: 'CLINIC' },
    };
  }

  // ============================================================
  // DOCTOR REGISTRATION / LOGIN
  // ============================================================

  async registerDoctor(data: RegisterDoctorDTO, ip?: string): Promise<AuthResponse> {
    const [emailExists, phoneExists] = await Promise.all([
      doctorRepository.emailExists(data.email),
      doctorRepository.phoneExists(data.phone),
    ]);

    if (emailExists) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'A doctor with this email already exists' },
      ]);
    }

    if (phoneExists) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'A doctor with this phone already exists' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const doctor = await doctorRepository.create({
      email: data.email,
      password: hashedPassword,
      firstNameFr: data.firstNameFr,
      firstNameAr: data.firstNameAr,
      lastNameFr: data.lastNameFr,
      lastNameAr: data.lastNameAr,
      phone: data.phone,
      wilayaId: data.wilayaId,
    });

    eventEmitter.emit('notification', {
      userId: doctor.id,
      title: '👨‍⚕️ Welcome to Iyadati!',
      body: 'Your doctor account has been created. Please upload your documents to get verified.',
      type: 'system',
      data: { type: 'welcome' },
    });

    const token = jwt.sign(
      {
        id: doctor.id,
        email: doctor.email,
        role: 'DOCTOR' as const,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    eventEmitter.emit('audit', {
      action: 'doctor.registered',
      entity: 'Doctor',
      entityId: doctor.id,
      performedBy: doctor.id,
      details: { email: doctor.email, name: `${doctor.firstNameFr} ${doctor.lastNameFr}` },
      ip,
    });

    logger.info(`Doctor registered: ${doctor.email}`);

    return {
      token,
      user: {
        id: doctor.id,
        email: doctor.email,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
        role: 'DOCTOR',
      },
    };
  }

  async loginDoctor(data: LoginDTO): Promise<AuthResponse> {
    const doctor = await doctorRepository.findByEmail(data.email);
    if (!doctor) throw new UnauthorizedError('Invalid email or password');

    if (!doctor.isVerified) throw new UnauthorizedError('Your account is pending verification');
    if (doctor.isSuspended) throw new UnauthorizedError('Your account has been suspended');

    const isPasswordValid = await bcrypt.compare(data.password, doctor.password);
    if (!isPasswordValid) throw new UnauthorizedError('Invalid email or password');

    const token = jwt.sign(
      {
        id: doctor.id,
        email: doctor.email,
        role: 'DOCTOR' as const,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: doctor.id,
        email: doctor.email,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
        role: 'DOCTOR',
      },
    };
  }

  // ============================================================
  // SELLER REGISTRATION / LOGIN
  // ============================================================

  async registerSeller(data: RegisterSellerDTO, ip?: string): Promise<AuthResponse> {
    const [existingEmail, existingPhone] = await Promise.all([
      sellerRepository.findByEmail(data.email),
      sellerRepository.findByPhone(data.phone),
    ]);

    if (existingEmail) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'This email is already in use' },
      ]);
    }

    if (existingPhone) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'This phone number is already in use' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const seller = await sellerRepository.create({
      email: data.email,
      password: hashedPassword,
      firstName: data.firstName,
      lastName: data.lastName,
      phone: data.phone,
      wilayaId: data.wilayaId,
      businessName: data.businessName,
      businessType: data.businessType as any || 'INDIVIDUAL',
      taxNumber: data.taxNumber,
      registrationNumber: data.registrationNumber,
      address: data.address,
    });

    await sellerRepository.update(seller.id, {
      status: 'PENDING',
      isVerified: false,
    });

    eventEmitter.emit('admin-notification', {
      type: 'new_seller_registration',
      sellerId: seller.id,
      message: `New seller registration: ${data.firstName} ${data.lastName}`,
    });

    eventEmitter.emit('notification', {
      userId: seller.id,
      title: '🛒 Welcome to Iyadati Sellers!',
      body: 'Your seller account has been created. Please wait for admin approval.',
      type: 'system',
      data: { type: 'seller_welcome' },
    });

    eventEmitter.emit('audit', {
      action: 'seller.registered',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: seller.id,
      details: { email: seller.email, name: `${seller.firstName} ${seller.lastName}` },
      ip,
    });

    logger.info(`Seller registered: ${seller.email}`);

    const name = seller.businessName || `${seller.firstName} ${seller.lastName}`;

    const token = jwt.sign(
      {
        id: seller.id,
        email: seller.email,
        role: 'SELLER' as const,
        name,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: seller.id,
        email: seller.email,
        name,
        role: 'SELLER',
      },
    };
  }

  async loginSeller(data: LoginDTO): Promise<AuthResponse> {
    const { email, password } = data;

    const seller = await sellerRepository.findByEmail(email);
    if (!seller) {
      throw new UnauthorizedError('Invalid email or password');
    }

    if (seller.status === 'PENDING') {
      throw new UnauthorizedError('Your seller account is pending approval');
    }

    if (seller.status === 'BANNED') {
      throw new UnauthorizedError('Your seller account has been banned');
    }

    if (seller.isSuspended) {
      throw new UnauthorizedError('Your seller account has been suspended');
    }

    const isPasswordValid = await bcrypt.compare(password, seller.password);
    if (!isPasswordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const name = seller.businessName || `${seller.firstName} ${seller.lastName}`;

    const token = jwt.sign(
      {
        id: seller.id,
        email: seller.email,
        role: 'SELLER' as const,
        name,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: seller.id,
        email: seller.email,
        name,
        role: 'SELLER',
      },
    };
  }

  // ============================================================
  // PASSWORD RESET
  // ============================================================

  /**
   * Request password reset - sends email with reset link
   * Works for all roles: USER, DOCTOR, CLINIC, SELLER
   */
  async requestPasswordReset(data: RequestPasswordResetDTO, ip?: string): Promise<{ message: string }> {
    const { email } = data;

    const user = await userRepository.findByEmail(email);
    const doctor = await doctorRepository.findByEmail(email);
    const clinic = await clinicRepository.findByEmail(email);
    const seller = await sellerRepository.findByEmail(email);

    let entity: any = null;
    let entityType: string | null = null;
    let name: string = '';

    if (user) {
      entity = user;
      entityType = 'USER';
      name = `${user.firstName} ${user.lastName}`;
    } else if (doctor) {
      entity = doctor;
      entityType = 'DOCTOR';
      name = `${doctor.firstNameFr} ${doctor.lastNameFr}`;
    } else if (clinic) {
      entity = clinic;
      entityType = 'CLINIC';
      name = clinic.nameFr;
    } else if (seller) {
      entity = seller;
      entityType = 'SELLER';
      name = seller.businessName || `${seller.firstName} ${seller.lastName}`;
    }

    if (!entity || !entityType) {
      logger.info(`Password reset requested for non-existent email: ${email}`);
      return {
        message: 'If an account with this email exists, a password reset link has been sent.',
      };
    }

    const token = await passwordSetupTokenRepository.create(entity.id, entityType, 24);

    const resetUrl = `${env.BASE_URL}/reset-password?token=${token.token}`;

    eventEmitter.emit('send-password-reset-email', {
      email: entity.email,
      name,
      type: entityType,
      resetUrl,
    });

    eventEmitter.emit('audit', {
      action: 'password.reset_requested',
      entity: entityType,
      entityId: entity.id,
      performedBy: entity.id,
      details: { email: entity.email },
      ip,
    });

    logger.info(`Password reset requested for ${entityType}: ${entity.email}`);

    return {
      message: 'If an account with this email exists, a password reset link has been sent.',
    };
  }

  /**
   * Reset password using token
   * Works for all roles: USER, DOCTOR, CLINIC, SELLER
   */
  async resetPassword(data: ResetPasswordDTO, ip?: string): Promise<{ message: string }> {
    const { token, password } = data;

    const tokenRecord = await passwordSetupTokenRepository.findByToken(token);
    if (!tokenRecord) {
      throw new BadRequestError('Invalid or expired reset token');
    }

    if (tokenRecord.usedAt) {
      throw new BadRequestError('This reset link has already been used');
    }

    if (new Date() > tokenRecord.expiresAt) {
      throw new BadRequestError('This reset link has expired. Please request a new one.');
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const ownerType = tokenRecord.ownerType;
    let entity: any = null;

    if (ownerType === 'USER') {
      entity = await userRepository.findById(tokenRecord.ownerId);
      if (!entity) throw new NotFoundError('User not found');
      await userRepository.update(entity.id, { password: hashedPassword });
    } else if (ownerType === 'DOCTOR') {
      entity = await doctorRepository.findById(tokenRecord.ownerId);
      if (!entity) throw new NotFoundError('Doctor not found');
      await doctorRepository.update(entity.id, { password: hashedPassword });
    } else if (ownerType === 'CLINIC') {
      entity = await clinicRepository.findById(tokenRecord.ownerId);
      if (!entity) throw new NotFoundError('Clinic not found');
      await clinicRepository.update(entity.id, { password: hashedPassword });
    } else if (ownerType === 'SELLER') {
      entity = await sellerRepository.findById(tokenRecord.ownerId);
      if (!entity) throw new NotFoundError('Seller not found');
      await sellerRepository.update(entity.id, { password: hashedPassword });
    } else {
      throw new BadRequestError('Unknown account type');
    }

    await passwordSetupTokenRepository.markAsUsed(token);

    eventEmitter.emit('audit', {
      action: 'password.reset',
      entity: ownerType,
      entityId: entity.id,
      performedBy: entity.id,
      details: { email: entity.email },
      ip,
    });

    logger.info(`Password reset for ${ownerType}: ${entity.email}`);

    return {
      message: 'Password reset successfully. You can now login with your new password.',
    };
  }
}

export const authService = new AuthService();

