// src/modules/auth/v1/auth.validation.ts

import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

// ============================================================
// LOGIN
// ============================================================

const loginSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(6).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
});

export const validateLogin = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = loginSchema.validate(req.body, { abortEarly: false });

  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));

    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }

  next();
};

// ============================================================
// USER REGISTER
// ============================================================

const registerUserSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
  firstName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name must be at least 2 characters',
    'any.required': 'First name is required',
  }),
  lastName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name must be at least 2 characters',
    'any.required': 'Last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  dateOfBirth: Joi.date().iso().max('now').required().messages({
    'date.format': 'Date of birth must be in ISO format (YYYY-MM-DD)',
    'date.max': 'Date of birth cannot be in the future',
    'any.required': 'Date of birth is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya ID is required',
  }),
});

export const validateRegisterUser = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = registerUserSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// VERIFY OTP
// ============================================================

const verifyOtpSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  otp: Joi.string().length(6).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'OTP must be exactly 6 digits',
    'string.pattern.base': 'OTP must contain only numbers',
    'any.required': 'OTP is required',
  }),
});

export const validateVerifyOtp = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = verifyOtpSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// RESEND OTP
// ============================================================

const resendOtpSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
});

export const validateResendOtp = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = resendOtpSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// CLINIC REGISTER
// ============================================================

const registerClinicSchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'French name must be at least 2 characters',
    'string.max': 'French name must be less than 100 characters',
    'any.required': 'French name is required',
  }),
  nameAr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Arabic name must be at least 2 characters',
    'string.max': 'Arabic name must be less than 100 characters',
    'any.required': 'Arabic name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
});

export const validateRegisterClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = registerClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// DOCTOR REGISTER
// ============================================================

const registerDoctorSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
  firstNameFr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'French first name must be at least 2 characters',
    'any.required': 'French first name is required',
  }),
  firstNameAr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Arabic first name must be at least 2 characters',
    'any.required': 'Arabic first name is required',
  }),
  lastNameFr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'French last name must be at least 2 characters',
    'any.required': 'French last name is required',
  }),
  lastNameAr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Arabic last name must be at least 2 characters',
    'any.required': 'Arabic last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
});

export const validateRegisterDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = registerDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// SELLER REGISTER
// ============================================================

const registerSellerSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
  firstName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name must be at least 2 characters',
    'any.required': 'First name is required',
  }),
  lastName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name must be at least 2 characters',
    'any.required': 'Last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  businessName: Joi.string().max(100).optional().allow(null, ''),
  businessType: Joi.string().valid('INDIVIDUAL', 'COMPANY', 'ASSOCIATION').optional(),
  taxNumber: Joi.string().optional().allow(null, ''),
  registrationNumber: Joi.string().optional().allow(null, ''),
  address: Joi.string().optional().allow(null, ''),
});

export const validateRegisterSeller = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = registerSellerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// PASSWORD RESET VALIDATIONS
// ============================================================

const requestPasswordResetSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
});

const resetPasswordSchema = Joi.object({
  token: Joi.string().required().messages({
    'any.required': 'Token is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
});

export const validateRequestPasswordReset = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = requestPasswordResetSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateResetPassword = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = resetPasswordSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

