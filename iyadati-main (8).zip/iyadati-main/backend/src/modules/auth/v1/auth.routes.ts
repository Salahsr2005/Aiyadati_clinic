// src/modules/auth/v1/auth.routes.ts

import { Router } from 'express';
import { AuthController } from './auth.controller';
import {
  validateLogin,
  validateRegisterUser,
  validateVerifyOtp,
  validateResendOtp,
  validateRegisterClinic,
  validateRegisterDoctor,
  validateRegisterSeller,
  validateRequestPasswordReset,
  validateResetPassword,
} from './auth.validation';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';

const router = Router();
const authController = new AuthController();

// ============================================================
// SUPER ADMIN / ADMIN
// ============================================================

router.post(
  '/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  validateLogin,
  authController.login.bind(authController)
);

router.post('/logout', authController.logout.bind(authController));
router.get('/me', authController.me.bind(authController));

// ============================================================
// USER
// ============================================================

router.post(
  '/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many registration attempts' }),
  validateRegisterUser,
  authController.registerUser
);

router.post(
  '/verify-otp',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many verification attempts' }),
  validateVerifyOtp,
  authController.verifyOtp
);

router.post(
  '/resend-otp',
  createRateLimiter({ windowMinutes: 15, maxRequests: 3, message: 'Too many OTP requests' }),
  validateResendOtp,
  authController.resendOtp
);

router.post(
  '/user/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  validateLogin,
  authController.loginUser
);

// ============================================================
// CLINIC
// ============================================================

router.post(
  '/clinic/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5 }),
  validateRegisterClinic,
  authController.registerClinic
);

router.post(
  '/clinic/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10 }),
  authController.loginClinic
);

// ============================================================
// DOCTOR
// ============================================================

router.post(
  '/doctor/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many registration attempts' }),
  validateRegisterDoctor,
  authController.registerDoctor
);

router.post(
  '/doctor/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  authController.loginDoctor
);

// ============================================================
// SELLER
// ============================================================

router.post(
  '/seller/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many registration attempts' }),
  validateRegisterSeller,
  authController.registerSeller
);

router.post(
  '/seller/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  validateLogin,
  authController.loginSeller
);

// ============================================================
// PASSWORD RESET
// ============================================================

router.post(
  '/request-password-reset',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many reset requests' }),
  validateRequestPasswordReset,
  authController.requestPasswordReset
);

router.post(
  '/reset-password',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many reset attempts' }),
  validateResetPassword,
  authController.resetPassword
);

export default router;

