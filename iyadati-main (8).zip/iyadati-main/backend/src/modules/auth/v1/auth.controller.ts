// src/modules/auth/v1/auth.controller.ts

import { Request, Response, NextFunction } from 'express';
import { authService } from './auth.service';
import { ResponseUtil } from '../../../core/utils/response';
import { env } from '../../../config/env';

export class AuthController {
  // ============================================================
  // SUPER ADMIN / ADMIN
  // ============================================================

  async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { token, user } = await authService.login(req.body);

      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });

      ResponseUtil.success(res, { token, user }, 'Login successful');
    } catch (error) {
      next(error);
    }
  }

  async logout(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      res.clearCookie('token', {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        path: '/',
      });

      ResponseUtil.success(res, null, 'Logged out successfully');
    } catch (error) {
      next(error);
    }
  }

  async me(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];

      if (!token) {
        ResponseUtil.unauthorized(res, 'Not authenticated');
        return;
      }

      const user = await authService.verifyToken(token);
      ResponseUtil.success(res, { user }, 'User retrieved');
    } catch (error) {
      next(error);
    }
  }

  // ============================================================
  // USER
  // ============================================================

  registerUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.registerUser(req.body);
      ResponseUtil.created(res, result, result.message);
    } catch (error) {
      next(error);
    }
  };

  loginUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.loginUser(req.body);

      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });

      ResponseUtil.success(res, { token, user }, 'Login successful');
    } catch (error) {
      next(error);
    }
  };

  verifyOtp = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.verifyUserOtp(req.body);
      ResponseUtil.success(res, result, result.message);
    } catch (error) {
      next(error);
    }
  };

  resendOtp = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.resendOtp(req.body);
      ResponseUtil.success(res, result, result.message);
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // CLINIC
  // ============================================================

  registerClinic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.registerClinic(req.body, req.ip);
      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });
      ResponseUtil.created(res, { token, user }, 'Clinic registered successfully');
    } catch (error) {
      next(error);
    }
  };

  loginClinic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.loginClinic(req.body);
      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });
      ResponseUtil.success(res, { token, user }, 'Login successful');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // DOCTOR
  // ============================================================

  registerDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.registerDoctor(req.body, req.ip);
      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });
      ResponseUtil.created(res, { token, user }, 'Doctor registered successfully');
    } catch (error) {
      next(error);
    }
  };

  loginDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.loginDoctor(req.body);
      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });
      ResponseUtil.success(res, { token, user }, 'Login successful');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // SELLER
  // ============================================================

  registerSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.registerSeller(req.body, req.ip);
      ResponseUtil.created(res, result, 'Seller registered successfully. Please wait for admin approval.');
    } catch (error) {
      next(error);
    }
  };

  loginSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { token, user } = await authService.loginSeller(req.body);

      res.cookie('token', token, {
        httpOnly: true,
        secure: env.isProduction,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });

      ResponseUtil.success(res, { token, user }, 'Seller login successful');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // PASSWORD RESET
  // ============================================================

  requestPasswordReset = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.requestPasswordReset(req.body, req.ip);
      ResponseUtil.success(res, null, result.message);
    } catch (error) {
      next(error);
    }
  };

  resetPassword = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await authService.resetPassword(req.body, req.ip);
      ResponseUtil.success(res, null, result.message);
    } catch (error) {
      next(error);
    }
  };
}

