// src/modules/auth/v1/auth.types.ts

export interface LoginDTO {
  email: string;
  password: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'USER' | 'CLINIC' | 'DOCTOR' | 'SELLER';
}

export interface AuthResponse {
  token: string;
  user: AuthUser;
}

export interface RegisterUserDTO {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  dateOfBirth: string;
  wilayaId: string;
}

export interface VerifyOtpDTO {
  email: string;
  otp: string;
}

export interface ResendOtpDTO {
  email: string;
}

export interface RegisterClinicDTO {
  nameFr: string;
  nameAr: string;
  phone: string;
  email: string;
  password: string;
  wilayaId: string;
}

export interface RegisterDoctorDTO {
  email: string;
  password: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
}

// ============================================================
// SELLER
// ============================================================

export interface RegisterSellerDTO {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  wilayaId: string;
  businessName?: string;
  businessType?: string;
  taxNumber?: string;
  registrationNumber?: string;
  address?: string;
}

// ============================================================
// PASSWORD RESET
// ============================================================

export interface RequestPasswordResetDTO {
  email: string;
}

export interface ResetPasswordDTO {
  token: string;
  password: string;
}

