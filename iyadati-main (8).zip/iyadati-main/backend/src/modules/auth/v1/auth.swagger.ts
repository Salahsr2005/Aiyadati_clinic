// src/modules/auth/v1/auth.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Auth
 *   description: Authentication and registration endpoints for all user types (Super Admin, Admin, User, Clinic, Doctor, Seller)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     LoginRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Registered email address
 *           example: superadmin@gmail.com
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Account password (min 6 characters)
 *           example: your_password
 *     
 *     RegisterUserRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstName
 *         - lastName
 *         - phone
 *         - dateOfBirth
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: User email address
 *           example: user@example.com
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Password (min 6 characters)
 *           example: "user123456"
 *         firstName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: First name
 *           example: "John"
 *         lastName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Last name
 *           example: "Doe"
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Phone number (exactly 10 digits)
 *           example: "0555123456"
 *         dateOfBirth:
 *           type: string
 *           format: date
 *           description: Date of birth (YYYY-MM-DD)
 *           example: "1990-01-01"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *     
 *     RegisterClinicRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *         - phone
 *         - email
 *         - password
 *         - wilayaId
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           description: Clinic name in French
 *           example: "Clinique El Wouroud"
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           description: Clinic name in Arabic
 *           example: "عيادة الورود"
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Phone number (exactly 10 digits)
 *           example: "0555123456"
 *         email:
 *           type: string
 *           format: email
 *           description: Clinic email address
 *           example: "contact@clinique.dz"
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Clinic password (min 6 characters)
 *           example: "clinic123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *     
 *     RegisterDoctorRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstNameFr
 *         - firstNameAr
 *         - lastNameFr
 *         - lastNameAr
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Doctor email address
 *           example: "doctor@example.com"
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Password (min 6 characters)
 *           example: "doctor123456"
 *         firstNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: First name in French
 *           example: "Mohamed"
 *         firstNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: First name in Arabic
 *           example: "محمد"
 *         lastNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Last name in French
 *           example: "Benali"
 *         lastNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Last name in Arabic
 *           example: "بن علي"
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Phone number (exactly 10 digits)
 *           example: "0665123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *     
 *     RegisterSellerRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstName
 *         - lastName
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Seller email address
 *           example: seller@example.com
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Password (min 6 characters)
 *           example: "seller123456"
 *         firstName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: First name
 *           example: "Mohamed"
 *         lastName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Last name
 *           example: "Khelifi"
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Phone number (exactly 10 digits)
 *           example: "0555123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         businessName:
 *           type: string
 *           maxLength: 100
 *           description: Business name (optional)
 *           example: "Pharma Santé"
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *           description: Type of business entity
 *           example: "INDIVIDUAL"
 *         taxNumber:
 *           type: string
 *           description: Tax identification number (NIF)
 *           example: "1234567890"
 *         registrationNumber:
 *           type: string
 *           description: Commercial registration number (RC)
 *           example: "9876543210"
 *         address:
 *           type: string
 *           description: Business address
 *           example: "123 Rue des Médecins, Alger"
 *     
 *     VerifyOtpRequest:
 *       type: object
 *       required:
 *         - email
 *         - otp
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Email address used during registration
 *           example: user@example.com
 *         otp:
 *           type: string
 *           pattern: '^[0-9]{6}$'
 *           description: 6-digit verification code sent to email
 *           example: "123456"
 *     
 *     ResendOtpRequest:
 *       type: object
 *       required:
 *         - email
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Email address used during registration
 *           example: user@example.com
 *     
 *     AuthUser:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: User unique identifier
 *           example: 550e8400-e29b-41d4-a716-446655440000
 *         email:
 *           type: string
 *           format: email
 *           description: User email address
 *           example: superadmin@gmail.com
 *         name:
 *           type: string
 *           description: User display name
 *           example: superadmin
 *         role:
 *           type: string
 *           enum: [SUPER_ADMIN, ADMIN, USER, CLINIC, DOCTOR, SELLER]
 *           description: User role for authorization
 *           example: SUPER_ADMIN
 *     
 *     AuthResponse:
 *       type: object
 *       properties:
 *         token:
 *           type: string
 *           description: |
 *             JWT access token.
 *             
 *             **Web clients**: Token is also set as an HTTP-only cookie automatically. You can ignore this field.
 *             
 *             **Mobile clients**: Store this token securely and send it in the Authorization header.
 *           example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *         user:
 *           $ref: '#/components/schemas/AuthUser'
 *     
 *     RequestPasswordResetRequest:
 *       type: object
 *       required:
 *         - email
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Email address of the account
 *           example: user@example.com
 *     
 *     ResetPasswordRequest:
 *       type: object
 *       required:
 *         - token
 *         - password
 *       properties:
 *         token:
 *           type: string
 *           description: Reset token received via email
 *           example: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: New password (min 6 characters)
 *           example: "MyNewSecurePassword123!"
 *     
 *     ValidationError:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: Validation failed
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: email
 *               message:
 *                 type: string
 *                 example: Valid email is required
 *     
 *     Error:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: Error message
 *         error:
 *           type: string
 *           example: Error details
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *               message:
 *                 type: string
 */

// ============================================================
// USER REGISTRATION
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/register:
 *   post:
 *     summary: Register a new user (patient)
 *     description: |
 *       Creates a new user account and sends a verification code via email.
 *       
 *       **Flow:**
 *       1. User submits registration data
 *       2. Account is created (unverified)
 *       3. A 6-digit OTP is sent to the user's email
 *       4. User must verify email with the OTP before logging in
 *       
 *       **Note:** This endpoint is for patient/user registration only.
 *       For clinic registration, use /clinic/register.
 *       For doctor registration, use /doctor/register.
 *       For seller registration, use /seller/register.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterUserRequest'
 *           example:
 *             email: "user@example.com"
 *             password: "user123456"
 *             firstName: "John"
 *             lastName: "Doe"
 *             phone: "0555123456"
 *             dateOfBirth: "1990-01-01"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Registration successful - check email for OTP
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Registration successful. Please check your email for the verification code.
 *                 data:
 *                   type: object
 *                   properties:
 *                     message:
 *                       type: string
 *                       example: Registration successful. Please check your email for the verification code.
 *             example:
 *               success: true
 *               message: "Registration successful. Please check your email for the verification code."
 *               data:
 *                 message: "Registration successful. Please check your email for the verification code."
 *       400:
 *         description: Validation error - missing or invalid fields
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *             examples:
 *               missingFields:
 *                 summary: Missing required fields
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Email is required"
 *                     - field: "phone"
 *                       message: "Phone is required"
 *               invalidPhone:
 *                 summary: Invalid phone number
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "phone"
 *                       message: "Phone must be exactly 10 digits"
 *               invalidEmail:
 *                 summary: Invalid email format
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Valid email is required"
 *       409:
 *         description: Conflict - email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               emailExists:
 *                 summary: Email already registered
 *                 value:
 *                   success: false
 *                   message: "Email already registered"
 *                   error: "Email already registered"
 *                   errors:
 *                     - field: "email"
 *                       message: "This email is already in use"
 *               phoneExists:
 *                 summary: Phone already registered
 *                 value:
 *                   success: false
 *                   message: "Phone already registered"
 *                   error: "Phone already registered"
 *                   errors:
 *                     - field: "phone"
 *                       message: "This phone number is already in use"
 *       429:
 *         description: Too many registration attempts
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Too many registration attempts"
 *               error: "Too many registration attempts"
 *       500:
 *         description: Internal server error
 */

// ============================================================
// USER VERIFICATION
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/verify-otp:
 *   post:
 *     summary: Verify email with OTP
 *     description: |
 *       Verifies a user's email using the 6-digit code sent during registration.
 *       **OTP expires after 10 minutes.**
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/VerifyOtpRequest'
 *           example:
 *             email: "user@example.com"
 *             otp: "123456"
 *     responses:
 *       200:
 *         description: Email verified successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Email verified successfully. You can now login.
 *                 data:
 *                   type: object
 *                   properties:
 *                     message:
 *                       type: string
 *                       example: Email verified successfully. You can now login.
 *       400:
 *         description: Verification failed (invalid OTP, expired, already verified)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               invalidOtp:
 *                 summary: Invalid OTP
 *                 value:
 *                   success: false
 *                   message: "Invalid verification code"
 *                   error: "Invalid verification code"
 *               expiredOtp:
 *                 summary: OTP expired
 *                 value:
 *                   success: false
 *                   message: "Verification code has expired. Please request a new one."
 *                   error: "Verification code has expired. Please request a new one."
 *               alreadyVerified:
 *                 summary: Already verified
 *                 value:
 *                   success: false
 *                   message: "Email already verified"
 *                   error: "Email already verified"
 *       429:
 *         description: Too many verification attempts
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/v1/auth/v1/resend-otp:
 *   post:
 *     summary: Resend verification OTP
 *     description: Sends a new verification code. Always returns success for security.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResendOtpRequest'
 *           example:
 *             email: "user@example.com"
 *     responses:
 *       200:
 *         description: OTP sent (same response whether email exists or not)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: If your email is registered, a new verification code has been sent.
 *       429:
 *         description: Too many OTP requests
 *       500:
 *         description: Internal server error
 */

// ============================================================
// USER LOGIN
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/user/login:
 *   post:
 *     summary: Login for Users (Patients)
 *     description: |
 *       Authenticates a regular user. Must be registered, verified, and not suspended.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           example:
 *             email: "user@example.com"
 *             password: "user123456"
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Login successful"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "user@example.com"
 *                   name: "John Doe"
 *                   role: "USER"
 *       401:
 *         description: Invalid credentials, not verified, or suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               invalidCredentials:
 *                 summary: Wrong email or password
 *                 value:
 *                   success: false
 *                   message: "Invalid email or password"
 *                   error: "Invalid email or password"
 *               notVerified:
 *                 summary: Email not verified
 *                 value:
 *                   success: false
 *                   message: "Please verify your email first"
 *                   error: "Please verify your email first"
 *               suspended:
 *                 summary: Account suspended
 *                 value:
 *                   success: false
 *                   message: "Your account has been suspended"
 *                   error: "Your account has been suspended"
 *       429:
 *         description: Too many login attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// CLINIC REGISTRATION
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/clinic/register:
 *   post:
 *     summary: Register a new clinic
 *     description: |
 *       Public endpoint for clinic registration. Clinic sets a password and receives
 *       a JWT token immediately to upload required documents.
 *       
 *       **Clinic Registration Flow:**
 *       1. Clinic owner submits registration with name, email, phone, password, and wilaya
 *       2. Clinic is created (unverified, incomplete)
 *       3. JWT token returned - clinic can upload documents immediately
 *       4. Clinic uploads required documents via clinic endpoints
 *       5. Staff reviews documents and verifies the clinic
 *       6. Once verified, clinic logs in with email + password via /clinic/login
 *       7. Clinic completes profile (description, logo, coordinates)
 *       
 *       **Security:** Password is hashed with bcrypt before storage.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterClinicRequest'
 *           example:
 *             nameFr: "Clinique El Wouroud"
 *             nameAr: "عيادة الورود"
 *             phone: "0555123456"
 *             email: "contact@clinique.dz"
 *             password: "clinic123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Clinic registered successfully - JWT token returned for document upload
 *         headers:
 *           Set-Cookie:
 *             schema:
 *               type: string
 *               example: token=eyJhbGciOi...; HttpOnly; SameSite=Strict; Path=/
 *             description: HTTP-only cookie set automatically (web clients)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Clinic registered successfully
 *                 data:
 *                   $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Clinic registered successfully"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "contact@clinique.dz"
 *                   name: "Clinique El Wouroud"
 *                   role: "CLINIC"
 *       400:
 *         description: Validation error - missing or invalid fields
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       409:
 *         description: Conflict - email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many registration attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// CLINIC LOGIN
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/clinic/login:
 *   post:
 *     summary: Login for verified clinics
 *     description: |
 *       Authenticates a clinic using email and password. Clinic must be verified by staff first.
 *       
 *       **Requirements:**
 *       - Clinic must be registered via /clinic/register
 *       - Clinic must be verified by staff
 *       - Clinic must not be suspended
 *       
 *       **After login**, the clinic receives a JWT token and can complete profile and manage rooms/hours.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           example:
 *             email: "contact@clinique.dz"
 *             password: "clinic123456"
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Login successful"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "contact@clinique.dz"
 *                   name: "Clinique El Wouroud"
 *                   role: "CLINIC"
 *       401:
 *         description: Invalid credentials, not verified, or suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many login attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// DOCTOR REGISTRATION
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/doctor/register:
 *   post:
 *     summary: Register a new doctor
 *     description: |
 *       Public endpoint for doctor registration. Returns a JWT token immediately
 *       so the doctor can upload required documents right after registration.
 *       
 *       **Doctor Registration Flow:**
 *       1. Doctor submits registration with personal info (French + Arabic names)
 *       2. Doctor is created with unverified and incomplete status
 *       3. JWT token is returned - doctor can now upload documents
 *       4. Doctor uploads required documents (degree, license, ID card)
 *       5. Staff reviews the documents and verifies the doctor
 *       6. Once verified, doctor can login via /doctor/login
 *       7. After login, doctor can complete profile (bio, specialties, photo, coordinates)
 *       
 *       **Client types:**
 *       - **Web**: HTTP-only cookie set automatically
 *       - **Mobile**: Store `data.token` in secure storage
 *       
 *       **Security:** Password is hashed with bcrypt before storage.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterDoctorRequest'
 *           example:
 *             email: "doctor@example.com"
 *             password: "doctor123456"
 *             firstNameFr: "Mohamed"
 *             firstNameAr: "محمد"
 *             lastNameFr: "Benali"
 *             lastNameAr: "بن علي"
 *             phone: "0665123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Doctor registered successfully - JWT token returned for document upload
 *         headers:
 *           Set-Cookie:
 *             schema:
 *               type: string
 *               example: token=eyJhbGciOi...; HttpOnly; SameSite=Strict; Path=/
 *             description: HTTP-only cookie set automatically (web clients)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Doctor registered successfully"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "doctor@example.com"
 *                   name: "Mohamed Benali"
 *                   role: "DOCTOR"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       409:
 *         description: Conflict - email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many registration attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// DOCTOR LOGIN
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/doctor/login:
 *   post:
 *     summary: Login for verified doctors
 *     description: |
 *       Authenticates a doctor using email and password. Doctor must be verified by staff first.
 *       
 *       **Requirements:**
 *       - Doctor must be registered via /doctor/register
 *       - Doctor must be verified by staff
 *       - Doctor must not be suspended
 *       
 *       **After login**, the doctor receives a JWT token and can manage their profile.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           example:
 *             email: "doctor@example.com"
 *             password: "doctor123456"
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Login successful"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "doctor@example.com"
 *                   name: "Mohamed Benali"
 *                   role: "DOCTOR"
 *       401:
 *         description: Invalid credentials, not verified, or suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many login attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// SELLER REGISTRATION
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/seller/register:
 *   post:
 *     summary: Register a new seller
 *     description: |
 *       Public endpoint for seller registration.
 *       
 *       **Flow:**
 *       1. Seller submits registration with personal and business details
 *       2. Seller account is created with `PENDING` status
 *       3. Password is set immediately (seller can login but can't sell until approved)
 *       4. Admin receives notification about new seller registration
 *       5. Admin reviews and activates the seller account
 *       
 *       **After approval,** seller can:
 *       - Create products
 *       - Manage orders
 *       - Upload documents
 *       
 *       **Note:** Sellers can also be created via the application flow
 *       (`/api/v1/applications/v1/seller`).
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterSellerRequest'
 *           example:
 *             email: "seller@example.com"
 *             password: "seller123456"
 *             firstName: "Mohamed"
 *             lastName: "Khelifi"
 *             phone: "0555123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             businessName: "Pharma Santé"
 *             businessType: "INDIVIDUAL"
 *             taxNumber: "1234567890"
 *             registrationNumber: "9876543210"
 *             address: "123 Rue des Médecins, Alger"
 *     responses:
 *       201:
 *         description: Seller registered successfully - pending admin approval
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Seller registered successfully. Please wait for admin approval.
 *                 data:
 *                   $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Seller registered successfully. Please wait for admin approval."
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "seller@example.com"
 *                   name: "Pharma Santé"
 *                   role: "SELLER"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       409:
 *         description: Email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many registration attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// SELLER LOGIN
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/seller/login:
 *   post:
 *     summary: Login for sellers
 *     description: |
 *       Authenticates a seller using email and password.
 *       
 *       **Requirements:**
 *       - Seller must be registered (via /seller/register or application flow)
 *       - Seller account must be approved (status = ACTIVE)
 *       - Seller must not be suspended or banned
 *       
 *       **Allowed Statuses:**
 *       - ✅ ACTIVE: Can login and sell
 *       - ❌ PENDING: Cannot login (waiting for admin approval)
 *       - ❌ SUSPENDED: Cannot login (temporarily blocked)
 *       - ❌ BANNED: Cannot login (permanently blocked)
 *       
 *       **After login,** seller can access e-commerce endpoints:
 *       - `/api/v1/ecommerce/v1/products` - Manage products
 *       - `/api/v1/ecommerce/v1/orders` - Manage orders
 *       - `/api/v1/ecommerce/v1/seller/documents` - Manage documents
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           example:
 *             email: "seller@example.com"
 *             password: "seller123456"
 *     responses:
 *       200:
 *         description: Login successful
 *         headers:
 *           Set-Cookie:
 *             schema:
 *               type: string
 *               example: token=eyJhbGciOi...; HttpOnly; SameSite=Strict; Path=/
 *             description: HTTP-only cookie set automatically (web clients)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Seller login successful
 *                 data:
 *                   $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Seller login successful"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "seller@example.com"
 *                   name: "Pharma Santé"
 *                   role: "SELLER"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       401:
 *         description: Invalid credentials or account not active
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               invalidCredentials:
 *                 summary: Wrong email or password
 *                 value:
 *                   success: false
 *                   message: "Invalid email or password"
 *                   error: "Invalid email or password"
 *               pending:
 *                 summary: Seller account pending approval
 *                 value:
 *                   success: false
 *                   message: "Your seller account is pending approval"
 *                   error: "Your seller account is pending approval"
 *               suspended:
 *                 summary: Seller account suspended
 *                 value:
 *                   success: false
 *                   message: "Your seller account has been suspended"
 *                   error: "Your seller account has been suspended"
 *               banned:
 *                 summary: Seller account banned
 *                 value:
 *                   success: false
 *                   message: "Your seller account has been banned"
 *                   error: "Your seller account has been banned"
 *       429:
 *         description: Too many login attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// STAFF LOGIN (SUPER ADMIN / ADMIN)
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/login:
 *   post:
 *     summary: Login for Super Admin and Admin (Staff)
 *     description: |
 *       Authenticates a Super Admin or Admin and returns a JWT token.
 *       **This endpoint is for staff only.**
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           examples:
 *             superAdmin:
 *               summary: Super Admin login
 *               value:
 *                 email: "superadmin@gmail.com"
 *                 password: "kolnhbdasgjejoefskn"
 *             admin:
 *               summary: Admin login
 *               value:
 *                 email: "admin@iyadati.com"
 *                 password: "admin123456"
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               success: true
 *               message: "Login successful"
 *               data:
 *                 token: "eyJhbGciOiJIUzI1NiIs..."
 *                 user:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "superadmin@gmail.com"
 *                   name: "superadmin"
 *                   role: "SUPER_ADMIN"
 *       401:
 *         description: Invalid credentials
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: Too many login attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// LOGOUT
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/logout:
 *   post:
 *     summary: Logout
 *     description: Clears authentication session. Works for all roles.
 *     tags: [Auth]
 *     security: []
 *     responses:
 *       200:
 *         description: Logged out successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Logged out successfully
 *                 data:
 *                   type: null
 *       500:
 *         description: Internal server error
 */

// ============================================================
// GET CURRENT USER
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/me:
 *   get:
 *     summary: Get current authenticated user
 *     description: Returns the currently authenticated user. Works for all roles.
 *     tags: [Auth]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Current user retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: User retrieved
 *                 data:
 *                   type: object
 *                   properties:
 *                     user:
 *                       $ref: '#/components/schemas/AuthUser'
 *             examples:
 *               SuperAdmin:
 *                 summary: Super Admin user
 *                 value:
 *                   success: true
 *                   message: "User retrieved"
 *                   data:
 *                     user:
 *                       id: "550e8400-e29b-41d4-a716-446655440000"
 *                       email: "superadmin@gmail.com"
 *                       name: "superadmin"
 *                       role: "SUPER_ADMIN"
 *               Seller:
 *                 summary: Seller user
 *                 value:
 *                   success: true
 *                   message: "User retrieved"
 *                   data:
 *                     user:
 *                       id: "550e8400-e29b-41d4-a716-446655440000"
 *                       email: "seller@example.com"
 *                       name: "Pharma Santé"
 *                       role: "SELLER"
 *       401:
 *         description: Not authenticated - no valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               noToken:
 *                 summary: No token provided
 *                 value:
 *                   success: false
 *                   message: "Not authenticated"
 *                   error: "Not authenticated"
 *               invalidToken:
 *                 summary: Invalid or expired token
 *                 value:
 *                   success: false
 *                   message: "Invalid or expired token"
 *                   error: "Invalid or expired token"
 *       500:
 *         description: Internal server error
 */

// ============================================================
// PASSWORD RESET
// ============================================================

/**
 * @swagger
 * /api/v1/auth/v1/request-password-reset:
 *   post:
 *     summary: Request password reset
 *     description: |
 *       Sends a password reset link to the provided email address.
 *       Works for all account types: USER, DOCTOR, CLINIC, SELLER.
 *       
 *       **Flow:**
 *       1. User enters their email
 *       2. System finds the account (if exists)
 *       3. Reset token is created (valid 24 hours)
 *       4. Email is sent with reset link
 *       5. User clicks link to set new password
 *       
 *       **Security:** Always returns the same message whether email exists or not.
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RequestPasswordResetRequest'
 *           example:
 *             email: "user@example.com"
 *     responses:
 *       200:
 *         description: Reset link sent (if email exists)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: If an account with this email exists, a password reset link has been sent.
 *                 data:
 *                   type: null
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       429:
 *         description: Too many reset requests
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Too many reset requests"
 *               error: "Too many reset requests"
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/v1/auth/v1/reset-password:
 *   post:
 *     summary: Reset password using token
 *     description: |
 *       Resets the password using the token received via email.
 *       Works for all account types: USER, DOCTOR, CLINIC, SELLER.
 *       
 *       **Flow:**
 *       1. User clicks reset link from email
 *       2. Frontend extracts token from URL
 *       3. User enters new password
 *       4. This endpoint validates the token and updates password
 *       5. Token is marked as used (cannot be reused)
 *       
 *       **Token expiry:** 24 hours from request
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResetPasswordRequest'
 *           example:
 *             token: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
 *             password: "MyNewSecurePassword123!"
 *     responses:
 *       200:
 *         description: Password reset successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Password reset successfully. You can now login with your new password.
 *                 data:
 *                   type: null
 *       400:
 *         description: Invalid or expired token, or validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               invalidToken:
 *                 summary: Invalid token
 *                 value:
 *                   success: false
 *                   message: "Invalid or expired reset token"
 *                   error: "Invalid or expired reset token"
 *               usedToken:
 *                 summary: Token already used
 *                 value:
 *                   success: false
 *                   message: "This reset link has already been used"
 *                   error: "This reset link has already been used"
 *               expiredToken:
 *                 summary: Token expired
 *                 value:
 *                   success: false
 *                   message: "This reset link has expired. Please request a new one."
 *                   error: "This reset link has expired. Please request a new one."
 *       429:
 *         description: Too many reset attempts
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Too many reset attempts"
 *               error: "Too many reset attempts"
 *       500:
 *         description: Internal server error
 */