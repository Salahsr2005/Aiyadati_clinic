import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';
import { SellerStatus, SellerType } from '@prisma/client';

// ============================================================
// CREATE SELLER VALIDATION
// ============================================================

const createSellerSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
  firstName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name must be at least 2 characters',
    'any.required': 'First name is required',
  }),
  lastName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name must be at least 2 characters',
    'any.required': 'Last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya ID is required',
  }),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  businessName: Joi.string().min(2).max(100).optional().allow(null, ''),
  businessType: Joi.string().valid(...Object.values(SellerType)).optional(),
  taxNumber: Joi.string().max(50).optional().allow(null, ''),
  registrationNumber: Joi.string().max(50).optional().allow(null, ''),
  address: Joi.string().max(500).optional().allow(null, ''),
});

export const validateCreateSeller = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createSellerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// UPDATE SELLER VALIDATION
// ============================================================

const updateSellerSchema = Joi.object({
  firstName: Joi.string().min(2).max(50).optional(),
  lastName: Joi.string().min(2).max(50).optional(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).optional(),
  email: Joi.string().email().optional(),
  businessName: Joi.string().min(2).max(100).optional().allow(null, ''),
  businessType: Joi.string().valid(...Object.values(SellerType)).optional(),
  taxNumber: Joi.string().max(50).optional().allow(null, ''),
  registrationNumber: Joi.string().max(50).optional().allow(null, ''),
  wilayaId: Joi.string().uuid().optional(),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  address: Joi.string().max(500).optional().allow(null, ''),
  isVerified: Joi.boolean().optional(),
  isSuspended: Joi.boolean().optional(),
  suspensionReason: Joi.string().max(500).optional().allow(null, ''),
  status: Joi.string().valid(...Object.values(SellerStatus)).optional(),
}).min(1).messages({
  'object.min': 'At least one field must be provided',
});

export const validateUpdateSeller = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateSellerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// SUSPEND SELLER VALIDATION
// ============================================================

const suspendSellerSchema = Joi.object({
  reason: Joi.string().min(3).max(500).required().messages({
    'string.min': 'Reason must be at least 3 characters',
    'any.required': 'Reason is required',
  }),
});

export const validateSuspendSeller = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = suspendSellerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// REJECT SELLER VALIDATION
// ============================================================

const rejectSellerSchema = Joi.object({
  reason: Joi.string().min(3).max(500).required().messages({
    'string.min': 'Reason must be at least 3 characters',
    'any.required': 'Reason is required',
  }),
});

export const validateRejectSeller = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = rejectSellerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

