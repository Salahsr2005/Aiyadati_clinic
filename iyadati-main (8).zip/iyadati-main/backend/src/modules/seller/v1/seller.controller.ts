// src/modules/seller/v1/seller.controller.ts

import { Request, Response, NextFunction } from 'express';
import { sellerService } from './seller.service';
import { ResponseUtil } from '../../../core/utils/response';
import {
  CreateSellerDTO,
  UpdateSellerDTO,
  SuspendSellerDTO,
  SellerFilters,
} from './seller.types';
import { SellerStatus } from '@prisma/client';

export class SellerController {
  // ============================================================
  // GET ALL SELLERS (Admin)
  // ============================================================

  getSellers = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters: SellerFilters = {
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10,
        status: req.query.status as SellerStatus,
        isVerified: req.query.isVerified === 'true' ? true : req.query.isVerified === 'false' ? false : undefined,
        isSuspended: req.query.isSuspended === 'true' ? true : req.query.isSuspended === 'false' ? false : undefined,
        search: req.query.search as string,
        wilayaId: req.query.wilayaId as string,
        sortBy: req.query.sortBy as string,
        sortOrder: req.query.sortOrder as 'asc' | 'desc',
      };

      const result = await sellerService.getSellers(filters);

      ResponseUtil.paginated(
        res,
        result.sellers,
        result.total,
        filters.page || 1,
        filters.limit || 10,
        'Sellers retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // GET SELLER BY ID (Admin)
  // ============================================================

  getSellerById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const seller = await sellerService.getSellerById(req.params.id);
      ResponseUtil.success(res, seller, 'Seller retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // GET SELLER BY EMAIL (Admin)
  // ============================================================

  getSellerByEmail = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const seller = await sellerService.getSellerByEmail(req.params.email);
      ResponseUtil.success(res, seller, 'Seller retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // GET SELLER BY PHONE (Admin)
  // ============================================================

  getSellerByPhone = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const seller = await sellerService.getSellerByPhone(req.params.phone);
      ResponseUtil.success(res, seller, 'Seller retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // CREATE SELLER (Admin)
  // ============================================================

  createSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: CreateSellerDTO = req.body;
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      const seller = await sellerService.createSeller(data, adminId, ip);
      ResponseUtil.created(res, seller, 'Seller created successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // UPDATE SELLER (Admin)
  // ============================================================

  updateSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: UpdateSellerDTO = req.body;
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      const seller = await sellerService.updateSeller(req.params.id, data, adminId, ip);
      ResponseUtil.success(res, seller, 'Seller updated successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // VERIFY SELLER (Admin)
  // ============================================================

  verifySeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      const seller = await sellerService.verifySeller(req.params.id, adminId, ip);
      ResponseUtil.success(res, seller, 'Seller verified successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // REJECT SELLER (Admin)
  // ============================================================

  rejectSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      if (!reason) {
        ResponseUtil.badRequest(res, 'Rejection reason is required');
        return;
      }

      const seller = await sellerService.rejectSeller(id, reason, adminId, ip);
      ResponseUtil.success(res, seller, 'Seller rejected successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // SUSPEND SELLER (Admin)
  // ============================================================

  suspendSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: SuspendSellerDTO = req.body;
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      if (!data.reason) {
        ResponseUtil.badRequest(res, 'Suspension reason is required');
        return;
      }

      const seller = await sellerService.suspendSeller(req.params.id, data, adminId, ip);
      ResponseUtil.success(res, seller, 'Seller suspended successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // UNSUSPEND SELLER (Admin)
  // ============================================================

  unsuspendSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      const seller = await sellerService.unsuspendSeller(req.params.id, adminId, ip);
      ResponseUtil.success(res, seller, 'Seller unsuspended successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // DELETE SELLER (Admin)
  // ============================================================

  deleteSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const adminId = req.user?.id;
      const ip = req.ip;

      if (!adminId) {
        ResponseUtil.unauthorized(res, 'Admin authentication required');
        return;
      }

      await sellerService.deleteSeller(req.params.id, adminId, ip);
      ResponseUtil.success(res, null, 'Seller deleted successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // GET SELLER STATS (Admin)
  // ============================================================

  getSellerStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const stats = await sellerService.getSellerStats();
      ResponseUtil.success(res, stats, 'Seller statistics retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // GET PENDING SELLERS (Admin)
  // ============================================================

  getPendingSellers = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const sellers = await sellerService.getPendingSellers(limit);
      ResponseUtil.success(res, sellers, 'Pending sellers retrieved successfully');
    } catch (error) {
      next(error);
    }
  };
}

export const sellerController = new SellerController();

