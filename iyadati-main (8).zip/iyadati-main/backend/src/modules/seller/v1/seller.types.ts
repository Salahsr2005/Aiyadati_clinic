import { SellerStatus, SellerType } from '@prisma/client';

export interface SellerResponse {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  businessName: string | null;
  businessType: SellerType;
  taxNumber: string | null;
  registrationNumber: string | null;
  wilayaId: string;
  wilaya?: {
    id: string;
    code: number;
    nameFr: string;
    nameAr: string;
  };
  baladyaId: string | null;
  baladya?: {
    id: string;
    nameFr: string;
    nameAr: string;
  } | null;
  address: string | null;
  status: SellerStatus;
  isVerified: boolean;
  isSuspended: boolean;
  suspensionReason: string | null;
  verifiedBy: string | null;
  verifiedAt: string | null;
  rejectionReason: string | null;
  avgRating: number | null;
  totalReviews: number;
  productCount?: number;
  orderCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface SellerFilters {
  page?: number;
  limit?: number;
  status?: SellerStatus;
  isVerified?: boolean;
  isSuspended?: boolean;
  search?: string;
  wilayaId?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface CreateSellerDTO {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  wilayaId: string;
  baladyaId?: string;
  businessName?: string;
  businessType?: SellerType;
  taxNumber?: string;
  registrationNumber?: string;
  address?: string;
}

export interface UpdateSellerDTO {
  firstName?: string;
  lastName?: string;
  phone?: string;
  email?: string;
  businessName?: string | null;
  businessType?: SellerType;
  taxNumber?: string | null;
  registrationNumber?: string | null;
  wilayaId?: string;
  baladyaId?: string | null;
  address?: string | null;
  isVerified?: boolean;
  isSuspended?: boolean;
  suspensionReason?: string | null;
  status?: SellerStatus;
}

export interface SuspendSellerDTO {
  reason: string;
}

