// src/modules/seller/v1/seller.routes.ts

import { Router } from 'express';
import { sellerController } from './seller.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import {
  validateCreateSeller,
  validateUpdateSeller,
  validateSuspendSeller,
  validateRejectSeller,
} from './seller.validation';

const router = Router();

// ============================================================
// ALL ROUTES REQUIRE ADMIN AUTHENTICATION
// ============================================================

router.use(authenticate, authorize('SUPER_ADMIN', 'ADMIN'));

// ============================================================
// GET ROUTES
// ============================================================

/**
 * GET /api/v1/seller/v1
 * Get all sellers with pagination and filters
 */
router.get(
  '/',
  createRateLimiter({ windowMinutes: 1, maxRequests: 30 }),
  sellerController.getSellers
);

/**
 * GET /api/v1/seller/v1/stats
 * Get seller statistics
 */
router.get(
  '/stats',
  sellerController.getSellerStats
);

/**
 * GET /api/v1/seller/v1/pending
 * Get pending sellers
 */
router.get(
  '/pending',
  sellerController.getPendingSellers
);

/**
 * GET /api/v1/seller/v1/id/:id
 * Get seller by ID
 */
router.get(
  '/id/:id',
  sellerController.getSellerById
);

/**
 * GET /api/v1/seller/v1/email/:email
 * Get seller by email
 */
router.get(
  '/email/:email',
  sellerController.getSellerByEmail
);

/**
 * GET /api/v1/seller/v1/phone/:phone
 * Get seller by phone
 */
router.get(
  '/phone/:phone',
  sellerController.getSellerByPhone
);

// ============================================================
// POST ROUTES
// ============================================================

/**
 * POST /api/v1/seller/v1
 * Create a new seller
 */
router.post(
  '/',
  createRateLimiter({ windowMinutes: 5, maxRequests: 10 }),
  validateCreateSeller,
  sellerController.createSeller
);

// ============================================================
// PATCH ROUTES
// ============================================================

/**
 * PATCH /api/v1/seller/v1/:id
 * Update a seller
 */
router.patch(
  '/:id',
  validateUpdateSeller,
  sellerController.updateSeller
);

/**
 * PATCH /api/v1/seller/v1/:id/verify
 * Verify a seller
 */
router.patch(
  '/:id/verify',
  sellerController.verifySeller
);

/**
 * PATCH /api/v1/seller/v1/:id/reject
 * Reject a seller
 */
router.patch(
  '/:id/reject',
  validateRejectSeller,
  sellerController.rejectSeller
);

/**
 * PATCH /api/v1/seller/v1/:id/suspend
 * Suspend a seller
 */
router.patch(
  '/:id/suspend',
  validateSuspendSeller,
  sellerController.suspendSeller
);

/**
 * PATCH /api/v1/seller/v1/:id/unsuspend
 * Unsuspend a seller
 */
router.patch(
  '/:id/unsuspend',
  sellerController.unsuspendSeller
);

// ============================================================
// DELETE ROUTES
// ============================================================

/**
 * DELETE /api/v1/seller/v1/:id
 * Delete a seller (hard delete - admin only)
 */
router.delete(
  '/:id',
  sellerController.deleteSeller
);

export default router;

