// src/modules/seller/v1/seller.service.ts

import bcrypt from 'bcryptjs';
import { sellerRepository } from '../../../repositories/seller.repository';
import { eventEmitter } from '../../../core/events/event-emitter';
import { logger } from '../../../core/utils/logger';
import { NotFoundError, ConflictError, BadRequestError } from '../../../core/utils/error';
import {
  SellerResponse,
  SellerFilters,
  CreateSellerDTO,
  UpdateSellerDTO,
  SuspendSellerDTO,
} from './seller.types';
import { SellerStatus } from '@prisma/client';

export class SellerService {
  private toSellerResponse(seller: any): SellerResponse {
    return {
      id: seller.id,
      email: seller.email,
      firstName: seller.firstName,
      lastName: seller.lastName,
      phone: seller.phone,
      businessName: seller.businessName,
      businessType: seller.businessType,
      taxNumber: seller.taxNumber,
      registrationNumber: seller.registrationNumber,
      wilayaId: seller.wilayaId,
      wilaya: seller.wilaya ? {
        id: seller.wilaya.id,
        code: seller.wilaya.code,
        nameFr: seller.wilaya.nameFr,
        nameAr: seller.wilaya.nameAr,
      } : undefined,
      baladyaId: seller.baladyaId,
      baladya: seller.baladya ? {
        id: seller.baladya.id,
        nameFr: seller.baladya.nameFr,
        nameAr: seller.baladya.nameAr,
      } : null,
      address: seller.address,
      status: seller.status,
      isVerified: seller.isVerified,
      isSuspended: seller.isSuspended,
      suspensionReason: seller.suspensionReason,
      verifiedBy: seller.verifiedBy,
      verifiedAt: seller.verifiedAt?.toISOString() || null,
      rejectionReason: seller.rejectionReason,
      avgRating: seller.avgRating,
      totalReviews: seller.totalReviews,
      productCount: seller._count?.products,
      orderCount: seller._count?.orders,
      createdAt: seller.createdAt.toISOString(),
      updatedAt: seller.updatedAt.toISOString(),
    };
  }

  // ============================================================
  // GET ALL SELLERS
  // ============================================================

  async getSellers(filters: SellerFilters): Promise<{ sellers: SellerResponse[]; total: number }> {
    const { items, total } = await sellerRepository.findAll({
      page: filters.page || 1,
      limit: filters.limit || 10,
      status: filters.status,
      isVerified: filters.isVerified,
      isSuspended: filters.isSuspended,
      search: filters.search,
      wilayaId: filters.wilayaId,
      sortBy: filters.sortBy || 'createdAt',
      sortOrder: filters.sortOrder || 'desc',
    });

    return {
      sellers: items.map((s: any) => this.toSellerResponse(s)),
      total,
    };
  }

  // ============================================================
  // GET SELLER BY ID
  // ============================================================

  async getSellerById(id: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');
    return this.toSellerResponse(seller);
  }

  // ============================================================
  // GET SELLER BY EMAIL
  // ============================================================

  async getSellerByEmail(email: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findByEmail(email);
    if (!seller) throw new NotFoundError('Seller not found');
    return this.toSellerResponse(seller);
  }

  // ============================================================
  // GET SELLER BY PHONE
  // ============================================================

  async getSellerByPhone(phone: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findByPhone(phone);
    if (!seller) throw new NotFoundError('Seller not found');
    return this.toSellerResponse(seller);
  }

  // ============================================================
  // CREATE SELLER (Admin)
  // ============================================================

  async createSeller(data: CreateSellerDTO, adminId: string, ip?: string): Promise<SellerResponse> {
    // Check if email already exists
    const emailExists = await sellerRepository.emailExists(data.email);
    if (emailExists) {
      throw new ConflictError('A seller with this email already exists', [
        { field: 'email', message: 'Email already in use' },
      ]);
    }

    // Check if phone already exists
    const phoneExists = await sellerRepository.phoneExists(data.phone);
    if (phoneExists) {
      throw new ConflictError('A seller with this phone already exists', [
        { field: 'phone', message: 'Phone already in use' },
      ]);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password, 12);

    // Create seller
    const seller = await sellerRepository.create({
      ...data,
      password: hashedPassword,
    });

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.created_by_admin',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        email: seller.email,
        firstName: seller.firstName,
        lastName: seller.lastName,
        businessName: seller.businessName,
      },
      ip,
    });

    // Notification
    eventEmitter.emit('notification', {
      userId: seller.id,
      title: '🎉 Welcome as a Seller!',
      body: `Your seller account has been created by admin. Please check your email to set up your password.`,
      type: 'system',
      data: { type: 'seller_created' },
    });

    logger.info(`Seller created by admin ${adminId}: ${seller.email}`);

    return this.toSellerResponse(seller);
  }

  // ============================================================
  // UPDATE SELLER (Admin)
  // ============================================================

  async updateSeller(id: string, data: UpdateSellerDTO, adminId: string, ip?: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    // Check email uniqueness if being changed
    if (data.email && data.email !== seller.email) {
      const emailExists = await sellerRepository.emailExists(data.email, id);
      if (emailExists) {
        throw new ConflictError('A seller with this email already exists', [
          { field: 'email', message: 'Email already in use' },
        ]);
      }
    }

    // Check phone uniqueness if being changed
    if (data.phone && data.phone !== seller.phone) {
      const phoneExists = await sellerRepository.phoneExists(data.phone, id);
      if (phoneExists) {
        throw new ConflictError('A seller with this phone already exists', [
          { field: 'phone', message: 'Phone already in use' },
        ]);
      }
    }

    const updated = await sellerRepository.update(id, data);

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.updated_by_admin',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        changedFields: Object.keys(data),
        email: updated.email,
      },
      ip,
    });

    logger.info(`Seller updated by admin ${adminId}: ${updated.email}`);

    return this.toSellerResponse(updated);
  }

  // ============================================================
  // VERIFY SELLER
  // ============================================================

  async verifySeller(id: string, adminId: string, ip?: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    if (seller.isVerified) {
      throw new BadRequestError('Seller is already verified');
    }

    const updated = await sellerRepository.verify(id);

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.verified',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        email: seller.email,
        businessName: seller.businessName,
      },
      ip,
    });

    // Notification
    eventEmitter.emit('notification', {
      userId: seller.id,
      title: '✅ Seller Account Verified',
      body: 'Your seller account has been verified. You can now start selling products.',
      type: 'system',
      data: { type: 'seller_verified' },
    });

    logger.info(`Seller verified by admin ${adminId}: ${seller.email}`);

    return this.toSellerResponse(updated);
  }

  // ============================================================
  // REJECT SELLER
  // ============================================================

    async rejectSeller(id: string, reason: string, adminId: string, ip?: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    if (seller.status === 'BANNED') {
        throw new BadRequestError('Seller is already banned/rejected');
    }

    if (seller.isVerified) {
        throw new BadRequestError('Cannot reject a verified seller. Suspend them instead.');
    }

    const updated = await sellerRepository.reject(id, reason);

    // Audit log
    eventEmitter.emit('audit', {
        action: 'seller.rejected',
        entity: 'Seller',
        entityId: seller.id,
        performedBy: adminId,
        details: {
        email: seller.email,
        reason,
        },
        ip,
    });

    // Notification
    eventEmitter.emit('notification', {
        userId: seller.id,
        title: '❌ Seller Account Rejected',
        body: `Your seller application has been rejected. Reason: ${reason}`,
        type: 'system',
        data: { type: 'seller_rejected' },
    });

    logger.info(`Seller rejected by admin ${adminId}: ${seller.email} - Reason: ${reason}`);

    return this.toSellerResponse(updated);
    }

  // ============================================================
  // SUSPEND SELLER
  // ============================================================

  async suspendSeller(id: string, data: SuspendSellerDTO, adminId: string, ip?: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    if (seller.isSuspended) {
      throw new BadRequestError('Seller is already suspended');
    }

    const updated = await sellerRepository.suspend(id, data.reason);

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.suspended',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        email: seller.email,
        reason: data.reason,
      },
      ip,
    });

    // Notification
    eventEmitter.emit('notification', {
      userId: seller.id,
      title: '⛔ Seller Account Suspended',
      body: `Your seller account has been suspended. Reason: ${data.reason}`,
      type: 'system',
      data: { type: 'seller_suspended' },
    });

    logger.info(`Seller suspended by admin ${adminId}: ${seller.email} - Reason: ${data.reason}`);

    return this.toSellerResponse(updated);
  }

  // ============================================================
  // UNSUSPEND SELLER
  // ============================================================

  async unsuspendSeller(id: string, adminId: string, ip?: string): Promise<SellerResponse> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    if (!seller.isSuspended) {
      throw new BadRequestError('Seller is not suspended');
    }

    const updated = await sellerRepository.unsuspend(id);

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.unsuspended',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        email: seller.email,
      },
      ip,
    });

    // Notification
    eventEmitter.emit('notification', {
      userId: seller.id,
      title: '✅ Seller Account Reinstated',
      body: 'Your seller account has been reinstated. You can now sell products again.',
      type: 'system',
      data: { type: 'seller_unsuspended' },
    });

    logger.info(`Seller unsuspended by admin ${adminId}: ${seller.email}`);

    return this.toSellerResponse(updated);
  }

  // ============================================================
  // DELETE SELLER (Hard delete - admin only)
  // ============================================================

  async deleteSeller(id: string, adminId: string, ip?: string): Promise<void> {
    const seller = await sellerRepository.findById(id);
    if (!seller) throw new NotFoundError('Seller not found');

    // Check if seller has active orders
    if (seller.orders && seller.orders.some((o: any) => o.status !== 'CANCELLED' && o.status !== 'RETURNED')) {
      throw new BadRequestError('Cannot delete seller with active orders. Cancel or complete all orders first.');
    }

    // Check if seller has active products
    if (seller.products && seller.products.some((p: any) => p.status === 'ACTIVE')) {
      throw new BadRequestError('Cannot delete seller with active products. Deactivate all products first.');
    }

    // Audit log
    eventEmitter.emit('audit', {
      action: 'seller.deleted',
      entity: 'Seller',
      entityId: seller.id,
      performedBy: adminId,
      details: {
        email: seller.email,
        businessName: seller.businessName,
      },
      ip,
    });

    await sellerRepository.delete(id);

    logger.info(`Seller deleted by admin ${adminId}: ${seller.email}`);
  }

  // ============================================================
  // GET SELLER STATS
  // ============================================================

  async getSellerStats(): Promise<{
    total: number;
    pending: number;
    active: number;
    suspended: number;
    banned: number;
  }> {
    return sellerRepository.getStats();
  }

  // ============================================================
  // GET PENDING SELLERS
  // ============================================================

  async getPendingSellers(limit: number = 10): Promise<SellerResponse[]> {
    const sellers = await sellerRepository.getRecent(limit);
    return sellers.map((s: any) => this.toSellerResponse(s));
  }
}

export const sellerService = new SellerService();

