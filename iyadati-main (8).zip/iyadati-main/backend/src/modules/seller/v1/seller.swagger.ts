/**
 * @swagger
 * tags:
 *   name: Seller Management
 *   description: Admin management of seller accounts
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     SellerResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         email:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         businessName:
 *           type: string
 *           nullable: true
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *         taxNumber:
 *           type: string
 *           nullable: true
 *         registrationNumber:
 *           type: string
 *           nullable: true
 *         wilayaId:
 *           type: string
 *         wilaya:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             code:
 *               type: integer
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         baladyaId:
 *           type: string
 *           nullable: true
 *         baladya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         address:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [PENDING, ACTIVE, SUSPENDED, BANNED]
 *         isVerified:
 *           type: boolean
 *         isSuspended:
 *           type: boolean
 *         suspensionReason:
 *           type: string
 *           nullable: true
 *         verifiedBy:
 *           type: string
 *           nullable: true
 *         verifiedAt:
 *           type: string
 *           nullable: true
 *         rejectionReason:
 *           type: string
 *           nullable: true
 *         avgRating:
 *           type: number
 *           nullable: true
 *         totalReviews:
 *           type: integer
 *         productCount:
 *           type: integer
 *         orderCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     CreateSellerRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstName
 *         - lastName
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *         password:
 *           type: string
 *           minLength: 6
 *         firstName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         lastName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *         wilayaId:
 *           type: string
 *           format: uuid
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         businessName:
 *           type: string
 *           nullable: true
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *         taxNumber:
 *           type: string
 *           nullable: true
 *         registrationNumber:
 *           type: string
 *           nullable: true
 *         address:
 *           type: string
 *           nullable: true
 *     UpdateSellerRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         email:
 *           type: string
 *         businessName:
 *           type: string
 *           nullable: true
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *         taxNumber:
 *           type: string
 *           nullable: true
 *         registrationNumber:
 *           type: string
 *           nullable: true
 *         wilayaId:
 *           type: string
 *         baladyaId:
 *           type: string
 *           nullable: true
 *         address:
 *           type: string
 *           nullable: true
 *         isVerified:
 *           type: boolean
 *         isSuspended:
 *           type: boolean
 *         suspensionReason:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [PENDING, ACTIVE, SUSPENDED, BANNED]
 *     SuspendSellerRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500
 *     RejectSellerRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500
 *     SellerStatsResponse:
 *       type: object
 *       properties:
 *         total:
 *           type: integer
 *         pending:
 *           type: integer
 *         active:
 *           type: integer
 *         suspended:
 *           type: integer
 *         banned:
 *           type: integer
 */

// ============================================================
// GET ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/seller/v1:
 *   get:
 *     summary: Get all sellers (Admin)
 *     description: |
 *       Returns paginated list of all sellers with filtering options.
 *       Use this for admin seller management dashboard.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, ACTIVE, SUSPENDED, BANNED]
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by name, email, phone, or business name
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, firstName, lastName, email, status]
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *     responses:
 *       200:
 *         description: Sellers retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SellerResponse'
 *                 meta:
 *                   type: object
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/stats:
 *   get:
 *     summary: Get seller statistics (Admin)
 *     description: Returns counts of sellers by status for admin dashboard
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerStatsResponse'
 *             example:
 *               success: true
 *               data:
 *                 total: 150
 *                 pending: 12
 *                 active: 120
 *                 suspended: 15
 *                 banned: 3
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/pending:
 *   get:
 *     summary: Get pending sellers (Admin)
 *     description: Returns sellers with PENDING status for quick review
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Pending sellers retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SellerResponse'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/id/{id}:
 *   get:
 *     summary: Get seller by ID (Admin)
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Seller retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/email/{email}:
 *   get:
 *     summary: Get seller by email (Admin)
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: email
 *         required: true
 *         schema:
 *           type: string
 *           format: email
 *     responses:
 *       200:
 *         description: Seller retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/phone/{phone}:
 *   get:
 *     summary: Get seller by phone (Admin)
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: phone
 *         required: true
 *         schema:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *     responses:
 *       200:
 *         description: Seller retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

// ============================================================
// POST ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/seller/v1:
 *   post:
 *     summary: Create a seller (Admin)
 *     description: |
 *       Creates a new seller account. The seller will receive a notification.
 *       Password should be set by the seller via the set-password flow.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateSellerRequest'
 *     responses:
 *       201:
 *         description: Seller created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Validation failed
 *       409:
 *         description: Email or phone already exists
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

// ============================================================
// PATCH ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/seller/v1/{id}:
 *   patch:
 *     summary: Update a seller (Admin)
 *     description: Update any field of a seller account
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateSellerRequest'
 *     responses:
 *       200:
 *         description: Seller updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Validation failed
 *       404:
 *         description: Seller not found
 *       409:
 *         description: Email or phone already exists
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/{id}/verify:
 *   patch:
 *     summary: Verify a seller (Admin)
 *     description: Mark a seller as verified. Notifies the seller.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Seller verified
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Seller is already verified
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/{id}/reject:
 *   patch:
 *     summary: Reject a seller (Admin)
 *     description: |
 *       Reject a seller application with a reason.
 *       Can only reject sellers with PENDING status.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RejectSellerRequest'
 *     responses:
 *       200:
 *         description: Seller rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Seller cannot be rejected (already verified or not pending)
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/{id}/suspend:
 *   patch:
 *     summary: Suspend a seller (Admin)
 *     description: |
 *       Temporarily block a seller from selling.
 *       The seller will be notified with the reason.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SuspendSellerRequest'
 *     responses:
 *       200:
 *         description: Seller suspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Seller is already suspended
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/seller/v1/{id}/unsuspend:
 *   patch:
 *     summary: Unsuspend a seller (Admin)
 *     description: Reinstate a suspended seller. Notifies the seller.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Seller unsuspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Seller is not suspended
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

// ============================================================
// DELETE ROUTES
// ============================================================

/**
 * @swagger
 * /api/v1/seller/v1/{id}:
 *   delete:
 *     summary: Delete a seller (Admin)
 *     description: |
 *       ⚠️ WARNING: Hard delete - cannot be undone!
 *       Only allowed if seller has no active orders or active products.
 *     tags: [Seller Management]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Seller deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                   example: "Seller deleted successfully"
 *       400:
 *         description: Cannot delete - has active orders or products
 *       404:
 *         description: Seller not found
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */