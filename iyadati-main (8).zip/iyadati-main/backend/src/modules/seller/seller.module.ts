import { Router } from 'express';
import sellerRoutes from './v1/seller.routes';
import './v1/seller.swagger';

const router = Router();
router.use('/v1', sellerRoutes);

export { router as sellerModule };

