// src/modules/ecommerce/v1/ecommerce.types.ts

import { OrderStatus, ProductStatus, OrderPaymentMethod, PaymentStatus, SellerStatus } from '@prisma/client';

// ============================================================
// Category
// ============================================================

export interface CreateCategoryDTO {
  nameFr: string;
  nameAr: string;
  slug: string;
  descriptionFr?: string;
  descriptionAr?: string;
  imagePath?: string;
  parentId?: string;
  sortOrder?: number;
}

export interface UpdateCategoryDTO {
  nameFr?: string;
  nameAr?: string;
  slug?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  imagePath?: string;
  parentId?: string | null;
  sortOrder?: number;
  isActive?: boolean;
}

export interface CategoryResponse {
  id: string;
  nameFr: string;
  nameAr: string;
  slug: string;
  descriptionFr: string | null;
  descriptionAr: string | null;
  imagePath: string | null;
  parentId: string | null;
  parent?: { id: string; nameFr: string; nameAr: string; slug: string } | null;
  children?: CategoryResponse[];
  sortOrder: number;
  isActive: boolean;
  productCount?: number;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// Product
// ============================================================

export interface CreateProductDTO {
  categoryId: string;
  titleFr: string;
  titleAr: string;
  descriptionFr?: string;
  descriptionAr?: string;
  price: number;
  comparePrice?: number;
  stock: number;
  sku?: string;
}

export interface UpdateProductDTO {
  titleFr?: string;
  titleAr?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  price?: number;
  comparePrice?: number | null;
  stock?: number;
  sku?: string;
  status?: ProductStatus;
  categoryId?: string;
}

export interface ProductFilters {
  sellerId?: string;
  categoryId?: string;
  status?: ProductStatus;
  isApproved?: boolean;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface ProductResponse {
  id: string;
  sellerId: string;
  seller?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    businessName?: string;
    wilaya?: { id: string; nameFr: string; nameAr: string };
  };
  categoryId: string;
  category?: {
    id: string;
    nameFr: string;
    nameAr: string;
    slug: string;
    parent?: { id: string; nameFr: string; nameAr: string; slug: string } | null;
  };
  titleFr: string;
  titleAr: string;
  descriptionFr: string | null;
  descriptionAr: string | null;
  price: number;
  comparePrice: number | null;
  stock: number;
  sku: string | null;
  status: ProductStatus;
  isApproved: boolean;
  approvedBy: string | null;
  approvedAt: string | null;
  viewCount: number;
  saleCount: number;
  images: ProductImageResponse[];
  orderCount?: number;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// Product Image
// ============================================================

export interface ProductImageResponse {
  id: string;
  productId: string;
  fileId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  isPrimary: boolean;
  sortOrder: number;
  accessUrl: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// Shipping Company
// ============================================================

export interface CreateShippingCompanyDTO {
  name: string;
  trackingUrl?: string;
  logoPath?: string;
}

export interface UpdateShippingCompanyDTO {
  name?: string;
  trackingUrl?: string;
  logoPath?: string;
  isActive?: boolean;
}

export interface ShippingCompanyResponse {
  id: string;
  name: string;
  trackingUrl: string | null;
  logoPath: string | null;
  isActive: boolean;
  orderCount?: number;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// Order
// ============================================================

export interface CreateOrderDTO {
  shippingCompanyId?: string;
  shippingCost?: number;
  notes?: string;
  paymentMethod: OrderPaymentMethod;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
}

export interface OrderFilters {
  buyerId?: string;
  sellerId?: string;
  status?: OrderStatus;
  paymentStatus?: PaymentStatus;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface OrderResponse {
  id: string;
  buyerId: string;
  buyer?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  sellerId: string;
  seller?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    businessName?: string;
  };
  status: OrderStatus;
  paymentMethod: OrderPaymentMethod;
  paymentStatus: string;
  chargilyId: string | null;
  shippingCompanyId: string | null;
  shippingCompany?: {
    id: string;
    name: string;
    trackingUrl: string | null;
  } | null;
  trackingNumber: string | null;
  subtotal: number;
  shippingCost: number;
  totalAmount: number;
  notes: string | null;
  sellerNotes: string | null;
  cancelledAt: string | null;
  cancelledBy: string | null;
  cancelReason: string | null;
  deliveredAt: string | null;
  items: OrderItemResponse[];
  statusHistory: OrderStatusHistoryResponse[];
  createdAt: string;
  updatedAt: string;
}

export interface OrderItemResponse {
  id: string;
  orderId: string;
  productId: string;
  product?: {
    id: string;
    titleFr: string;
    titleAr: string;
    images?: { fileId: string; accessUrl: string }[];
  };
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface OrderStatusHistoryResponse {
  id: string;
  orderId: string;
  status: OrderStatus;
  notes: string | null;
  changedBy: string;
  createdAt: string;
}

export interface UpdateOrderStatusDTO {
  status: OrderStatus;
  notes?: string;
}

export interface UpdateTrackingDTO {
  shippingCompanyId: string;
  trackingNumber: string;
}

export interface CancelOrderDTO {
  reason: string;
}

// ============================================================
// Seller Document
// ============================================================

export interface SellerDocumentResponse {
  id: string;
  sellerId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  docType: string;
  status: string;
  verifiedBy: string | null;
  verifiedAt: string | null;
  rejectionReason: string | null;
  accessUrl: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// Seller Management
// ============================================================

export interface ToggleSellerStatusDTO {
  status: SellerStatus;
}

export interface SellerResponse {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  businessName: string | null;
  businessType: string;
  taxNumber: string | null;
  registrationNumber: string | null;
  wilayaId: string;
  baladyaId: string | null;
  address: string | null;
  status: SellerStatus;
  isVerified: boolean;
  isSuspended: boolean;
  suspensionReason: string | null;
  verifiedBy: string | null;
  verifiedAt: string | null;
  rejectionReason: string | null;
  avgRating: number | null;
  totalReviews: number;
  productCount?: number;
  orderCount?: number;
  createdAt: string;
  updatedAt: string;
}

