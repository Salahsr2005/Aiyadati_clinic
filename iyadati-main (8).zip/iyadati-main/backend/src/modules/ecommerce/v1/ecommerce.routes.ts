// src/modules/ecommerce/v1/ecommerce.routes.ts

import { Router } from 'express';
import { EcommerceController } from './ecommerce.controller';
import {
  validateCreateCategory,
  validateUpdateCategory,
  validateCreateProduct,
  validateUpdateProduct,
  validateCreateShippingCompany,
  validateUpdateShippingCompany,
  validateCreateOrder,
  validateUpdateOrderStatus,
  validateUpdateTracking,
  validateCancelOrder,
  validateToggleSellerStatus,
} from './ecommerce.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import { uploadProductImage, uploadSellerDocument } from '../../../core/middleware/upload.middleware';

const router = Router();
const controller = new EcommerceController();

// ============================================================
// PUBLIC ROUTES (No authentication required)
// ============================================================

// Categories (public read)
router.get('/categories', controller.getCategories);
router.get('/categories/tree', controller.getCategoryTree);
router.get('/categories/slug/:slug', controller.getCategoryBySlug);
router.get('/categories/:id', controller.getCategoryById);

// Products (public read)
router.get('/products', controller.getProducts);
router.get('/products/:id', controller.getProductById);

// Shipping companies (public read)
router.get('/shipping-companies', controller.getShippingCompanies);

// ============================================================
// ADMIN ROUTES (Category & Shipping Management)
// ============================================================

// Categories (admin write)
router.post(
  '/categories',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateCategory,
  controller.createCategory
);

router.patch(
  '/categories/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateCategory,
  controller.updateCategory
);

router.delete(
  '/categories/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.deleteCategory
);

// Shipping companies (admin write)
router.post(
  '/shipping-companies',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateShippingCompany,
  controller.createShippingCompany
);

router.patch(
  '/shipping-companies/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateShippingCompany,
  controller.updateShippingCompany
);

router.delete(
  '/shipping-companies/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.deleteShippingCompany
);

// ============================================================
// SELLER ROUTES (Product Management) - authorize('SELLER')
// ============================================================

router.get(
  '/my/products',
  authenticate,
  authorize('SELLER'),
  controller.getMyProducts
);

router.post(
  '/products',
  authenticate,
  authorize('SELLER'),
  validateCreateProduct,
  controller.createProduct
);

router.patch(
  '/products/:id',
  authenticate,
  authorize('SELLER'),
  validateUpdateProduct,
  controller.updateProduct
);

router.delete(
  '/products/:id',
  authenticate,
  authorize('SELLER'),
  controller.deleteProduct
);

// Product Images
router.post(
  '/products/:id/images',
  authenticate,
  authorize('SELLER'),
  uploadProductImage,
  controller.uploadProductImage
);

router.delete(
  '/products/:id/images/:imageId',
  authenticate,
  authorize('SELLER'),
  controller.deleteProductImage
);

router.patch(
  '/products/:id/images/:imageId/primary',
  authenticate,
  authorize('SELLER'),
  controller.setPrimaryImage
);

// ============================================================
// ADMIN ROUTES (Product Approval)
// ============================================================

router.patch(
  '/products/:id/approve',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.approveProduct
);

router.patch(
  '/products/:id/reject',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.rejectProduct
);

// ============================================================
// BUYER ROUTES (Orders) - authorize('USER') for regular customers
// ============================================================

router.get(
  '/my/orders',
  authenticate,
  authorize('USER'),
  controller.getMyOrders
);

router.post(
  '/orders',
  authenticate,
  authorize('USER'),
  createRateLimiter({ windowMinutes: 1, maxRequests: 10, message: 'Too many orders' }),
  validateCreateOrder,
  controller.createOrder
);

router.get(
  '/orders/:id',
  authenticate,
  authorize('USER'),
  controller.getOrderById
);

router.post(
  '/orders/:id/cancel',
  authenticate,
  authorize('USER'),
  validateCancelOrder,
  controller.cancelOrder
);

// ============================================================
// SELLER ROUTES (Order Management) - authorize('SELLER')
// ============================================================

router.get(
  '/my/sales',
  authenticate,
  authorize('SELLER'),
  controller.getMySales
);

router.patch(
  '/orders/:id/status',
  authenticate,
  authorize('SELLER'),
  validateUpdateOrderStatus,
  controller.updateOrderStatus
);

router.patch(
  '/orders/:id/tracking',
  authenticate,
  authorize('SELLER'),
  validateUpdateTracking,
  controller.updateTracking
);

router.get(
  '/my/stats',
  authenticate,
  authorize('SELLER'),
  controller.getSellerStats
);

// ============================================================
// SELLER PROFILE (Self-service)
// ============================================================

router.get(
  '/my/profile',
  authenticate,
  authorize('SELLER'),
  controller.getMyProfile
);

router.patch(
  '/my/profile',
  authenticate,
  authorize('SELLER'),
  controller.updateMyProfile
);

// ============================================================
// ADMIN ROUTES (Orders)
// ============================================================

router.get(
  '/admin/orders',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getOrders
);

// ============================================================
// SELLER DOCUMENTS - authorize('SELLER')
// ============================================================

router.get(
  '/seller/documents',
  authenticate,
  authorize('SELLER'),
  controller.getSellerDocuments
);

router.post(
  '/seller/documents',
  authenticate,
  authorize('SELLER'),
  uploadSellerDocument,
  controller.uploadSellerDocument
);

router.delete(
  '/seller/documents/:id',
  authenticate,
  authorize('SELLER'),
  controller.deleteSellerDocument
);

// Admin: Verify documents
router.patch(
  '/seller/documents/:id/verify',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.verifySellerDocument
);

// Admin: Reject documents
router.patch(
  '/seller/documents/:id/reject',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.rejectSellerDocument
);

// ============================================================
// SELLER MANAGEMENT (Admin only)
// ============================================================

router.get(
  '/admin/sellers',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getAllSellers
);

router.get(
  '/admin/sellers/stats',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getSellerStatsAdmin
);

router.get(
  '/admin/sellers/:sellerId',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getSellerById
);

// Admin: Update seller status - with validation
router.patch(
  '/admin/sellers/:sellerId/status',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateToggleSellerStatus, // ✅ Added validation
  controller.toggleSellerStatus
);

// Admin: Reset seller password
router.post(
  '/admin/sellers/:sellerId/reset-password',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.resetSellerPassword
);

// ============================================================
// LEGACY: Admin toggle user selling permission (deprecated)
// ============================================================

router.patch(
  '/users/:userId/can-post',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.toggleCanPost
);

export default router;

