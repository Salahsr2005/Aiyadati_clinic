// src/modules/ecommerce/v1/ecommerce.swagger.ts

/**
 * @swagger
 * tags:
 *   name: E-Commerce
 *   description: Full e-commerce system - Categories, Products, Orders, Shipping, Seller Management
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     # ============================================================
 *     # CATEGORY SCHEMAS
 *     # ============================================================
 *     CategoryResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         nameFr:
 *           type: string
 *           example: "Électronique"
 *         nameAr:
 *           type: string
 *           example: "إلكترونيات"
 *         slug:
 *           type: string
 *           example: "electronique"
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         imagePath:
 *           type: string
 *           nullable: true
 *         parentId:
 *           type: string
 *           nullable: true
 *         parent:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             slug:
 *               type: string
 *         children:
 *           type: array
 *           nullable: true
 *           items:
 *             type: object
 *         sortOrder:
 *           type: integer
 *         isActive:
 *           type: boolean
 *         productCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     CreateCategoryRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *         - slug
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         slug:
 *           type: string
 *           pattern: '^[a-z0-9-]+$'
 *           example: "smartphones"
 *         descriptionFr:
 *           type: string
 *           maxLength: 500
 *         descriptionAr:
 *           type: string
 *           maxLength: 500
 *         parentId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *     
 *     UpdateCategoryRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         nameFr:
 *           type: string
 *         nameAr:
 *           type: string
 *         slug:
 *           type: string
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         parentId:
 *           type: string
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *         isActive:
 *           type: boolean

 *     # ============================================================
 *     # PRODUCT SCHEMAS
 *     # ============================================================
 *     ProductResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         sellerId:
 *           type: string
 *         seller:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             email:
 *               type: string
 *             phone:
 *               type: string
 *             businessName:
 *               type: string
 *               nullable: true
 *             wilaya:
 *               type: object
 *         categoryId:
 *           type: string
 *         category:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             slug:
 *               type: string
 *             parent:
 *               type: object
 *               nullable: true
 *         titleFr:
 *           type: string
 *           example: "iPhone 15 Pro"
 *         titleAr:
 *           type: string
 *           example: "ايفون 15 برو"
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         price:
 *           type: number
 *           example: 150000
 *         comparePrice:
 *           type: number
 *           nullable: true
 *           example: 180000
 *         stock:
 *           type: integer
 *           example: 50
 *         sku:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [ACTIVE, INACTIVE, OUT_OF_STOCK]
 *         isApproved:
 *           type: boolean
 *         approvedBy:
 *           type: string
 *           nullable: true
 *         approvedAt:
 *           type: string
 *           nullable: true
 *         viewCount:
 *           type: integer
 *         saleCount:
 *           type: integer
 *         images:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ProductImageResponse'
 *         orderCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     ProductImageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         productId:
 *           type: string
 *         fileId:
 *           type: string
 *           description: UUID used for secure file access
 *         fileName:
 *           type: string
 *         fileType:
 *           type: string
 *         fileSize:
 *           type: integer
 *         isPrimary:
 *           type: boolean
 *         sortOrder:
 *           type: integer
 *         accessUrl:
 *           type: string
 *           description: Public URL for the product image
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     CreateProductRequest:
 *       type: object
 *       required:
 *         - categoryId
 *         - titleFr
 *         - titleAr
 *         - price
 *       properties:
 *         categoryId:
 *           type: string
 *           format: uuid
 *         titleFr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *         titleAr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *         descriptionFr:
 *           type: string
 *           maxLength: 5000
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           maxLength: 5000
 *           nullable: true
 *         price:
 *           type: number
 *           minimum: 0
 *           example: 150000
 *         comparePrice:
 *           type: number
 *           minimum: 0
 *           nullable: true
 *           example: 180000
 *         stock:
 *           type: integer
 *           minimum: 0
 *           default: 0
 *         sku:
 *           type: string
 *           maxLength: 50
 *           nullable: true
 *     
 *     UpdateProductRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         titleFr:
 *           type: string
 *         titleAr:
 *           type: string
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         price:
 *           type: number
 *         comparePrice:
 *           type: number
 *           nullable: true
 *         stock:
 *           type: integer
 *         sku:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [ACTIVE, INACTIVE, OUT_OF_STOCK]
 *         categoryId:
 *           type: string

 *     # ============================================================
 *     # SHIPPING COMPANY SCHEMAS
 *     # ============================================================
 *     ShippingCompanyResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         name:
 *           type: string
 *           example: "Yalidine"
 *         trackingUrl:
 *           type: string
 *           nullable: true
 *           example: "https://yalidine.com/track/{tracking_number}"
 *         logoPath:
 *           type: string
 *           nullable: true
 *         isActive:
 *           type: boolean
 *         orderCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     CreateShippingCompanyRequest:
 *       type: object
 *       required:
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         trackingUrl:
 *           type: string
 *           format: uri
 *           nullable: true
 *         logoPath:
 *           type: string
 *           nullable: true
 *     
 *     UpdateShippingCompanyRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         name:
 *           type: string
 *         trackingUrl:
 *           type: string
 *           nullable: true
 *         logoPath:
 *           type: string
 *           nullable: true
 *         isActive:
 *           type: boolean

 *     # ============================================================
 *     # ORDER SCHEMAS
 *     # ============================================================
 *     OrderResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         buyerId:
 *           type: string
 *         buyer:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             email:
 *               type: string
 *             phone:
 *               type: string
 *         sellerId:
 *           type: string
 *         seller:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             email:
 *               type: string
 *             businessName:
 *               type: string
 *               nullable: true
 *         status:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *         paymentMethod:
 *           type: string
 *           enum: [CHARGILY, CASH_ON_DELIVERY]
 *         paymentStatus:
 *           type: string
 *           enum: [PENDING, PAID, FAILED, EXPIRED]
 *         chargilyId:
 *           type: string
 *           nullable: true
 *         shippingCompanyId:
 *           type: string
 *           nullable: true
 *         shippingCompany:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             name:
 *               type: string
 *             trackingUrl:
 *               type: string
 *               nullable: true
 *         trackingNumber:
 *           type: string
 *           nullable: true
 *         subtotal:
 *           type: number
 *         shippingCost:
 *           type: number
 *         totalAmount:
 *           type: number
 *         notes:
 *           type: string
 *           nullable: true
 *         sellerNotes:
 *           type: string
 *           nullable: true
 *         cancelledAt:
 *           type: string
 *           nullable: true
 *         cancelledBy:
 *           type: string
 *           nullable: true
 *         cancelReason:
 *           type: string
 *           nullable: true
 *         deliveredAt:
 *           type: string
 *           nullable: true
 *         items:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/OrderItemResponse'
 *         statusHistory:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/OrderStatusHistoryResponse'
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     OrderItemResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         orderId:
 *           type: string
 *         productId:
 *           type: string
 *         product:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             titleFr:
 *               type: string
 *             titleAr:
 *               type: string
 *             images:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   fileId:
 *                     type: string
 *                   accessUrl:
 *                     type: string
 *         quantity:
 *           type: integer
 *         unitPrice:
 *           type: number
 *         totalPrice:
 *           type: number
 *     
 *     OrderStatusHistoryResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         orderId:
 *           type: string
 *         status:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *         notes:
 *           type: string
 *           nullable: true
 *         changedBy:
 *           type: string
 *         createdAt:
 *           type: string
 *     
 *     CreateOrderRequest:
 *       type: object
 *       required:
 *         - paymentMethod
 *         - items
 *       properties:
 *         shippingCompanyId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         shippingCost:
 *           type: number
 *           minimum: 0
 *           default: 0
 *         notes:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         paymentMethod:
 *           type: string
 *           enum: [CHARGILY, CASH_ON_DELIVERY]
 *           example: "CASH_ON_DELIVERY"
 *         items:
 *           type: array
 *           minItems: 1
 *           items:
 *             type: object
 *             required:
 *               - productId
 *               - quantity
 *             properties:
 *               productId:
 *                 type: string
 *                 format: uuid
 *               quantity:
 *                 type: integer
 *                 minimum: 1
 *           example:
 *             - productId: "550e8400-e29b-41d4-a716-446655440000"
 *               quantity: 2
 *     
 *     UpdateOrderStatusRequest:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *         notes:
 *           type: string
 *           maxLength: 500
 *     
 *     UpdateTrackingRequest:
 *       type: object
 *       required:
 *         - shippingCompanyId
 *         - trackingNumber
 *       properties:
 *         shippingCompanyId:
 *           type: string
 *           format: uuid
 *         trackingNumber:
 *           type: string
 *           maxLength: 100
 *     
 *     CancelOrderRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500

 *     # ============================================================
 *     # SELLER DOCUMENT SCHEMAS
 *     # ============================================================
 *     SellerDocumentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         sellerId:
 *           type: string
 *         fileName:
 *           type: string
 *         fileType:
 *           type: string
 *         fileSize:
 *           type: integer
 *         docType:
 *           type: string
 *           example: "LICENSE"
 *         status:
 *           type: string
 *           enum: [PENDING, APPROVED, REJECTED]
 *         verifiedBy:
 *           type: string
 *           nullable: true
 *         verifiedAt:
 *           type: string
 *           nullable: true
 *         rejectionReason:
 *           type: string
 *           nullable: true
 *         accessUrl:
 *           type: string
 *           description: Signed URL for private document access (expires in 30 minutes)
 *           example: "http://localhost:3975/api/v1/files/private/550e8400-e29b-41d4-a716-446655440000?expires=1784569353394&signature=abc123..."
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string

 *     # ============================================================
 *     # SELLER MANAGEMENT SCHEMAS
 *     # ============================================================
 *     SellerResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         email:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         phone:
 *           type: string
 *         businessName:
 *           type: string
 *           nullable: true
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *         taxNumber:
 *           type: string
 *           nullable: true
 *         registrationNumber:
 *           type: string
 *           nullable: true
 *         wilayaId:
 *           type: string
 *         baladyaId:
 *           type: string
 *           nullable: true
 *         address:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [PENDING, ACTIVE, SUSPENDED, BANNED]
 *         isVerified:
 *           type: boolean
 *         isSuspended:
 *           type: boolean
 *         suspensionReason:
 *           type: string
 *           nullable: true
 *         verifiedBy:
 *           type: string
 *           nullable: true
 *         verifiedAt:
 *           type: string
 *           nullable: true
 *         rejectionReason:
 *           type: string
 *           nullable: true
 *         avgRating:
 *           type: number
 *           nullable: true
 *         totalReviews:
 *           type: integer
 *         productCount:
 *           type: integer
 *         orderCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     ToggleSellerStatusRequest:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: [ACTIVE, SUSPENDED, BANNED]
 *           description: New status for the seller account
 *           example: "ACTIVE"
 *     
 *     ResetPasswordRequest:
 *       type: object
 *       description: No body required - password reset is triggered by the endpoint
 *     
 *     ResetPasswordResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Password reset link sent to seller email
 *     
 *     SellerStatsResponse:
 *       type: object
 *       properties:
 *         total:
 *           type: integer
 *         pending:
 *           type: integer
 *         active:
 *           type: integer
 *         suspended:
 *           type: integer
 *         banned:
 *           type: integer

 *     # ============================================================
 *     # SELLER PROFILE SCHEMAS (Self-service)
 *     # ============================================================
 *     UpdateSellerProfileRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         firstName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Updated first name
 *         lastName:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Updated last name
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Updated phone number (10 digits)
 *         businessName:
 *           type: string
 *           maxLength: 100
 *           description: Updated business name
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *           description: Updated business type
 *         taxNumber:
 *           type: string
 *           description: Updated tax number (NIF)
 *         registrationNumber:
 *           type: string
 *           description: Updated commercial registration number (RC)
 *         address:
 *           type: string
 *           description: Updated business address
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Updated baladya (municipality) ID

 *     # ============================================================
 *     # LEGACY SCHEMAS (deprecated)
 *     # ============================================================
 *     ToggleCanPostRequest:
 *       type: object
 *       required:
 *         - canPost
 *       properties:
 *         canPost:
 *           type: boolean
 *           description: Enable/disable user's ability to sell products (deprecated - use seller status instead)
 */

// ============================================================
// CATEGORY ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/categories:
 *   get:
 *     summary: Get all categories (Public)
 *     description: |
 *       Returns paginated list of categories. No authentication required.
 *       Supports filtering by parent (null = root categories) and search.
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: query
 *         name: parentId
 *         schema:
 *           type: string
 *         description: Filter by parent category ID (null for root, specific ID for subcategories)
 *       - in: query
 *         name: isActive
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by French or Arabic name
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 50
 *     responses:
 *       200:
 *         description: Categories retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CategoryResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Create a category (Admin)
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateCategoryRequest'
 *     responses:
 *       201:
 *         description: Category created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/CategoryResponse'
 *       400:
 *         description: Slug already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/categories/tree:
 *   get:
 *     summary: Get full category tree (Public)
 *     description: Returns nested category tree structure (up to 4 levels deep)
 *     tags: [E-Commerce]
 *     responses:
 *       200:
 *         description: Category tree retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CategoryResponse'
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/categories/slug/{slug}:
 *   get:
 *     summary: Get category by slug (Public)
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *         example: "smartphones"
 *     responses:
 *       200:
 *         description: Category retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/CategoryResponse'
 *       404:
 *         description: Category not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/categories/{id}:
 *   get:
 *     summary: Get category by ID (Public)
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Category retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/CategoryResponse'
 *       404:
 *         description: Category not found
 *   patch:
 *     summary: Update category (Admin)
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateCategoryRequest'
 *     responses:
 *       200:
 *         description: Category updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/CategoryResponse'
 *       404:
 *         description: Category not found
 *   delete:
 *     summary: Delete category (Admin)
 *     description: Cannot delete categories with subcategories or products
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Category deleted
 *       400:
 *         description: Cannot delete - has subcategories or products
 *       404:
 *         description: Category not found
 */

// ============================================================
// PRODUCT ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/products:
 *   get:
 *     summary: Get all products (Public)
 *     description: |
 *       Browse product catalog with advanced filtering.
 *       Supports search, price range, category (includes subcategories), stock filter.
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: query
 *         name: categoryId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by category (includes subcategories)
 *       - in: query
 *         name: sellerId
 *         schema:
 *           type: string
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [ACTIVE, INACTIVE, OUT_OF_STOCK]
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search in titles, descriptions, SKU
 *       - in: query
 *         name: minPrice
 *         schema:
 *           type: number
 *       - in: query
 *         name: maxPrice
 *         schema:
 *           type: number
 *       - in: query
 *         name: inStock
 *         schema:
 *           type: boolean
 *         description: Only show products with stock > 0
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, price, saleCount, viewCount]
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *     responses:
 *       200:
 *         description: Products retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ProductResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Create product (Seller)
 *     description: |
 *       Create a new product listing. Requires an active, verified seller account.
 *       Stock automatically sets status: 0 = OUT_OF_STOCK, >0 = ACTIVE.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateProductRequest'
 *     responses:
 *       201:
 *         description: Product created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductResponse'
 *       400:
 *         description: Validation error or SKU exists
 *       403:
 *         description: Not authorized to sell (seller account not active/verified)
 *       404:
 *         description: Category or seller not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}:
 *   get:
 *     summary: Get product details (Public)
 *     description: Returns product with category, seller info, and images. Increments view count.
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Product retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductResponse'
 *       404:
 *         description: Product not found
 *   patch:
 *     summary: Update product (Seller/Admin)
 *     description: Only product owner or admin can update. Stock auto-sets status.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateProductRequest'
 *     responses:
 *       200:
 *         description: Product updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductResponse'
 *       403:
 *         description: Not the product owner
 *       404:
 *         description: Product not found
 *   delete:
 *     summary: Delete product (Seller/Admin)
 *     description: Only product owner or admin can delete
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Product deleted
 *       403:
 *         description: Not the product owner
 *       404:
 *         description: Product not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}/approve:
 *   patch:
 *     summary: Approve product (Admin)
 *     description: Approves a product making it visible to all users. Notifies the seller.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Product approved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductResponse'
 *       404:
 *         description: Product not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}/reject:
 *   patch:
 *     summary: Reject product (Admin)
 *     description: Rejects a product. Notifies the seller with a reason.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Product rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductResponse'
 *       404:
 *         description: Product not found
 */

// ============================================================
// PRODUCT IMAGE ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}/images:
 *   post:
 *     summary: Upload product image (Seller)
 *     description: |
 *       Upload image for a product. Use multipart/form-data field `image`.
 *       Max 5MB, allowed: JPEG, PNG, WebP, SVG.
 *       Set isPrimary=true to make it the main product image.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Product ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Product image (JPEG, PNG, WebP, SVG - max 5MB)
 *               isPrimary:
 *                 type: boolean
 *                 description: Set as primary image
 *     responses:
 *       201:
 *         description: Image uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductImageResponse'
 *       403:
 *         description: Not the product owner
 *       404:
 *         description: Product not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}/images/{imageId}:
 *   delete:
 *     summary: Delete product image (Seller)
 *     description: Deletes the image from both database and storage. Only the product owner can delete.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Product ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Image ID
 *     responses:
 *       200:
 *         description: Image deleted
 *       403:
 *         description: Not the product owner
 *       404:
 *         description: Image not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/products/{id}/images/{imageId}/primary:
 *   patch:
 *     summary: Set image as primary (Seller)
 *     description: Makes this image the primary display image for the product
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Product ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Image ID
 *     responses:
 *       200:
 *         description: Primary image set
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ProductImageResponse'
 *       404:
 *         description: Image not found
 */

// ============================================================
// MY PRODUCTS ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/my/products:
 *   get:
 *     summary: Get my products (Seller)
 *     description: Returns products owned by the authenticated seller
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Products retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ProductResponse'
 *                 meta:
 *                   type: object
 *       401:
 *         description: Not authenticated
 */

// ============================================================
// SHIPPING COMPANY ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/shipping-companies:
 *   get:
 *     summary: Get shipping companies (Public)
 *     description: Returns list of available shipping companies
 *     tags: [E-Commerce]
 *     parameters:
 *       - in: query
 *         name: isActive
 *         schema:
 *           type: boolean
 *         description: Filter by active status
 *     responses:
 *       200:
 *         description: Companies retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ShippingCompanyResponse'
 *   post:
 *     summary: Create shipping company (Admin)
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateShippingCompanyRequest'
 *     responses:
 *       201:
 *         description: Company created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ShippingCompanyResponse'
 *       400:
 *         description: Company name already exists
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/shipping-companies/{id}:
 *   patch:
 *     summary: Update shipping company (Admin)
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateShippingCompanyRequest'
 *     responses:
 *       200:
 *         description: Company updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ShippingCompanyResponse'
 *       404:
 *         description: Company not found
 *   delete:
 *     summary: Delete shipping company (Admin)
 *     description: Soft-deletes if company has orders, hard-deletes otherwise
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Company deleted
 *       404:
 *         description: Company not found
 */

// ============================================================
// ORDER ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/orders:
 *   post:
 *     summary: Create order (Buyer)
 *     description: |
 *       Place a new order. Validates stock, product availability, and single-seller constraint.
 *       Cannot buy own products. Stock is decremented automatically.
 *       Notifies seller via push notification.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateOrderRequest'
 *     responses:
 *       201:
 *         description: Order created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OrderResponse'
 *       400:
 *         description: Insufficient stock / product not available / own product / mixed sellers
 *       403:
 *         description: Seller is not accepting orders
 *       404:
 *         description: Product not found
 *       429:
 *         description: Too many order attempts
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/orders/{id}:
 *   get:
 *     summary: Get order details (Buyer/Seller/Admin)
 *     description: Only the buyer, seller, or admin can view an order
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Order retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OrderResponse'
 *       403:
 *         description: Cannot view this order
 *       404:
 *         description: Order not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/orders/{id}/status:
 *   patch:
 *     summary: Update order status (Seller/Admin)
 *     description: |
 *       Seller or admin can update order status.
 *       Available transitions: PENDING → CONFIRMED → PROCESSING → SHIPPED → DELIVERED
 *       Notifies buyer on status change.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateOrderStatusRequest'
 *     responses:
 *       200:
 *         description: Status updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OrderResponse'
 *       403:
 *         description: Only seller can update status
 *       404:
 *         description: Order not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/orders/{id}/tracking:
 *   patch:
 *     summary: Update tracking info (Seller)
 *     description: Set shipping company and tracking number. Auto-sets status to SHIPPED.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateTrackingRequest'
 *     responses:
 *       200:
 *         description: Tracking updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OrderResponse'
 *       403:
 *         description: Only seller can update tracking
 *       404:
 *         description: Order not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/orders/{id}/cancel:
 *   post:
 *     summary: Cancel order (Buyer/Admin)
 *     description: |
 *       Buyer can cancel only PENDING orders. Admin can cancel any order.
 *       Restores product stock automatically.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CancelOrderRequest'
 *     responses:
 *       200:
 *         description: Order cancelled
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OrderResponse'
 *       400:
 *         description: Can only cancel pending orders
 *       403:
 *         description: Cannot cancel this order
 *       404:
 *         description: Order not found
 */

// ============================================================
// MY ORDERS / SALES ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/my/orders:
 *   get:
 *     summary: Get my orders (Buyer)
 *     description: Returns orders where authenticated user is the buyer
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Orders retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/OrderResponse'
 *                 meta:
 *                   type: object
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/my/sales:
 *   get:
 *     summary: Get my sales (Seller)
 *     description: Returns orders where authenticated user is the seller
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Sales retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/OrderResponse'
 *                 meta:
 *                   type: object
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/my/stats:
 *   get:
 *     summary: Get seller statistics (Seller)
 *     description: Returns order counts by status and total revenue for the authenticated seller
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     stats:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           status:
 *                             type: string
 *                           _count:
 *                             type: object
 *                           _sum:
 *                             type: object
 *                     total:
 *                       type: integer
 *                     revenue:
 *                       type: number
 *                       description: Total revenue from non-cancelled/returned orders
 *       404:
 *         description: Seller not found
 */

// ============================================================
// ADMIN ORDER ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/orders:
 *   get:
 *     summary: Get all orders (Admin)
 *     description: View all orders with full filtering
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: buyerId
 *         schema:
 *           type: string
 *       - in: query
 *         name: sellerId
 *         schema:
 *           type: string
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, RETURNED]
 *       - in: query
 *         name: paymentStatus
 *         schema:
 *           type: string
 *           enum: [PENDING, PAID, FAILED, EXPIRED]
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Orders retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/OrderResponse'
 *                 meta:
 *                   type: object
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

// ============================================================
// SELLER DOCUMENT ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/seller/documents:
 *   get:
 *     summary: Get my seller documents (Seller)
 *     description: Returns documents (license, tax card) uploaded by the seller
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SellerDocumentResponse'
 *       401:
 *         description: Not authenticated
 *   post:
 *     summary: Upload seller document (Seller)
 *     description: |
 *       Upload license or verification document for seller account.
 *       Use multipart/form-data field `document`. Max 20MB (PDF, JPEG, PNG).
 *       Documents are private - accessible only via signed URLs.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - document
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *               docType:
 *                 type: string
 *                 enum: [LICENSE, ID_CARD, REGISTRATION, TAX_CERTIFICATE, OTHER]
 *                 default: OTHER
 *                 description: Type of document
 *     responses:
 *       201:
 *         description: Document uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerDocumentResponse'
 *       400:
 *         description: Invalid file or missing document
 *       401:
 *         description: Not authenticated
 *       404:
 *         description: Seller not found
 *       413:
 *         description: File too large (max 20MB)
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/seller/documents/{id}:
 *   delete:
 *     summary: Delete seller document (Seller)
 *     description: Deletes the document from both database and storage. Only the owner can delete.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Document deleted
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not your document
 *       404:
 *         description: Document not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/seller/documents/{id}/verify:
 *   patch:
 *     summary: Verify seller document (Admin)
 *     description: Admin verifies a seller's license/document. Notifies seller.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Document verified
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerDocumentResponse'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Document not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/seller/documents/{id}/reject:
 *   patch:
 *     summary: Reject seller document (Admin)
 *     description: Admin rejects a seller's document with a reason. Notifies seller.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - reason
 *             properties:
 *               reason:
 *                 type: string
 *                 minLength: 3
 *                 maxLength: 500
 *                 example: "Document is blurry and unreadable"
 *     responses:
 *       200:
 *         description: Document rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerDocumentResponse'
 *       400:
 *         description: Missing rejection reason
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Document not found
 */

// ============================================================
// SELLER PROFILE (Self-service)
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/my/profile:
 *   get:
 *     summary: Get my seller profile (Seller)
 *     description: |
 *       Returns the authenticated seller's own profile information.
 *       
 *       **Required Role:** SELLER
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profile retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Profile retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *             example:
 *               success: true
 *               message: "Profile retrieved successfully"
 *               data:
 *                 id: "550e8400-e29b-41d4-a716-446655440000"
 *                 email: "seller@example.com"
 *                 firstName: "Mohamed"
 *                 lastName: "Khelifi"
 *                 phone: "0555123456"
 *                 businessName: "Pharma Santé"
 *                 businessType: "INDIVIDUAL"
 *                 status: "ACTIVE"
 *                 isVerified: true
 *                 wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (requires SELLER role)
 *       404:
 *         description: Seller not found
 *       500:
 *         description: Internal server error
 *   
 *   patch:
 *     summary: Update my seller profile (Seller)
 *     description: |
 *       Updates the authenticated seller's own profile information.
 *       
 *       **Allowed fields:**
 *       - firstName, lastName, phone
 *       - businessName, businessType
 *       - taxNumber, registrationNumber
 *       - address, baladyaId
 *       
 *       **Not allowed:** email, status, isVerified, password
 *       
 *       **Required Role:** SELLER
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateSellerProfileRequest'
 *           examples:
 *             updateBusiness:
 *               summary: Update business name
 *               value:
 *                 businessName: "Pharma Santé Plus"
 *             updatePersonal:
 *               summary: Update personal info
 *               value:
 *                 firstName: "Ahmed"
 *                 lastName: "Ben Khelifi"
 *                 phone: "0555987654"
 *             updateFull:
 *               summary: Update multiple fields
 *               value:
 *                 businessName: "Pharma Santé Plus"
 *                 businessType: "COMPANY"
 *                 address: "456 Rue des Médecins, Alger"
 *                 baladyaId: "550e8400-e29b-41d4-a716-446655440003"
 *     responses:
 *       200:
 *         description: Profile updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Profile updated successfully
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (requires SELLER role)
 *       404:
 *         description: Seller not found
 *       500:
 *         description: Internal server error
 */

// ============================================================
// SELLER MANAGEMENT ENDPOINTS (Admin)
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/sellers:
 *   get:
 *     summary: Get all sellers (Admin)
 *     description: |
 *       Returns paginated list of all sellers with filtering options.
 *       Useful for admin dashboard to manage seller accounts.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, ACTIVE, SUSPENDED, BANNED]
 *         description: Filter by seller status
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *         description: Filter by verification status
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by name, email, phone, or business name
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *     responses:
 *       200:
 *         description: Sellers retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SellerResponse'
 *                 meta:
 *                   type: object
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/sellers/stats:
 *   get:
 *     summary: Get seller statistics (Admin)
 *     description: |
 *       Returns counts of sellers by status (PENDING, ACTIVE, SUSPENDED, BANNED).
 *       Useful for admin dashboard overview.
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Seller statistics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerStatsResponse'
 *                 example:
 *                   success: true
 *                   data:
 *                     total: 150
 *                     pending: 12
 *                     active: 120
 *                     suspended: 15
 *                     banned: 3
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/sellers/{sellerId}:
 *   get:
 *     summary: Get seller by ID (Admin)
 *     description: Returns detailed information about a specific seller including their products and orders
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: sellerId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Seller ID
 *     responses:
 *       200:
 *         description: Seller retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Seller not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/sellers/{sellerId}/status:
 *   patch:
 *     summary: Update seller status (Admin)
 *     description: |
 *       Change a seller's account status. This controls their ability to sell products.
 *       - ACTIVE: Full selling privileges (also sets isVerified=true)
 *       - SUSPENDED: Temporarily blocked from selling
 *       - BANNED: Permanently blocked from selling
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: sellerId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Seller ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ToggleSellerStatusRequest'
 *           examples:
 *             activate:
 *               summary: Activate seller
 *               value:
 *                 status: "ACTIVE"
 *             suspend:
 *               summary: Suspend seller
 *               value:
 *                 status: "SUSPENDED"
 *             ban:
 *               summary: Ban seller
 *               value:
 *                 status: "BANNED"
 *     responses:
 *       200:
 *         description: Seller status updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                   example: "Seller status updated to ACTIVE"
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       400:
 *         description: Invalid status or missing status
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Status must be one of: ACTIVE, SUSPENDED, BANNED"
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Seller not found
 */

/**
 * @swagger
 * /api/v1/ecommerce/v1/admin/sellers/{sellerId}/reset-password:
 *   post:
 *     summary: Reset seller password (Admin)
 *     description: |
 *       Admin triggers a password reset for a seller.
 *       A password setup link is sent to the seller's email.
 *       
 *       **Flow:**
 *       1. Admin calls this endpoint
 *       2. Random password is generated and hashed
 *       3. Password setup token is created (valid 72 hours)
 *       4. Email is sent with "Set Password" button
 *       5. Seller clicks link and sets new password
 *       
 *       **Required Role:** SUPER_ADMIN or ADMIN
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: sellerId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Seller ID
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResetPasswordRequest'
 *     responses:
 *       200:
 *         description: Password reset link sent
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Password reset link sent to seller email
 *                 data:
 *                   type: null
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Seller not found
 *       500:
 *         description: Internal server error
 */

// ============================================================
// LEGACY ENDPOINTS (deprecated)
// ============================================================

/**
 * @swagger
 * /api/v1/ecommerce/v1/users/{userId}/can-post:
 *   patch:
 *     summary: Toggle user selling permission (Admin) - DEPRECATED
 *     description: |
 *       ⚠️ **DEPRECATED**: Use `/admin/sellers/{sellerId}/status` instead.
 *       This endpoint will be removed in a future version.
 *       Enable or disable a user's ability to sell products (canPost flag)
 *     tags: [E-Commerce]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: User ID (same as seller ID)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ToggleCanPostRequest'
 *           example:
 *             canPost: true
 *     responses:
 *       200:
 *         description: Permission updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                   example: "User selling enabled successfully"
 *                 data:
 *                   $ref: '#/components/schemas/SellerResponse'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized (Admin only)
 *       404:
 *         description: Seller not found
 *     deprecated: true
 */