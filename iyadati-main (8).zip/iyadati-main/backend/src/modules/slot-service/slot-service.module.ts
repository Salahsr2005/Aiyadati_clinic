import { Router } from 'express';
import slotServiceRoutes from './v1/slot-service.routes';

const router = Router();
router.use('/v1', slotServiceRoutes);

export { router as slotServiceModule };

