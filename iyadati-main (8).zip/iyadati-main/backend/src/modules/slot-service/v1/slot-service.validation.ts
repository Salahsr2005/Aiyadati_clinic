import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const generateServiceSlotsSchema = Joi.object({
  startDate: Joi.date().iso().required().messages({
    'date.iso': 'Start date must be in YYYY-MM-DD format',
    'any.required': 'Start date is required',
  }),
  endDate: Joi.date().iso().min(Joi.ref('startDate')).required().messages({
    'date.iso': 'End date must be in YYYY-MM-DD format',
    'date.min': 'End date must be after start date',
    'any.required': 'End date is required',
  }),
  clinicId: Joi.string().uuid().optional(),
  roomId: Joi.string().uuid().optional(),
  force: Joi.boolean().optional().default(false),
});

export const validateGenerateServiceSlots = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const { error } = generateServiceSlotsSchema.validate(req.body, {
    abortEarly: false,
  });
  if (error) {
    const errors = error.details.map((d) => ({
      field: d.path.join('.'),
      message: d.message,
    }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

