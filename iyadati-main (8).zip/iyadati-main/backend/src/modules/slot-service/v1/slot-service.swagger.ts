/**
 * @swagger
 * tags:
 *   name: Slot Service
 *   description: Service-based slot discovery and management
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     DoctorServiceResponse:
 *       type: object
 *       properties:
 *         doctorId:
 *           type: string
 *           format: uuid
 *         firstNameFr:
 *           type: string
 *         firstNameAr:
 *           type: string
 *         lastNameFr:
 *           type: string
 *         lastNameAr:
 *           type: string
 *         email:
 *           type: string
 *         phone:
 *           type: string
 *         photoUrl:
 *           type: string
 *           nullable: true
 *         avgRating:
 *           type: number
 *           nullable: true
 *         totalReviews:
 *           type: integer
 *         specialties:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               nameFr:
 *                 type: string
 *               nameAr:
 *                 type: string
 *         clinic:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             logoUrl:
 *               type: string
 *               nullable: true
 *         isPrimary:
 *           type: boolean
 *         slots:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *                 format: uuid
 *               startTime:
 *                 type: string
 *                 format: date-time
 *               endTime:
 *                 type: string
 *                 format: date-time
 *               isAvailable:
 *                 type: boolean
 *               clinicId:
 *                 type: string
 *                 nullable: true
 *               roomId:
 *                 type: string
 *                 nullable: true
 *         availableSlotsCount:
 *           type: integer
 *     
 *     ServiceAvailabilityResponse:
 *       type: object
 *       properties:
 *         serviceId:
 *           type: string
 *           format: uuid
 *         serviceNameFr:
 *           type: string
 *         serviceNameAr:
 *           type: string
 *         date:
 *           type: string
 *           format: date
 *         totalSlots:
 *           type: integer
 *         availableSlots:
 *           type: integer
 *         doctors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *                 format: uuid
 *               doctorName:
 *                 type: string
 *               slots:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                       format: uuid
 *                     startTime:
 *                       type: string
 *                       format: date-time
 *                     endTime:
 *                       type: string
 *                       format: date-time
 *     
 *     DoctorServicesResponse:
 *       type: object
 *       properties:
 *         doctorId:
 *           type: string
 *           format: uuid
 *         doctorName:
 *           type: string
 *         services:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               serviceId:
 *                 type: string
 *                 format: uuid
 *               serviceNameFr:
 *                 type: string
 *               serviceNameAr:
 *                 type: string
 *               totalSlots:
 *                 type: integer
 *               availableSlots:
 *                 type: integer
 *               nextAvailableSlot:
 *                 type: string
 *                 format: date-time
 *                 nullable: true
 *     
 *     GenerateServiceSlotsRequest:
 *       type: object
 *       required:
 *         - startDate
 *         - endDate
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *           description: Start date for slot generation (YYYY-MM-DD)
 *         endDate:
 *           type: string
 *           format: date
 *           description: End date for slot generation (YYYY-MM-DD)
 *         clinicId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         roomId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         force:
 *           type: boolean
 *           default: false
 *           description: Force regeneration (cancels existing appointments)
 */

/**
 * @swagger
 * /api/v1/slot-service/v1/services/{serviceId}/doctors:
 *   get:
 *     summary: Get doctors offering a service with available slots
 *     description: |
 *       Patient-facing endpoint to find all doctors who offer a specific service
 *       and have available slots on a given date.
 *       
 *       **Flow:** Select Service → See Doctors → Pick Slot → Book
 *       
 *       **Search:** Use the `q` parameter to filter doctors by name (French or Arabic).
 *       Partial matches are supported (case-insensitive).
 *     tags: [Slot Service]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: serviceId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to check availability (YYYY-MM-DD)
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specific clinic
 *       - in: query
 *         name: q
 *         schema:
 *           type: string
 *         description: Free-text search by doctor name (French or Arabic)
 *         example: "Ahmed"
 *     responses:
 *       200:
 *         description: Doctors with available slots retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     service:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                         nameFr:
 *                           type: string
 *                         nameAr:
 *                           type: string
 *                         descriptionFr:
 *                           type: string
 *                         descriptionAr:
 *                           type: string
 *                         clinicId:
 *                           type: string
 *                     doctors:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/DoctorServiceResponse'
 *                     total:
 *                       type: integer
 *                 message:
 *                   type: string
 *       400:
 *         description: Missing date parameter or invalid format
 *       404:
 *         description: Service not found
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /api/v1/slot-service/v1/services/{serviceId}/availability:
 *   get:
 *     summary: Get service availability on a date
 *     description: |
 *       Shows all slots for a specific service across all doctors on a given date.
 *       Useful for displaying service-level availability.
 *     tags: [Slot Service]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: serviceId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Date to check (YYYY-MM-DD)
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specific clinic
 *     responses:
 *       200:
 *         description: Service availability retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ServiceAvailabilityResponse'
 *       404:
 *         description: Service not found
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /api/v1/slot-service/v1/doctors/{doctorId}/services:
 *   get:
 *     summary: Get all services a doctor offers with slot counts
 *     description: |
 *       Get all services a doctor offers, along with slot counts and next available slot.
 *       Useful for doctor profile pages.
 *     tags: [Slot Service]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter slots by specific date
 *     responses:
 *       200:
 *         description: Doctor services retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorServicesResponse'
 *       404:
 *         description: Doctor not found
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /api/v1/slot-service/v1/clinic/services/{serviceId}/generate:
 *   post:
 *     summary: Generate slots for a service (Clinic)
 *     description: |
 *       Generates slots for all doctors assigned to a service.
 *       Each slot will be tagged with the serviceId.
 *       
 *       **Prerequisites:**
 *       - Service must exist and belong to the clinic
 *       - At least one doctor must be assigned to the service
 *       
 *       **Note:** Uses the same slot generation logic as the appointment module.
 *     tags: [Slot Service]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: serviceId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GenerateServiceSlotsRequest'
 *           example:
 *             startDate: "2026-09-01"
 *             endDate: "2026-09-07"
 *             clinicId: "clinic-uuid-here"
 *             roomId: "room-uuid-here"
 *     responses:
 *       201:
 *         description: Slots generated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     serviceId:
 *                       type: string
 *                     slotsCreated:
 *                       type: integer
 *                     doctors:
 *                       type: array
 *                       items:
 *                         type: string
 *                 message:
 *                   type: string
 *       400:
 *         description: Validation error, no doctors assigned, or service not in clinic
 *       404:
 *         description: Service not found
 *       403:
 *         description: Forbidden (requires CLINIC role)
 *       401:
 *         description: Unauthorized
 */