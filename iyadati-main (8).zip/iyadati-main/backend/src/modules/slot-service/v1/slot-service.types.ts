export interface DoctorServiceResponse {
  doctorId: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  email: string;
  phone: string;
  photoUrl: string | null;
  avgRating: number | null;
  totalReviews: number;
  specialties: Array<{
    id: string;
    nameFr: string;
    nameAr: string;
  }>;
  clinic: {
    id: string;
    nameFr: string;
    nameAr: string;
    logoUrl: string | null;
  } | null;
  isPrimary: boolean;
  slots: Array<{
    id: string;
    startTime: Date;
    endTime: Date;
    isAvailable: boolean;
    clinicId: string | null;
    roomId: string | null;
  }>;
  availableSlotsCount: number;
}

export interface ServiceAvailabilityResponse {
  serviceId: string;
  serviceNameFr: string;
  serviceNameAr: string;
  date: string;
  totalSlots: number;
  availableSlots: number;
  doctors: Array<{
    doctorId: string;
    doctorName: string;
    slots: Array<{
      id: string;
      startTime: string;
      endTime: string;
    }>;
  }>;
}

export interface DoctorServicesResponse {
  doctorId: string;
  doctorName: string;
  services: Array<{
    serviceId: string;
    serviceNameFr: string;
    serviceNameAr: string;
    totalSlots: number;
    availableSlots: number;
    nextAvailableSlot?: string;
  }>;
}

export interface GenerateServiceSlotsDTO {
  serviceId: string;
  startDate: string;
  endDate: string;
  clinicId?: string;
  roomId?: string;
  force?: boolean;
}

