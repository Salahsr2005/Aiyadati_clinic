import { Router } from 'express';
import { SlotServiceController } from './slot-service.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new SlotServiceController();

// ============================================================
// PATIENT-FACING ROUTES (Public/User)
// ============================================================

// Get doctors offering a service with available slots
router.get(
  '/services/:serviceId/doctors',
  authenticate,
  authorize('USER', 'DOCTOR', 'CLINIC', 'ADMIN', 'SUPER_ADMIN'),
  controller.getDoctorsByService
);

// Get availability for a specific service on a date
router.get(
  '/services/:serviceId/availability',
  authenticate,
  authorize('USER', 'DOCTOR', 'CLINIC', 'ADMIN', 'SUPER_ADMIN'),
  controller.getServiceAvailability
);

// Get all services a doctor offers with slot counts
router.get(
  '/doctors/:doctorId/services',
  authenticate,
  authorize('USER', 'DOCTOR', 'CLINIC', 'ADMIN', 'SUPER_ADMIN'),
  controller.getDoctorServices
);

// ============================================================
// CLINIC-FACING ROUTES
// ============================================================

// Generate slots for a specific service (clinic self-service)
router.post(
  '/clinic/services/:serviceId/generate',
  authenticate,
  authorize('CLINIC'),
  controller.generateServiceSlots
);

export default router;

