import { slotRepository } from '../../../repositories/slot.repository';
import { clinicServiceRepository } from '../../../repositories/clinic-service.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { nowAlgeria } from '../../../core/utils/timezone';
import {
  DoctorServiceResponse,
  ServiceAvailabilityResponse,
  DoctorServicesResponse,
  GenerateServiceSlotsDTO,
} from './slot-service.types';

export class SlotServiceService {
  /**
   * Get doctors offering a specific service with available slots
   * Main patient-facing endpoint: "Find a doctor by service"
   * 🆕 Supports free-text search by doctor name via `query` parameter
   */
  async getDoctorsByService(
    serviceId: string,
    date: string,
    clinicId?: string,
    query?: string // 🆕 ADDED
  ): Promise<{
    service: any;
    doctors: DoctorServiceResponse[];
    total: number;
  }> {
    // Validate service exists
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) {
      throw new NotFoundError('Service not found');
    }

    // Validate date
    const targetDate = new Date(date);
    if (isNaN(targetDate.getTime())) {
      throw new BadRequestError('Invalid date format. Use YYYY-MM-DD');
    }

    // Get all doctors offering this service
    const serviceDoctors = await clinicServiceRepository.getServiceDoctors(serviceId);

    if (serviceDoctors.length === 0) {
      return {
        service: {
          id: service.id,
          nameFr: service.nameFr,
          nameAr: service.nameAr,
          descriptionFr: service.descriptionFr,
          descriptionAr: service.descriptionAr,
          clinicId: service.clinicId,
        },
        doctors: [],
        total: 0,
      };
    }

    // 🆕 Filter doctors by name if query provided
    let filteredServiceDoctors = serviceDoctors;
    if (query && query.trim()) {
      const search = query.trim().toLowerCase();
      filteredServiceDoctors = serviceDoctors.filter((sd: any) => {
        const fullNameFr = `${sd.doctor.firstNameFr} ${sd.doctor.lastNameFr}`.toLowerCase();
        const fullNameAr = `${sd.doctor.firstNameAr} ${sd.doctor.lastNameAr}`.toLowerCase();
        return fullNameFr.includes(search) || fullNameAr.includes(search);
      });
    }

    // For each filtered doctor, get their available slots for this service
    const results = await Promise.all(
      filteredServiceDoctors.map(async (sd: any) => {
        // Get all slots for this service on this date
        const allSlots = await slotRepository.findAvailableByServiceAndDate(
          serviceId,
          date,
          sd.doctor.clinicLinks?.[0]?.clinicId || clinicId
        );

        // Filter slots for this specific doctor
        const doctorSlots = allSlots.filter(
          (slot: any) => slot.doctorId === sd.doctorId
        );

        // Get the clinic from the doctor's clinic links
        const clinic = sd.doctor.clinicLinks && sd.doctor.clinicLinks.length > 0
          ? sd.doctor.clinicLinks[0].clinic
          : null;

        return {
          doctor: sd.doctor,
          clinic: clinic,
          service: sd.service,
          isPrimary: sd.isPrimary,
          slots: doctorSlots.map((slot: any) => ({
            id: slot.id,
            startTime: slot.startTime,
            endTime: slot.endTime,
            isAvailable: slot.status === 'available',
            clinicId: slot.clinicId,
            roomId: slot.roomId,
          })),
          availableSlotsCount: doctorSlots.length,
        };
      })
    );

    // Return only doctors with available slots
    const availableDoctors = results.filter((r) => r.slots.length > 0);

    // Format response
    const doctors: DoctorServiceResponse[] = availableDoctors.map((r) => ({
      doctorId: r.doctor.id,
      firstNameFr: r.doctor.firstNameFr,
      firstNameAr: r.doctor.firstNameAr,
      lastNameFr: r.doctor.lastNameFr,
      lastNameAr: r.doctor.lastNameAr,
      email: r.doctor.email,
      phone: r.doctor.phone,
      photoUrl: r.doctor.photoPath
        ? `${process.env.BASE_URL}/uploads/${r.doctor.photoPath}`
        : null,
      avgRating: r.doctor.avgRating,
      totalReviews: r.doctor.totalReviews,
      specialties: r.doctor.specialties?.map((s: any) => ({
        id: s.specialty.id,
        nameFr: s.specialty.nameFr,
        nameAr: s.specialty.nameAr,
      })) || [],
      clinic: r.clinic
        ? {
            id: r.clinic.id,
            nameFr: r.clinic.nameFr,
            nameAr: r.clinic.nameAr,
            logoUrl: r.clinic.logoFileId
              ? `${process.env.BASE_URL}/api/v1/files/public/${r.clinic.logoFileId}`
              : r.clinic.logoPath
              ? `${process.env.BASE_URL}/uploads/${r.clinic.logoPath}`
              : null,
          }
        : null,
      isPrimary: r.isPrimary || false,
      slots: r.slots.map((slot) => ({
        id: slot.id,
        startTime: slot.startTime,
        endTime: slot.endTime,
        isAvailable: slot.isAvailable,
        clinicId: slot.clinicId,
        roomId: slot.roomId,
      })),
      availableSlotsCount: r.slots.length,
    }));

    return {
      service: {
        id: service.id,
        nameFr: service.nameFr,
        nameAr: service.nameAr,
        descriptionFr: service.descriptionFr,
        descriptionAr: service.descriptionAr,
        clinicId: service.clinicId,
      },
      doctors,
      total: doctors.length,
    };
  }

  /**
   * Get availability for a specific service on a date
   * Shows all slots across all doctors offering this service
   */
  async getServiceAvailability(
    serviceId: string,
    date: string,
    clinicId?: string
  ): Promise<ServiceAvailabilityResponse> {
    // Validate service exists
    const service = await clinicServiceRepository.findById(serviceId);
    if (!service) {
      throw new NotFoundError('Service not found');
    }

    const targetDate = new Date(date);
    if (isNaN(targetDate.getTime())) {
      throw new BadRequestError('Invalid date format. Use YYYY-MM-DD');
    }

    const slots = await slotRepository.findAvailableByServiceAndDate(
      serviceId,
      date,
      clinicId
    );

    // Group by doctor
    const doctorMap = new Map<
      string,
      {
        doctorId: string;
        doctorName: string;
        slots: Array<{
          id: string;
          startTime: string;
          endTime: string;
        }>;
      }
    >();

    for (const slot of slots) {
      const doctorId = slot.doctorId;
      const doctorName = slot.doctor
        ? `${slot.doctor.firstNameFr} ${slot.doctor.lastNameFr}`
        : 'Unknown Doctor';

      if (!doctorMap.has(doctorId)) {
        doctorMap.set(doctorId, {
          doctorId,
          doctorName,
          slots: [],
        });
      }

      doctorMap.get(doctorId)!.slots.push({
        id: slot.id,
        startTime: slot.startTime.toISOString(),
        endTime: slot.endTime.toISOString(),
      });
    }

    const totalSlots = slots.length;
    const availableSlots = slots.filter((s) => s.status === 'available').length;

    return {
      serviceId: service.id,
      serviceNameFr: service.nameFr,
      serviceNameAr: service.nameAr,
      date,
      totalSlots,
      availableSlots,
      doctors: Array.from(doctorMap.values()),
    };
  }

  /**
   * Get all services a doctor offers with slot counts
   */
  async getDoctorServices(
    doctorId: string,
    date?: string
  ): Promise<DoctorServicesResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) {
      throw new NotFoundError('Doctor not found');
    }

    const services = await slotRepository.getDoctorServicesWithSlotCounts(
      doctorId,
      date
    );

    // Get next available slot for each service
    const now = nowAlgeria();
    const servicesWithNextSlot = await Promise.all(
      services.map(async (item) => {
        let nextAvailableSlot: string | undefined;

        if (date) {
          const slots = await slotRepository.findAvailableByServiceAndDate(
            item.service.id,
            date
          );
          const doctorSlots = slots.filter((s) => s.doctorId === doctorId);
          if (doctorSlots.length > 0) {
            nextAvailableSlot = doctorSlots[0].startTime.toISOString();
          }
        }

        return {
          serviceId: item.service.id,
          serviceNameFr: item.service.nameFr,
          serviceNameAr: item.service.nameAr,
          totalSlots: item.totalSlots,
          availableSlots: item.availableSlots,
          nextAvailableSlot,
        };
      })
    );

    return {
      doctorId: doctor.id,
      doctorName: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
      services: servicesWithNextSlot,
    };
  }

  /**
   * Generate slots for a specific service
   * This is a convenience method that generates slots for all doctors
   * who offer this service, tagged with the serviceId
   */
  async generateSlotsForService(
    clinicId: string,
    data: GenerateServiceSlotsDTO,
    userId: string,
    userRole: string
  ): Promise<{ serviceId: string; slotsCreated: number; doctors: string[] }> {
    // Validate service exists and belongs to this clinic
    const service = await clinicServiceRepository.findById(data.serviceId);
    if (!service) {
      throw new NotFoundError('Service not found');
    }

    if (service.clinicId !== clinicId) {
      throw new BadRequestError('Service does not belong to this clinic');
    }

    // Get all doctors assigned to this service
    const serviceDoctors = await clinicServiceRepository.getServiceDoctors(
      data.serviceId
    );

    if (serviceDoctors.length === 0) {
      throw new BadRequestError(
        'No doctors assigned to this service. Please assign doctors first.'
      );
    }

    let totalSlotsCreated = 0;
    const doctorsProcessed: string[] = [];

    // Generate slots for each doctor
    for (const sd of serviceDoctors) {
      try {
        // Use the appointment service's generateSlots method
        // We'll import it dynamically to avoid circular dependency
        const { appointmentService } = await import(
          '../../appointment/v1/appointment.service'
        );

        const slots = await appointmentService.generateSlots(
          sd.doctorId,
          {
            startDate: data.startDate,
            endDate: data.endDate,
            clinicId: data.clinicId || clinicId,
            roomId: data.roomId,
            serviceId: data.serviceId, // 🆕 Pass serviceId to tag slots
            force: data.force || false,
          },
          userId,
          userRole
        );

        totalSlotsCreated += slots.length;
        doctorsProcessed.push(sd.doctorId);

        // Log audit
        eventEmitter.emit('audit', {
          action: 'slots.generated_for_service',
          entity: 'Slot',
          performedBy: userId,
          details: {
            serviceId: data.serviceId,
            doctorId: sd.doctorId,
            slotsCreated: slots.length,
            startDate: data.startDate,
            endDate: data.endDate,
          },
        });
      } catch (error) {
        logger.error(
          `Failed to generate slots for doctor ${sd.doctorId} for service ${data.serviceId}`,
          error
        );
        // Continue with other doctors
      }
    }

    logger.info(
      `Generated ${totalSlotsCreated} slots for service ${data.serviceId} across ${doctorsProcessed.length} doctors`
    );

    return {
      serviceId: data.serviceId,
      slotsCreated: totalSlotsCreated,
      doctors: doctorsProcessed,
    };
  }
}

export const slotServiceService = new SlotServiceService();

