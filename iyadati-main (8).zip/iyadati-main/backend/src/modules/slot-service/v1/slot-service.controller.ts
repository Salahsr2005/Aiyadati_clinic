import { Request, Response, NextFunction } from 'express';
import { slotServiceService } from './slot-service.service';
import { ResponseUtil } from '../../../core/utils/response';

export class SlotServiceController {
  /**
   * Patient-facing: Get doctors by service with available slots
   * 🆕 Supports free-text search via `q` query parameter
   */
  getDoctorsByService = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const { serviceId } = req.params;
      const { date, clinicId, q } = req.query; // 🆕 Added q

      if (!date) {
        ResponseUtil.badRequest(res, 'Date query parameter is required');
        return;
      }

      const result = await slotServiceService.getDoctorsByService(
        serviceId,
        date as string,
        clinicId as string,
        q as string // 🆕 Pass query
      );

      ResponseUtil.success(
        res,
        result,
        'Doctors with available slots retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  /**
   * Patient-facing: Get availability for a specific service
   */
  getServiceAvailability = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const { serviceId } = req.params;
      const { date, clinicId } = req.query;

      if (!date) {
        ResponseUtil.badRequest(res, 'Date query parameter is required');
        return;
      }

      const result = await slotServiceService.getServiceAvailability(
        serviceId,
        date as string,
        clinicId as string
      );

      ResponseUtil.success(res, result, 'Service availability retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Patient-facing: Get a doctor's services
   */
  getDoctorServices = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const { date } = req.query;

      const result = await slotServiceService.getDoctorServices(
        doctorId,
        date as string
      );

      ResponseUtil.success(res, result, 'Doctor services retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Clinic-facing: Generate slots for a service
   */
  generateServiceSlots = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const result = await slotServiceService.generateSlotsForService(
        req.user!.id,
        {
          serviceId: req.params.serviceId,
          ...req.body,
        },
        req.user!.id,
        req.user!.role
      );

      ResponseUtil.created(
        res,
        result,
        'Slots generated successfully for the service'
      );
    } catch (error) {
      next(error);
    }
  };
}

