import { Router } from 'express';
import applicationRoutes from './v1/application.routes';
import './v1/application.swagger';

const router = Router();

router.use('/v1', applicationRoutes);

export { router as applicationModule };

