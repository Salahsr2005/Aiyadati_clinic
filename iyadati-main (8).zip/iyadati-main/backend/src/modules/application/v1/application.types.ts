import { ApplicationStatus, ApplicationType } from '@prisma/client';

// ============================================================
// DOCTOR APPLICATION
// ============================================================

export interface DoctorApplicationDTO {
  email: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  phone: string;
  wilayaId: string;
  specialties?: string[];
  bioFr?: string;
  bioAr?: string;
  yearsExp?: number;
  practiceType?: string;
  notes?: string;
}

// ============================================================
// CLINIC APPLICATION
// ============================================================

export interface ClinicApplicationDTO {
  nameFr: string;
  nameAr: string;
  email: string;
  phone: string;
  wilayaId: string;
  baladyaId?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  facilityType?: string;
  notes?: string;
}

// ============================================================
// SELLER APPLICATION
// ============================================================

export interface SellerApplicationDTO {
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  wilayaId: string;
  baladyaId?: string;
  businessName?: string;
  businessType?: string;
  taxNumber?: string;
  regNumber?: string;
  address?: string;
  notes?: string;
}

// ============================================================
// REVIEW & PASSWORD
// ============================================================

export interface ReviewApplicationDTO {
  status: 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  notes?: string;
}

export interface SetPasswordDTO {
  token: string;
  password: string;
}

export interface ApplicationResponse {
  id: string;
  type: ApplicationType;
  status: ApplicationStatus;
  submittedAt: Date;
  reviewedAt: Date | null;
  reviewedBy: string | null;
  rejectionReason: string | null;
  createdEntityId: string | null;
  createdEntityType: string | null;
  [key: string]: any;
}

