import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

// ============================================================
// DOCTOR APPLICATION
// ============================================================

const doctorApplicationSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  firstNameFr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name (French) must be at least 2 characters',
    'any.required': 'First name (French) is required',
  }),
  firstNameAr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name (Arabic) must be at least 2 characters',
    'any.required': 'First name (Arabic) is required',
  }),
  lastNameFr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name (French) must be at least 2 characters',
    'any.required': 'Last name (French) is required',
  }),
  lastNameAr: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name (Arabic) must be at least 2 characters',
    'any.required': 'Last name (Arabic) is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  specialties: Joi.array().items(Joi.string().uuid()).optional(),
  bioFr: Joi.string().allow(null, '').optional(),
  bioAr: Joi.string().allow(null, '').optional(),
  yearsExp: Joi.number().min(0).max(60).optional(),
  practiceType: Joi.string().valid('INDEPENDENT', 'CLINIC_BASED', 'BOTH').optional(),
  notes: Joi.string().allow(null, '').optional(),
});

export const validateDoctorApplication = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = doctorApplicationSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// CLINIC APPLICATION
// ============================================================

const clinicApplicationSchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Clinic name (French) must be at least 2 characters',
    'any.required': 'Clinic name (French) is required',
  }),
  nameAr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Clinic name (Arabic) must be at least 2 characters',
    'any.required': 'Clinic name (Arabic) is required',
  }),
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  baladyaId: Joi.string().uuid().allow(null).optional(),
  descriptionFr: Joi.string().allow(null, '').optional(),
  descriptionAr: Joi.string().allow(null, '').optional(),
  facilityType: Joi.string().valid('CLINIC', 'HOSPITAL').optional(),
  notes: Joi.string().allow(null, '').optional(),
});

export const validateClinicApplication = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = clinicApplicationSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// SELLER APPLICATION
// ============================================================

const sellerApplicationSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  firstName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name must be at least 2 characters',
    'any.required': 'First name is required',
  }),
  lastName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name must be at least 2 characters',
    'any.required': 'Last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'string.pattern.base': 'Phone must contain only numbers',
    'any.required': 'Phone is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  baladyaId: Joi.string().uuid().allow(null).optional(),
  businessName: Joi.string().max(100).allow(null, '').optional(),
  businessType: Joi.string().valid('INDIVIDUAL', 'COMPANY', 'ASSOCIATION').optional(),
  taxNumber: Joi.string().allow(null, '').optional(),
  regNumber: Joi.string().allow(null, '').optional(),
  address: Joi.string().allow(null, '').optional(),
  notes: Joi.string().allow(null, '').optional(),
});

export const validateSellerApplication = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = sellerApplicationSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// REVIEW APPLICATION
// ============================================================

const reviewApplicationSchema = Joi.object({
  status: Joi.string().valid('APPROVED', 'REJECTED').required().messages({
    'any.required': 'Status is required',
    'any.only': 'Status must be APPROVED or REJECTED',
  }),
  rejectionReason: Joi.string().when('status', {
    is: 'REJECTED',
    then: Joi.required().messages({
      'any.required': 'Rejection reason is required when rejecting',
    }),
    otherwise: Joi.optional(),
  }),
  notes: Joi.string().allow(null, '').optional(),
});

export const validateReviewApplication = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = reviewApplicationSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// SET PASSWORD
// ============================================================

const setPasswordSchema = Joi.object({
  token: Joi.string().required().messages({
    'any.required': 'Token is required',
  }),
  password: Joi.string().min(6).max(100).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'any.required': 'Password is required',
  }),
});

export const validateSetPassword = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = setPasswordSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

