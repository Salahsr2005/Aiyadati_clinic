// src/modules/application/v1/application.controller.ts

import { Request, Response, NextFunction } from 'express';
import { applicationService } from './application.service';
import { ResponseUtil } from '../../../core/utils/response';

export class ApplicationController {
  // ============================================================
  // PUBLIC - Submit applications
  // ============================================================

  submitDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const application = await applicationService.submitDoctor(
        req.body,
        req.ip,
        req.get('user-agent')
      );
      ResponseUtil.created(res, application, 'Doctor application submitted successfully');
    } catch (error) {
      next(error);
    }
  };

  submitClinic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const application = await applicationService.submitClinic(
        req.body,
        req.ip,
        req.get('user-agent')
      );
      ResponseUtil.created(res, application, 'Clinic application submitted successfully');
    } catch (error) {
      next(error);
    }
  };

  submitSeller = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const application = await applicationService.submitSeller(
        req.body,
        req.ip,
        req.get('user-agent')
      );
      ResponseUtil.created(res, application, 'Seller application submitted successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // PUBLIC - Set password
  // ============================================================

  setPassword = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await applicationService.setPassword(req.body);
      ResponseUtil.success(res, result, 'Password set successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // ADMIN - Get applications
  // ============================================================

  getStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const stats = await applicationService.getStats();
      ResponseUtil.success(res, stats, 'Statistics retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const status = req.query.status as string | undefined;
      const type = req.query.type as string | undefined;

      const { applications, total } = await applicationService.listApplications(
        page,
        limit,
        status,
        type
      );

      ResponseUtil.paginated(
        res,
        applications,
        total,
        page,
        limit,
        'Applications retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  get = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const application = await applicationService.getApplication(req.params.id);
      ResponseUtil.success(res, application, 'Application retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // ADMIN - Review
  // ============================================================

  review = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await applicationService.reviewApplication(
        req.params.id,
        req.body,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, result, 'Application reviewed successfully');
    } catch (error) {
      next(error);
    }
  };
}

