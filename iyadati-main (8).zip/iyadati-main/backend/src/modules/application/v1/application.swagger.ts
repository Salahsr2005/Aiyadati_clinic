// src/modules/application/v1/application.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Applications
 *   description: Public registration applications for Doctors, Clinics, and Sellers with Admin review workflow
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     ApplicationType:
 *       type: string
 *       enum: [DOCTOR, CLINIC, SELLER]
 *       description: Type of application being submitted
 *       example: DOCTOR
 *     
 *     ApplicationStatus:
 *       type: string
 *       enum: [PENDING, APPROVED, REJECTED]
 *       description: Current status of the application
 *       example: PENDING
 *     
 *     DoctorApplicationRequest:
 *       type: object
 *       required:
 *         - email
 *         - firstNameFr
 *         - firstNameAr
 *         - lastNameFr
 *         - lastNameAr
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Doctor's email address
 *           example: dr.ahmed.benali@example.com
 *         firstNameFr:
 *           type: string
 *           description: Doctor's first name in French
 *           example: Ahmed
 *         firstNameAr:
 *           type: string
 *           description: Doctor's first name in Arabic
 *           example: أحمد
 *         lastNameFr:
 *           type: string
 *           description: Doctor's last name in French
 *           example: Benali
 *         lastNameAr:
 *           type: string
 *           description: Doctor's last name in Arabic
 *           example: بن علي
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Doctor's phone number (10 digits)
 *           example: "0555123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID where the doctor practices
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         specialties:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: Array of specialty IDs
 *           example: ["550e8400-e29b-41d4-a716-446655440001"]
 *         bioFr:
 *           type: string
 *           description: Doctor's biography in French
 *           example: "Cardiologue expérimenté avec 10 ans de pratique"
 *         bioAr:
 *           type: string
 *           description: Doctor's biography in Arabic
 *           example: "طبيب قلب متمرس مع 10 سنوات من الخبرة"
 *         yearsExp:
 *           type: integer
 *           minimum: 0
 *           maximum: 60
 *           description: Years of experience
 *           example: 10
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *           description: Type of practice
 *           example: INDEPENDENT
 *         notes:
 *           type: string
 *           description: Additional notes
 *           example: "Specialized in interventional cardiology"
 *     
 *     ClinicApplicationRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *         - email
 *         - phone
 *         - wilayaId
 *       properties:
 *         nameFr:
 *           type: string
 *           description: Clinic name in French
 *           example: Clinique El Wouroud
 *         nameAr:
 *           type: string
 *           description: Clinic name in Arabic
 *           example: عيادة الورود
 *         email:
 *           type: string
 *           format: email
 *           description: Clinic email address
 *           example: contact@clinique.dz
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Clinic phone number (10 digits)
 *           example: "0555123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID where the clinic is located
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Baladya (municipality) ID
 *           example: "550e8400-e29b-41d4-a716-446655440003"
 *         descriptionFr:
 *           type: string
 *           description: Clinic description in French
 *           example: "Clinique moderne offrant des soins de qualité"
 *         descriptionAr:
 *           type: string
 *           description: Clinic description in Arabic
 *           example: "عيادة حديثة تقدم رعاية صحية عالية الجودة"
 *         facilityType:
 *           type: string
 *           enum: [CLINIC, HOSPITAL]
 *           description: Type of facility
 *           example: CLINIC
 *         notes:
 *           type: string
 *           description: Additional notes
 *           example: "New clinic with modern equipment"
 *     
 *     SellerApplicationRequest:
 *       type: object
 *       required:
 *         - email
 *         - firstName
 *         - lastName
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Seller's email address
 *           example: seller@example.com
 *         firstName:
 *           type: string
 *           description: Seller's first name
 *           example: Mohamed
 *         lastName:
 *           type: string
 *           description: Seller's last name
 *           example: Khelifi
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           description: Seller's phone number (10 digits)
 *           example: "0555123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID where the seller is based
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Baladya (municipality) ID
 *           example: "550e8400-e29b-41d4-a716-446655440003"
 *         businessName:
 *           type: string
 *           description: Business name (optional)
 *           example: "Pharma Santé"
 *         businessType:
 *           type: string
 *           enum: [INDIVIDUAL, COMPANY, ASSOCIATION]
 *           description: Type of business entity
 *           example: INDIVIDUAL
 *         taxNumber:
 *           type: string
 *           description: Tax identification number (NIF)
 *           example: "1234567890"
 *         regNumber:
 *           type: string
 *           description: Commercial registration number (RC)
 *           example: "9876543210"
 *         address:
 *           type: string
 *           description: Business address
 *           example: "123 Rue des Médecins, Alger"
 *         notes:
 *           type: string
 *           description: Additional notes
 *           example: "Specialized in medical equipment"
 *     
 *     ApplicationResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         type:
 *           $ref: '#/components/schemas/ApplicationType'
 *         status:
 *           $ref: '#/components/schemas/ApplicationStatus'
 *         submittedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-09-03T10:30:00.000Z"
 *         reviewedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-09-04T14:00:00.000Z"
 *         reviewedBy:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           example: "660e8400-e29b-41d4-a716-446655440001"
 *         rejectionReason:
 *           type: string
 *           nullable: true
 *           example: "Incomplete documentation"
 *         createdEntityId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           example: "770e8400-e29b-41d4-a716-446655440002"
 *         createdEntityType:
 *           type: string
 *           nullable: true
 *           enum: [DOCTOR, CLINIC, SELLER]
 *           example: DOCTOR
 *         notes:
 *           type: string
 *           nullable: true
 *         ipAddress:
 *           type: string
 *           nullable: true
 *         userAgent:
 *           type: string
 *           nullable: true
 *         # Doctor fields
 *         doctorEmail:
 *           type: string
 *           nullable: true
 *         doctorFirstNameFr:
 *           type: string
 *           nullable: true
 *         doctorFirstNameAr:
 *           type: string
 *           nullable: true
 *         doctorLastNameFr:
 *           type: string
 *           nullable: true
 *         doctorLastNameAr:
 *           type: string
 *           nullable: true
 *         doctorPhone:
 *           type: string
 *           nullable: true
 *         doctorWilayaId:
 *           type: string
 *           nullable: true
 *         doctorSpecialties:
 *           type: array
 *           items:
 *             type: string
 *           nullable: true
 *         doctorBioFr:
 *           type: string
 *           nullable: true
 *         doctorBioAr:
 *           type: string
 *           nullable: true
 *         doctorYearsExp:
 *           type: integer
 *           nullable: true
 *         doctorPracticeType:
 *           type: string
 *           nullable: true
 *         # Clinic fields
 *         clinicNameFr:
 *           type: string
 *           nullable: true
 *         clinicNameAr:
 *           type: string
 *           nullable: true
 *         clinicEmail:
 *           type: string
 *           nullable: true
 *         clinicPhone:
 *           type: string
 *           nullable: true
 *         clinicWilayaId:
 *           type: string
 *           nullable: true
 *         clinicBaladyaId:
 *           type: string
 *           nullable: true
 *         clinicDescriptionFr:
 *           type: string
 *           nullable: true
 *         clinicDescriptionAr:
 *           type: string
 *           nullable: true
 *         clinicFacilityType:
 *           type: string
 *           nullable: true
 *         # Seller fields
 *         sellerEmail:
 *           type: string
 *           nullable: true
 *         sellerFirstName:
 *           type: string
 *           nullable: true
 *         sellerLastName:
 *           type: string
 *           nullable: true
 *         sellerPhone:
 *           type: string
 *           nullable: true
 *         sellerWilayaId:
 *           type: string
 *           nullable: true
 *         sellerBaladyaId:
 *           type: string
 *           nullable: true
 *         sellerBusinessName:
 *           type: string
 *           nullable: true
 *         sellerBusinessType:
 *           type: string
 *           nullable: true
 *         sellerTaxNumber:
 *           type: string
 *           nullable: true
 *         sellerRegNumber:
 *           type: string
 *           nullable: true
 *         sellerAddress:
 *           type: string
 *           nullable: true
 *     
 *     PaginatedApplicationResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Applications retrieved successfully
 *         data:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ApplicationResponse'
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *               example: 1
 *             limit:
 *               type: integer
 *               example: 20
 *             total:
 *               type: integer
 *               example: 45
 *             totalPages:
 *               type: integer
 *               example: 3
 *             hasNextPage:
 *               type: boolean
 *               example: true
 *             hasPreviousPage:
 *               type: boolean
 *               example: false
 *     
 *     ReviewApplicationRequest:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: [APPROVED, REJECTED]
 *           description: Decision to approve or reject
 *           example: APPROVED
 *         rejectionReason:
 *           type: string
 *           description: Reason for rejection (required when status is REJECTED)
 *           example: "Missing required medical license document"
 *         notes:
 *           type: string
 *           description: Internal admin notes
 *           example: "Application reviewed by Dr. Smith - all documents in order"
 *     
 *     SetPasswordRequest:
 *       type: object
 *       required:
 *         - token
 *         - password
 *       properties:
 *         token:
 *           type: string
 *           description: Password setup token received via email
 *           example: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           maxLength: 100
 *           description: New password (min 6 characters)
 *           example: "MySecurePassword123!"
 *     
 *     SetPasswordResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Password set successfully
 *         data:
 *           type: object
 *           properties:
 *             token:
 *               type: string
 *               description: JWT token for immediate login
 *               example: "eyJhbGciOiJIUzI1NiIs..."
 *             redirectUrl:
 *               type: string
 *               description: URL to redirect to after password setup
 *               example: "/doctor/dashboard"
 *             role:
 *               type: string
 *               enum: [DOCTOR, CLINIC, SELLER]
 *               example: DOCTOR
 *     
 *     DashboardStatsResponse:
 *       type: object
 *       properties:
 *         total:
 *           type: integer
 *           description: Total applications
 *           example: 150
 *         pending:
 *           type: integer
 *           description: Pending applications
 *           example: 25
 *         approved:
 *           type: integer
 *           description: Approved applications
 *           example: 100
 *         rejected:
 *           type: integer
 *           description: Rejected applications
 *           example: 25
 *         byType:
 *           type: object
 *           properties:
 *             doctor:
 *               type: integer
 *               example: 60
 *             clinic:
 *               type: integer
 *               example: 50
 *             seller:
 *               type: integer
 *               example: 40
 *         today:
 *           type: integer
 *           description: Applications submitted today
 *           example: 5
 *     
 *     ErrorResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *         error:
 *           type: string
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *               message:
 *                 type: string
 */

// ============================================================
// PUBLIC ROUTES - DOCTOR
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/doctor:
 *   post:
 *     summary: Submit a Doctor registration application
 *     description: |
 *       Submit an application to register as a doctor on the platform.
 *       
 *       **Flow:**
 *       1. Doctor submits application with personal and professional details
 *       2. Application is saved with `PENDING` status
 *       3. Admin reviews the application
 *       4. If approved → Doctor account is created and password setup email is sent
 *       5. If rejected → Rejection email is sent
 *       
 *       **Rate Limit:** 3 applications per 15 minutes per IP
 *     tags: [Applications]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/DoctorApplicationRequest'
 *           example:
 *             email: "dr.ahmed.benali@example.com"
 *             firstNameFr: "Ahmed"
 *             firstNameAr: "أحمد"
 *             lastNameFr: "Benali"
 *             lastNameAr: "بن علي"
 *             phone: "0555123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             specialties: ["550e8400-e29b-41d4-a716-446655440001"]
 *             bioFr: "Cardiologue expérimenté avec 10 ans de pratique"
 *             bioAr: "طبيب قلب متمرس مع 10 سنوات من الخبرة"
 *             yearsExp: 10
 *             practiceType: "INDEPENDENT"
 *             notes: "Specialized in interventional cardiology"
 *     responses:
 *       201:
 *         description: Doctor application submitted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor application submitted successfully
 *                 data:
 *                   $ref: '#/components/schemas/ApplicationResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             examples:
 *               MissingFields:
 *                 summary: Missing required fields
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Email is required"
 *                     - field: "firstNameFr"
 *                       message: "First name (French) is required"
 *               InvalidEmail:
 *                 summary: Invalid email format
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Valid email is required"
 *               InvalidPhone:
 *                 summary: Invalid phone number
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "phone"
 *                       message: "Phone must be exactly 10 digits"
 *       409:
 *         description: Conflict - pending application already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             example:
 *               success: false
 *               message: "You already have a pending doctor application"
 *               errors:
 *                 - field: "email"
 *                   message: "A pending application already exists for this email"
 *       429:
 *         description: Too many requests
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 */

// ============================================================
// PUBLIC ROUTES - CLINIC
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/clinic:
 *   post:
 *     summary: Submit a Clinic registration application
 *     description: |
 *       Submit an application to register a clinic on the platform.
 *       
 *       **Flow:**
 *       1. Clinic submits application with name, contact, and location details
 *       2. Application is saved with `PENDING` status
 *       3. Admin reviews the application
 *       4. If approved → Clinic account is created and password setup email is sent
 *       5. If rejected → Rejection email is sent
 *       
 *       **Rate Limit:** 3 applications per 15 minutes per IP
 *     tags: [Applications]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ClinicApplicationRequest'
 *           example:
 *             nameFr: "Clinique El Wouroud"
 *             nameAr: "عيادة الورود"
 *             email: "contact@clinique.dz"
 *             phone: "0555123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             baladyaId: "550e8400-e29b-41d4-a716-446655440003"
 *             descriptionFr: "Clinique moderne offrant des soins de qualité"
 *             descriptionAr: "عيادة حديثة تقدم رعاية صحية عالية الجودة"
 *             facilityType: "CLINIC"
 *             notes: "New clinic with modern equipment"
 *     responses:
 *       201:
 *         description: Clinic application submitted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Clinic application submitted successfully
 *                 data:
 *                   $ref: '#/components/schemas/ApplicationResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       409:
 *         description: Conflict - pending application already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       429:
 *         description: Too many requests
 *       500:
 *         description: Internal server error
 */

// ============================================================
// PUBLIC ROUTES - SELLER
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/seller:
 *   post:
 *     summary: Submit a Seller registration application
 *     description: |
 *       Submit an application to register as a medical product seller on the platform.
 *       
 *       **Flow:**
 *       1. Seller submits application with personal and business details
 *       2. Application is saved with `PENDING` status
 *       3. Admin reviews the application
 *       4. If approved → Seller account is created and password setup email is sent
 *       5. If rejected → Rejection email is sent
 *       
 *       **Rate Limit:** 3 applications per 15 minutes per IP
 *     tags: [Applications]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SellerApplicationRequest'
 *           example:
 *             email: "seller@example.com"
 *             firstName: "Mohamed"
 *             lastName: "Khelifi"
 *             phone: "0555123456"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             businessName: "Pharma Santé"
 *             businessType: "INDIVIDUAL"
 *             taxNumber: "1234567890"
 *             regNumber: "9876543210"
 *             address: "123 Rue des Médecins, Alger"
 *             notes: "Specialized in medical equipment"
 *     responses:
 *       201:
 *         description: Seller application submitted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Seller application submitted successfully
 *                 data:
 *                   $ref: '#/components/schemas/ApplicationResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       409:
 *         description: Conflict - pending application already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       429:
 *         description: Too many requests
 *       500:
 *         description: Internal server error
 */

// ============================================================
// PUBLIC ROUTES - SET PASSWORD
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/set-password:
 *   post:
 *     summary: Set password using token from email
 *     description: |
 *       Sets the password for a newly approved account using the token received via email.
 *       
 *       **Flow:**
 *       1. Admin approves application → email sent with `set-password` link
 *       2. User clicks link → redirected to frontend with `token` in URL
 *       3. User enters new password → calls this endpoint
 *       4. Password is set, token is marked as used
 *       5. JWT token is returned → user is automatically logged in
 *       6. User is redirected to their dashboard
 *       
 *       **Token expiry:** 72 hours from approval
 *       
 *       **Rate Limit:** 10 attempts per 15 minutes per IP
 *     tags: [Applications]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SetPasswordRequest'
 *           example:
 *             token: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
 *             password: "MySecurePassword123!"
 *     responses:
 *       200:
 *         description: Password set successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SetPasswordResponse'
 *             examples:
 *               Doctor:
 *                 summary: Doctor account - redirect to doctor dashboard
 *                 value:
 *                   success: true
 *                   message: "Password set successfully"
 *                   data:
 *                     token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                     redirectUrl: "/doctor/dashboard"
 *                     role: "DOCTOR"
 *               Clinic:
 *                 summary: Clinic account - redirect to clinic dashboard
 *                 value:
 *                   success: true
 *                   message: "Password set successfully"
 *                   data:
 *                     token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                     redirectUrl: "/clinic/dashboard"
 *                     role: "CLINIC"
 *               Seller:
 *                 summary: Seller account - redirect to seller dashboard
 *                 value:
 *                   success: true
 *                   message: "Password set successfully"
 *                   data:
 *                     token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                     redirectUrl: "/seller/dashboard"
 *                     role: "SELLER"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             examples:
 *               InvalidToken:
 *                 summary: Invalid or expired token
 *                 value:
 *                   success: false
 *                   message: "Invalid or expired token"
 *               TokenUsed:
 *                 summary: Token already used
 *                 value:
 *                   success: false
 *                   message: "Token already used"
 *               TokenExpired:
 *                 summary: Token has expired
 *                 value:
 *                   success: false
 *                   message: "Token has expired"
 *       404:
 *         description: Account not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       429:
 *         description: Too many attempts
 *       500:
 *         description: Internal server error
 */

// ============================================================
// ADMIN ROUTES - STATS
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/admin/stats:
 *   get:
 *     summary: Get dashboard statistics (Admin only)
 *     description: |
 *       Returns statistics about all applications for the admin dashboard.
 *       
 *       **Data returned:**
 *       - Total applications
 *       - Pending, approved, rejected counts
 *       - Breakdown by type (Doctor, Clinic, Seller)
 *       - Applications submitted today
 *       
 *       **Permissions:** Requires ADMIN or SUPER_ADMIN role
 *     tags: [Applications]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Statistics retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/DashboardStatsResponse'
 *             example:
 *               success: true
 *               message: "Statistics retrieved successfully"
 *               data:
 *                 total: 150
 *                 pending: 25
 *                 approved: 100
 *                 rejected: 25
 *                 byType:
 *                   doctor: 60
 *                   clinic: 50
 *                   seller: 40
 *                 today: 5
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - insufficient permissions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 */

// ============================================================
// ADMIN ROUTES - LIST
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/admin:
 *   get:
 *     summary: List all applications (Admin only)
 *     description: |
 *       Returns a paginated list of all registration applications.
 *       Can filter by status and type.
 *       
 *       **Permissions:** Requires ADMIN or SUPER_ADMIN role
 *     tags: [Applications]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Items per page
 *         example: 20
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [PENDING, APPROVED, REJECTED]
 *         description: Filter by application status
 *         example: PENDING
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [DOCTOR, CLINIC, SELLER]
 *         description: Filter by application type
 *         example: DOCTOR
 *     responses:
 *       200:
 *         description: Applications retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedApplicationResponse'
 *             examples:
 *               AllApplications:
 *                 summary: List of all applications
 *                 value:
 *                   success: true
 *                   message: "Applications retrieved successfully"
 *                   data:
 *                     - id: "550e8400-e29b-41d4-a716-446655440000"
 *                       type: "DOCTOR"
 *                       status: "PENDING"
 *                       submittedAt: "2026-09-03T10:30:00.000Z"
 *                       doctorEmail: "dr.ahmed.benali@example.com"
 *                       doctorFirstNameFr: "Ahmed"
 *                       doctorLastNameFr: "Benali"
 *                     - id: "550e8400-e29b-41d4-a716-446655440001"
 *                       type: "CLINIC"
 *                       status: "APPROVED"
 *                       submittedAt: "2026-09-02T11:00:00.000Z"
 *                       reviewedAt: "2026-09-03T09:00:00.000Z"
 *                       reviewedBy: "660e8400-e29b-41d4-a716-446655440001"
 *                       createdEntityId: "770e8400-e29b-41d4-a716-446655440002"
 *                       createdEntityType: "CLINIC"
 *                       clinicNameFr: "Clinique El Wouroud"
 *                       clinicEmail: "contact@clinique.dz"
 *                   meta:
 *                     page: 1
 *                     limit: 20
 *                     total: 2
 *                     totalPages: 1
 *                     hasNextPage: false
 *                     hasPreviousPage: false
 *               FilteredPending:
 *                 summary: Filter by PENDING status
 *                 value:
 *                   success: true
 *                   message: "Applications retrieved successfully"
 *                   data:
 *                     - id: "550e8400-e29b-41d4-a716-446655440000"
 *                       type: "DOCTOR"
 *                       status: "PENDING"
 *                       submittedAt: "2026-09-03T10:30:00.000Z"
 *                       doctorEmail: "dr.ahmed.benali@example.com"
 *                   meta:
 *                     page: 1
 *                     limit: 20
 *                     total: 1
 *                     totalPages: 1
 *                     hasNextPage: false
 *                     hasPreviousPage: false
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - insufficient permissions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 */

// ============================================================
// ADMIN ROUTES - GET BY ID
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/admin/{id}:
 *   get:
 *     summary: Get a single application by ID (Admin only)
 *     description: |
 *       Returns detailed information about a specific application.
 *       
 *       **Permissions:** Requires ADMIN or SUPER_ADMIN role
 *     tags: [Applications]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Application ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Application retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Application retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/ApplicationResponse'
 *             example:
 *               success: true
 *               message: "Application retrieved successfully"
 *               data:
 *                 id: "550e8400-e29b-41d4-a716-446655440000"
 *                 type: "DOCTOR"
 *                 status: "PENDING"
 *                 submittedAt: "2026-09-03T10:30:00.000Z"
 *                 doctorEmail: "dr.ahmed.benali@example.com"
 *                 doctorFirstNameFr: "Ahmed"
 *                 doctorFirstNameAr: "أحمد"
 *                 doctorLastNameFr: "Benali"
 *                 doctorLastNameAr: "بن علي"
 *                 doctorPhone: "0555123456"
 *                 doctorWilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *                 doctorSpecialties: ["550e8400-e29b-41d4-a716-446655440001"]
 *                 doctorBioFr: "Cardiologue expérimenté avec 10 ans de pratique"
 *                 doctorYearsExp: 10
 *                 doctorPracticeType: "INDEPENDENT"
 *                 notes: "Specialized in interventional cardiology"
 *                 ipAddress: "192.168.1.1"
 *                 userAgent: "Mozilla/5.0..."
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - insufficient permissions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Application not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 */

// ============================================================
// ADMIN ROUTES - REVIEW
// ============================================================

/**
 * @swagger
 * /api/v1/applications/v1/admin/{id}/review:
 *   patch:
 *     summary: Review an application (Approve/Reject) - Admin only
 *     description: |
 *       Approve or reject a pending application.
 *       
 *       **If APPROVED:**
 *       1. Account is created (Doctor/Clinic/Seller)
 *       2. Random temporary password is generated
 *       3. Password setup token is created (valid 72 hours)
 *       4. Email is sent with "Set Password" button
 *       5. Application status becomes `APPROVED`
 *       6. `createdEntityId` and `createdEntityType` are set
 *       
 *       **If REJECTED:**
 *       1. Application status becomes `REJECTED`
 *       2. Rejection reason is recorded
 *       3. Rejection email is sent to the applicant
 *       
 *       **Permissions:** Requires ADMIN or SUPER_ADMIN role
 *     tags: [Applications]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Application ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ReviewApplicationRequest'
 *           examples:
 *             ApproveDoctor:
 *               summary: Approve a doctor application
 *               value:
 *                 status: "APPROVED"
 *                 notes: "All documents verified. Approved."
 *             RejectDoctor:
 *               summary: Reject a doctor application
 *               value:
 *                 status: "REJECTED"
 *                 rejectionReason: "Missing required medical license document"
 *                 notes: "Applicant needs to upload valid medical license"
 *     responses:
 *       200:
 *         description: Application reviewed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Application reviewed successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     application:
 *                       $ref: '#/components/schemas/ApplicationResponse'
 *                     entity:
 *                       type: object
 *                       nullable: true
 *                       description: The created account (only when APPROVED)
 *                     entityType:
 *                       type: string
 *                       nullable: true
 *                       description: Type of created account
 *             examples:
 *               Approved:
 *                 summary: Application approved - account created
 *                 value:
 *                   success: true
 *                   message: "Application reviewed successfully"
 *                   data:
 *                     application:
 *                       id: "550e8400-e29b-41d4-a716-446655440000"
 *                       type: "DOCTOR"
 *                       status: "APPROVED"
 *                       submittedAt: "2026-09-03T10:30:00.000Z"
 *                       reviewedAt: "2026-09-04T14:00:00.000Z"
 *                       reviewedBy: "660e8400-e29b-41d4-a716-446655440001"
 *                       createdEntityId: "770e8400-e29b-41d4-a716-446655440002"
 *                       createdEntityType: "DOCTOR"
 *                       doctorEmail: "dr.ahmed.benali@example.com"
 *                     entity:
 *                       id: "770e8400-e29b-41d4-a716-446655440002"
 *                       email: "dr.ahmed.benali@example.com"
 *                       firstNameFr: "Ahmed"
 *                       lastNameFr: "Benali"
 *                       isVerified: true
 *                     entityType: "DOCTOR"
 *               Rejected:
 *                 summary: Application rejected
 *                 value:
 *                   success: true
 *                   message: "Application reviewed successfully"
 *                   data:
 *                     application:
 *                       id: "550e8400-e29b-41d4-a716-446655440000"
 *                       type: "DOCTOR"
 *                       status: "REJECTED"
 *                       submittedAt: "2026-09-03T10:30:00.000Z"
 *                       reviewedAt: "2026-09-04T14:00:00.000Z"
 *                       reviewedBy: "660e8400-e29b-41d4-a716-446655440001"
 *                       rejectionReason: "Missing required medical license document"
 *                       doctorEmail: "dr.ahmed.benali@example.com"
 *                     entity: null
 *                     entityType: null
 *       400:
 *         description: Validation error or application not pending
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             examples:
 *               AlreadyReviewed:
 *                 summary: Application already reviewed
 *                 value:
 *                   success: false
 *                   message: "Application is already approved"
 *                   error: "Application is already approved"
 *               MissingRejectionReason:
 *                 summary: Rejection reason required for REJECTED
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "rejectionReason"
 *                       message: "Rejection reason is required when rejecting"
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - insufficient permissions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Application not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       409:
 *         description: Conflict - email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 */