// src/modules/application/v1/application.routes.ts

import { Router } from 'express';
import { ApplicationController } from './application.controller';
import {
  validateDoctorApplication,
  validateClinicApplication,
  validateSellerApplication,
  validateReviewApplication,
  validateSetPassword,
} from './application.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';

const router = Router();
const controller = new ApplicationController();

// ============================================================
// PUBLIC ROUTES - SEPARATE PER TYPE
// ============================================================

// 🩺 Doctor application
router.post(
  '/doctor',
  createRateLimiter({ windowMinutes: 15, maxRequests: 3, message: 'Too many applications' }),
  validateDoctorApplication,
  controller.submitDoctor
);

// 🏥 Clinic application
router.post(
  '/clinic',
  createRateLimiter({ windowMinutes: 15, maxRequests: 3, message: 'Too many applications' }),
  validateClinicApplication,
  controller.submitClinic
);

// 🛒 Seller application
router.post(
  '/seller',
  createRateLimiter({ windowMinutes: 15, maxRequests: 3, message: 'Too many applications' }),
  validateSellerApplication,
  controller.submitSeller
);

// 🔐 Set password from token
router.post(
  '/set-password',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many attempts' }),
  validateSetPassword,
  controller.setPassword
);

// ============================================================
// ADMIN ROUTES
// ============================================================

router.use(authenticate);

// 📊 Dashboard stats
router.get(
  '/admin/stats',
  authorize('ADMIN', 'SUPER_ADMIN'),
  controller.getStats
);

// 📋 List all applications
router.get(
  '/admin',
  authorize('ADMIN', 'SUPER_ADMIN'),
  controller.list
);

// 📄 Get single application
router.get(
  '/admin/:id',
  authorize('ADMIN', 'SUPER_ADMIN'),
  controller.get
);

// ✅ Review application
router.patch(
  '/admin/:id/review',
  authorize('ADMIN', 'SUPER_ADMIN'),
  validateReviewApplication,
  controller.review
);

export default router;

