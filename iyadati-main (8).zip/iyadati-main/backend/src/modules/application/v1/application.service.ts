import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { Prisma, ApplicationStatus, ApplicationType } from '@prisma/client';

import { applicationRepository } from '../../../repositories/application.repository';
import { passwordSetupTokenRepository } from '../../../repositories/password-setup-token.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { sellerRepository } from '../../../repositories/seller.repository';

import {
  ConflictError,
  NotFoundError,
  BadRequestError,
} from '../../../core/utils/error';

import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { env } from '../../../config/env';

import {
  DoctorApplicationDTO,
  ClinicApplicationDTO,
  SellerApplicationDTO,
  ReviewApplicationDTO,
  SetPasswordDTO,
} from './application.types';

import { prisma } from '../../../config/database';

const JWT_SECRET =
  env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

const BASE_URL =
  env.BASE_URL || 'http://localhost:3975';

export class ApplicationService {
  // ============================================================
  // SUBMIT DOCTOR APPLICATION
  // ============================================================

  async submitDoctor(
    data: DoctorApplicationDTO,
    ip?: string,
    userAgent?: string
  ) {
    const existing =
      await applicationRepository.findByEmailAndType(
        data.email,
        'DOCTOR'
      );

    if (existing) {
      throw new ConflictError(
        'You already have a pending doctor application',
        [
          {
            field: 'email',
            message:
              'A pending application already exists for this email',
          },
        ]
      );
    }

    const applicationData = {
      type: 'DOCTOR' as ApplicationType,
      status: 'PENDING' as ApplicationStatus,
      submittedAt: new Date(),
      ipAddress: ip,
      userAgent: userAgent,
      notes: data.notes,

      doctorEmail: data.email,
      doctorFirstNameFr: data.firstNameFr,
      doctorFirstNameAr: data.firstNameAr,
      doctorLastNameFr: data.lastNameFr,
      doctorLastNameAr: data.lastNameAr,
      doctorPhone: data.phone,
      doctorWilayaId: data.wilayaId,
      doctorSpecialties: data.specialties || [],
      doctorBioFr: data.bioFr,
      doctorBioAr: data.bioAr,
      doctorYearsExp: data.yearsExp,
      doctorPracticeType: data.practiceType,
    };

    const application =
      await applicationRepository.create(
        applicationData
      );

    eventEmitter.emit('admin-notification', {
      type: 'new_doctor_application',
      applicationId: application.id,
      message: `New doctor application from ${data.firstNameFr} ${data.lastNameFr}`,
    });

    logger.info(
      `New doctor application: ${application.id} - ${data.email}`
    );

    return application;
  }

  // ============================================================
  // SUBMIT CLINIC APPLICATION
  // ============================================================

  async submitClinic(
    data: ClinicApplicationDTO,
    ip?: string,
    userAgent?: string
  ) {
    const existing =
      await applicationRepository.findByEmailAndType(
        data.email,
        'CLINIC'
      );

    if (existing) {
      throw new ConflictError(
        'You already have a pending clinic application',
        [
          {
            field: 'email',
            message:
              'A pending application already exists for this email',
          },
        ]
      );
    }

    const applicationData = {
      type: 'CLINIC' as ApplicationType,
      status: 'PENDING' as ApplicationStatus,
      submittedAt: new Date(),
      ipAddress: ip,
      userAgent: userAgent,
      notes: data.notes,

      clinicNameFr: data.nameFr,
      clinicNameAr: data.nameAr,
      clinicEmail: data.email,
      clinicPhone: data.phone,
      clinicWilayaId: data.wilayaId,
      clinicBaladyaId: data.baladyaId,
      clinicDescriptionFr: data.descriptionFr,
      clinicDescriptionAr: data.descriptionAr,
      clinicFacilityType: data.facilityType,
    };

    const application =
      await applicationRepository.create(
        applicationData
      );

    eventEmitter.emit('admin-notification', {
      type: 'new_clinic_application',
      applicationId: application.id,
      message: `New clinic application from ${data.nameFr}`,
    });

    logger.info(
      `New clinic application: ${application.id} - ${data.email}`
    );

    return application;
  }

  // ============================================================
  // SUBMIT SELLER APPLICATION
  // ============================================================

  async submitSeller(
    data: SellerApplicationDTO,
    ip?: string,
    userAgent?: string
  ) {
    const existing =
      await applicationRepository.findByEmailAndType(
        data.email,
        'SELLER'
      );

    if (existing) {
      throw new ConflictError(
        'You already have a pending seller application',
        [
          {
            field: 'email',
            message:
              'A pending application already exists for this email',
          },
        ]
      );
    }

    const applicationData = {
      type: 'SELLER' as ApplicationType,
      status: 'PENDING' as ApplicationStatus,
      submittedAt: new Date(),
      ipAddress: ip,
      userAgent: userAgent,
      notes: data.notes,

      sellerEmail: data.email,
      sellerFirstName: data.firstName,
      sellerLastName: data.lastName,
      sellerPhone: data.phone,
      sellerWilayaId: data.wilayaId,
      sellerBaladyaId: data.baladyaId,
      sellerBusinessName: data.businessName,
      sellerBusinessType: data.businessType,
      sellerTaxNumber: data.taxNumber,
      sellerRegNumber: data.regNumber,
      sellerAddress: data.address,
    };

    const application =
      await applicationRepository.create(
        applicationData
      );

    eventEmitter.emit('admin-notification', {
      type: 'new_seller_application',
      applicationId: application.id,
      message: `New seller application from ${data.firstName} ${data.lastName}`,
    });

    logger.info(
      `New seller application: ${application.id} - ${data.email}`
    );

    return application;
  }

  // ============================================================
  // GET APPLICATION
  // ============================================================

  async getApplication(id: string) {
    const application =
      await applicationRepository.findById(id);

    if (!application) {
      throw new NotFoundError('Application');
    }

    return application;
  }

  // ============================================================
  // LIST APPLICATIONS
  // ============================================================

  async listApplications(
    page: number,
    limit: number,
    status?: string,
    type?: string
  ) {
    return applicationRepository.findAll({
      page,
      limit,
      status: status as ApplicationStatus,
      type: type as ApplicationType,
    });
  }

  // ============================================================
  // GET STATS
  // ============================================================

  async getStats() {
    const [
      total,
      pending,
      approved,
      rejected,
      doctorCount,
      clinicCount,
      sellerCount,
    ] = await Promise.all([
      prisma.registrationApplication.count(),

      prisma.registrationApplication.count({
        where: {
          status: 'PENDING',
        },
      }),

      prisma.registrationApplication.count({
        where: {
          status: 'APPROVED',
        },
      }),

      prisma.registrationApplication.count({
        where: {
          status: 'REJECTED',
        },
      }),

      prisma.registrationApplication.count({
        where: {
          type: 'DOCTOR',
        },
      }),

      prisma.registrationApplication.count({
        where: {
          type: 'CLINIC',
        },
      }),

      prisma.registrationApplication.count({
        where: {
          type: 'SELLER',
        },
      }),
    ]);

    const today = new Date();

    today.setHours(0, 0, 0, 0);

    const todayCount =
      await prisma.registrationApplication.count({
        where: {
          submittedAt: {
            gte: today,
          },
        },
      });

    return {
      total,
      pending,
      approved,
      rejected,

      byType: {
        doctor: doctorCount,
        clinic: clinicCount,
        seller: sellerCount,
      },

      today: todayCount,
    };
  }

  // ============================================================
  // REVIEW APPLICATION
  // ============================================================

  async reviewApplication(
    applicationId: string,
    data: ReviewApplicationDTO,
    reviewerId: string,
    ip?: string
  ) {
    const application =
      await applicationRepository.findById(
        applicationId
      );

    if (!application) {
      throw new NotFoundError('Application');
    }

    if (application.status !== 'PENDING') {
      throw new BadRequestError(
        `Application is already ${application.status.toLowerCase()}`
      );
    }

    // ============================================================
    // REJECT
    // ============================================================

    if (data.status === 'REJECTED') {
      const updated =
        await applicationRepository.reject(
          applicationId,
          {
            reviewedBy: reviewerId,
            reviewedAt: new Date(),
            rejectionReason:
              data.rejectionReason,
            notes: data.notes,
          }
        );

      await this.sendRejectionEmail(
        application
      );

      logger.info(
        `Application ${applicationId} rejected by ${reviewerId}`
      );

      return updated;
    }

    // ============================================================
    // APPROVE
    // ============================================================

    if (data.status === 'APPROVED') {
      const randomPassword =
        crypto.randomBytes(20).toString('hex');

      const hashedPassword =
        await bcrypt.hash(
          randomPassword,
          12
        );

      const {
        entity,
        entityType,
      } =
        await this.createAccountFromApplication(
          application,
          hashedPassword
        );

      await applicationRepository.approveWithEntity(
        applicationId,
        {
          entityId: entity.id,
          entityType: entityType,
          reviewedBy: reviewerId,
          reviewedAt: new Date(),
        }
      );

      const token =
        await passwordSetupTokenRepository.create(
          entity.id,
          entityType
        );

      await this.sendPasswordSetupEmail(
        application,
        entity,
        token
      );

      logger.info(
        `Application ${applicationId} approved, ${entityType} created: ${entity.id}`
      );

      return {
        application:
          await applicationRepository.findById(
            applicationId
          ),
        entity,
        entityType,
      };
    }

    throw new BadRequestError(
      'Invalid status'
    );
  }

  // ============================================================
  // SET PASSWORD
  // ============================================================

  async setPassword(
    data: SetPasswordDTO
  ) {
    const tokenRecord =
      await passwordSetupTokenRepository.findByToken(
        data.token
      );

    if (!tokenRecord) {
      throw new BadRequestError(
        'Invalid or expired token'
      );
    }

    if (tokenRecord.usedAt) {
      throw new BadRequestError(
        'Token already used'
      );
    }

    if (
      new Date() >
      tokenRecord.expiresAt
    ) {
      throw new BadRequestError(
        'Token has expired'
      );
    }

    const hashedPassword =
      await bcrypt.hash(
        data.password,
        12
      );

    let entity: any;

    const ownerType =
      tokenRecord.ownerType;

    // ============================================================
    // DOCTOR
    // ============================================================

    if (ownerType === 'DOCTOR') {
      entity =
        await doctorRepository.findById(
          tokenRecord.ownerId
        );

      if (!entity) {
        throw new NotFoundError(
          'Doctor'
        );
      }

      entity =
        await doctorRepository.update(
          entity.id,
          {
            password: hashedPassword,
          }
        );
    }

    // ============================================================
    // CLINIC
    // ============================================================

    else if (ownerType === 'CLINIC') {
      entity =
        await clinicRepository.findById(
          tokenRecord.ownerId
        );

      if (!entity) {
        throw new NotFoundError(
          'Clinic'
        );
      }

      entity =
        await clinicRepository.update(
          entity.id,
          {
            password: hashedPassword,
          }
        );
    }

    // ============================================================
    // SELLER
    // ============================================================

    else if (ownerType === 'SELLER') {
      entity =
        await sellerRepository.findById(
          tokenRecord.ownerId
        );

      if (!entity) {
        throw new NotFoundError(
          'Seller'
        );
      }

      entity =
        await sellerRepository.update(
          entity.id,
          {
            password: hashedPassword,
          }
        );
    }

    else {
      throw new BadRequestError(
        'Unknown account type'
      );
    }

    await passwordSetupTokenRepository.markAsUsed(
      data.token
    );

    const jwtToken = jwt.sign(
      {
        id: entity.id,
        email: entity.email,
        role: ownerType,
        name:
          entity.name ||
          entity.firstNameFr ||
          entity.firstName,
      },
      JWT_SECRET,
      {
        expiresIn: '7d',
      }
    );

    const dashboardPath =
      ownerType === 'DOCTOR'
        ? '/doctor/dashboard'
        : ownerType === 'CLINIC'
          ? '/clinic/dashboard'
          : '/seller/dashboard';

    logger.info(
      `Password set for ${ownerType}: ${entity.email}`
    );

    return {
      token: jwtToken,
      redirectUrl: dashboardPath,
      role: ownerType,
      entity,
    };
  }

  // ============================================================
  // CREATE ACCOUNT FROM APPLICATION
  // ============================================================

  private async createAccountFromApplication(
    application: any,
    hashedPassword: string
  ) {
    // ============================================================
    // DOCTOR
    // ============================================================

    if (application.type === 'DOCTOR') {
      const doctor =
        await doctorRepository.create({
          email:
            application.doctorEmail,

          password:
            hashedPassword,

          firstNameFr:
            application.doctorFirstNameFr,

          firstNameAr:
            application.doctorFirstNameAr,

          lastNameFr:
            application.doctorLastNameFr,

          lastNameAr:
            application.doctorLastNameAr,

          phone:
            application.doctorPhone,

          wilayaId:
            application.doctorWilayaId,

          isVerified: true,

          isCompleted: false,
        });

      const updateData: any = {};

      if (
        application.doctorBioFr !==
        undefined
      ) {
        updateData.bioFr =
          application.doctorBioFr;
      }

      if (
        application.doctorBioAr !==
        undefined
      ) {
        updateData.bioAr =
          application.doctorBioAr;
      }

      if (
        application.doctorYearsExp !==
        undefined
      ) {
        updateData.yearsOfExp =
          application.doctorYearsExp;
      }

      if (
        application.doctorPracticeType !==
        undefined
      ) {
        updateData.practiceType =
          application.doctorPracticeType;
      }

      if (
        Object.keys(updateData).length > 0
      ) {
        await prisma.doctor.update({
          where: {
            id: doctor.id,
          },
          data: updateData,
        });
      }

      if (
        application.doctorSpecialties?.length >
        0
      ) {
        for (
          const specialtyId of
          application.doctorSpecialties
        ) {
          try {
            await prisma.doctorSpecialty.create({
              data: {
                doctorId: doctor.id,
                specialtyId,
              },
            });
          } catch (e) {
            // Ignore duplicate/invalid specialty
          }
        }
      }

      await prisma.doctorConfig.create({
        data: {
          doctorId: doctor.id,
        },
      });

      return {
        entity: doctor,
        entityType: 'DOCTOR',
      };
    }

    // ============================================================
    // CLINIC
    // ============================================================

    if (application.type === 'CLINIC') {
      const clinic =
        await clinicRepository.create({
          nameFr:
            application.clinicNameFr,

          nameAr:
            application.clinicNameAr,

          email:
            application.clinicEmail,

          phone:
            application.clinicPhone,

          password:
            hashedPassword,

          /*
           * ClinicCreateInput expects the
           * relation instead of wilayaId.
           */
          wilaya: {
            connect: {
              id:
                application.clinicWilayaId,
            },
          },

          isVerified: true,

          isCompleted: false,
        });

      const updateData: any = {};

      if (
        application.clinicBaladyaId !==
        undefined
      ) {
        updateData.baladyaId =
          application.clinicBaladyaId;
      }

      if (
        application.clinicDescriptionFr !==
        undefined
      ) {
        updateData.descriptionFr =
          application.clinicDescriptionFr;
      }

      if (
        application.clinicDescriptionAr !==
        undefined
      ) {
        updateData.descriptionAr =
          application.clinicDescriptionAr;
      }

      if (
        application.clinicFacilityType !==
        undefined
      ) {
        updateData.facilityType =
          application.clinicFacilityType;
      }

      if (
        Object.keys(updateData).length > 0
      ) {
        await prisma.clinic.update({
          where: {
            id: clinic.id,
          },
          data: updateData,
        });
      }

      return {
        entity: clinic,
        entityType: 'CLINIC',
      };
    }

    // ============================================================
    // SELLER
    // ============================================================

    if (application.type === 'SELLER') {
      const seller =
        await sellerRepository.create({
          email:
            application.sellerEmail,

          password:
            hashedPassword,

          firstName:
            application.sellerFirstName,

          lastName:
            application.sellerLastName,

          phone:
            application.sellerPhone,

          /*
           * SellerCreateInput expects wilayaId.
           */
          wilayaId:
            application.sellerWilayaId,
        });

      const updateData: any = {
        status: 'ACTIVE',
        isVerified: true,
      };

      if (
        application.sellerBaladyaId !==
        undefined
      ) {
        updateData.baladyaId =
          application.sellerBaladyaId;
      }

      if (
        application.sellerBusinessName !==
        undefined
      ) {
        updateData.businessName =
          application.sellerBusinessName;
      }

      if (
        application.sellerBusinessType !==
        undefined
      ) {
        updateData.businessType =
          application.sellerBusinessType;
      }

      if (
        application.sellerTaxNumber !==
        undefined
      ) {
        updateData.taxNumber =
          application.sellerTaxNumber;
      }

      if (
        application.sellerRegNumber !==
        undefined
      ) {
        updateData.registrationNumber =
          application.sellerRegNumber;
      }

      if (
        application.sellerAddress !==
        undefined
      ) {
        updateData.address =
          application.sellerAddress;
      }

      await prisma.seller.update({
        where: {
          id: seller.id,
        },
        data: updateData,
      });

      return {
        entity: seller,
        entityType: 'SELLER',
      };
    }

    throw new Error(
      `Unknown application type: ${application.type}`
    );
  }

  // ============================================================
  // SEND PASSWORD SETUP EMAIL
  // ============================================================

  private async sendPasswordSetupEmail(
    application: any,
    entity: any,
    token: any
  ) {
    let email: string;
    let name: string;
    let type: string;

    if (application.type === 'DOCTOR') {
      email = entity.email;

      name =
        `${entity.firstNameFr} ${entity.lastNameFr}`;

      type = 'Doctor';
    }

    else if (
      application.type === 'CLINIC'
    ) {
      email = entity.email;

      name = entity.nameFr;

      type = 'Clinic';
    }

    else if (
      application.type === 'SELLER'
    ) {
      email = entity.email;

      name =
        `${entity.firstName} ${entity.lastName}`;

      type = 'Seller';
    }

    else {
      return;
    }

    const setupUrl =
      `${BASE_URL}/set-password?token=${token.token}`;

    eventEmitter.emit(
      'send-password-setup-email',
      {
        email,
        name,
        type,
        setupUrl,
      }
    );
  }

  // ============================================================
  // SEND REJECTION EMAIL
  // ============================================================

  private async sendRejectionEmail(
    application: any
  ) {
    let email: string;
    let name: string;
    let type: string;

    if (
      application.type === 'DOCTOR'
    ) {
      email =
        application.doctorEmail;

      name =
        `${application.doctorFirstNameFr} ${application.doctorLastNameFr}`;

      type = 'Doctor';
    }

    else if (
      application.type === 'CLINIC'
    ) {
      email =
        application.clinicEmail;

      name =
        application.clinicNameFr;

      type = 'Clinic';
    }

    else if (
      application.type === 'SELLER'
    ) {
      email =
        application.sellerEmail;

      name =
        `${application.sellerFirstName} ${application.sellerLastName}`;

      type = 'Seller';
    }

    else {
      return;
    }

    eventEmitter.emit(
      'send-application-rejection-email',
      {
        email,
        name,
        type,
        reason:
          application.rejectionReason,
      }
    );
  }
}

export const applicationService =  new ApplicationService();
