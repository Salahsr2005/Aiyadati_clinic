import path from 'path';
import fs from 'fs/promises';
import { specialtyRepository } from '../../../repositories/specialty.repository';
import { NotFoundError, ConflictError, DatabaseError } from '../../../core/utils/error';
import { generatePublicUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { CreateSpecialtyDTO, UpdateSpecialtyDTO, SpecialtyResponse } from './specialty.types';
import { env } from '../../../config/env';
import { fileService } from '../../../modules/file/v1/file.service';
import { StorageFactory } from '../../../core/storage/storage.factory';

import { specialtyCache } from './cache/specialty.cache';

export class SpecialtyService {
  private toResponse(s: any): SpecialtyResponse {
    return {
      id: s.id,
      nameFr: s.nameFr,
      nameAr: s.nameAr,
      descriptionFr: s.descriptionFr,
      descriptionAr: s.descriptionAr,
      imagePath: s.imagePath,
      imageUrl: s.fileId 
        ? generatePublicUrl(s.fileId) 
        : null,
      isActive: s.isActive,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
    };
  }

  async findAll(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      search: params.search || undefined,
      isActive: params.isActive !== undefined ? params.isActive === 'true' : undefined,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };

    const cacheKey = JSON.stringify(parsedParams);

    return specialtyCache.rememberAll(
      cacheKey,
      async () => {
        const { specialties, total } = await specialtyRepository.findAll(parsedParams);
        return {
          specialties: specialties.map((s: any) => this.toResponse(s)),
          total,
        };
      },
    );
  }

  async findById(id: string): Promise<SpecialtyResponse> {
    return specialtyCache.rememberById(
      id,
      async () => {
        const specialty = await specialtyRepository.findById(id);
        if (!specialty) {
          throw new NotFoundError('Specialty');
        }
        return this.toResponse(specialty);
      },
    );
  }

  async create(data: CreateSpecialtyDTO): Promise<SpecialtyResponse> {
    try {
      const specialty = await specialtyRepository.create({
        nameFr: data.nameFr,
        nameAr: data.nameAr,
        descriptionFr: data.descriptionFr,
        descriptionAr: data.descriptionAr,
      });
      await specialtyCache.invalidateAll();
      logger.info(`Specialty created: ${specialty.nameFr}`);
      return this.toResponse(specialty);
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ConflictError('Specialty name already exists', [
          {
            field: 'name',
            message: 'A specialty with this name already exists',
          },
        ]);
      }
      throw new DatabaseError('Failed to create specialty');
    }
  }

  async update(id: string, data: UpdateSpecialtyDTO): Promise<SpecialtyResponse> {
    const existing = await specialtyRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Specialty');
    }

    try {
      const updated = await specialtyRepository.update(id, data);
      await specialtyCache.invalidate(id);
      return this.toResponse(updated);
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ConflictError('Specialty name already exists');
      }
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    const existing = await specialtyRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Specialty');
    }

    if (existing.fileId) {
      await fileService.deleteFile(existing.fileId, 'SYSTEM', 'SUPER_ADMIN', true);
    }

    await specialtyRepository.softDelete(id);
    await specialtyCache.invalidate(id);
    logger.info(`Specialty deleted: ${existing.nameFr}`);
  }

  async restore(id: string): Promise<SpecialtyResponse> {
    const existing = await specialtyRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Specialty');
    }
    const restored = await specialtyRepository.restore(id);
    await specialtyCache.invalidate(id);
    return this.toResponse(restored);
  }

  async uploadImage(id: string, file: Express.Multer.File): Promise<SpecialtyResponse> {
    const existing = await specialtyRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Specialty');
    }

    // Delete old file if exists
    if (existing.fileId) {
      try {
        await fileService.deleteFile(existing.fileId, 'SYSTEM', 'SUPER_ADMIN', true);
      } catch (error) {
        logger.warn(`Failed to delete old file for specialty ${id}: ${existing.imagePath}`, error);
      }
    }

    // Upload new file to SeaweedFS
    const storage = StorageFactory.getInstance();

    const uploadResult = await storage.upload(
      {
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
      },
      {
        path: 'public/logos',
        isPublic: true,
        contentType: file.mimetype,
        cacheControl: 'public, max-age=31536000',
        metadata: {
          specialtyId: id,
          originalName: file.originalname,
        },
      }
    );

    const updated = await specialtyRepository.update(id, {
      imagePath: uploadResult.key,
      fileId: uploadResult.id,
    });

    await specialtyCache.invalidate(id);
    logger.info(`Image uploaded for specialty ${id}: ${file.originalname}`);
    return this.toResponse(updated);
  }
}

export const specialtyService = new SpecialtyService();

