import { JobsOptions, Queue } from 'bullmq';
import { bullMqConnection } from '../connection';

export enum SlotGenerationJobName {
  GENERATE_SLOTS = 'generate-slots',
  CHECK_RULES = 'check-rules',
  CLEAN_EXPIRED_SLOTS = 'clean-expired-slots', // 👈 NEW
}

export interface GenerateSlotsPayload {
  ruleId: string;
  doctorId: string;
  bookingWindowDays: number;
  clinicId?: string;
  roomId?: string;
  frequency: string;
}

class SlotGenerationQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('slot-generation', {
      connection: bullMqConnection,
    });
  }

  public async enqueueGenerateSlots(
    payload: GenerateSlotsPayload,
    options?: JobsOptions
  ): Promise<void> {
    await this.queue.add(
      SlotGenerationJobName.GENERATE_SLOTS,
      payload,
      {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 5000,
        },
        removeOnComplete: 1000,
        removeOnFail: 5000,
        ...options,
      }
    );
  }

  public async enqueueCheckRules(): Promise<void> {
    await this.queue.add(
      SlotGenerationJobName.CHECK_RULES,
      {},
      {
        jobId: 'check-rules',
      }
    );
  }

  // 👇 NEW METHOD
  public async enqueueCleanExpiredSlots(): Promise<void> {
    await this.queue.add(
      SlotGenerationJobName.CLEAN_EXPIRED_SLOTS,
      {},
      {
        jobId: 'clean-expired-slots',
        repeat: {
          pattern: '0 * * * *', // Every hour
        },
        removeOnComplete: true,
        removeOnFail: true,
      }
    );
  }

  public getQueue(): Queue {
    return this.queue;
  }

  public async close(): Promise<void> {
    await this.queue.close();
  }
}

export const slotGenerationQueue = new SlotGenerationQueueService();

