// src/infrastructure/queues/email/email.jobs.ts

export enum EmailJobName {
  // Existing
  SEND_OTP = 'send-otp',
  SEND_PASSWORD_SETUP = 'send-password-setup',
  SEND_APPLICATION_REJECTION = 'send-application-rejection',
  SEND_ADMIN_NOTIFICATION = 'send-admin-notification',

  // Password Reset
  SEND_PASSWORD_RESET = 'send-password-reset',

  // Future
  SEND_WELCOME = 'send-welcome',
  RESET_PASSWORD = 'reset-password',
  APPOINTMENT_REMINDER = 'appointment-reminder',
}

