// src/infrastructure/queues/email/templates/password-setup.template.ts

import { SendPasswordSetupEmailPayload } from '../email.types';

export interface EmailTemplate {
  subject: string;
  html: string;
}

export const generatePasswordSetupEmail = (
  payload: SendPasswordSetupEmailPayload
): EmailTemplate => ({
  subject: `🎉 Your ${payload.type} account is approved!`,

  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8f9fa; border-radius: 12px;">
      
      <!-- Header -->
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #6B21A8; margin: 0;">Iyadati</h1>
        <p style="color: #6B7280; margin: 5px 0 0;">Your Health Partner</p>
      </div>
      
      <!-- Main Content -->
      <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h2 style="color: #1F2937; margin-top: 0;">Welcome, ${payload.name}! 👋</h2>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          Great news! Your <strong>${payload.type}</strong> application has been approved by our team.
        </p>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          To get started, please set up your password by clicking the button below:
        </p>
        
        <!-- Button -->
        <div style="text-align: center; margin: 30px 0;">
          <a href="${payload.setupUrl}" 
             style="
               display: inline-block;
               background: #6B21A8;
               color: white;
               padding: 14px 40px;
               border-radius: 8px;
               text-decoration: none;
               font-size: 16px;
               font-weight: 600;
               transition: background 0.3s;
             "
          >
            Set Password
          </a>
        </div>
        
        <p style="color: #6B7280; font-size: 14px; text-align: center; margin: 0;">
          ⏰ This link expires in <strong>72 hours</strong>
        </p>
      </div>
      
      <!-- Footer -->
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px; margin: 0;">
          If you didn't apply for a ${payload.type} account, please ignore this email.
        </p>
        <p style="color: #9CA3AF; font-size: 12px; margin: 5px 0 0;">
          © ${new Date().getFullYear()} Iyadati. All rights reserved.
        </p>
      </div>
    </div>
  `,
});

