// src/infrastructure/queues/email/templates/rejection.template.ts

import { SendApplicationRejectionEmailPayload } from '../email.types';

export interface EmailTemplate {
  subject: string;
  html: string;
}

export const generateRejectionEmail = (
  payload: SendApplicationRejectionEmailPayload
): EmailTemplate => ({
  subject: `📋 ${payload.type} Application Update`,

  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8f9fa; border-radius: 12px;">
      
      <!-- Header -->
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #6B21A8; margin: 0;">Iyadati</h1>
        <p style="color: #6B7280; margin: 5px 0 0;">Your Health Partner</p>
      </div>
      
      <!-- Main Content -->
      <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h2 style="color: #1F2937; margin-top: 0;">Hello ${payload.name} 👋</h2>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          Thank you for your interest in becoming a <strong>${payload.type}</strong> on Iyadati.
        </p>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          After careful review, we regret to inform you that your application has been <strong style="color: #DC2626;">not approved</strong> at this time.
        </p>
        
        ${payload.reason ? `
          <div style="background: #FEF2F2; padding: 16px; border-radius: 8px; border-left: 4px solid #DC2626; margin: 20px 0;">
            <p style="color: #991B1B; margin: 0; font-size: 14px;">
              <strong>Reason:</strong> ${payload.reason}
            </p>
          </div>
        ` : ''}
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          You are welcome to reapply with updated information at any time.
        </p>
      </div>
      
      <!-- Footer -->
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px; margin: 0;">
          If you have questions, please contact our support team.
        </p>
        <p style="color: #9CA3AF; font-size: 12px; margin: 5px 0 0;">
          © ${new Date().getFullYear()} Iyadati. All rights reserved.
        </p>
      </div>
    </div>
  `,
});

