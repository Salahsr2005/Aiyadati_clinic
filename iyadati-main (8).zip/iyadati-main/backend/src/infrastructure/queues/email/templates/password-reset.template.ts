// src/infrastructure/queues/email/templates/password-reset.template.ts

import { SendPasswordResetEmailPayload } from '../email.types';

export interface EmailTemplate {
  subject: string;
  html: string;
}

export const generatePasswordResetEmail = (
  payload: SendPasswordResetEmailPayload
): EmailTemplate => ({
  subject: '🔐 Reset Your Iyadati Password',

  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8f9fa; border-radius: 12px;">
      
      <!-- Header -->
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #6B21A8; margin: 0;">Iyadati</h1>
        <p style="color: #6B7280; margin: 5px 0 0;">Your Health Partner</p>
      </div>
      
      <!-- Main Content -->
      <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h2 style="color: #1F2937; margin-top: 0;">Hello ${payload.name} 👋</h2>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          We received a request to reset the password for your <strong>${payload.type}</strong> account.
        </p>
        
        <p style="color: #374151; font-size: 16px; line-height: 1.6;">
          If you made this request, click the button below to reset your password:
        </p>
        
        <!-- Button -->
        <div style="text-align: center; margin: 30px 0;">
          <a href="${payload.resetUrl}" 
             style="
               display: inline-block;
               background: #6B21A8;
               color: white;
               padding: 14px 40px;
               border-radius: 8px;
               text-decoration: none;
               font-size: 16px;
               font-weight: 600;
               transition: background 0.3s;
             "
          >
            Reset Password
          </a>
        </div>
        
        <p style="color: #6B7280; font-size: 14px; text-align: center; margin: 0;">
          ⏰ This link expires in <strong>24 hours</strong>
        </p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;" />
        
        <p style="color: #6B7280; font-size: 14px; text-align: center; margin: 0;">
          If you didn't request a password reset, please ignore this email.
        </p>
      </div>
      
      <!-- Footer -->
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px; margin: 0;">
          © ${new Date().getFullYear()} Iyadati. All rights reserved.
        </p>
      </div>
    </div>
  `,
});

