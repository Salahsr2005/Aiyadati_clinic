// src/infrastructure/queues/email/email.types.ts

// ============================================================
// EXISTING
// ============================================================

export interface SendOtpEmailPayload {
  email: string;
  name: string;
  otp: string;
}

// ============================================================
// NEW - Password Setup Email
// ============================================================

export interface SendPasswordSetupEmailPayload {
  email: string;
  name: string;
  type: string; // 'Doctor', 'Clinic', 'Seller'
  setupUrl: string;
}

// ============================================================
// NEW - Application Rejection Email
// ============================================================

export interface SendApplicationRejectionEmailPayload {
  email: string;
  name: string;
  type: string; // 'Doctor', 'Clinic', 'Seller'
  reason?: string;
}

// ============================================================
// NEW - Admin Notification Email
// ============================================================

export interface SendAdminNotificationPayload {
  adminEmail?: string;
  subject: string;
  message: string;
  applicationId: string;
  applicantType: string;
}

// ============================================================
// NEW - Password Reset Email
// ============================================================

export interface SendPasswordResetEmailPayload {
  email: string;
  name: string;
  type: string; // 'USER', 'DOCTOR', 'CLINIC', 'SELLER'
  resetUrl: string;
}

