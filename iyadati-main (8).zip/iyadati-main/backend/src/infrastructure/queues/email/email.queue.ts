// src/infrastructure/queues/email/email.queue.ts

import { JobsOptions, Queue } from 'bullmq';
import { bullMqConnection } from '../connection';
import { EmailJobName } from './email.jobs';
import {
  SendOtpEmailPayload,
  SendPasswordSetupEmailPayload,
  SendApplicationRejectionEmailPayload,
  SendAdminNotificationPayload,
  SendPasswordResetEmailPayload,
} from './email.types';

class EmailQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('email', {
      connection: bullMqConnection,
    });
  }

  // ============================================================
  // EXISTING
  // ============================================================

  public async enqueueOtp(payload: SendOtpEmailPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_OTP, payload);
  }

  // ============================================================
  // NEW - Password Setup Email
  // ============================================================

  public async enqueuePasswordSetup(payload: SendPasswordSetupEmailPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_PASSWORD_SETUP, payload);
  }

  // ============================================================
  // NEW - Application Rejection Email
  // ============================================================

  public async enqueueApplicationRejection(payload: SendApplicationRejectionEmailPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_APPLICATION_REJECTION, payload);
  }

  // ============================================================
  // NEW - Admin Notification Email
  // ============================================================

  public async enqueueAdminNotification(payload: SendAdminNotificationPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_ADMIN_NOTIFICATION, payload);
  }

  // ============================================================
  // NEW - Password Reset Email
  // ============================================================

  public async enqueuePasswordReset(payload: SendPasswordResetEmailPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_PASSWORD_RESET, payload);
  }

  // ============================================================
  // PRIVATE
  // ============================================================

  private async enqueue(
    jobName: EmailJobName,
    payload: unknown,
    options?: JobsOptions,
  ): Promise<void> {
    console.log(`[Email Queue] Adding job: ${jobName}`);

    const job = await this.queue.add(jobName, payload, {
      attempts: 5,
      backoff: {
        type: "exponential",
        delay: 5000,
      },
      removeOnComplete: 1000,
      removeOnFail: 5000,
      ...options,
    });

    console.log(`[Email Queue] Job added: ${job.id}`);
  }

  public getQueue() {
    return this.queue;
  }

  public async close(): Promise<void> {
    await this.queue.close();
  }
}

export const emailQueue = new EmailQueueService();

