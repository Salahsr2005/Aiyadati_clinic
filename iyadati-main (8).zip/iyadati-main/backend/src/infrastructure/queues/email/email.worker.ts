// src/infrastructure/queues/email/email.worker.ts

console.log('>>> email.worker.ts loaded');
import { Job, Worker } from 'bullmq';

import { bullMqConnection } from '../connection';
import { logger } from '../../../core/utils/logger';
import { sendEmail } from '../../../core/utils/email';

import { EmailJobName } from './email.jobs';
import {
  SendOtpEmailPayload,
  SendPasswordSetupEmailPayload,
  SendApplicationRejectionEmailPayload,
  SendPasswordResetEmailPayload,
} from './email.types';
import { generateOtpEmail } from './templates/otp.template';
import { generatePasswordSetupEmail } from './templates/password-setup.template';
import { generateRejectionEmail } from './templates/rejection.template';
import { generatePasswordResetEmail } from './templates/password-reset.template';

class EmailWorkerService {
  private readonly worker: Worker;

  constructor() {
    console.log('>>> EmailWorkerService constructor');

    this.worker = new Worker(
      'email',
      this.process.bind(this),
      {
        connection: bullMqConnection,
        concurrency: 10,
      }
    );

    this.registerEvents();
  }

  private async process(job: Job): Promise<void> {
    switch (job.name) {
      // Existing
      case EmailJobName.SEND_OTP:
        await this.processOtp(job as Job<SendOtpEmailPayload>);
        break;

      // NEW - Password Setup
      case EmailJobName.SEND_PASSWORD_SETUP:
        await this.processPasswordSetup(job as Job<SendPasswordSetupEmailPayload>);
        break;

      // NEW - Application Rejection
      case EmailJobName.SEND_APPLICATION_REJECTION:
        await this.processApplicationRejection(job as Job<SendApplicationRejectionEmailPayload>);
        break;

      // NEW - Password Reset
      case EmailJobName.SEND_PASSWORD_RESET:
        await this.processPasswordReset(job as Job<SendPasswordResetEmailPayload>);
        break;

      default:
        throw new Error(`Unknown email job: ${job.name}`);
    }
  }

  // ============================================================
  // EXISTING - OTP
  // ============================================================

  private async processOtp(job: Job<SendOtpEmailPayload>): Promise<void> {
    const payload = job.data;
    const template = generateOtpEmail(payload);

    const sent = await sendEmail({
      to: payload.email,
      subject: template.subject,
      html: template.html,
    });

    if (!sent) {
      throw new Error(`Failed to send OTP email to ${payload.email}`);
    }

    logger.info('[Email Worker] OTP email sent.', {
      jobId: job.id,
      email: payload.email,
    });
  }

  // ============================================================
  // NEW - Password Setup Email
  // ============================================================

  private async processPasswordSetup(job: Job<SendPasswordSetupEmailPayload>): Promise<void> {
    const payload = job.data;
    const template = generatePasswordSetupEmail(payload);

    const sent = await sendEmail({
      to: payload.email,
      subject: template.subject,
      html: template.html,
    });

    if (!sent) {
      throw new Error(`Failed to send password setup email to ${payload.email}`);
    }

    logger.info('[Email Worker] Password setup email sent.', {
      jobId: job.id,
      email: payload.email,
      type: payload.type,
    });
  }

  // ============================================================
  // NEW - Application Rejection Email
  // ============================================================

  private async processApplicationRejection(job: Job<SendApplicationRejectionEmailPayload>): Promise<void> {
    const payload = job.data;
    const template = generateRejectionEmail(payload);

    const sent = await sendEmail({
      to: payload.email,
      subject: template.subject,
      html: template.html,
    });

    if (!sent) {
      throw new Error(`Failed to send rejection email to ${payload.email}`);
    }

    logger.info('[Email Worker] Application rejection email sent.', {
      jobId: job.id,
      email: payload.email,
      type: payload.type,
    });
  }

  // ============================================================
  // NEW - Password Reset Email
  // ============================================================

  private async processPasswordReset(job: Job<SendPasswordResetEmailPayload>): Promise<void> {
    const payload = job.data;
    const template = generatePasswordResetEmail(payload);

    const sent = await sendEmail({
      to: payload.email,
      subject: template.subject,
      html: template.html,
    });

    if (!sent) {
      throw new Error(`Failed to send password reset email to ${payload.email}`);
    }

    logger.info('[Email Worker] Password reset email sent.', {
      jobId: job.id,
      email: payload.email,
      type: payload.type,
    });
  }

  // ============================================================
  // REGISTER EVENTS
  // ============================================================

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Email Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Email Worker] Job completed.', {
        jobId: job.id,
        jobName: job.name,
      });
    });

    this.worker.on('failed', (job, error) => {
      logger.error('[Email Worker] Job failed.', {
        jobId: job?.id,
        jobName: job?.name,
        message: error.message,
        stack: error.stack,
        attemptsMade: job?.attemptsMade,
      });
    });

    this.worker.on('error', (error) => {
      logger.error('[Email Worker] Worker error.', { error });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const emailWorker = new EmailWorkerService();

