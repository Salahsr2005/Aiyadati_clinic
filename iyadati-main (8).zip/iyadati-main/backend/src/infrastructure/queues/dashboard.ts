import { ExpressAdapter } from '@bull-board/express';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';

import { emailQueue } from './email/email.queue';
import { notificationQueue } from './notification/notification.queue';
import { slotGenerationQueue } from './slot-generation/slot-generation.queue';
import { reminderQueue } from './reminder/reminder.queue';
import { accountDeletionQueue } from './account-deletion/account-deletion.queue';

const serverAdapter = new ExpressAdapter();

serverAdapter.setBasePath('/admin/queues');

createBullBoard({
  queues: [
    new BullMQAdapter(emailQueue.getQueue()),
    new BullMQAdapter(notificationQueue.getQueue()),
    new BullMQAdapter(slotGenerationQueue.getQueue()),
    new BullMQAdapter(reminderQueue.getQueue()),
    new BullMQAdapter(accountDeletionQueue.getQueue()),
  ],
  serverAdapter,
});

export { serverAdapter };

