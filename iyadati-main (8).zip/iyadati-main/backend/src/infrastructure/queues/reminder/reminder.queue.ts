import { JobsOptions, Queue } from 'bullmq';
import { bullMqConnection } from '../connection';
import { ReminderJobName, ReminderPayload } from './reminder.jobs';
import { logger } from '../../../core/utils/logger';

class ReminderQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('reminder', {
      connection: bullMqConnection,
      defaultJobOptions: {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 5000,
        },
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    });
  }

  /**
   * Enqueue a single reminder job
   * Called AFTER the DB transaction commits
   */
  async enqueueReminder(
    reminderId: string,
    reminderType: ReminderPayload['reminderType'],
    delay: number
  ): Promise<void> {
    const payload: ReminderPayload = {
      reminderId,
      reminderType,
    };

    await this.queue.add(
      ReminderJobName.APPOINTMENT_REMINDER,
      payload,
      {
        jobId: `reminder-${reminderId}`,
        delay: Math.max(0, delay),
      }
    );
  }

  /**
   * Enqueue multiple reminders in batch
   * Called AFTER the DB transaction commits
   */
  async enqueueReminders(
    reminders: Array<{ id: string; reminderType: ReminderPayload['reminderType']; scheduledAt: Date }>
  ): Promise<void> {
    if (reminders.length === 0) return;

    let enqueuedCount = 0;
    for (const reminder of reminders) {
      const delay = Math.max(0, reminder.scheduledAt.getTime() - Date.now());
      try {
        await this.enqueueReminder(reminder.id, reminder.reminderType, delay);
        enqueuedCount++;
      } catch (error) {
        logger.error(`Failed to enqueue reminder ${reminder.id}`, { error });
      }
    }

    if (enqueuedCount > 0) {
      logger.info(`Enqueued ${enqueuedCount}/${reminders.length} reminders`);
    }
  }

  /**
   * Cancel specific reminders by their IDs (best effort)
   * Called AFTER the DB transaction commits
   * Removes BullMQ jobs when possible, but DB status check is the primary guarantee
   */
  async cancelRemindersByIds(reminderIds: string[]): Promise<{ removed: number; total: number }> {
    if (reminderIds.length === 0) {
      return { removed: 0, total: 0 };
    }

    let removedCount = 0;
    for (const reminderId of reminderIds) {
      const jobId = `reminder-${reminderId}`;
      try {
        const removed = await this.queue.remove(jobId);
        if (removed) {
          removedCount++;
        }
      } catch (error) {
        // Job might be in active state or already completed
        // That's fine - the DB status check in the worker will handle it
        logger.debug(`Could not remove job ${jobId}: ${error instanceof Error ? error.message : 'unknown error'}`);
      }
    }

    if (removedCount > 0) {
      logger.info(`Removed ${removedCount}/${reminderIds.length} BullMQ jobs`);
    }

    return { removed: removedCount, total: reminderIds.length };
  }

  getQueue(): Queue {
    return this.queue;
  }

  async close(): Promise<void> {
    await this.queue.close();
  }
}

export const reminderQueue = new ReminderQueueService();

