export enum ReminderJobName {
  APPOINTMENT_REMINDER = 'appointment-reminder',
}

export interface ReminderPayload {
  reminderId: string;
  reminderType: '3_DAYS' | '1_DAY' | '2_HOURS' | '1_HOUR';
}

