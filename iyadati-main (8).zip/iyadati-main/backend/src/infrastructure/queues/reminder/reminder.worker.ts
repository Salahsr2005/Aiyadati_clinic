// backend/src/infrastructure/queues/reminder/reminder.worker.ts

import { Job, Worker } from 'bullmq';
import { bullMqConnection } from '../connection';
import { prisma } from '../../../core/utils/prisma';
import { notificationQueue } from '../notification/notification.queue';
import { logger } from '../../../core/utils/logger';
import { ReminderJobName, ReminderPayload } from './reminder.jobs';
import { reminderService } from '../../../modules/appointment/v1/reminder.service';

class ReminderWorkerService {
  private readonly worker: Worker;

  constructor() {
    this.worker = new Worker(
      'reminder',
      this.process.bind(this),
      {
        connection: bullMqConnection,
        concurrency: 10,
      }
    );

    this.registerEvents();
  }

  private async process(job: Job<ReminderPayload>): Promise<void> {
    if (job.name !== ReminderJobName.APPOINTMENT_REMINDER) {
      throw new Error(`Unknown reminder job: ${job.name}`);
    }

    const { reminderId, reminderType } = job.data;

    logger.info(`Processing reminder ${reminderId} of type ${reminderType}`);

    // ============================================================
    // 1. Load reminder from DB using repository
    // ============================================================

    const reminder = await reminderService.getReminderWithAppointment(reminderId);

    // ============================================================
    // 2. Handle cases where reminder shouldn't send
    // ============================================================

    if (!reminder) {
      logger.warn(`Reminder ${reminderId} not found in DB`);
      return;
    }

    if (reminder.status === 'SENT') {
      logger.info(`Reminder ${reminderId} already sent`);
      return;
    }

    if (reminder.status === 'CANCELLED') {
      logger.info(`Reminder ${reminderId} was cancelled`);
      return;
    }

    // Check if appointment still exists and is valid
    const appointment = reminder.appointment;
    if (!appointment) {
      await reminderService.markReminderAsCancelled(reminderId);
      logger.warn(`Reminder ${reminderId} cancelled - appointment not found`);
      return;
    }

    // Don't send reminders for cancelled, completed, or no-show appointments
    const invalidStatuses = ['CANCELLED', 'COMPLETED', 'NO_SHOW'];
    if (invalidStatuses.includes(appointment.status)) {
      await reminderService.markReminderAsCancelled(reminderId);
      logger.info(`Reminder ${reminderId} cancelled - appointment status: ${appointment.status}`);
      return;
    }

    // ============================================================
    // 3. Build notification content from fresh data
    // ============================================================

    const slotDate = appointment.slot?.date?.toISOString()?.slice(0, 10) || 'Unknown date';
    const slotTime = appointment.slot?.startTime?.toISOString()?.slice(11, 16) || 'Unknown time';

    let patientName = 'A patient';
    if (appointment.patientType === 'REGISTERED' && appointment.patient) {
      patientName = `${appointment.patient.firstName} ${appointment.patient.lastName}`;
    } else if (appointment.guestPatient) {
      patientName = `${appointment.guestPatient.firstName} ${appointment.guestPatient.lastName}`;
    }

    const doctorName = appointment.doctor
      ? `Dr. ${appointment.doctor.firstNameFr} ${appointment.doctor.lastNameFr}`
      : 'Doctor';

    // ============================================================
    // 4. Send notification via QUEUE (not eventEmitter!)
    // ============================================================

    try {
      if (reminder.recipientType === 'PATIENT') {
        await this.sendPatientReminder(
          reminder.recipientId,
          reminderType,
          doctorName,
          slotDate,
          slotTime,
          reminderId
        );
      } else {
        await this.sendDoctorReminder(
          reminder.recipientId,
          reminderType,
          patientName,
          slotDate,
          slotTime,
          reminderId
        );
      }

      // ============================================================
      // 5. Mark as sent using repository
      // ============================================================

      await reminderService.markReminderAsSent(reminderId);

      logger.info(`✅ Reminder ${reminderId} sent successfully to ${reminder.recipientType}`);

    } catch (error) {
      // Update error count and last error, but DON'T mark as FAILED yet
      // The worker's 'failed' event handler will mark as FAILED after max retries
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';

      await reminderService.updateReminderWithError(reminderId, errorMessage);

      logger.error(`❌ Reminder ${reminderId} failed (attempt ${reminder.attempts + 1}): ${errorMessage}`);
      throw error; // Let BullMQ retry
    }
  }

  private async sendPatientReminder(
    userId: string,
    type: string,
    doctorName: string,
    date: string,
    time: string,
    reminderId: string
  ): Promise<void> {
    const titles: Record<string, string> = {
      '3_DAYS': '📅 Appointment in 3 Days',
      '1_DAY': '📅 Appointment Tomorrow!',
      '2_HOURS': '⏰ Appointment in 2 Hours!',
      '1_HOUR': '⏰ Appointment in 1 Hour!',
    };

    const bodies: Record<string, string> = {
      '3_DAYS': `You have an appointment with ${doctorName} on ${date} at ${time}. Please ensure you're prepared.`,
      '1_DAY': `Don't forget! You have an appointment with ${doctorName} tomorrow at ${time}.`,
      '2_HOURS': `Reminder: Your appointment with ${doctorName} is in 2 hours at ${time}.`,
      '1_HOUR': `⚠️ Your appointment with ${doctorName} is in 1 hour at ${time}. Please don't be late!`,
    };

    await notificationQueue.enqueue({
      userId,
      title: titles[type] || 'Appointment Reminder',
      body: bodies[type] || `Reminder for ${doctorName} on ${date} at ${time}`,
      type: 'appointment_reminder',
      data: {
        reminderId,
        type: 'appointment_reminder',
        reminderSubType: type,
        appointmentDate: date,
        appointmentTime: time,
      },
    });
  }

  private async sendDoctorReminder(
    userId: string,
    type: string,
    patientName: string,
    date: string,
    time: string,
    reminderId: string
  ): Promise<void> {
    const title = type === '1_DAY'
      ? '📋 Appointment Tomorrow'
      : '📋 Appointment in 1 Hour';

    const body = type === '1_DAY'
      ? `${patientName} has an appointment tomorrow at ${time}`
      : `${patientName} has an appointment in 1 hour at ${time}`;

    await notificationQueue.enqueue({
      userId,
      title,
      body,
      type: 'appointment_reminder',
      data: {
        reminderId,
        type: 'doctor_reminder',
        reminderSubType: type,
        patientName,
      },
    });
  }

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Reminder Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Reminder Worker] Job completed.', {
        jobId: job.id,
        reminderId: job.data.reminderId,
      });
    });

    this.worker.on('failed', async (job, error) => {
      if (!job) return;

      const maxAttempts = job.opts?.attempts || 3;

      if (job.attemptsMade >= maxAttempts) {
        // Max retries reached - mark as FAILED using repository
        try {
          await reminderService.markReminderAsFailed(job.data.reminderId, error.message);
          logger.error(`[Reminder Worker] Job permanently failed after ${maxAttempts} attempts.`, {
            jobId: job.id,
            reminderId: job.data.reminderId,
            message: error.message,
          });
        } catch (dbError) {
          logger.error(`[Reminder Worker] Failed to mark reminder as FAILED in DB`, {
            jobId: job.id,
            reminderId: job.data.reminderId,
            error: dbError,
          });
        }
      } else {
        // Will retry - keep as PENDING with lastError set
        logger.warn(`[Reminder Worker] Job failed, will retry (attempt ${job.attemptsMade}/${maxAttempts}).`, {
          jobId: job.id,
          reminderId: job.data.reminderId,
          message: error.message,
        });
      }
    });

    this.worker.on('error', (error) => {
      logger.error('[Reminder Worker] Worker error.', { error });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const reminderWorker = new ReminderWorkerService();

