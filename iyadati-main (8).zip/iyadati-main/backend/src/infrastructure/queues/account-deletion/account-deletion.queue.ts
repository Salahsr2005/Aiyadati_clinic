import { JobsOptions, Queue } from 'bullmq';
import { bullMqConnection } from '../connection';
import { logger } from '../../../core/utils/logger';

export enum AccountDeletionJobName {
  DELETE_USER = 'delete-user',
  CHECK_PENDING = 'check-pending',
}

export interface DeleteUserPayload {
  userId: string;
  userEmail: string;
}

class AccountDeletionQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('account-deletion', {
      connection: bullMqConnection,
      defaultJobOptions: {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 5000,
        },
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    });
  }

  /**
   * Enqueue a single user deletion job
   */
  async enqueueUserDeletion(userId: string, userEmail: string): Promise<void> {
    const payload: DeleteUserPayload = {
      userId,
      userEmail,
    };

    await this.queue.add(
      AccountDeletionJobName.DELETE_USER,
      payload,
      {
        jobId: `delete-user-${userId}`,
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 5000,
        },
      }
    );
  }

  /**
   * Enqueue the recurring check job (runs daily at 2 AM)
   */
  async scheduleRecurringCheck(): Promise<void> {
    // Remove existing recurring job if any
    await this.queue.removeRepeatable('check-pending-deletions', {
      pattern: '0 2 * * *',
    });

    await this.queue.add(
      'check-pending-deletions',
      {},
      {
        jobId: 'check-pending-deletions',
        repeat: {
          pattern: '0 2 * * *', // Daily at 2 AM
        },
        removeOnComplete: true,
        removeOnFail: true,
      }
    );

    logger.info('📅 Account deletion check scheduled (daily at 2 AM)');
  }

  getQueue(): Queue {
    return this.queue;
  }

  async close(): Promise<void> {
    await this.queue.close();
  }
}

export const accountDeletionQueue = new AccountDeletionQueueService();

