import { Job, Worker } from 'bullmq';
import { bullMqConnection } from '../connection';
import { userRepository } from '../../../repositories/user.repository';
import { logger } from '../../../core/utils/logger';
import { AccountDeletionJobName, DeleteUserPayload } from './account-deletion.queue';
import { accountDeletionQueue } from './account-deletion.queue';
import { prisma } from '../../../core/utils/prisma';

class AccountDeletionWorkerService {
  private readonly worker: Worker;

  constructor() {
    this.worker = new Worker(
      'account-deletion',
      this.process.bind(this),
      {
        connection: bullMqConnection,
        concurrency: 5,
      }
    );

    this.registerEvents();
    this.scheduleCheck(); // Schedule the recurring check on startup
  }

  private async scheduleCheck(): Promise<void> {
    await accountDeletionQueue.scheduleRecurringCheck();
  }

  private async process(job: Job): Promise<void> {
    switch (job.name) {
      case 'check-pending-deletions':
        await this.processCheckPendingDeletions();
        break;

      case AccountDeletionJobName.DELETE_USER:
        await this.processDeleteUser(job as Job<DeleteUserPayload>);
        break;

      default:
        throw new Error(`Unknown account deletion job: ${job.name}`);
    }
  }

  /**
   * Check for users pending deletion and enqueue them
   */
  private async processCheckPendingDeletions(): Promise<void> {
    logger.info('🔄 Checking for users pending deletion...');
    
    try {
      // Get pending users WITH appointments included
      const pendingUsers = await prisma.user.findMany({
        where: {
          deletionStatus: 'pending',
          deletionScheduledAt: {
            lte: new Date(),
          },
        },
        include: {
          appointments: {
            where: {
              status: {
                in: ['PENDING', 'CONFIRMED', 'IN_PROGRESS'],
              },
            },
          },
        },
      });
      
      if (pendingUsers.length === 0) {
        logger.info('✅ No users pending deletion.');
        return;
      }

      logger.info(`Found ${pendingUsers.length} users pending deletion.`);

      // Filter out users with active appointments
      const usersToDelete = pendingUsers.filter(user => {
        const hasActiveAppointments = user.appointments && user.appointments.length > 0;
        
        if (hasActiveAppointments) {
          logger.warn(`⚠️ Skipping user ${user.email} - has active appointments.`);
          return false;
        }
        
        return true;
      });

      if (usersToDelete.length === 0) {
        logger.info('✅ No users ready for deletion (all have active appointments).');
        return;
      }

      // Enqueue each user for deletion
      for (const user of usersToDelete) {
        await accountDeletionQueue.enqueueUserDeletion(user.id, user.email);
      }

      logger.info(`✅ Enqueued ${usersToDelete.length} users for deletion.`);

    } catch (error) {
      logger.error('❌ Failed to check pending deletions:', error);
      throw error;
    }
  }

  /**
   * Permanently delete a single user
   */
  private async processDeleteUser(job: Job<DeleteUserPayload>): Promise<void> {
    const { userId, userEmail } = job.data;

    try {
      await userRepository.permanentDeleteUser(userId);
      logger.info(`🗑️ Permanently deleted user: ${userEmail}`);
    } catch (error) {
      logger.error(`❌ Failed to delete user ${userEmail}:`, error);
      throw error;
    }
  }

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Account Deletion Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Account Deletion Worker] Job completed.', {
        jobId: job.id,
        jobName: job.name,
      });
    });

    this.worker.on('failed', (job, error) => {
      logger.error('[Account Deletion Worker] Job failed.', {
        jobId: job?.id,
        jobName: job?.name,
        message: error.message,
        stack: error.stack,
        attemptsMade: job?.attemptsMade,
      });
    });

    this.worker.on('error', (error) => {
      logger.error('[Account Deletion Worker] Worker error.', { error });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const accountDeletionWorker = new AccountDeletionWorkerService();

