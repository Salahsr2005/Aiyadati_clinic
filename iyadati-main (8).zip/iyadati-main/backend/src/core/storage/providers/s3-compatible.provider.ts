import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
  CopyObjectCommand,
  CreateBucketCommand,
  PutObjectCommandInput,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { Readable } from 'stream';
import crypto from 'crypto';
import { StorageProvider } from '../../interfaces/storage.interface';
import {
  FileInput,
  UploadOptions,
  UploadResult,
  DownloadOptions,
  FileOutput,
  FileMetadata,
  DeleteResult,
  DeleteOptions,
  CopyResult,
  MoveResult,
  SignedUploadUrlResult,
  HeadObjectResult,
} from '../storage.types';
import { env } from '../../../config/env';
import { NotFoundError, BadRequestError } from '../../utils/error';
import { logger } from '../../utils/logger';

export class S3CompatibleStorageProvider implements StorageProvider {
  // Internal client for server-to-server operations (upload, download, delete, etc.)
  private client: S3Client;
  
  // Presign client for generating URLs that are accessible from the browser
  private presignClient: S3Client;
  
  private publicBucket: string;
  private privateBucket: string;
  private endpoint: string;
  private publicEndpoint: string;
  private publicProtocol: string;

  constructor() {
    this.publicBucket = env.STORAGE_BUCKET_PUBLIC;
    this.privateBucket = env.STORAGE_BUCKET_PRIVATE;
    
    // Internal endpoint (server-to-server)
    this.endpoint = `${env.STORAGE_ENDPOINT}:${env.STORAGE_PORT}`;
    
    // Public endpoint (client-facing)
    this.publicEndpoint = `${env.STORAGE_PUBLIC_ENDPOINT}:${env.STORAGE_PUBLIC_PORT}`;

    // ✅ FIX: Separate protocols for internal vs public
    const internalProtocol = env.STORAGE_USE_SSL ? 'https' : 'http';
    const publicProtocol = env.STORAGE_PUBLIC_USE_SSL ? 'https' : 'http';
    this.publicProtocol = publicProtocol;

    // Internal client - used for actual file operations (upload, download, delete, etc.)
    this.client = new S3Client({
      endpoint: `${internalProtocol}://${this.endpoint}`,
      region: env.STORAGE_REGION,
      credentials: {
        accessKeyId: env.STORAGE_ACCESS_KEY || 'admin',
        secretAccessKey: env.STORAGE_SECRET_KEY || 'admin',
      },
      forcePathStyle: true,
      maxAttempts: 3,
    });

    // Presign client - used ONLY for generating signed URLs that browsers can access
    // This client uses the public endpoint so the URLs are accessible from outside Docker
    this.presignClient = new S3Client({
      endpoint: `${publicProtocol}://${this.publicEndpoint}`,
      region: env.STORAGE_REGION,
      credentials: {
        accessKeyId: env.STORAGE_ACCESS_KEY || 'admin',
        secretAccessKey: env.STORAGE_SECRET_KEY || 'admin',
      },
      forcePathStyle: true,
    });

    logger.info(`S3CompatibleStorageProvider initialized with internal endpoint: ${this.endpoint}`);
    logger.info(`S3CompatibleStorageProvider public endpoint for presigned URLs: ${this.publicEndpoint}`);
    logger.info(`S3CompatibleStorageProvider public protocol: ${publicProtocol}`);

    // Auto-create buckets on startup
    this.ensureBuckets().catch(error => {
      logger.debug('Bucket creation skipped:', error.message);
    });
  }

  // ============================================================
  // ✅ FIX: Sanitize metadata values to ASCII-safe
  // ============================================================

  /**
   * Encode non-ASCII characters in metadata values to ASCII-safe format
   * Prevents SignatureDoesNotMatch errors with non-ASCII filenames
   */
  private sanitizeMetadata(metadata: Record<string, string>): Record<string, string> {
    const safe: Record<string, string> = {};
    for (const [key, value] of Object.entries(metadata)) {
      safe[key] = encodeURIComponent(String(value));
    }
    return safe;
  }

  /**
   * Decode metadata values back to their original form
   */
  private decodeMetadata(metadata: Record<string, string>): Record<string, string> {
    const decoded: Record<string, string> = {};
    for (const [key, value] of Object.entries(metadata)) {
      try {
        decoded[key] = decodeURIComponent(value);
      } catch {
        decoded[key] = value;
      }
    }
    return decoded;
  }

  private async ensureBuckets(): Promise<void> {
    const buckets = [this.publicBucket, this.privateBucket];
    
    for (const bucket of buckets) {
      try {
        await this.client.send(new CreateBucketCommand({
          Bucket: bucket,
        }));
        logger.info(`✅ Created bucket: ${bucket}`);
      } catch (error: any) {
        logger.debug(`Bucket ${bucket} creation skipped: ${error.message}`);
      }
    }
  }

  private getBucket(isPublic: boolean): string {
    return isPublic ? this.publicBucket : this.privateBucket;
  }

  private generateKey(path: string, originalName: string, isPublic: boolean): string {
    const ext = originalName.includes('.') ? originalName.split('.').pop() : '';
    const uuid = crypto.randomUUID();
    const cleanPath = path ? path.replace(/^\/+/, '').replace(/\/+$/, '') : '';
    
    const baseKey = cleanPath || (isPublic ? 'public' : 'private');
    
    return `${baseKey}/${uuid}${ext ? `.${ext}` : ''}`;
  }

  private async withRetry<T>(operation: () => Promise<T>, maxRetries = 3): Promise<T> {
    let lastError: Error | undefined;
    for (let i = 0; i < maxRetries; i++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        if (i < maxRetries - 1) {
          const delay = Math.pow(2, i) * 1000;
          logger.warn(`Retry ${i + 1}/${maxRetries} after ${delay}ms: ${lastError.message}`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    throw lastError || new Error('Operation failed after retries');
  }

  // ============================================================
  // UPLOAD (uses internal client)
  // ============================================================

  async upload(file: FileInput, options: UploadOptions = {}): Promise<UploadResult> {
    const { path = '', metadata = {}, isPublic = false, contentType, cacheControl } = options;

    const key = this.generateKey(path, file.originalName, isPublic);
    const bucket = this.getBucket(isPublic);

    const rawMetadata: Record<string, string> = {
      ...metadata,
      'original-name': file.originalName,
      'uploaded-at': new Date().toISOString(),
      'is-public': String(isPublic),
    };

    if (options.checksum) {
      rawMetadata.checksum = options.checksum;
    }

    const sanitizedMetadata = this.sanitizeMetadata(rawMetadata);

    const commandInput: PutObjectCommandInput = {
      Bucket: bucket,
      Key: key,
      Body: file.buffer,
      ContentType: contentType || file.mimeType,
      ContentLength: file.size,
      Metadata: sanitizedMetadata,
    };

    if (cacheControl) {
      commandInput.CacheControl = cacheControl;
    }

    const command = new PutObjectCommand(commandInput);

    const s3Result = await this.withRetry(async () => {
      return await this.client.send(command);
    });

    const result: UploadResult = {
      id: crypto.randomUUID(),
      key,
      path: key,
      metadata: {
        ...metadata,
        originalName: file.originalName,
        mimeType: file.mimeType,
        size: String(file.size),
        isPublic: String(isPublic),
      },
      size: file.size,
      uploadedAt: new Date(),
      etag: s3Result.ETag?.replace(/"/g, ''),
    };

    if (options.checksum) {
      result.checksum = options.checksum;
    }

    if (isPublic) {
      result.publicUrl = this.getPublicUrl(key);
    }

    return result;
  }

  // ============================================================
  // DOWNLOAD (uses internal client)
  // ============================================================

  async download(identifier: string, options?: DownloadOptions): Promise<FileOutput> {
    const bucket = await this.getBucketForKey(identifier);

    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: identifier,
    });

    const result = await this.withRetry(async () => {
      return await this.client.send(command);
    });

    if (!result.Body) {
      throw new NotFoundError('File not found');
    }

    const chunks: Uint8Array[] = [];
    for await (const chunk of result.Body as any) {
      chunks.push(chunk);
    }

    const buffer = Buffer.concat(chunks);

    const rawMetadata: Record<string, string> = {};
    if (result.Metadata) {
      Object.entries(result.Metadata).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          rawMetadata[key] = String(value);
        }
      });
    }
    const decodedMetadata = this.decodeMetadata(rawMetadata);

    return {
      buffer,
      metadata: {
        id: decodedMetadata['file-id'] || crypto.randomUUID(),
        key: identifier,
        path: identifier,
        originalName: decodedMetadata['original-name'] || identifier.split('/').pop() || identifier,
        mimeType: result.ContentType || 'application/octet-stream',
        size: result.ContentLength || buffer.length,
        isPublic: decodedMetadata['is-public'] === 'true',
        metadata: decodedMetadata,
        createdAt: result.LastModified || new Date(),
        updatedAt: result.LastModified || new Date(),
      },
      size: buffer.length,
      contentType: result.ContentType || 'application/octet-stream',
    };
  }

  // ============================================================
  // DOWNLOAD STREAM (uses internal client)
  // ============================================================

  async downloadStream(identifier: string): Promise<NodeJS.ReadableStream> {
    const bucket = await this.getBucketForKey(identifier);

    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: identifier,
    });

    const result = await this.withRetry(async () => {
      return await this.client.send(command);
    });

    if (!result.Body) {
      throw new NotFoundError('File not found');
    }

    return result.Body as NodeJS.ReadableStream;
  }

  // ============================================================
  // DELETE (uses internal client)
  // ============================================================

  async delete(identifier: string, options?: DeleteOptions): Promise<DeleteResult> {
    try {
      const bucket = await this.getBucketForKey(identifier);

      const command = new DeleteObjectCommand({
        Bucket: bucket,
        Key: identifier,
      });

      await this.withRetry(async () => {
        return await this.client.send(command);
      });

      return { success: true };
    } catch (error) {
      logger.error(`Failed to delete ${identifier}:`, error);
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // ============================================================
  // EXISTS (uses internal client)
  // ============================================================

  async exists(identifier: string): Promise<boolean> {
    try {
      await this.head(identifier);
      return true;
    } catch (error) {
      if ((error as any).name === 'NotFound' || (error as any).$metadata?.httpStatusCode === 404) {
        return false;
      }
      logger.warn(`Error checking existence of ${identifier}:`, error);
      return false;
    }
  }

  // ============================================================
  // HEAD / METADATA (uses internal client)
  // ============================================================

  async head(identifier: string): Promise<HeadObjectResult> {
    const bucket = await this.getBucketForKey(identifier);

    const command = new HeadObjectCommand({
      Bucket: bucket,
      Key: identifier,
    });

    const result = await this.withRetry(async () => {
      return await this.client.send(command);
    });

    const rawMetadata: Record<string, string> = {};
    if (result.Metadata) {
      Object.entries(result.Metadata).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          rawMetadata[key] = String(value);
        }
      });
    }
    const decodedMetadata = this.decodeMetadata(rawMetadata);

    return {
      size: result.ContentLength || 0,
      contentType: result.ContentType || 'application/octet-stream',
      etag: result.ETag?.replace(/"/g, '') || '',
      lastModified: result.LastModified || new Date(),
      metadata: decodedMetadata,
    };
  }

  // ============================================================
  // GET METADATA (uses internal client)
  // ============================================================

  async getMetadata(identifier: string): Promise<FileMetadata> {
    const head = await this.head(identifier);

    return {
      id: head.metadata['file-id'] || crypto.randomUUID(),
      key: identifier,
      path: identifier,
      originalName: head.metadata['original-name'] || identifier.split('/').pop() || identifier,
      mimeType: head.contentType,
      size: head.size,
      isPublic: head.metadata['is-public'] === 'true',
      metadata: head.metadata,
      createdAt: head.lastModified,
      updatedAt: head.lastModified,
    };
  }

  // ============================================================
  // UPDATE METADATA (uses internal client)
  // ============================================================

  async updateMetadata(identifier: string, metadata: Partial<FileMetadata>): Promise<FileMetadata> {
    const current = await this.head(identifier);
    const bucket = await this.getBucketForKey(identifier);

    const newMetadata = {
      ...current.metadata,
    };

    if (metadata.metadata) {
      Object.assign(newMetadata, metadata.metadata);
    }

    Object.keys(newMetadata).forEach(key => {
      if (newMetadata[key] === undefined) {
        delete newMetadata[key];
      }
    });

    const sanitizedMetadata = this.sanitizeMetadata(newMetadata);

    const command = new CopyObjectCommand({
      Bucket: bucket,
      CopySource: `${bucket}/${identifier}`,
      Key: identifier,
      Metadata: sanitizedMetadata,
      MetadataDirective: 'REPLACE',
      ContentType: current.contentType,
    });

    await this.withRetry(async () => {
      return await this.client.send(command);
    });

    return this.getMetadata(identifier);
  }

  // ============================================================
  // COPY (uses internal client)
  // ============================================================

  async copy(source: string, destination: string): Promise<CopyResult> {
    const sourceBucket = await this.getBucketForKey(source);
    const destBucket = await this.getBucketForKey(destination);

    const command = new CopyObjectCommand({
      Bucket: destBucket,
      CopySource: `${sourceBucket}/${source}`,
      Key: destination,
    });

    await this.withRetry(async () => {
      return await this.client.send(command);
    });

    return {
      success: true,
      newId: crypto.randomUUID(),
      newKey: destination,
    };
  }

  // ============================================================
  // MOVE (uses internal client)
  // ============================================================

  async move(source: string, destination: string): Promise<MoveResult> {
    const copyResult = await this.copy(source, destination);

    if (copyResult.success) {
      await this.delete(source);
    }

    return {
      success: copyResult.success,
      newId: copyResult.newId,
      newKey: copyResult.newKey,
    };
  }

  // ============================================================
  // SIGNED URL (GET) - uses presignClient (public endpoint)
  // ============================================================

  async getSignedUrl(identifier: string, expiresIn: number = 1800): Promise<string> {
    const bucket = await this.getBucketForKey(identifier);

    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: identifier,
    });

    return await this.withRetry(async () => {
      return await getSignedUrl(this.presignClient, command, { expiresIn });
    });
  }

  // ============================================================
  // SIGNED UPLOAD URL - uses presignClient (public endpoint)
  // ============================================================

  async getSignedUploadUrl(
    key: string,
    options?: {
      expiresIn?: number;
      contentType?: string;
      size?: number;
      metadata?: Record<string, string>;
    }
  ): Promise<SignedUploadUrlResult> {
    const expiresIn = options?.expiresIn || 300;
    const isPublic = key.startsWith('public/');
    const bucket = this.getBucket(isPublic);

    const sanitizedMetadata = options?.metadata ? this.sanitizeMetadata(options.metadata) : {};

    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      ContentType: options?.contentType || 'application/octet-stream',
      Metadata: sanitizedMetadata,
    });

    const url = await this.withRetry(async () => {
      return await getSignedUrl(this.presignClient, command, { expiresIn });
    });

    return {
      url,
      key,
      expiresAt: new Date(Date.now() + expiresIn * 1000),
    };
  }

  // ============================================================
  // PUBLIC URL - uses public endpoint
  // ============================================================

  getPublicUrl(identifier: string): string {
    if (!identifier.startsWith('public/')) {
      throw new BadRequestError('Only public files have public URLs');
    }

    const cdnUrl = env.CDN_URL;
    if (cdnUrl) {
      // ✅ CDN_URL already includes the bucket path
      return `${cdnUrl}/${identifier}`;
    }

    // ✅ FIX: Use the stored publicProtocol instead of env.STORAGE_USE_SSL
    const port = env.STORAGE_PUBLIC_PORT;
    const portStr = (port && port !== 80 && port !== 443) ? `:${port}` : '';
    
    return `${this.publicProtocol}://${env.STORAGE_PUBLIC_ENDPOINT}${portStr}/${env.STORAGE_BUCKET_PUBLIC}/${identifier}`;
  }

  // ============================================================
  // VERIFY CHECKSUM - uses internal client
  // ============================================================

  async verifyChecksum(identifier: string, expectedChecksum: string): Promise<boolean> {
    try {
      const head = await this.head(identifier);
      const storedChecksum = head.metadata['checksum'];
      return storedChecksum === expectedChecksum;
    } catch (error) {
      logger.error(`Failed to verify checksum for ${identifier}:`, error);
      return false;
    }
  }

  // ============================================================
  // HELPERS
  // ============================================================

  private async getBucketForKey(key: string): Promise<string> {
    if (key.startsWith('public/')) {
      return this.publicBucket;
    }
    if (key.startsWith('private/')) {
      return this.privateBucket;
    }

    try {
      await this.client.send(new HeadObjectCommand({
        Bucket: this.publicBucket,
        Key: key,
      }));
      return this.publicBucket;
    } catch (error) {
      return this.privateBucket;
    }
  }
}

