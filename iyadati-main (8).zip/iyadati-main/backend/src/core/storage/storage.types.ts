/**
 * INPUT: What you give to the storage system when uploading
 */
export interface FileInput {
  buffer: Buffer;
  originalName: string;
  mimeType: string;
  size: number;
}

/**
 * OPTIONS: Extra settings when uploading
 */
export interface UploadOptions {
  path?: string;
  metadata?: Record<string, string>;
  isPublic?: boolean;
  contentType?: string;
  cacheControl?: string;
  checksum?: string; // ← ADDED
}

/**
 * RESULT: What the storage system returns after saving
 */
export interface UploadResult {
  id: string;
  key: string;
  path: string;
  publicUrl?: string;
  metadata: Record<string, string>;
  size: number;
  uploadedAt: Date;
  checksum?: string; // ← ADDED
  etag?: string;     // ← ADDED (for S3 compatibility)
}

/**
 * OPTIONS: Options for downloading
 */
export interface DownloadOptions {
  range?: { start: number; end: number };
}

/**
 * METADATA: All the information about a file
 */
export interface FileMetadata {
  id: string;
  key: string;
  path: string;
  originalName: string;
  mimeType: string;
  size: number;
  isPublic: boolean;
  metadata: Record<string, string>;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * OUTPUT: What you get when you ask for a file
 */
export interface FileOutput {
  buffer: Buffer;
  metadata: FileMetadata;
  size: number;
  contentType: string;
}

/**
 * DELETE: Result of deleting a file
 */
export interface DeleteResult {
  success: boolean;
  message?: string;
}

/**
 * DELETE: Options for deleting
 */
export interface DeleteOptions {
  permanent?: boolean;
}

/**
 * COPY: Result of copying a file
 */
export interface CopyResult {
  success: boolean;
  newId: string;
  newKey: string;
}

/**
 * MOVE: Result of moving a file
 */
export interface MoveResult {
  success: boolean;
  newId: string;
  newKey: string;
}

// ============================================================
// NEW TYPES FOR S3/SEAWEEDFS
// ============================================================

/**
 * Result from generating a presigned upload URL
 */
export interface SignedUploadUrlResult {
  /** The presigned URL to upload to */
  url: string;
  /** The storage key (object key) */
  key: string;
  /** When the URL expires */
  expiresAt: Date;
  /** Optional form fields for multipart uploads */
  fields?: Record<string, string>;
}

/**
 * Result from checking object head
 */
export interface HeadObjectResult {
  /** File size in bytes */
  size: number;
  /** Content type (MIME type) */
  contentType: string;
  /** ETag from S3 */
  etag: string;
  /** Last modified date */
  lastModified: Date;
  /** Object metadata */
  metadata: Record<string, string>;
}

