import { StorageProvider } from '../interfaces/storage.interface';
import { LocalStorageProvider } from './providers/local.provider';
import { S3CompatibleStorageProvider } from './providers/s3-compatible.provider';
import { env } from '../../config/env';
import { logger } from '../utils/logger';

export class StorageFactory {
  private static instance: StorageProvider | null = null;

  static getInstance(): StorageProvider {
    if (!StorageFactory.instance) {
      const type = env.STORAGE_TYPE || 'local';

      switch (type) {
        case 'local':
          StorageFactory.instance = new LocalStorageProvider();
          break;
        case 's3-compatible':
          StorageFactory.instance = new S3CompatibleStorageProvider();
          break;
        default:
          throw new Error(`Unsupported storage type: ${type}`);
      }

      logger.info(`✅ Storage provider initialized: ${type}`);
    }

    return StorageFactory.instance;
  }

  static reset(): void {
    StorageFactory.instance = null;
  }
}

