import { Response } from 'express';
import { ApiResponse } from '../types/response.types';

export class ResponseUtil {
  /**
   * Success response (200)
   */
  static success<T>(
    res: Response,
    data?: T,
    message = 'Success',
    statusCode = 200,
    meta?: ApiResponse['meta']
  ): Response {
    const response: ApiResponse<T> = {
      success: true,
      message,
      data,
      meta: {
        timestamp: new Date().toISOString(),
        ...meta,
      },
    };
    
    // Add request ID if available
    const reqId = (res.req as any)?.id;
    if (reqId && response.meta) {
      response.meta.requestId = reqId;
    }
    
    return res.status(statusCode).json(response);
  }
  
  /**
   * Created response (201)
   */
  static created<T>(
    res: Response,
    data?: T,
    message = 'Resource created successfully'
  ): Response {
    return this.success(res, data, message, 201);
  }
  
  /**
   * No content response (204)
   */
  static noContent(res: Response): Response {
    return res.status(204).send();
  }
  
  /**
   * Success with pagination
   */
  static paginated<T>(
    res: Response,
    items: T[],
    total: number,
    page: number,
    limit: number,
    message = 'Success'
  ): Response {
    const totalPages = Math.ceil(total / limit);
    
    const response: ApiResponse<T[]> = {
      success: true,
      message,
      data: items,
      meta: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
        timestamp: new Date().toISOString(),
      },
    };
    
    // Add request ID if available
    const reqId = (res.req as any)?.id;
    if (reqId && response.meta) {
      response.meta.requestId = reqId;
    }
    
    return res.status(200).json(response);
  }
  
  /**
   * Error response
   */
  static error(
    res: Response,
    message = 'Internal server error',
    statusCode = 500,
    errors?: any[]
  ): Response {
    const response: ApiResponse = {
      success: false,
      message,
      error: message,
      errors,
      meta: {
        timestamp: new Date().toISOString(),
      },
    };
    
    // Add request ID if available
    const reqId = (res.req as any)?.id;
    if (reqId && response.meta) {
      response.meta.requestId = reqId;
    }
    
    return res.status(statusCode).json(response);
  }
  
  /**
   * Bad request response (400)
   */
  static badRequest(res: Response, message = 'Bad request', errors?: any[]): Response {
    return this.error(res, message, 400, errors);
  }
  
  /**
   * Unauthorized response (401)
   */
  static unauthorized(res: Response, message = 'Unauthorized'): Response {
    return this.error(res, message, 401);
  }
  
  /**
   * Forbidden response (403)
   */
  static forbidden(res: Response, message = 'Forbidden'): Response {
    return this.error(res, message, 403);
  }
  
  /**
   * Not found response (404)
   */
  static notFound(res: Response, message = 'Resource not found'): Response {
    return this.error(res, message, 404);
  }
  
  /**
   * Conflict response (409)
   */
  static conflict(res: Response, message = 'Conflict', errors?: any[]): Response {
    return this.error(res, message, 409, errors);
  }

  /**
   * Send a conflict response (409)
   * Used when an operation cannot be completed due to conflicts
   */
  static warning(res: Response, message: string, data?: any): void {
    res.status(409).json({
      success: false,
      message,
      data: data || null,
      error: 'CONFLICT',
    });
  }

  
  /**
   * Too many requests response (429)
   */
  static tooManyRequests(res: Response, message = 'Too many requests'): Response {
    return this.error(res, message, 429);
  }
  
  /**
   * Validation error response (422)
   */
  static validationError(res: Response, message = 'Validation failed', errors?: any[]): Response {
    return this.error(res, message, 422, errors);
  }
}

