import { Request, Response, NextFunction } from 'express';
import { ForbiddenError } from '../utils/error';
import { userRepository } from '../../repositories/user.repository';

/**
 * Middleware to check if user has pending deletion
 * Blocks all actions except deletion management endpoints
 */
export const checkDeletionStatus = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
  const userId = req.user?.id;
  
  if (!userId) {
    return next();
  }

  // Only check for regular users (you can extend to other roles if needed)
  if (req.user?.role === 'USER') {
    const user = await userRepository.findById(userId);
    
    if (user?.deletionStatus === 'pending') {
      throw new ForbiddenError(
        'Your account is scheduled for deletion. Please contact support or cancel deletion to continue.'
      );
    }
  }

  next();
};

