import multer, { Multer } from 'multer'; 
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { env } from '../../config/env';
import { BadRequestError } from '../utils/error';
import { RequestHandler } from 'express';

// ============================================================
// CONFIGURATION
// ============================================================

// Base directories (only used for path generation, NOT for writing)
const UPLOAD_DIR = path.join(__dirname, '../../../', env.UPLOAD_DIR || 'uploads');
const PUBLIC_DIR = path.join(UPLOAD_DIR, 'public');
const PRIVATE_DIR = path.join(UPLOAD_DIR, 'private');

// File size limits
const LIMITS = {
  LOGO: 2 * 1024 * 1024,           // 2MB
  DOCUMENT: 20 * 1024 * 1024,      // 20MB
  GALLERY: 5 * 1024 * 1024,        // 5MB
  SERVICE_IMAGE: 5 * 1024 * 1024,  // 5MB
  PRODUCT: 5 * 1024 * 1024,        // 5MB
  ADVERTISEMENT: 10 * 1024 * 1024, // 10MB
};

// Allowed file types
const ALLOWED = {
  IMAGE: ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'],
  DOCUMENT: ['application/pdf', 'image/jpeg', 'image/png'],
};

// ============================================================
// CREATE UPLOAD - MEMORY STORAGE
// ============================================================

/**
 * Generate a secure filename (UUID only, no path info)
 * Used for generating storage keys
 */
const generateSecureFilename = (originalName: string): string => {
  const ext = path.extname(originalName);
  const uuid = crypto.randomUUID();
  return `${uuid}${ext}`;
};

/**
 * Generate storage key for S3/SeaweedFS
 */
export const generateStorageKey = (
  type: 'public' | 'private',
  subPath: string,
  filename: string
): string => {
  const cleanPath = subPath.replace(/^\/+/, '').replace(/\/+$/, '');
  return `${type}/${cleanPath}/${filename}`;
};

/**
 * Create multer upload instance with memory storage
 * Returns an Express middleware
 */
const createUpload = (
  maxSize: number,
  allowedTypes: string[],
  fieldName = 'file',
  maxFiles = 1
): RequestHandler => {  // ← Explicitly return RequestHandler
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: maxSize,
      files: maxFiles,
    },
    fileFilter: (_req, file, cb) => {
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new BadRequestError(
          `Invalid file type. Allowed: ${allowedTypes.join(', ')}`
        ) as any);
      }
    },
  });

  if (maxFiles === 1) {
    return upload.single(fieldName) as RequestHandler;
  }
  return upload.array(fieldName, maxFiles) as RequestHandler;
};

// ============================================================
// EXPORTED UPLOAD MIDDLEWARE
// ============================================================

// Public files
export const uploadLogo: RequestHandler = createUpload(LIMITS.LOGO, ALLOWED.IMAGE, 'logo');
export const uploadGalleryImage: RequestHandler = createUpload(LIMITS.GALLERY, ALLOWED.IMAGE, 'image');
export const uploadServiceImage: RequestHandler = createUpload(LIMITS.SERVICE_IMAGE, ALLOWED.IMAGE, 'image');
export const uploadSpecialtyImage: RequestHandler = createUpload(LIMITS.GALLERY, ALLOWED.IMAGE, 'image');
export const uploadProductImage: RequestHandler = createUpload(LIMITS.PRODUCT, ALLOWED.IMAGE, 'image');
export const uploadAdvertisement: RequestHandler = createUpload(
  LIMITS.ADVERTISEMENT,
  ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'],
  'image'
);

// Private files
export const uploadDoctorDocument: RequestHandler = createUpload(LIMITS.DOCUMENT, ALLOWED.DOCUMENT, 'document');
export const uploadUserDocument: RequestHandler = createUpload(LIMITS.DOCUMENT, ALLOWED.DOCUMENT, 'document');
export const uploadClinicDocument: RequestHandler = createUpload(LIMITS.DOCUMENT, ALLOWED.DOCUMENT, 'document');
export const uploadSellerDocument: RequestHandler = createUpload(LIMITS.DOCUMENT, ALLOWED.DOCUMENT, 'document');

// Multiple files
export const uploadMultipleDocuments: RequestHandler = createUpload(LIMITS.DOCUMENT, ALLOWED.DOCUMENT, 'documents', 5);

// ============================================================
// EXPORT DIRECTORIES FOR OTHER MODULES
// ============================================================

export const UPLOAD_PATHS = {
  PUBLIC: {
    LOGOS: 'public/logos',
    GALLERY: 'public/gallery',
    SERVICE_IMAGES: 'public/service-images',
    PRODUCTS: 'public/products',
    SPECIALTY_IMAGES: 'public/specialty-images',
    ADVERTISEMENTS: 'public/advertisements',
  },
  PRIVATE: {
    DOCTOR_DOCUMENTS: 'private/doctor-documents',
    USER_DOCUMENTS: 'private/user-documents',
    CLINIC_DOCUMENTS: 'private/clinic-documents',
    SELLER_DOCUMENTS: 'private/ecommerce-documents',
  },
};

// ============================================================
// UTILITY: Get file URL by fileId (for API responses)
// ============================================================

export const getFileUrl = (fileId: string, isPublic: boolean = false): string => {
  const baseUrl = env.BASE_URL || 'http://localhost:3975';
  const endpoint = isPublic ? 'public' : 'private';
  return `${baseUrl}/api/v1/files/${endpoint}/${fileId}`;
};

