// src/core/middleware/auth.middleware.ts

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UnauthorizedError } from '../utils/error';
import { AuthUser } from '../../modules/auth/v1/auth.types';
import { sellerRepository } from '../../repositories/seller.repository';

const JWT_SECRET = process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export const authenticate = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
  try {
    // 1. Check cookie first (web)
    let token = req.cookies?.token;

    // 2. Check Authorization header (mobile)
    if (!token) {
      const authHeader = req.headers.authorization;
      if (authHeader?.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
      }
    }

    if (!token) {
      throw new UnauthorizedError('No token provided');
    }

    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;

    // ✅ Check if seller is still active
    if (decoded.role === 'SELLER') {
      const seller = await sellerRepository.findById(decoded.id);
      if (!seller || seller.status === 'BANNED' || seller.isSuspended) {
        throw new UnauthorizedError('Account is no longer active');
      }
    }

    req.user = decoded;
    next();
  } catch (error) {
    if (error instanceof UnauthorizedError) {
      next(error);
    } else {
      next(new UnauthorizedError('Invalid or expired token'));
    }
  }
};

