// src/core/events/listeners/otp-email.listener.ts

import { eventEmitter } from '../event-emitter';
import { logger } from '../../utils/logger';
import { emailQueue } from '../../../infrastructure/queues/email/email.queue';

export const registerOtpEmailListener = (): void => {
  // ============================================================
  // EXISTING - OTP Email
  // ============================================================

  eventEmitter.on(
    'send-otp-email',
    async (event: { email: string; name: string; otp: string }) => {
      try {
        await emailQueue.enqueueOtp(event);
        logger.info('[Email Queue] OTP email queued.', {
          email: event.email,
        });
      } catch (error) {
        logger.error('Failed to enqueue OTP email.', {
          error,
          email: event.email,
        });
      }
    }
  );

  // ============================================================
  // Password Setup Email (after approval)
  // ============================================================

  eventEmitter.on(
    'send-password-setup-email',
    async (event: {
      email: string;
      name: string;
      type: string;
      setupUrl: string;
    }) => {
      try {
        await emailQueue.enqueuePasswordSetup(event);
        logger.info('[Email Queue] Password setup email queued.', {
          email: event.email,
          type: event.type,
        });
      } catch (error) {
        logger.error('Failed to enqueue password setup email.', {
          error,
          email: event.email,
        });
      }
    }
  );

  // ============================================================
  // Application Rejection Email
  // ============================================================

  eventEmitter.on(
    'send-application-rejection-email',
    async (event: {
      email: string;
      name: string;
      type: string;
      reason?: string;
    }) => {
      try {
        await emailQueue.enqueueApplicationRejection(event);
        logger.info('[Email Queue] Application rejection email queued.', {
          email: event.email,
          type: event.type,
        });
      } catch (error) {
        logger.error('Failed to enqueue application rejection email.', {
          error,
          email: event.email,
        });
      }
    }
  );

  // ============================================================
  // Admin Notification (new application received)
  // ============================================================

  eventEmitter.on(
    'admin-notification',
    async (event: {
      type: string;
      applicationId: string;
      applicantType: string;
      message: string;
    }) => {
      try {
        logger.info('[Admin Notification] New application received.', {
          applicationId: event.applicationId,
          applicantType: event.applicantType,
          message: event.message,
        });
      } catch (error) {
        logger.error('Failed to process admin notification.', {
          error,
          applicationId: event.applicationId,
        });
      }
    }
  );

  // ============================================================
  // Password Reset Email
  // ============================================================

  eventEmitter.on(
    'send-password-reset-email',
    async (event: {
      email: string;
      name: string;
      type: string;
      resetUrl: string;
    }) => {
      try {
        await emailQueue.enqueuePasswordReset(event);
        logger.info('[Email Queue] Password reset email queued.', {
          email: event.email,
          type: event.type,
        });
      } catch (error) {
        logger.error('Failed to enqueue password reset email.', {
          error,
          email: event.email,
        });
      }
    }
  );

  logger.info('All email listeners registered');
};

