2 phase is the e shop

3 phase is as yassir system we will set the nurse

second dynamic patient number in a slot

 Senior decision:

Development:
Node Alpine ✔

Production:
Depends on project


<!-- booking race condition but look for atomic unique --> Done

<!-- payment duplicate  --> Done


auth mode now is plain

Grafana
Prometheus
MinIO
Nginx
RabbitMQ
Elasticsearch

note now the mode in pg bouncer is transaction 


<!-- adding service to the clinic --> Done

<!-- adding hospital too and their services --> Done

<!-- checking signed url with
changing storage from /uploads to /private-uploads --> Done



<!-- search slots then doctor --> Done
<!-- send credits by email --> Done


use nock in tests for auth

https://chat.deepseek.com/a/chat/s/70aaeb44-5680-4360-87c2-581d1b8ee00e check for background jobs