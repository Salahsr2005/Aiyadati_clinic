// prisma/seed.ts
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import crypto from 'crypto';

// ✅ NEW: Storage imports
import { StorageFactory } from '../src/core/storage/storage.factory';
import { generatePublicUrl } from '../src/core/utils/signed-url';

const prisma = new PrismaClient();

// ============================================================
// ENUM VALUES AS CONSTANTS (to avoid TS compilation issues)
// ============================================================

const Role = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  ADMIN: 'ADMIN',
  SUPPORT: 'SUPPORT',
} as const;

const DayOfWeek = {
  SUNDAY: 'SUNDAY',
  MONDAY: 'MONDAY',
  TUESDAY: 'TUESDAY',
  WEDNESDAY: 'WEDNESDAY',
  THURSDAY: 'THURSDAY',
  FRIDAY: 'FRIDAY',
  SATURDAY: 'SATURDAY',
} as const;

const PracticeType = {
  INDEPENDENT: 'INDEPENDENT',
  CLINIC_BASED: 'CLINIC_BASED',
  BOTH: 'BOTH',
} as const;

const InviteStatus = {
  PENDING: 'PENDING',
  ACCEPTED: 'ACCEPTED',
  REJECTED: 'REJECTED',
} as const;

const AppointmentStatus = {
  PENDING: 'PENDING',
  CONFIRMED: 'CONFIRMED',
  IN_PROGRESS: 'IN_PROGRESS',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',
  NO_SHOW: 'NO_SHOW',
} as const;

const AppointmentType = {
  IN_PERSON: 'IN_PERSON',
  VIDEO: 'VIDEO',
  HOME_VISIT: 'HOME_VISIT',
} as const;

const PaymentMethod = {
  CREDIT: 'CREDIT',
  ON_SITE: 'ON_SITE',
} as const;

const ReviewVisibility = {
  BOTH: 'BOTH',
  RATING_ONLY: 'RATING_ONLY',
  REVIEW_ONLY: 'REVIEW_ONLY',
  NONE: 'NONE',
} as const;

const PaymentStatus = {
  PENDING: 'PENDING',
  PAID: 'PAID',
  FAILED: 'FAILED',
  EXPIRED: 'EXPIRED',
} as const;

const FacilityType = {
  CLINIC: 'CLINIC',
  HOSPITAL: 'HOSPITAL',
} as const;

const OrderStatus = {
  PENDING: 'PENDING',
  CONFIRMED: 'CONFIRMED',
  PROCESSING: 'PROCESSING',
  SHIPPED: 'SHIPPED',
  DELIVERED: 'DELIVERED',
  CANCELLED: 'CANCELLED',
  RETURNED: 'RETURNED',
} as const;

const ProductStatus = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  OUT_OF_STOCK: 'OUT_OF_STOCK',
} as const;

const OrderPaymentMethod = {
  CHARGILY: 'CHARGILY',
  CASH_ON_DELIVERY: 'CASH_ON_DELIVERY',
} as const;

// ============================================================
// DIRECTORY STRUCTURE - Keep for local fallback
// ============================================================

const UPLOAD_ROOT = path.join(__dirname, '..', 'uploads');

const DIRS = {
  publicLogos: path.join(UPLOAD_ROOT, 'public', 'logos'),
  publicGallery: path.join(UPLOAD_ROOT, 'public', 'gallery'),
  publicServiceImages: path.join(UPLOAD_ROOT, 'public', 'service-images'),
  publicProducts: path.join(UPLOAD_ROOT, 'public', 'products'),
  privateDoctorDocuments: path.join(UPLOAD_ROOT, 'private', 'doctor-documents'),
  privateUserDocuments: path.join(UPLOAD_ROOT, 'private', 'user-documents'),
  privateClinicDocuments: path.join(UPLOAD_ROOT, 'private', 'clinic-documents'),
  privateEcommerceDocuments: path.join(UPLOAD_ROOT, 'private', 'ecommerce-documents'),
};

// ============================================================
// IMAGE & DOCUMENT URLS
// ============================================================

const DOCTOR_PHOTOS = [
  'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop',
];

const CLINIC_PHOTOS = [
  'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=800&h=600&fit=crop',
];

const GALLERY_PHOTOS = [
  'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1551076805-e1869033e561?w=800&h=600&fit=crop',
  'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&h=600&fit=crop',
];

const PRODUCT_PHOTOS = [
  'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=800&fit=crop',
  'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=800&fit=crop',
  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&h=800&fit=crop',
  'https://images.unsplash.com/photo-1503602642458-232111445657?w=800&h=800&fit=crop',
  'https://images.unsplash.com/photo-1560343090-f0409e92791a?w=800&h=800&fit=crop',
  'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&h=800&fit=crop',
];

// ============================================================
// DATA ARRAYS
// ============================================================

const wilayasData = [
  { code: 1, nameFr: 'Adrar', nameAr: 'أدرار' },
  { code: 2, nameFr: 'Chlef', nameAr: 'الشلف' },
  { code: 3, nameFr: 'Laghouat', nameAr: 'الأغواط' },
  { code: 4, nameFr: 'Oum El Bouaghi', nameAr: 'أم البواقي' },
  { code: 5, nameFr: 'Batna', nameAr: 'باتنة' },
  { code: 6, nameFr: 'Béjaïa', nameAr: 'بجاية' },
  { code: 7, nameFr: 'Biskra', nameAr: 'بسكرة' },
  { code: 8, nameFr: 'Béchar', nameAr: 'بشار' },
  { code: 9, nameFr: 'Blida', nameAr: 'البليدة' },
  { code: 10, nameFr: 'Bouïra', nameAr: 'البويرة' },
  { code: 11, nameFr: 'Tamanrasset', nameAr: 'تمنراست' },
  { code: 12, nameFr: 'Tébessa', nameAr: 'تبسة' },
  { code: 13, nameFr: 'Tlemcen', nameAr: 'تلمسان' },
  { code: 14, nameFr: 'Tiaret', nameAr: 'تيارت' },
  { code: 15, nameFr: 'Tizi Ouzou', nameAr: 'تيزي وزو' },
  { code: 16, nameFr: 'Alger', nameAr: 'الجزائر' },
  { code: 17, nameFr: 'Djelfa', nameAr: 'الجلفة' },
  { code: 18, nameFr: 'Jijel', nameAr: 'جيجل' },
  { code: 19, nameFr: 'Sétif', nameAr: 'سطيف' },
  { code: 20, nameFr: 'Saïda', nameAr: 'سعيدة' },
  { code: 21, nameFr: 'Skikda', nameAr: 'سكيكدة' },
  { code: 22, nameFr: 'Sidi Bel Abbès', nameAr: 'سيدي بلعباس' },
  { code: 23, nameFr: 'Annaba', nameAr: 'عنابة' },
  { code: 24, nameFr: 'Guelma', nameAr: 'قالمة' },
  { code: 25, nameFr: 'Constantine', nameAr: 'قسنطينة' },
  { code: 26, nameFr: 'Médéa', nameAr: 'المدية' },
  { code: 27, nameFr: 'Mostaganem', nameAr: 'مستغانم' },
  { code: 28, nameFr: "M'Sila", nameAr: 'المسيلة' },
  { code: 29, nameFr: 'Mascara', nameAr: 'معسكر' },
  { code: 30, nameFr: 'Ouargla', nameAr: 'ورقلة' },
  { code: 31, nameFr: 'Oran', nameAr: 'وهران' },
  { code: 32, nameFr: 'El Bayadh', nameAr: 'البيض' },
  { code: 33, nameFr: 'Illizi', nameAr: 'إيليزي' },
  { code: 34, nameFr: 'Bordj Bou Arréridj', nameAr: 'برج بوعريريج' },
  { code: 35, nameFr: 'Boumerdès', nameAr: 'بومرداس' },
  { code: 36, nameFr: 'El Tarf', nameAr: 'الطارف' },
  { code: 37, nameFr: 'Tindouf', nameAr: 'تندوف' },
  { code: 38, nameFr: 'Tissemsilt', nameAr: 'تيسمسيلت' },
  { code: 39, nameFr: 'El Oued', nameAr: 'الوادي' },
  { code: 40, nameFr: 'Khenchela', nameAr: 'خنشلة' },
  { code: 41, nameFr: 'Souk Ahras', nameAr: 'سوق أهراس' },
  { code: 42, nameFr: 'Tipaza', nameAr: 'تيبازة' },
  { code: 43, nameFr: 'Mila', nameAr: 'ميلة' },
  { code: 44, nameFr: 'Aïn Defla', nameAr: 'عين الدفلى' },
  { code: 45, nameFr: 'Naâma', nameAr: 'النعامة' },
  { code: 46, nameFr: 'Aïn Témouchent', nameAr: 'عين تموشنت' },
  { code: 47, nameFr: 'Ghardaïa', nameAr: 'غرداية' },
  { code: 48, nameFr: 'Relizane', nameAr: 'غليزان' },
  { code: 49, nameFr: 'Timimoun', nameAr: 'تيميمون' },
  { code: 50, nameFr: 'Bordj Badji Mokhtar', nameAr: 'برج باجي مختار' },
  { code: 51, nameFr: 'Ouled Djellal', nameAr: 'أولاد جلال' },
  { code: 52, nameFr: 'Béni Abbès', nameAr: 'بني عباس' },
  { code: 53, nameFr: 'In Salah', nameAr: 'عين صالح' },
  { code: 54, nameFr: 'In Guezzam', nameAr: 'عين قزام' },
  { code: 55, nameFr: 'Touggourt', nameAr: 'تقرت' },
  { code: 56, nameFr: 'Djanet', nameAr: 'جانت' },
  { code: 57, nameFr: "El M'Ghair", nameAr: 'المغير' },
  { code: 58, nameFr: 'El Menia', nameAr: 'المنيعة' },
];

const specialtiesData = [
  { nameFr: 'Cardiologie', nameAr: 'طب القلب' },
  { nameFr: 'Dermatologie', nameAr: 'طب الجلد' },
  { nameFr: 'Pédiatrie', nameAr: 'طب الأطفال' },
  { nameFr: 'Ophtalmologie', nameAr: 'طب العيون' },
  { nameFr: 'Orthopédie', nameAr: 'جراحة العظام' },
  { nameFr: 'Médecine Générale', nameAr: 'طب عام' },
  { nameFr: 'Gynécologie', nameAr: 'طب النساء' },
  { nameFr: 'Neurologie', nameAr: 'طب الأعصاب' },
  { nameFr: 'Psychiatrie', nameAr: 'الطب النفسي' },
  { nameFr: 'ORL', nameAr: 'أنف أذن حنجرة' },
  { nameFr: 'Endocrinologie', nameAr: 'الغدد الصماء' },
  { nameFr: 'Rhumatologie', nameAr: 'طب الروماتيزم' },
  { nameFr: 'Urologie', nameAr: 'طب المسالك البولية' },
  { nameFr: 'Gastro-entérologie', nameAr: 'الجهاز الهضمي' },
  { nameFr: 'Pneumologie', nameAr: 'طب الرئة' },
];

const algerianFirstNames = [
  'Mohamed', 'Ahmed', 'Abdelkader', 'Youssef', 'Omar', 'Ali', 'Karim', 'Amine', 'Sofiane', 'Rachid',
  'Fatima', 'Amina', 'Meriem', 'Sarah', 'Nadia', 'Lamia', 'Karima', 'Samira', 'Yasmine', 'Aicha',
  'Bilal', 'Mehdi', 'Nabil', 'Walid', 'Hichem', 'Samir', 'Nacer', 'Djamel', 'Farid', 'Malik',
  'Lila', 'Souad', 'Nora', 'Assia', 'Djamila', 'Zahra', 'Hafsa', 'Chahrazed', 'Warda', 'Kenza',
];

const algerianLastNames = [
  'Benali', 'Khelifi', 'Said', 'Boudiaf', 'Zerrouk', 'Mansouri', 'Hamidi', 'Brahimi', 'Cherif', 'Djebbar',
  'Boukhatem', 'Ait Ouarab', 'Bensalem', 'Hamdi', 'Ziani', 'Belkacem', 'Mokhtari', 'Fares', 'Boutaleb', 'Chikhi',
  'Benzema', 'Kaddour', 'Ould Ali', 'Bouaziz', 'Amara', 'Touati', 'Larbi', 'Meziane', 'Benamara', 'Boudjemaa',
  'Slimani', 'Benslimane', 'Othmani', 'Bouzid', 'Chabane', 'Rahmani', 'Haddad', 'Boumediene', 'Meddour', 'Kaci',
];

const clinicNames = [
  { nameFr: 'Clinique El Wouroud', nameAr: 'عيادة الورود' },
  { nameFr: 'Clinique Errahma', nameAr: 'عيادة الرحمة' },
  { nameFr: 'Clinique El Amane', nameAr: 'عيادة الأمان' },
  { nameFr: 'Clinique Ibn Sina', nameAr: 'عيادة ابن سينا' },
];

const productCategoriesData = [
  { nameFr: 'Équipement Médical', nameAr: 'معدات طبية', slug: 'medical-equipment' },
  { nameFr: 'Médicaments', nameAr: 'أدوية', slug: 'medications' },
  { nameFr: 'Suppléments', nameAr: 'مكملات غذائية', slug: 'supplements' },
  { nameFr: 'Hygiène', nameAr: 'منتجات النظافة', slug: 'hygiene' },
  { nameFr: 'Livres Médicaux', nameAr: 'كتب طبية', slug: 'medical-books' },
  { nameFr: 'Orthopédie', nameAr: 'منتجات العظام', slug: 'orthopedic-products' },
];

const shippingCompaniesData = [
  { name: 'Yalidine', trackingUrl: 'https://yalidine.com/track/' },
  { name: 'DHL Algérie', trackingUrl: 'https://www.dhl.com/dz-en/home/tracking.html' },
  { name: 'EMS Algérie', trackingUrl: 'https://www.poste.dz/ems/tracking' },
];

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function ensureDirectories() {
  console.log('📁 Ensuring upload directories exist...');
  for (const dir of Object.values(DIRS)) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`  ✅ Created ${dir}`);
    }
  }
}

async function downloadFile(url: string, retries = 3): Promise<Buffer | null> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const buffer = await new Promise<Buffer>((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        
        const req = client.get(url, { timeout: 30000 }, (response: any) => {
          if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
            const redirectUrl = response.headers.location;
            const fullUrl = redirectUrl.startsWith('http') ? redirectUrl : new URL(redirectUrl, url).toString();
            downloadFile(fullUrl).then((result) => {
              if (result) {
                resolve(result);
              } else {
                reject(new Error('Redirect failed'));
              }
            }).catch(reject);
            return;
          }
          
          if (response.statusCode !== 200) {
            reject(new Error(`Status ${response.statusCode}`));
            return;
          }
          
          const chunks: Buffer[] = [];
          response.on('data', (chunk: Buffer) => chunks.push(chunk));
          response.on('end', () => {
            const buffer = Buffer.concat(chunks);
            if (buffer.length === 0) {
              reject(new Error('Empty response'));
            } else {
              resolve(buffer);
            }
          });
          response.on('error', reject);
        });
        
        req.on('error', reject);
        req.on('timeout', () => {
          req.destroy();
          reject(new Error('Timeout'));
        });
        req.end();
      });
      
      if (buffer && buffer.length > 0) {
        return buffer;
      }
    } catch (error) {
      if (attempt === retries) {
        console.warn(`  ⚠️  Failed to download ${url} after ${retries} attempts: ${error}`);
        return null;
      }
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
  return null;
}

// ✅ UPDATED: Upload to object storage instead of local file system
async function uploadToStorage(
  buffer: Buffer,
  originalName: string,
  mimeType: string,
  path: string,
  isPublic: boolean = true
): Promise<{ fileId: string; storageKey: string; filePath: string; size: number } | null> {
  if (!buffer || buffer.length === 0) {
    console.warn(`  ⚠️  Empty buffer, skipping upload`);
    return null;
  }
  
  try {
    const storage = StorageFactory.getInstance();
    
    const result = await storage.upload(
      {
        buffer: buffer,
        originalName: originalName,
        mimeType: mimeType,
        size: buffer.length,
      },
      {
        path: path,
        isPublic: isPublic,
        contentType: mimeType,
        cacheControl: isPublic ? 'public, max-age=31536000, immutable' : 'private, no-cache',
        metadata: {
          source: 'seed',
          uploadedAt: new Date().toISOString(),
        },
      }
    );

    return {
      fileId: result.id,
      storageKey: result.key,
      filePath: result.key,
      size: result.size,
    };
  } catch (error) {
    console.warn(`  ⚠️  Failed to upload to storage: ${error}`);
    return null;
  }
}

// ✅ UPDATED: Save file with fallback to local if storage fails
async function saveFile(buffer: Buffer, dir: string, ext: string): Promise<string | null> {
  // First try: Upload to object storage
  const mimeType = ext === 'png' ? 'image/png' 
    : ext === 'webp' ? 'image/webp' 
    : ext === 'gif' ? 'image/gif' 
    : ext === 'svg' ? 'image/svg+xml'
    : 'image/jpeg';
  
  // Determine the path based on the directory
  let storagePath = '';
  let isPublic = true;
  
  if (dir.includes('public/logos')) storagePath = 'public/logos';
  else if (dir.includes('public/gallery')) storagePath = 'public/gallery';
  else if (dir.includes('public/service-images')) storagePath = 'public/service-images';
  else if (dir.includes('public/products')) storagePath = 'public/products';
  else if (dir.includes('private/doctor-documents')) { storagePath = 'private/doctor-documents'; isPublic = false; }
  else if (dir.includes('private/user-documents')) { storagePath = 'private/user-documents'; isPublic = false; }
  else if (dir.includes('private/clinic-documents')) { storagePath = 'private/clinic-documents'; isPublic = false; }
  else if (dir.includes('private/ecommerce-documents')) { storagePath = 'private/ecommerce-documents'; isPublic = false; }
  else {
    // Fallback: use dir name
    const parts = dir.split('/');
    const lastPart = parts[parts.length - 1];
    const parentPart = parts[parts.length - 2] || 'public';
    storagePath = `${parentPart}/${lastPart}`;
  }
  
  const filename = `${uuidv4()}.${ext}`;
  const filepath = path.join(dir, filename);
  
  try {
    // Try object storage first
    const uploadResult = await uploadToStorage(buffer, filename, mimeType, storagePath, isPublic);
    
    if (uploadResult) {
      // Also save locally as fallback (keep existing behavior for backward compatibility)
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      await fs.promises.writeFile(filepath, buffer);
      
      // Return the filename (local) - the storage key is used for actual file access
      // We return the filename so database records have a reference
      return filename;
    }
    
    // Fallback: Save locally only
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    await fs.promises.writeFile(filepath, buffer);
    
    const stats = await fs.promises.stat(filepath);
    if (stats.size === 0) {
      console.warn(`  ⚠️  File ${filename} was written but size is 0`);
      return null;
    }
    
    return filename;
  } catch (error) {
    console.warn(`  ⚠️  Failed to save file to ${dir}: ${error}`);
    return null;
  }
}

const fileCache: Map<string, Buffer> = new Map();

async function getCachedFile(url: string): Promise<Buffer | null> {
  if (fileCache.has(url)) {
    const cached = fileCache.get(url)!;
    if (cached && cached.length > 0) {
      return cached;
    }
    fileCache.delete(url);
  }
  
  const buffer = await downloadFile(url);
  if (buffer && buffer.length > 0) {
    fileCache.set(url, buffer);
    return buffer;
  }
  
  return null;
}

async function getPlaceholderBuffer(): Promise<Buffer> {
  const minimalPNG = Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
    0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41,
    0x54, 0x78, 0x9C, 0x63, 0x00, 0x00, 0x00, 0x02,
    0x00, 0x01, 0x5B, 0x7B, 0xBC, 0xFE, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42,
    0x60, 0x82
  ]);
  return minimalPNG;
}

async function generateSimplePDF(): Promise<Buffer> {
  const pdfContent = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 123 >>
stream
BT
/F1 24 Tf
100 700 Td
(Generated Document) Tj
/F1 18 Tf
0 -40 Td
(This is a placeholder PDF document generated for seeding purposes.) Tj
0 -30 Td
(Please replace with actual documents.) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
0000000015 00000 n 
0000000068 00000 n 
0000000130 00000 n 
0000000216 00000 n 
0000000422 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
480
%%EOF`;

  return Buffer.from(pdfContent, 'utf-8');
}

async function getDocumentBuffer(): Promise<Buffer> {
  const pdfUrls = [
    'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    'https://www.africau.edu/images/default/sample.pdf',
  ];
  
  for (const url of pdfUrls) {
    const buffer = await getCachedFile(url);
    if (buffer && buffer.length > 0) {
      return buffer;
    }
  }
  
  console.log('  ℹ️  Using generated PDF placeholder for documents');
  return await generateSimplePDF();
}

let cachedDocumentBuffer: Buffer | null = null;

async function getDocumentBufferCached(): Promise<Buffer> {
  if (!cachedDocumentBuffer) {
    cachedDocumentBuffer = await getDocumentBuffer();
  }
  return cachedDocumentBuffer;
}

function randomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function randomSubset<T>(arr: T[], count: number): T[] {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, arr.length));
}

// ============================================================
// CLEAR DATABASE
// ============================================================

async function clearDatabase() {
  console.log('🧹 Clearing existing data...');
  
  const deleteOrder = [
    'orderStatusHistory', 'orderItem', 'order', 'productImage', 'product', 'category',
    'sellerDocument', 'shippingCompany', 'clinicServiceImage', 'clinicServiceDoctor',
    'clinicService', 'clinicGallery', 'clinicDocument', 'doctorLogo', 'doctorDocument',
    'userDocument', 'notification', 'userDevice', 'chatMessage', 'chatRoom',
    'creditTransaction', 'payment', 'auditLog', 'appointment', 'slot', 'doctorBreak',
    'doctorAvailability', 'clinicDoctor', 'doctorSpecialty', 'doctorConfig',
    'doctorReview', 'clinicReview', 'doctor', 'clinicWorkingHours', 'clinicRoom',
    'clinic', 'userWallet', 'contactUser', 'user', 'specialty', 'baladya', 'wilaya',
    'admin', 'superAdmin', 'healthCheck', 'creditPrice', 'fileRegistry',
  ];

  for (const model of deleteOrder) {
    try {
      await (prisma as any)[model].deleteMany();
    } catch (e) {
      // Ignore
    }
  }
  console.log('✅ Database cleared');
}

async function cleanupOldFiles() {
  console.log('🗑️  Cleaning up old uploaded files...');
  for (const dir of Object.values(DIRS)) {
    if (fs.existsSync(dir)) {
      const files = fs.readdirSync(dir);
      for (const file of files) {
        try { fs.unlinkSync(path.join(dir, file)); } catch (e) {}
      }
    }
  }
  console.log('✅ Old files cleaned up');
}

// ============================================================
// SEED FUNCTIONS
// ============================================================

async function seedSuperAdmins() {
  console.log('  🔑 Seeding 1 super admin...');
  const hashedPassword = await bcrypt.hash('superadmin123', 12);
  await prisma.superAdmin.create({
    data: { 
      email: 'superadmin@iyadati.dz', 
      name: 'Super Admin Principal',
      password: hashedPassword,
      role: Role.SUPER_ADMIN as any,
    },
  });
  console.log(`  ✅ ${await prisma.superAdmin.count()} super admin seeded`);
}

async function seedAdmins() {
  console.log('  👮 Seeding 3 admins...');
  const hashedPassword = await bcrypt.hash('admin123456', 12);
  const adminRoles = ['ADMIN', 'SUPPORT', 'MODERATOR'];
  for (let i = 0; i < 3; i++) {
    await prisma.admin.create({
      data: {
        email: `admin${i + 1}@iyadati.dz`,
        name: `Admin ${i + 1}`,
        password: hashedPassword,
        role: (i === 0 ? Role.ADMIN : Role.SUPPORT) as any,
        adminRole: adminRoles[i % adminRoles.length],
        createdBy: 'system',
      },
    });
  }
  console.log(`  ✅ ${await prisma.admin.count()} admins seeded`);
}

async function seedWilayas() {
  console.log('  📍 Seeding 58 wilayas...');
  for (const w of wilayasData) {
    await prisma.wilaya.create({
      data: { nameFr: w.nameFr, nameAr: w.nameAr, code: w.code },
    });
  }
  console.log(`  ✅ ${await prisma.wilaya.count()} wilayas seeded`);
}

async function seedSpecialties() {
  console.log('  🏥 Seeding 15 specialties...');
  for (const s of specialtiesData) {
    await prisma.specialty.create({
      data: { nameFr: s.nameFr, nameAr: s.nameAr },
    });
  }
  console.log(`  ✅ ${await prisma.specialty.count()} specialties seeded`);
}

async function seedCreditPrices() {
  console.log('  💰 Seeding credit prices...');
  const prices = [500, 1000, 2000, 5000, 10000];
  for (const price of prices) {
    await prisma.creditPrice.create({ data: { price } });
  }
  console.log(`  ✅ ${await prisma.creditPrice.count()} credit prices seeded`);
}

async function seedUsers(count: number) {
  console.log(`  👤 Seeding ${count} users...`);
  const wilayas = await prisma.wilaya.findMany();
  const hashedPassword = await bcrypt.hash('user123456', 12);
  const createdUsers = [];
  
  for (let i = 0; i < count; i++) {
    const firstName = randomElement(algerianFirstNames);
    const lastName = randomElement(algerianLastNames);
    const wilaya = randomElement(wilayas);
    const canPost = Math.random() < 0.3;
    
    const user = await prisma.user.create({
      data: {
        email: `user${i + 1}@gmail.com`,
        firstName,
        lastName,
        phone: `05${String(randomInt(10000000, 99999999))}`,
        dateOfBirth: randomDate(new Date(1950, 0, 1), new Date(2005, 11, 31)),
        wilayaId: wilaya.id,
        password: hashedPassword,
        isVerified: Math.random() < 0.9,
        canPost,
        noShowCount: randomInt(0, 3),
        trustPoints: randomInt(0, 100),
        trustLevel: randomInt(0, 3),
        isSuspended: Math.random() < 0.05,
        suspensionReason: Math.random() < 0.05 ? 'Comportement inapproprié' : null,
      },
    });
    createdUsers.push(user);
    
    await prisma.userWallet.create({
      data: { userId: user.id, credits: randomInt(0, 50) },
    });
  }
  console.log(`  ✅ ${await prisma.user.count()} users seeded`);
  return createdUsers;
}

async function seedContactUsers(users: any[]) {
  console.log('  👨‍👩‍👧‍👦 Seeding contact users...');
  const relationships = ['parent', 'child', 'spouse', 'sibling', 'other'];
  let count = 0;
  for (const user of randomSubset(users, 100)) {
    const numContacts = randomInt(1, 3);
    for (let j = 0; j < numContacts; j++) {
      await prisma.contactUser.create({
        data: {
          userId: user.id,
          firstName: randomElement(algerianFirstNames),
          lastName: randomElement(algerianLastNames),
          phone: `06${String(randomInt(10000000, 99999999))}`,
          dateOfBirth: randomDate(new Date(1950, 0, 1), new Date(2020, 11, 31)),
          relationship: randomElement(relationships),
          isActive: Math.random() < 0.9,
        },
      });
      count++;
    }
  }
  console.log(`  ✅ ${count} contact users seeded`);
}

// ✅ UPDATED: Seed user documents with object storage
async function seedUserDocuments(users: any[]) {
  console.log('  📄 Seeding user documents...');
  const pdfBuffer = await getDocumentBufferCached();
  
  let count = 0;
  const docTypes = ['prescription', 'lab_result', 'x_ray', 'vaccination', 'certificate', 'referral'];
  
  for (const user of randomSubset(users, 100)) {
    const numDocs = randomInt(1, 3);
    for (let j = 0; j < numDocs; j++) {
      const docType = randomElement(docTypes);
      
      // Upload to object storage
      const uploadResult = await uploadToStorage(
        pdfBuffer,
        `${docType}_${user.firstName}_${user.lastName}.pdf`,
        'application/pdf',
        'private/user-documents',
        false
      );
      
      if (!uploadResult) {
        console.warn(`  ⚠️  Failed to upload document for user ${user.id}`);
        continue;
      }
      
      await prisma.userDocument.create({
        data: {
          userId: user.id,
          fileId: uploadResult.fileId,
          storageKey: uploadResult.storageKey,
          fileName: `${docType}_${Date.now()}.pdf`,
          fileType: 'application/pdf',
          fileSize: uploadResult.size,
          filePath: uploadResult.filePath,
          storageType: 'private',
          category: 'medical',
          docType,
          title: `Document médical - ${docType}`,
          description: `Document ${docType} pour ${user.firstName} ${user.lastName}`,
          docDate: randomDate(new Date(2020, 0, 1), new Date()),
          tags: [docType],
        },
      });
      count++;
    }
  }
  console.log(`  ✅ ${count} user documents seeded`);
}

// ✅ UPDATED: Seed doctors with object storage
async function seedDoctors(count: number) {
  console.log(`  👨‍⚕️ Seeding ${count} doctors...`);
  const wilayas = await prisma.wilaya.findMany();
  const specialties = await prisma.specialty.findMany();
  const hashedPassword = await bcrypt.hash('doctor123456', 12);
  
  console.log('  ⬇️  Downloading doctor photos...');
  const photoBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < Math.min(count, DOCTOR_PHOTOS.length); i++) {
    const buffer = await getCachedFile(DOCTOR_PHOTOS[i]);
    photoBuffers.push(buffer);
  }
  
  const placeholderBuffer = await getPlaceholderBuffer();
  const pdfBuffer = await getDocumentBufferCached();
  
  const createdDoctors = [];
  const practiceTypes = [PracticeType.INDEPENDENT, PracticeType.CLINIC_BASED, PracticeType.BOTH];
  const reviewVisibilities = [ReviewVisibility.BOTH, ReviewVisibility.RATING_ONLY, ReviewVisibility.REVIEW_ONLY, ReviewVisibility.NONE];
  
  for (let i = 0; i < count; i++) {
    const firstNameFr = randomElement(algerianFirstNames);
    const lastNameFr = randomElement(algerianLastNames);
    const wilaya = randomElement(wilayas);
    const specialty = randomElement(specialties);
    const practiceType = randomElement(practiceTypes);
    const reviewVisibility = randomElement(reviewVisibilities);
    
    const photoBuffer = photoBuffers[i % photoBuffers.length] || placeholderBuffer;
    const photoFilename = await saveFile(photoBuffer, DIRS.publicLogos, 'jpg');
    
    const photoPath = photoFilename ? `public/logos/${photoFilename}` : 'public/default-doctor.jpg';
    const photoFileId = photoFilename ? crypto.randomUUID() : 'default';
    
    const doctor = await prisma.doctor.create({
      data: {
        email: `dr.${firstNameFr.toLowerCase()}.${lastNameFr.toLowerCase()}${i + 1}@iyadati.dz`,
        password: hashedPassword,
        firstNameFr, firstNameAr: firstNameFr,
        lastNameFr, lastNameAr: lastNameFr,
        phone: `066${String(randomInt(100000, 999999))}`,
        wilayaId: wilaya.id,
        practiceType: practiceType as any,
        yearsOfExp: randomInt(1, 35),
        isVerified: Math.random() < 0.9,
        isCompleted: Math.random() < 0.95,
        isSuspended: Math.random() < 0.05,
        bioFr: `Docteur ${firstNameFr} ${lastNameFr}, spécialiste basé à ${wilaya.nameFr}.`,
        bioAr: `الدكتور ${firstNameFr} ${lastNameFr}، أخصائي مقيم في ${wilaya.nameAr}.`,
        photoPath, photoFileId,
        latitude: 36 + Math.random() * 4,
        longitude: 0 + Math.random() * 8,
        reviewVisibility: reviewVisibility as any,
        avgRating: Math.random() < 0.5 ? randomInt(30, 50) / 10 : null,
        totalReviews: randomInt(0, 200),
      },
    });
    createdDoctors.push(doctor);
    
    if (photoFilename) {
      // Upload logo to object storage
      const uploadResult = await uploadToStorage(
        photoBuffer,
        `logo_${firstNameFr}_${lastNameFr}.jpg`,
        'image/jpeg',
        'public/logos',
        true
      );
      
      if (uploadResult) {
        await prisma.doctorLogo.create({
          data: {
            doctorId: doctor.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            fileName: `logo_${firstNameFr}_${lastNameFr}.jpg`,
            fileType: 'image/jpeg',
            fileSize: uploadResult.size,
            filePath: uploadResult.filePath,
            storageType: 'public',
          },
        });
      }
    }
    
    // Specialties
    const numSpecialties = randomInt(1, 3);
    for (const spec of randomSubset(specialties, numSpecialties)) {
      try { await prisma.doctorSpecialty.create({ data: { doctorId: doctor.id, specialtyId: spec.id } }); } catch (e) {}
    }
    
    // Documents - upload to object storage
    const docTypes = ['degree', 'license', 'id_card', 'certification', 'insurance'];
    for (let j = 0; j < randomInt(2, 4); j++) {
      const docType = randomElement(docTypes);
      
      const uploadResult = await uploadToStorage(
        pdfBuffer,
        `${docType}_${lastNameFr}.pdf`,
        'application/pdf',
        'private/doctor-documents',
        false
      );
      
      if (uploadResult) {
        await prisma.doctorDocument.create({
          data: {
            doctorId: doctor.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            fileName: `${docType}_${lastNameFr}.pdf`,
            fileType: 'application/pdf',
            fileSize: uploadResult.size,
            filePath: uploadResult.filePath,
            storageType: 'private',
            category: 'verification',
            docType,
          },
        });
      }
    }
    
    // Availabilities
    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    for (const day of randomSubset(days, randomInt(3, 6))) {
      await prisma.doctorAvailability.create({
        data: {
          doctorId: doctor.id,
          dayOfWeek: day as any,
          startTime: new Date(`1970-01-01T${String(randomInt(8, 10)).padStart(2, '0')}:00:00Z`),
          endTime: new Date(`1970-01-01T${String(randomInt(16, 19)).padStart(2, '0')}:00:00Z`),
          isActive: Math.random() < 0.9,
        },
      });
    }
    
    // Config
    await prisma.doctorConfig.create({
      data: {
        doctorId: doctor.id,
        slotDuration: randomElement([15, 20, 30, 45, 60]),
        bufferTime: randomElement([0, 5, 10, 15]),
        maxPerSlot: randomInt(1, 3),
      },
    });
    
    // Breaks
    for (let j = 0; j < randomInt(0, 2); j++) {
      const startDate = randomDate(new Date(2024, 0, 1), new Date(2025, 11, 31));
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + randomInt(1, 14));
      await prisma.doctorBreak.create({
        data: {
          doctorId: doctor.id, startDate, endDate,
          reason: randomElement(['vacation', 'sick leave', 'conference', 'training', 'personal']),
          isAllDay: Math.random() < 0.8,
        },
      });
    }
    
    if ((i + 1) % 2 === 0 || i === count - 1) {
      console.log(`  📊 Created ${i + 1}/${count} doctors`);
    }
  }
  console.log(`  ✅ ${await prisma.doctor.count()} doctors seeded`);
  return createdDoctors;
}

// ✅ UPDATED: Seed clinics with object storage
async function seedClinics(count: number) {
  console.log(`  🏥 Seeding ${count} clinics...`);
  const wilayas = await prisma.wilaya.findMany();
  const hashedPassword = await bcrypt.hash('clinic123456', 12);
  
  console.log('  ⬇️  Downloading clinic photos...');
  const photoBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < Math.min(count, CLINIC_PHOTOS.length); i++) {
    const buffer = await getCachedFile(CLINIC_PHOTOS[i]);
    photoBuffers.push(buffer);
  }
  
  console.log('  ⬇️  Downloading gallery photos...');
  const galleryBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < Math.min(count * 4, GALLERY_PHOTOS.length); i++) {
    const buffer = await getCachedFile(GALLERY_PHOTOS[i % GALLERY_PHOTOS.length]);
    galleryBuffers.push(buffer);
  }
  
  const placeholderBuffer = await getPlaceholderBuffer();
  const pdfBuffer = await getDocumentBufferCached();
  
  const createdClinics = [];
  const facilityTypes = [FacilityType.CLINIC, FacilityType.HOSPITAL];
  const reviewVisibilities = [ReviewVisibility.BOTH, ReviewVisibility.RATING_ONLY, ReviewVisibility.REVIEW_ONLY, ReviewVisibility.NONE];
  
  for (let i = 0; i < count; i++) {
    const clinicName = clinicNames[i % clinicNames.length];
    const wilaya = randomElement(wilayas);
    const facilityType = randomElement(facilityTypes);
    const reviewVisibility = randomElement(reviewVisibilities);
    
    const photoBuffer = photoBuffers[i % photoBuffers.length] || placeholderBuffer;
    const logoFilename = await saveFile(photoBuffer, DIRS.publicLogos, 'png');
    const logoPath = logoFilename ? `public/logos/${logoFilename}` : 'public/default-clinic.png';
    
    const clinic = await prisma.clinic.create({
      data: {
        nameFr: clinicName.nameFr,
        nameAr: clinicName.nameAr,
        email: `contact${i + 1}@${clinicName.nameFr.toLowerCase().replace(/\s+/g, '')}.dz`,
        phone: `055${String(randomInt(100000, 999999))}`,
        password: hashedPassword,
        wilayaId: wilaya.id,
        latitude: 36 + Math.random() * 4,
        longitude: 0 + Math.random() * 8,
        facilityType: facilityType as any,
        isVerified: Math.random() < 0.9,
        isSuspended: Math.random() < 0.05,
        isCompleted: Math.random() < 0.95,
        descriptionFr: `${clinicName.nameFr} - Établissement médical moderne à ${wilaya.nameFr}.`,
        descriptionAr: `${clinicName.nameAr} - مؤسسة طبية حديثة في ${wilaya.nameAr}.`,
        logoPath,
        reviewVisibility: reviewVisibility as any,
        avgRating: Math.random() < 0.5 ? randomInt(30, 50) / 10 : null,
        totalReviews: randomInt(0, 300),
      },
    });
    createdClinics.push(clinic);
    
    // Working Hours
    const allDays = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    for (const day of allDays) {
      const isOpen = day !== 'FRIDAY' || Math.random() < 0.3;
      await prisma.clinicWorkingHours.create({
        data: {
          clinicId: clinic.id,
          dayOfWeek: day as any,
          openTime: new Date(`1970-01-01T${String(isOpen ? randomInt(7, 9) : 8).padStart(2, '0')}:00:00Z`),
          closeTime: new Date(`1970-01-01T${String(isOpen ? randomInt(17, 21) : 12).padStart(2, '0')}:00:00Z`),
          isOpen,
        },
      });
    }
    
    // Rooms
    const roomNames = ['Consultation', 'Examen', 'Traitement', 'Opération', 'Urgence', 'Radiologie', 'Laboratoire'];
    for (let j = 0; j < randomInt(2, 6); j++) {
      await prisma.clinicRoom.create({
        data: { clinicId: clinic.id, name: `${roomNames[j % roomNames.length]} ${j + 1}`, isActive: Math.random() < 0.9 },
      });
    }
    
    // Gallery - upload to object storage
    for (let j = 0; j < randomInt(3, 6); j++) {
      const galleryBuffer = galleryBuffers[(i * 4 + j) % galleryBuffers.length] || placeholderBuffer;
      
      const uploadResult = await uploadToStorage(
        galleryBuffer,
        `gallery_${clinic.nameFr}_${j + 1}.jpg`,
        'image/jpeg',
        'public/gallery',
        true
      );
      
      if (uploadResult) {
        await prisma.clinicGallery.create({
          data: {
            clinicId: clinic.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            filePath: uploadResult.filePath,
            imagePath: uploadResult.filePath,
            fileName: `gallery_${clinic.nameFr}_${j + 1}.jpg`,
            fileType: 'image/jpeg',
            fileSize: uploadResult.size,
            storageType: 'public',
            captionFr: `${clinic.nameFr} - Photo ${j + 1}`,
            captionAr: `${clinic.nameAr} - صورة ${j + 1}`,
            sortOrder: j,
          },
        });
      }
    }
    
    // Documents - upload to object storage
    const docTypes = ['license', 'registration', 'insurance', 'accreditation', 'tax'];
    for (let j = 0; j < randomInt(3, 5); j++) {
      const docType = randomElement(docTypes);
      
      const uploadResult = await uploadToStorage(
        pdfBuffer,
        `${docType}_${clinic.nameFr}.pdf`,
        'application/pdf',
        'private/clinic-documents',
        false
      );
      
      if (uploadResult) {
        await prisma.clinicDocument.create({
          data: {
            clinicId: clinic.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            fileName: `${docType}_${clinic.nameFr}.pdf`,
            fileType: 'application/pdf',
            fileSize: uploadResult.size,
            filePath: uploadResult.filePath,
            storageType: 'private',
            category: 'legal',
            docType,
            uploadedBy: 'system',
          },
        });
      }
    }
    
    if (i === count - 1) {
      console.log(`  📊 Created ${i + 1}/${count} clinics`);
    }
  }
  console.log(`  ✅ ${await prisma.clinic.count()} clinics seeded`);
  return createdClinics;
}

// ✅ UPDATED: Seed clinic services with object storage
async function seedClinicServices(clinics: any[]) {
  console.log('  🩺 Seeding clinic services...');
  
  console.log('  ⬇️  Downloading service images...');
  const serviceImageBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < 12; i++) {
    const buffer = await getCachedFile(GALLERY_PHOTOS[i % GALLERY_PHOTOS.length]);
    serviceImageBuffers.push(buffer);
  }
  
  const placeholderBuffer = await getPlaceholderBuffer();
  
  const servicesData = [
    { nameFr: 'Consultation Générale', nameAr: 'استشارة عامة' },
    { nameFr: 'Analyses de Laboratoire', nameAr: 'تحاليل المختبر' },
    { nameFr: 'Imagerie Médicale', nameAr: 'التصوير الطبي' },
    { nameFr: 'Urgences 24/7', nameAr: 'الطوارئ 24/7' },
    { nameFr: 'Kinésithérapie', nameAr: 'العلاج الطبيعي' },
    { nameFr: 'Chirurgie Générale', nameAr: 'الجراحة العامة' },
    { nameFr: 'Cardiologie Interventionnelle', nameAr: 'طب القلب التداخلي' },
    { nameFr: 'Maternité', nameAr: 'الأمومة' },
    { nameFr: 'Pédiatrie Spécialisée', nameAr: 'طب الأطفال المتخصص' },
    { nameFr: 'Ophtalmologie Laser', nameAr: 'طب العيون بالليزر' },
    { nameFr: 'Dentisterie Esthétique', nameAr: 'طب الأسنان التجميلي' },
    { nameFr: 'ORL et Audiologie', nameAr: 'الأنف والأذن والحنجرة' },
  ];
  
  let totalServices = 0;
  
  for (const clinic of clinics) {
    const numServices = randomInt(3, 6);
    const clinicServices = randomSubset(servicesData, numServices);
    
    for (let j = 0; j < clinicServices.length; j++) {
      const service = clinicServices[j];
      const createdService = await prisma.clinicService.create({
        data: {
          clinicId: clinic.id,
          nameFr: service.nameFr, nameAr: service.nameAr,
          descriptionFr: `${service.nameFr} - Service professionnel`,
          descriptionAr: `${service.nameAr} - خدمة احترافية`,
          sortOrder: j,
          isActive: Math.random() < 0.9,
        },
      });
      totalServices++;
      
      for (let k = 0; k < randomInt(1, 2); k++) {
        const imgBuffer = serviceImageBuffers[randomInt(0, serviceImageBuffers.length - 1)] || placeholderBuffer;
        
        const uploadResult = await uploadToStorage(
          imgBuffer,
          `${service.nameFr}_${k + 1}.jpg`,
          'image/jpeg',
          'public/service-images',
          true
        );
        
        if (uploadResult) {
          await prisma.clinicServiceImage.create({
            data: {
              serviceId: createdService.id,
              fileId: uploadResult.fileId,
              storageKey: uploadResult.storageKey,
              filePath: uploadResult.filePath,
              imagePath: uploadResult.filePath,
              fileName: `${service.nameFr}_${k + 1}.jpg`,
              fileType: 'image/jpeg',
              fileSize: uploadResult.size,
              storageType: 'public',
              captionFr: `${service.nameFr} - Image ${k + 1}`,
              captionAr: `${service.nameAr} - صورة ${k + 1}`,
              sortOrder: k,
            },
          });
        }
      }
    }
  }
  console.log(`  ✅ ${totalServices} clinic services seeded`);
}

async function seedClinicDoctors(doctors: any[], clinics: any[]) {
  console.log('  🔗 Linking doctors to clinics...');
  let totalLinks = 0;
  
  for (const clinic of clinics) {
    const numDoctors = randomInt(2, 4);
    for (const doctor of randomSubset(doctors, numDoctors)) {
      try {
        await prisma.clinicDoctor.create({
          data: {
            clinicId: clinic.id, doctorId: doctor.id,
            status: randomElement([InviteStatus.ACCEPTED, InviteStatus.ACCEPTED, InviteStatus.PENDING]) as any,
            invitedBy: randomElement(['clinic', 'doctor']),
            isActive: Math.random() < 0.9,
          },
        });
        totalLinks++;
      } catch (e) {}
    }
  }
  console.log(`  ✅ ${totalLinks} doctor-clinic links seeded`);
}

async function seedSlots(doctors: any[], clinics: any[]) {
  console.log('  📅 Seeding appointment slots...');
  const rooms = await prisma.clinicRoom.findMany();
  let totalSlots = 0;
  const today = new Date();
  
  for (const doctor of randomSubset(doctors, Math.min(4, doctors.length))) {
    const availabilities = await prisma.doctorAvailability.findMany({
      where: { doctorId: doctor.id, isActive: true },
    });
    if (availabilities.length === 0) continue;
    
    const config = await prisma.doctorConfig.findUnique({ where: { doctorId: doctor.id } });
    const slotDuration = config?.slotDuration || 30;
    const bufferTime = config?.bufferTime || 5;
    const maxPerSlot = config?.maxPerSlot || 1;
    
    for (let dayOffset = 0; dayOffset < 14; dayOffset++) {
      const slotDate = new Date(today);
      slotDate.setDate(slotDate.getDate() + dayOffset);
      
      const dayNames = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
      const dayName = dayNames[slotDate.getDay()];
      const availability = availabilities.find(a => a.dayOfWeek === dayName);
      if (!availability) continue;
      
      const breaks = await prisma.doctorBreak.findMany({
        where: { doctorId: doctor.id, startDate: { lte: slotDate }, endDate: { gte: slotDate } },
      });
      if (breaks.length > 0) continue;
      
      const startHour = new Date(availability.startTime).getUTCHours();
      const endHour = new Date(availability.endTime).getUTCHours();
      const totalMinutes = (endHour - startHour) * 60;
      const slotCount = Math.floor(totalMinutes / (slotDuration + bufferTime));
      const slotsToCreate = Math.floor(slotCount * (0.3 + Math.random() * 0.5));
      
      for (let s = 0; s < Math.min(slotsToCreate, 3); s++) {
        const startMinutes = startHour * 60 + s * (slotDuration + bufferTime);
        const endMinutes = startMinutes + slotDuration;
        
        const startTime = new Date('1970-01-01T00:00:00Z');
        startTime.setUTCHours(Math.floor(startMinutes / 60), startMinutes % 60, 0, 0);
        
        const endTime = new Date('1970-01-01T00:00:00Z');
        endTime.setUTCHours(Math.floor(endMinutes / 60), endMinutes % 60, 0, 0);
        
        const doctorClinicLinks = await prisma.clinicDoctor.findMany({
          where: { doctorId: doctor.id, isActive: true },
        });
        
        let clinicId: string | null = null;
        let roomId: string | null = null;
        
        if (doctorClinicLinks.length > 0) {
          const link = randomElement(doctorClinicLinks);
          clinicId = link.clinicId;
          const clinicRooms = rooms.filter(r => r.clinicId === clinicId);
          if (clinicRooms.length > 0) roomId = randomElement(clinicRooms).id;
        }
        
        const statuses = ['available', 'available', 'available', 'full', 'cancelled'];
        const slotKey = `${doctor.id}_${clinicId || 'none'}_${slotDate.toISOString().split('T')[0]}_${startMinutes}`;
        
        await prisma.slot.create({
          data: {
            slotKey,
            doctorId: doctor.id, 
            clinicId, 
            roomId,
            date: slotDate, 
            startTime, 
            endTime,
            maxPatients: maxPerSlot,
            status: randomElement(statuses),
          },
        });
        totalSlots++;
      }
    }
  }
  console.log(`  ✅ ${totalSlots} slots seeded`);
}

async function seedAppointments(users: any[], doctors: any[], clinics: any[]) {
  console.log('  📋 Seeding appointments...');
  
  const slots = await prisma.slot.findMany({
    where: { status: { in: ['available', 'full'] } },
    take: 100,
    orderBy: { date: 'asc' },
  });
  
  const appointmentStatuses = [AppointmentStatus.PENDING, AppointmentStatus.CONFIRMED, AppointmentStatus.IN_PROGRESS, AppointmentStatus.COMPLETED, AppointmentStatus.CANCELLED, AppointmentStatus.NO_SHOW];
  const appointmentTypes = [AppointmentType.IN_PERSON, AppointmentType.VIDEO, AppointmentType.HOME_VISIT];
  const paymentMethods = [PaymentMethod.CREDIT, PaymentMethod.ON_SITE];
  
  let totalAppointments = 0;
  
  for (const slot of randomSubset(slots, Math.min(50, slots.length))) {
    const user = randomElement(users);
    const doctor = doctors.find(d => d.id === slot.doctorId);
    if (!doctor) continue;
    
    const existingCount = await prisma.appointment.count({ where: { slotId: slot.id } });
    if (existingCount >= slot.maxPatients) continue;
    
    const statusWeights: Record<string, number> = {
      [AppointmentStatus.COMPLETED]: 30,
      [AppointmentStatus.CONFIRMED]: 25,
      [AppointmentStatus.CANCELLED]: 15,
      [AppointmentStatus.PENDING]: 15,
      [AppointmentStatus.IN_PROGRESS]: 10,
      [AppointmentStatus.NO_SHOW]: 5,
    };
    
    const weightedArray: string[] = [];
    for (const [status, weight] of Object.entries(statusWeights)) {
      for (let w = 0; w < weight; w++) weightedArray.push(status);
    }
    const status = randomElement(weightedArray) as string;
    
    try {
      const appointment = await prisma.appointment.create({
        data: {
          slotId: slot.id,
          doctorId: doctor.id,
          patientId: user.id,
          clinicId: slot.clinicId,
          type: randomElement(appointmentTypes) as any,
          paymentMethod: randomElement(paymentMethods) as any,
          status: status as any,
          notes: status === AppointmentStatus.CANCELLED ? 'Annulation demandée' : 
                 status === AppointmentStatus.NO_SHOW ? 'Non-présentation' : 'Consultation de routine',
          createdBy: user.id,
          createdByType: 'patient',
          confirmedAt: status !== AppointmentStatus.PENDING ? randomDate(new Date(2024, 0, 1), new Date()) : null,
          confirmedBy: status !== AppointmentStatus.PENDING ? randomElement(['doctor', 'clinic', 'system']) : null,
          cancelledAt: status === AppointmentStatus.CANCELLED || status === AppointmentStatus.NO_SHOW ? new Date() : null,
          cancelledBy: status === AppointmentStatus.CANCELLED ? 'patient' : status === AppointmentStatus.NO_SHOW ? 'system' : null,
          cancelReason: status === AppointmentStatus.CANCELLED ? 'Conflit d\'horaire' : null,
        },
      });
      totalAppointments++;
      
      const newCount = await prisma.appointment.count({ where: { slotId: slot.id } });
      if (newCount >= slot.maxPatients) {
        await prisma.slot.update({ where: { id: slot.id }, data: { status: 'full' } });
      }
      
      if (appointment.paymentMethod === PaymentMethod.CREDIT) {
        const wallet = await prisma.userWallet.findUnique({ where: { userId: user.id } });
        if (wallet) {
          const cost = randomInt(1, 3);
          if (wallet.credits >= cost) {
            await prisma.creditTransaction.create({
              data: {
                walletId: wallet.id, amount: -cost, type: 'use',
                description: `Paiement rendez-vous #${appointment.id.slice(0, 8)}`,
                referenceId: appointment.id,
              },
            });
            await prisma.userWallet.update({ where: { id: wallet.id }, data: { credits: { decrement: cost } } });
          }
        }
      }
    } catch (e) {
      continue;
    }
  }
  console.log(`  ✅ ${totalAppointments} appointments seeded`);
}

async function seedReviews(users: any[], doctors: any[], clinics: any[]) {
  console.log('  ⭐ Seeding reviews...');
  
  let doctorReviewCount = 0;
  for (const doctor of randomSubset(doctors, Math.min(4, doctors.length))) {
    for (const user of randomSubset(users, randomInt(3, 10))) {
      try {
        await prisma.doctorReview.create({
          data: {
            doctorId: doctor.id, patientId: user.id,
            rating: randomInt(3, 5),
            review: `Excellent médecin, très professionnel. Je recommande le Dr ${doctor.lastNameFr}.`,
          },
        });
        doctorReviewCount++;
      } catch (e) {}
    }
    
    const reviews = await prisma.doctorReview.findMany({ where: { doctorId: doctor.id, rating: { not: null } } });
    if (reviews.length > 0) {
      const avgRating = reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length;
      await prisma.doctor.update({ where: { id: doctor.id }, data: { avgRating, totalReviews: reviews.length } });
    }
  }
  
  let clinicReviewCount = 0;
  for (const clinic of randomSubset(clinics, Math.min(4, clinics.length))) {
    for (const user of randomSubset(users, randomInt(5, 15))) {
      try {
        await prisma.clinicReview.create({
          data: {
            clinicId: clinic.id, patientId: user.id,
            rating: randomInt(3, 5),
            review: `Très bonne clinique, personnel accueillant et professionnel.`,
          },
        });
        clinicReviewCount++;
      } catch (e) {}
    }
    
    const reviews = await prisma.clinicReview.findMany({ where: { clinicId: clinic.id, rating: { not: null } } });
    if (reviews.length > 0) {
      const avgRating = reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length;
      await prisma.clinic.update({ where: { id: clinic.id }, data: { avgRating, totalReviews: reviews.length } });
    }
  }
  
  console.log(`  ✅ ${doctorReviewCount} doctor reviews and ${clinicReviewCount} clinic reviews seeded`);
}

async function seedChatRooms(users: any[], doctors: any[], clinics: any[]) {
  console.log('  💬 Seeding chat rooms...');
  const messages = [
    'Bonjour, comment puis-je vous aider?',
    'J\'ai besoin d\'un conseil médical',
    'Quels sont vos symptômes?',
    'Depuis combien de temps ressentez-vous cela?',
    'Je vous recommande de prendre rendez-vous',
    'Merci docteur, je vais suivre vos conseils',
    'N\'hésitez pas à me recontacter si besoin',
  ];
  
  let totalRooms = 0;
  
  for (let i = 0; i < 20; i++) {
    const user = randomElement(users);
    const doctor = randomElement(doctors);
    
    const room = await prisma.chatRoom.create({
      data: {
        userId: user.id, userRole: 'USER',
        userName: `${user.firstName} ${user.lastName}`,
        userEmail: user.email,
        status: randomElement(['open', 'open', 'open', 'closed']),
        lastMessage: randomElement(messages),
      },
    });
    totalRooms++;
    
    for (let j = 0; j < randomInt(2, 6); j++) {
      await prisma.chatMessage.create({
        data: {
          roomId: room.id,
          senderId: j % 2 === 0 ? user.id : doctor.id,
          senderRole: j % 2 === 0 ? 'USER' : 'DOCTOR',
          senderName: j % 2 === 0 ? `${user.firstName} ${user.lastName}` : `Dr. ${doctor.lastNameFr}`,
          message: randomElement(messages),
          createdAt: randomDate(new Date(2024, 0, 1), new Date()),
        },
      });
    }
  }
  
  for (let i = 0; i < 10; i++) {
    const user = randomElement(users);
    const clinic = randomElement(clinics);
    
    const room = await prisma.chatRoom.create({
      data: {
        userId: user.id, userRole: 'USER',
        userName: `${user.firstName} ${user.lastName}`,
        userEmail: user.email,
        status: randomElement(['open', 'open', 'closed']),
        lastMessage: 'Bonjour, quels sont vos horaires?',
      },
    });
    totalRooms++;
    
    for (let j = 0; j < randomInt(2, 5); j++) {
      await prisma.chatMessage.create({
        data: {
          roomId: room.id,
          senderId: j % 2 === 0 ? user.id : clinic.id,
          senderRole: j % 2 === 0 ? 'USER' : 'CLINIC',
          senderName: j % 2 === 0 ? `${user.firstName} ${user.lastName}` : clinic.nameFr,
          message: randomElement(messages),
          createdAt: randomDate(new Date(2024, 0, 1), new Date()),
        },
      });
    }
  }
  
  console.log(`  ✅ ${totalRooms} chat rooms seeded`);
}

async function seedUserDevices(users: any[]) {
  console.log('  📱 Seeding user devices...');
  let totalDevices = 0;
  const platforms = ['android', 'ios', 'web'];
  
  for (const user of randomSubset(users, 100)) {
    for (let j = 0; j < randomInt(1, 2); j++) {
      await prisma.userDevice.create({
        data: {
          userId: user.id,
          deviceToken: crypto.randomUUID(),
          platform: randomElement(platforms),
          isActive: Math.random() < 0.9,
        },
      });
      totalDevices++;
    }
  }
  console.log(`  ✅ ${totalDevices} user devices seeded`);
}

async function seedNotifications(users: any[]) {
  console.log('  🔔 Seeding notifications...');
  const titles = [
    'Rappel de rendez-vous', 'Nouveau message', 'Paiement confirmé',
    'Mise à jour système', 'Transfert de crédits', 'Confirmation de réservation',
    'Résultat d\'analyse disponible', 'Promotion spéciale',
  ];
  const bodies = [
    'Vous avez un rendez-vous demain à 10h.', 'Un nouveau message vous attend.',
    'Votre paiement a été traité avec succès.', 'Une nouvelle version est disponible.',
  ];
  const types = ['appointment', 'chat', 'payment', 'system', 'transfer'];
  
  let totalNotifications = 0;
  
  for (const user of randomSubset(users, 100)) {
    for (let j = 0; j < randomInt(2, 8); j++) {
      await prisma.notification.create({
        data: {
          userId: user.id,
          title: randomElement(titles),
          body: randomElement(bodies),
          type: randomElement(types),
          isRead: Math.random() < 0.6,
          createdAt: randomDate(new Date(2024, 0, 1), new Date()),
        },
      });
      totalNotifications++;
    }
  }
  console.log(`  ✅ ${totalNotifications} notifications seeded`);
}

async function seedPayments(users: any[]) {
  console.log('  💳 Seeding payments...');
  let totalPayments = 0;
  const paymentStatuses = [PaymentStatus.PAID, PaymentStatus.PAID, PaymentStatus.PAID, PaymentStatus.PENDING, PaymentStatus.FAILED, PaymentStatus.EXPIRED];
  
  for (const user of randomSubset(users, 100)) {
    for (let j = 0; j < randomInt(1, 3); j++) {
      const credits = randomElement([5, 10, 20, 50, 100]);
      const amount = credits * 100;
      const status = randomElement(paymentStatuses);
      
      const payment = await prisma.payment.create({
        data: {
          userId: user.id, credits, amount,
          status: status as any,
          chargilyId: status === PaymentStatus.PAID ? `ch_${crypto.randomUUID()}` : null,
          chargilyUrl: `https://checkout.chargily.dz/${crypto.randomUUID()}`,
          completedAt: status === PaymentStatus.PAID ? randomDate(new Date(2024, 0, 1), new Date()) : null,
        },
      });
      totalPayments++;
      
      if (status === PaymentStatus.PAID) {
        const wallet = await prisma.userWallet.findUnique({ where: { userId: user.id } });
        if (wallet) {
          await prisma.creditTransaction.create({
            data: {
              walletId: wallet.id, amount: credits, type: 'purchase',
              description: `Achat de ${credits} crédits`, referenceId: payment.id,
            },
          });
          await prisma.userWallet.update({ where: { id: wallet.id }, data: { credits: { increment: credits } } });
        }
      }
    }
  }
  console.log(`  ✅ ${totalPayments} payments seeded`);
}

async function seedCategories() {
  console.log('  📂 Seeding e-commerce categories...');
  for (const cat of productCategoriesData) {
    await prisma.category.create({
      data: {
        nameFr: cat.nameFr, nameAr: cat.nameAr, slug: cat.slug,
        descriptionFr: `${cat.nameFr} - Produits de qualité`, descriptionAr: `${cat.nameAr} - منتجات عالية الجودة`,
      },
    });
  }
  console.log(`  ✅ ${await prisma.category.count()} categories seeded`);
  return await prisma.category.findMany();
}

// ✅ UPDATED: Seed products with object storage
async function seedProducts(sellers: any[], categories: any[]) {
  console.log('  🛍️ Seeding products...');
  
  console.log('  ⬇️  Downloading product images...');
  const productImageBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < PRODUCT_PHOTOS.length; i++) {
    const buffer = await getCachedFile(PRODUCT_PHOTOS[i]);
    productImageBuffers.push(buffer);
  }
  
  const placeholderBuffer = await getPlaceholderBuffer();
  
  const productsData = [
    { titleFr: 'Tensiomètre Électronique', titleAr: 'جهاز قياس الضغط', price: 8500, categorySlug: 'medical-equipment' },
    { titleFr: 'Thermomètre Infrarouge', titleAr: 'مقياس حرارة', price: 4500, categorySlug: 'medical-equipment' },
    { titleFr: 'Oxymètre de Pouls', titleAr: 'مقياس التأكسج', price: 3200, categorySlug: 'medical-equipment' },
    { titleFr: 'Stéthoscope Professionnel', titleAr: 'سماعة طبية', price: 12000, categorySlug: 'medical-equipment' },
    { titleFr: 'Glucomètre Connecté', titleAr: 'جهاز قياس السكر', price: 6500, categorySlug: 'medical-equipment' },
    { titleFr: 'Paracétamol 500mg', titleAr: 'باراسيتامول', price: 350, categorySlug: 'medications' },
    { titleFr: 'Ibuprofène 400mg', titleAr: 'إيبوبروفين', price: 450, categorySlug: 'medications' },
    { titleFr: 'Amoxicilline 1g', titleAr: 'أموكسيسيلين', price: 850, categorySlug: 'medications' },
    { titleFr: 'Oméprazole 20mg', titleAr: 'أوميبرازول', price: 580, categorySlug: 'medications' },
    { titleFr: 'Métformine 850mg', titleAr: 'ميتفورمين', price: 450, categorySlug: 'medications' },
    { titleFr: 'Vitamine C 1000mg', titleAr: 'فيتامين سي', price: 1800, categorySlug: 'supplements' },
    { titleFr: 'Vitamine D3 2000UI', titleAr: 'فيتامين د3', price: 1500, categorySlug: 'supplements' },
    { titleFr: 'Magnésium Marin', titleAr: 'مغنيسيوم بحري', price: 2200, categorySlug: 'supplements' },
    { titleFr: 'Oméga 3', titleAr: 'أوميغا 3', price: 2800, categorySlug: 'supplements' },
    { titleFr: 'Zinc + Sélénium', titleAr: 'زنك + سيلينيوم', price: 1900, categorySlug: 'supplements' },
    { titleFr: 'Gel Hydroalcoolique', titleAr: 'جل كحولي', price: 350, categorySlug: 'hygiene' },
    { titleFr: 'Masques FFP2', titleAr: 'أقنعة FFP2', price: 2500, categorySlug: 'hygiene' },
    { titleFr: 'Savon Antiseptique', titleAr: 'صابون مطهر', price: 450, categorySlug: 'hygiene' },
    { titleFr: 'Gants Médicaux', titleAr: 'قفازات طبية', price: 1200, categorySlug: 'hygiene' },
    { titleFr: 'Compresses Stériles', titleAr: 'كمادات معقمة', price: 750, categorySlug: 'hygiene' },
  ];
  
  const createdProducts = [];
  const productStatuses = [ProductStatus.ACTIVE, ProductStatus.ACTIVE, ProductStatus.ACTIVE, ProductStatus.INACTIVE, ProductStatus.OUT_OF_STOCK];
  
  for (let pIdx = 0; pIdx < productsData.length; pIdx++) {
    const p = productsData[pIdx];
    const seller = randomElement(sellers);
    const category = categories.find(c => c.slug === p.categorySlug);
    if (!category) continue;
    
    const status = randomElement(productStatuses);
    const stock = status === ProductStatus.OUT_OF_STOCK ? 0 : randomInt(10, 200);
    
    const product = await prisma.product.create({
      data: {
        sellerId: seller.id, categoryId: category.id,
        titleFr: p.titleFr, titleAr: p.titleAr,
        descriptionFr: `${p.titleFr} - Haute qualité`, descriptionAr: `${p.titleAr} - جودة عالية`,
        price: p.price, comparePrice: Math.round(p.price * 1.25),
        stock, sku: `SKU-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
        status: status as any, isApproved: Math.random() < 0.9,
        viewCount: randomInt(0, 5000), saleCount: randomInt(0, 200),
      },
    });
    createdProducts.push(product);
    
    for (let j = 0; j < randomInt(2, 4); j++) {
      const imgBuffer = productImageBuffers[(pIdx * 3 + j) % productImageBuffers.length] || placeholderBuffer;
      
      const uploadResult = await uploadToStorage(
        imgBuffer,
        `product_${p.titleFr.replace(/\s+/g, '_')}_${j + 1}.jpg`,
        'image/jpeg',
        'public/products',
        true
      );
      
      if (uploadResult) {
        await prisma.productImage.create({
          data: {
            productId: product.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            filePath: uploadResult.filePath,
            fileName: `product_${p.titleFr.replace(/\s+/g, '_')}_${j + 1}.jpg`,
            fileType: 'image/jpeg',
            fileSize: uploadResult.size,
            storageType: 'public',
            isPrimary: j === 0,
            sortOrder: j,
          },
        });
      }
    }
  }
  console.log(`  ✅ ${createdProducts.length} products seeded`);
  return createdProducts;
}

async function seedShippingCompanies() {
  console.log('  🚚 Seeding shipping companies...');
  for (const company of shippingCompaniesData) {
    await prisma.shippingCompany.create({
      data: { name: company.name, trackingUrl: company.trackingUrl, isActive: true },
    });
  }
  console.log(`  ✅ ${await prisma.shippingCompany.count()} shipping companies seeded`);
  return await prisma.shippingCompany.findMany();
}

async function seedOrders(buyers: any[], sellers: any[], products: any[], shippingCompanies: any[]) {
  console.log('  📦 Seeding orders...');
  
  let totalOrders = 0;
  
  for (let i = 0; i < 50; i++) {
    const buyer = randomElement(buyers);
    let seller = randomElement(sellers);
    
    let sellerProducts = products.filter(p => p.sellerId === seller.id);
    
    if (sellerProducts.length === 0) {
      const validSellers = sellers.filter((s: any) => products.some(p => p.sellerId === s.id));
      if (validSellers.length === 0) continue;
      seller = randomElement(validSellers);
      sellerProducts = products.filter(p => p.sellerId === seller.id);
      if (sellerProducts.length === 0) continue;
    }
    
    const numItems = randomInt(1, 3);
    const orderProducts = randomSubset(sellerProducts, Math.min(numItems, sellerProducts.length));
    
    const subtotal = orderProducts.reduce((sum, p) => sum + p.price, 0);
    const shippingCost = subtotal > 5000 ? 0 : randomElement([300, 500, 800, 1000]);
    const totalAmount = subtotal + shippingCost;
    
    const orderStatus = randomElement([
      OrderStatus.PENDING, OrderStatus.CONFIRMED, OrderStatus.PROCESSING,
      OrderStatus.SHIPPED, OrderStatus.SHIPPED, OrderStatus.DELIVERED,
      OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.RETURNED,
    ]);
    
    const shippingCompany = randomElement(shippingCompanies);
    const hasTracking = orderStatus === OrderStatus.SHIPPED || orderStatus === OrderStatus.DELIVERED;
    
    const order = await prisma.order.create({
      data: {
        buyerId: buyer.id, sellerId: seller.id,
        status: orderStatus as any,
        paymentMethod: randomElement([OrderPaymentMethod.CHARGILY, OrderPaymentMethod.CASH_ON_DELIVERY]) as any,
        paymentStatus: (orderStatus === OrderStatus.DELIVERED ? PaymentStatus.PAID : 
                       orderStatus === OrderStatus.CANCELLED ? PaymentStatus.EXPIRED :
                       randomElement([PaymentStatus.PENDING, PaymentStatus.PAID, PaymentStatus.PENDING])) as any,
        shippingCompanyId: shippingCompany.id,
        trackingNumber: hasTracking ? `TRK-${crypto.randomUUID().slice(0, 10).toUpperCase()}` : null,
        subtotal, shippingCost, totalAmount,
        notes: randomElement(['Merci de livrer rapidement', 'Appeler avant livraison', null, null, null]),
        cancelledAt: orderStatus === OrderStatus.CANCELLED ? randomDate(new Date(2024, 6, 1), new Date()) : null,
        cancelledBy: orderStatus === OrderStatus.CANCELLED ? randomElement(['buyer', 'seller']) : null,
        cancelReason: orderStatus === OrderStatus.CANCELLED ? randomElement(['Produit non disponible', 'Changement d\'avis', 'Erreur de commande']) : null,
        deliveredAt: orderStatus === OrderStatus.DELIVERED ? randomDate(new Date(2024, 6, 1), new Date()) : null,
      },
    });
    totalOrders++;
    
    for (const product of orderProducts) {
      const quantity = randomInt(1, 3);
      await prisma.orderItem.create({
        data: {
          orderId: order.id, productId: product.id, quantity,
          unitPrice: product.price, totalPrice: product.price * quantity,
        },
      });
    }
    
    const statusFlow = getStatusFlow(orderStatus);
    for (const status of statusFlow) {
      await prisma.orderStatusHistory.create({
        data: {
          orderId: order.id, status: status as any,
          notes: `Commande ${status.toLowerCase()}`,
          changedBy: status === OrderStatus.PENDING ? buyer.id : seller.id,
          createdAt: randomDate(new Date(2024, 6, 1), new Date()),
        },
      });
    }
  }
  console.log(`  ✅ ${totalOrders} orders seeded`);
}

function getStatusFlow(finalStatus: string): string[] {
  const flow: string[] = [OrderStatus.PENDING];
  
  if (finalStatus === OrderStatus.CANCELLED) {
    flow.push(OrderStatus.CANCELLED);
    return flow;
  }
  
  if (finalStatus === OrderStatus.CONFIRMED || 
      finalStatus === OrderStatus.PROCESSING || 
      finalStatus === OrderStatus.SHIPPED || 
      finalStatus === OrderStatus.DELIVERED) {
    flow.push(OrderStatus.CONFIRMED);
  }
  
  if (finalStatus === OrderStatus.PROCESSING || 
      finalStatus === OrderStatus.SHIPPED || 
      finalStatus === OrderStatus.DELIVERED) {
    flow.push(OrderStatus.PROCESSING);
  }
  
  if (finalStatus === OrderStatus.SHIPPED || 
      finalStatus === OrderStatus.DELIVERED) {
    flow.push(OrderStatus.SHIPPED);
  }
  
  if (finalStatus === OrderStatus.DELIVERED) {
    flow.push(OrderStatus.DELIVERED);
  }
  
  if (finalStatus === OrderStatus.RETURNED) {
    flow.push(OrderStatus.CONFIRMED, OrderStatus.SHIPPED, OrderStatus.RETURNED);
  }
  
  return flow;
}

// ✅ UPDATED: Seed seller documents with object storage
async function seedSellerDocuments(sellers: any[]) {
  console.log('  📄 Seeding seller documents...');
  
  const pdfBuffer = await getDocumentBufferCached();
  
  let totalDocs = 0;
  const docTypes = ['license', 'id_card', 'tax_card', 'registration'];
  
  for (const seller of randomSubset(sellers, 50)) {
    for (let j = 0; j < randomInt(1, 2); j++) {
      const docType = randomElement(docTypes);
      
      const uploadResult = await uploadToStorage(
        pdfBuffer,
        `${docType}_seller.pdf`,
        'application/pdf',
        'private/ecommerce-documents',
        false
      );
      
      if (uploadResult) {
        await prisma.sellerDocument.create({
          data: {
            userId: seller.id,
            fileId: uploadResult.fileId,
            storageKey: uploadResult.storageKey,
            fileName: `${docType}_seller.pdf`,
            fileType: 'application/pdf',
            fileSize: uploadResult.size,
            filePath: uploadResult.filePath,
            storageType: 'private',
            docType,
            isVerified: Math.random() < 0.8,
          },
        });
        totalDocs++;
      }
    }
  }
  console.log(`  ✅ ${totalDocs} seller documents seeded`);
}

async function seedHealthCheck() {
  console.log('  ❤️ Seeding health checks...');
  await prisma.healthCheck.create({
    data: { status: 'healthy', checkedAt: new Date() },
  });
  console.log('  ✅ Health check seeded');
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log('🚀 Starting REDUCED seed - 150 users, 4 doctors, 4 clinics!\n');
  console.log('📸 USING OBJECT STORAGE (SeaweedFS/S3) FOR FILES\n');
  
  ensureDirectories();
  console.log('');
  
  await cleanupOldFiles();
  console.log('');
  
  await clearDatabase();
  console.log('');
  
  console.log('='.repeat(60));
  console.log('📊 PHASE 1: Base Configuration');
  console.log('='.repeat(60));
  await seedSuperAdmins();
  await seedAdmins();
  await seedWilayas();
  await seedSpecialties();
  await seedCreditPrices();
  await seedHealthCheck();
  console.log('');
  
  console.log('='.repeat(60));
  console.log('👥 PHASE 2: Users & Profiles');
  console.log('='.repeat(60));
  const users = await seedUsers(150);
  await seedContactUsers(users);
  await seedUserDocuments(users);
  await seedUserDevices(users);
  const sellers = users.filter((u: any) => u.canPost);
  console.log(`  ℹ️  ${sellers.length} users can sell products`);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('👨‍⚕️ PHASE 3: Doctors');
  console.log('='.repeat(60));
  const doctors = await seedDoctors(4);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('🏥 PHASE 4: Clinics & Services');
  console.log('='.repeat(60));
  const clinics = await seedClinics(4);
  await seedClinicServices(clinics);
  await seedClinicDoctors(doctors, clinics);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('📅 PHASE 5: Appointments & Slots');
  console.log('='.repeat(60));
  await seedSlots(doctors, clinics);
  await seedAppointments(users, doctors, clinics);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('⭐ PHASE 6: Reviews & Communication');
  console.log('='.repeat(60));
  await seedReviews(users, doctors, clinics);
  await seedChatRooms(users, doctors, clinics);
  await seedNotifications(users);
  await seedPayments(users);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('🛒 PHASE 7: E-Commerce');
  console.log('='.repeat(60));
  const categories = await seedCategories();
  const products = await seedProducts(sellers, categories);
  const shippingCompanies = await seedShippingCompanies();
  await seedOrders(users, sellers, products, shippingCompanies);
  await seedSellerDocuments(sellers);
  console.log('');
  
  console.log('='.repeat(60));
  console.log('✅ REDUCED SEED COMPLETED SUCCESSFULLY!');
  console.log('='.repeat(60));
  
  console.log('\n📊 FINAL DATA SUMMARY:');
  console.log(`  🔑 Super Admins: ${await prisma.superAdmin.count()}`);
  console.log(`  👮 Admins: ${await prisma.admin.count()}`);
  console.log(`  📍 Wilayas: ${await prisma.wilaya.count()}`);
  console.log(`  🏥 Specialties: ${await prisma.specialty.count()}`);
  console.log(`  👤 Users: ${await prisma.user.count()}`);
  console.log(`  👨‍👩‍👧‍👦 Contact Users: ${await prisma.contactUser.count()}`);
  console.log(`  💰 Wallets: ${await prisma.userWallet.count()}`);
  console.log(`  📄 User Documents: ${await prisma.userDocument.count()}`);
  console.log(`  👨‍⚕️ Doctors: ${await prisma.doctor.count()}`);
  console.log(`  📄 Doctor Documents: ${await prisma.doctorDocument.count()}`);
  console.log(`  🖼️ Doctor Logos: ${await prisma.doctorLogo.count()}`);
  console.log(`  🏥 Clinics: ${await prisma.clinic.count()}`);
  console.log(`  🏢 Clinic Rooms: ${await prisma.clinicRoom.count()}`);
  console.log(`  🕐 Clinic Working Hours: ${await prisma.clinicWorkingHours.count()}`);
  console.log(`  📸 Clinic Gallery: ${await prisma.clinicGallery.count()}`);
  console.log(`  📄 Clinic Documents: ${await prisma.clinicDocument.count()}`);
  console.log(`  🩺 Clinic Services: ${await prisma.clinicService.count()}`);
  console.log(`  🖼️ Service Images: ${await prisma.clinicServiceImage.count()}`);
  console.log(`  🔗 Doctor-Clinic Links: ${await prisma.clinicDoctor.count()}`);
  console.log(`  📅 Slots: ${await prisma.slot.count()}`);
  console.log(`  📋 Appointments: ${await prisma.appointment.count()}`);
  console.log(`  ⭐ Doctor Reviews: ${await prisma.doctorReview.count()}`);
  console.log(`  ⭐ Clinic Reviews: ${await prisma.clinicReview.count()}`);
  console.log(`  💬 Chat Rooms: ${await prisma.chatRoom.count()}`);
  console.log(`  💬 Chat Messages: ${await prisma.chatMessage.count()}`);
  console.log(`  📱 User Devices: ${await prisma.userDevice.count()}`);
  console.log(`  🔔 Notifications: ${await prisma.notification.count()}`);
  console.log(`  💳 Payments: ${await prisma.payment.count()}`);
  console.log(`  💸 Credit Transactions: ${await prisma.creditTransaction.count()}`);
  console.log(`  📂 Categories: ${await prisma.category.count()}`);
  console.log(`  🛍️ Products: ${await prisma.product.count()}`);
  console.log(`  🖼️ Product Images: ${await prisma.productImage.count()}`);
  console.log(`  📦 Orders: ${await prisma.order.count()}`);
  console.log(`  📦 Order Items: ${await prisma.orderItem.count()}`);
  console.log(`  📜 Order Status History: ${await prisma.orderStatusHistory.count()}`);
  console.log(`  🚚 Shipping Companies: ${await prisma.shippingCompany.count()}`);
  console.log(`  📄 Seller Documents: ${await prisma.sellerDocument.count()}`);
  
  console.log('\n📋 DEMO CREDENTIALS:');
  console.log('  🔑 Super Admin: superadmin@iyadati.dz / superadmin123');
  console.log('  👮 Admin:       admin1@iyadati.dz / admin123456');
  console.log('  👤 User:        user1@gmail.com / user123456');
  console.log('  👨‍⚕️ Doctor:      dr.[random]@iyadati.dz / doctor123456');
  console.log('  🏥 Clinic:      contact1@cliniqueelwouroud.dz / clinic123456');
  
  console.log('\n📈 COVERAGE CHECKLIST:');
  console.log('  ✅ All Roles (SUPER_ADMIN, ADMIN, SUPPORT)');
  console.log('  ✅ All DayOfWeek values');
  console.log('  ✅ All PracticeType values');
  console.log('  ✅ All InviteStatus values');
  console.log('  ✅ All AppointmentStatus values');
  console.log('  ✅ All AppointmentType values');
  console.log('  ✅ All PaymentMethod values');
  console.log('  ✅ All ReviewVisibility values');
  console.log('  ✅ All PaymentStatus values');
  console.log('  ✅ All FacilityType values');
  console.log('  ✅ All OrderStatus values');
  console.log('  ✅ All ProductStatus values');
  console.log('  ✅ All OrderPaymentMethod values');
}

main()
  .catch((e) => {
    console.error('❌ SEED ERROR:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    console.log('\n👋 Database connection closed. Goodbye!');
  });

