import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function seedSuperAdmin() {
  const existingAdmin = await prisma.superAdmin.findUnique({
    where: { email: 'superadmin@gmail.com' },
  });

  if (existingAdmin) {
    console.log('✅ Super admin already exists, skipping...');
    return;
  }

  const hashedPassword = await bcrypt.hash('kolnhbdasgjejoefskn', 12);

  await prisma.superAdmin.create({
    data: {
      email: 'superadmin@gmail.com',
      name: 'superadmin',
      password: hashedPassword,
      role: Role.SUPER_ADMIN,
    },
  });

  console.log('✅ Super admin created successfully!');
  console.log('📧 Email: superadmin@gmail.com');
  console.log('🔑 Password: kolnhbdasgjejoefskn');
}

async function main() {
  console.log('🌱 Seeding Super Admin...\n');
  await seedSuperAdmin();
  console.log('\n✅ Seed completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

