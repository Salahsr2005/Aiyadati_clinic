import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ============================================================
// WILAYA DATA - Using the same structure as your existing seed
// ============================================================
const wilayas = [
  { code: 1, nameFr: 'Adrar', nameAr: 'أدرار' },
  { code: 2, nameFr: 'Chlef', nameAr: 'الشلف' },
  { code: 3, nameFr: 'Laghouat', nameAr: 'الأغواط' },
  { code: 4, nameFr: 'Oum El Bouaghi', nameAr: 'أم البواقي' },
  { code: 5, nameFr: 'Batna', nameAr: 'باتنة' },
  { code: 6, nameFr: 'Béjaïa', nameAr: 'بجاية' },
  { code: 7, nameFr: 'Biskra', nameAr: 'بسكرة' },
  { code: 8, nameFr: 'Béchar', nameAr: 'بشار' },
  { code: 9, nameFr: 'Blida', nameAr: 'البليدة' },
  { code: 10, nameFr: 'Bouïra', nameAr: 'البويرة' },
  { code: 11, nameFr: 'Tamanrasset', nameAr: 'تمنراست' },
  { code: 12, nameFr: 'Tébessa', nameAr: 'تبسة' },
  { code: 13, nameFr: 'Tlemcen', nameAr: 'تلمسان' },
  { code: 14, nameFr: 'Tiaret', nameAr: 'تيارت' },
  { code: 15, nameFr: 'Tizi Ouzou', nameAr: 'تيزي وزو' },
  { code: 16, nameFr: 'Algiers', nameAr: 'الجزائر' },
  { code: 17, nameFr: 'Djelfa', nameAr: 'الجلفة' },
  { code: 18, nameFr: 'Jijel', nameAr: 'جيجل' },
  { code: 19, nameFr: 'Sétif', nameAr: 'سطيف' },
  { code: 20, nameFr: 'Saïda', nameAr: 'سعيدة' },
  { code: 21, nameFr: 'Skikda', nameAr: 'سكيكدة' },
  { code: 22, nameFr: 'Sidi Bel Abbès', nameAr: 'سيدي بلعباس' },
  { code: 23, nameFr: 'Annaba', nameAr: 'عنابة' },
  { code: 24, nameFr: 'Guelma', nameAr: 'قالمة' },
  { code: 25, nameFr: 'Constantine', nameAr: 'قسنطينة' },
  { code: 26, nameFr: 'Médéa', nameAr: 'المدية' },
  { code: 27, nameFr: 'Mostaganem', nameAr: 'مستغانم' },
  { code: 28, nameFr: "M'Sila", nameAr: 'المسيلة' },
  { code: 29, nameFr: 'Mascara', nameAr: 'معسكر' },
  { code: 30, nameFr: 'Ouargla', nameAr: 'ورقلة' },
  { code: 31, nameFr: 'Oran', nameAr: 'وهران' },
  { code: 32, nameFr: 'El Bayadh', nameAr: 'البيض' },
  { code: 33, nameFr: 'Illizi', nameAr: 'إليزي' },
  { code: 34, nameFr: 'Bordj Bou Arréridj', nameAr: 'برج بوعريريج' },
  { code: 35, nameFr: 'Boumerdès', nameAr: 'بومرداس' },
  { code: 36, nameFr: 'El Tarf', nameAr: 'الطارف' },
  { code: 37, nameFr: 'Tindouf', nameAr: 'تندوف' },
  { code: 38, nameFr: 'Tissemsilt', nameAr: 'تيسمسيلت' },
  { code: 39, nameFr: 'El Oued', nameAr: 'الوادي' },
  { code: 40, nameFr: 'Khenchela', nameAr: 'خنشلة' },
  { code: 41, nameFr: 'Souk Ahras', nameAr: 'سوق أهراس' },
  { code: 42, nameFr: 'Tipaza', nameAr: 'تيبازة' },
  { code: 43, nameFr: 'Mila', nameAr: 'ميلة' },
  { code: 44, nameFr: "Aïn Defla", nameAr: 'عين الدفلى' },
  { code: 45, nameFr: 'Naâma', nameAr: 'النعامة' },
  { code: 46, nameFr: "Aïn Témouchent", nameAr: 'عين تموشنت' },
  { code: 47, nameFr: 'Ghardaïa', nameAr: 'غرداية' },
  { code: 48, nameFr: 'Relizane', nameAr: 'غليزان' },
  { code: 49, nameFr: 'Timimoun', nameAr: 'تيميمون' },
  { code: 50, nameFr: 'Bordj Badji Mokhtar', nameAr: 'برج باجي مختار' },
  { code: 51, nameFr: 'Ouled Djellal', nameAr: 'أولاد جلال' },
  { code: 52, nameFr: 'Béni Abbès', nameAr: 'بني عباس' },
  { code: 53, nameFr: 'Ain Salah', nameAr: 'عين صالح' },
  { code: 54, nameFr: 'Ain Guezzam', nameAr: 'عين قزام' },
  { code: 55, nameFr: 'Touggourt', nameAr: 'تقرت' },
  { code: 56, nameFr: 'Djanet', nameAr: 'جانت' },
  { code: 57, nameFr: "El M'Ghair", nameAr: 'المغير' },
  { code: 58, nameFr: 'El Menia', nameAr: 'المنيعة' },
  { code: 59, nameFr: 'Aflou', nameAr: 'أفلو' },
];

interface MunicipalityRow {
  wilaya_code: string;
  wilaya_name: string;
  municipality_id: string;
  municipality_name: string;
  municipality_name_ar: string;
}

function parseCSV(filePath: string): MunicipalityRow[] {
  const fileContent = fs.readFileSync(filePath, 'utf-8');
  const lines = fileContent.split('\n');
  
  // Get headers
  const headers = lines[0].split(',').map(h => h.trim());
  
  const results: MunicipalityRow[] = [];
  
  // Parse each line (skip header)
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Handle quoted fields
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim());
    
    if (values.length >= 5) {
      results.push({
        wilaya_code: values[0].replace(/^"|"$/g, ''),
        wilaya_name: values[1].replace(/^"|"$/g, ''),
        municipality_id: values[2].replace(/^"|"$/g, ''),
        municipality_name: values[3].replace(/^"|"$/g, ''),
        municipality_name_ar: values[4].replace(/^"|"$/g, ''),
      });
    }
  }
  
  return results;
}

async function seedWilayas() {
  console.log('📍 Seeding wilayas...');
  
  for (const w of wilayas) {
    await prisma.wilaya.upsert({
      where: { code: w.code },
      update: { 
        nameFr: w.nameFr,
        nameAr: w.nameAr,
      },
      create: { 
        nameFr: w.nameFr,
        nameAr: w.nameAr,
        code: w.code,
      },
    });
  }

  const count = await prisma.wilaya.count();
  console.log(`✅ Wilayas seeded successfully! (${count} total)\n`);
}

async function seedBaladyatFromCSV() {
  console.log('🏙️  Seeding baladyat from CSV...');
  
  const csvPath = path.join(__dirname, 'data', 'municipalities.csv');
  console.log(`📂 Reading CSV from: ${csvPath}`);
  
  // Check if file exists
  if (!fs.existsSync(csvPath)) {
    console.error(`❌ CSV file not found at: ${csvPath}`);
    console.log('📝 Please make sure the file exists at: backend/prisma/data/municipalities.csv');
    return;
  }
  
  const rows = parseCSV(csvPath);
  console.log(`✅ Loaded ${rows.length} municipality records\n`);

  let baladyaCount = 0;
  let skippedCount = 0;
  let errorCount = 0;

  // Process each municipality
  for (const row of rows) {
    try {
      // Skip if missing names
      if (!row.municipality_name || !row.municipality_name.trim()) {
        skippedCount++;
        continue;
      }

      // Find the wilaya by code using the wilayas array
      const wilayaCode = parseInt(row.wilaya_code);
      const wilaya = await prisma.wilaya.findUnique({
        where: { code: wilayaCode },
      });

      if (!wilaya) {
        console.warn(`⚠️  Wilaya not found for code ${row.wilaya_code} (${row.wilaya_name})`);
        skippedCount++;
        continue;
      }

      const nameFr = row.municipality_name.trim();
      const nameAr = row.municipality_name_ar?.trim() || nameFr; // Fallback to French if Arabic missing

      // Use upsert with the correct unique constraint
        await prisma.baladya.upsert({
        where: {
            nameFr_wilayaId: {
            nameFr: nameFr,
            wilayaId: wilaya.id,
            },
        },
        update: {
            nameAr: nameAr,
            code: parseInt(row.municipality_id), // ← ADD THIS
        },
        create: {
            nameFr: nameFr,
            nameAr: nameAr,
            code: parseInt(row.municipality_id), // ← ADD THIS
            wilayaId: wilaya.id,
        },
        });

      
      baladyaCount++;
      
      // Progress indicator
      if (baladyaCount % 100 === 0) {
        console.log(`  📊 Progress: ${baladyaCount} municipalities seeded...`);
      }
      
    } catch (error) {
      errorCount++;
      console.error(`❌ Error seeding municipality "${row.municipality_name}":`, 
        error instanceof Error ? error.message : error);
    }
  }

  const totalCount = await prisma.baladya.count();
  console.log(`\n📈 Baladyat Summary:`);
  console.log(`  ✅ Seeded: ${baladyaCount}`);
  console.log(`  ⏭️  Skipped: ${skippedCount}`);
  console.log(`  ❌ Errors: ${errorCount}`);
  console.log(`  📊 Total in DB: ${totalCount}`);
}

async function main() {
  console.log('🌱 Starting location seed...\n');

  await seedWilayas();
  await seedBaladyatFromCSV();

  console.log('\n✅ Location seed completed successfully! 🎉');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

