-- AlterTable
ALTER TABLE "appointments" ADD COLUMN     "service_id" TEXT;

-- AlterTable
ALTER TABLE "slots" ADD COLUMN     "service_id" TEXT;
