-- AlterTable
ALTER TABLE "users" ADD COLUMN     "deletion_reason" TEXT,
ADD COLUMN     "deletion_requested_at" TIMESTAMP(3),
ADD COLUMN     "deletion_reversible_until" TIMESTAMP(3),
ADD COLUMN     "deletion_scheduled_at" TIMESTAMP(3),
ADD COLUMN     "deletion_status" TEXT DEFAULT 'active';
