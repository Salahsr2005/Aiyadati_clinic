/*
  Warnings:

  - You are about to drop the column `is_verified` on the `seller_documents` table. All the data in the column will be lost.
  - You are about to drop the column `user_id` on the `seller_documents` table. All the data in the column will be lost.
  - The `doc_type` column on the `seller_documents` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - You are about to drop the column `can_post` on the `users` table. All the data in the column will be lost.
  - Added the required column `seller_id` to the `seller_documents` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "ApplicationStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "ApplicationType" AS ENUM ('DOCTOR', 'CLINIC', 'SELLER');

-- CreateEnum
CREATE TYPE "SellerStatus" AS ENUM ('PENDING', 'ACTIVE', 'SUSPENDED', 'BANNED');

-- CreateEnum
CREATE TYPE "SellerType" AS ENUM ('INDIVIDUAL', 'COMPANY', 'ASSOCIATION');

-- CreateEnum
CREATE TYPE "SellerDocumentType" AS ENUM ('LICENSE', 'ID_CARD', 'REGISTRATION', 'TAX_CERTIFICATE', 'OTHER');

-- CreateEnum
CREATE TYPE "SellerDocumentStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- DropForeignKey
ALTER TABLE "orders" DROP CONSTRAINT "orders_seller_id_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_seller_id_fkey";

-- DropForeignKey
ALTER TABLE "seller_documents" DROP CONSTRAINT "seller_documents_user_id_fkey";

-- DropIndex
DROP INDEX "seller_documents_user_id_is_verified_idx";

-- AlterTable
ALTER TABLE "seller_documents" DROP COLUMN "is_verified",
DROP COLUMN "user_id",
ADD COLUMN     "rejection_reason" TEXT,
ADD COLUMN     "seller_id" TEXT NOT NULL,
ADD COLUMN     "status" "SellerDocumentStatus" NOT NULL DEFAULT 'PENDING',
DROP COLUMN "doc_type",
ADD COLUMN     "doc_type" "SellerDocumentType" NOT NULL DEFAULT 'OTHER';

-- AlterTable
ALTER TABLE "users" DROP COLUMN "can_post";

-- CreateTable
CREATE TABLE "registration_applications" (
    "id" TEXT NOT NULL,
    "type" "ApplicationType" NOT NULL,
    "status" "ApplicationStatus" NOT NULL DEFAULT 'PENDING',
    "reviewed_by" TEXT,
    "reviewed_at" TIMESTAMP(3),
    "rejection_reason" TEXT,
    "doctor_email" TEXT,
    "doctor_first_name_fr" TEXT,
    "doctor_first_name_ar" TEXT,
    "doctor_last_name_fr" TEXT,
    "doctor_last_name_ar" TEXT,
    "doctor_phone" TEXT,
    "doctor_wilaya_id" TEXT,
    "doctor_specialties" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "doctor_bio_fr" TEXT,
    "doctor_bio_ar" TEXT,
    "doctor_years_experience" INTEGER,
    "doctor_practice_type" TEXT,
    "clinic_name_fr" TEXT,
    "clinic_name_ar" TEXT,
    "clinic_email" TEXT,
    "clinic_phone" TEXT,
    "clinic_wilaya_id" TEXT,
    "clinic_baladya_id" TEXT,
    "clinic_description_fr" TEXT,
    "clinic_description_ar" TEXT,
    "clinic_facility_type" TEXT,
    "seller_email" TEXT,
    "seller_first_name" TEXT,
    "seller_last_name" TEXT,
    "seller_phone" TEXT,
    "seller_wilaya_id" TEXT,
    "seller_baladya_id" TEXT,
    "seller_business_name" TEXT,
    "seller_business_type" TEXT,
    "seller_tax_number" TEXT,
    "seller_reg_number" TEXT,
    "seller_address" TEXT,
    "notes" TEXT,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "submitted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "created_entity_id" TEXT,
    "created_entity_type" TEXT,

    CONSTRAINT "registration_applications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "application_documents" (
    "id" TEXT NOT NULL,
    "application_id" TEXT NOT NULL,
    "file_id" TEXT NOT NULL,
    "storage_key" TEXT NOT NULL,
    "file_path" TEXT NOT NULL,
    "file_name" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "doc_type" TEXT NOT NULL,
    "storage_type" TEXT NOT NULL DEFAULT 'private',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "application_documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "password_setup_tokens" (
    "id" TEXT NOT NULL,
    "owner_id" TEXT NOT NULL,
    "owner_type" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "used_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "password_setup_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sellers" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "first_name" TEXT NOT NULL,
    "last_name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "business_name" TEXT,
    "business_type" "SellerType" NOT NULL DEFAULT 'INDIVIDUAL',
    "tax_number" TEXT,
    "registration_number" TEXT,
    "wilaya_id" TEXT NOT NULL,
    "baladya_id" TEXT,
    "address" TEXT,
    "status" "SellerStatus" NOT NULL DEFAULT 'PENDING',
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "is_suspended" BOOLEAN NOT NULL DEFAULT false,
    "suspension_reason" TEXT,
    "verified_by" TEXT,
    "verified_at" TIMESTAMP(3),
    "rejection_reason" TEXT,
    "avg_rating" DOUBLE PRECISION,
    "total_reviews" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sellers_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "registration_applications_status_type_submitted_at_idx" ON "registration_applications"("status", "type", "submitted_at");

-- CreateIndex
CREATE INDEX "registration_applications_reviewed_by_idx" ON "registration_applications"("reviewed_by");

-- CreateIndex
CREATE UNIQUE INDEX "application_documents_file_id_key" ON "application_documents"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "application_documents_storage_key_key" ON "application_documents"("storage_key");

-- CreateIndex
CREATE INDEX "application_documents_application_id_doc_type_idx" ON "application_documents"("application_id", "doc_type");

-- CreateIndex
CREATE UNIQUE INDEX "password_setup_tokens_token_key" ON "password_setup_tokens"("token");

-- CreateIndex
CREATE INDEX "password_setup_tokens_token_idx" ON "password_setup_tokens"("token");

-- CreateIndex
CREATE INDEX "password_setup_tokens_expires_at_used_at_idx" ON "password_setup_tokens"("expires_at", "used_at");

-- CreateIndex
CREATE INDEX "password_setup_tokens_owner_id_owner_type_idx" ON "password_setup_tokens"("owner_id", "owner_type");

-- CreateIndex
CREATE UNIQUE INDEX "sellers_email_key" ON "sellers"("email");

-- CreateIndex
CREATE UNIQUE INDEX "sellers_phone_key" ON "sellers"("phone");

-- CreateIndex
CREATE INDEX "sellers_email_idx" ON "sellers"("email");

-- CreateIndex
CREATE INDEX "sellers_phone_idx" ON "sellers"("phone");

-- CreateIndex
CREATE INDEX "sellers_wilaya_id_idx" ON "sellers"("wilaya_id");

-- CreateIndex
CREATE INDEX "sellers_status_is_verified_idx" ON "sellers"("status", "is_verified");

-- CreateIndex
CREATE INDEX "sellers_business_name_idx" ON "sellers"("business_name");

-- CreateIndex
CREATE INDEX "seller_documents_seller_id_status_idx" ON "seller_documents"("seller_id", "status");

-- CreateIndex
CREATE INDEX "seller_documents_doc_type_idx" ON "seller_documents"("doc_type");

-- CreateIndex
CREATE INDEX "seller_documents_status_verified_at_idx" ON "seller_documents"("status", "verified_at");

-- AddForeignKey
ALTER TABLE "application_documents" ADD CONSTRAINT "application_documents_application_id_fkey" FOREIGN KEY ("application_id") REFERENCES "registration_applications"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sellers" ADD CONSTRAINT "sellers_wilaya_id_fkey" FOREIGN KEY ("wilaya_id") REFERENCES "wilayas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sellers" ADD CONSTRAINT "sellers_baladya_id_fkey" FOREIGN KEY ("baladya_id") REFERENCES "baladyat"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "seller_documents" ADD CONSTRAINT "seller_documents_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "sellers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "sellers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders" ADD CONSTRAINT "orders_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "sellers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
