/*
  Warnings:

  - A unique constraint covering the columns `[code]` on the table `baladyat` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "baladyat" ADD COLUMN     "code" INTEGER;

-- CreateIndex
CREATE UNIQUE INDEX "baladyat_code_key" ON "baladyat"("code");
