// backend/prisma/seed.vps.update.ts

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ============================================================
// WILAYA DATA - For updating Arabic names
// ============================================================
const wilayas = [
  { code: 1, nameFr: 'Adrar', nameAr: 'أدرار' },
  { code: 2, nameFr: 'Chlef', nameAr: 'الشلف' },
  { code: 3, nameFr: 'Laghouat', nameAr: 'الأغواط' },
  { code: 4, nameFr: 'Oum El Bouaghi', nameAr: 'أم البواقي' },
  { code: 5, nameFr: 'Batna', nameAr: 'باتنة' },
  { code: 6, nameFr: 'Béjaïa', nameAr: 'بجاية' },
  { code: 7, nameFr: 'Biskra', nameAr: 'بسكرة' },
  { code: 8, nameFr: 'Béchar', nameAr: 'بشار' },
  { code: 9, nameFr: 'Blida', nameAr: 'البليدة' },
  { code: 10, nameFr: 'Bouïra', nameAr: 'البويرة' },
  { code: 11, nameFr: 'Tamanrasset', nameAr: 'تمنراست' },
  { code: 12, nameFr: 'Tébessa', nameAr: 'تبسة' },
  { code: 13, nameFr: 'Tlemcen', nameAr: 'تلمسان' },
  { code: 14, nameFr: 'Tiaret', nameAr: 'تيارت' },
  { code: 15, nameFr: 'Tizi Ouzou', nameAr: 'تيزي وزو' },
  { code: 16, nameFr: 'Algiers', nameAr: 'الجزائر' },
  { code: 17, nameFr: 'Djelfa', nameAr: 'الجلفة' },
  { code: 18, nameFr: 'Jijel', nameAr: 'جيجل' },
  { code: 19, nameFr: 'Sétif', nameAr: 'سطيف' },
  { code: 20, nameFr: 'Saïda', nameAr: 'سعيدة' },
  { code: 21, nameFr: 'Skikda', nameAr: 'سكيكدة' },
  { code: 22, nameFr: 'Sidi Bel Abbès', nameAr: 'سيدي بلعباس' },
  { code: 23, nameFr: 'Annaba', nameAr: 'عنابة' },
  { code: 24, nameFr: 'Guelma', nameAr: 'قالمة' },
  { code: 25, nameFr: 'Constantine', nameAr: 'قسنطينة' },
  { code: 26, nameFr: 'Médéa', nameAr: 'المدية' },
  { code: 27, nameFr: 'Mostaganem', nameAr: 'مستغانم' },
  { code: 28, nameFr: "M'Sila", nameAr: 'المسيلة' },
  { code: 29, nameFr: 'Mascara', nameAr: 'معسكر' },
  { code: 30, nameFr: 'Ouargla', nameAr: 'ورقلة' },
  { code: 31, nameFr: 'Oran', nameAr: 'وهران' },
  { code: 32, nameFr: 'El Bayadh', nameAr: 'البيض' },
  { code: 33, nameFr: 'Illizi', nameAr: 'إليزي' },
  { code: 34, nameFr: 'Bordj Bou Arréridj', nameAr: 'برج بوعريريج' },
  { code: 35, nameFr: 'Boumerdès', nameAr: 'بومرداس' },
  { code: 36, nameFr: 'El Tarf', nameAr: 'الطارف' },
  { code: 37, nameFr: 'Tindouf', nameAr: 'تندوف' },
  { code: 38, nameFr: 'Tissemsilt', nameAr: 'تيسمسيلت' },
  { code: 39, nameFr: 'El Oued', nameAr: 'الوادي' },
  { code: 40, nameFr: 'Khenchela', nameAr: 'خنشلة' },
  { code: 41, nameFr: 'Souk Ahras', nameAr: 'سوق أهراس' },
  { code: 42, nameFr: 'Tipaza', nameAr: 'تيبازة' },
  { code: 43, nameFr: 'Mila', nameAr: 'ميلة' },
  { code: 44, nameFr: "Aïn Defla", nameAr: 'عين الدفلى' },
  { code: 45, nameFr: 'Naâma', nameAr: 'النعامة' },
  { code: 46, nameFr: "Aïn Témouchent", nameAr: 'عين تموشنت' },
  { code: 47, nameFr: 'Ghardaïa', nameAr: 'غرداية' },
  { code: 48, nameFr: 'Relizane', nameAr: 'غليزان' },
  { code: 49, nameFr: 'Timimoun', nameAr: 'تيميمون' },
  { code: 50, nameFr: 'Bordj Badji Mokhtar', nameAr: 'برج باجي مختار' },
  { code: 51, nameFr: 'Ouled Djellal', nameAr: 'أولاد جلال' },
  { code: 52, nameFr: 'Béni Abbès', nameAr: 'بني عباس' },
  { code: 53, nameFr: 'Ain Salah', nameAr: 'عين صالح' },
  { code: 54, nameFr: 'Ain Guezzam', nameAr: 'عين قزام' },
  { code: 55, nameFr: 'Touggourt', nameAr: 'تقرت' },
  { code: 56, nameFr: 'Djanet', nameAr: 'جانت' },
  { code: 57, nameFr: "El M'Ghair", nameAr: 'المغير' },
  { code: 58, nameFr: 'El Menia', nameAr: 'المنيعة' },
  { code: 59, nameFr: 'Aflou', nameAr: 'أفلو' },
];

// ============================================================
// SPECIALTY MAPPING
// ============================================================
const SPECIALTY_CODE_MAP: Record<string, string> = {
  '22': 'Médecine générale',
  '25': 'Gynécologie et obstétrique',
  '21': 'Pédiatrie et chirurgie pédiatrique',
  '69': 'Cliniques et hôpitaux',
  '27': 'Dentisterie',
  '29': 'Oto-rhino-laryngologie (ORL)',
  '34': 'Ophtalmologie',
  '28': 'Orthopédie et rhumatologie',
  '31': 'Cardiologie',
  '26': 'Médecine interne',
  '52': 'Psychiatrie',
  '90': 'Neurochirurgie',
  '62': 'Chirurgie générale',
  '30': 'Dermatologie et vénéréologie',
  '42': 'Diabétologie et endocrinologie',
  '32': 'Pneumologie et médecine respiratoire',
  '40': 'Psychologie clinique',
  '51': 'Pharmacies',
  '36': 'Gastro-entérologie',
  '68': "Laboratoire d'analyses médicales",
  '53': 'Radiologie',
  '70': 'Protection civile',
  '50': 'Physiothérapie et médecine alternative',
  '44': 'Hématologie-oncologie',
  '55': 'Anesthésiologie',
  '72': 'Opticien médical',
  '73': "Clinique d'orthophonie",
  '74': 'Vétérinaire',
  '48': 'Nutrition et diététique',
  '75': 'Fournitures médicales',
  '76': "Associations d'aide aux patients",
  '77': "Maison d'accueil pour les patients",
  '78': 'Ambulance privée',
  '79': 'Allergologie',
  '80': 'Médecine physique et réadaptation',
  '81': 'Sage-femme',
  '82': 'Infirmière à domicile',
  '83': 'Maladies infectieuses',
  '84': 'Urologie',
  '85': 'Néphrologie',
  '88': 'Médecine nucléaire',
  '89': 'Centres de traitement de la toxicomanie',
  '91': 'Biologie et biochimie médicales',
  '92': 'Chirurgie esthétique',
  '93': 'Centre de soins corporels',
};

interface DoctorJson {
  Num_doct: string;
  Name_doct: string;
  Num_sp: string;
  Adress_doct: string;
  Tel1_doct: string;
  Tel2_doct: string;
  Email_doct: string;
  Wilaya_doct: string;
  description_doct: string;
  latcor: string | null;
  loncor: string | null;
  idbaladiya: string | null;
  newinfo: string;
  created_at: string | null;
  updated_at: string | null;
  iduser: string;
}

interface MunicipalityRow {
  wilaya_code: string;
  wilaya_name: string;
  municipality_id: string;
  municipality_name: string;
  municipality_name_ar: string;
}

function parseCSV(filePath: string): MunicipalityRow[] {
  const fileContent = fs.readFileSync(filePath, 'utf-8');
  const lines = fileContent.split('\n');

  const results: MunicipalityRow[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const values: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim());

    if (values.length >= 5) {
      results.push({
        wilaya_code: values[0].replace(/^"|"$/g, ''),
        wilaya_name: values[1].replace(/^"|"$/g, ''),
        municipality_id: values[2].replace(/^"|"$/g, ''),
        municipality_name: values[3].replace(/^"|"$/g, ''),
        municipality_name_ar: values[4].replace(/^"|"$/g, ''),
      });
    }
  }

  return results;
}

// ============================================================
// ARABIC → FRENCH TRANSLITERATION (LOCAL, NO EXTERNAL PACKAGES)
// ============================================================

// Common Algerian names → conventional French spelling
// Add more as needed
const NAME_DICTIONARY: Record<string, string> = {
  // First names
  'محمد': 'Mohamed',
  'احمد': 'Ahmed',
  'أحمد': 'Ahmed',
  'علي': 'Ali',
  'عمر': 'Omar',
  'عثمان': 'Othmane',
  'يوسف': 'Youcef',
  'ابراهيم': 'Ibrahim',
  'إبراهيم': 'Ibrahim',
  'اسماعيل': 'Ismail',
  'إسماعيل': 'Ismail',
  'عبدالله': 'Abdellah',
  'عبد الله': 'Abdellah',
  'عبدالقادر': 'Abdelkader',
  'عبد القادر': 'Abdelkader',
  'عبدالرحمان': 'Abderrahmane',
  'عبد الرحمان': 'Abderrahmane',
  'عبدالرحمن': 'Abderrahmane',
  'عبد الرحمن': 'Abderrahmane',
  'عبدالحق': 'Abdelhak',
  'عبد الحق': 'Abdelhak',
  'عبدالكريم': 'Abdelkrim',
  'عبد الكريم': 'Abdelkrim',
  'عبدالحميد': 'Abdelhamid',
  'عبد الحميد': 'Abdelhamid',
  'عبدالمجيد': 'Abdelmadjid',
  'عبد المجيد': 'Abdelmadjid',
  'عبدالعزيز': 'Abdelaziz',
  'عبد العزيز': 'Abdelaziz',
  'عبدالنور': 'Abdennour',
  'عبد النور': 'Abdennour',
  'رياض': 'Riad',
  'كريم': 'Karim',
  'نبيل': 'Nabil',
  'رشيد': 'Rachid',
  'نور الدين': 'Noureddine',
  'نورالدين': 'Noureddine',
  'صلاح الدين': 'Salaheddine',
  'جمال': 'Djamel',
  'سمير': 'Samir',
  'فريد': 'Farid',
  'حسين': 'Hocine',
  'الحسين': 'El Hocine',
  'بلقاسم': 'Belkacem',
  'لقاسم': 'Lakacem',
  'قاسم': 'Kacem',
  'بوعلام': 'Boualem',
  'بوزيد': 'Bouzid',
  'مصطفى': 'Mustapha',
  'مصطفي': 'Mustapha',
  'الطاهر': 'Tahar',
  'طاهر': 'Tahar',
  'زين الدين': 'Zineddine',
  'حمزة': 'Hamza',
  'اسامة': 'Oussama',
  'أسامة': 'Oussama',
  'خالد': 'Khaled',
  'سفيان': 'Sofiane',
  'وليد': 'Walid',
  'فارس': 'Farès',
  'انيس': 'Anis',
  'أنيس': 'Anis',
  'مهدي': 'Mehdi',
  'ياسين': 'Yacine',
  'فاطمة': 'Fatima',
  'فاطمة الزهراء': 'Fatima Zohra',
  'خديجة': 'Khadidja',
  'عائشة': 'Aicha',
  'مريم': 'Meriem',
  'زينب': 'Zineb',
  'سعاد': 'Souad',
  'سميرة': 'Samira',
  'نادية': 'Nadia',
  'كريمة': 'Karima',
  'حورية': 'Houria',
  'ليلى': 'Leila',
  'نجاة': 'Nadjet',
  'سارة': 'Sara',
  'امال': 'Amel',
  'أمال': 'Amel',
  'وردة': 'Warda',
  'حياة': 'Hayat',
  'نوال': 'Nawel',
  'ياسمين': 'Yasmine',
  'دنيا': 'Dounia',
  'شهرزاد': 'Chahrazad',
  'نسرين': 'Nesrine',
  'سمية': 'Soumia',
  'نور': 'Nour',
  'سليم': 'Salim',
  'غشام': 'Ghacham',
  'علاوش': 'Alaouch',
  'مسلوب': 'Masloub',
  'بوشنتوف': 'Bouchentouf',
  'زكرياء': 'Zakaria',
  'عبدالرزاق': 'Abderrazak',
  'عبد الرزاق': 'Abderrazak',
  'مخلوفي': 'Mekhloufi',
  'السعيد': 'El Said',
  'بن عاشور': 'Ben Achour',
};

// Character mapping for fallback transliteration
const LETTER_MAP: Record<string, string> = {
  'ا': 'a', 'أ': 'a', 'إ': 'i', 'آ': 'a', 'ى': 'a', 'ة': 'a',
  'ب': 'b',
  'ت': 't',
  'ث': 'th',
  'ج': 'dj',
  'ح': 'h',
  'خ': 'kh',
  'د': 'd',
  'ذ': 'dh',
  'ر': 'r',
  'ز': 'z',
  'س': 's',
  'ش': 'ch',
  'ص': 's',
  'ض': 'd',
  'ط': 't',
  'ظ': 'dh',
  'ع': 'a',
  'غ': 'gh',
  'ف': 'f',
  'ق': 'q',
  'ك': 'k',
  'ل': 'l',
  'م': 'm',
  'ن': 'n',
  'ه': 'h',
  'و': 'ou',
  'ؤ': 'ou',
  'ي': 'i',
  'ئ': 'i',
  'ء': '',
};

function transliterateWord(word: string): string {
  const clean = word.trim();
  if (!clean) return '';

  // Check dictionary first
  if (NAME_DICTIONARY[clean]) {
    return NAME_DICTIONARY[clean];
  }

  // Fallback: letter-by-letter mapping
  let result = '';
  for (const char of clean) {
    result += LETTER_MAP[char] || char;
  }

  // Capitalize first letter
  if (result) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }

  return result || clean;
}

function transliterateArabicName(fullText: string): string {
  const clean = fullText.trim();
  if (!clean) return '';

  // Try the whole name as a single lookup first (for compound names)
  if (NAME_DICTIONARY[clean]) {
    return NAME_DICTIONARY[clean];
  }

  // Then try each word
  const words = clean.split(/\s+/);
  return words
    .map(w => transliterateWord(w))
    .filter(Boolean)
    .join(' ');
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function capitalizeWords(str: string): string {
  if (!str) return '';
  return str
    .split(' ')
    .filter(word => word.length > 0)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

function extractNameParts(name: string): {
  firstNameFr: string;
  lastNameFr: string;
  firstNameAr: string;
  lastNameAr: string;
} {
  if (!name || !name.trim()) {
    return {
      firstNameFr: 'Unknown',
      lastNameFr: 'Doctor',
      firstNameAr: 'طبيب',
      lastNameAr: 'مجهول',
    };
  }

  const trimmed = name.trim();
  const hasArabic = /[\u0600-\u06FF]/.test(trimmed);

  if (hasArabic) {
    const parts = trimmed.split(/\s+/);

    if (parts.length === 1) {
      const firstNameFr = capitalizeWords(transliterateWord(parts[0])) || 'Unknown';
      return {
        firstNameFr,
        lastNameFr: firstNameFr,
        firstNameAr: parts[0],
        lastNameAr: 'طبيب',
      };
    }

    // Multiple parts - last part is last name, rest is first name
    const lastNameAr = parts[parts.length - 1];
    const firstNameAr = parts.slice(0, -1).join(' ');

    const firstNameFr = capitalizeWords(transliterateArabicName(firstNameAr)) || 'Unknown';
    const lastNameFr = capitalizeWords(transliterateArabicName(lastNameAr)) || 'Doctor';

    return {
      firstNameFr,
      lastNameFr,
      firstNameAr: firstNameAr || 'طبيب',
      lastNameAr: lastNameAr || 'مجهول',
    };
  } else {
    // French/Latin name - keep as is
    const parts = trimmed.split(/\s+/);
    if (parts.length === 1) {
      return {
        firstNameFr: capitalizeWords(parts[0]),
        lastNameFr: 'Doctor',
        firstNameAr: capitalizeWords(parts[0]),
        lastNameAr: 'طبيب',
      };
    }
    const firstNameFr = capitalizeWords(parts[0]);
    const lastNameFr = capitalizeWords(parts.slice(1).join(' '));
    return {
      firstNameFr,
      lastNameFr,
      firstNameAr: firstNameFr,
      lastNameAr: lastNameFr,
    };
  }
}

function cleanPhone(phone: string): string | null {
  if (!phone) return null;
  let cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
  if (cleaned.startsWith('0') && cleaned.length === 10) return cleaned;
  if (cleaned.startsWith('+213')) {
    cleaned = '0' + cleaned.slice(4);
    return cleaned.length === 10 ? cleaned : null;
  }
  if (/^\d+$/.test(cleaned) && cleaned.length >= 8) {
    cleaned = cleaned.padStart(10, '0');
    return cleaned;
  }
  return null;
}

function generateRandomPhone(): string {
  const prefixes = ['055', '056', '057', '066', '067', '077'];
  return prefixes[Math.floor(Math.random() * prefixes.length)] +
         String(Math.floor(Math.random() * 10000000)).padStart(7, '0');
}

function generateEmail(name: string, phone: string): string {
  const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30) || 'doctor';
  return `${slug}${phone.slice(-4)}@iyadati.dz`;
}

async function isPhoneExists(phone: string): Promise<boolean> {
  const existing = await prisma.doctor.findUnique({
    where: { phone },
    select: { id: true },
  });
  return !!existing;
}

async function isEmailExists(email: string): Promise<boolean> {
  const existing = await prisma.doctor.findUnique({
    where: { email },
    select: { id: true },
  });
  return !!existing;
}

async function getUniquePhone(): Promise<string> {
  let attempts = 0;
  let phone: string;
  do {
    phone = generateRandomPhone();
    attempts++;
    if (attempts > 100) {
      const timestamp = Date.now().toString().slice(-7);
      phone = `055${timestamp}`;
      break;
    }
  } while (await isPhoneExists(phone));
  return phone;
}

async function getUniqueEmail(name: string, phone: string): Promise<string> {
  let attempts = 0;
  let email: string;
  const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30) || 'doctor';

  do {
    if (attempts === 0) {
      email = `${slug}${phone.slice(-4)}@iyadati.dz`;
    } else {
      email = `${slug}${phone.slice(-4)}${attempts}@iyadati.dz`;
    }
    attempts++;
    if (attempts > 100) {
      const ts = Date.now().toString().slice(-6);
      email = `${slug}${ts}@iyadati.dz`;
      break;
    }
  } while (await isEmailExists(email));

  return email;
}

async function deleteDoctorsWithNoAppointments() {
  console.log('🗑️  Deleting seeded doctors (isBookable: false)...');

  const doctorsToDelete = await prisma.doctor.findMany({
    where: {
      isAvailableForBooking: false,
      appointments: { none: {} },
    },
    select: { id: true },
  });

  console.log(`   Found ${doctorsToDelete.length} doctors to delete (with no appointments)`);

  const doctorsWithAppointments = await prisma.doctor.count({
    where: {
      isAvailableForBooking: false,
      appointments: { some: {} },
    },
  });
  console.log(`   ${doctorsWithAppointments} doctors have appointments (will be kept)`);

  if (doctorsToDelete.length === 0) {
    console.log('   ✅ No doctors to delete\n');
    return 0;
  }

  const idsToDelete = doctorsToDelete.map(d => d.id);

  console.log('   Deleting doctor specialties...');
  await prisma.doctorSpecialty.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor configs...');
  await prisma.doctorConfig.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor logos...');
  await prisma.doctorLogo.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor documents...');
  await prisma.doctorDocument.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor breaks...');
  await prisma.doctorBreak.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor availabilities...');
  await prisma.doctorAvailability.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting slots...');
  await prisma.slot.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting slot generation rules...');
  await prisma.slotGenerationRule.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting clinic service doctors...');
  await prisma.clinicServiceDoctor.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting clinic doctors...');
  await prisma.clinicDoctor.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctor reviews...');
  await prisma.doctorReview.deleteMany({ where: { doctorId: { in: idsToDelete } } });

  console.log('   Deleting doctors...');
  const result = await prisma.doctor.deleteMany({ where: { id: { in: idsToDelete } } });
  console.log(`   ✅ Deleted ${result.count} doctors\n`);

  return result.count;
}

async function updateVps() {
  console.log('🚀 Starting VPS UPDATE with transliteration...\n');
  console.log('⚠️  This will:');
  console.log('   1. Update Wilayas with Arabic names');
  console.log('   2. Add Baladyat (municipalities) with codes');
  console.log('   3. DELETE all doctors with isBookable: false AND no appointments');
  console.log('   4. Seed fresh doctors from JSON with transliterated names\n');

  // STEP 1: UPDATE WILAYAS
  console.log('📍 Updating Wilayas...');
  for (const w of wilayas) {
    await prisma.wilaya.upsert({
      where: { code: w.code },
      update: { nameAr: w.nameAr },
      create: { code: w.code, nameFr: w.nameFr, nameAr: w.nameAr },
    });
  }
  const wilayaCount = await prisma.wilaya.count();
  console.log(`✅ Wilayas updated! (${wilayaCount} total)\n`);

  // STEP 2: ADD BALADYAT
  console.log('🏙️  Adding Baladyat...');
  const csvPath = path.join(__dirname, 'data', 'municipalities.csv');

  if (!fs.existsSync(csvPath)) {
    console.error(`❌ CSV file not found: ${csvPath}`);
    process.exit(1);
  }

  const rows = parseCSV(csvPath);
  let baladyaCount = 0;

  for (const row of rows) {
    const wilaya = await prisma.wilaya.findUnique({
      where: { code: parseInt(row.wilaya_code) },
    });

    if (!wilaya) continue;

    const nameFr = row.municipality_name.trim();
    const nameAr = row.municipality_name_ar?.trim() || nameFr;

    await prisma.baladya.upsert({
      where: {
        nameFr_wilayaId: {
          nameFr: nameFr,
          wilayaId: wilaya.id,
        },
      },
      update: {
        nameAr: nameAr,
        code: parseInt(row.municipality_id),
      },
      create: {
        nameFr: nameFr,
        nameAr: nameAr,
        code: parseInt(row.municipality_id),
        wilayaId: wilaya.id,
      },
    });
    baladyaCount++;
  }

  console.log(`✅ Baladyat added! (${baladyaCount} total)\n`);

  // STEP 3: DELETE SEEDED DOCTORS
  await deleteDoctorsWithNoAppointments();

  // STEP 4: SEED DOCTORS FROM JSON
  console.log('👨‍⚕️ Seeding doctors from JSON...');

  const jsonPath = path.join(__dirname, 'data', 'doctors_raw.json');
  if (!fs.existsSync(jsonPath)) {
    console.error(`❌ JSON file not found: ${jsonPath}`);
    process.exit(1);
  }

  const jsonContent = fs.readFileSync(jsonPath, 'utf-8');
  const doctors: DoctorJson[] = JSON.parse(jsonContent);

  console.log(`📊 Found ${doctors.length} doctors in JSON\n`);

  const specialties = await prisma.specialty.findMany();
  const wilayasMap = await prisma.wilaya.findMany();

  const specialtyMap: Record<string, string> = {};
  for (const spec of specialties) {
    specialtyMap[spec.nameFr] = spec.id;
  }

  const wilayaMap: Record<string, string> = {};
  for (const w of wilayasMap) {
    wilayaMap[String(w.code)] = w.id;
  }

  console.log(`✅ Loaded: ${specialties.length} specialties, ${wilayasMap.length} wilayas\n`);

  const hashedPassword = await bcrypt.hash('doctor123456', 12);

  let successCount = 0;
  let errorCount = 0;
  let skippedCount = 0;
  let duplicatePhoneCount = 0;
  let duplicateEmailCount = 0;

  for (let i = 0; i < doctors.length; i++) {
    const doc = doctors[i];

    try {
      const name = doc.Name_doct || '';
      const phoneRaw = doc.Tel1_doct || '';
      const phone2Raw = doc.Tel2_doct || '';
      const emailRaw = doc.Email_doct || '';
      const description = doc.description_doct || '';
      const wilayaCode = doc.Wilaya_doct || '';
      const specialtyCode = doc.Num_sp || '';
      const municipalityId = doc.idbaladiya || '';
      const latRaw = doc.latcor;
      const lngRaw = doc.loncor;

      if (!name || !name.trim()) {
        skippedCount++;
        continue;
      }

      if (!wilayaCode || !wilayaCode.trim() || wilayaCode === '0') {
        skippedCount++;
        continue;
      }

      const wilayaId = wilayaMap[wilayaCode];
      if (!wilayaId) {
        skippedCount++;
        continue;
      }

      let baladyaId = null;
      if (municipalityId && municipalityId.trim() && municipalityId !== 'null') {
        const baladya = await prisma.baladya.findUnique({
          where: { code: parseInt(municipalityId) },
        });
        if (baladya) {
          baladyaId = baladya.id;
        }
      }

      const specialtyName = SPECIALTY_CODE_MAP[specialtyCode] || null;
      const specialtyId = specialtyName && specialtyMap[specialtyName] ? specialtyMap[specialtyName] : null;

      const nameParts = extractNameParts(name);

      let phone = cleanPhone(phoneRaw);
      if (!phone) phone = cleanPhone(phone2Raw);

      if (!phone || await isPhoneExists(phone)) {
        if (phone) duplicatePhoneCount++;
        phone = await getUniquePhone();
      }

      let email = emailRaw;

      if (!email || !email.trim() || await isEmailExists(email)) {
        if (email && await isEmailExists(email)) duplicateEmailCount++;
        email = await getUniqueEmail(name, phone);
      }

      const lat = parseFloat(latRaw || '');
      const lng = parseFloat(lngRaw || '');

      const doctorData: any = {
        email,
        password: hashedPassword,
        firstNameFr: nameParts.firstNameFr.slice(0, 100),
        firstNameAr: nameParts.firstNameAr.slice(0, 100),
        lastNameFr: nameParts.lastNameFr.slice(0, 100),
        lastNameAr: nameParts.lastNameAr.slice(0, 100),
        phone,
        wilayaId,
        practiceType: 'INDEPENDENT' as any,
        isVerified: true,
        isCompleted: true,
        isSuspended: false,
        isRegistered: true,
        isAvailableForBooking: false,
        messageForUser: "En attente jusqu'au lancement d'Iyadati",
        latitude: !isNaN(lat) && lat !== 0 ? lat : null,
        longitude: !isNaN(lng) && lng !== 0 ? lng : null,
        bioFr: description || `${nameParts.firstNameFr} ${nameParts.lastNameFr}`,
        bioAr: description || `${nameParts.firstNameAr} ${nameParts.lastNameAr}`,
        yearsOfExp: null,
        reviewVisibility: 'BOTH' as any,
        avgRating: null,
        totalReviews: 0,
      };

      if (baladyaId) {
        doctorData.baladyaId = baladyaId;
      }

      const doctor = await prisma.doctor.create({ data: doctorData });

      if (specialtyId) {
        await prisma.doctorSpecialty.create({
          data: { doctorId: doctor.id, specialtyId: specialtyId },
        });
      }

      await prisma.doctorConfig.create({
        data: {
          doctorId: doctor.id,
          slotDuration: 30,
          bufferTime: 5,
          maxPerSlot: 1,
        },
      });

      successCount++;

      if ((i + 1) % 500 === 0 || i === doctors.length - 1) {
        console.log(`  📊 Progress: ${i + 1}/${doctors.length} doctors processed (${successCount} created)...`);
      }

    } catch (error) {
      errorCount++;
      if (errorCount <= 5) {
        console.error(`  ❌ Error at record ${i + 1}:`, error instanceof Error ? error.message : error);
      }
    }
  }

  console.log(`\n📈 VPS UPDATE SUMMARY:`);
  console.log(`  ✅ Successfully seeded: ${successCount}`);
  console.log(`  ⏭️  Skipped: ${skippedCount}`);
  console.log(`  ❌ Errors: ${errorCount}`);
  console.log(`  📱 Duplicate phones fixed: ${duplicatePhoneCount}`);
  console.log(`  ✉️  Duplicate emails fixed: ${duplicateEmailCount}`);

  console.log('\n📊 FINAL DATABASE STATS:');
  console.log(`  🌍 Wilayas: ${await prisma.wilaya.count()}`);
  console.log(`  🏙️  Baladyat: ${await prisma.baladya.count()}`);
  console.log(`  🔬 Specialties: ${await prisma.specialty.count()}`);
  console.log(`  👨‍⚕️ Total Doctors: ${await prisma.doctor.count()}`);
  console.log(`  🔗 Doctor Specialties: ${await prisma.doctorSpecialty.count()}`);
  console.log(`  ⚙️ Doctor Configs: ${await prisma.doctorConfig.count()}`);

  console.log('\n✅ VPS UPDATE COMPLETED! 🎉');
}

// ============================================================
// MAIN
// ============================================================
async function main() {
  try {
    // Test the transliterator first
    const testNames = ['بوشنتوف إيمان', 'مسلوب زكرياء', 'محمد', 'عبد الرحمان'];
    console.log('📝 Testing transliteration:');
    for (const name of testNames) {
      const result = transliterateArabicName(name);
      console.log(`  "${name}" → "${result}"`);
    }
    console.log('');

    await updateVps();
  } catch (error) {
    console.error('❌ UPDATE ERROR:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();

