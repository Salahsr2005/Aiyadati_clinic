// backend/prisma/seed.doctors.ts

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ============================================================
// SPECIALTY MAPPING (from specialties.csv)
// ============================================================
const SPECIALTY_CODE_MAP: Record<string, string> = {
  '22': 'Médecine générale',
  '25': 'Gynécologie et obstétrique',
  '21': 'Pédiatrie et chirurgie pédiatrique',
  '69': 'Cliniques et hôpitaux',
  '27': 'Dentisterie',
  '29': 'Oto-rhino-laryngologie (ORL)',
  '34': 'Ophtalmologie',
  '28': 'Orthopédie et rhumatologie',
  '31': 'Cardiologie',
  '26': 'Médecine interne',
  '52': 'Psychiatrie',
  '90': 'Neurochirurgie',
  '62': 'Chirurgie générale',
  '30': 'Dermatologie et vénéréologie',
  '42': 'Diabétologie et endocrinologie',
  '32': 'Pneumologie et médecine respiratoire',
  '40': 'Psychologie clinique',
  '51': 'Pharmacies',
  '36': 'Gastro-entérologie',
  '68': "Laboratoire d'analyses médicales",
  '53': 'Radiologie',
  '70': 'Protection civile',
  '50': 'Physiothérapie et médecine alternative',
  '44': 'Hématologie-oncologie',
  '55': 'Anesthésiologie',
  '72': 'Opticien médical',
  '73': "Clinique d'orthophonie",
  '74': 'Vétérinaire',
  '48': 'Nutrition et diététique',
  '75': 'Fournitures médicales',
  '76': "Associations d'aide aux patients",
  '77': "Maison d'accueil pour les patients",
  '78': 'Ambulance privée',
  '79': 'Allergologie',
  '80': 'Médecine physique et réadaptation',
  '81': 'Sage-femme',
  '82': 'Infirmière à domicile',
  '83': 'Maladies infectieuses',
  '84': 'Urologie',
  '85': 'Néphrologie',
  '88': 'Médecine nucléaire',
  '89': 'Centres de traitement de la toxicomanie',
  '91': 'Biologie et biochimie médicales',
  '92': 'Chirurgie esthétique',
  '93': 'Centre de soins corporels',
};

interface DoctorJson {
  Num_doct: string;
  Name_doct: string;
  Num_sp: string;
  Adress_doct: string;
  Tel1_doct: string;
  Tel2_doct: string;
  Email_doct: string;
  Wilaya_doct: string;
  description_doct: string;
  latcor: string | null;
  loncor: string | null;
  idbaladiya: string | null;
  newinfo: string;
  created_at: string | null;
  updated_at: string | null;
  iduser: string;
}

// ============================================================
// TRACKING SETS FOR DUPLICATE DETECTION
// ============================================================
const usedPhones = new Set<string>();
const usedEmails = new Set<string>();

function cleanPhone(phone: string): string | null {
  if (!phone) return null;
  let cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
  if (cleaned.startsWith('0') && cleaned.length === 10) return cleaned;
  if (cleaned.startsWith('+213')) {
    cleaned = '0' + cleaned.slice(4);
    return cleaned.length === 10 ? cleaned : null;
  }
  if (/^\d+$/.test(cleaned) && cleaned.length >= 8) {
    cleaned = cleaned.padStart(10, '0');
    return cleaned;
  }
  return null;
}

function generateRandomPhone(): string {
  const prefixes = ['055', '056', '057', '066', '067', '077'];
  let phone = '';
  let attempts = 0;
  do {
    phone = prefixes[Math.floor(Math.random() * prefixes.length)] + 
            String(Math.floor(Math.random() * 10000000)).padStart(7, '0');
    attempts++;
  } while (usedPhones.has(phone) && attempts < 100);
  return phone;
}

function extractNameParts(name: string): { firstNameFr: string; lastNameFr: string; firstNameAr: string; lastNameAr: string } {
  if (!name || !name.trim()) {
    return { firstNameFr: 'Unknown', lastNameFr: 'Doctor', firstNameAr: 'طبيب', lastNameAr: 'مجهول' };
  }
  
  const trimmed = name.trim();
  const hasArabic = /[\u0600-\u06FF]/.test(trimmed);
  
  if (hasArabic) {
    const parts = trimmed.split(/\s+/);
    if (parts.length === 1) {
      return {
        firstNameFr: 'Unknown',
        lastNameFr: 'Doctor',
        firstNameAr: parts[0],
        lastNameAr: 'طبيب'
      };
    }
    const lastNameAr = parts[parts.length - 1];
    const firstNameAr = parts.slice(0, -1).join(' ');
    return {
      firstNameFr: 'Unknown',
      lastNameFr: 'Doctor',
      firstNameAr,
      lastNameAr
    };
  } else {
    const parts = trimmed.split(/\s+/);
    if (parts.length === 1) {
      return {
        firstNameFr: parts[0],
        lastNameFr: 'Doctor',
        firstNameAr: 'طبيب',
        lastNameAr: 'طبيب'
      };
    }
    const firstNameFr = parts[0];
    const lastNameFr = parts.slice(1).join(' ');
    return {
      firstNameFr,
      lastNameFr,
      firstNameAr: firstNameFr,
      lastNameAr: lastNameFr
    };
  }
}

function generateEmail(name: string, phone: string): string {
  if (name && name.trim()) {
    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30);
    let email = `${slug}${phone.slice(-4)}@iyadati.dz`;
    let counter = 1;
    while (usedEmails.has(email)) {
      email = `${slug}${phone.slice(-4)}${counter}@iyadati.dz`;
      counter++;
    }
    return email;
  }
  let email = `doctor_${phone.slice(-4)}@iyadati.dz`;
  let counter = 1;
  while (usedEmails.has(email)) {
    email = `doctor_${phone.slice(-4)}${counter}@iyadati.dz`;
    counter++;
  }
  return email;
}

async function seedDoctorsFromJson() {
  console.log('👨‍⚕️ Starting DOCTORS seed from JSON...\n');
  
  const jsonPath = path.join(__dirname, 'data', 'doctors_raw.json');
  console.log(`📂 Reading JSON from: ${jsonPath}`);
  
  if (!fs.existsSync(jsonPath)) {
    console.error(`❌ JSON file not found: ${jsonPath}`);
    console.log('📁 Please place doctors_raw.json in backend/prisma/data/');
    process.exit(1);
  }
  
  const jsonContent = fs.readFileSync(jsonPath, 'utf-8');
  const doctors: DoctorJson[] = JSON.parse(jsonContent);
  
  console.log(`📊 Found ${doctors.length} doctors in JSON\n`);
  
  // Load all required data from DB
  console.log('📥 Loading data from database...');
  const specialties = await prisma.specialty.findMany();
  const wilayas = await prisma.wilaya.findMany();
  
  // Create lookup maps
  const specialtyMap: Record<string, string> = {};
  for (const spec of specialties) {
    specialtyMap[spec.nameFr] = spec.id;
  }
  
  const wilayaMap: Record<string, string> = {};
  for (const w of wilayas) {
    wilayaMap[String(w.code)] = w.id;
  }
  
  console.log(`✅ Loaded: ${specialties.length} specialties, ${wilayas.length} wilayas\n`);
  
  const hashedPassword = await bcrypt.hash('doctor123456', 12);
  
  let successCount = 0;
  let errorCount = 0;
  let skippedCount = 0;
  let baladyaFoundCount = 0;
  let baladyaNotFoundCount = 0;
  let duplicatePhoneCount = 0;
  let duplicateEmailCount = 0;
  let noNameCount = 0;
  let noWilayaCount = 0;
  const errors: string[] = [];
  
  for (let i = 0; i < doctors.length; i++) {
    const doc = doctors[i];
    
    try {
      // ============================================================
      // EXTRACT DATA
      // ============================================================
      const name = doc.Name_doct || '';
      const phoneRaw = doc.Tel1_doct || '';
      const phone2Raw = doc.Tel2_doct || '';
      const emailRaw = doc.Email_doct || '';
      const description = doc.description_doct || '';
      const wilayaCode = doc.Wilaya_doct || '';
      const specialtyCode = doc.Num_sp || '';
      const municipalityId = doc.idbaladiya || '';
      const latRaw = doc.latcor;
      const lngRaw = doc.loncor;
      
      // ============================================================
      // SKIP CONDITIONS
      // ============================================================
      
      // Skip if no name
      if (!name || !name.trim()) {
        noNameCount++;
        skippedCount++;
        continue;
      }
      
      // Skip if no wilaya code
      if (!wilayaCode || !wilayaCode.trim()) {
        noWilayaCount++;
        skippedCount++;
        continue;
      }
      
      // Get wilaya
      const wilayaId = wilayaMap[wilayaCode];
      if (!wilayaId) {
        errors.push(`Record ${i + 1}: Wilaya code ${wilayaCode} not found`);
        errorCount++;
        skippedCount++;
        continue;
      }
      
      // ============================================================
      // GET BALADYA BY municipality_id (code field)
      // ============================================================
      let baladyaId = null;
      if (municipalityId && municipalityId.trim() && municipalityId !== 'null') {
        const baladya = await prisma.baladya.findUnique({
          where: { code: parseInt(municipalityId) }
        });
        if (baladya) {
          baladyaId = baladya.id;
          baladyaFoundCount++;
        } else {
          baladyaNotFoundCount++;
        }
      }
      
      // ============================================================
      // GET SPECIALTY
      // ============================================================
      const specialtyName = SPECIALTY_CODE_MAP[specialtyCode] || null;
      const specialtyId = specialtyName && specialtyMap[specialtyName] ? specialtyMap[specialtyName] : null;
      
      // ============================================================
      // EXTRACT NAME PARTS
      // ============================================================
      const nameParts = extractNameParts(name);
      
      // ============================================================
      // CLEAN PHONE - WITH DUPLICATE HANDLING
      // ============================================================
      let phone = cleanPhone(phoneRaw);
      if (!phone) phone = cleanPhone(phone2Raw);
      
      // If phone is duplicate or invalid, generate random
      if (!phone || usedPhones.has(phone)) {
        if (phone) {
          duplicatePhoneCount++;
        }
        phone = generateRandomPhone();
        // Ensure we don't use a duplicate phone
        while (usedPhones.has(phone)) {
          phone = generateRandomPhone();
        }
      }
      usedPhones.add(phone);
      
      // ============================================================
      // GET EMAIL - WITH DUPLICATE HANDLING
      // ============================================================
      let email = emailRaw || generateEmail(name, phone);
      
      // If email is duplicate, generate new one
      let emailCounter = 1;
      while (usedEmails.has(email)) {
        duplicateEmailCount++;
        const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30);
        email = `${slug}${phone.slice(-4)}${emailCounter}@iyadati.dz`;
        emailCounter++;
      }
      usedEmails.add(email);
      
      // ============================================================
      // PARSE COORDINATES
      // ============================================================
      const lat = parseFloat(latRaw || '');
      const lng = parseFloat(lngRaw || '');
      
      // ============================================================
      // BUILD DOCTOR DATA
      // ============================================================
      const doctorData: any = {
        email,
        password: hashedPassword,
        firstNameFr: nameParts.firstNameFr.slice(0, 100),
        firstNameAr: nameParts.firstNameAr.slice(0, 100),
        lastNameFr: nameParts.lastNameFr.slice(0, 100),
        lastNameAr: nameParts.lastNameAr.slice(0, 100),
        phone,
        wilayaId,
        practiceType: 'INDEPENDENT' as any,
        isVerified: true,
        isCompleted: true,
        isSuspended: false,
        isRegistered: true,
        isAvailableForBooking: false,
        messageForUser: "En attente jusqu'au lancement d'Iyadati",
        latitude: !isNaN(lat) && lat !== 0 ? lat : null,
        longitude: !isNaN(lng) && lng !== 0 ? lng : null,
        bioFr: description || `${name}`,
        bioAr: description || `${name}`,
        yearsOfExp: null,
        reviewVisibility: 'BOTH' as any,
        avgRating: null,
        totalReviews: 0,
      };
      
      // Add baladya if found
      if (baladyaId) {
        doctorData.baladyaId = baladyaId;
      }
      
      // ============================================================
      // CREATE DOCTOR
      // ============================================================
      const doctor = await prisma.doctor.create({
        data: doctorData,
      });
      
      // Add specialty if found
      if (specialtyId) {
        await prisma.doctorSpecialty.create({
          data: {
            doctorId: doctor.id,
            specialtyId: specialtyId,
          },
        });
      }
      
      // Create doctor config
      await prisma.doctorConfig.create({
        data: {
          doctorId: doctor.id,
          slotDuration: 30,
          bufferTime: 5,
          maxPerSlot: 1,
        },
      });
      
      successCount++;
      
      if ((i + 1) % 500 === 0 || i === doctors.length - 1) {
        console.log(`  📊 Progress: ${i + 1}/${doctors.length} doctors processed (${successCount} created)...`);
      }
      
    } catch (error) {
      errorCount++;
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push(`Record ${i + 1}: ${errorMsg}`);
      if (errorCount <= 10) {
        console.error(`  ❌ Error at record ${i + 1}:`, errorMsg);
      }
    }
  }
  
  console.log(`\n📈 DOCTOR SEED SUMMARY:`);
  console.log(`  📊 Total records processed: ${doctors.length}`);
  console.log(`  ✅ Successfully seeded: ${successCount}`);
  console.log(`  ⏭️  Skipped (no name): ${noNameCount}`);
  console.log(`  ⏭️  Skipped (no wilaya): ${noWilayaCount}`);
  console.log(`  ⏭️  Skipped (other): ${skippedCount - noNameCount - noWilayaCount}`);
  console.log(`  ❌ Errors: ${errorCount}`);
  console.log(`  📱 Duplicate phones fixed: ${duplicatePhoneCount}`);
  console.log(`  ✉️  Duplicate emails fixed: ${duplicateEmailCount}`);
  console.log(`  🏙️  Baladya found by code: ${baladyaFoundCount}`);
  console.log(`  🏙️  Baladya not found: ${baladyaNotFoundCount}`);
  
  if (errors.length > 0) {
    console.log(`\n📋 First 10 errors:`);
    errors.slice(0, 10).forEach(err => console.log(`   ${err}`));
  }
  
  console.log('\n📊 FINAL DATABASE STATS:');
  console.log(`  👨‍⚕️ Total Doctors: ${await prisma.doctor.count()}`);
  console.log(`  🔗 Doctor Specialties: ${await prisma.doctorSpecialty.count()}`);
  console.log(`  ⚙️ Doctor Configs: ${await prisma.doctorConfig.count()}`);
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  try {
    await seedDoctorsFromJson();
    console.log('\n✅ Doctors seed completed successfully! 🎉');
  } catch (error) {
    console.error('❌ SEED ERROR:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();