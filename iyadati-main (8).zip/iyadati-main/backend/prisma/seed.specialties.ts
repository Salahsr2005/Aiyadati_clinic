// backend/prisma/seed.specialties.ts

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

interface SpecialtyRow {
  code: string;
  name: string;
  name_ar: string;
  order: string;
}

function parseCSV(filePath: string): SpecialtyRow[] {
  const fileContent = fs.readFileSync(filePath, 'utf-8');
  const lines = fileContent.split('\n');
  
  // Get headers
  const headers = lines[0].split(',').map(h => h.trim());
  
  const results: SpecialtyRow[] = [];
  
  // Parse each line (skip header)
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Handle quoted fields
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim());
    
    if (values.length >= 4) {
      results.push({
        code: values[0].replace(/^"|"$/g, ''),
        name: values[1].replace(/^"|"$/g, ''),
        name_ar: values[2].replace(/^"|"$/g, ''),
        order: values[3].replace(/^"|"$/g, ''),
      });
    }
  }
  
  return results;
}

async function seedSpecialties() {
  console.log('🔬 Starting specialties seed...\n');
  
  const csvPath = path.join(__dirname, 'data', 'specialties.csv');
  console.log(`📂 Reading CSV from: ${csvPath}`);
  
  // Check if file exists
  if (!fs.existsSync(csvPath)) {
    console.error(`❌ CSV file not found at: ${csvPath}`);
    console.log('📝 Please make sure the file exists at: backend/prisma/data/specialties.csv');
    return;
  }
  
  const rows = parseCSV(csvPath);
  console.log(`✅ Loaded ${rows.length} specialty records\n`);

  let specialtyCount = 0;
  let errorCount = 0;

  // Process each specialty
  for (const row of rows) {
    try {
      // Skip if missing names
      if (!row.name || !row.name.trim()) {
        console.warn(`⚠️  Skipping specialty with missing name (code: ${row.code})`);
        continue;
      }

      const nameFr = row.name.trim();
      const nameAr = row.name_ar?.trim() || nameFr; // Fallback to French if Arabic missing

      // Use upsert with nameFr as unique identifier
      await prisma.specialty.upsert({
        where: {
          nameFr: nameFr,
        },
        update: {
          nameAr: nameAr,
          isActive: true,
        },
        create: {
          nameFr: nameFr,
          nameAr: nameAr,
          isActive: true,
        },
      });
      
      specialtyCount++;
      
      // Progress indicator
      if (specialtyCount % 10 === 0) {
        console.log(`  📊 Progress: ${specialtyCount} specialties seeded...`);
      }
      
    } catch (error) {
      errorCount++;
      console.error(`❌ Error seeding specialty "${row.name}" (code: ${row.code}):`, 
        error instanceof Error ? error.message : error);
    }
  }

  const totalCount = await prisma.specialty.count();
  console.log(`\n📈 Specialties Summary:`);
  console.log(`  ✅ Seeded: ${specialtyCount}`);
  console.log(`  ❌ Errors: ${errorCount}`);
  console.log(`  📊 Total in DB: ${totalCount}`);
}

async function main() {
  try {
    await seedSpecialties();
    console.log('\n✅ Specialties seed completed successfully! 🎉');
  } catch (error) {
    console.error('❌ Seed failed:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();