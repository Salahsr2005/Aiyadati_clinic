// prisma/seed-medical-ecommerce.ts
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ✅ NEW: Storage imports
import { StorageFactory } from '../src/core/storage/storage.factory';
import { generatePublicUrl } from '../src/core/utils/signed-url';

const prisma = new PrismaClient();

// ============================================================
// 📁 LOCAL MEDICAL IMAGES - From seed-assets/products
// ============================================================

const LOCAL_IMAGE_DIR = path.join(__dirname, 'seed-assets', 'products');

// Get all available images
function getAvailableImages(): string[] {
  if (!fs.existsSync(LOCAL_IMAGE_DIR)) {
    return [];
  }
  return fs.readdirSync(LOCAL_IMAGE_DIR).filter(f => 
    /\.(jpg|jpeg|png|webp|gif)$/i.test(f)
  );
}

// ============================================================
// MEDICAL PRODUCT DATA
// ============================================================

const MEDICAL_PRODUCTS = [
  // Stethoscopes
  {
    titleFr: 'Stéthoscope Professionnel Littmann',
    titleAr: 'سماعة طبية احترافية',
    price: 12500,
    category: 'medical-equipment',
    descriptionFr: 'Stéthoscope de haute qualité pour professionnels de santé.',
    descriptionAr: 'سماعة طبية عالية الجودة للمهنيين الصحيين.',
    images: 3,
  },
  {
    titleFr: 'Stéthoscope Médical Classique',
    titleAr: 'سماعة طبية كلاسيكية',
    price: 8900,
    category: 'medical-equipment',
    descriptionFr: 'Stéthoscope fiable pour usage quotidien en milieu médical.',
    descriptionAr: 'سماعة طبية موثوقة للاستخدام اليومي.',
    images: 2,
  },

  // Pulse Oximeters
  {
    titleFr: 'Oxymètre de Pouls Digital',
    titleAr: 'مقياس التأكسج الرقمي',
    price: 3500,
    category: 'medical-equipment',
    descriptionFr: 'Oxymètre précis pour mesure rapide de la saturation en oxygène.',
    descriptionAr: 'مقياس تأكسج دقيق لقياس سريع للتشبع بالأكسجين.',
    images: 2,
  },
  {
    titleFr: 'Oxymètre de Pouls de Doigt',
    titleAr: 'مقياس تأكسج الإصبع',
    price: 4200,
    category: 'medical-equipment',
    descriptionFr: 'Oxymètre compact à placer au doigt. Affichage clair.',
    descriptionAr: 'مقياس تأكسج صغير يوضع على الإصبع.',
    images: 2,
  },

  // Nebulizers
  {
    titleFr: 'Nébuliseur Médical Omron',
    titleAr: 'جهاز الاستنشاق الطبي',
    price: 7200,
    category: 'medical-equipment',
    descriptionFr: 'Nébuliseur efficace pour le traitement des affections respiratoires.',
    descriptionAr: 'جهاز استنشاق فعال لعلاج أمراض الجهاز التنفسي.',
    images: 2,
  },
  {
    titleFr: 'Nébuliseur à Maille Portable',
    titleAr: 'جهاز استنشاق شبكي محمول',
    price: 8500,
    category: 'medical-equipment',
    descriptionFr: 'Nébuliseur compact à technologie mesh.',
    descriptionAr: 'جهاز استنشاق مضغوط بتقنية شبكية.',
    images: 2,
  },

  // Wheelchairs
  {
    titleFr: 'Fauteuil Roulant Standard',
    titleAr: 'كرسي متحرك قياسي',
    price: 8500,
    category: 'orthopedic-products',
    descriptionFr: 'Fauteuil roulant robuste pour une mobilité quotidienne.',
    descriptionAr: 'كرسي متحرك قوي للتنقل اليومي.',
    images: 2,
  },

  // Crutches
  {
    titleFr: 'Béquilles Orthopédiques',
    titleAr: 'عكازات تقويمية',
    price: 3400,
    category: 'orthopedic-products',
    descriptionFr: 'Béquilles réglables pour un soutien optimal.',
    descriptionAr: 'عكازات قابلة للتعديل لدعم مثالي.',
    images: 2,
  },

  // Syringes
  {
    titleFr: 'Seringues Hypodermiques - Lot de 100',
    titleAr: 'محاقن تحت الجلد - علبة 100',
    price: 1500,
    category: 'medical-equipment',
    descriptionFr: 'Seringues stériles à usage unique.',
    descriptionAr: 'محاقن معقمة للاستخدام الواحد.',
    images: 2,
  },

  // Blood Pressure Monitors
  {
    titleFr: 'Tensiomètre Électronique',
    titleAr: 'جهاز قياس ضغط الدم الإلكتروني',
    price: 8900,
    category: 'medical-equipment',
    descriptionFr: 'Tensiomètre automatique précis avec détection des arythmies.',
    descriptionAr: 'جهاز قياس ضغط دم أوتوماتيكي دقيق.',
    images: 2,
  },

  // Thermometers
  {
    titleFr: 'Thermomètre Médical Digital',
    titleAr: 'مقياس حرارة طبي رقمي',
    price: 1800,
    category: 'medical-equipment',
    descriptionFr: 'Thermomètre digital précis pour une mesure rapide.',
    descriptionAr: 'مقياس حرارة رقمي دقيق.',
    images: 2,
  },

  // First Aid Kits
  {
    titleFr: 'Kit de Premiers Secours Complet',
    titleAr: 'مجموعة إسعافات أولية كاملة',
    price: 7200,
    category: 'hygiene',
    descriptionFr: 'Kit d\'urgence professionnel complet.',
    descriptionAr: 'مجموعة إسعافات أولية مهنية كاملة.',
    images: 2,
  },

  // Walkers
  {
    titleFr: 'Déambulateur Médical',
    titleAr: 'مشاية طبية',
    price: 5600,
    category: 'orthopedic-products',
    descriptionFr: 'Déambulateur stable et sécurisé.',
    descriptionAr: 'مشاية طبية ثابتة وآمنة.',
    images: 2,
  },

  // Oxygen Equipment
  {
    titleFr: 'Bouteille d\'Oxygène Médicale',
    titleAr: 'أسطوانة أكسجين طبية',
    price: 12000,
    category: 'medical-equipment',
    descriptionFr: 'Bouteille d\'oxygène portable pour usage médical.',
    descriptionAr: 'أسطوانة أكسجين محمولة للاستخدام الطبي.',
    images: 2,
  },

  // Medications
  {
    titleFr: 'Paracétamol 500mg - Boîte de 30 comprimés',
    titleAr: 'باراسيتامول 500 ملغ',
    price: 380,
    category: 'medications',
    descriptionFr: 'Antalgique et antipyrétique. Soulage la douleur.',
    descriptionAr: 'مسكن للألم وخافض للحرارة.',
    images: 2,
  },
  {
    titleFr: 'Ibuprofène 400mg - Boîte de 20 comprimés',
    titleAr: 'إيبوبروفين 400 ملغ',
    price: 450,
    category: 'medications',
    descriptionFr: 'Anti-inflammatoire non stéroïdien.',
    descriptionAr: 'مضاد التهاب غير ستيرويدي.',
    images: 2,
  },

  // Supplements
  {
    titleFr: 'Vitamine C 1000mg - 60 comprimés',
    titleAr: 'فيتامين سي 1000 ملغ',
    price: 1900,
    category: 'supplements',
    descriptionFr: 'Complément alimentaire à haute dose de vitamine C.',
    descriptionAr: 'مكمل غذائي بجرعة عالية من فيتامين سي.',
    images: 2,
  },
  {
    titleFr: 'Vitamine D3 2000 UI - 60 gélules',
    titleAr: 'فيتامين د3 2000 وحدة دولية',
    price: 1600,
    category: 'supplements',
    descriptionFr: 'Vitamine D3 pour la santé osseuse.',
    descriptionAr: 'فيتامين د3 لصحة العظام.',
    images: 2,
  },

  // Hygiene Products
  {
    titleFr: 'Masques Chirurgicaux FFP2 - Boîte de 50',
    titleAr: 'أقنعة جراحية FFP2',
    price: 2800,
    category: 'hygiene',
    descriptionFr: 'Masques de protection haute filtration.',
    descriptionAr: 'أقنعة حماية عالية الترشيح.',
    images: 2,
  },
  {
    titleFr: 'Gel Hydroalcoolique 500ml',
    titleAr: 'جل كحولي 500 مل',
    price: 380,
    category: 'hygiene',
    descriptionFr: 'Gel désinfectant pour les mains.',
    descriptionAr: 'جل مطهر لليدين.',
    images: 2,
  },

  // Medical Books
  {
    titleFr: 'Manuel de Médecine Interne - Harrison',
    titleAr: 'كتاب هاريسون للطب الباطني',
    price: 4500,
    category: 'medical-books',
    descriptionFr: 'Référence mondiale en médecine interne.',
    descriptionAr: 'المرجع العالمي في الطب الباطني.',
    images: 2,
  },
  {
    titleFr: 'Anatomie Humaine - Netter',
    titleAr: 'تشريح الإنسان - نتر',
    price: 5800,
    category: 'medical-books',
    descriptionFr: 'Atlas d\'anatomie le plus complet.',
    descriptionAr: 'أطلس التشريح الأكثر اكتمالاً.',
    images: 2,
  },
];

// ============================================================
// SELLER DATA
// ============================================================

const SELLER_PROFILES = [
  { firstName: 'Mohamed', lastName: 'Benali', email: 'pharmacie.benali@medical.dz' },
  { firstName: 'Fatima', lastName: 'Zerrouki', email: 'clinique.zerrouki@medical.dz' },
  { firstName: 'Karim', lastName: 'Boudiaf', email: 'medical.boudiaf@medical.dz' },
  { firstName: 'Nadia', lastName: 'Khelifi', email: 'sante.khelifi@medical.dz' },
  { firstName: 'Rachid', lastName: 'Mansouri', email: 'pharma.mansouri@medical.dz' },
  { firstName: 'Samira', lastName: 'Hamidi', email: 'medical.hamidi@medical.dz' },
  { firstName: 'Abdelkader', lastName: 'Brahimi', email: 'clinique.brahimi@medical.dz' },
  { firstName: 'Yasmine', lastName: 'Said', email: 'sante.said@medical.dz' },
];

// ============================================================
// CATEGORIES
// ============================================================

const MEDICAL_CATEGORIES = [
  { nameFr: 'Équipement Médical', nameAr: 'معدات طبية', slug: 'medical-equipment' },
  { nameFr: 'Médicaments', nameAr: 'أدوية', slug: 'medications' },
  { nameFr: 'Compléments Alimentaires', nameAr: 'مكملات غذائية', slug: 'supplements' },
  { nameFr: "Produits d'Hygiène", nameAr: 'منتجات النظافة', slug: 'hygiene' },
  { nameFr: 'Livres Médicaux', nameAr: 'كتب طبية', slug: 'medical-books' },
  { nameFr: 'Produits Orthopédiques', nameAr: 'منتجات العظام', slug: 'orthopedic-products' },
];

// ============================================================
// HELPERS
// ============================================================

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generatePhoneNumber(): string {
  return `055${String(randomInt(1000000, 9999999))}`;
}

// ============================================================
// ✅ NEW: Upload image to object storage
// ============================================================

async function uploadToStorage(
  imageBuffer: Buffer,
  originalName: string,
  mimeType: string
): Promise<{ fileId: string; storageKey: string; filePath: string; size: number } | null> {
  try {
    const storage = StorageFactory.getInstance();
    
    const result = await storage.upload(
      {
        buffer: imageBuffer,
        originalName: originalName,
        mimeType: mimeType,
        size: imageBuffer.length,
      },
      {
        path: 'public/products',
        isPublic: true,
        contentType: mimeType,
        cacheControl: 'public, max-age=31536000, immutable',
        metadata: {
          source: 'seed',
          category: 'medical-product',
        },
      }
    );

    return {
      fileId: result.id,
      storageKey: result.key,
      filePath: result.key,
      size: result.size,
    };
  } catch (error) {
    console.error('  ❌ Upload failed:', error);
    return null;
  }
}

// ============================================================
// CLEANUP
// ============================================================

async function deleteExistingSellers() {
  console.log('🗑️  Deleting existing seller accounts...');
  
  const sellerEmails = SELLER_PROFILES.map(p => p.email);
  
  for (const email of sellerEmails) {
    try {
      const user = await prisma.user.findUnique({ where: { email } });
      if (user) {
        await prisma.userWallet.deleteMany({ where: { userId: user.id } });
        await prisma.product.deleteMany({ where: { sellerId: user.id } });
        await prisma.user.delete({ where: { id: user.id } });
        console.log(`  ✅ Deleted: ${email}`);
      }
    } catch (error) {
      // Ignore
    }
  }
  console.log('✅ Existing sellers cleaned up');
}

async function clearEcommerceData() {
  console.log('🧹 Clearing existing e-commerce data...');
  
  const models = [
    'orderStatusHistory',
    'orderItem',
    'order',
    'productImage',
    'product',
    'category',
    'sellerDocument',
  ];
  
  for (const model of models) {
    try {
      await (prisma as any)[model].deleteMany();
      console.log(`  ✅ Cleared ${model}`);
    } catch (e) {
      // Ignore
    }
  }
  console.log('✅ E-commerce data cleared');
}

async function createMedicalCategories() {
  console.log('📂 Creating medical categories...');
  for (const cat of MEDICAL_CATEGORIES) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: {
        nameFr: cat.nameFr,
        nameAr: cat.nameAr,
        descriptionFr: `${cat.nameFr} - Produits médicaux de qualité`,
        descriptionAr: `${cat.nameAr} - منتجات طبية عالية الجودة`,
        isActive: true,
      },
      create: {
        nameFr: cat.nameFr,
        nameAr: cat.nameAr,
        slug: cat.slug,
        descriptionFr: `${cat.nameFr} - Produits médicaux de qualité`,
        descriptionAr: `${cat.nameAr} - منتجات طبية عالية الجودة`,
        isActive: true,
      },
    });
  }
  console.log(`  ✅ ${await prisma.category.count()} categories created`);
  return await prisma.category.findMany();
}

async function createMedicalSellers() {
  console.log('👨‍⚕️ Creating medical sellers...');
  const hashedPassword = await bcrypt.hash('seller123456', 12);
  const createdSellers = [];
  
  const wilayas = await prisma.wilaya.findMany();
  if (wilayas.length === 0) {
    console.error('❌ No wilayas found! Run main seed first.');
    return [];
  }
  
  for (const profile of SELLER_PROFILES) {
    try {
      const phone = generatePhoneNumber();
      
      const user = await prisma.user.create({
        data: {
          email: profile.email,
          password: hashedPassword,
          firstName: profile.firstName,
          lastName: profile.lastName,
          phone: phone,
          dateOfBirth: new Date(1980, randomInt(0, 11), randomInt(1, 28)),
          wilayaId: randomElement(wilayas).id,
          isVerified: true,
          canPost: true,
          trustPoints: 100,
          trustLevel: 3,
        },
      });
      
      await prisma.userWallet.create({
        data: {
          userId: user.id,
          credits: 100,
        },
      });
      
      createdSellers.push(user);
      console.log(`  ✅ ${profile.firstName} ${profile.lastName} (${profile.email})`);
    } catch (error: any) {
      if (error.code === 'P2002') {
        console.warn(`  ⚠️ Skipping ${profile.email} - exists`);
      }
    }
  }
  
  console.log(`  ✅ ${createdSellers.length} sellers created`);
  return createdSellers;
}

// ============================================================
// ✅ UPDATED: Seed products with object storage
// ============================================================

async function seedMedicalProducts(sellers: any[], categories: any[]) {
  console.log('🛍️ Seeding medical products with object storage...');
  
  if (sellers.length === 0 || categories.length === 0) {
    console.error('❌ No sellers or categories!');
    return [];
  }
  
  const availableImages = getAvailableImages();
  
  if (availableImages.length === 0) {
    console.error(`❌ No images found in: ${LOCAL_IMAGE_DIR}`);
    console.error('  Please add medical product images.');
    return [];
  }
  
  console.log(`  📸 Found ${availableImages.length} local images`);
  
  const createdProducts = [];
  let totalImages = 0;
  
  for (let i = 0; i < MEDICAL_PRODUCTS.length; i++) {
    const productData = MEDICAL_PRODUCTS[i];
    const category = categories.find(c => c.slug === productData.category);
    const seller = randomElement(sellers);
    
    if (!category) continue;
    
    const stock = randomInt(10, 200);
    const comparePrice = Math.round(productData.price * (1 + (randomInt(10, 30) / 100)));
    
    try {
      const product = await prisma.product.create({
        data: {
          sellerId: seller.id,
          categoryId: category.id,
          titleFr: productData.titleFr,
          titleAr: productData.titleAr,
          descriptionFr: productData.descriptionFr,
          descriptionAr: productData.descriptionAr,
          price: productData.price,
          comparePrice: comparePrice,
          stock: stock,
          sku: `MED-${String(i + 1).padStart(4, '0')}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`,
          status: 'ACTIVE',
          isApproved: true,
          approvedBy: 'system',
          approvedAt: new Date(),
          viewCount: randomInt(0, 1000),
          saleCount: randomInt(0, 50),
        },
      });
      
      createdProducts.push(product);
      
      const numImages = productData.images || 2;
      let imagesSaved = 0;
      
      // ✅ Upload each image to object storage
      for (let j = 0; j < numImages; j++) {
        const imageIndex = (i + j) % availableImages.length;
        const localFilename = availableImages[imageIndex];
        const sourcePath = path.join(LOCAL_IMAGE_DIR, localFilename);
        
        if (!fs.existsSync(sourcePath)) {
          console.warn(`  ⚠️ File not found: ${localFilename}`);
          continue;
        }
        
        try {
          const imageBuffer = fs.readFileSync(sourcePath);
          const ext = path.extname(localFilename);
          const mimeType = ext === '.png' ? 'image/png' 
            : ext === '.webp' ? 'image/webp' 
            : ext === '.gif' ? 'image/gif' 
            : 'image/jpeg';
          
          console.log(`  📸 Uploading ${localFilename} for: ${productData.titleFr.substring(0, 35)}...`);
          
          // ✅ Upload to object storage
          const uploadResult = await uploadToStorage(
            imageBuffer,
            localFilename,
            mimeType
          );
          
          if (uploadResult) {
            await prisma.productImage.create({
              data: {
                productId: product.id,
                fileId: uploadResult.fileId,
                storageKey: uploadResult.storageKey,
                filePath: uploadResult.filePath,
                fileName: localFilename,
                fileType: mimeType,
                fileSize: uploadResult.size,
                storageType: 'public',
                isPrimary: j === 0,
                sortOrder: j,
              },
            });
            imagesSaved++;
            totalImages++;
            console.log(`    ✅ Uploaded: ${uploadResult.filePath}`);
          } else {
            console.warn(`    ❌ Failed to upload: ${localFilename}`);
          }
        } catch (error) {
          console.warn(`    ❌ Error uploading ${localFilename}:`, error);
        }
      }
      
      console.log(`  ✅ ${productData.titleFr.substring(0, 40)}... - ${imagesSaved} images`);
      
      if ((i + 1) % 5 === 0 || i === MEDICAL_PRODUCTS.length - 1) {
        console.log(`  📊 Progress: ${i + 1}/${MEDICAL_PRODUCTS.length}`);
      }
    } catch (error) {
      console.warn(`  ❌ Failed: ${productData.titleFr}`);
      console.error(error);
    }
  }
  
  console.log(`  ✅ ${createdProducts.length} products with ${totalImages} images`);
  return createdProducts;
}

async function seedShippingCompanies() {
  console.log('🚚 Seeding shipping companies...');
  const companies = [
    { name: 'Yalidine Médical', trackingUrl: 'https://yalidine.com/track/' },
    { name: 'DHL Medical Express', trackingUrl: 'https://www.dhl.com/dz-en/home/tracking.html' },
    { name: 'EMS Médical', trackingUrl: 'https://www.poste.dz/ems/tracking' },
  ];
  
  for (const company of companies) {
    await prisma.shippingCompany.upsert({
      where: { name: company.name },
      update: { trackingUrl: company.trackingUrl, isActive: true },
      create: { name: company.name, trackingUrl: company.trackingUrl, isActive: true },
    });
  }
  console.log(`  ✅ ${await prisma.shippingCompany.count()} shipping companies ready`);
  return await prisma.shippingCompany.findMany();
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log('\n🏥 MEDICAL E-COMMERCE SEED');
  console.log('📸 USING OBJECT STORAGE (SeaweedFS/S3)');
  console.log('='.repeat(60));
  
  // Check available images
  const availableImages = getAvailableImages();
  console.log(`\n📸 Available images: ${availableImages.length}`);
  if (availableImages.length > 0) {
    console.log('   Files:', availableImages.join(', '));
  } else {
    console.error('❌ No images found in prisma/seed-assets/products/');
    console.log('\n📝 Please add medical product images to:');
    console.log('   prisma/seed-assets/products/');
    process.exit(1);
  }
  
  console.log('');
  
  await deleteExistingSellers();
  console.log('');
  
  await clearEcommerceData();
  console.log('');
  
  const categories = await createMedicalCategories();
  console.log('');
  
  const sellers = await createMedicalSellers();
  console.log('');
  
  if (sellers.length === 0) {
    console.error('❌ No sellers created. Exiting...');
    process.exit(1);
  }
  
  const products = await seedMedicalProducts(sellers, categories);
  console.log('');
  
  const shippingCompanies = await seedShippingCompanies();
  console.log('');
  
  console.log('='.repeat(60));
  console.log('✅ MEDICAL E-COMMERCE SEED COMPLETED!');
  console.log('='.repeat(60));
  console.log(`\n📊 SUMMARY:`);
  console.log(`  📂 Categories: ${categories.length}`);
  console.log(`  👨‍⚕️ Sellers: ${sellers.length}`);
  console.log(`  🛍️ Products: ${products.length}`);
  console.log(`  🖼️ Product Images: ${await prisma.productImage.count()}`);
  console.log(`  🚚 Shipping Companies: ${shippingCompanies.length}`);
  
  console.log('\n📋 SELLER CREDENTIALS:');
  for (const seller of sellers) {
    console.log(`  📧 ${seller.email} / password: seller123456`);
  }
  
  console.log('\n📋 PRODUCT CATEGORIES:');
  for (const category of categories) {
    const count = await prisma.product.count({ where: { categoryId: category.id } });
    console.log(`  📂 ${category.nameFr}: ${count} products`);
  }
  
  console.log('\n📸 IMAGES USED:');
  for (const img of availableImages) {
    console.log(`  🖼️ ${img}`);
  }
  
  console.log('\n✅ Done!');
}

main()
  .catch((e) => {
    console.error('❌ SEED ERROR:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    console.log('\n👋 Database connection closed.');
  });

