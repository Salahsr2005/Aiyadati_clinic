// backend/tests/integration/modules/appointment/v1/appointment.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { PrismaClient } from '@prisma/client';

let app: any;
let prisma: PrismaClient;
let pgContainer: StartedPostgreSqlContainer;

// Test data
let wilayaId: string;
let baladyaId: string;
let specialtyId: string;
let doctorId: string;
let clinicId: string;
let userId: string;
let userId2: string;
let slotId: string;
let guestPatientId: string;

// Users and tokens
let adminToken: string;
let adminUser: any;
let doctorToken: string;
let doctorUser: any;
let clinicToken: string;
let clinicUser: any;
let userToken: string;
let userUser: any;
let regularUserToken: string;
let regularUser: any;

const JWT_SECRET = process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

// Cleanup tracking
const cleanupIds = {
  appointments: [] as string[],
  slots: [] as string[],
  doctors: [] as string[],
  clinics: [] as string[],
  users: [] as string[],
  specialties: [] as string[],
  guestPatients: [] as string[],
  availabilities: [] as string[],
  breaks: [] as string[],
  configs: [] as string[],
  walletTransactions: [] as string[],
  wallets: [] as string[],
};

describe('Appointment Module - Integration Tests', () => {
  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    await prisma.$connect();

    const appModule = await import('../../../../../src/app');
    app = appModule.default;

    // ============================================================
    // Create test data
    // ============================================================

    // 1. Create Wilaya
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // 2. Create Baladya
    const baladya = await prisma.baladya.create({
      data: {
        nameFr: `Test Baladya ${crypto.randomUUID()}`,
        nameAr: `بلدية اختبار ${crypto.randomUUID()}`,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    baladyaId = baladya.id;

    // 3. Create Specialty
    const specialty = await prisma.specialty.create({
      data: {
        nameFr: `Cardiology ${crypto.randomUUID()}`,
        nameAr: `أمراض القلب ${crypto.randomUUID()}`,
        isActive: true,
      },
    });
    specialtyId = specialty.id;
    cleanupIds.specialties.push(specialty.id);

    // 4. Create Admin User
    const adminPassword = await bcrypt.hash('Admin123!', 12);
    adminUser = await prisma.admin.create({
      data: {
        email: `admin-${crypto.randomUUID()}@example.com`,
        password: adminPassword,
        name: 'Test Admin',
      },
    });
    cleanupIds.users.push(adminUser.id);

    adminToken = jwt.sign(
      { id: adminUser.id, email: adminUser.email, role: 'ADMIN', name: 'Test Admin' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 5. Create Regular User (patient)
    const userPassword = await bcrypt.hash('User123!', 12);
    userUser = await prisma.user.create({
      data: {
        email: `user-${crypto.randomUUID()}@example.com`,
        password: userPassword,
        firstName: 'Test',
        lastName: 'Patient',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        trustPoints: 5,
        trustLevel: 2,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    userId = userUser.id;
    cleanupIds.users.push(userUser.id);

    userToken = jwt.sign(
      { id: userUser.id, email: userUser.email, role: 'USER', name: 'Test Patient' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 6. Create Another User (for testing multiple patients)
    const userPassword2 = await bcrypt.hash('User123!', 12);
    const user2 = await prisma.user.create({
      data: {
        email: `user2-${crypto.randomUUID()}@example.com`,
        password: userPassword2,
        firstName: 'Test2',
        lastName: 'Patient2',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        trustPoints: 5,
        trustLevel: 2,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    userId2 = user2.id;
    cleanupIds.users.push(user2.id);

    regularUserToken = jwt.sign(
      { id: user2.id, email: user2.email, role: 'USER', name: 'Test2 Patient' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 7. Create Doctor
    const doctorPassword = await bcrypt.hash('Doctor123!', 12);
    doctorUser = await prisma.doctor.create({
      data: {
        email: `doctor-${crypto.randomUUID()}@example.com`,
        password: doctorPassword,
        firstNameFr: 'Test',
        firstNameAr: 'اختبار',
        lastNameFr: 'Doctor',
        lastNameAr: 'طبيب',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        isVerified: true,
        isSuspended: false,
        isRegistered: true,
        isCompleted: true,
        isAvailableForBooking: true,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    doctorId = doctorUser.id;
    cleanupIds.doctors.push(doctorUser.id);

    doctorToken = jwt.sign(
      {
        id: doctorUser.id,
        email: doctorUser.email,
        role: 'DOCTOR',
        name: `${doctorUser.firstNameFr} ${doctorUser.lastNameFr}`,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 8. Create Clinic
    const clinicPassword = await bcrypt.hash('Clinic123!', 12);
    clinicUser = await prisma.clinic.create({
      data: {
        nameFr: `Test Clinic ${crypto.randomUUID()}`,
        nameAr: `عيادة اختبار ${crypto.randomUUID()}`,
        email: `clinic-${crypto.randomUUID()}@example.com`,
        password: clinicPassword,
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
        wilaya: { connect: { id: wilayaId } },
        baladya: { connect: { id: baladyaId } },
      },
    });
    clinicId = clinicUser.id;
    cleanupIds.clinics.push(clinicUser.id);

    clinicToken = jwt.sign(
      {
        id: clinicUser.id,
        email: clinicUser.email,
        role: 'CLINIC',
        name: clinicUser.nameFr,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 9. Link Doctor to Clinic
    await prisma.clinicDoctor.create({
      data: {
        clinicId,
        doctorId,
        status: 'ACCEPTED',
        invitedBy: 'clinic',
        isActive: true,
      },
    });

    // 10. Create Doctor Config
    const config = await prisma.doctorConfig.create({
      data: {
        doctorId,
        slotDuration: 30,
        bufferTime: 5,
        maxPerSlot: 3,
      },
    });
    cleanupIds.configs.push(config.id);

    // 11. Create Doctor Availability
    const availability = await prisma.doctorAvailability.create({
      data: {
        doctorId,
        dayOfWeek: 'MONDAY',
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        endTime: new Date('1970-01-01T17:00:00.000Z'),
        isActive: true,
      },
    });
    cleanupIds.availabilities.push(availability.id);

    // 12. Create a base slot
    const date = new Date();
    const dayOfWeek = date.getDay();
    const daysUntilMonday = dayOfWeek === 1 ? 7 : (8 - dayOfWeek) % 7;
    date.setDate(date.getDate() + daysUntilMonday);

    const startTime = new Date(date);
    startTime.setHours(9, 0, 0, 0);
    const endTime = new Date(date);
    endTime.setHours(9, 30, 0, 0);

    const slot = await prisma.slot.create({
      data: {
        doctorId,
        clinicId,
        date,
        startTime,
        endTime,
        maxPatients: 3,
        status: 'available',
        slotKey: `${doctorId}:${date.toISOString().slice(0, 10)}:09:00:${clinicId}:base`,
      },
    });
    slotId = slot.id;
    cleanupIds.slots.push(slot.id);

    // 13. Create Guest Patient
    const guestPatient = await prisma.guestPatient.create({
      data: {
        firstName: 'Guest',
        lastName: 'Patient',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        createdBy: doctorId,
        createdByType: 'DOCTOR',
      },
    });
    guestPatientId = guestPatient.id;
    cleanupIds.guestPatients.push(guestPatient.id);

    // 14. Create Credit Price
    await prisma.creditPrice.create({
      data: {
        price: 10,
      },
    });

    // 15. Create User Wallet with credits
    const wallet = await prisma.userWallet.create({
      data: {
        userId,
        credits: 10,
      },
    });
    cleanupIds.wallets.push(wallet.id);

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    // Clean up appointments first
    if (cleanupIds.appointments.length > 0) {
      await prisma.appointment.deleteMany({
        where: { id: { in: cleanupIds.appointments } },
      });
      cleanupIds.appointments = [];
    }
    if (cleanupIds.walletTransactions.length > 0) {
      await prisma.creditTransaction.deleteMany({
        where: { id: { in: cleanupIds.walletTransactions } },
      });
      cleanupIds.walletTransactions = [];
    }
  });

  afterAll(async () => {
    // Clean up in correct order to avoid FK violations
    if (cleanupIds.appointments.length > 0) {
      await prisma.appointment.deleteMany({
        where: { id: { in: cleanupIds.appointments } },
      });
    }
    if (cleanupIds.slots.length > 0) {
      await prisma.slot.deleteMany({
        where: { id: { in: cleanupIds.slots } },
      });
    }
    if (cleanupIds.breaks.length > 0) {
      await prisma.doctorBreak.deleteMany({
        where: { id: { in: cleanupIds.breaks } },
      });
    }
    if (cleanupIds.availabilities.length > 0) {
      await prisma.doctorAvailability.deleteMany({
        where: { id: { in: cleanupIds.availabilities } },
      });
    }
    if (cleanupIds.configs.length > 0) {
      await prisma.doctorConfig.deleteMany({
        where: { id: { in: cleanupIds.configs } },
      });
    }
    if (cleanupIds.guestPatients.length > 0) {
      await prisma.guestPatient.deleteMany({
        where: { id: { in: cleanupIds.guestPatients } },
      });
    }
    if (cleanupIds.wallets.length > 0) {
      await prisma.userWallet.deleteMany({
        where: { id: { in: cleanupIds.wallets } },
      });
    }
    if (cleanupIds.specialties.length > 0) {
      await prisma.doctorSpecialty.deleteMany({
        where: { specialtyId: { in: cleanupIds.specialties } },
      });
      await prisma.specialty.deleteMany({
        where: { id: { in: cleanupIds.specialties } },
      });
    }
    if (cleanupIds.doctors.length > 0) {
      await prisma.doctor.deleteMany({
        where: { id: { in: cleanupIds.doctors } },
      });
    }
    if (cleanupIds.clinics.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: cleanupIds.clinics } },
      });
    }
    if (cleanupIds.users.length > 0) {
      await prisma.admin.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
      await prisma.user.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
    }
    await prisma.doctor.deleteMany({ where: { wilayaId } });
    await prisma.user.deleteMany({ where: { wilayaId } });
    await prisma.clinic.deleteMany({ where: { wilayaId } });
    await prisma.baladya.deleteMany({ where: { id: baladyaId } });
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const generatePhone = (): string => {
    const prefixes = ['05', '06', '07'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const rest = Math.floor(10000000 + Math.random() * 89999999).toString();
    return prefix + rest;
  };

  // ============================================================
  // ✅ FIXED: Helper function to create a new slot with truly unique time
  // ============================================================

  const createTestSlot = async (overrides: any = {}) => {
    const uniqueSeed = Date.now() % 1000 + Math.random() * 1000;
    
    // ✅ If date is provided directly, use it
    let date = overrides.date ? new Date(overrides.date) : new Date();
    
    if (!overrides.date) {
      const dayOfWeek = date.getDay();
      const daysUntilMonday = dayOfWeek === 1 ? 7 : (8 - dayOfWeek) % 7;
      date.setDate(date.getDate() + daysUntilMonday + (overrides.weekOffset || 0) + Math.floor(uniqueSeed / 500));
    }

    const baseHour = 9 + (Math.floor(uniqueSeed / 60) % 8);
    const baseMinute = Math.floor(uniqueSeed % 60);
    const startHour = overrides.startHour !== undefined ? overrides.startHour : baseHour;
    const startMinute = overrides.startMinute !== undefined ? overrides.startMinute : baseMinute;

    const startTime = new Date(date);
    startTime.setHours(startHour, startMinute, 0, 0);
    const endTime = new Date(date);
    endTime.setHours(startHour + 1, startMinute, 0, 0);

    const uniqueId = Date.now().toString(36) + Math.random().toString(36).substring(2, 10);
    const slotKey = `${overrides.doctorId || doctorId}:${date.toISOString().slice(0, 10)}:${String(startHour).padStart(2, '0')}${String(startMinute).padStart(2, '0')}:${overrides.clinicId || clinicId}:${uniqueId}`;

    const slot = await prisma.slot.create({
      data: {
        doctorId: overrides.doctorId || doctorId,
        clinicId: overrides.clinicId !== undefined ? overrides.clinicId : clinicId,
        date,
        startTime,
        endTime,
        maxPatients: overrides.maxPatients || 3,
        status: overrides.status || 'available',
        slotKey,
      },
    });
    cleanupIds.slots.push(slot.id);
    return slot;
  };

  // ============================================================
  // Helper to create a test appointment
  // ============================================================

  const createTestAppointment = async (overrides: any = {}) => {
    const appointment = await prisma.appointment.create({
      data: {
        slotId: overrides.slotId || slotId,
        doctorId: overrides.doctorId || doctorId,
        patientId: overrides.patientId || userId,
        patientType: overrides.patientType || 'REGISTERED',
        status: overrides.status || 'PENDING',
        paymentMethod: overrides.paymentMethod || 'CREDIT',
        createdBy: overrides.createdBy || userId,
        createdByType: overrides.createdByType || 'user',
        type: overrides.type || 'IN_PERSON',
        clinicId: overrides.clinicId || null,
        notes: overrides.notes || null,
        guestPatientId: overrides.guestPatientId || null,
        ...overrides,
      },
    });
    cleanupIds.appointments.push(appointment.id);
    return appointment;
  };

  // ============================================================
  // Tests - Config
  // ============================================================

  describe('Doctor Config', () => {
    describe('GET /api/v1/appointment/v1/doctor/config', () => {
      it('should get doctor config', async () => {
        const response = await request(app)
          .get('/api/v1/appointment/v1/doctor/config')
          .set('Authorization', `Bearer ${doctorToken}`);

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.data).toMatchObject({
          doctorId,
          slotDuration: 30,
          bufferTime: 5,
          maxPerSlot: 3,
        });
      });

      it('should return 401 without token', async () => {
        const response = await request(app)
          .get('/api/v1/appointment/v1/doctor/config');

        expect(response.status).toBe(401);
      });

      it('should return 403 for non-doctor user', async () => {
        const response = await request(app)
          .get('/api/v1/appointment/v1/doctor/config')
          .set('Authorization', `Bearer ${userToken}`);

        expect(response.status).toBe(403);
      });
    });

    describe('PUT /api/v1/appointment/v1/doctor/config', () => {
      it('should update doctor config', async () => {
        const response = await request(app)
          .put('/api/v1/appointment/v1/doctor/config')
          .set('Authorization', `Bearer ${doctorToken}`)
          .send({
            slotDuration: 45,
            bufferTime: 10,
            maxPerSlot: 2,
          });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.data).toMatchObject({
          slotDuration: 45,
          bufferTime: 10,
          maxPerSlot: 2,
        });
      });

      it('should reject invalid config', async () => {
        const response = await request(app)
          .put('/api/v1/appointment/v1/doctor/config')
          .set('Authorization', `Bearer ${doctorToken}`)
          .send({
            slotDuration: 200,
            bufferTime: -5,
          });

        expect(response.status).toBe(422);
        expect(response.body.errors).toBeDefined();
      });
    });
  });

  // ============================================================
  // Tests - Slots (Public)
  // ============================================================

  describe('GET /api/v1/appointment/v1/slots/:doctorId', () => {
    it('should get available slots for a doctor', async () => {
      const response = await request(app)
        .get(`/api/v1/appointment/v1/slots/${doctorId}`)
        .query({ date: new Date().toISOString().slice(0, 10) });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should return 422 when date is missing', async () => {
      const response = await request(app)
        .get(`/api/v1/appointment/v1/slots/${doctorId}`);

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  // ============================================================
  // Tests - Doctor Slots (Authenticated)
  // ============================================================

  describe('GET /api/v1/appointment/v1/doctor/slots', () => {
    it('should get doctor slots', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/doctor/slots')
        .set('Authorization', `Bearer ${doctorToken}`)
        .query({ date: new Date().toISOString().slice(0, 10) });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/doctor/slots');

      expect(response.status).toBe(401);
    });
  });

  // ============================================================
  // Tests - Generate Slots
  // ============================================================

  describe('POST /api/v1/appointment/v1/doctor/slots/generate', () => {
    it('should generate slots for a doctor', async () => {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() + 14);
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + 7);

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/generate')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          startDate: startDate.toISOString().slice(0, 10),
          endDate: endDate.toISOString().slice(0, 10),
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should reject without required fields', async () => {
      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/generate')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({});

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  // ============================================================
  // Tests - Quick Slot
  // ============================================================

  describe('POST /api/v1/appointment/v1/doctor/slots/quick', () => {
    it('should add a quick slot', async () => {
      const date = new Date();
      const dayOfWeek = date.getDay();
      const daysUntilMonday = dayOfWeek === 1 ? 7 : (8 - dayOfWeek) % 7;
      date.setDate(date.getDate() + daysUntilMonday + 14);

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/quick')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          date: date.toISOString().slice(0, 10),
          startTime: '14:00',
          endTime: '14:30',
          maxPatients: 2,
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('id');
      expect(['14:00', '13:00']).toContain(response.body.data.startTime);
      expect(['14:30', '13:30']).toContain(response.body.data.endTime);
      expect(response.body.data.maxPatients).toBe(2);

      if (response.body.data.id) {
        cleanupIds.slots.push(response.body.data.id);
      }
    });

    it('should reject invalid time format', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 7);

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/quick')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          date: date.toISOString().slice(0, 10),
          startTime: 'invalid',
          endTime: '14:30',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });

    it('should reject when start time >= end time', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 7);

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/quick')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          date: date.toISOString().slice(0, 10),
          startTime: '15:00',
          endTime: '14:30',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  // ============================================================
  // Tests - Book Appointment (User)
  // ============================================================

  describe('POST /api/v1/appointment/v1/book', () => {
    it('should book an appointment as user with credits', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          patientId: userId,
          type: 'IN_PERSON',
          paymentMethod: 'CREDIT',
          notes: 'Test appointment',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toMatchObject({
        slotId: slot.id,
        patientId: userId,
        patientType: 'REGISTERED',
        status: 'PENDING',
        paymentMethod: 'CREDIT',
        notes: 'Test appointment',
      });
      expect(response.body.data).toHaveProperty('id');

      if (response.body.data.id) {
        cleanupIds.appointments.push(response.body.data.id);
      }
    });

    it('should book an appointment with ON_SITE payment', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          patientId: userId,
          type: 'IN_PERSON',
          paymentMethod: 'ON_SITE',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.paymentMethod).toBe('ON_SITE');

      if (response.body.data.id) {
        cleanupIds.appointments.push(response.body.data.id);
      }
    });

    it('should book an appointment with guest patient', async () => {
      const slot = await createTestSlot();
      const guestPhone = generatePhone();

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          slotId: slot.id,
          guestPatient: {
            firstName: 'Guest',
            lastName: 'Booking',
            phone: guestPhone,
            email: 'guest@example.com',
          },
          type: 'IN_PERSON',
          paymentMethod: 'ON_SITE',
          notes: 'Guest booking',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.patientType).toBe('GUEST');
      expect(response.body.data.paymentMethod).toBe('ON_SITE');
      expect(response.body.data.guestPatientId).toBeDefined();

      if (response.body.data.id) {
        cleanupIds.appointments.push(response.body.data.id);
      }
    });

    it('should reject booking without patientId or guestPatient', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          type: 'IN_PERSON',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });

    it('should reject booking with both patientId and guestPatient', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          patientId: userId,
          guestPatient: {
            firstName: 'Guest',
            lastName: 'Patient',
            phone: generatePhone(),
          },
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });

    it('should reject booking without slotId', async () => {
      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          patientId: userId,
          type: 'IN_PERSON',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });

    it('should reject booking when slot is full', async () => {
      const slot = await createTestSlot({ maxPatients: 1 });

      const firstResponse = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          patientId: userId,
        });

      expect(firstResponse.status).toBe(201);
      if (firstResponse.body.data.id) {
        cleanupIds.appointments.push(firstResponse.body.data.id);
      }

      const secondResponse = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${regularUserToken}`)
        .send({
          slotId: slot.id,
          patientId: userId2,
        });

      expect(secondResponse.status).toBe(409);
      expect(secondResponse.body.message).toContain('Slot is full');
    });

    it('should reject booking when doctor is not available for booking', async () => {
      const unavailableDoctor = await prisma.doctor.create({
        data: {
          email: `unavailable-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstNameFr: 'Unavailable',
          firstNameAr: 'غير متاح',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isRegistered: true,
          isCompleted: true,
          isAvailableForBooking: false,
          messageForUser: 'On vacation until September',
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.doctors.push(unavailableDoctor.id);

      await prisma.doctorAvailability.create({
        data: {
          doctorId: unavailableDoctor.id,
          dayOfWeek: 'MONDAY',
          startTime: new Date('1970-01-01T08:00:00.000Z'),
          endTime: new Date('1970-01-01T17:00:00.000Z'),
          isActive: true,
        },
      });

      const date = new Date();
      const dayOfWeek = date.getDay();
      const daysUntilMonday = dayOfWeek === 1 ? 7 : (8 - dayOfWeek) % 7;
      date.setDate(date.getDate() + daysUntilMonday + 7);

      const slot = await prisma.slot.create({
        data: {
          doctorId: unavailableDoctor.id,
          clinicId,
          date,
          startTime: new Date(date.setHours(9, 0, 0, 0)),
          endTime: new Date(date.setHours(10, 0, 0, 0)),
          maxPatients: 3,
          status: 'available',
          slotKey: `${unavailableDoctor.id}:${date.toISOString().slice(0, 10)}:09:00:${clinicId}:${Date.now().toString(36)}`,
        },
      });
      cleanupIds.slots.push(slot.id);

      const response = await request(app)
        .post('/api/v1/appointment/v1/book')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          slotId: slot.id,
          patientId: userId,
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('On vacation until September');
    });
  });

  // ============================================================
  // Tests - Clinic Book
  // ============================================================

  describe('POST /api/v1/appointment/v1/clinic/book', () => {
    it('should book an appointment as clinic', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .post('/api/v1/appointment/v1/clinic/book')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({
          slotId: slot.id,
          patientId: userId2,
          type: 'IN_PERSON',
          paymentMethod: 'ON_SITE',
          notes: 'Clinic booking',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toMatchObject({
        slotId: slot.id,
        patientId: userId2,
        clinicId,
        createdByType: 'clinic',
        status: 'PENDING',
        notes: 'Clinic booking',
      });

      if (response.body.data.id) {
        cleanupIds.appointments.push(response.body.data.id);
      }
    });

    it('should reject clinic booking for slot not in clinic', async () => {
      const date = new Date();
      const dayOfWeek = date.getDay();
      const daysUntilMonday = dayOfWeek === 1 ? 7 : (8 - dayOfWeek) % 7;
      date.setDate(date.getDate() + daysUntilMonday + 7);

      const slot = await prisma.slot.create({
        data: {
          doctorId,
          clinicId: null,
          date,
          startTime: new Date(date.setHours(10, 0, 0, 0)),
          endTime: new Date(date.setHours(11, 0, 0, 0)),
          maxPatients: 3,
          status: 'available',
          slotKey: `${doctorId}:${date.toISOString().slice(0, 10)}:10:00:none:${Date.now().toString(36)}`,
        },
      });
      cleanupIds.slots.push(slot.id);

      const response = await request(app)
        .post('/api/v1/appointment/v1/clinic/book')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({
          slotId: slot.id,
          patientId: userId2,
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('does not belong to your clinic');
    });
  });

  // ============================================================
  // Tests - Confirm Appointment
  // ============================================================

  describe('POST /api/v1/appointment/v1/appointments/:id/confirm', () => {
    it('should confirm a pending appointment as doctor', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });

      const response = await request(app)
        .post(`/api/v1/appointment/v1/appointments/${appointment.id}/confirm`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ notes: 'Confirmed by doctor' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CONFIRMED');
      expect(response.body.data.confirmedBy).toBe(doctorId);
    });

    it('should confirm a pending appointment as clinic', async () => {
      const appointment = await createTestAppointment({
        status: 'PENDING',
        clinicId,
        doctorId,
      });

      const response = await request(app)
        .post(`/api/v1/appointment/v1/appointments/${appointment.id}/confirm`)
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({ notes: 'Confirmed by clinic' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CONFIRMED');
      expect(response.body.data.confirmedBy).toBe(clinicId);
    });

    it('should reject confirming appointment that is not PENDING', async () => {
      const appointment = await createTestAppointment({ status: 'CONFIRMED' });

      const response = await request(app)
        .post(`/api/v1/appointment/v1/appointments/${appointment.id}/confirm`)
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Cannot confirm appointment with status CONFIRMED');
    });

    it('should reject confirming appointment as patient', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });

      const response = await request(app)
        .post(`/api/v1/appointment/v1/appointments/${appointment.id}/confirm`)
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Update Status
  // ============================================================

  describe('PATCH /api/v1/appointment/v1/:id/status', () => {
    it('should cancel appointment as patient (>= 3 days before - refund)', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 5);
      const slot = await createTestSlot({
        date,
        startHour: 9,
        status: 'available',
      });

      const appointment = await createTestAppointment({
        slotId: slot.id,
        status: 'PENDING',
        paymentMethod: 'CREDIT',
      });

      const initialWallet = await prisma.userWallet.findUnique({
        where: { userId },
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          status: 'CANCELLED',
          cancelReason: 'Patient changed mind',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CANCELLED');
      expect(response.body.data.cancelReason).toBe('Patient changed mind');

      const wallet = await prisma.userWallet.findUnique({
        where: { userId },
      });
      expect(wallet?.credits).toBe(initialWallet!.credits + 1);
    });

    it('should cancel appointment as patient (< 3 days before - NO refund)', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 1);
      const slot = await createTestSlot({
        date,
        startHour: 9,
        status: 'available',
      });

      const appointment = await createTestAppointment({
        slotId: slot.id,
        status: 'PENDING',
        paymentMethod: 'CREDIT',
      });

      const initialWallet = await prisma.userWallet.findUnique({
        where: { userId },
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          status: 'CANCELLED',
          cancelReason: 'Last minute cancellation',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CANCELLED');

      const wallet = await prisma.userWallet.findUnique({
        where: { userId },
      });
      expect(wallet?.credits).toBe(initialWallet!.credits);
    });

    it('should cancel appointment as provider - always refund', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 1);
      const slot = await createTestSlot({
        date,
        startHour: 9,
        status: 'available',
      });

      const appointment = await createTestAppointment({
        slotId: slot.id,
        status: 'PENDING',
        paymentMethod: 'CREDIT',
      });

      const initialWallet = await prisma.userWallet.findUnique({
        where: { userId },
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          status: 'CANCELLED',
          cancelReason: 'Provider unavailable',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CANCELLED');

      const wallet = await prisma.userWallet.findUnique({
        where: { userId },
      });
      expect(wallet?.credits).toBe(initialWallet!.credits + 1);
    });

    it('should mark appointment as CONFIRMED (doctor)', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ status: 'CONFIRMED' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('CONFIRMED');
    });

    it('should mark appointment as IN_PROGRESS', async () => {
      const appointment = await createTestAppointment({ status: 'CONFIRMED' });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ status: 'IN_PROGRESS' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('IN_PROGRESS');
    });

    // ✅ FIXED: Use a fresh user for the COMPLETED test
    it('should mark appointment as COMPLETED', async () => {
      // Create a fresh user with known trust points
      const freshUserPassword = await bcrypt.hash('User123!', 12);
      const freshUser = await prisma.user.create({
        data: {
          email: `fresh-complete-${crypto.randomUUID()}@example.com`,
          password: freshUserPassword,
          firstName: 'Fresh',
          lastName: 'Complete',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          dateOfBirth: new Date('1990-01-01'),
          isVerified: true,
          isSuspended: false,
          trustPoints: 5,
          trustLevel: 2,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(freshUser.id);

      // Create wallet for fresh user
      const freshWallet = await prisma.userWallet.create({
        data: {
          userId: freshUser.id,
          credits: 10,
        },
      });
      cleanupIds.wallets.push(freshWallet.id);

      // Get token for fresh user
      const freshUserToken = jwt.sign(
        { id: freshUser.id, email: freshUser.email, role: 'USER', name: 'Fresh Complete' },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      // Create appointment with fresh user
      const appointment = await createTestAppointment({
        status: 'IN_PROGRESS',
        paymentMethod: 'CREDIT',
        creditPriceAtBooking: 10,
        createdByType: 'user',
        patientId: freshUser.id,
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ status: 'COMPLETED' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('COMPLETED');

      // Check trust points updated (started with 5, +1 for COMPLETED)
      const user = await prisma.user.findUnique({
        where: { id: freshUser.id },
      });
      expect(user?.trustPoints).toBe(6);

      // Check provider earnings created
      const earnings = await prisma.providerEarning.findMany({
        where: { appointmentId: appointment.id },
      });
      expect(earnings.length).toBeGreaterThan(0);
    });

    it('should mark appointment as NO_SHOW', async () => {
      // ✅ Create a fresh user with known trust points for this test
      const freshUserPassword = await bcrypt.hash('User123!', 12);
      const freshUser = await prisma.user.create({
        data: {
          email: `fresh-no-show-${crypto.randomUUID()}@example.com`,
          password: freshUserPassword,
          firstName: 'FreshNoShow',
          lastName: 'User',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          dateOfBirth: new Date('1990-01-01'),
          isVerified: true,
          isSuspended: false,
          trustPoints: 5,
          trustLevel: 2,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(freshUser.id);

      // Create wallet for fresh user
      const freshWallet = await prisma.userWallet.create({
        data: {
          userId: freshUser.id,
          credits: 10,
        },
      });
      cleanupIds.wallets.push(freshWallet.id);

      // Get token for fresh user
      const freshUserToken = jwt.sign(
        { id: freshUser.id, email: freshUser.email, role: 'USER', name: 'Fresh NoShow User' },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const appointment = await createTestAppointment({
        status: 'CONFIRMED',
        paymentMethod: 'CREDIT',
        patientId: freshUser.id,
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ status: 'NO_SHOW' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.status).toBe('NO_SHOW');

      // Check trust points updated (started with 5, -2 for NO_SHOW)
      const user = await prisma.user.findUnique({
        where: { id: freshUser.id },
      });
      expect(user?.trustPoints).toBe(3);
    });

    it('should reject invalid status transition', async () => {
      const appointment = await createTestAppointment({ status: 'COMPLETED' });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ status: 'NO_SHOW' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Cannot transition');
    });

    it('should reject updating appointment as wrong user', async () => {
      const appointment = await createTestAppointment({
        status: 'PENDING',
        patientId: userId2,
      });

      const response = await request(app)
        .patch(`/api/v1/appointment/v1/${appointment.id}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ status: 'CANCELLED' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Not your appointment');
    });
  });

  // ============================================================
  // Tests - Get Appointments
  // ============================================================

  describe('GET /api/v1/appointment/v1/me', () => {
    it('should get user appointments', async () => {
      await createTestAppointment({ patientId: userId });

      const response = await request(app)
        .get('/api/v1/appointment/v1/me')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/me');

      expect(response.status).toBe(401);
    });
  });

  describe('GET /api/v1/appointment/v1/doctor/appointments', () => {
    it('should get doctor appointments', async () => {
      await createTestAppointment({ doctorId });

      const response = await request(app)
        .get('/api/v1/appointment/v1/doctor/appointments')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should filter doctor appointments by date', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/doctor/appointments')
        .set('Authorization', `Bearer ${doctorToken}`)
        .query({ date: new Date().toISOString().slice(0, 10) });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });

  describe('GET /api/v1/appointment/v1/clinic/appointments', () => {
    it('should get clinic appointments', async () => {
      await createTestAppointment({ clinicId });

      const response = await request(app)
        .get('/api/v1/appointment/v1/clinic/appointments')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should filter clinic appointments by date', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/clinic/appointments')
        .set('Authorization', `Bearer ${clinicToken}`)
        .query({ date: new Date().toISOString().slice(0, 10) });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });

  describe('GET /api/v1/appointment/v1/admin/appointments', () => {
    it('should get all appointments as admin', async () => {
      await createTestAppointment();

      const response = await request(app)
        .get('/api/v1/appointment/v1/admin/appointments')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should filter admin appointments by status', async () => {
      await createTestAppointment({ status: 'CONFIRMED' });

      const response = await request(app)
        .get('/api/v1/appointment/v1/admin/appointments')
        .set('Authorization', `Bearer ${adminToken}`)
        .query({ status: 'CONFIRMED' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      response.body.data.forEach((app: any) => {
        expect(app.status).toBe('CONFIRMED');
      });
    });

    it('should return 403 for non-admin user', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/admin/appointments')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Guest Patient Management
  // ============================================================

  describe('GET /api/v1/appointment/v1/guest-patients', () => {
    it('should get guest patients created by doctor', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/guest-patients')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should return 403 for non-doctor/clinic user', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/guest-patients')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(403);
    });
  });

  describe('POST /api/v1/appointment/v1/guest-patients', () => {
    it('should create a guest patient', async () => {
      const phone = generatePhone();

      const response = await request(app)
        .post('/api/v1/appointment/v1/guest-patients')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          firstName: 'New',
          lastName: 'Guest',
          phone,
          email: 'newguest@example.com',
          notes: 'Test guest creation',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toMatchObject({
        firstName: 'New',
        lastName: 'Guest',
        phone,
        email: 'newguest@example.com',
        createdBy: doctorId,
        createdByType: 'DOCTOR',
        notes: 'Test guest creation',
      });

      if (response.body.data.id) {
        cleanupIds.guestPatients.push(response.body.data.id);
      }
    });

    it('should reject guest patient without required fields', async () => {
      const response = await request(app)
        .post('/api/v1/appointment/v1/guest-patients')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          firstName: 'Incomplete',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  // ============================================================
  // ✅ FIXED: Guest Patient Search
  // ============================================================

  describe('GET /api/v1/appointment/v1/guest-patients/search', () => {
    it('should search guest patients by name', async () => {
      // Create a unique guest patient to search for
      const uniqueName = `SearchTest${Date.now()}`;
      const phone = generatePhone();

      const createResponse = await request(app)
        .post('/api/v1/appointment/v1/guest-patients')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          firstName: uniqueName,
          lastName: 'Search',
          phone,
        });

      expect(createResponse.status).toBe(201);
      if (createResponse.body.data.id) {
        cleanupIds.guestPatients.push(createResponse.body.data.id);
      }

      // Now search for it
      const response = await request(app)
        .get('/api/v1/appointment/v1/guest-patients/search')
        .set('Authorization', `Bearer ${doctorToken}`)
        .query({ q: uniqueName });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.data.length).toBeGreaterThan(0);
      expect(response.body.data[0].firstName).toBe(uniqueName);
    });

    it('should reject search with query < 2 characters', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/guest-patients/search')
        .set('Authorization', `Bearer ${doctorToken}`)
        .query({ q: 'G' });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  describe('GET /api/v1/appointment/v1/guest-patients/:id', () => {
    it('should get a specific guest patient', async () => {
      const response = await request(app)
        .get(`/api/v1/appointment/v1/guest-patients/${guestPatientId}`)
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.id).toBe(guestPatientId);
    });

    it('should return 404 for non-existent guest patient', async () => {
      const response = await request(app)
        .get('/api/v1/appointment/v1/guest-patients/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(404);
      expect(response.body.message).toContain('Guest patient not found');
    });
  });

  describe('PATCH /api/v1/appointment/v1/guest-patients/:id', () => {
    it('should update a guest patient', async () => {
      const response = await request(app)
        .patch(`/api/v1/appointment/v1/guest-patients/${guestPatientId}`)
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          firstName: 'Updated',
          lastName: 'Guest',
          notes: 'Updated notes',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.firstName).toBe('Updated');
      expect(response.body.data.lastName).toBe('Guest');
      expect(response.body.data.notes).toBe('Updated notes');
    });
  });

  // ============================================================
  // Tests - Slot Automation
  // ============================================================

  describe('POST /api/v1/appointment/v1/doctor/slots/automation', () => {
    it('should enable slot automation', async () => {
      await prisma.slotGenerationRule.deleteMany({
        where: { doctorId },
      });

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/automation')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toMatchObject({
        doctorId,
        frequency: 'WEEKLY',
        bookingWindowDays: 30,
        enabled: true,
      });
    });

    it('should reject automation with invalid frequency', async () => {
      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/automation')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          frequency: 'INVALID',
          bookingWindowDays: 30,
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  describe('GET /api/v1/appointment/v1/doctor/slots/automation', () => {
    it('should get automation status', async () => {
      await prisma.slotGenerationRule.upsert({
        where: { doctorId },
        update: {
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          enabled: true,
          nextRunAt: new Date(),
        },
        create: {
          doctorId,
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          nextRunAt: new Date(),
        },
      });

      const response = await request(app)
        .get('/api/v1/appointment/v1/doctor/slots/automation')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeDefined();
    });
  });

  // ============================================================
  // ✅ FIXED: DELETE automation
  // ============================================================

  describe('DELETE /api/v1/appointment/v1/doctor/slots/automation', () => {
    it('should disable slot automation', async () => {
      // First ensure automation rule exists by enabling it
      const enableResponse = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/automation')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
        });

      expect(enableResponse.status).toBe(200);
      expect(enableResponse.body.success).toBe(true);

      // Now disable it
      const response = await request(app)
        .delete('/api/v1/appointment/v1/doctor/slots/automation')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });

  // ============================================================
  // Tests - Cancel Slot
  // ============================================================

  describe('DELETE /api/v1/appointment/v1/doctor/slots/:id', () => {
    it('should cancel a slot as doctor', async () => {
      const slot = await createTestSlot();

      const response = await request(app)
        .delete(`/api/v1/appointment/v1/doctor/slots/${slot.id}`)
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should return 404 for non-existent slot', async () => {
      const response = await request(app)
        .delete('/api/v1/appointment/v1/doctor/slots/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Cancel Slots By Date
  // ============================================================

  describe('POST /api/v1/appointment/v1/doctor/slots/cancel-date', () => {
    it('should cancel slots by date as doctor', async () => {
      const date = new Date();
      date.setDate(date.getDate() + 10);

      const response = await request(app)
        .post('/api/v1/appointment/v1/doctor/slots/cancel-date')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          date: date.toISOString().slice(0, 10),
          reason: 'Holiday',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('cancelledCount');
    });
  });
});