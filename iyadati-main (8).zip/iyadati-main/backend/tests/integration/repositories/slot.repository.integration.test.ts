import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('SlotRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let slotRepository: typeof import('../../../src/repositories/slot.repository')['slotRepository'];
  let wilayaId: string;
  let doctorId: string;
  let clinicId: string;
  let roomId: string;
  const slotIds: string[] = [];
  const appointmentIds: string[] = [];
  const doctorIds: string[] = [];
  const clinicIds: string[] = [];
  const roomIds: string[] = [];
  const walletIds: string[] = [];
  const userIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ slotRepository } = await import('../../../src/repositories/slot.repository'));

    await prisma.$connect();

    // Create test data dependencies
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // Create a test doctor
    const doctor = await prisma.doctor.create({
      data: {
        email: `doctor-${crypto.randomUUID()}@example.com`,
        password: 'hashed-password',
        firstNameFr: 'Test',
        firstNameAr: 'اختبار',
        lastNameFr: 'Doctor',
        lastNameAr: 'طبيب',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        wilaya: { connect: { id: wilayaId } },
        isVerified: true,
        isSuspended: false,
        isRegistered: true,
        isCompleted: true,
        isAvailableForBooking: true,
      },
    });
    doctorId = doctor.id;
    doctorIds.push(doctor.id);

    // Create a test clinic
    const clinic = await prisma.clinic.create({
      data: {
        nameFr: `Test Clinic ${crypto.randomUUID()}`,
        nameAr: `عيادة اختبار ${crypto.randomUUID()}`,
        email: `clinic-${crypto.randomUUID()}@example.com`,
        password: 'hashed-password',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        wilaya: { connect: { id: wilayaId } },
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
      },
    });
    clinicId = clinic.id;
    clinicIds.push(clinic.id);

    // Create a test room
    const room = await prisma.clinicRoom.create({
      data: {
        clinicId: clinicId,
        name: 'Test Room',
        isActive: true,
      },
    });
    roomId = room.id;
    roomIds.push(room.id);

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    // Clean up in reverse order to avoid FK violations
    if (appointmentIds.length > 0) {
      await prisma.appointment.deleteMany({
        where: { id: { in: appointmentIds } },
      });
      appointmentIds.length = 0;
    }
    if (walletIds.length > 0) {
      await prisma.creditTransaction.deleteMany({
        where: { walletId: { in: walletIds } },
      });
      await prisma.userWallet.deleteMany({
        where: { id: { in: walletIds } },
      });
      walletIds.length = 0;
    }
    if (userIds.length > 0) {
      await prisma.user.deleteMany({
        where: { id: { in: userIds } },
      });
      userIds.length = 0;
    }
    if (slotIds.length > 0) {
      await prisma.slot.deleteMany({
        where: { id: { in: slotIds } },
      });
      slotIds.length = 0;
    }
  });

  afterAll(async () => {
    // Clean up test data
    if (roomIds.length > 0) {
      await prisma.clinicRoom.deleteMany({
        where: { id: { in: roomIds } },
      });
    }
    if (clinicIds.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: clinicIds } },
      });
    }
    if (doctorIds.length > 0) {
      await prisma.doctor.deleteMany({
        where: { id: { in: doctorIds } },
      });
    }
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  // Helper to generate unique slot times to avoid slotKey conflicts
  let slotCounter = 0;

  const generateSlotKey = (
    doctorId: string,
    date: Date,
    startTime: Date,
    clinicId?: string | null,
    roomId?: string | null
  ): string => {
    const dateStr = date.toISOString().slice(0, 10);
    const timeStr = startTime.toISOString().slice(11, 16);
    const clinicPart = clinicId || 'none';
    const roomPart = roomId || 'none';
    return `${doctorId}:${dateStr}:${timeStr}:${clinicPart}:${roomPart}`;
  };

  const createTestSlot = async (overrides: any = {}) => {
    slotCounter++;
    // Use unique start times to avoid slotKey conflicts
    const baseMinutes = 9 * 60 + slotCounter * 5;
    const hours = Math.floor(baseMinutes / 60);
    const minutes = baseMinutes % 60;

    const date = overrides.date || new Date('2026-08-20');
    const startTime = overrides.startTime || new Date(`1970-01-01T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00.000Z`);
    const endTime = overrides.endTime || new Date(startTime.getTime() + 30 * 60000);

    const slot = await prisma.slot.create({
      data: {
        doctorId,
        clinicId: overrides.clinicId !== undefined ? overrides.clinicId : null,
        roomId: overrides.roomId !== undefined ? overrides.roomId : null,
        date: date,
        startTime: startTime,
        endTime: endTime,
        maxPatients: overrides.maxPatients || 3,
        status: overrides.status || 'available',
        slotKey: generateSlotKey(
          doctorId,
          date,
          startTime,
          overrides.clinicId !== undefined ? overrides.clinicId : null,
          overrides.roomId !== undefined ? overrides.roomId : null
        ),
      },
    });
    slotIds.push(slot.id);
    return slot;
  };

  const createTestUser = async (overrides: any = {}) => {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const user = await prisma.user.create({
      data: {
        email: `test-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        firstName: 'Test',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
        ...overrides,
      },
    });
    userIds.push(user.id);
    return user;
  };

  const createTestWallet = async (userId: string, credits: number = 0) => {
    const wallet = await prisma.userWallet.create({
      data: { userId, credits },
    });
    walletIds.push(wallet.id);
    return wallet;
  };

  const createTestAppointment = async (slotId: string, patientId: string, overrides: any = {}) => {
    // Check if appointment already exists for this slot and patient
    const existing = await prisma.appointment.findFirst({
      where: {
        slotId,
        patientId,
      },
    });

    if (existing) {
      // If exists, update it instead
      const updated = await prisma.appointment.update({
        where: { id: existing.id },
        data: {
          status: overrides.status || 'PENDING',
          paymentMethod: overrides.paymentMethod || 'CREDIT',
        },
      });
      return updated;
    }

    const appointment = await prisma.appointment.create({
      data: {
        slotId,
        doctorId,
        patientId,
        patientType: 'REGISTERED',
        status: overrides.status || 'PENDING',
        paymentMethod: overrides.paymentMethod || 'CREDIT',
        createdBy: patientId,
        createdByType: 'user',
        type: 'IN_PERSON',
        ...overrides,
      },
    });
    appointmentIds.push(appointment.id);
    return appointment;
  };

  // ============================================================
  // Tests
  // ============================================================

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find a slot by id with all relations', async () => {
      const slot = await createTestSlot();
      const result = await slotRepository.findById(slot.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(slot.id);
      expect(result?.doctor).toBeDefined();
      expect(result?.doctor.id).toBe(doctorId);
    });

    it('should return null when slot does not exist', async () => {
      const result = await slotRepository.findById('00000000-0000-0000-0000-000000000000');
      expect(result).toBeNull();
    });
  });

  // ============================================================
  // findByDoctorAndDate
  // ============================================================

  describe('findByDoctorAndDate', () => {
    it('should return slots for a doctor on a specific date', async () => {
      const slot1 = await createTestSlot({
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const slot2 = await createTestSlot({
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });

      const result = await slotRepository.findByDoctorAndDate(doctorId, '2026-08-20');

      expect(result).toHaveLength(2);
      expect(result[0].id).toBe(slot1.id);
      expect(result[1].id).toBe(slot2.id);
      expect(result[0].startTime).toStrictEqual(slot1.startTime);
      expect(result[1].startTime).toStrictEqual(slot2.startTime);
    });

    it('should return empty array when no slots found', async () => {
      const result = await slotRepository.findByDoctorAndDate(doctorId, '2026-08-21');
      expect(result).toHaveLength(0);
    });

    it('should filter by clinicId', async () => {
      const clinicSlot = await createTestSlot({ clinicId });
      await createTestSlot({ clinicId: null });

      const result = await slotRepository.findByDoctorAndDate(doctorId, '2026-08-20');

      expect(result).toHaveLength(2);
      expect(result.some(s => s.clinicId === clinicId)).toBe(true);
      expect(result.some(s => s.clinicId === null)).toBe(true);
    });
  });

  // ============================================================
  // findAvailableByDoctorAndDate
  // ============================================================

  describe('findAvailableByDoctorAndDate', () => {
    it('should return only available slots excluding cancelled', async () => {
      const available1 = await createTestSlot({
        status: 'available',
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const available2 = await createTestSlot({
        status: 'available',
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });
      await createTestSlot({
        status: 'cancelled',
        startTime: new Date('1970-01-01T11:00:00.000Z'),
      });

      const result = await slotRepository.findAvailableByDoctorAndDate(doctorId, '2026-08-20');

      expect(result).toHaveLength(2);
      expect(result.some(s => s.id === available1.id)).toBe(true);
      expect(result.some(s => s.id === available2.id)).toBe(true);
      expect(result.some(s => s.status === 'cancelled')).toBe(false);
    });

    it('should filter out slots that have already passed', async () => {
      const futureSlot = await createTestSlot({
        date: new Date('2026-12-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const pastSlot = await createTestSlot({
        date: new Date('2026-08-19'),
        startTime: new Date('1970-01-01T08:00:00.000Z'),
      });

      const result = await slotRepository.findAvailableByDoctorAndDate(doctorId, '2026-12-20');

      expect(result).toHaveLength(1);
      expect(result[0].id).toBe(futureSlot.id);
    });
  });

  // ============================================================
  // validateSlotIsBookable
  // ============================================================

  describe('validateSlotIsBookable', () => {
    it('should return slot when valid and bookable', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-12-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });

      const result = await slotRepository.validateSlotIsBookable(slot.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(slot.id);
      expect(result?.status).toBe('available');
    });

    it('should throw error when slot not found', async () => {
      await expect(
        slotRepository.validateSlotIsBookable('00000000-0000-0000-0000-000000000000')
      ).rejects.toThrow('Slot not found');
    });

    it('should throw error when slot is cancelled', async () => {
      const slot = await createTestSlot({ status: 'cancelled' });

      await expect(
        slotRepository.validateSlotIsBookable(slot.id)
      ).rejects.toThrow('This slot has been cancelled');
    });

    it('should throw error when slot has already passed', async () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const slot = await createTestSlot({
        date: yesterday,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
      });

      await expect(
        slotRepository.validateSlotIsBookable(slot.id)
      ).rejects.toThrow('This slot has already passed');
    });
  });

  // ============================================================
  // refreshSlotStatus
  // ============================================================

  describe('refreshSlotStatus', () => {
    it('should set status to full when active appointments >= maxPatients', async () => {
      const slot = await createTestSlot({ maxPatients: 1 });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      await createTestAppointment(slot.id, user.id);

      const result = await slotRepository.refreshSlotStatus(slot.id);

      expect(result?.status).toBe('full');
    });

    it('should set status to available when active appointments < maxPatients', async () => {
      const slot = await createTestSlot({ maxPatients: 3 });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      await createTestAppointment(slot.id, user.id);

      const result = await slotRepository.refreshSlotStatus(slot.id);

      expect(result?.status).toBe('available');
    });

    it('should not update if status already correct', async () => {
      const slot = await createTestSlot({ status: 'available', maxPatients: 3 });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      await createTestAppointment(slot.id, user.id);

      const result = await slotRepository.refreshSlotStatus(slot.id);

      expect(result?.status).toBe('available');
    });

    it('should return null when slot not found', async () => {
      const result = await slotRepository.refreshSlotStatus('00000000-0000-0000-0000-000000000000');
      expect(result).toBeNull();
    });

    it('should handle cancelled appointments in count', async () => {
      const slot = await createTestSlot({ maxPatients: 1 });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);

      await createTestAppointment(slot.id, user.id, { status: 'PENDING' });

      const result = await slotRepository.refreshSlotStatus(slot.id);

      expect(result?.status).toBe('full');
    });

    it('should handle NO_SHOW appointments in count', async () => {
      const slot = await createTestSlot({ maxPatients: 2 });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);

      await createTestAppointment(slot.id, user.id, { status: 'NO_SHOW' });

      const result = await slotRepository.refreshSlotStatus(slot.id);

      expect(result?.status).toBe('available');
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    it('should create a slot with generated slotKey', async () => {
      const date = new Date('2026-08-20');
      const startTime = new Date('1970-01-01T09:00:00.000Z');
      const endTime = new Date('1970-01-01T09:30:00.000Z');
      const maxPatients = 2;

      const result = await slotRepository.create({
        doctorId,
        clinicId,
        roomId,
        date,
        startTime,
        endTime,
        maxPatients,
      });

      slotIds.push(result.id);

      expect(result).toMatchObject({
        doctorId,
        clinicId,
        roomId,
        date,
        startTime,
        endTime,
        maxPatients,
        status: 'available',
      });
      expect(result.slotKey).toBeDefined();
      expect(result.slotKey).toContain(doctorId);
      expect(result.slotKey).toContain('2026-08-20');
      expect(result.slotKey).toContain('09:00');
    });

    it('should use default maxPatients when not provided', async () => {
      const date = new Date('2026-08-20');
      const startTime = new Date('1970-01-01T09:00:00.000Z');
      const endTime = new Date('1970-01-01T09:30:00.000Z');

      const result = await slotRepository.create({
        doctorId,
        date,
        startTime,
        endTime,
      });

      slotIds.push(result.id);

      expect(result.maxPatients).toBe(1);
    });

    it('should handle null clinicId and roomId', async () => {
      const date = new Date('2026-08-20');
      const startTime = new Date('1970-01-01T09:00:00.000Z');
      const endTime = new Date('1970-01-01T09:30:00.000Z');

      const result = await slotRepository.create({
        doctorId,
        date,
        startTime,
        endTime,
      });

      slotIds.push(result.id);

      expect(result.clinicId).toBeNull();
      expect(result.roomId).toBeNull();
      expect(result.slotKey).toContain('none:none');
    });
  });

  // ============================================================
  // createMany
  // ============================================================

  describe('createMany', () => {
    it('should create multiple slots with generated slotKeys', async () => {
      const slots = [
        {
          doctorId,
          clinicId,
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          endTime: new Date('1970-01-01T09:30:00.000Z'),
          maxPatients: 2,
        },
        {
          doctorId,
          clinicId,
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T10:00:00.000Z'),
          endTime: new Date('1970-01-01T10:30:00.000Z'),
          maxPatients: 3,
        },
      ];

      const result = await slotRepository.createMany(slots);

      expect(result.count).toBe(2);

      const createdSlots = await prisma.slot.findMany({
        where: { doctorId },
        orderBy: { startTime: 'asc' },
      });

      expect(createdSlots).toHaveLength(2);
      expect(createdSlots[0].maxPatients).toBe(2);
      expect(createdSlots[1].maxPatients).toBe(3);
      expect(createdSlots[0].slotKey).toBeDefined();
      expect(createdSlots[1].slotKey).toBeDefined();
      expect(createdSlots[0].slotKey).not.toBe(createdSlots[1].slotKey);

      createdSlots.forEach(s => slotIds.push(s.id));
    });

    it('should handle empty array', async () => {
      const result = await slotRepository.createMany([]);
      expect(result.count).toBe(0);
    });

    it('should skip duplicates', async () => {
      const slot1 = await createTestSlot();
      slotIds.push(slot1.id);

      const duplicateSlot = {
        doctorId,
        date: slot1.date,
        startTime: slot1.startTime,
        endTime: slot1.endTime,
        maxPatients: 3,
      };

      const result = await slotRepository.createMany([duplicateSlot]);

      expect(result.count).toBe(0);
    });
  });

  // ============================================================
  // updateStatus
  // ============================================================

  describe('updateStatus', () => {
    it('should update slot status', async () => {
      const slot = await createTestSlot({ status: 'available' });

      const result = await slotRepository.updateStatus(slot.id, 'cancelled');

      expect(result.status).toBe('cancelled');

      const updatedSlot = await prisma.slot.findUnique({
        where: { id: slot.id },
      });
      expect(updatedSlot?.status).toBe('cancelled');
    });
  });

  // ============================================================
  // cancelSlot
  // ============================================================

  describe('cancelSlot', () => {
    it('should cancel a slot', async () => {
      const slot = await createTestSlot({ status: 'available' });

      const result = await slotRepository.cancelSlot(slot.id);

      expect(result.status).toBe('cancelled');
    });
  });

  // ============================================================
  // cancelByDoctorAndDate
  // ============================================================

  describe('cancelByDoctorAndDate', () => {
    it('should cancel all slots for a doctor on a date', async () => {
      const slot1 = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const slot2 = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });

      const result = await slotRepository.cancelByDoctorAndDate(doctorId, '2026-08-20');

      expect(result.count).toBe(2);

      const slots = await prisma.slot.findMany({
        where: {
          doctorId,
          date: new Date('2026-08-20'),
        },
      });
      expect(slots.every(s => s.status === 'cancelled')).toBe(true);
    });

    it('should return 0 when no slots to cancel', async () => {
      const result = await slotRepository.cancelByDoctorAndDate(doctorId, '2026-08-21');
      expect(result.count).toBe(0);
    });
  });

  // ============================================================
  // deleteByDoctorAndDateRange
  // ============================================================

  describe('deleteByDoctorAndDateRange', () => {
    const startDate = new Date('2026-08-20');
    const endDate = new Date('2026-08-22');

    it('should delete slots without active appointments', async () => {
      const slot1 = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const slot2 = await createTestSlot({
        date: new Date('2026-08-21'),
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });

      const result = await slotRepository.deleteByDoctorAndDateRange(doctorId, startDate, endDate);

      expect(result).toBe(2);

      const remainingSlots = await prisma.slot.findMany({
        where: { doctorId },
      });
      expect(remainingSlots).toHaveLength(0);
    });

    it('should throw error when slots have active appointments', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      await createTestAppointment(slot.id, user.id);

      await expect(
        slotRepository.deleteByDoctorAndDateRange(doctorId, startDate, endDate)
      ).rejects.toThrow('Cannot regenerate slots: 1 slot(s) have active appointments');
    });

    it('should include appointment details in error message', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      await createTestAppointment(slot.id, user.id);

      await expect(
        slotRepository.deleteByDoctorAndDateRange(doctorId, startDate, endDate)
      ).rejects.toThrow('2026-08-20 at 09:00 (1 appointment)');
    });

    it('should delete slots with CANCELLED appointments', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      const app = await createTestAppointment(slot.id, user.id, { status: 'CANCELLED' });

      await prisma.appointment.delete({ where: { id: app.id } });
      const appIdx = appointmentIds.indexOf(app.id);
      if (appIdx > -1) appointmentIds.splice(appIdx, 1);

      const result = await slotRepository.deleteByDoctorAndDateRange(doctorId, startDate, endDate);

      expect(result).toBe(1);
    });

    it('should delete slots with NO_SHOW appointments', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      await createTestWallet(user.id, 10);
      const app = await createTestAppointment(slot.id, user.id, { status: 'NO_SHOW' });

      await prisma.appointment.delete({ where: { id: app.id } });
      const appIdx = appointmentIds.indexOf(app.id);
      if (appIdx > -1) appointmentIds.splice(appIdx, 1);

      const result = await slotRepository.deleteByDoctorAndDateRange(doctorId, startDate, endDate);

      expect(result).toBe(1);
    });
  });

  // ============================================================
  // forceDeleteByDoctorAndDateRange
  // ============================================================

  describe('forceDeleteByDoctorAndDateRange', () => {
    const startDate = new Date('2026-08-20');
    const endDate = new Date('2026-08-22');

    it('should cancel appointments and refund credits for registered patients', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 5);
      const app = await createTestAppointment(slot.id, user.id, { paymentMethod: 'CREDIT' });

      await prisma.appointment.delete({ where: { id: app.id } });
      const appIdx = appointmentIds.indexOf(app.id);
      if (appIdx > -1) appointmentIds.splice(appIdx, 1);

      const result = await slotRepository.forceDeleteByDoctorAndDateRange(
        doctorId,
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.deletedSlots).toBe(1);
    });

    it('should not refund credits for guest patients', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });

      const guestPatient = await prisma.guestPatient.create({
        data: {
          firstName: 'Guest',
          lastName: 'Patient',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          createdBy: doctorId,
          createdByType: 'DOCTOR',
        },
      });

      const app = await prisma.appointment.create({
        data: {
          slotId: slot.id,
          doctorId,
          guestPatientId: guestPatient.id,
          patientType: 'GUEST',
          paymentMethod: 'ON_SITE',
          status: 'PENDING',
          createdBy: doctorId,
          createdByType: 'doctor',
          type: 'IN_PERSON',
        },
      });
      appointmentIds.push(app.id);

      await prisma.appointment.delete({ where: { id: app.id } });
      const appIdx = appointmentIds.indexOf(app.id);
      if (appIdx > -1) appointmentIds.splice(appIdx, 1);

      const result = await slotRepository.forceDeleteByDoctorAndDateRange(
        doctorId,
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.deletedSlots).toBe(1);
    });

    it('should handle slots without appointments', async () => {
      await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      await createTestSlot({
        date: new Date('2026-08-21'),
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });

      const result = await slotRepository.forceDeleteByDoctorAndDateRange(
        doctorId,
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.deletedSlots).toBe(2);
      expect(result.cancelledAppointments).toBe(0);
      expect(result.refundedCredits).toBe(0);
    });

    it('should cancel appointments even without credits', async () => {
      const slot = await createTestSlot({
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });
      const user = await createTestUser();
      await createTestWallet(user.id, 0);
      const app = await createTestAppointment(slot.id, user.id, { paymentMethod: 'ON_SITE' });

      await prisma.appointment.delete({ where: { id: app.id } });
      const appIdx = appointmentIds.indexOf(app.id);
      if (appIdx > -1) appointmentIds.splice(appIdx, 1);

      const result = await slotRepository.forceDeleteByDoctorAndDateRange(
        doctorId,
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.deletedSlots).toBe(1);
    });
  });

  // ============================================================
  // markExpiredSlots
  // ============================================================

  describe('markExpiredSlots', () => {
    it('should mark expired slots as expired', async () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const expiredSlot = await createTestSlot({
        date: yesterday,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        status: 'available',
      });

      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      await createTestSlot({
        date: futureDate,
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        status: 'available',
      });

      const result = await slotRepository.markExpiredSlots();

      expect(result).toBeGreaterThan(0);

      const updatedExpiredSlot = await prisma.slot.findUnique({
        where: { id: expiredSlot.id },
      });
      expect(updatedExpiredSlot?.status).toBe('expired');
    });

    it('should return 0 when no expired slots', async () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      await createTestSlot({
        date: futureDate,
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        status: 'available',
      });

      const result = await slotRepository.markExpiredSlots();

      expect(result).toBe(0);
    });

    it('should not mark cancelled slots as expired', async () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const cancelledSlot = await createTestSlot({
        date: yesterday,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        status: 'cancelled',
      });

      await slotRepository.markExpiredSlots();

      const updatedSlot = await prisma.slot.findUnique({
        where: { id: cancelledSlot.id },
      });
      expect(updatedSlot?.status).toBe('cancelled');
    });

    it('should mark full slots as expired when past date', async () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const fullSlot = await createTestSlot({
        date: yesterday,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        status: 'full',
      });

      await slotRepository.markExpiredSlots();

      const updatedSlot = await prisma.slot.findUnique({
        where: { id: fullSlot.id },
      });
      expect(updatedSlot?.status).toBe('expired');
    });
  });

  // ============================================================
  // getBookingHorizon - FIXED TEST
  // ============================================================

  describe('getBookingHorizon', () => {
    it('should return farthest date with slots', async () => {
      await createTestSlot({ date: new Date('2026-08-20') });
      await createTestSlot({ date: new Date('2026-09-20') });

      const result = await slotRepository.getBookingHorizon(doctorId);

      expect(result).not.toBeNull();
      expect(result?.toISOString().slice(0, 10)).toBe('2026-09-20');
    });

    it('should filter by clinicId when provided', async () => {
      await createTestSlot({ clinicId, date: new Date('2026-09-20') });
      await createTestSlot({ clinicId: null, date: new Date('2026-10-20') });

      const result = await slotRepository.getBookingHorizon(doctorId, clinicId);

      expect(result?.toISOString().slice(0, 10)).toBe('2026-09-20');
    });

    it('should filter by roomId when provided', async () => {
      // Delete existing slots first to ensure clean state
      await prisma.slot.deleteMany({ where: { doctorId } });
      slotIds.length = 0;

      // ✅ FIXED: Pass clinicId AND roomId when creating the slot
      const dateWithRoom = new Date('2026-09-20');
      await createTestSlot({
        clinicId,      // ✅ FIXED: Add clinicId
        roomId,
        date: dateWithRoom,
        startTime: new Date('1970-01-01T09:00:00.000Z'),
      });

      // Create a slot without roomId (should be ignored)
      const dateWithoutRoom = new Date('2026-10-20');
      await createTestSlot({
        clinicId,      // ✅ FIXED: Add clinicId
        roomId: null,
        date: dateWithoutRoom,
        startTime: new Date('1970-01-01T10:00:00.000Z'),
      });

      // Verify both slots exist
      const allSlots = await prisma.slot.findMany({
        where: { doctorId },
        orderBy: { date: 'desc' },
      });
      expect(allSlots).toHaveLength(2);

      // Now test getBookingHorizon with roomId filter
      const result = await slotRepository.getBookingHorizon(doctorId, clinicId, roomId);

      expect(result).not.toBeNull();
      // Should return the date with the matching roomId (2026-09-20)
      expect(result?.toISOString().slice(0, 10)).toBe('2026-09-20');
    });

    it('should return null when no slots found', async () => {
      await prisma.slot.deleteMany({ where: { doctorId } });
      slotIds.length = 0;

      const result = await slotRepository.getBookingHorizon(doctorId);
      expect(result).toBeNull();
    });
  });

  // ============================================================
  // generateMissingSlots
  // ============================================================

  describe('generateMissingSlots', () => {
    it('should create missing slots idempotently', async () => {
      await prisma.slot.deleteMany({ where: { doctorId } });
      slotIds.length = 0;

      const slots = [
        {
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          endTime: new Date('1970-01-01T09:30:00.000Z'),
          maxPatients: 2,
        },
        {
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T10:00:00.000Z'),
          endTime: new Date('1970-01-01T10:30:00.000Z'),
          maxPatients: 3,
        },
      ];

      const result = await slotRepository.generateMissingSlots(doctorId, slots);

      expect(result.created).toBe(2);
      expect(result.existing).toBe(0);
      expect(result.errors).toBe(0);

      const result2 = await slotRepository.generateMissingSlots(doctorId, slots);

      expect(result2.created).toBe(0);
      expect(result2.existing).toBe(2);
      expect(result2.errors).toBe(0);
    });

    it('should handle errors during creation', async () => {
      const slots = [
        {
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          endTime: new Date('1970-01-01T09:30:00.000Z'),
          maxPatients: 2,
        },
      ];

      await expect(
        slotRepository.generateMissingSlots('00000000-0000-0000-0000-000000000000', slots)
      ).rejects.toThrow();
    });
  });

  // ============================================================
  // upsertAutomationRule - FIXED TEST
  // ============================================================

  describe('upsertAutomationRule', () => {
    // ✅ FIXED: Move automationData inside the test
    it('should create automation rule', async () => {
      // Clean up any existing rule
      await prisma.slotGenerationRule.deleteMany({ where: { doctorId } });

      // Verify no rule exists
      const existingRule = await prisma.slotGenerationRule.findUnique({
        where: { doctorId },
      });
      expect(existingRule).toBeNull();

      // ✅ FIXED: Build automationData inside the test (not at describe level)
      const automationData = {
        frequency: 'WEEKLY' as const,
        bookingWindowDays: 30,
        clinicId,
        roomId,
      };

      const result = await slotRepository.upsertAutomationRule(doctorId, automationData);

      // Check the returned result
      expect(result).toMatchObject({
        doctorId,
        frequency: 'WEEKLY',
        bookingWindowDays: 30,
        enabled: true,
        clinicId,
        roomId,
      });
      expect(result.nextRunAt).toBeInstanceOf(Date);

      // Verify in database
      const rule = await prisma.slotGenerationRule.findUnique({
        where: { doctorId },
      });
      expect(rule).not.toBeNull();
      expect(rule?.frequency).toBe('WEEKLY');
      expect(rule?.bookingWindowDays).toBe(30);
      expect(rule?.clinicId).toBe(clinicId);
      expect(rule?.roomId).toBe(roomId);
    });

    it('should update existing automation rule', async () => {
      await prisma.slotGenerationRule.deleteMany({ where: { doctorId } });

      // ✅ FIXED: Build automationData inside the test
      const automationData = {
        frequency: 'WEEKLY' as const,
        bookingWindowDays: 30,
        clinicId,
        roomId,
      };

      await slotRepository.upsertAutomationRule(doctorId, automationData);

      const updateData = {
        frequency: 'DAILY' as const,
        bookingWindowDays: 60,
        clinicId,
        roomId,
      };

      const result = await slotRepository.upsertAutomationRule(doctorId, updateData);

      expect(result.frequency).toBe('DAILY');
      expect(result.bookingWindowDays).toBe(60);
      expect(result.clinicId).toBe(clinicId);
      expect(result.roomId).toBe(roomId);

      const rule = await prisma.slotGenerationRule.findUnique({
        where: { doctorId },
      });
      expect(rule?.frequency).toBe('DAILY');
      expect(rule?.bookingWindowDays).toBe(60);
      expect(rule?.clinicId).toBe(clinicId);
      expect(rule?.roomId).toBe(roomId);
    });
  });

  // ============================================================
  // disableAutomationRule
  // ============================================================

  describe('disableAutomationRule', () => {
    it('should disable automation rule', async () => {
      await prisma.slotGenerationRule.deleteMany({ where: { doctorId } });

      // ✅ FIXED: Build automationData inside the test
      const automationData = {
        frequency: 'WEEKLY' as const,
        bookingWindowDays: 30,
        clinicId,
        roomId,
      };

      await slotRepository.upsertAutomationRule(doctorId, automationData);

      await slotRepository.disableAutomationRule(doctorId);

      const rule = await prisma.slotGenerationRule.findUnique({
        where: { doctorId },
      });
      expect(rule?.enabled).toBe(false);
    });
  });

  // ============================================================
  // getAutomationRule
  // ============================================================

  describe('getAutomationRule', () => {
    it('should return automation rule when exists', async () => {
      await prisma.slotGenerationRule.deleteMany({ where: { doctorId } });

      // ✅ FIXED: Build automationData inside the test
      const automationData = {
        frequency: 'WEEKLY' as const,
        bookingWindowDays: 30,
        clinicId,
        roomId,
      };

      await slotRepository.upsertAutomationRule(doctorId, automationData);

      const result = await slotRepository.getAutomationRule(doctorId);

      expect(result).not.toBeNull();
      expect(result?.doctorId).toBe(doctorId);
      expect(result?.frequency).toBe('WEEKLY');
      expect(result?.bookingWindowDays).toBe(30);
      expect(result?.enabled).toBe(true);
      expect(result?.clinicId).toBe(clinicId);
      expect(result?.roomId).toBe(roomId);
    });

    it('should return null when no rule exists', async () => {
      await prisma.slotGenerationRule.deleteMany({ where: { doctorId } });

      const result = await slotRepository.getAutomationRule(doctorId);
      expect(result).toBeNull();
    });
  });
});

