// backend/tests/integration/repositories/appointment.repository.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient } from '@prisma/client';

describe('AppointmentRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let appointmentRepository: typeof import('../../../src/repositories/appointment.repository')['appointmentRepository'];
  let slotRepository: typeof import('../../../src/repositories/slot.repository')['slotRepository'];
  let wilayaId: string;
  let doctorId: string;
  let clinicId: string;
  let userId: string;
  let slotId: string;
  let guestPatientId: string;

  const appointmentIds: string[] = [];
  const slotIds: string[] = [];
  const userIds: string[] = [];
  const doctorIds: string[] = [];
  const clinicIds: string[] = [];
  const guestPatientIds: string[] = [];
  const walletIds: string[] = [];
  const contactUserIds: string[] = [];

  // Helper to create a unique patient for each test
  let patientCounter = 0;
  let slotCounter = 0;

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ appointmentRepository } = await import('../../../src/repositories/appointment.repository'));
    ({ slotRepository } = await import('../../../src/repositories/slot.repository'));

    await prisma.$connect();

    // Create test data dependencies
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // Create a test doctor
    const doctor = await prisma.doctor.create({
      data: {
        email: `doctor-${crypto.randomUUID()}@example.com`,
        password: 'hashed-password',
        firstNameFr: 'Test',
        firstNameAr: 'اختبار',
        lastNameFr: 'Doctor',
        lastNameAr: 'طبيب',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        wilaya: { connect: { id: wilayaId } },
        isVerified: true,
        isSuspended: false,
        isRegistered: true,
        isCompleted: true,
        isAvailableForBooking: true,
      },
    });
    doctorId = doctor.id;
    doctorIds.push(doctor.id);

    // Create a test clinic
    const clinic = await prisma.clinic.create({
      data: {
        nameFr: `Test Clinic ${crypto.randomUUID()}`,
        nameAr: `عيادة اختبار ${crypto.randomUUID()}`,
        email: `clinic-${crypto.randomUUID()}@example.com`,
        password: 'hashed-password',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        wilaya: { connect: { id: wilayaId } },
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
      },
    });
    clinicId = clinic.id;
    clinicIds.push(clinic.id);

    // Create a test user (patient)
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const user = await prisma.user.create({
      data: {
        email: `patient-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        firstName: 'Test',
        lastName: 'Patient',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    userId = user.id;
    userIds.push(user.id);

    // Create a guest patient
    const guestPatient = await prisma.guestPatient.create({
      data: {
        firstName: 'Guest',
        lastName: 'Patient',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        createdBy: doctorId,
        createdByType: 'DOCTOR',
      },
    });
    guestPatientId = guestPatient.id;
    guestPatientIds.push(guestPatient.id);

    // Create a base slot
    const date = new Date('2026-12-20');
    const startTime = new Date('1970-01-01T09:00:00.000Z');
    const endTime = new Date('1970-01-01T09:30:00.000Z');

    const slot = await slotRepository.create({
      doctorId,
      clinicId,
      date,
      startTime,
      endTime,
      maxPatients: 3,
    });
    slotId = slot.id;
    slotIds.push(slot.id);

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    // Clean up in reverse order to avoid FK violations
    if (contactUserIds.length > 0) {
      await prisma.contactUser.deleteMany({
        where: { id: { in: contactUserIds } },
      });
      contactUserIds.length = 0;
    }
    if (appointmentIds.length > 0) {
      await prisma.appointment.deleteMany({
        where: { id: { in: appointmentIds } },
      });
      appointmentIds.length = 0;
    }
    if (walletIds.length > 0) {
      await prisma.creditTransaction.deleteMany({
        where: { walletId: { in: walletIds } },
      });
      await prisma.userWallet.deleteMany({
        where: { id: { in: walletIds } },
      });
      walletIds.length = 0;
    }
  });

  afterAll(async () => {
    // Clean up test data
    if (guestPatientIds.length > 0) {
      await prisma.guestPatient.deleteMany({
        where: { id: { in: guestPatientIds } },
      });
    }
    if (slotIds.length > 0) {
      await prisma.slot.deleteMany({
        where: { id: { in: slotIds } },
      });
    }
    if (userIds.length > 0) {
      await prisma.user.deleteMany({
        where: { id: { in: userIds } },
      });
    }
    if (clinicIds.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: clinicIds } },
      });
    }
    if (doctorIds.length > 0) {
      await prisma.doctor.deleteMany({
        where: { id: { in: doctorIds } },
      });
    }
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  // Helper to create a unique user (patient)
  const createUniquePatient = async () => {
    patientCounter++;
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const user = await prisma.user.create({
      data: {
        email: `patient-${patientCounter}-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        firstName: `Patient${patientCounter}`,
        lastName: 'Test',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    userIds.push(user.id);
    return user;
  };

  // Helper to create a unique slot
  const createUniqueSlot = async (overrides: any = {}) => {
    slotCounter++;
    const date = new Date('2026-12-20');
    // Use different hours for each slot to avoid conflicts
    const hours = 9 + (slotCounter % 8);
    const minutes = Math.floor(slotCounter / 8) * 5;
    const startTime = new Date(`1970-01-01T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00.000Z`);
    const endTime = new Date(startTime.getTime() + 30 * 60000);

    const slot = await slotRepository.create({
      doctorId: overrides.doctorId || doctorId,
      clinicId: overrides.clinicId || clinicId,
      date: overrides.date || date,
      startTime: overrides.startTime || startTime,
      endTime: overrides.endTime || endTime,
      maxPatients: overrides.maxPatients || 3,
    });
    slotIds.push(slot.id);
    return slot;
  };

  // Helper to create a test appointment with unique patient and slot
  const createTestAppointment = async (overrides: any = {}) => {
    // If no patientId provided, create a unique patient
    let patientId = overrides.patientId;
    if (!patientId && !overrides.guestPatientId) {
      const patient = await createUniquePatient();
      patientId = patient.id;
    }

    // If no slotId provided, create a unique slot
    let slotIdToUse = overrides.slotId;
    if (!slotIdToUse) {
      const slot = await createUniqueSlot({
        doctorId: overrides.doctorId || doctorId,
        clinicId: overrides.clinicId,
      });
      slotIdToUse = slot.id;
    }

    const appointment = await prisma.appointment.create({
      data: {
        slotId: slotIdToUse,
        doctorId: overrides.doctorId || doctorId,
        patientId: patientId || null,
        patientType: overrides.patientType || 'REGISTERED',
        status: overrides.status || 'PENDING',
        paymentMethod: overrides.paymentMethod || 'CREDIT',
        createdBy: overrides.createdBy || patientId || userId,
        createdByType: overrides.createdByType || 'user',
        type: overrides.type || 'IN_PERSON',
        clinicId: overrides.clinicId !== undefined ? overrides.clinicId : null,
        contactUserId: overrides.contactUserId !== undefined ? overrides.contactUserId : null,
        notes: overrides.notes !== undefined ? overrides.notes : null,
        guestPatientId: overrides.guestPatientId !== undefined ? overrides.guestPatientId : null,
        idempotencyKey: overrides.idempotencyKey || null,
        ...overrides,
      },
    });
    appointmentIds.push(appointment.id);
    return appointment;
  };

  // ============================================================
  // Tests
  // ============================================================

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find an appointment by id with all relations', async () => {
      const appointment = await createTestAppointment();

      const result = await appointmentRepository.findById(appointment.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(appointment.id);
      expect(result?.slot).toBeDefined();
      expect(result?.doctor).toBeDefined();
      expect(result?.patient).toBeDefined();
      expect(result?.doctor?.id).toBe(doctorId);
      expect(result?.patient?.id).toBe(appointment.patientId);
    });

    it('should return null when appointment does not exist', async () => {
      const result = await appointmentRepository.findById('00000000-0000-0000-0000-000000000000');
      expect(result).toBeNull();
    });

    it('should find appointment with guest patient', async () => {
      const appointment = await createTestAppointment({
        patientId: null,
        guestPatientId,
        patientType: 'GUEST',
        paymentMethod: 'ON_SITE',
      });

      const result = await appointmentRepository.findById(appointment.id);

      expect(result).not.toBeNull();
      expect(result?.patientId).toBeNull();
      expect(result?.guestPatientId).toBe(guestPatientId);
      expect(result?.patientType).toBe('GUEST');
    });
  });

  // ============================================================
  // findBySlotId
  // ============================================================

  describe('findBySlotId', () => {
    it('should find an appointment by slot id', async () => {
      const appointment = await createTestAppointment();

      const result = await appointmentRepository.findBySlotId(appointment.slotId);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(appointment.id);
    });

    it('should return null when no appointment found for slot', async () => {
      const result = await appointmentRepository.findBySlotId('00000000-0000-0000-0000-000000000000');
      expect(result).toBeNull();
    });

    it('should return the first appointment when multiple exist', async () => {
      // Create two appointments for the same slot with different patients
      const slot = await createUniqueSlot();
      const user2 = await createUniquePatient();
      await createTestAppointment({ slotId: slot.id, patientId: user2.id });
      const appointment = await createTestAppointment({ slotId: slot.id });

      const result = await appointmentRepository.findBySlotId(slot.id);

      expect(result).not.toBeNull();
      expect(result?.slotId).toBe(slot.id);
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    it('should create an appointment with all data', async () => {
      const patient = await createUniquePatient();
      const slot = await createUniqueSlot();
      const data = {
        slotId: slot.id,
        doctorId,
        patientId: patient.id,
        contactUserId: undefined,
        clinicId,
        type: 'VIDEO',
        paymentMethod: 'CREDIT',
        notes: 'Test appointment',
        createdBy: patient.id,
        createdByType: 'user',
      };

      const result = await appointmentRepository.create(data);

      appointmentIds.push(result.id);

      expect(result).toMatchObject({
        slotId: slot.id,
        doctorId,
        patientId: patient.id,
        clinicId,
        type: 'VIDEO',
        paymentMethod: 'CREDIT',
        notes: 'Test appointment',
        createdBy: patient.id,
        createdByType: 'user',
        status: 'PENDING',
        patientType: 'REGISTERED',
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
    });

    it('should create an appointment with guest patient', async () => {
      const slot = await createUniqueSlot();
      const data = {
        slotId: slot.id,
        doctorId,
        patientId: undefined as string | undefined,
        guestPatientId,
        patientType: 'GUEST' as const,
        paymentMethod: 'ON_SITE' as const,
        createdBy: doctorId,
        createdByType: 'doctor',
      };

      const result = await appointmentRepository.create(data as any);

      appointmentIds.push(result.id);

      expect(result).toMatchObject({
        slotId: slot.id,
        doctorId,
        patientId: null,
        guestPatientId,
        patientType: 'GUEST',
        paymentMethod: 'ON_SITE',
        createdBy: doctorId,
        createdByType: 'doctor',
      });
    });

    it('should create an appointment with minimal data', async () => {
      const patient = await createUniquePatient();
      const slot = await createUniqueSlot();
      const data = {
        slotId: slot.id,
        doctorId,
        patientId: patient.id,
        createdBy: patient.id,
        createdByType: 'user',
      };

      const result = await appointmentRepository.create(data);

      appointmentIds.push(result.id);

      expect(result).toMatchObject({
        slotId: slot.id,
        doctorId,
        patientId: patient.id,
        createdBy: patient.id,
        createdByType: 'user',
        status: 'PENDING',
        type: 'IN_PERSON',
        paymentMethod: 'CREDIT',
      });
      expect(result.contactUserId).toBeNull();
      expect(result.clinicId).toBeNull();
      expect(result.notes).toBeNull();
    });
  });

  // ============================================================
  // findByPatientId
  // ============================================================

  describe('findByPatientId', () => {
    it('should return appointments for a patient with pagination', async () => {
      const patient = await createUniquePatient();
      // Create appointments on different slots for the same patient
      await createTestAppointment({ patientId: patient.id });
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByPatientId(patient.id, 1, 10);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.appointments[0]?.patientId).toBe(patient.id);
      expect(result.appointments[0]?.slot).toBeDefined();
      expect(result.appointments[0]?.doctor).toBeDefined();
    });

    it('should use default pagination values', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByPatientId(patient.id);

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should calculate pagination correctly', async () => {
      const patient = await createUniquePatient();
      // Create 5 appointments for the same patient on different slots
      for (let i = 0; i < 5; i++) {
        await createTestAppointment({ patientId: patient.id });
      }

      const result = await appointmentRepository.findByPatientId(patient.id, 2, 2);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(5);
    });

    it('should return empty array when no appointments', async () => {
      const result = await appointmentRepository.findByPatientId('00000000-0000-0000-0000-000000000000');
      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });

    it('should order appointments by createdAt descending', async () => {
      const patient = await createUniquePatient();
      const app1 = await createTestAppointment({ patientId: patient.id });
      // Wait a bit to ensure different timestamps
      await new Promise((resolve) => setTimeout(resolve, 10));
      const app2 = await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByPatientId(patient.id);

      expect(result.appointments[0]?.id).toBe(app2.id);
      expect(result.appointments[1]?.id).toBe(app1.id);
    });
  });

  // ============================================================
  // findByDoctorId
  // ============================================================

  describe('findByDoctorId', () => {
    it('should return appointments for a doctor with pagination', async () => {
      // Create a unique doctor for this test
      const bcrypt = await import('bcryptjs');
      const testDoctor = await prisma.doctor.create({
        data: {
          email: `test-doctor-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.default.hash('Password123!', 12),
          firstNameFr: 'Test',
          firstNameAr: 'اختبار',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isVerified: true,
          isSuspended: false,
          isRegistered: true,
          isCompleted: true,
          isAvailableForBooking: true,
        },
      });
      doctorIds.push(testDoctor.id);

      await createTestAppointment({ doctorId: testDoctor.id });
      await createTestAppointment({ doctorId: testDoctor.id });

      const result = await appointmentRepository.findByDoctorId(testDoctor.id, 1, 10);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.appointments[0]?.doctorId).toBe(testDoctor.id);
      expect(result.appointments[0]?.slot).toBeDefined();
      expect(result.appointments[0]?.patient).toBeDefined();
    });

    it('should filter by date when provided', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByDoctorId(doctorId, 1, 10, '2026-12-20');

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should filter by date with no matching appointments', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByDoctorId(doctorId, 1, 10, '2026-12-21');

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });

    it('should use default pagination values', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByDoctorId(doctorId);

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should calculate pagination correctly', async () => {
      for (let i = 0; i < 5; i++) {
        const patient = await createUniquePatient();
        await createTestAppointment({ patientId: patient.id });
      }

      const result = await appointmentRepository.findByDoctorId(doctorId, 2, 2);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(5);
    });

    it('should include patient and clinic in response', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findByDoctorId(doctorId);

      expect(result.appointments[0]?.patient).toBeDefined();
      expect(result.appointments[0]?.clinic).toBeDefined();
      expect(result.appointments[0]?.clinic?.id).toBe(clinicId);
    });

    it('should handle undefined date parameter', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findByDoctorId(doctorId, 1, 10, undefined);

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });
  });

  // ============================================================
  // findByClinicId
  // ============================================================

  describe('findByClinicId', () => {
    it('should return appointments for a clinic with pagination', async () => {
      const patient1 = await createUniquePatient();
      const patient2 = await createUniquePatient();
      await createTestAppointment({ patientId: patient1.id, clinicId });
      await createTestAppointment({ patientId: patient2.id, clinicId });

      const result = await appointmentRepository.findByClinicId(clinicId, 1, 10);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.appointments[0]?.clinicId).toBe(clinicId);
      expect(result.appointments[0]?.slot).toBeDefined();
      expect(result.appointments[0]?.doctor).toBeDefined();
    });

    it('should filter by date when provided', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findByClinicId(clinicId, 1, 10, '2026-12-20');

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should filter by date with no matching appointments', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findByClinicId(clinicId, 1, 10, '2026-12-21');

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });

    it('should use default pagination values', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findByClinicId(clinicId);

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should calculate pagination correctly', async () => {
      for (let i = 0; i < 5; i++) {
        const patient = await createUniquePatient();
        await createTestAppointment({ patientId: patient.id, clinicId });
      }

      const result = await appointmentRepository.findByClinicId(clinicId, 2, 2);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(5);
    });

    it('should include patient and doctor in response', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findByClinicId(clinicId);

      expect(result.appointments[0]?.patient).toBeDefined();
      expect(result.appointments[0]?.doctor).toBeDefined();
      expect(result.appointments[0]?.doctor?.id).toBe(doctorId);
    });
  });

  // ============================================================
  // findAll
  // ============================================================

  describe('findAll', () => {
    it('should return all appointments with default pagination', async () => {
      await createTestAppointment();
      await createTestAppointment({ clinicId });
      await createTestAppointment({ status: 'CONFIRMED' });

      const result = await appointmentRepository.findAll();

      expect(result.appointments).toHaveLength(3);
      expect(result.total).toBe(3);
      expect(result.appointments[0]?.slot).toBeDefined();
      expect(result.appointments[0]?.doctor).toBeDefined();
      expect(result.appointments[0]?.patient).toBeDefined();
    });

    it('should filter by date', async () => {
      await createTestAppointment();
      await createTestAppointment();

      const result = await appointmentRepository.findAll(1, 20, { date: '2026-12-20' });

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should filter by doctorId', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id });

      const result = await appointmentRepository.findAll(1, 20, { doctorId });

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should filter by clinicId', async () => {
      const patient = await createUniquePatient();
      await createTestAppointment({ patientId: patient.id, clinicId });

      const result = await appointmentRepository.findAll(1, 20, { clinicId });

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should filter by status', async () => {
      await createTestAppointment({ status: 'CONFIRMED' });
      await createTestAppointment({ status: 'PENDING' });

      const result = await appointmentRepository.findAll(1, 20, { status: 'CONFIRMED' });

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(result.appointments[0]?.status).toBe('CONFIRMED');
    });

    it('should apply multiple filters together', async () => {
      await createTestAppointment({
        clinicId,
        status: 'CONFIRMED',
      });
      await createTestAppointment({
        clinicId,
        status: 'PENDING',
      });

      const result = await appointmentRepository.findAll(1, 20, {
        clinicId,
        status: 'CONFIRMED',
        date: '2026-12-20',
      });

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(result.appointments[0]?.clinicId).toBe(clinicId);
      expect(result.appointments[0]?.status).toBe('CONFIRMED');
    });

    it('should use custom pagination', async () => {
      for (let i = 0; i < 5; i++) {
        await createTestAppointment();
      }

      const result = await appointmentRepository.findAll(2, 2);

      expect(result.appointments).toHaveLength(2);
      expect(result.total).toBe(5);
    });

    it('should handle empty result set', async () => {
      const result = await appointmentRepository.findAll(999, 10);

      expect(result.appointments).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // updateStatus
  // ============================================================

  describe('updateStatus', () => {
    it('should update appointment status', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });

      const result = await appointmentRepository.updateStatus(appointment.id, 'CONFIRMED');

      expect(result.status).toBe('CONFIRMED');

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.status).toBe('CONFIRMED');
    });

    it('should update status with extra data', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });
      const confirmedAt = new Date();

      const result = await appointmentRepository.updateStatus(appointment.id, 'CONFIRMED', {
        confirmedAt,
        confirmedBy: doctorId,
      });

      expect(result.status).toBe('CONFIRMED');
      expect(result.confirmedAt).toBeDefined();
      expect(result.confirmedBy).toBe(doctorId);

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.confirmedAt).toBeDefined();
      expect(updated?.confirmedBy).toBe(doctorId);
    });

    it('should update to CANCELLED status with extra data', async () => {
      const appointment = await createTestAppointment({ status: 'PENDING' });
      const cancelledAt = new Date();

      const result = await appointmentRepository.updateStatus(appointment.id, 'CANCELLED', {
        cancelledAt,
        cancelledBy: appointment.patientId,
        cancelReason: 'Patient request',
      });

      expect(result.status).toBe('CANCELLED');
      expect(result.cancelledAt).toBeDefined();
      expect(result.cancelledBy).toBe(appointment.patientId);
      expect(result.cancelReason).toBe('Patient request');

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.status).toBe('CANCELLED');
      expect(updated?.cancelReason).toBe('Patient request');
    });

    it('should update to NO_SHOW status', async () => {
      const appointment = await createTestAppointment({ status: 'CONFIRMED' });

      const result = await appointmentRepository.updateStatus(appointment.id, 'NO_SHOW');

      expect(result.status).toBe('NO_SHOW');

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.status).toBe('NO_SHOW');
    });

    it('should update to COMPLETED status', async () => {
      const appointment = await createTestAppointment({ status: 'IN_PROGRESS' });

      const result = await appointmentRepository.updateStatus(appointment.id, 'COMPLETED');

      expect(result.status).toBe('COMPLETED');

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.status).toBe('COMPLETED');
    });

    it('should update to IN_PROGRESS status', async () => {
      const appointment = await createTestAppointment({ status: 'CONFIRMED' });

      const result = await appointmentRepository.updateStatus(appointment.id, 'IN_PROGRESS');

      expect(result.status).toBe('IN_PROGRESS');

      const updated = await prisma.appointment.findUnique({
        where: { id: appointment.id },
      });
      expect(updated?.status).toBe('IN_PROGRESS');
    });
  });

  // ============================================================
  // Edge Cases
  // ============================================================

  describe('Edge Cases', () => {
    it('should handle findById with invalid id gracefully', async () => {
      const result = await appointmentRepository.findById('');
      expect(result).toBeNull();
    });

    it('should handle findBySlotId with invalid slot id', async () => {
      const result = await appointmentRepository.findBySlotId('');
      expect(result).toBeNull();
    });

    it('should handle create with guest patient and no patientId', async () => {
      const slot = await createUniqueSlot();
      const data = {
        slotId: slot.id,
        doctorId,
        patientId: undefined as string | undefined,
        guestPatientId,
        patientType: 'GUEST' as const,
        paymentMethod: 'ON_SITE' as const,
        createdBy: doctorId,
        createdByType: 'doctor',
      };

      const result = await appointmentRepository.create(data as any);

      appointmentIds.push(result.id);

      expect(result.patientId).toBeNull();
      expect(result.guestPatientId).toBe(guestPatientId);
      expect(result.patientType).toBe('GUEST');
    });

    it('should handle create with contactUserId', async () => {
      const patient = await createUniquePatient();
      const slot = await createUniqueSlot();
      // Create a contact user first
      const contactUser = await prisma.contactUser.create({
        data: {
          userId: patient.id,
          firstName: 'Contact',
          lastName: 'User',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          dateOfBirth: new Date('1990-01-01'),
          relationship: 'friend',
        },
      });
      contactUserIds.push(contactUser.id);

      const data = {
        slotId: slot.id,
        doctorId,
        patientId: patient.id,
        contactUserId: contactUser.id,
        createdBy: patient.id,
        createdByType: 'user',
      };

      const result = await appointmentRepository.create(data);

      appointmentIds.push(result.id);

      expect(result.contactUserId).toBe(contactUser.id);
    });

    it('should handle findAll with empty filters', async () => {
      await createTestAppointment();

      const result = await appointmentRepository.findAll(1, 20, {});

      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });
  });
});

