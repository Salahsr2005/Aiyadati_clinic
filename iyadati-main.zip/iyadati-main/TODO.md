a surface that has main buttons to what actions there is

Reserve appointment
Search for a home nurse
Search for a home doctor
Search for a drug
E-Store -> 1/opticien 2/parafarme 
Services


