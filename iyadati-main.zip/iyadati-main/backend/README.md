Iyadati Backend API
A production-grade Express.js API with TypeScript, Prisma ORM, Joi validation, rate limiting, event-driven audit logging, and Swagger documentation.

🚀 Quick Start
bash
# Install dependencies
npm install

# Set up environment
cp .env.example .env

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate dev --name init

# Seed the database (creates Super Admin)
npm run prisma:seed

# Start development server
npm run dev
Server runs at http://localhost:3975
Swagger docs at http://localhost:3975/api/docs

Default Super Admin:

Email: superadmin@gmail.com

Password: kolnhbdasgjejoefskn

📁 Project Structure
text
src/
├── app.ts                          # Express app setup & middleware
├── server.ts                       # Entry point - starts HTTP server
├── config/                         # Application configuration
│   ├── env.ts                      # Environment variables (single source of truth)
│   ├── swagger.ts                  # OpenAPI/Swagger specification
│   ├── swagger-ui.ts              # Swagger UI options & customization
│   ├── swagger-theme.ts           # Custom CSS (sidebar, dark mode, purple theme)
│   └── swagger-custom-js.ts       # Sidebar navigation & export buttons JS
├── core/                           # Core application logic (shared across modules)
│   ├── events/                     # Event system for async operations
│   │   ├── event-emitter.ts        # Singleton EventEmitter
│   │   ├── register-listeners.ts   # Register all event listeners
│   │   └── listeners/
│   │       └── audit.listener.ts   # Audit log event listener
│   ├── middleware/                  # Express middleware
│   │   ├── errorHandler.middleware.ts  # Global error handling (logs only in dev)
│   │   ├── auth.middleware.ts          # JWT authentication (cookie + bearer)
│   │   ├── authorize.middleware.ts     # Role-based authorization
│   │   └── rateLimit.middleware.ts     # Dynamic rate limiter factory
│   ├── types/                      # TypeScript type definitions
│   │   ├── response.types.ts       # API response type interfaces
│   │   └── express.d.ts           # Express Request augmentation (req.user)
│   └── utils/                      # Shared utilities
│       ├── error.ts                # AppError classes (base + specific errors)
│       ├── logger.ts               # Winston logger (debug in dev, info in prod)
│       ├── prisma.ts              # Prisma client singleton (query logging in dev)
│       ├── response.ts            # ResponseUtil (success/error/paginated responses)
│       └── email.ts               # Nodemailer email sender (Mailtrap)
├── repositories/                   # Data access layer (Prisma CRUD operations)
│   ├── super-admin.repository.ts   # SuperAdmin database queries
│   └── admin.repository.ts         # Admin database queries
└── modules/                        # Feature modules (business logic)
    ├── health/                     # Health check module
    │   ├── health.module.ts
    │   └── v1/
    ├── auth/                       # Authentication module
    │   ├── auth.module.ts
    │   └── v1/
    └── admin/                      # Admin management module
        ├── admin.module.ts
        └── v1/
🔧 Core Utilities
Environment Configuration (src/config/env.ts)
Centralized, type-safe access to environment variables. Use this instead of process.env everywhere:

typescript
import { env } from '../config/env';

// Environment checks
if (env.isDevelopment) { ... }
if (env.isProduction) { ... }

// Typed values with defaults
const port = env.PORT;           // number, defaults to 3975
const dbUrl = env.DATABASE_URL;   // string
const nodeEnv = env.NODE_ENV;    // 'development' | 'production' | 'test'
File	Usage
server.ts	env.PORT for server port
errorHandler.middleware.ts	env.isDevelopment to control error logging
prisma.ts	env.isDevelopment to control query logging
logger.ts	env.isDevelopment to set log level
rateLimit.middleware.ts	env.isDevelopment to multiply rate limits by 100
Error Handling (src/core/utils/error.ts)
All errors extend the base AppError class with HTTP status codes:

typescript
throw new NotFoundError('User');
throw new ValidationError('Invalid input', [{ field: 'email', message: 'Required' }]);
throw new UnauthorizedError('Invalid credentials');
throw new ForbiddenError('Admin access required');
throw new ConflictError('Email already exists');
throw new DatabaseError('Connection failed');
throw new RateLimitError('Too many requests');
Class	Status Code	Use Case
BadRequestError	400	Malformed requests
ValidationError	400	Invalid input data
UnauthorizedError	401	Missing/invalid authentication
ForbiddenError	403	Authenticated but no permission
NotFoundError	404	Resource doesn't exist
ConflictError	409	Duplicate/conflicting data
RateLimitError	429	Too many requests
DatabaseError	500	Database operation failures
Operational vs Non-Operational:

Operational (isOperational: true): Expected errors - returned to client

Non-operational (isOperational: false): Programming bugs - automatically logged

Response Formatting (src/core/utils/response.ts)
ResponseUtil provides consistent JSON responses:

typescript
import { ResponseUtil } from '../core/utils/response';

// Success responses
ResponseUtil.success(res, data, 'Message', 200);
ResponseUtil.created(res, data, 'Created');
ResponseUtil.noContent(res);
ResponseUtil.paginated(res, items, total, page, limit);

// Error responses
ResponseUtil.badRequest(res, 'Message', errors);
ResponseUtil.unauthorized(res, 'Message');
ResponseUtil.forbidden(res, 'Message');
ResponseUtil.notFound(res, 'Resource not found');
ResponseUtil.conflict(res, 'Message', errors);
ResponseUtil.validationError(res, 'Message', errors);
ResponseUtil.tooManyRequests(res, 'Message');
Success Response Format:

json
{
  "success": true,
  "message": "Health check completed",
  "data": { ... },
  "meta": {
    "timestamp": "2024-06-11T13:29:25.000Z"
  }
}
Error Response Format:

json
{
  "success": false,
  "message": "Validation failed",
  "error": "Validation failed",
  "errors": [
    { "field": "status", "message": "Status is required" }
  ],
  "meta": {
    "timestamp": "2024-06-11T13:29:25.000Z"
  }
}
Logging (src/core/utils/logger.ts)
Winston logger with environment-aware log levels:

typescript
import { logger } from '../core/utils/logger';

logger.debug('Detailed info');     // Only in development
logger.info('Server started');     // Always
logger.warn('Rate limit reached'); // Always
logger.error('Database failed', { error }); // Always
Environment	Log Level	What's Logged
Development	debug	Everything
Production	info	info, warn, error only
🗄️ Repositories (Data Access Layer)
Repositories handle all Prisma database operations. Services call repositories, never Prisma directly.

typescript
import { adminRepository } from '../repositories/admin.repository';

// Available methods:
adminRepository.findById(id)
adminRepository.findByEmail(email)
adminRepository.create(data)
adminRepository.update(id, data)
adminRepository.delete(id)
adminRepository.findAll(page, limit)
adminRepository.updatePassword(id, hashedPassword)
adminRepository.emailExists(email, excludeId?)
Why repositories?

Single source of truth for database queries

Easy to change database logic without touching services

Testable - mock the repository, not Prisma

📡 Event System (Audit Logging)
Event-driven architecture for non-blocking side effects. Events are emitted during operations and processed asynchronously - they never slow down API responses.

How it works:
text
Request → Controller → Service → DB operation
                                ↓
                          eventEmitter.emit('audit', {...})  ← Non-blocking (0.001ms)
                                ↓
                          Response sent to client ← Fast!
                                ↓
                          Event loop picks up callback
                                ↓
                          Writes to AuditLog table ← Async, doesn't affect response
Files:
File	Purpose
core/events/event-emitter.ts	Singleton EventEmitter instance
core/events/listeners/audit.listener.ts	Listens for 'audit' events, writes to DB
core/events/register-listeners.ts	Registers all listeners on startup
Usage in services:
typescript
import { eventEmitter } from '../core/events/event-emitter';

// After creating an admin:
eventEmitter.emit('audit', {
  action: 'admin.created',
  entity: 'Admin',
  entityId: admin.id,
  performedBy: createdBy,
  details: { email: admin.email, name: admin.name },
  ip: requestIp,
});
Audit log actions:
Action	When
admin.created	Super Admin creates a new admin
admin.updated	Super Admin updates an admin
admin.deleted	Super Admin deletes an admin
Memory impact:
One singleton EventEmitter (~2KB)

One listener function per event type

Callbacks are queued and freed after execution

Negligible memory footprint

🛡️ Middleware
Authentication (auth.middleware.ts)
Verifies JWT from cookie (web) or Authorization header (mobile):

typescript
import { authenticate } from '../core/middleware/auth.middleware';

router.use(authenticate);
// req.user is now available: { id, email, name, role }
Authorization (authorize.middleware.ts)
Restricts access by role:

typescript
import { authorize } from '../core/middleware/authorize.middleware';

router.use(authenticate, authorize('SUPER_ADMIN'));  // Only Super Admin
router.use(authenticate, authorize('SUPER_ADMIN', 'ADMIN')); // Multiple roles
Rate Limiting (rateLimit.middleware.ts)
Dynamic rate limiter factory - call it directly in routes with custom parameters:

typescript
import { createRateLimiter } from '../core/middleware/rateLimit.middleware';

// Auth - 10 attempts per 15 minutes
router.post('/login', createRateLimiter({ 
  windowMinutes: 15, 
  maxRequests: 10, 
  message: 'Too many login attempts' 
}), controller.login);

// Reports - 5 per hour
router.get('/reports', createRateLimiter({ 
  windowMinutes: 60, 
  maxRequests: 5 
}), controller.reports);

// Default - 100 per 15 minutes
router.get('/list', createRateLimiter(), controller.list);
Development vs Production:

Config	Development	Production
maxRequests: 10	1000 allowed	10 allowed
maxRequests: 100	10000 allowed	100 allowed
In development, limits are multiplied by 100 so you never hit them during testing. In production, real limits apply.

🔐 Authentication System
Dual authentication supporting both web (cookies) and mobile (Bearer tokens):

Client	Auth Method	Token Storage
Web	HTTP-only cookie	Automatic (browser)
Mobile	Bearer token	Secure storage (expo-secure-store)
Auth Endpoints:
Method	Endpoint	Auth	Description
POST	/api/v1/auth/v1/login	No	Login, returns token + sets cookie
POST	/api/v1/auth/v1/logout	No	Clears cookie
GET	/api/v1/auth/v1/me	Yes	Get current user
Roles:
Role	Description
SUPER_ADMIN	Full access, can manage admins
ADMIN	Limited access (configurable via adminRole)
📦 API Endpoints
Health Module
Method	Endpoint	Description
GET	/api/v1/health/v1	Full system health status
POST	/api/v1/health/v1/check	Create health check record
GET	/api/v1/health/v1/checks	Paginated health check history
DELETE	/api/v1/health/v1/cleanup	Cleanup old records
Auth Module
Method	Endpoint	Auth	Description
POST	/api/v1/auth/v1/login	No	Login (returns token + cookie)
POST	/api/v1/auth/v1/logout	No	Logout (clears cookie)
GET	/api/v1/auth/v1/me	Yes	Get current user
Admin Module (Super Admin only)
Method	Endpoint	Description
POST	/api/v1/admin/v1	Create admin
GET	/api/v1/admin/v1	List all admins (paginated)
GET	/api/v1/admin/v1/:id	Get admin by ID
PATCH	/api/v1/admin/v1/:id	Update admin
DELETE	/api/v1/admin/v1/:id	Delete admin
Documentation
Method	Endpoint	Description
GET	/api/docs	Swagger UI
GET	/api/docs.json	Raw OpenAPI spec
🗄️ Database
Models:
prisma
model HealthCheck { ... }   // System health records
model SuperAdmin { ... }    // Super admin accounts
model Admin { ... }         // Admin accounts
model AuditLog { ... }      // Event audit trail
Commands:
bash
npx prisma studio          # Open database GUI
npx prisma migrate dev     # Create and apply migrations
npx prisma db push         # Push schema without migrations
npx prisma generate        # Regenerate Prisma client
npm run prisma:seed        # Seed Super Admin account
🛠️ Available Scripts
bash
npm run dev            # Development server with hot reload
npm start              # Run compiled production build
npm run prisma:migrate # Run database migrations
npm run prisma:generate# Generate Prisma client
npm run prisma:seed    # Seed database
npm run clean          # Remove dist folder
🎨 Swagger Documentation
Auto-generated from JSDoc comments in *.swagger.ts files. Features:

Left sidebar with module navigation

Search to filter modules

Export buttons (endpoint, module, full documentation)

Dark/light mode

Purple theme

🚦 Error Handling Flow
Service throws AppError

Controller catches via next(error)

Global error handler:

Development: Logs full details

Production: Silent, hides internals

Handles Prisma errors (P2002, P2003, P2025)

Handles custom AppError instances

Handles JWT errors

Returns consistent JSON error responses

📝 Adding a New Module
Create folder: src/modules/[name]/v1/

Create files: types.ts, validation.ts, service.ts, controller.ts, routes.ts, swagger.ts, module.ts

Create repository: src/repositories/[name].repository.ts

Register in src/app.ts: v1Router.use('/name', nameModule);

Add rate limiting in routes: createRateLimiter({ ... })

Add audit events in service: eventEmitter.emit('audit', { ... })

