import type { Config } from "jest";

const config: Config = {
  displayName: "unit",

  preset: "ts-jest",

  testEnvironment: "node",

  rootDir: ".",

  testMatch: [
    "<rootDir>/tests/unit/**/*.test.ts",
  ],

  setupFilesAfterEnv: [
    "<rootDir>/tests/setup/setupAfterEnv.ts",
  ],

  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
  },

  transform: {
    "^.+\\.tsx?$": [
      "ts-jest",
      {
        tsconfig: "<rootDir>/tsconfig.test.json",
      },
    ],
  },
};

export default config;

