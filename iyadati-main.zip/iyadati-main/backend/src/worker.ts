import { logger } from './core/utils/logger';
import './infrastructure/queues/workers';

logger.info('Background workers started.');

