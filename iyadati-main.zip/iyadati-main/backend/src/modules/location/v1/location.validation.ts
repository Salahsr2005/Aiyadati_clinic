import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createBaladyaSchema = Joi.object({
  nameFr: Joi.string()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.min': 'French name must be at least 2 characters',
      'string.max': 'French name must be less than 100 characters',
      'any.required': 'French name is required',
    }),
  nameAr: Joi.string()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.min': 'Arabic name must be at least 2 characters',
      'string.max': 'Arabic name must be less than 100 characters',
      'any.required': 'Arabic name is required',
    }),
});

const updateBaladyaSchema = Joi.object({
  nameFr: Joi.string()
    .min(2)
    .max(100)
    .optional()
    .messages({
      'string.min': 'French name must be at least 2 characters',
      'string.max': 'French name must be less than 100 characters',
    }),
  nameAr: Joi.string()
    .min(2)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Arabic name must be at least 2 characters',
      'string.max': 'Arabic name must be less than 100 characters',
    }),
}).min(1);

export const validateCreateBaladya = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createBaladyaSchema.validate(req.body, { abortEarly: false });

  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }

  next();
};

export const validateUpdateBaladya = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateBaladyaSchema.validate(req.body, { abortEarly: false });

  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }

  next();
};

