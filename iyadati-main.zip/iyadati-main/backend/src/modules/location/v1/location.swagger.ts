/**
 * @swagger
 * tags:
 *   name: Location
 *   description: Wilayas and Baladyat endpoints with multilingual support
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     WilayaResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         code:
 *           type: integer
 *           example: 16
 *         name:
 *           type: string
 *           description: Localized name based on lang parameter
 *           example: "Algiers"
 *         nameFr:
 *           type: string
 *           example: "Algiers"
 *         nameAr:
 *           type: string
 *           example: "الجزائر"
 *         baladyatCount:
 *           type: integer
 *           example: 57
 *     
 *     WilayaDetailResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         code:
 *           type: integer
 *         name:
 *           type: string
 *           description: Localized name based on lang parameter
 *         nameFr:
 *           type: string
 *         nameAr:
 *           type: string
 *         baladyat:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/BaladyaResponse'
 *     
 *     BaladyaResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         name:
 *           type: string
 *           description: Localized name based on lang parameter
 *           example: "Bab El Oued"
 *         nameFr:
 *           type: string
 *           example: "Bab El Oued"
 *         nameAr:
 *           type: string
 *           example: "باب الوادي"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *     
 *     CreateBaladyaRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "Bab El Oued"
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "باب الوادي"
 *     
 *     UpdateBaladyaRequest:
 *       type: object
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "New District"
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "المنطقة الجديدة"
 */

/**
 * @swagger
 * /api/v1/location/v1/wilayas:
 *   get:
 *     summary: Get all wilayas
 *     description: Returns all wilayas with baladya counts. Supports language parameter.
 *     tags: [Location]
 *     parameters:
 *       - in: query
 *         name: lang
 *         schema:
 *           type: string
 *           enum: [fr, ar]
 *           default: fr
 *         description: Language for the response
 *     responses:
 *       200:
 *         description: Wilayas retrieved successfully
 */

/**
 * @swagger
 * /api/v1/location/v1/wilayas/{id}:
 *   get:
 *     summary: Get wilaya by ID with baladyat
 *     description: Returns a single wilaya with all its baladyat. Supports language parameter.
 *     tags: [Location]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: lang
 *         schema:
 *           type: string
 *           enum: [fr, ar]
 *           default: fr
 *     responses:
 *       200:
 *         description: Wilaya retrieved successfully
 *       404:
 *         description: Wilaya not found
 */

/**
 * @swagger
 * /api/v1/location/v1/wilayas/{wilayaId}/baladyat:
 *   get:
 *     summary: Get all baladyat for a wilaya
 *     description: Returns all baladyat in the specified wilaya. Supports language parameter.
 *     tags: [Location]
 *     parameters:
 *       - in: path
 *         name: wilayaId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: lang
 *         schema:
 *           type: string
 *           enum: [fr, ar]
 *           default: fr
 *     responses:
 *       200:
 *         description: Baladyat retrieved successfully
 *       404:
 *         description: Wilaya not found
 *
 *   post:
 *     summary: Add a baladya to a wilaya
 *     description: Creates a new baladya. Requires authentication (SUPER_ADMIN or ADMIN).
 *     tags: [Location]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: wilayaId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateBaladyaRequest'
 *     responses:
 *       201:
 *         description: Baladya created successfully
 *       400:
 *         description: Validation error
 *       401:
 *         description: Not authenticated
 *       404:
 *         description: Wilaya not found
 *       409:
 *         description: Baladya already exists
 */

/**
 * @swagger
 * /api/v1/location/v1/baladyat/{id}:
 *   get:
 *     summary: Get baladya by ID
 *     description: Returns a single baladya. Supports language parameter.
 *     tags: [Location]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: lang
 *         schema:
 *           type: string
 *           enum: [fr, ar]
 *           default: fr
 *     responses:
 *       200:
 *         description: Baladya retrieved successfully
 *       404:
 *         description: Baladya not found
 *
 *   put:
 *     summary: Update a baladya
 *     description: Updates an existing baladya. Requires authentication (SUPER_ADMIN or ADMIN).
 *     tags: [Location]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateBaladyaRequest'
 *     responses:
 *       200:
 *         description: Baladya updated successfully
 *       400:
 *         description: Validation error
 *       401:
 *         description: Not authenticated
 *       404:
 *         description: Baladya not found
 *       409:
 *         description: Name conflict in this wilaya
 */

