import { wilayaRepository } from '../../../repositories/wilaya.repository';
import { NotFoundError, ConflictError } from '../../../core/utils/error';
import { 
  WilayaResponse, 
  WilayaDetailResponse, 
  BaladyaResponse, 
  CreateBaladyaDTO,
  UpdateBaladyaDTO,
} from './location.types';

export class LocationService {
  /**
   * Get all wilayas with baladya counts
   */
  async getWilayas(lang?: 'fr' | 'ar'): Promise<WilayaResponse[]> {
    const wilayas = await wilayaRepository.findAll();

    return wilayas.map((w) => ({
      id: w.id,
      code: w.code,
      nameFr: w.nameFr,
      nameAr: w.nameAr,
      baladyatCount: (w as any)._count?.baladyat || 0,
    }));
  }

  /**
   * Get wilaya by ID with baladyat
   */
  async getWilayaById(id: string, lang?: 'fr' | 'ar'): Promise<WilayaDetailResponse> {
    const wilaya = await wilayaRepository.findById(id);
    if (!wilaya) {
      throw new NotFoundError('Wilaya');
    }

    return {
      id: wilaya.id,
      code: wilaya.code,
      nameFr: wilaya.nameFr,
      nameAr: wilaya.nameAr,
      baladyat: wilaya.baladyat.map((b: any) => ({
        id: b.id,
        nameFr: b.nameFr,
        nameAr: b.nameAr,
        wilayaId: b.wilayaId,
      })),
    };
  }

  /**
   * Get all baladyat for a wilaya
   */
  async getBaladyatByWilayaId(wilayaId: string, lang?: 'fr' | 'ar'): Promise<BaladyaResponse[]> {
    const wilaya = await wilayaRepository.findById(wilayaId);
    if (!wilaya) {
      throw new NotFoundError('Wilaya');
    }

    const baladyat = await wilayaRepository.findBaladyatByWilayaId(wilayaId);
    
    return baladyat.map((b) => ({
      id: b.id,
      nameFr: b.nameFr,
      nameAr: b.nameAr,
      wilayaId: b.wilayaId,
    }));
  }

  /**
   * Get a single baladya by ID
   */
  async getBaladyaById(id: string): Promise<BaladyaResponse> {
    const baladya = await wilayaRepository.findBaladyaById(id);
    if (!baladya) {
      throw new NotFoundError('Baladya');
    }

    return {
      id: baladya.id,
      nameFr: baladya.nameFr,
      nameAr: baladya.nameAr,
      wilayaId: baladya.wilayaId,
    };
  }

  /**
   * Add a baladya to a wilaya
   */
  async addBaladya(wilayaId: string, data: CreateBaladyaDTO): Promise<BaladyaResponse> {
    const wilaya = await wilayaRepository.findById(wilayaId);
    if (!wilaya) {
      throw new NotFoundError('Wilaya');
    }

    // Check if French name already exists in this wilaya
    const frNameExists = await wilayaRepository.checkBaladyaNameExistsInWilaya(
      wilayaId, 
      data.nameFr
    );
    if (frNameExists) {
      throw new ConflictError('Baladya with this French name already exists in this wilaya');
    }

    // Check if Arabic name already exists in this wilaya
    const arNameExists = await wilayaRepository.checkBaladyaArNameExistsInWilaya(
      wilayaId, 
      data.nameAr
    );
    if (arNameExists) {
      throw new ConflictError('Baladya with this Arabic name already exists in this wilaya');
    }

    try {
      const baladya = await wilayaRepository.createBaladya({
        nameFr: data.nameFr,
        nameAr: data.nameAr,
        wilayaId: wilayaId,
      });

      return {
        id: baladya.id,
        nameFr: baladya.nameFr,
        nameAr: baladya.nameAr,
        wilayaId: baladya.wilayaId,
      };
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ConflictError('Baladya with this name already exists in this wilaya');
      }
      throw error;
    }
  }

  /**
   * Update a baladya
   */
  async updateBaladya(id: string, data: UpdateBaladyaDTO): Promise<BaladyaResponse> {
    const baladya = await wilayaRepository.findBaladyaById(id);
    if (!baladya) {
      throw new NotFoundError('Baladya');
    }

    // Check if French name conflicts
    if (data.nameFr && data.nameFr !== baladya.nameFr) {
      const frNameExists = await wilayaRepository.checkBaladyaNameExistsInWilaya(
        baladya.wilayaId, 
        data.nameFr,
        id
      );
      if (frNameExists) {
        throw new ConflictError('Baladya with this French name already exists in this wilaya');
      }
    }

    // Check if Arabic name conflicts
    if (data.nameAr && data.nameAr !== baladya.nameAr) {
      const arNameExists = await wilayaRepository.checkBaladyaArNameExistsInWilaya(
        baladya.wilayaId, 
        data.nameAr,
        id
      );
      if (arNameExists) {
        throw new ConflictError('Baladya with this Arabic name already exists in this wilaya');
      }
    }

    try {
      const updatedBaladya = await wilayaRepository.updateBaladya(id, data);
      
      return {
        id: updatedBaladya.id,
        nameFr: updatedBaladya.nameFr,
        nameAr: updatedBaladya.nameAr,
        wilayaId: updatedBaladya.wilayaId,
      };
    } catch (error: any) {
      throw error;
    }
  }
}

export const locationService = new LocationService();

