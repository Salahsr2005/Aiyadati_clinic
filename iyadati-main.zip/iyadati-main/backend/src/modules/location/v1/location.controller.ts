import { Request, Response, NextFunction } from 'express';
import { locationService } from './location.service';
import { ResponseUtil } from '../../../core/utils/response';

export class LocationController {
  /**
   * GET /api/v1/location/v1/wilayas?lang=fr|ar
   */
  getWilayas = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const lang = req.query.lang as 'fr' | 'ar' || 'fr';
      const wilayas = await locationService.getWilayas(lang);
      
      const transformedWilayas = wilayas.map(w => ({
        id: w.id,
        code: w.code,
        name: lang === 'ar' ? w.nameAr : w.nameFr,
        nameFr: w.nameFr,
        nameAr: w.nameAr,
        baladyatCount: w.baladyatCount,
      }));
      
      ResponseUtil.success(res, transformedWilayas, 'Wilayas retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * GET /api/v1/location/v1/wilayas/:id?lang=fr|ar
   */
  getWilayaById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const lang = req.query.lang as 'fr' | 'ar' || 'fr';
      const wilaya = await locationService.getWilayaById(req.params.id, lang);
      
      const transformedBaladyat = wilaya.baladyat.map(b => ({
        id: b.id,
        name: lang === 'ar' ? b.nameAr : b.nameFr,
        nameFr: b.nameFr,
        nameAr: b.nameAr,
        wilayaId: b.wilayaId,
      }));
      
      const response = {
        id: wilaya.id,
        code: wilaya.code,
        name: lang === 'ar' ? wilaya.nameAr : wilaya.nameFr,
        nameFr: wilaya.nameFr,
        nameAr: wilaya.nameAr,
        baladyat: transformedBaladyat,
      };
      
      ResponseUtil.success(res, response, 'Wilaya retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * GET /api/v1/location/v1/wilayas/:wilayaId/baladyat?lang=fr|ar
   */
  getBaladyatByWilayaId = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const lang = req.query.lang as 'fr' | 'ar' || 'fr';
      const baladyat = await locationService.getBaladyatByWilayaId(req.params.wilayaId, lang);
      
      const transformedBaladyat = baladyat.map(b => ({
        id: b.id,
        name: lang === 'ar' ? b.nameAr : b.nameFr,
        nameFr: b.nameFr,
        nameAr: b.nameAr,
        wilayaId: b.wilayaId,
      }));
      
      ResponseUtil.success(res, transformedBaladyat, 'Baladyat retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * GET /api/v1/location/v1/baladyat/:id?lang=fr|ar
   */
  getBaladyaById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const lang = req.query.lang as 'fr' | 'ar' || 'fr';
      const baladya = await locationService.getBaladyaById(req.params.id);
      
      const response = {
        id: baladya.id,
        name: lang === 'ar' ? baladya.nameAr : baladya.nameFr,
        nameFr: baladya.nameFr,
        nameAr: baladya.nameAr,
        wilayaId: baladya.wilayaId,
      };
      
      ResponseUtil.success(res, response, 'Baladya retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * POST /api/v1/location/v1/wilayas/:wilayaId/baladyat
   */
  addBaladya = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const baladya = await locationService.addBaladya(req.params.wilayaId, req.body);
      ResponseUtil.created(res, {
        id: baladya.id,
        nameFr: baladya.nameFr,
        nameAr: baladya.nameAr,
        wilayaId: baladya.wilayaId,
      }, 'Baladya added successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * PUT /api/v1/location/v1/baladyat/:id
   */
  updateBaladya = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const baladya = await locationService.updateBaladya(req.params.id, req.body);
      ResponseUtil.success(res, {
        id: baladya.id,
        nameFr: baladya.nameFr,
        nameAr: baladya.nameAr,
        wilayaId: baladya.wilayaId,
      }, 'Baladya updated successfully');
    } catch (error) {
      next(error);
    }
  };
}

