export interface WilayaResponse {
  id: string;
  code: number;
  nameFr: string;
  nameAr: string;
  baladyatCount?: number;
}

export interface WilayaDetailResponse {
  id: string;
  code: number;
  nameFr: string;
  nameAr: string;
  baladyat: BaladyaResponse[];
}

export interface BaladyaResponse {
  id: string;
  nameFr: string;
  nameAr: string;
  wilayaId: string;
}

export interface CreateBaladyaDTO {
  nameFr: string;
  nameAr: string;
}

export interface UpdateBaladyaDTO {
  nameFr?: string;
  nameAr?: string;
}

export interface GetWilayasQuery {
  lang?: 'fr' | 'ar';
}

export interface GetWilayaByIdQuery {
  lang?: 'fr' | 'ar';
}

export interface GetBaladyatQuery {
  lang?: 'fr' | 'ar';
}

