import { Router } from 'express';
import { LocationController } from './location.controller';
import { validateCreateBaladya, validateUpdateBaladya } from './location.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const locationController = new LocationController();

// Public routes
router.get('/wilayas', locationController.getWilayas);
router.get('/wilayas/:id', locationController.getWilayaById);
router.get('/wilayas/:wilayaId/baladyat', locationController.getBaladyatByWilayaId);
router.get('/baladyat/:id', locationController.getBaladyaById);

// Admin only routes
router.post(
  '/wilayas/:wilayaId/baladyat',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateBaladya,
  locationController.addBaladya
);

router.put(
  '/baladyat/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateBaladya,
  locationController.updateBaladya
);

export default router;

