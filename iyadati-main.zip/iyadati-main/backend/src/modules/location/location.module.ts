import { Router } from 'express';
import locationRoutes from './v1/location.routes';
import './v1/location.swagger';

const router = Router();

router.use('/v1', locationRoutes);

export { router as locationModule };

