import { Router } from 'express';
import creditRoutes from './v1/credit.routes';

const router = Router();
router.use('/v1', creditRoutes);

export { router as creditModule };

