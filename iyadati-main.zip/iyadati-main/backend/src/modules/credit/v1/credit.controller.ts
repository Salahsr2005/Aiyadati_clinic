import { Request, Response, NextFunction } from 'express';
import { creditService } from './credit.service';
import { ResponseUtil } from '../../../core/utils/response';

export class CreditController {
  async getCurrentPrice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const result = await creditService.getCurrentPrice();
      ResponseUtil.success(res, result, 'Current credit price retrieved');
    } catch (error) {
      next(error);
    }
  }

  async updatePrice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { price } = req.body;
      const result = await creditService.updatePrice(
        price,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, result, 'Credit price updated successfully');
    } catch (error) {
      next(error);
    }
  }

  async getPriceHistory(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const history = await creditService.getPriceHistory(limit);
      ResponseUtil.success(res, history, 'Price history retrieved');
    } catch (error) {
      next(error);
    }
  }

  async getAllPrices(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const prices = await creditService.getAllPrices();
      ResponseUtil.success(res, prices, 'All credit prices retrieved');
    } catch (error) {
      next(error);
    }
  }
}

