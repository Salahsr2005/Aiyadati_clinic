// backend/src/modules/credit/v1/credit.service.ts
import { creditPriceRepository } from '../../../repositories/credit-price.repository';
import { auditLogRepository } from '../../../repositories/audit-log.repository';
import { BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { 
  CurrentPriceResponse, 
  UpdatePriceResponse,
  CreditPriceHistoryResponse 
} from './credit.types';

export class CreditService {
  async getCurrentPrice(): Promise<CurrentPriceResponse> {
    const latest = await creditPriceRepository.getLatest();
    return {
      price: latest.price,
      updatedAt: latest.updatedAt
    };
  }

  async getPriceHistory(limit: number = 10): Promise<CreditPriceHistoryResponse[]> {
    const history = await creditPriceRepository.getHistory(limit);
    return history.map(item => ({
      id: item.id,
      price: item.price,
      createdAt: item.createdAt.toISOString(),
      updatedAt: item.updatedAt.toISOString()
    }));
  }

  async updatePrice(price: number, performedBy: string, ip?: string): Promise<UpdatePriceResponse> {
    // Validate price
    if (price < 1) {
      throw new BadRequestError('Price must be at least 1 DZD');
    }
    if (price > 10000) {
      throw new BadRequestError('Price cannot exceed 10000 DZD');
    }

    // Get old price for audit
    const oldPrice = await creditPriceRepository.getCurrentPrice();

    // Create new price record
    const newPrice = await creditPriceRepository.updatePrice(price);

    // Log audit
    await auditLogRepository.create({
      action: 'credit_price.updated',
      entity: 'CreditPrice',
      entityId: newPrice.id,
      performedBy,
      details: {
        oldPrice,
        newPrice: price,
        difference: price - oldPrice
      },
      ip
    });

    logger.info(`Credit price updated from ${oldPrice} to ${price} DZD by ${performedBy}`);

    return {
      oldPrice,
      newPrice: price,
      updatedAt: newPrice.updatedAt
    };
  }

  async getAllPrices(): Promise<any[]> {
    return await creditPriceRepository.getAll();
  }
}

export const creditService = new CreditService();

