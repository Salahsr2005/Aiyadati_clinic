// backend/src/modules/credit/v1/credit.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Credit
 *   description: Credit price management endpoints (Super Admin only)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     CreditPriceResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "123e4567-e89b-12d3-a456-426614174000"
 *           description: Unique identifier of the credit price record
 *         price:
 *           type: integer
 *           example: 500
 *           description: Price per credit in DZD
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *           description: Record creation timestamp
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *           description: Record last update timestamp
 *
 *     CurrentPriceResponse:
 *       type: object
 *       properties:
 *         price:
 *           type: integer
 *           example: 500
 *           description: Current price per credit in DZD
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *           description: When the current price was set
 *
 *     UpdatePriceRequest:
 *       type: object
 *       required:
 *         - price
 *       properties:
 *         price:
 *           type: integer
 *           minimum: 1
 *           maximum: 10000
 *           example: 600
 *           description: New price per credit in DZD (1-10000)
 *
 *     UpdatePriceResponse:
 *       type: object
 *       properties:
 *         oldPrice:
 *           type: integer
 *           example: 500
 *           description: Previous price before update
 *         newPrice:
 *           type: integer
 *           example: 600
 *           description: New price after update
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *           description: When the price was updated
 *
 *     CreditPriceHistoryResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "123e4567-e89b-12d3-a456-426614174000"
 *         price:
 *           type: integer
 *           example: 500
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-14T10:30:00.000Z"
 *
 *     ErrorResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: "Validation failed"
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: "price"
 *               message:
 *                 type: string
 *                 example: "Price must be at least 1 DZD"
 */

/**
 * @swagger
 * /api/v1/credit/v1/current:
 *   get:
 *     summary: Get current credit price
 *     description: Retrieves the current price per credit in DZD. This is the price users will pay when purchasing credits.
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     responses:
 *       200:
 *         description: Current credit price retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Current credit price retrieved"
 *                 data:
 *                   $ref: '#/components/schemas/CurrentPriceResponse'
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - User is not a Super Admin
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/credit/v1/:
 *   put:
 *     summary: Update credit price
 *     description: Updates the price per credit. Only Super Admin can perform this action. All changes are logged in audit logs.
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdatePriceRequest'
 *           example:
 *             price: 600
 *     responses:
 *       200:
 *         description: Credit price updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Credit price updated successfully"
 *                 data:
 *                   $ref: '#/components/schemas/UpdatePriceResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             examples:
 *               minError:
 *                 summary: Price too low
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "price"
 *                       message: "Price must be at least 1 DZD"
 *               maxError:
 *                 summary: Price too high
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "price"
 *                       message: "Price cannot exceed 10000 DZD"
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - User is not a Super Admin
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/credit/v1/history:
 *   get:
 *     summary: Get credit price change history
 *     description: Retrieves the history of credit price changes. Shows all previous prices with timestamps.
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of history records to return (max 100)
 *         example: 20
 *     responses:
 *       200:
 *         description: Price history retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Price history retrieved"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CreditPriceHistoryResponse'
 *               example:
 *                 success: true
 *                 message: "Price history retrieved"
 *                 data:
 *                   - id: "123e4567-e89b-12d3-a456-426614174000"
 *                     price: 600
 *                     createdAt: "2026-07-14T10:30:00.000Z"
 *                     updatedAt: "2026-07-14T10:30:00.000Z"
 *                   - id: "223e4567-e89b-12d3-a456-426614174001"
 *                     price: 500
 *                     createdAt: "2026-07-01T08:00:00.000Z"
 *                     updatedAt: "2026-07-01T08:00:00.000Z"
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - User is not a Super Admin
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/credit/v1/all:
 *   get:
 *     summary: Get all credit price records
 *     description: Retrieves all credit price records in the system. Useful for complete price history and auditing.
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     responses:
 *       200:
 *         description: All credit prices retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "All credit prices retrieved"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CreditPriceResponse'
 *               example:
 *                 success: true
 *                 message: "All credit prices retrieved"
 *                 data:
 *                   - id: "123e4567-e89b-12d3-a456-426614174000"
 *                     price: 600
 *                     createdAt: "2026-07-14T10:30:00.000Z"
 *                     updatedAt: "2026-07-14T10:30:00.000Z"
 *                   - id: "223e4567-e89b-12d3-a456-426614174001"
 *                     price: 500
 *                     createdAt: "2026-07-01T08:00:00.000Z"
 *                     updatedAt: "2026-07-01T08:00:00.000Z"
 *                   - id: "323e4567-e89b-12d3-a456-426614174002"
 *                     price: 450
 *                     createdAt: "2026-06-15T14:20:00.000Z"
 *                     updatedAt: "2026-06-15T14:20:00.000Z"
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - User is not a Super Admin
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *     cookieAuth:
 *       type: apiKey
 *       in: cookie
 *       name: token
 */

/**
 * @swagger
 * /api/v1/credit/v1/current:
 *   get:
 *     summary: Get current credit price
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: OK
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Admin or Super Admin required
 */

/**
 * @swagger
 * /api/v1/credit/v1/:
 *   put:
 *     summary: Update credit price
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - price
 *             properties:
 *               price:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 10000
 *                 example: 600
 *     responses:
 *       200:
 *         description: OK
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Admin or Super Admin required
 */

/**
 * @swagger
 * /api/v1/credit/v1/history:
 *   get:
 *     summary: Get price change history
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of records to return
 *     responses:
 *       200:
 *         description: OK
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Admin or Super Admin required
 */

/**
 * @swagger
 * /api/v1/credit/v1/all:
 *   get:
 *     summary: Get all price records
 *     tags: [Credit]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: OK
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Admin or Super Admin required
 */