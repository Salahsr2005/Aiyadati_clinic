// backend/src/modules/credit/v1/credit.validation.ts
import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const updateCreditPriceSchema = Joi.object({
  price: Joi.number().integer().min(1).max(10000).required().messages({
    'number.min': 'Price must be at least 1 DZD',
    'number.max': 'Price cannot exceed 10000 DZD',
    'any.required': 'Price is required'
  })
});

export const validateUpdateCreditPrice = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateCreditPriceSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

