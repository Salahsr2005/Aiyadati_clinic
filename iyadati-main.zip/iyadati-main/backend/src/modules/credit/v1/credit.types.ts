// backend/src/modules/credit/v1/credit.types.ts
export interface CreditPriceResponse {
  id: string;
  price: number;
  createdAt: string;
  updatedAt: string;
}

export interface CurrentPriceResponse {
  price: number;
  updatedAt: string;
}

export interface UpdateCreditPriceDTO {
  price: number;
}

export interface UpdatePriceResponse {
  oldPrice: number;
  newPrice: number;
  updatedAt: string;
}

export interface CreditPriceHistoryResponse {
  id: string;
  price: number;
  createdAt: string;
  updatedAt: string;
}

