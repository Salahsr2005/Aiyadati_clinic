import { Router } from 'express';
import { CreditController } from './credit.controller';
import { validateUpdateCreditPrice } from './credit.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new CreditController();

// Super Admin only routes
router.get(
  '/current',
  authenticate,
  authorize('SUPER_ADMIN'),
  controller.getCurrentPrice
);

router.put(
  '/',
  authenticate,
  authorize('SUPER_ADMIN'),
  validateUpdateCreditPrice,
  controller.updatePrice
);

router.get(
  '/history',
  authenticate,
  authorize('SUPER_ADMIN'),
  controller.getPriceHistory
);

router.get(
  '/all',
  authenticate,
  authorize('SUPER_ADMIN'),
  controller.getAllPrices
);

export default router;
