// src/modules/specialty/v1/specialty.controller.ts

import { Request, Response, NextFunction } from 'express';
import { specialtyService } from './specialty.service';
import { ResponseUtil } from '../../../core/utils/response';

export class SpecialtyController {
  findAll = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { specialties, total } = await specialtyService.findAll(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      ResponseUtil.paginated(res, specialties, total, page, limit, 'Specialties retrieved successfully');
    } catch (error) { next(error); }
  };

  findById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const specialty = await specialtyService.findById(req.params.id);
      ResponseUtil.success(res, specialty, 'Specialty retrieved successfully');
    } catch (error) { next(error); }
  };

  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const specialty = await specialtyService.create(req.body);
      ResponseUtil.created(res, specialty, 'Specialty created successfully');
    } catch (error) { next(error); }
  };

  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const specialty = await specialtyService.update(req.params.id, req.body);
      ResponseUtil.success(res, specialty, 'Specialty updated successfully');
    } catch (error) { next(error); }
  };

  delete = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await specialtyService.delete(req.params.id);
      ResponseUtil.success(res, null, 'Specialty deleted successfully');
    } catch (error) { next(error); }
  };

  restore = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const specialty = await specialtyService.restore(req.params.id);
      ResponseUtil.success(res, specialty, 'Specialty restored successfully');
    } catch (error) { next(error); }
  };

  // ✅ Like Doctor.uploadPhoto
  uploadImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { 
        ResponseUtil.badRequest(res, 'Image file is required'); 
        return; 
      }
      const specialty = await specialtyService.uploadImage(req.params.id, req.file);
      ResponseUtil.success(res, specialty, 'Image uploaded successfully');
    } catch (error) { next(error); }
  };
}

