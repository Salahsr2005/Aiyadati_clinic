import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createSpecialtySchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'French name must be at least 2 characters',
    'string.max': 'French name must be less than 100 characters',
    'any.required': 'French name is required',
  }),
  nameAr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Arabic name must be at least 2 characters',
    'string.max': 'Arabic name must be less than 100 characters',
    'any.required': 'Arabic name is required',
  }),
  descriptionFr: Joi.string().max(500).optional().allow(null, ''),
  descriptionAr: Joi.string().max(500).optional().allow(null, ''),
});

const updateSpecialtySchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).optional(),
  nameAr: Joi.string().min(2).max(100).optional(),
  descriptionFr: Joi.string().max(500).optional().allow(null, ''),
  descriptionAr: Joi.string().max(500).optional().allow(null, ''),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateSpecialty = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createSpecialtySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateSpecialty = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateSpecialtySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

