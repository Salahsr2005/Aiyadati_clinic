// src/modules/specialty/v1/specialty.types.ts

export interface CreateSpecialtyDTO {
  nameFr: string;
  nameAr: string;
  descriptionFr?: string;
  descriptionAr?: string;
}

export interface UpdateSpecialtyDTO {
  nameFr?: string;
  nameAr?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  imagePath?: string;
  fileId?: string;
  isActive?: boolean;
}

export interface SpecialtyResponse {
  id: string;
  nameFr: string;
  nameAr: string;
  descriptionFr: string | null;
  descriptionAr: string | null;
  imagePath: string | null;
  imageUrl: string | null;  // ✅ Secure URL
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

