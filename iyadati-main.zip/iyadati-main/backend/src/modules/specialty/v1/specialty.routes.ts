// src/modules/specialty/v1/specialty.routes.ts

import { Router } from 'express';
import { SpecialtyController } from './specialty.controller';
import { validateCreateSpecialty, validateUpdateSpecialty } from './specialty.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { uploadLogo } from '../../../core/middleware/upload.middleware';

const router = Router();
const specialtyController = new SpecialtyController();

// Public - anyone can view specialties
router.get('/', specialtyController.findAll);
router.get('/:id', specialtyController.findById);

// Staff only - manage specialties
router.post('/', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateCreateSpecialty, specialtyController.create);
router.patch('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateSpecialty, specialtyController.update);
router.delete('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), specialtyController.delete);
router.post('/:id/restore', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), specialtyController.restore);

// ✅ Upload image - like Doctor.uploadPhoto
router.post(
  '/:id/image',  // Single endpoint for image
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  uploadLogo,  // Uses 'logo' field
  specialtyController.uploadImage
);

export default router;

