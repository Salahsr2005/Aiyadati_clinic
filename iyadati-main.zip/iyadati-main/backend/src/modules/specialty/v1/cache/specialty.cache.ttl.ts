export const SpecialtyCacheTTL = {
  FIND_ALL: 60 * 60,
  FIND_BY_ID: 60 * 60,
} as const;