import { redisService } from '../../../../infrastructure/redis';

import { SpecialtyCacheKeys } from './specialty.cache.keys';
import { SpecialtyCacheTTL } from './specialty.cache.ttl';

const DEFAULT_VERSION = 0;

async function getVersion(): Promise<number> {
  const version = await redisService.getString(
    SpecialtyCacheKeys.version(),
  );

  return version
    ? Number(version)
    : DEFAULT_VERSION;
}

export const specialtyCache = {
  async rememberAll<T>(
    paramsKey: string,
    loader: () => Promise<T>,
  ) {
    const version = await getVersion();

    return redisService.remember(
      SpecialtyCacheKeys.all(
        version,
        paramsKey,
      ),
      SpecialtyCacheTTL.FIND_ALL,
      loader,
    );
  },

  rememberById<T>(
    id: string,
    loader: () => Promise<T>,
  ) {
    return redisService.remember(
      SpecialtyCacheKeys.byId(id),
      SpecialtyCacheTTL.FIND_BY_ID,
      loader,
    );
  },

  invalidateById(id: string) {
    return redisService.delete(
      SpecialtyCacheKeys.byId(id),
    );
  },

  invalidateAll() {
    return redisService.increment(
      SpecialtyCacheKeys.version(),
    );
  },

  async invalidate(id: string) {
    await Promise.all([
      this.invalidateById(id),
      this.invalidateAll(),
    ]);
  },
};

