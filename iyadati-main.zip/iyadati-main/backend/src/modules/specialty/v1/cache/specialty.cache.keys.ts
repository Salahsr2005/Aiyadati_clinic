export const SpecialtyCacheKeys = {
  version: () => 'specialties:version',

  all: (version: number, params: string) =>
    `specialties:v${version}:${params}`,

  byId: (id: string) => `specialties:${id}`,
};
