You're expecting to see the cache hit and miss in the service, but you don't because remember() hides all of that.

Let's expand what actually happens.

When you write:

return specialtyCache.rememberAll(
  cacheKey,
  async () => {
    const { specialties, total } =
      await specialtyRepository.findAll(parsedParams);

    return {
      specialties: specialties.map((s: any) => this.toResponse(s)),
      total,
    };
  },
);

this eventually calls:

redisService.remember(...)

Inside remember() you currently have:

async remember<T>(
  key: string,
  ttlSeconds: number,
  resolver: () => Promise<T>,
): Promise<T> {
  const cached = await this.get<T>(key);

  if (cached !== null) {
    return cached;              // <-- CACHE HIT
  }

  const value = await resolver(); // <-- CACHE MISS → Database

  await this.set(key, value, ttlSeconds);

  return value;
}

Let's imagine the first request.

GET /specialties

↓

remember()

↓

get(key)

↓

Redis

Redis says:

null

Then:

cached === null

↓

resolver()

↓

specialtyRepository.findAll()

↓

Database

↓

set()

↓

Redis

↓

Return response

Now the second request.

GET /specialties

↓

remember()

↓

get(key)

↓

Redis

Redis returns:

{
   specialties: ...
}

Then:

if (cached !== null) {
    return cached;
}

The resolver is never executed.

The repository is never called.

The database isn't touched.

If you want to see it happening

Temporarily change remember() to this:

async remember<T>(
  key: string,
  ttlSeconds: number,
  resolver: () => Promise<T>,
): Promise<T> {
  const cached = await this.get<T>(key);

  if (cached !== null) {
    logger.info(`[Redis] Cache HIT: ${key}`);

    return cached;
  }

  logger.info(`[Redis] Cache MISS: ${key}`);

  const value = await resolver();

  await this.set(key, value, ttlSeconds);

  return value;
}

Now you'll literally see:

First request:

[Redis] Cache MISS: specialties:...

Second request:

[Redis] Cache HIT: specialties:...
This is why I created remember()

Without remember(), every service would have to write:

const cached = await redisService.get(...);

if (cached) {
    return cached;
}

const data = await repository.findAll(...);

await redisService.set(...);

return data;

in every single endpoint.

remember() encapsulates that repetitive pattern into one reusable method. That's why your service looks so simple—it delegates the cache hit/miss logic to the infrastructure layer. This is a common pattern known as cache-aside, and it's exactly what remember() is implementing for you.