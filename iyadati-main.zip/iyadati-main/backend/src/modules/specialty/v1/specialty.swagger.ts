// src/modules/specialty/v1/specialty.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Specialty
 *   description: Medical specialties management endpoints
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     SpecialtyResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         nameFr:
 *           type: string
 *           example: "Cardiologie"
 *         nameAr:
 *           type: string
 *           example: "طب القلب"
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *           example: "Spécialité médicale dédiée au cœur et aux vaisseaux"
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *           example: "تخصص طبي مخصص للقلب والأوعية الدموية"
 *         imagePath:
 *           type: string
 *           nullable: true
 *         imageUrl:
 *           type: string
 *           nullable: true
 *           description: |
 *             Secure public URL for specialty image.
 *             Uses fileId (UUID) instead of exposing the file path.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         isActive:
 *           type: boolean
 *           example: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *
 *     CreateSpecialtyRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "Cardiologie"
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "طب القلب"
 *         descriptionFr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *
 *     UpdateSpecialtyRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         descriptionFr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 */

/**
 * @swagger
 * /api/v1/specialty/v1:
 *   get:
 *     summary: Get all specialties
 *     description: Returns a paginated list of medical specialties. Public endpoint.
 *     tags: [Specialty]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by French or Arabic name
 *       - in: query
 *         name: isActive
 *         schema:
 *           type: boolean
 *         description: Filter by active status
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, nameFr, nameAr]
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *     responses:
 *       200:
 *         description: Specialties retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SpecialtyResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Create a new specialty (Staff)
 *     description: Creates a new medical specialty. Requires Super Admin or Admin role.
 *     tags: [Specialty]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateSpecialtyRequest'
 *     responses:
 *       201:
 *         description: Specialty created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SpecialtyResponse'
 *       400:
 *         description: Validation error
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       409:
 *         description: Specialty name already exists
 */

/**
 * @swagger
 * /api/v1/specialty/v1/{id}:
 *   get:
 *     summary: Get specialty by ID
 *     description: Returns a single specialty. Public endpoint.
 *     tags: [Specialty]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Specialty retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SpecialtyResponse'
 *       404:
 *         description: Specialty not found
 */

/**
 * @swagger
 * /api/v1/specialty/v1/{id}:
 *   patch:
 *     summary: Update specialty (Staff)
 *     description: Updates a specialty. Requires Super Admin or Admin.
 *     tags: [Specialty]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateSpecialtyRequest'
 *     responses:
 *       200:
 *         description: Specialty updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SpecialtyResponse'
 *       400:
 *         description: Validation error
 *       404:
 *         description: Specialty not found
 *       409:
 *         description: Name conflict
 */

/**
 * @swagger
 * /api/v1/specialty/v1/{id}:
 *   delete:
 *     summary: Delete specialty (Staff)
 *     description: Soft delete - marks specialty as inactive. Requires Super Admin or Admin.
 *     tags: [Specialty]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Specialty deleted successfully
 *       404:
 *         description: Specialty not found
 */

/**
 * @swagger
 * /api/v1/specialty/v1/{id}/restore:
 *   post:
 *     summary: Restore specialty (Staff)
 *     description: Restores a soft-deleted specialty back to active. Requires Super Admin or Admin.
 *     tags: [Specialty]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Specialty restored successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/SpecialtyResponse'
 *       404:
 *         description: Specialty not found
 */

/**
 * @swagger
 * /api/v1/specialty/v1/{id}/image:
 *   post:
 *     summary: Upload specialty image (Staff)
 *     description: |
 *       Uploads an image for the specialty.
 *       Accepted: JPEG, PNG, WebP, SVG. Max: 2MB.
 *       Use `multipart/form-data` with field name `logo`.
 *       
 *       **Security:** Files are stored with UUID filenames and accessed via secure URLs.
 *       The access URL will contain only the file ID, not the file path.
 *       Format: /api/v1/files/public/{fileId}
 *     tags: [Specialty]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               logo:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 2MB)
 *     responses:
 *       200:
 *         description: Image uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Image uploaded successfully
 *                 data:
 *                   $ref: '#/components/schemas/SpecialtyResponse'
 *       400:
 *         description: Invalid file type or size
 *       404:
 *         description: Specialty not found
 */