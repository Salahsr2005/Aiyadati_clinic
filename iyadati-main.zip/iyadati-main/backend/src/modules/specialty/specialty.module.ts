import { Router } from 'express';
import specialtyRoutes from './v1/specialty.routes';
import './v1/specialty.swagger';

const router = Router();
router.use('/v1', specialtyRoutes);

export { router as specialtyModule };

