import { Router } from 'express';
import consentRoutes from './v1/consent.routes';
import './v1/consent.swagger';

const router = Router();
router.use('/v1', consentRoutes);

export { router as consentModule };
