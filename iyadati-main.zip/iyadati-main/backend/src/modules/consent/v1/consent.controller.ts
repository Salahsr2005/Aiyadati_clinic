import { Request, Response, NextFunction } from 'express';
import { consentService } from './consent.service';
import { ResponseUtil } from '../../../core/utils/response';
import { BadRequestError } from '../../../core/utils/error';

export class ConsentController {
  // ============================================================
  // PATIENT ENDPOINTS
  // ============================================================

  getMyConsent = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const patientId = req.user!.id;
      
      const consent = await consentService.getConsent(patientId, doctorId);
      ResponseUtil.success(res, consent, 'Consent retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  setMyConsent = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const patientId = req.user!.id;
      const { level, customDocumentIds, expiresInDays } = req.body;

      const validLevels = ['FULL', 'APPOINTMENT_ONLY', 'CUSTOM', 'NONE'];
      if (!validLevels.includes(level)) {
        throw new BadRequestError('Invalid consent level');
      }

      if (level === 'CUSTOM' && (!customDocumentIds || customDocumentIds.length === 0)) {
        throw new BadRequestError('Custom level requires document IDs');
      }

      const consent = await consentService.setConsent(patientId, doctorId, {
        level,
        customDocumentIds,
        expiresInDays,
      });

      ResponseUtil.success(res, consent, 'Consent updated successfully');
    } catch (error) {
      next(error);
    }
  };

  revokeMyConsent = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const patientId = req.user!.id;
      
      await consentService.revokeConsent(patientId, doctorId);
      ResponseUtil.success(res, null, 'Consent revoked successfully');
    } catch (error) {
      next(error);
    }
  };

  getMyConsents = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const patientId = req.user!.id;
      const consents = await consentService.getPatientConsents(patientId);
      ResponseUtil.success(res, consents, 'Consents retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  getMyDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const patientId = req.user!.id;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;

      const { documents, total } = await consentService.getPatientDocumentsWithUploader(
        patientId,
        page,
        limit
      );

      ResponseUtil.paginated(
        res,
        documents,
        total,
        page,
        limit,
        'Documents retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  getMyUploadingDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const patientId = req.user!.id;
      const doctors = await consentService.getUploadingDoctors(patientId);
      ResponseUtil.success(res, doctors, 'Doctors retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  deleteMyDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { documentId } = req.params;
      const patientId = req.user!.id;
      const { reason } = req.body;

      await consentService.deletePatientDocument(documentId, patientId, { reason });

      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) {
      next(error);
    }
  };

  getMyAccessLogs = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const patientId = req.user!.id;
      const doctorId = req.query.doctorId as string | undefined;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const { logs, total } = await consentService.getAccessLogs(patientId, doctorId, page, limit);
      ResponseUtil.paginated(res, logs, total, page, limit, 'Access logs retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // DOCTOR ENDPOINTS
  // ============================================================

  getMyPatients = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctorId = req.user!.id;
      const patients = await consentService.getDoctorPatients(doctorId);
      ResponseUtil.success(res, patients, 'Patients retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  getPatientDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { patientId } = req.params;
      const doctorId = req.user!.id;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;

      const result = await consentService.getPatientDocuments(
        patientId,
        doctorId,
        page,
        limit
      );

      ResponseUtil.paginated(
        res,
        result.documents,
        result.total,
        page,
        limit,
        'Patient documents retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  uploadPatientDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { patientId } = req.params;
      const doctorId = req.user!.id;

      if (!req.file) {
        ResponseUtil.badRequest(res, 'Document file is required');
        return;
      }

      const { title, description, docDate, tags, appointmentId } = req.body;

      const doc = await consentService.uploadPatientDocument(
        patientId,
        doctorId,
        req.file,
        { title, description, docDate, tags, appointmentId }
      );

      ResponseUtil.created(res, doc, 'Document uploaded to patient successfully');
    } catch (error) {
      next(error);
    }
  };

  // ============================================================
  // ADMIN ENDPOINTS
  // ============================================================

  getAllConsents = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = req.query;
      const page = parseInt(filters.page as string) || 1;
      const limit = parseInt(filters.limit as string) || 10;
      
      const result = await consentService.getAllConsents({
        patientId: filters.patientId as string,
        doctorId: filters.doctorId as string,
        level: filters.level as any,
        isActive: filters.isActive === 'true' ? true : filters.isActive === 'false' ? false : undefined,
        page,
        limit,
      });
      
      ResponseUtil.paginated(
        res,
        result.consents,
        result.total,
        page,
        limit,
        'Consents retrieved successfully'
      );
    } catch (error) {
      next(error);
    }
  };

  restoreDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { documentId } = req.params;
      const adminId = req.user!.id;

      await consentService.restorePatientDocument(documentId, adminId);

      ResponseUtil.success(res, null, 'Document restored successfully');
    } catch (error) {
      next(error);
    }
  };
}

