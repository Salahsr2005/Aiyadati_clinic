import { Router } from 'express';
import { ConsentController } from './consent.controller';
import {
  validateSetConsent,
  validateDoctorIdParam,
  validatePatientIdParam,
  validateDocumentIdParam,
  validateUploadDocument,
  validateDeleteDocument,
} from './consent.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { uploadUserDocument } from '../../../core/middleware/upload.middleware';

const router = Router();
const consentController = new ConsentController();

// ============================================================
// PATIENT ENDPOINTS (USER role)
// ============================================================

// Get all my consents
router.get(
  '/me/doctors',
  authenticate,
  authorize('USER'),
  consentController.getMyConsents
);

// Get consent for specific doctor
router.get(
  '/me/doctors/:doctorId',
  authenticate,
  authorize('USER'),
  validateDoctorIdParam,
  consentController.getMyConsent
);

// Set consent for a doctor (INVITE DOCTOR)
router.post(
  '/me/doctors/:doctorId',
  authenticate,
  authorize('USER'),
  validateDoctorIdParam,
  validateSetConsent,
  consentController.setMyConsent
);

// Revoke consent (REMOVE DOCTOR)
router.delete(
  '/me/doctors/:doctorId',
  authenticate,
  authorize('USER'),
  validateDoctorIdParam,
  consentController.revokeMyConsent
);

// Get my documents with uploader info
router.get(
  '/me/documents',
  authenticate,
  authorize('USER'),
  consentController.getMyDocuments
);

// Get doctors who uploaded documents to me
router.get(
  '/me/documents/doctors',
  authenticate,
  authorize('USER'),
  consentController.getMyUploadingDoctors
);

// Soft delete my document (PATIENT ONLY)
router.delete(
  '/me/documents/:documentId',
  authenticate,
  authorize('USER'),
  validateDocumentIdParam,
  validateDeleteDocument,
  consentController.deleteMyDocument
);

// Get my access logs
router.get(
  '/me/access-logs',
  authenticate,
  authorize('USER'),
  consentController.getMyAccessLogs
);

// ============================================================
// DOCTOR ENDPOINTS (DOCTOR role)
// ============================================================

// Get all patients with consent
router.get(
  '/doctor/patients',
  authenticate,
  authorize('DOCTOR'),
  consentController.getMyPatients
);

// Get patient's accessible documents
router.get(
  '/doctor/patients/:patientId/documents',
  authenticate,
  authorize('DOCTOR'),
  validatePatientIdParam,
  consentController.getPatientDocuments
);

// Doctor uploads document to patient (UPLOAD ONLY - NO DELETE)
router.post(
  '/doctor/patients/:patientId/documents',
  authenticate,
  authorize('DOCTOR'),
  validatePatientIdParam,
  uploadUserDocument,
  validateUploadDocument,
  consentController.uploadPatientDocument
);

// ============================================================
// ADMIN ENDPOINTS (SUPER_ADMIN, ADMIN)
// ============================================================

// Get all consents
router.get(
  '/admin/consents',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  consentController.getAllConsents
);

// Admin restores a soft-deleted document
router.post(
  '/admin/documents/:documentId/restore',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateDocumentIdParam,
  consentController.restoreDocument
);

export default router;

