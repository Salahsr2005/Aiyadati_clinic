// backend/src/modules/consent/v1/consent.service.ts
import { patientConsentRepository } from '../../../repositories/patient-consent.repository';
import { userDocumentRepository } from '../../../repositories/user-document.repository';
import { userRepository } from '../../../repositories/user.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { NotFoundError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { generateSignedUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { ConsentLevel } from '@prisma/client';
import { prisma } from '../../../core/utils/prisma';
import {
  ConsentResponse,
  ConsentWithDetailsResponse,
  DocumentAccessResponse,
  PatientDocumentResponse,
  AccessLogResponse,
  SetConsentDTO,
  UploadPatientDocumentDTO,
  DeleteDocumentDTO,
  ConsentFilters,
  DocumentFilters,
  UploaderType,
} from './consent.types';

export class ConsentService {
  // ============================================================
  // CONSENT MANAGEMENT
  // ============================================================

  async getConsent(patientId: string, doctorId: string): Promise<ConsentResponse | null> {
    const consent = await patientConsentRepository.findConsent(patientId, doctorId);
    if (!consent) return null;
    return this.toConsentResponse(consent);
  }

  async setConsent(
    patientId: string,
    doctorId: string,
    data: SetConsentDTO
  ): Promise<ConsentResponse> {
    const patient = await userRepository.findById(patientId);
    if (!patient) throw new NotFoundError('Patient');
    if (patient.isSuspended) throw new BadRequestError('Patient is suspended');

    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');
    if (!doctor.isVerified) throw new BadRequestError('Doctor is not verified');

    if (data.level === 'CUSTOM' && data.customDocumentIds) {
      const documents = await prisma.userDocument.findMany({
        where: {
          id: { in: data.customDocumentIds },
          userId: patientId,
          deletedAt: null,
        },
      });

      if (documents.length !== data.customDocumentIds.length) {
        throw new BadRequestError('Some documents do not belong to you or are deleted');
      }
    }

    const consent = await patientConsentRepository.upsertConsent(
      patientId,
      doctorId,
      data
    );

    logger.info(`Patient ${patientId} set consent for doctor ${doctorId} to ${data.level}`);

    if (data.level !== 'NONE') {
      await eventEmitter.emit('notification', {
        userId: doctorId,
        title: '📋 Patient Shared Medical Records',
        body: `Patient ${patient.firstName} ${patient.lastName} has granted you access to their medical records.`,
        type: 'consent_granted',
        data: { patientId, level: data.level },
      });
    }

    return this.toConsentResponse(consent);
  }

  async revokeConsent(patientId: string, doctorId: string): Promise<void> {
    const consent = await patientConsentRepository.findConsent(patientId, doctorId);
    if (!consent) throw new NotFoundError('Consent not found');

    await patientConsentRepository.revokeConsent(patientId, doctorId);

    const doctor = await doctorRepository.findById(doctorId);
    if (doctor) {
      await eventEmitter.emit('notification', {
        userId: doctorId,
        title: '🔒 Patient Revoked Access',
        body: `Patient has revoked your access to their medical records.`,
        type: 'consent_revoked',
        data: { patientId },
      });
    }

    logger.info(`Patient ${patientId} revoked consent for doctor ${doctorId}`);
  }

  async getPatientConsents(patientId: string): Promise<ConsentResponse[]> {
    const consents = await patientConsentRepository.findActiveByPatient(patientId);
    return consents.map(c => this.toConsentResponse(c));
  }

  async getDoctorPatients(doctorId: string): Promise<ConsentWithDetailsResponse[]> {
    const consents = await patientConsentRepository.findActiveByDoctor(doctorId);
    
    return Promise.all(
      consents.map(async (c) => {
        const documentIds = await patientConsentRepository.getAccessibleDocumentIds(
          c.patientId,
          doctorId
        );
        
        return {
          ...this.toConsentResponse(c),
          accessLevel: c.level === 'NONE' ? 'NONE' : 
                       c.level === 'FULL' ? 'FULL' : 'LIMITED',
          documentCount: documentIds.documentIds.length,
        };
      })
    );
  }

  // ============================================================
  // DOCUMENT ACCESS
  // ============================================================

  async getPatientDocuments(
    patientId: string,
    doctorId: string,
    page: number = 1,
    limit: number = 10
  ): Promise<{ documents: DocumentAccessResponse[]; total: number }> {
    const { documentIds, level } = await patientConsentRepository.getAccessibleDocumentIds(
      patientId,
      doctorId
    );

    if (documentIds.length === 0) {
      throw new ForbiddenError('No accessible documents for this patient');
    }

    const skip = (page - 1) * limit;
    const [documents, total] = await Promise.all([
      prisma.userDocument.findMany({
        where: {
          id: { in: documentIds },
          deletedAt: null,
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.userDocument.count({
        where: {
          id: { in: documentIds },
          deletedAt: null,
        },
      }),
    ]);

    const docsWithUrls = await Promise.all(
      documents.map(async (doc) => {
        await patientConsentRepository.logAccess(
          doc.id,
          patientId,
          doctorId,
          'view'
        );

        return {
          id: doc.id,
          fileName: doc.fileName,
          fileType: doc.fileType,
          fileSize: doc.fileSize,
          title: doc.title,
          description: doc.description,
          docDate: doc.docDate?.toISOString() || null,
          accessUrl: generateSignedUrl(doc.fileId),
          accessedAt: new Date().toISOString(),
        };
      })
    );

    return { documents: docsWithUrls, total };
  }

  // ============================================================
  // DOCTOR UPLOADS DOCUMENT TO PATIENT
  // ============================================================

  async uploadPatientDocument(
    patientId: string,
    doctorId: string,
    file: Express.Multer.File,
    data: UploadPatientDocumentDTO
  ): Promise<PatientDocumentResponse> {
    const patient = await userRepository.findById(patientId);
    if (!patient) throw new NotFoundError('Patient');
    if (patient.isSuspended) throw new BadRequestError('Patient is suspended');

    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');
    if (!doctor.isVerified) throw new BadRequestError('Doctor is not verified');

    const consent = await patientConsentRepository.findConsent(patientId, doctorId);
    if (!consent || !consent.isActive) {
      throw new ForbiddenError('No active consent from patient to upload documents');
    }

    if (consent.expiresAt && consent.expiresAt < new Date()) {
      throw new ForbiddenError('Consent has expired');
    }

    if (consent.level !== 'FULL' && consent.level !== 'CUSTOM') {
      throw new ForbiddenError(
        `Current consent level (${consent.level}) does not allow document uploads. ` +
        'Patient needs to grant FULL or CUSTOM access.'
      );
    }

    const tags = data.tags ? data.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

    const doc = await userDocumentRepository.create({
      userId: patientId,
      fileName: file.originalname,
      filePath: `private/user-documents/${file.filename}`,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: file.filename,
      title: data.title || file.originalname,
      description: data.description,
      docDate: data.docDate ? new Date(data.docDate) : new Date(),
      tags,
      storageType: 'private',
      category: 'medical',
      docType: 'doctor_upload',
      appointmentId: data.appointmentId,
      isShared: true,
      sharedWith: [doctorId],
    });

    if (consent.level === 'CUSTOM' && !consent.customDocumentIds.includes(doc.id)) {
      await patientConsentRepository.upsertConsent(patientId, doctorId, {
        level: 'CUSTOM',
        customDocumentIds: [...consent.customDocumentIds, doc.id],
        expiresInDays: consent.expiresAt 
          ? Math.ceil((consent.expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
          : undefined,
      });
    }

    await patientConsentRepository.logAccess(
      doc.id,
      patientId,
      doctorId,
      'upload'
    );

    await eventEmitter.emit('notification', {
      userId: patientId,
      title: '📄 New Medical Document Added',
      body: `Dr. ${doctor.firstNameFr} ${doctor.lastNameFr} has added a new document to your medical records: ${doc.fileName}`,
      type: 'document_uploaded',
      data: {
        doctorId,
        documentId: doc.id,
        fileName: doc.fileName,
      },
    });

    logger.info(`Doctor ${doctorId} uploaded document ${doc.id} to patient ${patientId}`);

    return {
      id: doc.id,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      title: doc.title,
      description: doc.description,
      docDate: doc.docDate?.toISOString() || null,
      accessUrl: generateSignedUrl(doc.fileId),
      accessedAt: new Date().toISOString(),
      uploadedBy: doctorId,
      uploadedByType: 'doctor',
      uploadedByName: `Dr. ${doctor.firstNameFr} ${doctor.lastNameFr}`,
      isShared: true,
      sharedWith: [doctorId],
      isDeleted: false,
      deletedAt: null,
      deletedReason: null,
      doctorInfo: {
        id: doctor.id,
        firstNameFr: doctor.firstNameFr,
        lastNameFr: doctor.lastNameFr,
        email: doctor.email,
      },
    };
  }

  // ============================================================
  // PATIENT GETS DOCUMENTS WITH UPLOADER INFO
  // ============================================================

  async getPatientDocumentsWithUploader(
    patientId: string,
    page: number = 1,
    limit: number = 10,
    filters?: DocumentFilters
  ): Promise<{ documents: PatientDocumentResponse[]; total: number }> {
    const { documents, total } = await userDocumentRepository.findWithUploaderInfo(
      patientId,
      page,
      limit
    );

    const docsWithInfo: PatientDocumentResponse[] = await Promise.all(
      documents.map(async (doc: any) => {
        let uploadedBy = 'patient';
        let uploadedByName = 'You';
        let doctorInfo = null;

        if (doc.sharedWith && doc.sharedWith.length > 0) {
          const doctorId = doc.sharedWith[0];
          const doctor = await doctorRepository.findById(doctorId);
          if (doctor) {
            uploadedBy = 'doctor';
            uploadedByName = `Dr. ${doctor.firstNameFr} ${doctor.lastNameFr}`;
            doctorInfo = {
              id: doctor.id,
              firstNameFr: doctor.firstNameFr,
              lastNameFr: doctor.lastNameFr,
              email: doctor.email,
            };
          }
        }

        return {
          id: doc.id,
          fileName: doc.fileName,
          fileType: doc.fileType,
          fileSize: doc.fileSize,
          title: doc.title,
          description: doc.description,
          docDate: doc.docDate?.toISOString() || null,
          accessUrl: generateSignedUrl(doc.fileId),
          accessedAt: doc.lastAccessed?.toISOString() || doc.createdAt.toISOString(),
          uploadedBy: uploadedBy,
          uploadedByType: uploadedBy as UploaderType,
          uploadedByName: uploadedByName,
          isShared: doc.isShared || false,
          sharedWith: doc.sharedWith || [],
          isDeleted: !!doc.deletedAt,
          deletedAt: doc.deletedAt?.toISOString() || null,
          deletedReason: doc.deletedReason || null,
          doctorInfo,
        };
      })
    );

    return { documents: docsWithInfo, total };
  }

  async getUploadingDoctors(patientId: string) {
    const doctorIds = await userDocumentRepository.findAccessingDoctors(patientId);

    if (doctorIds.length === 0) {
      return [];
    }

    const doctors = await prisma.doctor.findMany({
      where: {
        id: { in: doctorIds },
      },
      select: {
        id: true,
        firstNameFr: true,
        lastNameFr: true,
        email: true,
        phone: true,
        isVerified: true,
      },
    });

    const doctorsWithCount = await Promise.all(
      doctors.map(async (doctor) => {
        const count = await userDocumentRepository.countSharedWithDoctor(patientId, doctor.id);

        return {
          ...doctor,
          documentCount: count,
        };
      })
    );

    return doctorsWithCount;
  }

  // ============================================================
  // PATIENT DELETES DOCUMENT (Soft Delete)
  // ============================================================

  async deletePatientDocument(
    documentId: string,
    patientId: string,
    data: DeleteDocumentDTO
  ): Promise<void> {
    const doc = await userDocumentRepository.findById(documentId);
    if (!doc) throw new NotFoundError('Document not found');

    if (doc.userId !== patientId) {
      throw new ForbiddenError('You can only delete your own documents');
    }

    await userDocumentRepository.softDelete(documentId, {
      deletedById: patientId,
      deletedByType: 'patient',
      reason: data.reason || 'Patient requested deletion',
    });

    logger.info(`Document ${documentId} soft deleted by patient ${patientId}`);

    if (doc.sharedWith && doc.sharedWith.length > 0) {
      for (const doctorId of doc.sharedWith) {
        await eventEmitter.emit('notification', {
          userId: doctorId,
          title: '📄 Document Deleted',
          body: `A document you had access to has been deleted by the patient.`,
          type: 'document_deleted',
          data: {
            patientId,
            documentId,
            fileName: doc.fileName,
          },
        });
      }
    }
  }

  // ============================================================
  // ADMIN RESTORES DOCUMENT
  // ============================================================

  async restorePatientDocument(documentId: string, adminId: string): Promise<void> {
    const doc = await userDocumentRepository.findByIdWithDeleted(documentId);
    if (!doc) throw new NotFoundError('Document not found');

    const admin = await prisma.admin.findUnique({
      where: { id: adminId },
    });
    if (!admin) throw new ForbiddenError('Only admins can restore documents');

    if (!doc.deletedAt) {
      throw new BadRequestError('Document is not deleted');
    }

    await userDocumentRepository.restore(documentId);

    logger.info(`Document ${documentId} restored by admin ${adminId}`);

    await eventEmitter.emit('notification', {
      userId: doc.userId,
      title: '📄 Document Restored',
      body: `Your document "${doc.fileName}" has been restored by an administrator.`,
      type: 'document_restored',
      data: {
        documentId,
        fileName: doc.fileName,
        adminId,
      },
    });
  }

  // ============================================================
  // ACCESS LOGS - FIXED
  // ============================================================

  async getAccessLogs(
    patientId: string,
    doctorId?: string,
    page: number = 1,
    limit: number = 10
  ): Promise<{ logs: AccessLogResponse[]; total: number }> {
    const { logs, total } = await patientConsentRepository.getAccessLogs(
      patientId,
      doctorId,
      page,
      limit
    );

    const mappedLogs: AccessLogResponse[] = logs.map(log => ({
      id: log.id,
      documentId: log.documentId || '', // ← Convert null to empty string
      document: log.document ? {
        id: log.document.id,
        fileName: log.document.fileName,
        title: log.document.title,
        fileType: log.document.fileType,
      } : {
        id: '',
        fileName: 'Unknown document',
        title: null,
        fileType: 'unknown',
      },
      doctorId: log.doctorId,
      doctor: {
        id: log.doctor.id,
        firstNameFr: log.doctor.firstNameFr,
        lastNameFr: log.doctor.lastNameFr,
        email: log.doctor.email,
      },
      accessType: log.accessType,
      ipAddress: log.ipAddress,
      userAgent: log.userAgent,
      accessedAt: log.accessedAt.toISOString(),
    }));

    return { 
      logs: mappedLogs, 
      total 
    };
  }

  // ============================================================
  // ADMIN ENDPOINTS
  // ============================================================

  async getAllConsents(filters: ConsentFilters) {
    const { consents, total } = await patientConsentRepository.findAll(
      filters.page || 1,
      filters.limit || 10,
      {
        patientId: filters.patientId,
        doctorId: filters.doctorId,
        level: filters.level,
        isActive: filters.isActive,
      }
    );

    return {
      consents: consents.map(c => this.toConsentResponse(c)),
      total,
    };
  }

  // ============================================================
  // HELPERS
  // ============================================================

  private toConsentResponse(consent: any): ConsentResponse {
    return {
      id: consent.id,
      patientId: consent.patientId,
      doctorId: consent.doctorId,
      level: consent.level,
      customDocumentIds: consent.customDocumentIds || [],
      expiresAt: consent.expiresAt?.toISOString() || null,
      isActive: consent.isActive,
      consentedAt: consent.consentedAt.toISOString(),
      revokedAt: consent.revokedAt?.toISOString() || null,
      consentMethod: consent.consentMethod,
      createdAt: consent.createdAt.toISOString(),
      updatedAt: consent.updatedAt.toISOString(),
      patient: consent.patient ? {
        id: consent.patient.id,
        firstName: consent.patient.firstName,
        lastName: consent.patient.lastName,
        email: consent.patient.email,
        phone: consent.patient.phone,
      } : undefined,
      doctor: consent.doctor ? {
        id: consent.doctor.id,
        firstNameFr: consent.doctor.firstNameFr,
        lastNameFr: consent.doctor.lastNameFr,
        email: consent.doctor.email,
        phone: consent.doctor.phone,
      } : undefined,
    };
  }
}

export const consentService = new ConsentService();

