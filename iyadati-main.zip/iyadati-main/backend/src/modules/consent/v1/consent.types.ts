import { ConsentLevel } from '@prisma/client';

// ============================================================
// ENUMS
// ============================================================

export type UploaderType = 'patient' | 'doctor' | string;

// ============================================================
// RESPONSE TYPES
// ============================================================

export interface ConsentResponse {
  id: string;
  patientId: string;
  doctorId: string;
  level: ConsentLevel;
  customDocumentIds: string[];
  expiresAt: string | null;
  isActive: boolean;
  consentedAt: string;
  revokedAt: string | null;
  consentMethod: string;
  createdAt: string;
  updatedAt: string;
  patient?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  doctor?: {
    id: string;
    firstNameFr: string;
    lastNameFr: string;
    email: string;
    phone: string;
  };
}

export interface ConsentWithDetailsResponse extends ConsentResponse {
  accessLevel: 'FULL' | 'LIMITED' | 'NONE';
  documentCount: number;
}

export interface DocumentAccessResponse {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  title: string | null;
  description: string | null;
  docDate: string | null;
  accessUrl: string;
  accessedAt?: string;
}

export interface PatientDocumentResponse extends DocumentAccessResponse {
  uploadedBy: string;
  uploadedByType: UploaderType;
  uploadedByName: string;
  isShared: boolean;
  sharedWith: string[];
  isDeleted: boolean;
  deletedAt: string | null;
  deletedReason: string | null;
  doctorInfo?: {
    id: string;
    firstNameFr: string;
    lastNameFr: string;
    email: string;
  } | null;
}

export interface AccessLogResponse {
  id: string;
  documentId: string;
  document: {
    id: string;
    fileName: string;
    title: string | null;
    fileType: string;
  };
  doctorId: string;
  doctor: {
    id: string;
    firstNameFr: string;
    lastNameFr: string;
    email: string;
  };
  accessType: string;
  ipAddress: string | null;
  userAgent: string | null;
  accessedAt: string;
}

// ============================================================
// REQUEST DTOs
// ============================================================

export interface SetConsentDTO {
  level: ConsentLevel;
  customDocumentIds?: string[];
  expiresInDays?: number;
}

export interface UploadPatientDocumentDTO {
  title?: string;
  description?: string;
  docDate?: string;
  tags?: string;
  appointmentId?: string;
}

export interface DeleteDocumentDTO {
  reason?: string;
}

// ============================================================
// FILTERS
// ============================================================

export interface ConsentFilters {
  patientId?: string;
  doctorId?: string;
  level?: ConsentLevel;
  isActive?: boolean;
  page?: number;
  limit?: number;
}

export interface DocumentFilters {
  docType?: string;
  storageType?: string;
  uploadedByType?: UploaderType;
  tag?: string;
  page?: number;
  limit?: number;
}

