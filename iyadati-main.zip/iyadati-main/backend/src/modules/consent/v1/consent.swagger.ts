/**
 * @swagger
 * tags:
 *   name: Consent
 *   description: Patient-Doctor consent management for medical document sharing
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     ConsentLevel:
 *       type: string
 *       enum: [FULL, APPOINTMENT_ONLY, CUSTOM, NONE]
 *       description: |
 *         - **FULL**: Doctor can see all medical documents
 *         - **APPOINTMENT_ONLY**: Doctor can only see documents from appointments with them
 *         - **CUSTOM**: Patient manually selects which documents to share
 *         - **NONE**: No access granted
 *
 *     SetConsentRequest:
 *       type: object
 *       required:
 *         - level
 *       properties:
 *         level:
 *           $ref: '#/components/schemas/ConsentLevel'
 *         customDocumentIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: Required when level is CUSTOM
 *         expiresInDays:
 *           type: integer
 *           minimum: 1
 *           maximum: 365
 *           description: Number of days before consent expires
 *
 *     ConsentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         patientId:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         level:
 *           $ref: '#/components/schemas/ConsentLevel'
 *         customDocumentIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         isActive:
 *           type: boolean
 *         consentedAt:
 *           type: string
 *           format: date-time
 *         revokedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         consentMethod:
 *           type: string
 *           enum: [app, signed_form, verbal]
 *
 *     DocumentAccessResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         fileName:
 *           type: string
 *         fileType:
 *           type: string
 *         fileSize:
 *           type: integer
 *         title:
 *           type: string
 *           nullable: true
 *         description:
 *           type: string
 *           nullable: true
 *         docDate:
 *           type: string
 *           format: date
 *           nullable: true
 *         accessUrl:
 *           type: string
 *           description: Signed URL (expires in 30 minutes)
 *         accessedAt:
 *           type: string
 *           format: date-time
 *
 *     PatientDocumentResponse:
 *       type: object
 *       allOf:
 *         - $ref: '#/components/schemas/DocumentAccessResponse'
 *         - type: object
 *           properties:
 *             uploadedBy:
 *               type: string
 *               format: uuid
 *             uploadedByType:
 *               type: string
 *               enum: [patient, doctor]
 *             uploadedByName:
 *               type: string
 *             isShared:
 *               type: boolean
 *             sharedWith:
 *               type: array
 *               items:
 *                 type: string
 *                 format: uuid
 *             isDeleted:
 *               type: boolean
 *             deletedAt:
 *               type: string
 *               format: date-time
 *               nullable: true
 *             deletedReason:
 *               type: string
 *               nullable: true
 *             doctorInfo:
 *               type: object
 *               nullable: true
 *               properties:
 *                 id:
 *                   type: string
 *                   format: uuid
 *                 firstNameFr:
 *                   type: string
 *                 lastNameFr:
 *                   type: string
 *                 email:
 *                   type: string
 *
 *     AccessLogResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         documentId:
 *           type: string
 *           format: uuid
 *         document:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             fileName:
 *               type: string
 *             title:
 *               type: string
 *               nullable: true
 *             fileType:
 *               type: string
 *         doctorId:
 *           type: string
 *           format: uuid
 *         doctor:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             firstNameFr:
 *               type: string
 *             lastNameFr:
 *               type: string
 *             email:
 *               type: string
 *         accessType:
 *           type: string
 *           enum: [view, download, granted]
 *         ipAddress:
 *           type: string
 *           nullable: true
 *         userAgent:
 *           type: string
 *           nullable: true
 *         accessedAt:
 *           type: string
 *           format: date-time
 */

// ============================================================
// PATIENT ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/consent/v1/me/doctors:
 *   get:
 *     summary: Get all my active consents
 *     description: Returns all active consents the authenticated patient has granted to doctors
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Consents retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ConsentResponse'
 *                 message:
 *                   type: string
 *                   example: "Consents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 */

/**
 * @swagger
 * /api/v1/consent/v1/me/doctors/{doctorId}:
 *   get:
 *     summary: Get my consent for a specific doctor
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Consent retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ConsentResponse'
 *                 message:
 *                   type: string
 *                   example: "Consent retrieved successfully"
 *
 *   post:
 *     summary: Set consent for a doctor (INVITE DOCTOR)
 *     description: |
 *       Set or update consent level for a specific doctor. This effectively invites the doctor to access your documents.
 *       - **FULL**: Grant access to all documents
 *       - **APPOINTMENT_ONLY**: Only documents from appointments with this doctor
 *       - **CUSTOM**: Manually select which documents to share
 *       - **NONE**: Revoke all access (remove doctor)
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SetConsentRequest'
 *           examples:
 *             fullAccess:
 *               summary: Grant full access
 *               value:
 *                 level: "FULL"
 *                 expiresInDays: 30
 *             customAccess:
 *               summary: Grant access to specific documents
 *               value:
 *                 level: "CUSTOM"
 *                 customDocumentIds: ["doc-1", "doc-2", "doc-3"]
 *                 expiresInDays: 90
 *             appointmentOnly:
 *               summary: Appointment-only access
 *               value:
 *                 level: "APPOINTMENT_ONLY"
 *             revokeAll:
 *               summary: Revoke all access (remove doctor)
 *               value:
 *                 level: "NONE"
 *     responses:
 *       200:
 *         description: Consent updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ConsentResponse'
 *                 message:
 *                   type: string
 *                   example: "Consent updated successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 *       404:
 *         description: Doctor not found
 *
 *   delete:
 *     summary: Revoke consent for a doctor (REMOVE DOCTOR)
 *     description: Revoke all access for a specific doctor
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Consent revoked
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Consent revoked successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 *       404:
 *         description: Consent not found
 */

/**
 * @swagger
 * /api/v1/consent/v1/me/documents:
 *   get:
 *     summary: Get my documents with uploader info
 *     description: |
 *       Returns all documents with information about who uploaded them.
 *       - If uploaded by patient: "uploadedBy": "patient", "uploadedByName": "You"
 *       - If uploaded by doctor: shows doctor's name and ID
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/PatientDocumentResponse'
 *                 meta:
 *                   type: object
 *                 message:
 *                   type: string
 *                   example: "Documents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 */

/**
 * @swagger
 * /api/v1/consent/v1/me/documents/doctors:
 *   get:
 *     summary: Get doctors who uploaded documents to me
 *     description: |
 *       Returns a list of doctors who have uploaded documents to the patient's record.
 *       Includes document count per doctor.
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Doctors retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         format: uuid
 *                       firstNameFr:
 *                         type: string
 *                       lastNameFr:
 *                         type: string
 *                       email:
 *                         type: string
 *                       phone:
 *                         type: string
 *                       isVerified:
 *                         type: boolean
 *                       documentCount:
 *                         type: integer
 *                         description: Number of documents this doctor uploaded
 *                 message:
 *                   type: string
 *                   example: "Doctors retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 */

/**
 * @swagger
 * /api/v1/consent/v1/me/documents/{documentId}:
 *   delete:
 *     summary: Soft delete my document (Patient only)
 *     description: |
 *       Soft deletes a document owned by the patient.
 *       The document is hidden but can be restored by an admin.
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: documentId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason:
 *                 type: string
 *                 maxLength: 500
 *                 description: Reason for deletion
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Document deleted successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 *       404:
 *         description: Document not found
 */

/**
 * @swagger
 * /api/v1/consent/v1/me/access-logs:
 *   get:
 *     summary: Get my document access logs
 *     description: |
 *       Returns paginated logs of who accessed your documents and when.
 *       Filter by doctor ID if needed.
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: doctorId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specific doctor
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Access logs retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AccessLogResponse'
 *                 meta:
 *                   type: object
 *                 message:
 *                   type: string
 *                   example: "Access logs retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires USER role
 */

// ============================================================
// DOCTOR ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/consent/v1/doctor/patients:
 *   get:
 *     summary: Get all patients with active consent (Doctor)
 *     description: Returns all patients who have granted you access to their documents
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Patients retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     allOf:
 *                       - $ref: '#/components/schemas/ConsentResponse'
 *                       - type: object
 *                         properties:
 *                           accessLevel:
 *                             type: string
 *                             enum: [FULL, LIMITED, NONE]
 *                           documentCount:
 *                             type: integer
 *                 message:
 *                   type: string
 *                   example: "Patients retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires DOCTOR role
 */

/**
 * @swagger
 * /api/v1/consent/v1/doctor/patients/{patientId}/documents:
 *   get:
 *     summary: Get patient's accessible documents (Doctor)
 *     description: |
 *       Returns all documents the patient has granted you access to.
 *       Documents are returned with signed URLs (expire in 30 minutes).
 *       Access is logged automatically.
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: patientId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/DocumentAccessResponse'
 *                 meta:
 *                   type: object
 *                 message:
 *                   type: string
 *                   example: "Patient documents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - No consent or requires DOCTOR role
 *       404:
 *         description: Patient not found
 *
 *   post:
 *     summary: Upload document to patient (Doctor)
 *     description: |
 *       Doctor uploads a medical document to a patient's record.
 *       
 *       **Requirements:**
 *       - Patient must have active consent (FULL or CUSTOM level)
 *       - If CUSTOM, the document is automatically added to the patient's custom list
 *       
 *       **Access:** DOCTOR only
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: patientId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - document
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *               title:
 *                 type: string
 *                 maxLength: 200
 *                 description: Document title (defaults to filename)
 *               description:
 *                 type: string
 *                 maxLength: 500
 *                 description: Document description
 *               docDate:
 *                 type: string
 *                 format: date
 *                 description: Date associated with the document
 *               tags:
 *                 type: string
 *                 maxLength: 300
 *                 description: Comma-separated tags
 *           example:
 *             document: (file)
 *             title: "Blood Test Results"
 *             description: "Annual blood test"
 *             docDate: "2026-08-05"
 *             tags: "blood, lab, annual"
 *     responses:
 *       201:
 *         description: Document uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/PatientDocumentResponse'
 *                 message:
 *                   type: string
 *                   example: "Document uploaded to patient successfully"
 *       400:
 *         description: Invalid file or missing document
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - No consent or requires DOCTOR role
 *       404:
 *         description: Patient not found
 *       413:
 *         description: File too large (max 20MB)
 */

// ============================================================
// ADMIN ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/consent/v1/admin/consents:
 *   get:
 *     summary: Get all consents (Admin)
 *     description: |
 *       Returns all consents with pagination and filtering options.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: patientId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by patient
 *       - in: query
 *         name: doctorId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by doctor
 *       - in: query
 *         name: level
 *         schema:
 *           $ref: '#/components/schemas/ConsentLevel'
 *         description: Filter by consent level
 *       - in: query
 *         name: isActive
 *         schema:
 *           type: boolean
 *         description: Filter by active status
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Consents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ConsentResponse'
 *                 meta:
 *                   type: object
 *                 message:
 *                   type: string
 *                   example: "Consents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 */

/**
 * @swagger
 * /api/v1/consent/v1/admin/documents/{documentId}/restore:
 *   post:
 *     summary: Restore soft-deleted document (Admin)
 *     description: |
 *       Restores a document that was soft-deleted by a patient.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Consent]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: documentId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to restore
 *     responses:
 *       200:
 *         description: Document restored successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Document restored successfully"
 *       400:
 *         description: Document is not deleted
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *       404:
 *         description: Document not found
 */