import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

// ============================================================
// SET CONSENT VALIDATION
// ============================================================

const setConsentSchema = Joi.object({
  level: Joi.string()
    .valid('FULL', 'APPOINTMENT_ONLY', 'CUSTOM', 'NONE')
    .required()
    .messages({
      'any.required': 'Consent level is required',
      'any.only': 'Level must be one of: FULL, APPOINTMENT_ONLY, CUSTOM, NONE',
    }),
  customDocumentIds: Joi.array()
    .items(Joi.string().uuid())
    .when('level', {
      is: 'CUSTOM',
      then: Joi.array().min(1).required().messages({
        'array.min': 'At least one document is required for CUSTOM level',
        'any.required': 'Document IDs are required for CUSTOM level',
      }),
      otherwise: Joi.optional(),
    }),
  expiresInDays: Joi.number()
    .integer()
    .min(1)
    .max(365)
    .optional()
    .messages({
      'number.min': 'Expiry must be at least 1 day',
      'number.max': 'Expiry cannot exceed 365 days',
    }),
});

export const validateSetConsent = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = setConsentSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// UPLOAD DOCUMENT VALIDATION
// ============================================================

const uploadDocumentSchema = Joi.object({
  title: Joi.string().max(200).optional().messages({
    'string.max': 'Title cannot exceed 200 characters',
  }),
  description: Joi.string().max(500).optional().allow('', null).messages({
    'string.max': 'Description cannot exceed 500 characters',
  }),
  docDate: Joi.date().iso().optional().messages({
    'date.format': 'Date must be in ISO format (YYYY-MM-DD)',
  }),
  tags: Joi.string().max(300).optional().messages({
    'string.max': 'Tags cannot exceed 300 characters',
  }),
  appointmentId: Joi.string().uuid().optional().allow(null),
});

export const validateUploadDocument = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = uploadDocumentSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// DELETE DOCUMENT VALIDATION
// ============================================================

const deleteDocumentSchema = Joi.object({
  reason: Joi.string().max(500).optional().allow('', null).messages({
    'string.max': 'Reason cannot exceed 500 characters',
  }),
});

export const validateDeleteDocument = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = deleteDocumentSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// PARAM VALIDATION
// ============================================================

const doctorIdParamSchema = Joi.object({
  doctorId: Joi.string().uuid().required().messages({
    'string.uuid': 'Doctor ID must be a valid UUID',
    'any.required': 'Doctor ID is required',
  }),
});

const patientIdParamSchema = Joi.object({
  patientId: Joi.string().uuid().required().messages({
    'string.uuid': 'Patient ID must be a valid UUID',
    'any.required': 'Patient ID is required',
  }),
});

const documentIdParamSchema = Joi.object({
  documentId: Joi.string().uuid().required().messages({
    'string.uuid': 'Document ID must be a valid UUID',
    'any.required': 'Document ID is required',
  }),
});

export const validateDoctorIdParam = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = doctorIdParamSchema.validate(req.params, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validatePatientIdParam = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = patientIdParamSchema.validate(req.params, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateDocumentIdParam = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = documentIdParamSchema.validate(req.params, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

