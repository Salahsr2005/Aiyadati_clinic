import { Router } from 'express';
import authRoutes from './v1/auth.routes';

// Import swagger docs
import './v1/auth.swagger';

const router = Router();

router.use('/v1', authRoutes);

export { router as authModule };

