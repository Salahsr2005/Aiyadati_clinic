import { Router } from 'express';
import { AuthController } from './auth.controller';
import { validateLogin , validateRegisterUser, validateVerifyOtp, validateResendOtp , validateRegisterClinic , validateRegisterDoctor} from './auth.validation';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';

const router = Router();
const authController = new AuthController();

router.post(
  '/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  validateLogin,
  authController.login.bind(authController)
);

router.post('/logout', authController.logout.bind(authController));
router.get('/me', authController.me.bind(authController));


router.post(
  '/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many registration attempts' }),
  validateRegisterUser,
  authController.registerUser
);

router.post(
  '/verify-otp',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many verification attempts' }),
  validateVerifyOtp,
  authController.verifyOtp
);

router.post(
  '/resend-otp',
  createRateLimiter({ windowMinutes: 15, maxRequests: 3, message: 'Too many OTP requests' }),
  validateResendOtp,
  authController.resendOtp
);

router.post(
  '/user/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  validateLogin,
  authController.loginUser
);

router.post(
  '/clinic/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5 }),
  validateRegisterClinic,
  authController.registerClinic
);

router.post(
  '/clinic/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10 }),
  authController.loginClinic
);

router.post(
  '/doctor/register',
  createRateLimiter({ windowMinutes: 15, maxRequests: 5, message: 'Too many registration attempts' }),
  validateRegisterDoctor,
  authController.registerDoctor
);

router.post(
  '/doctor/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many login attempts' }),
  authController.loginDoctor
);


export default router;

