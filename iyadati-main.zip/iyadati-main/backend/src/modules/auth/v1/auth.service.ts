import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';


import { superAdminRepository } from '../../../repositories/super-admin.repository';
import { adminRepository } from '../../../repositories/admin.repository';
import { userRepository } from '../../../repositories/user.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { walletRepository } from '../../../repositories/wallet.repository';


import { UnauthorizedError, ConflictError, BadRequestError, NotFoundError } from '../../../core/utils/error';

import { eventEmitter } from '../../../core/events/event-emitter';

import { logger } from '../../../core/utils/logger';

import { LoginDTO, RegisterUserDTO, VerifyOtpDTO, AuthUser, AuthResponse, ResendOtpDTO} from './auth.types';
import { RegisterClinicDTO } from './auth.types';
import { RegisterDoctorDTO } from './auth.types';

import { env } from '../../../config/env';

const JWT_SECRET = env.JWT_SECRET || 'iyadati-secret-key-change-in-production';
const JWT_EXPIRES_IN = '7d';

export class AuthService {
  /**
   * Login for Super Admin and Admin only
   */
  async login(data: LoginDTO): Promise<AuthResponse> {
    const { email, password } = data;

    // Try Super Admin first
    let user = await superAdminRepository.findByEmail(email);
    let role: 'SUPER_ADMIN' | 'ADMIN' = 'SUPER_ADMIN';

    // If not found, try Admin
    if (!user) {
      user = await adminRepository.findByEmail(email);
      role = 'ADMIN';
    }

    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role, name: user.name },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role,
      },
    };
  }

  /**
   * Login for Users only
   */
  async loginUser(data: LoginDTO): Promise<AuthResponse> {
    const { email, password } = data;

    const user = await userRepository.findByEmail(email);
    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    if (!user.isVerified) {
      throw new UnauthorizedError('Please verify your email first');
    }

    if (user.isSuspended) {
      throw new UnauthorizedError('Your account has been suspended');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: 'USER' as const, name: `${user.firstName} ${user.lastName}` },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: `${user.firstName} ${user.lastName}`,
        role: 'USER',
      },
    };
  }

  async verifyToken(token: string): Promise<AuthUser> {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
      return decoded;
    } catch (error) {
      throw new UnauthorizedError('Invalid or expired token');
    }
  }

  async registerUser(data: RegisterUserDTO): Promise<{ message: string }> {
    const [existingEmail, existingPhone] = await Promise.all([
      userRepository.findByEmail(data.email),
      userRepository.findByPhone(data.phone),
    ]);

    if (existingEmail) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'This email is already in use' },
      ]);
    }

    if (existingPhone) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'This phone number is already in use' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);
    const otp = crypto.randomInt(100000, 999999).toString();  //'123456'
    const hashedOtp = await bcrypt.hash(otp, 10);
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    const user = await userRepository.create({
      email: data.email,
      password: hashedPassword,
      firstName: data.firstName,
      lastName: data.lastName,
      phone: data.phone,
      dateOfBirth: new Date(data.dateOfBirth),
      wilaya: { connect: { id: data.wilayaId } },
      verificationCode: hashedOtp,
      otpExpiresAt,
    });

    await walletRepository.create(user.id);

    // Send welcome notification
    eventEmitter.emit('notification', {
      userId: user.id,
      title: '🎉 Welcome to Iyadati!',
      body: 'Your account has been created. Please check your email for the verification code.',
      type: 'system',
      data: { type: 'welcome' },
    });

    eventEmitter.emit('send-otp-email', {
      email: user.email,
      name: user.firstName,
      otp,
    });

    logger.info(`User registered: ${user.email}`);

    return { message: 'Registration successful. Please check your email for the verification code.' };
  }

  async verifyUserOtp(data: VerifyOtpDTO): Promise<{ message: string }> {
    const user = await userRepository.findByEmail(data.email);
    if (!user) {
      throw new BadRequestError('Invalid email or verification code');
    }

    if (user.isVerified) {
      return { message: 'Email already verified' };
    }

    if (!user.verificationCode || !user.otpExpiresAt) {
      throw new BadRequestError('No verification code found. Please register again.');
    }

    if (new Date() > user.otpExpiresAt) {
      throw new BadRequestError('Verification code has expired. Please request a new one.');
    }

    const isValidOtp = await bcrypt.compare(data.otp, user.verificationCode);
    if (!isValidOtp) {
      throw new BadRequestError('Invalid verification code');
    }

    await userRepository.verifyUser(user.id);

    // Notify user about successful verification
    eventEmitter.emit('notification', {
      userId: user.id,
      title: '✅ Email Verified!',
      body: 'Your email has been verified. You can now login and start booking appointments.',
      type: 'system',
      data: { type: 'email_verified' },
    });

    return { message: 'Email verified successfully. You can now login.' };
  }

  async resendOtp(data: ResendOtpDTO): Promise<{ message: string }> {
    const user = await userRepository.findByEmail(data.email);
    
    if (!user) {
      return { message: 'If your email is registered, a new verification code has been sent.' };
    }

    if (user.isVerified) {
      return { message: 'Email already verified. You can login now.' };
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const hashedOtp = await bcrypt.hash(otp, 10);
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await userRepository.setVerificationCode(user.id, hashedOtp, otpExpiresAt);

    eventEmitter.emit('send-otp-email', {
      email: user.email,
      name: user.firstName,
      otp,
    });

    logger.info(`New OTP sent to ${user.email}`);

    return { message: 'If your email is registered, a new verification code has been sent.' };
  }

  async registerClinic(data: RegisterClinicDTO, ip?: string): Promise<AuthResponse> {
    const [emailExists, phoneExists] = await Promise.all([
      clinicRepository.emailExists(data.email),
      clinicRepository.phoneExists(data.phone),
    ]);

    if (emailExists) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'A clinic with this email already exists' },
      ]);
    }

    if (phoneExists) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'A clinic with this phone already exists' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const clinic = await clinicRepository.create({
      nameFr: data.nameFr,
      nameAr: data.nameAr,
      password: hashedPassword,
      phone: data.phone,
      email: data.email,
      wilaya: { connect: { id: data.wilayaId } },
    });

    // Send welcome notification
    eventEmitter.emit('notification', {
      userId: clinic.id,
      title: '🏥 Welcome to Iyadati!',
      body: 'Your clinic has been registered. Please upload your documents to get verified.',
      type: 'system',
      data: { type: 'welcome' },
    });

    const token = jwt.sign(
      { id: clinic.id, email: clinic.email, role: 'CLINIC' as const, name: clinic.nameFr },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    logger.info(`Clinic registered: ${clinic.nameFr} (${clinic.email})`);

    return {
      token,
      user: {
        id: clinic.id,
        email: clinic.email,
        name: clinic.nameFr,
        role: 'CLINIC',
      },
    };
  }

  async loginClinic(data: LoginDTO): Promise<AuthResponse> {
    const clinic = await clinicRepository.findByEmail(data.email);
    if (!clinic) throw new UnauthorizedError('Clinic not found');

    // Check verification and suspension FIRST
    if (!clinic.isVerified) throw new UnauthorizedError('Clinic is pending verification');
    if (clinic.isSuspended) throw new UnauthorizedError('Clinic has been suspended');

    // Then check password
    const isPasswordValid = await bcrypt.compare(data.password, clinic.password);
    if (!isPasswordValid) throw new UnauthorizedError('Invalid email or password');

    const token = jwt.sign(
      { id: clinic.id, email: clinic.email, role: 'CLINIC' as const, name: clinic.nameFr },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: { id: clinic.id, email: clinic.email, name: clinic.nameFr, role: 'CLINIC' },
    };
  }

  async registerDoctor(data: RegisterDoctorDTO, ip?: string): Promise<AuthResponse> {
    const [emailExists, phoneExists] = await Promise.all([
      doctorRepository.emailExists(data.email),
      doctorRepository.phoneExists(data.phone),
    ]);

    if (emailExists) {
      throw new ConflictError('Email already registered', [
        { field: 'email', message: 'A doctor with this email already exists' },
      ]);
    }

    if (phoneExists) {
      throw new ConflictError('Phone already registered', [
        { field: 'phone', message: 'A doctor with this phone already exists' },
      ]);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);

    const doctor = await doctorRepository.create({
      email: data.email,
      password: hashedPassword,
      firstNameFr: data.firstNameFr,
      firstNameAr: data.firstNameAr,
      lastNameFr: data.lastNameFr,
      lastNameAr: data.lastNameAr,
      phone: data.phone,
      wilayaId: data.wilayaId,
    });

    // Send welcome notification
    eventEmitter.emit('notification', {
      userId: doctor.id,
      title: '👨‍⚕️ Welcome to Iyadati!',
      body: 'Your doctor account has been created. Please upload your documents to get verified.',
      type: 'system',
      data: { type: 'welcome' },
    });

    const token = jwt.sign(
      { id: doctor.id, email: doctor.email, role: 'DOCTOR' as const, name: `${doctor.firstNameFr} ${doctor.lastNameFr}` },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    eventEmitter.emit('audit', {
      action: 'doctor.registered',
      entity: 'Doctor',
      entityId: doctor.id,
      performedBy: doctor.id,
      details: { email: doctor.email, name: `${doctor.firstNameFr} ${doctor.lastNameFr}` },
      ip,
    });

    logger.info(`Doctor registered: ${doctor.email}`);

    return {
      token,
      user: {
        id: doctor.id,
        email: doctor.email,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
        role: 'DOCTOR',
      },
    };
  }

  async loginDoctor(data: LoginDTO): Promise<AuthResponse> {
    const doctor = await doctorRepository.findByEmail(data.email);
    if (!doctor) throw new UnauthorizedError('Invalid email or password');

    // Check verification and suspension FIRST
    if (!doctor.isVerified) throw new UnauthorizedError('Your account is pending verification');
    if (doctor.isSuspended) throw new UnauthorizedError('Your account has been suspended');

    // Then check password
    const isPasswordValid = await bcrypt.compare(data.password, doctor.password);
    if (!isPasswordValid) throw new UnauthorizedError('Invalid email or password');

    const token = jwt.sign(
      { id: doctor.id, email: doctor.email, role: 'DOCTOR' as const, name: `${doctor.firstNameFr} ${doctor.lastNameFr}` },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return {
      token,
      user: {
        id: doctor.id,
        email: doctor.email,
        name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
        role: 'DOCTOR',
      },
    };
  }
}



export const authService = new AuthService();

