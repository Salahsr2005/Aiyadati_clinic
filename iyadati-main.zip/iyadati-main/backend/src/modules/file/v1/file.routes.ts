// src/core/routes/file.routes.ts
import { Router } from 'express';
import { fileController } from './file.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';

const router = Router();

// ============================================================
// PUBLIC FILE ACCESS (No authentication required)
// ============================================================

/**
 * GET /api/v1/files/public/:fileId
 * Serve public file (images, logos, gallery, etc.)
 * No authentication required - rate limited to prevent abuse
 */
router.get(
  '/public/:fileId',
  createRateLimiter({
    windowMinutes: 1,
    maxRequests: 60,
    message: 'Too many public file requests',
  }),
  fileController.getPublicFile
);

/**
 * POST /api/v1/files/public/:fileId/url
 * Get public URL for a file (useful for frontend)
 * No authentication required
 */
router.post(
  '/public/:fileId/url',
  createRateLimiter({
    windowMinutes: 1,
    maxRequests: 30,
    message: 'Too many requests',
  }),
  fileController.getPublicUrl
);

// ============================================================
// PRIVATE FILE ACCESS (Authentication required)
// ============================================================

/**
 * GET /api/v1/files/private/:fileId
 * Serve private file with signed URL verification
 * Requires authentication and valid signed URL
 */
router.get(
  '/private/:fileId',
  authenticate,
  createRateLimiter({
    windowMinutes: 1,
    maxRequests: 30,
    message: 'Too many file access requests',
  }),
  fileController.getPrivateFile
);

/**
 * POST /api/v1/files/private/:fileId/access
 * Generate a fresh signed URL for private file access
 * Requires authentication
 */
router.post(
  '/private/:fileId/access',
  authenticate,
  createRateLimiter({
    windowMinutes: 5,
    maxRequests: 20,
    message: 'Too many access URL generation requests',
  }),
  fileController.getSignedUrl
);

/**
 * GET /api/v1/files/private/:fileId/metadata
 * Get file metadata (name, type, size, etc.)
 * Requires authentication
 */
router.get(
  '/private/:fileId/metadata',
  authenticate,
  fileController.getFileMetadata
);

/**
 * DELETE /api/v1/files/private/:fileId
 * Delete a file
 * Requires authentication (user must own the file or be admin)
 */
router.delete(
  '/private/:fileId',
  authenticate,
  fileController.deleteFile
);

// ============================================================
// LEGACY SUPPORT (Backward compatibility)
// ============================================================

/**
 * GET /api/v1/files/legacy/:fileName
 * Legacy endpoint for backward compatibility during migration
 * Enable with ENABLE_LEGACY_FILES=true
 */
router.get(
  '/legacy/:fileName',
  fileController.getLegacyFile
);

export default router;

