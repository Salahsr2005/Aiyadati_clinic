// src/core/controllers/file.controller.ts
import { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import { fileService } from './file.service';
import { 
  isValidFileId, 
  verifySignedUrl, 
  getFilePath,
  fileExists,
  generateSignedUrl 
} from '../../../core/utils/signed-url';
import { NotFoundError, ForbiddenError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { ResponseUtil } from '../../../core/utils/response';

export class FileController {
  /**
   * Get a fresh signed URL for private file access
   * POST /api/v1/files/private/:fileId/access
   */
  getSignedUrl = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // ✅ FIX: Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const url = await fileService.getSignedUrl(fileId, userId, role);
      ResponseUtil.success(res, { url, expiresIn: 1800 }, 'Signed URL generated successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get public file URL
   * POST /api/v1/files/public/:fileId/url
   */
  getPublicUrl = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const url = await fileService.getPublicUrl(fileId);
      ResponseUtil.success(res, { url }, 'Public URL generated successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Serve private file with signed URL verification
   * GET /api/v1/files/private/:fileId
   */
  getPrivateFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const { expires, signature } = req.query;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      // Validate required params
      if (!expires || !signature || typeof expires !== 'string' || typeof signature !== 'string') {
        ResponseUtil.badRequest(res, 'Missing expires or signature parameters');
        return;
      }

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // ✅ FIX: Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      // Validate fileId format
      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      // Verify signed URL
      if (!verifySignedUrl(fileId, expires, signature)) {
        ResponseUtil.forbidden(res, 'Invalid or expired link');
        return;
      }

      // Get file from service with access control
      const { buffer, metadata, contentType } = await fileService.getFile(
        fileId,
        userId,
        role,
        false // isPublic = false
      );

      // Set response headers
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(metadata.fileName)}"`);
      res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');
      res.setHeader('Content-Length', buffer.length);

      // Send file
      res.send(buffer);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Serve public file (no authentication required)
   * GET /api/v1/files/public/:fileId
   */
  getPublicFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;

      // Validate fileId format
      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      // Get file from service (no auth required for public)
      const { buffer, metadata, contentType } = await fileService.getFile(
        fileId,
        '', // No userId needed for public
        '', // No userRole needed for public
        true // isPublic = true
      );

      // Set response headers
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(metadata.fileName)}"`);
      res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache for 1 year
      res.setHeader('Content-Length', buffer.length);

      // Send file
      res.send(buffer);
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get file metadata by ID
   * GET /api/v1/files/private/:fileId/metadata
   */
  getFileMetadata = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // ✅ FIX: Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      const metadata = await fileService.getFileMetadata(fileId, userId, role);
      ResponseUtil.success(res, metadata, 'File metadata retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Delete file by ID
   * DELETE /api/v1/files/private/:fileId
   */
  deleteFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileId } = req.params;
      const userId = req.user?.id;
      const userRole = req.user?.role;

      if (!userId) {
        ResponseUtil.unauthorized(res, 'Authentication required');
        return;
      }

      // ✅ FIX: Ensure userRole is a string, default to empty if undefined
      const role = userRole || '';

      if (!isValidFileId(fileId)) {
        ResponseUtil.badRequest(res, 'Invalid file ID format');
        return;
      }

      await fileService.deleteFile(fileId, userId, role, false);
      ResponseUtil.success(res, null, 'File deleted successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Legacy support - for backward compatibility during migration
   * GET /api/v1/files/legacy/:fileName
   */
  getLegacyFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { fileName } = req.params;
      const { expires, signature } = req.query;

      // Only allow if legacy mode is enabled
      if (process.env.ENABLE_LEGACY_FILES !== 'true') {
        ResponseUtil.notFound(res, 'Legacy file access is disabled');
        return;
      }

      if (!expires || !signature || typeof expires !== 'string' || typeof signature !== 'string') {
        ResponseUtil.badRequest(res, 'Missing or invalid parameters');
        return;
      }

      // Verify using legacy verification
      const { verifySignedUrlLegacy } = await import('../../../core/utils/signed-url');
      if (!verifySignedUrlLegacy(fileName, expires, signature)) {
        ResponseUtil.forbidden(res, 'Invalid or expired link');
        return;
      }

      if (!fileExists(fileName)) {
        ResponseUtil.notFound(res, 'File not found');
        return;
      }

      const filePath = getFilePath(fileName);
      res.sendFile(filePath);
    } catch (error) {
      next(error);
    }
  };
}

export const fileController = new FileController();

