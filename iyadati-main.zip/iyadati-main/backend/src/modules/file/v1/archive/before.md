// src/modules/file/v1/file.service.ts

import fs from 'fs/promises';
import path from 'path';
import { prisma } from '../../../core/utils/prisma';
import { 
  generateSignedUrl, 
  generatePublicUrl,
  verifySignedUrl,
  isValidFileId,
  isUrlExpired,
  getFilePath 
} from '../../../core/utils/signed-url';
import { NotFoundError, ForbiddenError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';

// Storage abstraction imports
import { StorageFactory } from '../../../core/storage/storage.factory';
import { StorageProvider } from '../../../core/interfaces/storage.interface';

// Repository imports
import {
  userDocumentRepository,
} from '../../../repositories/user-document.repository';
import {
  doctorDocumentRepository,
} from '../../../repositories/doctor-document.repository';
import {
  clinicDocumentRepository,
} from '../../../repositories/clinic-document.repository';
import {
  clinicGalleryRepository,
} from '../../../repositories/clinic-gallery.repository';
import {
  clinicServiceImageRepository,
} from '../../../repositories/clinic-service-image.repository';
import { specialtyRepository } from '../../../repositories/specialty.repository';
import { productImageRepository } from '../../../repositories/product-image.repository';
import { sellerDocumentRepository } from '../../../repositories/seller-document.repository';
import { doctorLogoRepository } from '../../../repositories/doctor-logo.repository';

import { fileRegistryRepository } from '../../../repositories/file-registry.repository';


// Type definitions for repositories (using the instance types)
type PrivateRepository = typeof userDocumentRepository | typeof doctorDocumentRepository | typeof clinicDocumentRepository | typeof sellerDocumentRepository | typeof fileRegistryRepository
type PublicRepository = typeof clinicGalleryRepository | typeof clinicServiceImageRepository | typeof productImageRepository | typeof doctorLogoRepository | typeof specialtyRepository ;
// Map of repositories by owner type
const REPOSITORY_MAP: Record<string, PrivateRepository> = {
  user: userDocumentRepository,
  doctor: doctorDocumentRepository,
  clinic: clinicDocumentRepository,
  seller: sellerDocumentRepository,
};

const PUBLIC_REPOSITORY_MAP: Record<string, PublicRepository> = {
  gallery: clinicGalleryRepository,
  serviceImage: clinicServiceImageRepository,
  productImage: productImageRepository,
  doctorLogo: doctorLogoRepository,
  specialty: specialtyRepository,
};

// Type for file record with table info
interface FileRecord {
  _table: string;
  id: string;
  fileId: string;
  filePath: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  doctorId?: string;
  userId?: string;
  clinicId?: string;
  storageType?: string;
  [key: string]: any;
}

export class FileService {
  // Storage provider instance
  private storage: StorageProvider;

  constructor() {
    this.storage = StorageFactory.getInstance();
  }

  /**
   * Get file by ID with access control
   */
  async getFile(
    fileId: string,
    userId: string,
    userRole: string,
    isPublic: boolean = false
  ): Promise<{ buffer: Buffer; metadata: any; contentType: string }> {
    // Validate fileId format
    if (!isValidFileId(fileId)) {
      throw new BadRequestError('Invalid file ID format');
    }

    // Find file in database
    const file = await this.findFileById(fileId, isPublic);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Check access permissions (skip for public files)
    if (!isPublic) {
      await this.checkAccess(file, userId, userRole);
    }

    // Use storage abstraction instead of direct filesystem
    // OLD: const fullPath = path.join(process.cwd(), 'uploads', file.filePath);
    // OLD: await fs.access(fullPath);
    // OLD: const buffer = await fs.readFile(fullPath);
    
    // NEW: Use storage provider
    const result = await this.storage.download(file.filePath);

    // Update access count (skip for public to reduce DB load)
    if (!isPublic) {
      await this.incrementAccessCount(file, fileId);
    }

    // Log access (only for private files)
    if (!isPublic) {
      logger.info(`File accessed: ${fileId} by user ${userId}`);
    }

    return {
      buffer: result.buffer,
      metadata: file,
      contentType: file.fileType,
    };
  }

  /**
   * Generate signed URL for private file
   */
  async getSignedUrl(fileId: string, userId: string, userRole: string): Promise<string> {
    // Validate file exists and user has access
    const file = await this.findFileById(fileId, false);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    await this.checkAccess(file, userId, userRole);

    return generateSignedUrl(fileId);
  }

  /**
   * Get public URL for public file
   */
  async getPublicUrl(fileId: string): Promise<string> {
    const file = await this.findFileById(fileId, true);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    return generatePublicUrl(fileId);
  }

  /**
   * Delete file by ID
   */
  async deleteFile(
    fileId: string,
    userId: string,
    userRole: string,
    isPublic: boolean = false
  ): Promise<void> {
    const file = await this.findFileById(fileId, isPublic);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Check if user can delete
    await this.checkDeleteAccess(file, userId, userRole);

    // ✅ CHANGED: Use storage abstraction for delete
    // OLD: const fullPath = path.join(process.cwd(), 'uploads', file.filePath);
    // OLD: await fs.unlink(fullPath);
    
    // NEW: Use storage provider
    const result = await this.storage.delete(file.filePath);
    if (!result.success) {
      logger.warn(`Failed to delete file from storage: ${fileId} - ${result.message}`);
    }

    // Delete from database
    await this.deleteFromDatabase(file, fileId, isPublic);

    logger.info(`File deleted: ${fileId} by user ${userId}`);
  }

  /**
   * Get file metadata
   */
  async getFileMetadata(fileId: string, userId: string, userRole: string): Promise<any> {
    const file = await this.findFileById(fileId, false);
    if (!file) {
      throw new NotFoundError('File not found');
    }

    await this.checkAccess(file, userId, userRole);

    // Return sanitized metadata (remove sensitive fields)
    const { filePath, _table, ...metadata } = file;
    return metadata;
  }

  /**
   * Find file in all document tables
   */
  private async findFileById(fileId: string, isPublic: boolean): Promise<FileRecord | null> {
    if (isPublic) {
      // Check public tables
      for (const [key, repo] of Object.entries(PUBLIC_REPOSITORY_MAP)) {
        const file = await repo.findByFileId(fileId);
        if (file) {
          // Cast to FileRecord with _table
          const record = file as any;
          record._table = key;
          return record as FileRecord;
        }
      }
      return null;
    }

    // Check private tables
    for (const [key, repo] of Object.entries(REPOSITORY_MAP)) {
      const file = await repo.findByFileId(fileId);
      if (file) {
        // Cast to FileRecord with _table
        const record = file as any;
        record._table = key;
        return record as FileRecord;
      }
    }
    return null;
  }

  /**
   * Check access permissions for private files
   */
  private async checkAccess(
    file: FileRecord,
    userId: string,
    userRole: string
  ): Promise<void> {
    // Admins can access everything
    if (['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      return;
    }

    // Check ownership
    const ownerId = file.doctorId || file.userId || file.clinicId;
    if (ownerId === userId) {
      return;
    }

    // Check if user has specific permissions (e.g., clinic staff)
    if (file.clinicId) {
      const hasAccess = await this.checkClinicAccess(file.clinicId, userId);
      if (hasAccess) return;
    }

    throw new ForbiddenError('You do not have access to this file');
  }

  /**
   * Check if user has access to clinic files
   */
  private async checkClinicAccess(clinicId: string, userId: string): Promise<boolean> {
    // Check if user is a doctor in this clinic
    const clinicDoctor = await prisma.clinicDoctor.findFirst({
      where: {
        clinicId,
        doctorId: userId,
        status: 'ACCEPTED',
        isActive: true,
      },
    });

    return !!clinicDoctor;
  }

  /**
   * Check delete permissions
   */
  private async checkDeleteAccess(
    file: FileRecord,
    userId: string,
    userRole: string
  ): Promise<void> {
    // Admins can delete anything
    if (['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      return;
    }

    // Users can only delete their own files
    const ownerId = file.doctorId || file.userId || file.clinicId;
    if (ownerId !== userId) {
      throw new ForbiddenError('You can only delete your own files');
    }
  }

  /**
   * Increment access count
   */
  private async incrementAccessCount(
    file: FileRecord,
    fileId: string
  ): Promise<void> {
    const table = file._table;
    
    // Check private repositories first
    if (REPOSITORY_MAP[table]) {
      const repo = REPOSITORY_MAP[table];
      if (repo && typeof repo.incrementAccessCount === 'function') {
        await repo.incrementAccessCount(fileId);
      }
      return;
    }
    
    // Check public repositories
    if (PUBLIC_REPOSITORY_MAP[table]) {
      const repo = PUBLIC_REPOSITORY_MAP[table];
      if (repo && typeof repo.incrementAccessCount === 'function') {
        await repo.incrementAccessCount(fileId);
      }
    }
  }

  /**
   * Delete from database
   */
  private async deleteFromDatabase(
    file: FileRecord,
    fileId: string,
    isPublic: boolean
  ): Promise<void> {
    const table = file._table;
    
    if (isPublic) {
      if (PUBLIC_REPOSITORY_MAP[table]) {
        const repo = PUBLIC_REPOSITORY_MAP[table];
        if (repo && typeof repo.deleteByFileId === 'function') {
          await repo.deleteByFileId(fileId);
        }
      }
    } else {
      if (REPOSITORY_MAP[table]) {
        const repo = REPOSITORY_MAP[table];
        if (repo && typeof repo.deleteByFileId === 'function') {
          await repo.deleteByFileId(fileId);
        }
      }
    }
  }
}

export const fileService = new FileService();

