📋 Complete File System Architecture - Full Overview
🎯 High-Level Summary
We have built a secure, scalable file management system with:

UUID-based file IDs (no path exposure in URLs)

Public/Private storage separation

Storage abstraction (Phase 2 - ready for MinIO/S3)

Access control (ownership + role-based)

Signed URLs for private files (30-minute expiry)

📁 1. Directory Structure
text
uploads/
├── public/                          # Publicly accessible files (no auth needed)
│   ├── logos/                       # Doctor photos, Clinic logos, Specialty images
│   │   └── {uuid}.{ext}            # e.g., 550e8400-....png
│   ├── gallery/                     # Clinic gallery images
│   │   └── {uuid}.{ext}
│   ├── service-images/              # Clinic service images
│   │   └── {uuid}.{ext}
│   └── products/                    # E-commerce product images
│       └── {uuid}.{ext}
│
└── private/                         # Private files (require authentication)
    ├── doctor-documents/            # Doctor documents (degree, license, etc.)
    │   └── {uuid}.{ext}
    ├── user-documents/              # User medical documents
    │   └── {uuid}.{ext}
    ├── clinic-documents/            # Clinic documents
    │   └── {uuid}.{ext}
    └── ecommerce-documents/         # Seller verification documents
        └── {uuid}.{ext}
🗄️ 2. Database Schema - File Models
All File Models Follow the Same Pattern:
prisma
model [ModelName] {
  id          String   @id @default(uuid())
  
  // Relationship
  [owner]Id   String   @map("[owner]_id")
  [owner]     [Owner]  @relation(...)
  
  // === FILE IDENTIFIERS (SECURITY) ===
  fileId      String   @unique @default(uuid()) @map("file_id")
  storageKey  String   @unique @map("storage_key")
  
  // === FILE METADATA ===
  fileName    String   @map("file_name")
  fileType    String   @map("file_type")
  fileSize    Int      @map("file_size")
  filePath    String   @map("file_path")
  
  // === CLASSIFICATION ===
  storageType String   @default("private") @map("storage_type")  // 'public' | 'private'
  category    String   @default("document") @map("category")
  docType     String   @map("doc_type")
  
  // === AUDIT ===
  accessCount Int      @default(0) @map("access_count")
  lastAccessed DateTime? @map("last_accessed")
  expiresAt   DateTime? @map("expires_at")
  
  // === TIMESTAMPS ===
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
Models:
Model	Owner	Storage Type	Category	Purpose
DoctorDocument	Doctor	Private	document	Doctor verification docs
UserDocument	User	Private	document	User medical records
ClinicDocument	Clinic	Private	document	Clinic license/registration
ClinicGallery	Clinic	Public	gallery	Clinic public images
ClinicServiceImage	ClinicService	Public	service-image	Service images
DoctorLogo	Doctor	Public	logo	Doctor profile photos
ProductImage	Product	Public	product-image	E-commerce product images
SellerDocument	User	Private	document	Seller verification docs
Specialty	N/A	Public (single image)	logo	Specialty images
🗂️ 3. Repositories
Base Repository
File: src/repositories/base.repository.ts

Purpose: Abstract base class with common CRUD operations

Key Methods:

typescript
- findById(id: string)
- findByFileId(fileId: string)      // Find by UUID
- findByStorageKey(storageKey: string) // Find by disk filename
- delete(id: string)
- deleteByFileId(fileId: string)
- incrementAccessCount(fileId: string)
- findExpiredDocuments()
Document Repositories
Repository	File	Extends Base?
UserDocumentRepository	user-document.repository.ts	✅ Yes
DoctorDocumentRepository	doctor-document.repository.ts	✅ Yes
ClinicDocumentRepository	clinic-document.repository.ts	✅ Yes
ClinicGalleryRepository	clinic-gallery.repository.ts	✅ Yes
ClinicServiceImageRepository	clinic-service-image.repository.ts	✅ Yes
DoctorLogoRepository	doctor-logo.repository.ts	✅ Yes
ProductImageRepository	product-image.repository.ts	✅ Yes
SellerDocumentRepository	seller-document.repository.ts	✅ Yes
SpecialtyRepository	specialty.repository.ts	✅ Yes
ClinicRepository	clinic.repository.ts	❌ No (has logoFileId)
🔧 4. Upload Middleware
File: src/core/middleware/upload.middleware.ts

Purpose: Handle file uploads with Multer
Key Functions:
typescript
// Public uploads (no auth for viewing)
uploadLogo                    → public/logos/
uploadGalleryImage            → public/gallery/
uploadServiceImage            → public/service-images/
uploadProductImage            → public/products/

// Private uploads (auth required)
uploadDoctorDocument          → private/doctor-documents/
uploadUserDocument            → private/user-documents/
uploadClinicDocument          → private/clinic-documents/
uploadSellerDocument          → private/ecommerce-documents/

// Multiple files
uploadMultipleDocuments       → private/doctor-documents/ (up to 5 files)
File Naming:
typescript
// UUID v4 + extension
const uuid = crypto.randomUUID();  // "550e8400-e29b-41d4-a716-446655440000"
const filename = `${uuid}${ext}`;  // "550e8400-....pdf"
🔐 5. Signed URL Utility
File: src/core/utils/signed-url.ts

Purpose: Generate and verify secure URLs
Key Functions:
typescript
// Generate private file URL (expires in 30 min)
generateSignedUrl(fileId: string): string
// Returns: /api/v1/files/private/{fileId}?expires=123&signature=abc

// Generate public file URL (no expiry)
generatePublicUrl(fileId: string): string
// Returns: /api/v1/files/public/{fileId}

// Verify signed URL
verifySignedUrl(fileId, expires, signature): boolean

// Validate UUID format
isValidFileId(fileId): boolean
URL Examples:
Type	URL Pattern
Public	/api/v1/files/public/{uuid}
Private	/api/v1/files/private/{uuid}?expires=123&signature=abc
📦 6. File Service
File: src/modules/file/v1/file.service.ts

Purpose: Core business logic for all file operations
Key Methods:
typescript
class FileService {
  // Get file with access control
  async getFile(fileId, userId, userRole, isPublic)
  
  // Generate signed URL for private file
  async getSignedUrl(fileId, userId, userRole)
  
  // Get public URL
  async getPublicUrl(fileId)
  
  // Delete file (disk + database)
  async deleteFile(fileId, userId, userRole, isPublic)
  
  // Get file metadata
  async getFileMetadata(fileId, userId, userRole)
  
  // Find file in all tables
  private async findFileById(fileId, isPublic)
  
  // Check access permissions
  private async checkAccess(file, userId, userRole)
  
  // Check delete permissions
  private async checkDeleteAccess(file, userId, userRole)
  
  // Increment access count
  private async incrementAccessCount(file, fileId)
  
  // Delete from database
  private async deleteFromDatabase(file, fileId, isPublic)
}
Repository Mapping:
typescript
// Private repositories
const REPOSITORY_MAP = {
  user: userDocumentRepository,
  doctor: doctorDocumentRepository,
  clinic: clinicDocumentRepository,
  seller: sellerDocumentRepository,
};

// Public repositories (for file lookup)
const PUBLIC_REPOSITORY_MAP = {
  gallery: clinicGalleryRepository,
  serviceImage: clinicServiceImageRepository,
  productImage: productImageRepository,
  doctorLogo: doctorLogoRepository,
  specialty: specialtyRepository,
  clinic: clinicRepository,  // For clinic logos
};
🌐 7. File Controller & Routes
File: src/modules/file/v1/file.controller.ts

Endpoints:
Method	Endpoint	Description
GET	/files/public/:fileId	Serve public file
POST	/files/public/:fileId/url	Get public URL
GET	/files/private/:fileId	Serve private file (signed URL required)
POST	/files/private/:fileId/access	Generate signed URL
GET	/files/private/:fileId/metadata	Get file metadata
DELETE	/files/private/:fileId	Delete file
GET	/files/legacy/:fileName	Legacy support (optional)
🔄 8. Storage Abstraction (Phase 2)
Interface: src/core/interfaces/storage.interface.ts
typescript
interface StorageProvider {
  upload(file, options): Promise<UploadResult>
  download(identifier, options): Promise<FileOutput>
  delete(identifier, options): Promise<DeleteResult>
  exists(identifier): Promise<boolean>
  getSignedUrl(identifier, expiresIn): Promise<string>
  getPublicUrl(identifier): string
  getMetadata(identifier): Promise<FileMetadata>
  updateMetadata(identifier, metadata): Promise<FileMetadata>
  copy(source, destination): Promise<CopyResult>
  move(source, destination): Promise<MoveResult>
}
Implementation: src/core/storage/providers/local.provider.ts
Uses Node.js fs module

Files saved to uploads/ directory

Signed URLs generated with HMAC-SHA256

Factory: src/core/storage/storage.factory.ts
typescript
const storage = StorageFactory.getInstance();
// Returns LocalStorageProvider (or MinIO in future)
🏗️ 9. Module Integration
How Modules Use the File System:
typescript
// Example: Doctor Service
class DoctorService {
  async uploadDocument(doctorId, file, docType) {
    // 1. Save file using multer middleware (already done)
    // 2. Create database record
    const doc = await doctorDocumentRepository.create({
      doctorId,
      fileName: file.originalname,
      filePath: `private/doctor-documents/${file.filename}`,
      storageKey: file.filename,
      docType,
      // fileId is auto-generated
    });
    
    // 3. Generate secure URL
    return {
      id: doc.id,
      accessUrl: generateSignedUrl(doc.fileId),  // ✅ Uses fileId, not path
    };
  }
  
  async deleteDocument(documentId, userId, userRole) {
    const doc = await doctorDocumentRepository.findById(documentId);
    // ✅ Uses File Service to delete from disk + database
    await fileService.deleteFile(doc.fileId, userId, userRole, false);
  }
}
📊 10. File Access Flow Diagram
text
┌─────────────────────────────────────────────────────────────────────────────┐
│                             UPLOAD FLOW                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Client ──▶ Route ──▶ Multer ──▶ Disk ──▶ Repository ──▶ Database ──▶ Client │
│   (POST)     (auth)   (save)     (file)    (create)    (record)     (URL)    │
│                                                                             │
│  1. POST /api/v1/doctor/v1/me/documents                                    │
│  2. authenticate, authorize                                                │
│  3. uploadDoctorDocument saves file to disk                               │
│  4. File saved: uploads/private/doctor-documents/{uuid}.pdf              │
│  5. Repository creates database record with fileId                        │
│  6. Response: { accessUrl: /files/private/{fileId}?expires=&signature= } │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                             ACCESS FLOW                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Client ──▶ Route ──▶ Controller ──▶ Service ──▶ Database ──▶ Disk ──▶ Client │
│   (GET)      (auth)   (validate)   (lookup)    (find)     (read)     (file)    │
│                                                                             │
│  1. GET /api/v1/files/private/{fileId}?expires=&signature=                │
│  2. authenticate (JWT)                                                    │
│  3. Controller validates signature and expiry                             │
│  4. Service finds file in database by fileId                             │
│  5. Service checks access permissions (ownership)                         │
│  6. Service downloads file from disk                                     │
│  7. Response: file with proper headers                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
🗂️ 11. Module File Reference
All Files Related to File System:
File	Purpose
prisma/schema.prisma	Database schema with all file models
src/core/middleware/upload.middleware.ts	Multer upload middleware
src/core/utils/signed-url.ts	Secure URL generation/verification
src/core/interfaces/storage.interface.ts	Storage abstraction interface
src/core/storage/storage.types.ts	Storage types
src/core/storage/providers/local.provider.ts	Local filesystem implementation
src/core/storage/storage.factory.ts	Factory pattern for storage
src/modules/file/v1/file.service.ts	Core file business logic
src/modules/file/v1/file.controller.ts	File endpoints
src/modules/file/v1/file.routes.ts	File routes
src/repositories/base.repository.ts	Base repository
src/repositories/*-document.repository.ts	Document repositories
src/config/env.ts	Environment variables (STORAGE_TYPE, etc.)
🔑 12. Key Files & Their Locations
Where Files Are Stored on Disk:
File Type	Disk Location	URL Pattern
Doctor Photo	uploads/public/logos/{uuid}.{ext}	/api/v1/files/public/{fileId}
Doctor Logo	uploads/public/logos/{uuid}.{ext}	/api/v1/files/public/{fileId}
Clinic Logo	uploads/public/logos/{uuid}.{ext}	/api/v1/files/public/{fileId}
Specialty Image	uploads/public/logos/{uuid}.{ext}	/api/v1/files/public/{fileId}
Gallery Image	uploads/public/gallery/{uuid}.{ext}	/api/v1/files/public/{fileId}
Service Image	uploads/public/service-images/{uuid}.{ext}	/api/v1/files/public/{fileId}
Product Image	uploads/public/products/{uuid}.{ext}	/api/v1/files/public/{fileId}
Doctor Document	uploads/private/doctor-documents/{uuid}.{ext}	/api/v1/files/private/{fileId}?expires=&signature=
User Document	uploads/private/user-documents/{uuid}.{ext}	/api/v1/files/private/{fileId}?expires=&signature=
Clinic Document	uploads/private/clinic-documents/{uuid}.{ext}	/api/v1/files/private/{fileId}?expires=&signature=
🎯 13. Security Summary
Layer	Security Measure
Storage	UUID filenames, no path exposure
Access	Signed URLs with HMAC-SHA256
Expiration	Private URLs expire in 30 minutes
Authentication	JWT required for private files
Authorization	Ownership and role-based access
Rate Limiting	Prevents abuse
Audit	Access count and logging
🚀 14. Phase 3 Ready
The system is designed to switch to MinIO/S3 by:

Implementing MinioStorageProvider (implements StorageProvider)

Setting STORAGE_TYPE=minio in .env

No code changes in services! (thanks to abstraction)

This document should give you full context for any future conversation about the file system! 🎉

