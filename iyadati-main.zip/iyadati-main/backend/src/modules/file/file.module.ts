import { Router } from 'express';
import fileRoutes from './v1/file.routes';

const router = Router();
router.use('/', fileRoutes);

export { router as fileModule };

