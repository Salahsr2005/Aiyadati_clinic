import { Router } from 'express';
import { ClinicServiceController } from './clinic-service.controller';
import { validateCreateService, validateUpdateService, validateAssignDoctor } from './clinic-service.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { uploadServiceImage } from '../../../core/middleware/upload.middleware';

const router = Router();
const controller = new ClinicServiceController();

// ============================================================
// Public Routes
// ============================================================

router.get('/public/search', controller.searchPublic);
router.get('/public/:id', controller.getById);

// ============================================================
// Clinic Self-Service Routes
// ============================================================

router.get('/me', authenticate, authorize('CLINIC'), controller.getMyServices);
router.post('/me', authenticate, authorize('CLINIC'), validateCreateService, controller.createMyService);
router.patch('/me/:id', authenticate, authorize('CLINIC'), validateUpdateService, controller.updateMyService);
router.delete('/me/:id', authenticate, authorize('CLINIC'), controller.deleteMyService);

// Gallery
router.post('/me/:id/images', authenticate, authorize('CLINIC'), uploadServiceImage, controller.uploadImage);
router.delete('/me/:id/images/:imageId', authenticate, authorize('CLINIC'), controller.deleteImage);

// Doctors
router.get('/me/:id/doctors', authenticate, authorize('CLINIC'), controller.getServiceDoctors);
router.post('/me/:id/doctors', authenticate, authorize('CLINIC'), validateAssignDoctor, controller.assignDoctor);
router.delete('/me/:id/doctors/:doctorId', authenticate, authorize('CLINIC'), controller.removeDoctor);

// ============================================================
// Staff Routes (Super Admin + Admin)
// ============================================================

router.get('/clinic/:clinicId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.getMyServices);
router.post('/clinic/:clinicId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateCreateService, controller.createMyService);
router.patch('/clinic/:clinicId/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateService, controller.updateMyService);
router.delete('/clinic/:clinicId/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.deleteMyService);

// Gallery (staff)
router.post('/clinic/:clinicId/:id/images', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), uploadServiceImage, controller.uploadImage);
router.delete('/clinic/:clinicId/:id/images/:imageId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.deleteImage);

// Doctors (staff)
router.get('/clinic/:clinicId/:id/doctors', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.getServiceDoctors);
router.post('/clinic/:clinicId/:id/doctors', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateAssignDoctor, controller.assignDoctor);
router.delete('/clinic/:clinicId/:id/doctors/:doctorId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.removeDoctor);

export default router;

