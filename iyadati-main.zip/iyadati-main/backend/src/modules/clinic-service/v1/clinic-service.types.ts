export interface ClinicServiceResponse {
  id: string;
  clinicId: string;
  clinic?: {
    id: string;
    nameFr: string;
    nameAr: string;
    logoUrl: string | null;
    wilaya?: { id: string; nameFr: string; nameAr: string };
    baladya?: { id: string; nameFr: string; nameAr: string } | null;
  };
  nameFr: string;
  nameAr: string;
  descriptionFr: string | null;
  descriptionAr: string | null;
  isActive: boolean;
  sortOrder: number;
  gallery: ServiceImageResponse[];
  doctors: ServiceDoctorResponse[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateServiceDTO {
  nameFr: string;
  nameAr: string;
  descriptionFr?: string;
  descriptionAr?: string;
  sortOrder?: number;
}

export interface UpdateServiceDTO {
  nameFr?: string;
  nameAr?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  sortOrder?: number;
  isActive?: boolean;
}

export interface ServiceImageResponse {
  id: string;
  serviceId: string;
  imagePath: string;
  imageUrl: string; // ✅ Now uses fileId-based public URL
  captionFr: string | null;
  captionAr: string | null;
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
}

export interface AssignDoctorDTO {
  doctorId: string;
  isPrimary?: boolean;
}

export interface ServiceDoctorResponse {
  id: string;
  serviceId: string;
  doctorId: string;
  isPrimary: boolean;
  doctor: {
    id: string;
    firstNameFr: string;
    firstNameAr: string;
    lastNameFr: string;
    lastNameAr: string;
    photoUrl: string | null;
    specialties?: { id: string; nameFr: string; nameAr: string }[];
  };
  createdAt: string;
}

