import { Request, Response, NextFunction } from 'express';
import { clinicServiceService } from './clinic-service.service';
import { ResponseUtil } from '../../../core/utils/response';

export class ClinicServiceController {
  // === Public ===

  searchPublic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await clinicServiceService.searchPublic(req.query);
      ResponseUtil.paginated(
        res,
        result.services,
        result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 10,
        'Services retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  getById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const service = await clinicServiceService.getById(req.params.id);
      ResponseUtil.success(res, service, 'Service retrieved successfully');
    } catch (error) { next(error); }
  };

  // === Clinic Self-Service (uses req.user.id as clinicId) ===

  getMyServices = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinicId = req.params.clinicId || req.user!.id;
      const services = await clinicServiceService.getByClinicId(clinicId);
      ResponseUtil.success(res, services, 'Services retrieved successfully');
    } catch (error) { next(error); }
  };

  createMyService = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinicId = req.params.clinicId || req.user!.id;
      const service = await clinicServiceService.create(clinicId, req.body);
      ResponseUtil.created(res, service, 'Service created successfully');
    } catch (error) { next(error); }
  };

  updateMyService = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const service = await clinicServiceService.update(req.params.id, req.body);
      ResponseUtil.success(res, service, 'Service updated successfully');
    } catch (error) { next(error); }
  };

  deleteMyService = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicServiceService.delete(req.params.id);
      ResponseUtil.success(res, null, 'Service deleted successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // GALLERY
  // ============================================================

  uploadImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Image file is required'); return; }
      const img = await clinicServiceService.uploadImage(
        req.params.id,
        req.file,
        req.body.captionFr,
        req.body.captionAr
      );
      ResponseUtil.created(res, img, 'Image uploaded successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // UPDATED: Delete image with clinicId
  // ============================================================

  deleteImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // For self-service, use req.user.id as clinicId
      const clinicId = req.user?.id;
      await clinicServiceService.deleteImage(req.params.imageId, clinicId as string);
      ResponseUtil.success(res, null, 'Image deleted successfully');
    } catch (error) { next(error); }
  };

  // === Doctors ===

  assignDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await clinicServiceService.assignDoctor(req.params.id, req.body);
      ResponseUtil.created(res, result, 'Doctor assigned successfully');
    } catch (error) { next(error); }
  };

  removeDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicServiceService.removeDoctor(req.params.id, req.params.doctorId);
      ResponseUtil.success(res, null, 'Doctor removed successfully');
    } catch (error) { next(error); }
  };

  getServiceDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctors = await clinicServiceService.getServiceDoctors(req.params.id);
      ResponseUtil.success(res, doctors, 'Doctors retrieved successfully');
    } catch (error) { next(error); }
  };
}

