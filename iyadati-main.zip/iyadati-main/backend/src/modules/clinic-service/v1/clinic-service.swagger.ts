/**
 * @swagger
 * tags:
 *   name: Clinic Services
 *   description: Clinic & Hospital services management (Public, Self-service, and Staff)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     ClinicServiceResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         clinicId:
 *           type: string
 *           format: uuid
 *         clinic:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             nameFr:
 *               type: string
 *               example: "Hôpital Central"
 *             nameAr:
 *               type: string
 *               example: "المستشفى المركزي"
 *             logoUrl:
 *               type: string
 *               nullable: true
 *               description: Public URL for clinic logo (uses fileId instead of path)
 *               example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *             wilaya:
 *               type: object
 *               nullable: true
 *               properties:
 *                 id:
 *                   type: string
 *                 nameFr:
 *                   type: string
 *                 nameAr:
 *                   type: string
 *             baladya:
 *               type: object
 *               nullable: true
 *               properties:
 *                 id:
 *                   type: string
 *                 nameFr:
 *                   type: string
 *                 nameAr:
 *                   type: string
 *         nameFr:
 *           type: string
 *           example: "Consultation Cardiologie"
 *         nameAr:
 *           type: string
 *           example: "استشارة أمراض القلب"
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *           example: "Consultation spécialisée avec un cardiologue expérimenté"
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *           example: "استشارة متخصصة مع طبيب قلب ذو خبرة"
 *         isActive:
 *           type: boolean
 *           description: Whether the service is currently active
 *         sortOrder:
 *           type: integer
 *           description: Display order (lower numbers first)
 *         gallery:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ServiceImageResponse'
 *         doctors:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ServiceDoctorResponse'
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *
 *     CreateServiceRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 200
 *           example: "Consultation Cardiologie"
 *           description: Service name in French
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 200
 *           example: "استشارة أمراض القلب"
 *           description: Service name in Arabic
 *         descriptionFr:
 *           type: string
 *           maxLength: 2000
 *           nullable: true
 *           example: "Consultation spécialisée avec un cardiologue expérimenté"
 *           description: French description (optional)
 *         descriptionAr:
 *           type: string
 *           maxLength: 2000
 *           nullable: true
 *           example: "استشارة متخصصة مع طبيب قلب ذو خبرة"
 *           description: Arabic description (optional)
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *           default: 0
 *           example: 1
 *           description: Display order (optional, defaults to 0)
 *
 *     UpdateServiceRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 200
 *           example: "Consultation Cardiologie Avancée"
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 200
 *           example: "استشارة أمراض القلب المتقدمة"
 *         descriptionFr:
 *           type: string
 *           maxLength: 2000
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           maxLength: 2000
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *         isActive:
 *           type: boolean
 *           description: Enable or disable the service
 *
 *     ServiceImageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         serviceId:
 *           type: string
 *           format: uuid
 *         imagePath:
 *           type: string
 *           description: Internal file path (not exposed in URLs)
 *         imageUrl:
 *           type: string
 *           description: |
 *             Public URL for the service image.
 *             Uses fileId (UUID) instead of exposing the file path.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         captionFr:
 *           type: string
 *           nullable: true
 *         captionAr:
 *           type: string
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *         isActive:
 *           type: boolean
 *         createdAt:
 *           type: string
 *           format: date-time
 *
 *     AssignDoctorRequest:
 *       type: object
 *       required:
 *         - doctorId
 *       properties:
 *         doctorId:
 *           type: string
 *           format: uuid
 *           description: Doctor ID to assign to the service
 *         isPrimary:
 *           type: boolean
 *           default: false
 *           description: Mark as primary doctor for this service
 *
 *     ServiceDoctorResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         serviceId:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         isPrimary:
 *           type: boolean
 *         doctor:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             firstNameFr:
 *               type: string
 *             firstNameAr:
 *               type: string
 *             lastNameFr:
 *               type: string
 *             lastNameAr:
 *               type: string
 *             photoUrl:
 *               type: string
 *               nullable: true
 *             specialties:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   nameFr:
 *                     type: string
 *                   nameAr:
 *                     type: string
 *         createdAt:
 *           type: string
 *           format: date-time
 */

// ======================================================================
//  PUBLIC ENDPOINTS
// ======================================================================

/**
 * @swagger
 * /api/v1/clinic-services/v1/public/search:
 *   get:
 *     summary: Search clinic services (Public)
 *     description: |
 *       Search for services across all verified clinics/hospitals.
 *       No authentication required. Results include clinic info and assigned doctors.
 *     tags: [Clinic Services]
 *     parameters:
 *       - in: query
 *         name: query
 *         schema:
 *           type: string
 *         description: Search by service name (Fr/Ar)
 *         example: "cardiologie"
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specific clinic/hospital
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 50
 *     responses:
 *       200:
 *         description: Services retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicServiceResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     total:
 *                       type: integer
 *                       example: 25
 *                     page:
 *                       type: integer
 *                       example: 1
 *                     limit:
 *                       type: integer
 *                       example: 10
 *                 message:
 *                   type: string
 *                   example: "Services retrieved successfully"
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/public/{id}:
 *   get:
 *     summary: Get service by ID (Public)
 *     description: Get full details of a service including gallery and assigned doctors.
 *     tags: [Clinic Services]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     responses:
 *       200:
 *         description: Service retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicServiceResponse'
 *                 message:
 *                   type: string
 *                   example: "Service retrieved successfully"
 *       404:
 *         description: Service not found
 */

// ======================================================================
//  CLINIC SELF-SERVICE ENDPOINTS (CLINIC JWT)
// ======================================================================

/**
 * @swagger
 * /api/v1/clinic-services/v1/me:
 *   get:
 *     summary: Get my facility services (Self)
 *     description: Get all services for the authenticated clinic/hospital.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Services retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicServiceResponse'
 *                 message:
 *                   type: string
 *                   example: "Services retrieved successfully"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *
 *   post:
 *     summary: Create a new service (Self)
 *     description: Create a new service for the authenticated clinic/hospital.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateServiceRequest'
 *           examples:
 *             cardiology:
 *               summary: Cardiology Consultation
 *               value:
 *                 nameFr: "Consultation Cardiologie"
 *                 nameAr: "استشارة أمراض القلب"
 *                 descriptionFr: "Consultation spécialisée avec un cardiologue expérimenté"
 *                 descriptionAr: "استشارة متخصصة مع طبيب قلب ذو خبرة"
 *                 sortOrder: 1
 *             dental:
 *               summary: Dental Surgery
 *               value:
 *                 nameFr: "Chirurgie Dentaire"
 *                 nameAr: "جراحة الأسنان"
 *                 sortOrder: 2
 *     responses:
 *       201:
 *         description: Service created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicServiceResponse'
 *                 message:
 *                   type: string
 *                   example: "Service created successfully"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                 errors:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       field:
 *                         type: string
 *                       message:
 *                         type: string
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/me/{id}:
 *   patch:
 *     summary: Update my service (Self)
 *     description: Update a service belonging to the authenticated clinic. At least one field is required.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateServiceRequest'
 *           examples:
 *             updateName:
 *               summary: Update service name
 *               value:
 *                 nameFr: "Consultation Cardiologie Avancée"
 *                 nameAr: "استشارة أمراض القلب المتقدمة"
 *             disableService:
 *               summary: Disable service
 *               value:
 *                 isActive: false
 *             reorderService:
 *               summary: Change display order
 *               value:
 *                 sortOrder: 3
 *     responses:
 *       200:
 *         description: Service updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicServiceResponse'
 *                 message:
 *                   type: string
 *                   example: "Service updated successfully"
 *       400:
 *         description: Validation error
 *       404:
 *         description: Service not found
 *
 *   delete:
 *     summary: Delete my service (Self)
 *     description: Permanently delete a service belonging to the authenticated clinic.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     responses:
 *       200:
 *         description: Service deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Service deleted successfully"
 *       404:
 *         description: Service not found
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/me/{id}/images:
 *   post:
 *     summary: Upload service image (Self)
 *     description: |
 *       Upload an image for a service gallery.
 *       Accepted formats: JPEG, PNG, WebP, SVG. Max 5MB.
 *       File will be stored with a secure UUID and accessible via /api/v1/files/public/{fileId}
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 5MB)
 *               captionFr:
 *                 type: string
 *                 maxLength: 200
 *                 description: French caption (optional)
 *               captionAr:
 *                 type: string
 *                 maxLength: 200
 *                 description: Arabic caption (optional)
 *     responses:
 *       201:
 *         description: Image uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ServiceImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Image uploaded successfully"
 *       400:
 *         description: No file provided or invalid file type
 *       404:
 *         description: Service not found
 *       413:
 *         description: File too large (max 5MB)
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/me/{id}/images/{imageId}:
 *   delete:
 *     summary: Delete service image (Self)
 *     description: |
 *       Delete an image from a service gallery.
 *       Also deletes the physical file from storage.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Image ID
 *     responses:
 *       200:
 *         description: Image deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Image deleted successfully"
 *       404:
 *         description: Image not found
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/me/{id}/doctors:
 *   get:
 *     summary: Get assigned doctors for a service (Self)
 *     description: Get all doctors assigned to a specific service.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     responses:
 *       200:
 *         description: Doctors retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ServiceDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Doctors retrieved successfully"
 *       404:
 *         description: Service not found
 *
 *   post:
 *     summary: Assign doctor to service (Self)
 *     description: Assign an existing doctor from the clinic to this service.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AssignDoctorRequest'
 *           examples:
 *             assignDoctor:
 *               summary: Assign doctor
 *               value:
 *                 doctorId: "550e8400-e29b-41d4-a716-446655440000"
 *                 isPrimary: true
 *     responses:
 *       201:
 *         description: Doctor assigned successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ServiceDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Doctor assigned successfully"
 *       400:
 *         description: Validation error
 *       404:
 *         description: Service or doctor not found
 *       409:
 *         description: Doctor already assigned to this service
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/me/{id}/doctors/{doctorId}:
 *   delete:
 *     summary: Remove doctor from service (Self)
 *     description: Remove a doctor assignment from a service.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Doctor removed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Doctor removed successfully"
 *       404:
 *         description: Assignment not found
 */

// ======================================================================
//  STAFF ENDPOINTS (SUPER_ADMIN + ADMIN)
// ======================================================================

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}:
 *   get:
 *     summary: Get services for a facility (Staff)
 *     description: Get all services for any clinic/hospital. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *     responses:
 *       200:
 *         description: Services retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicServiceResponse'
 *                 message:
 *                   type: string
 *                   example: "Services retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *
 *   post:
 *     summary: Create service for a facility (Staff)
 *     description: Create a new service for any clinic/hospital. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateServiceRequest'
 *           example:
 *             nameFr: "Urgences"
 *             nameAr: "الطوارئ"
 *             descriptionFr: "Service d'urgences 24/7"
 *             descriptionAr: "خدمة الطوارئ 24/7"
 *             sortOrder: 1
 *     responses:
 *       201:
 *         description: Service created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicServiceResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}/{id}:
 *   patch:
 *     summary: Update a facility's service (Staff)
 *     description: Update any clinic/hospital service. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateServiceRequest'
 *     responses:
 *       200:
 *         description: Service updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicServiceResponse'
 *
 *   delete:
 *     summary: Delete a facility's service (Staff)
 *     description: Permanently delete any clinic/hospital service. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     responses:
 *       200:
 *         description: Service deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Service deleted successfully"
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}/{id}/images:
 *   post:
 *     summary: Upload service image (Staff)
 *     description: |
 *       Upload an image for any clinic/hospital service. Admin only.
 *       Accepted formats: JPEG, PNG, WebP, SVG. Max 5MB.
 *       File will be stored with a secure UUID and accessible via /api/v1/files/public/{fileId}
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 5MB)
 *               captionFr:
 *                 type: string
 *                 maxLength: 200
 *                 description: French caption (optional)
 *               captionAr:
 *                 type: string
 *                 maxLength: 200
 *                 description: Arabic caption (optional)
 *     responses:
 *       201:
 *         description: Image uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ServiceImageResponse'
 *       400:
 *         description: Invalid file or missing image
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *       413:
 *         description: File too large (max 5MB)
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}/{id}/images/{imageId}:
 *   delete:
 *     summary: Delete service image (Staff)
 *     description: |
 *       Delete an image from any clinic/hospital service. Admin only.
 *       Also deletes the physical file from storage.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Image ID
 *     responses:
 *       200:
 *         description: Image deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Image deleted successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *       404:
 *         description: Image not found
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}/{id}/doctors:
 *   get:
 *     summary: Get assigned doctors (Staff)
 *     description: Get all doctors assigned to any clinic/hospital service. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     responses:
 *       200:
 *         description: Doctors retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ServiceDoctorResponse'
 *
 *   post:
 *     summary: Assign doctor to service (Staff)
 *     description: Assign a doctor to any clinic/hospital service. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AssignDoctorRequest'
 *     responses:
 *       201:
 *         description: Doctor assigned successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ServiceDoctorResponse'
 */

/**
 * @swagger
 * /api/v1/clinic-services/v1/clinic/{clinicId}/{id}/doctors/{doctorId}:
 *   delete:
 *     summary: Remove doctor from service (Staff)
 *     description: Remove a doctor assignment from any clinic/hospital service. Admin only.
 *     tags: [Clinic Services]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Clinic/Hospital ID
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Service ID
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Doctor removed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Doctor removed successfully"
 */