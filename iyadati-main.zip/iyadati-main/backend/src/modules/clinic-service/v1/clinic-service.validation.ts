import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createServiceSchema = Joi.object({
  nameFr: Joi.string().min(2).max(200).required().messages({
    'string.min': 'Name (FR) must be at least 2 characters',
    'string.max': 'Name (FR) must be less than 200 characters',
    'any.required': 'Name (FR) is required',
  }),
  nameAr: Joi.string().min(2).max(200).required().messages({
    'string.min': 'Name (AR) must be at least 2 characters',
    'string.max': 'Name (AR) must be less than 200 characters',
    'any.required': 'Name (AR) is required',
  }),
  descriptionFr: Joi.string().max(2000).optional().allow(null, ''),
  descriptionAr: Joi.string().max(2000).optional().allow(null, ''),
  sortOrder: Joi.number().integer().min(0).optional(),
});

const updateServiceSchema = Joi.object({
  nameFr: Joi.string().min(2).max(200).optional(),
  nameAr: Joi.string().min(2).max(200).optional(),
  descriptionFr: Joi.string().max(2000).optional().allow(null, ''),
  descriptionAr: Joi.string().max(2000).optional().allow(null, ''),
  sortOrder: Joi.number().integer().min(0).optional(),
  isActive: Joi.boolean().optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

const assignDoctorSchema = Joi.object({
  doctorId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid doctor ID is required',
    'any.required': 'Doctor ID is required',
  }),
  isPrimary: Joi.boolean().optional().default(false),
});

export const validateCreateService = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createServiceSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateService = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateServiceSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateAssignDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = assignDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

