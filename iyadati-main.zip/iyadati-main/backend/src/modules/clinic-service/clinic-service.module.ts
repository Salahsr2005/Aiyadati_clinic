import { Router } from 'express';
import clinicServiceRoutes from './v1/clinic-service.routes'

const router = Router();
router.use('/v1', clinicServiceRoutes);

export { router as clinicServiceModule };


