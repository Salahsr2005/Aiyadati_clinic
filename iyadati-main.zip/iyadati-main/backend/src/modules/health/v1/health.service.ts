import { prisma } from '../../../core/utils/prisma';
import { HealthCheckResponse, CreateHealthCheckDTO } from './health.types';
import { DatabaseError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';

export class HealthService {
  /**
   * Convert Prisma HealthCheck to HealthCheckResponse
   */
  private toResponse(check: { id: number; status: string; checkedAt: Date }): HealthCheckResponse {
    return {
      id: check.id,
      status: check.status,
      checkedAt: check.checkedAt.toISOString(),
    };
  }

  /**
   * Get database status
   */
  async getDatabaseStatus(): Promise<boolean> {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return true;
    } catch (error) {
      logger.error('Database health check failed', { error });
      return false;
    }
  }

  /**
   * Get the latest health check record
   */
  async getLatestCheck(): Promise<HealthCheckResponse | null> {
    try {
      const check = await prisma.healthCheck.findFirst({
        orderBy: { checkedAt: 'desc' },
      });
      return check ? this.toResponse(check) : null;
    } catch (error) {
      logger.error('Failed to fetch latest health check', { error });
      throw new DatabaseError('Failed to fetch health check data');
    }
  }

  /**
   * Create a health check record
   */
  async createCheck(data: CreateHealthCheckDTO): Promise<HealthCheckResponse> {
    try {
      const check = await prisma.healthCheck.create({
        data: {
          status: data.status,
        },
      });
      return this.toResponse(check);
    } catch (error) {
      logger.error('Failed to create health check', { error });
      throw new DatabaseError('Failed to create health check record');
    }
  }

  /**
   * Get all health checks with pagination
   */
  async getAllChecks(page = 1, limit = 10): Promise<{ checks: HealthCheckResponse[]; total: number }> {
    try {
      const skip = (page - 1) * limit;
      
      const [checks, total] = await Promise.all([
        prisma.healthCheck.findMany({
          skip,
          take: limit,
          orderBy: { checkedAt: 'desc' },
        }),
        prisma.healthCheck.count(),
      ]);

      return { 
        checks: checks.map(check => this.toResponse(check)), 
        total 
      };
    } catch (error) {
      logger.error('Failed to fetch health checks', { error });
      throw new DatabaseError('Failed to fetch health checks');
    }
  }

  /**
   * Delete old health checks (cleanup)
   */
  async cleanupOldChecks(daysToKeep = 7): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const result = await prisma.healthCheck.deleteMany({
        where: {
          checkedAt: {
            lt: cutoffDate,
          },
        },
      });

      return result.count;
    } catch (error) {
      logger.error('Failed to cleanup old health checks', { error });
      throw new DatabaseError('Failed to cleanup old health checks');
    }
  }
}

