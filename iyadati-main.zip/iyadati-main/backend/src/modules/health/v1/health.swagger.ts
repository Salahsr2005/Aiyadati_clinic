/**
 * @swagger
 * tags:
 *   name: Health
 *   description: System health monitoring and diagnostics
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     HealthStatus:
 *       type: object
 *       properties:
 *         status:
 *           type: string
 *           enum: [healthy, degraded]
 *           description: Current system health status
 *           example: healthy
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: Current server timestamp
 *           example: "2024-06-11T13:29:25.000Z"
 *         uptime:
 *           type: number
 *           description: Server uptime in seconds
 *           example: 12345.678
 *         database:
 *           type: string
 *           enum: [connected, disconnected]
 *           description: Database connection status
 *           example: connected
 *         lastCheck:
 *           $ref: '#/components/schemas/HealthCheckRecord'
 *     HealthCheckRecord:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           description: Health check record ID
 *           example: 1
 *         status:
 *           type: string
 *           description: Health check status message
 *           example: "All systems operational"
 *         checkedAt:
 *           type: string
 *           format: date-time
 *           description: When the check was performed
 *           example: "2024-06-11T13:29:25.000Z"
 *     CreateHealthCheck:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           minLength: 1
 *           maxLength: 50
 *           description: Status message for the health check
 *           example: "All systems operational"
 *     PaginatedHealthChecks:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Health checks retrieved"
 *         data:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/HealthCheckRecord'
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *               example: 1
 *             limit:
 *               type: integer
 *               example: 10
 *             total:
 *               type: integer
 *               example: 50
 *             totalPages:
 *               type: integer
 *               example: 5
 *             hasNextPage:
 *               type: boolean
 *               example: true
 *             hasPreviousPage:
 *               type: boolean
 *               example: false
 *             timestamp:
 *               type: string
 *               format: date-time
 *     CleanupResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Cleaned up health checks older than 7 days"
 *         data:
 *           type: object
 *           properties:
 *             deletedCount:
 *               type: integer
 *               description: Number of records deleted
 *               example: 15
 *             daysKept:
 *               type: integer
 *               description: Number of days kept
 *               example: 7
 *     ValidationError:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: "Validation failed"
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: "status"
 *               message:
 *                 type: string
 *                 example: "Status is required"
 */

/**
 * @swagger
 * /health:
 *   get:
 *     summary: Get full system health status
 *     description: Returns comprehensive health information including database connectivity, server uptime, and last health check
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: Health check completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Health check completed"
 *                 data:
 *                   $ref: '#/components/schemas/HealthStatus'
 *             examples:
 *               healthy:
 *                 summary: System is healthy
 *                 value:
 *                   success: true
 *                   message: "Health check completed"
 *                   data:
 *                     status: "healthy"
 *                     timestamp: "2024-06-11T13:29:25.000Z"
 *                     uptime: 12345.678
 *                     database: "connected"
 *                     lastCheck:
 *                       id: 1
 *                       status: "All systems operational"
 *                       checkedAt: "2024-06-11T13:25:00.000Z"
 *               degraded:
 *                 summary: Database disconnected
 *                 value:
 *                   success: true
 *                   message: "Health check completed"
 *                   data:
 *                     status: "degraded"
 *                     timestamp: "2024-06-11T13:29:25.000Z"
 *                     uptime: 12345.678
 *                     database: "disconnected"
 *                     lastCheck: null
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Failed to fetch health check data"
 *               error: "Failed to fetch health check data"
 */

/**
 * @swagger
 * /health/check:
 *   post:
 *     summary: Create a health check record
 *     description: Records a new health check status in the database
 *     tags: [Health]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateHealthCheck'
 *           examples:
 *             operational:
 *               summary: Systems operational
 *               value:
 *                 status: "All systems operational"
 *             maintenance:
 *               summary: Under maintenance
 *               value:
 *                 status: "Scheduled maintenance in progress"
 *     responses:
 *       201:
 *         description: Health check record created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Health check record created"
 *                 data:
 *                   $ref: '#/components/schemas/HealthCheckRecord'
 *             example:
 *               success: true
 *               message: "Health check record created"
 *               data:
 *                 id: 1
 *                 status: "All systems operational"
 *                 checkedAt: "2024-06-11T13:29:25.000Z"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *             examples:
 *               missingStatus:
 *                 summary: Missing status field
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "status"
 *                       message: "Status is required"
 *               emptyStatus:
 *                 summary: Empty status
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "status"
 *                       message: "Status cannot be empty"
 *               tooLong:
 *                 summary: Status too long
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "status"
 *                       message: "Status must be less than 50 characters"
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Failed to create health check record"
 *               error: "Failed to create health check record"
 */

/**
 * @swagger
 * /health/checks:
 *   get:
 *     summary: Get paginated health check history
 *     description: Retrieve a paginated list of all health check records, ordered by most recent first
 *     tags: [Health]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of records per page
 *         example: 10
 *     responses:
 *       200:
 *         description: Health checks retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedHealthChecks'
 *             example:
 *               success: true
 *               message: "Health checks retrieved"
 *               data:
 *                 - id: 3
 *                   status: "Database migration completed"
 *                   checkedAt: "2024-06-11T13:29:25.000Z"
 *                 - id: 2
 *                   status: "High traffic alert"
 *                   checkedAt: "2024-06-11T12:00:00.000Z"
 *                 - id: 1
 *                   status: "All systems operational"
 *                   checkedAt: "2024-06-11T10:00:00.000Z"
 *               meta:
 *                 page: 1
 *                 limit: 10
 *                 total: 3
 *                 totalPages: 1
 *                 hasNextPage: false
 *                 hasPreviousPage: false
 *                 timestamp: "2024-06-11T13:29:25.000Z"
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Failed to fetch health checks"
 *               error: "Failed to fetch health checks"
 */

/**
 * @swagger
 * /health/cleanup:
 *   delete:
 *     summary: Cleanup old health check records
 *     description: Deletes health check records older than the specified number of days
 *     tags: [Health]
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 365
 *           default: 7
 *         description: Delete records older than this many days
 *         example: 7
 *     responses:
 *       200:
 *         description: Cleanup completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CleanupResponse'
 *             example:
 *               success: true
 *               message: "Cleaned up health checks older than 7 days"
 *               data:
 *                 deletedCount: 15
 *                 daysKept: 7
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Failed to cleanup old health checks"
 *               error: "Failed to cleanup old health checks"
 */