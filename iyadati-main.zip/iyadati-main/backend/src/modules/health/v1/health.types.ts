export interface HealthCheckResponse {
  id: number;
  status: string;
  checkedAt: string;
}

export interface HealthStatus {
  status: string;
  timestamp: string;
  uptime: number;
  database: 'connected' | 'disconnected';
  lastCheck: HealthCheckResponse | null;
}

export interface CreateHealthCheckDTO {
  status: string;
}

