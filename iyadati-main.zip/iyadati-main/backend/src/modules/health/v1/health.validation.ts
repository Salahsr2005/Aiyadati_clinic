import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
import { ResponseUtil } from '../../../core/utils/response';

const createHealthCheckSchema = Joi.object({
  status: Joi.string()
    .trim()
    .min(1)
    .max(50)
    .required()
    .messages({
      'string.empty': 'Status cannot be empty',
      'string.max': 'Status must be less than 50 characters',
      'any.required': 'Status is required',
    }),
});

export const validateHealthCheck = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createHealthCheckSchema.validate(req.body, { abortEarly: false });
  
  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));
    
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  
  next();
};

