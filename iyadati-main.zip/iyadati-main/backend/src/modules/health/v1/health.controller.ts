import { Request, Response, NextFunction } from 'express';
import { HealthService } from './health.service';
import { ResponseUtil } from '../../../core/utils/response';

const healthService = new HealthService();

export class HealthController {
  /**
   * GET /health - Full health status
   */
  async getHealth(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const dbConnected = await healthService.getDatabaseStatus();
      const lastCheck = await healthService.getLatestCheck();

      ResponseUtil.success(res, {
        status: dbConnected ? 'healthy' : 'degraded',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        database: dbConnected ? 'connected' : 'disconnected',
        lastCheck,
      }, 'Health check completed');
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /health/check - Create health check record
   */
  async createCheck(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const check = await healthService.createCheck(req.body);
      ResponseUtil.created(res, check, 'Health check record created');
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /health/checks - Get paginated health check history
   */
  async getChecks(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const { checks, total } = await healthService.getAllChecks(page, limit);
      
      ResponseUtil.paginated(res, checks, total, page, limit, 'Health checks retrieved');
    } catch (error) {
      next(error);
    }
  }

  /**
   * DELETE /health/cleanup - Cleanup old records
   */
  async cleanupChecks(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const daysToKeep = parseInt(req.query.days as string) || 7;
      const deletedCount = await healthService.cleanupOldChecks(daysToKeep);
      
      ResponseUtil.success(res, {
        deletedCount,
        daysKept: daysToKeep,
      }, `Cleaned up health checks older than ${daysToKeep} days`);
    } catch (error) {
      next(error);
    }
  }
}

