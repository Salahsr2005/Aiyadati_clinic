import { Router } from 'express';
import { HealthController } from './health.controller';
import { validateHealthCheck } from './health.validation';

const router = Router();
const healthController = new HealthController();

router.get('/', healthController.getHealth.bind(healthController));
router.post('/check', validateHealthCheck, healthController.createCheck.bind(healthController));
router.get('/checks', healthController.getChecks.bind(healthController));
router.delete('/cleanup', healthController.cleanupChecks.bind(healthController));

export default router;

