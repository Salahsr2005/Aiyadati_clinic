import { Router } from 'express';
import healthRoutes from './v1/health.routes';

// Import swagger docs to register them
import './v1/health.swagger';

const router = Router();

router.use('/', healthRoutes);

export { router as healthModule };

