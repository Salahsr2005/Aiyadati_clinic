import { prisma } from '../../../core/utils/prisma';
import { slotRepository } from '../../../repositories/slot.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { specialtyRepository } from '../../../repositories/specialty.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { SlotSearchFilters, SlotSearchResponse, SlotSearchItem, AdvancedSearchFilters } from './slot-search.types';

export class SlotSearchService {
  
  async searchSlots(filters: SlotSearchFilters): Promise<SlotSearchResponse> {
    const {
      date,
      specialtyId,
      wilayaId,
      baladyaId,
      doctorName,
      clinicId,
      startTimeFrom,
      startTimeTo,
      minRating,
      practiceType,
      page = 1,
      limit = 20
    } = filters;

    // Cast page and limit to numbers
    const pageNum = Number(page) || 1;
    const limitNum = Number(limit) || 20;

    // Validate date is provided
    if (!date) {
      throw new BadRequestError('Date is required');
    }

    // Build where clause for slots
    const where: any = {
      status: 'available',
      date: new Date(date),
    };

    // Filter by time range
    if (startTimeFrom) {
      const [hours, minutes] = startTimeFrom.split(':');
      where.startTime = {
        gte: new Date(`1970-01-01T${hours}:${minutes}:00.000Z`)
      };
    }
    if (startTimeTo) {
      const [hours, minutes] = startTimeTo.split(':');
      where.startTime = {
        ...where.startTime,
        lte: new Date(`1970-01-01T${hours}:${minutes}:00.000Z`)
      };
    }

    // Filter by clinic
    if (clinicId) {
      where.clinicId = clinicId;
    }

    // Build doctor filters
    const doctorWhere: any = {
      isVerified: true,
      isSuspended: false,
    };

    // Filter by specialty
    if (specialtyId) {
      doctorWhere.specialties = {
        some: { specialtyId }
      };
    }

    // Filter by location
    if (wilayaId) {
      doctorWhere.wilayaId = wilayaId;
    }
    if (baladyaId) {
      doctorWhere.baladyaId = baladyaId;
    }

    // Filter by name (search in both French and Arabic)
    if (doctorName) {
      doctorWhere.OR = [
        { firstNameFr: { contains: doctorName, mode: 'insensitive' } },
        { lastNameFr: { contains: doctorName, mode: 'insensitive' } },
        { firstNameAr: { contains: doctorName, mode: 'insensitive' } },
        { lastNameAr: { contains: doctorName, mode: 'insensitive' } },
      ];
    }

    // Filter by rating
    if (minRating) {
      doctorWhere.avgRating = { gte: Number(minRating) };
    }

    // Filter by practice type
    if (practiceType && practiceType !== 'BOTH') {
      doctorWhere.practiceType = practiceType;
    }

    // Apply doctor filters to slot where
    where.doctor = doctorWhere;

    // Get total count for pagination
    const total = await prisma.slot.count({
      where,
    });

    // Get slots with pagination
    const slots = await prisma.slot.findMany({
      where,
      include: {
        doctor: {
          include: {
            specialties: {
              include: {
                specialty: true,
              },
            },
            wilaya: true,
            baladya: true,
          },
        },
        clinic: {
          include: {
            wilaya: true,
            baladya: true,
          },
        },
        room: true,
        appointments: {
          where: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      orderBy: [
        { date: 'asc' },
        { startTime: 'asc' },
      ],
      skip: (pageNum - 1) * limitNum,
      take: limitNum,
    });

    // Transform results
    const transformedSlots = slots.map(slot => this.transformSlot(slot));

    return {
      slots: transformedSlots,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
      filters,
    };
  }

  // Search by doctor ID
  async searchSlotsByDoctor(doctorId: string, date: string): Promise<SlotSearchItem[]> {
    if (!date) {
      throw new BadRequestError('Date is required');
    }

    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) {
      throw new NotFoundError('Doctor not found');
    }

    const slots = await slotRepository.findAvailableByDoctorAndDate(doctorId, date);
    
    const fullSlots = await prisma.slot.findMany({
      where: {
        id: { in: slots.map(s => s.id) },
      },
      include: {
        doctor: {
          include: {
            specialties: {
              include: {
                specialty: true,
              },
            },
            wilaya: true,
            baladya: true,
          },
        },
        clinic: {
          include: {
            wilaya: true,
            baladya: true,
          },
        },
        room: true,
        appointments: {
          where: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      orderBy: [
        { date: 'asc' },
        { startTime: 'asc' },
      ],
    });

    return fullSlots.map(slot => this.transformSlot(slot));
  }

  // Search by specialty
  async searchSlotsBySpecialty(specialtyId: string, date: string, wilayaId?: string): Promise<SlotSearchItem[]> {
    if (!date) {
      throw new BadRequestError('Date is required');
    }

    const specialty = await specialtyRepository.findById(specialtyId);
    if (!specialty) {
      throw new NotFoundError('Specialty not found');
    }

    const where: any = {
      status: 'available',
      date: new Date(date),
      doctor: {
        isVerified: true,
        isSuspended: false,
        specialties: {
          some: { specialtyId },
        },
      },
    };

    if (wilayaId) {
      where.doctor.wilayaId = wilayaId;
    }

    const slots = await prisma.slot.findMany({
      where,
      include: {
        doctor: {
          include: {
            specialties: {
              include: {
                specialty: true,
              },
            },
            wilaya: true,
            baladya: true,
          },
        },
        clinic: {
          include: {
            wilaya: true,
            baladya: true,
          },
        },
        room: true,
        appointments: {
          where: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      orderBy: [
        { date: 'asc' },
        { startTime: 'asc' },
      ],
    });

    return slots.map(slot => this.transformSlot(slot));
  }

  // Advanced search with sorting
  async advancedSearch(filters: AdvancedSearchFilters): Promise<SlotSearchResponse> {
    const {
      sortBy = 'time',
      sortOrder = 'asc',
      ...searchFilters
    } = filters;

    const results = await this.searchSlots(searchFilters);

    if (sortBy === 'rating') {
      results.slots.sort((a, b) => {
        const ratingA = a.doctor.avgRating || 0;
        const ratingB = b.doctor.avgRating || 0;
        return sortOrder === 'asc' ? ratingA - ratingB : ratingB - ratingA;
      });
    } else if (sortBy === 'popularity') {
      results.slots.sort((a, b) => {
        const popularityA = a.doctor.totalReviews || 0;
        const popularityB = b.doctor.totalReviews || 0;
        return sortOrder === 'asc' ? popularityA - popularityB : popularityB - popularityA;
      });
    }

    return results;
  }

  // Transform slot to search item - FIXED location
  private transformSlot(slot: any): SlotSearchItem {
    const bookedCount = slot.appointments?.length || 0;
    const availableSpots = slot.maxPatients - bookedCount;

    // Build doctor object
    const doctor: SlotSearchItem['doctor'] = {
      id: slot.doctor.id,
      firstNameFr: slot.doctor.firstNameFr,
      firstNameAr: slot.doctor.firstNameAr,
      lastNameFr: slot.doctor.lastNameFr,
      lastNameAr: slot.doctor.lastNameAr,
      email: slot.doctor.email,
      phone: slot.doctor.phone,
      avgRating: slot.doctor.avgRating,
      totalReviews: slot.doctor.totalReviews,
      photoPath: slot.doctor.photoPath,
      yearsOfExperience: slot.doctor.yearsOfExp,
      practiceType: slot.doctor.practiceType,
      isVerified: slot.doctor.isVerified,
      specialties: slot.doctor.specialties?.map((s: any) => ({
        id: s.specialty.id,
        nameFr: s.specialty.nameFr,
        nameAr: s.specialty.nameAr,
      })) || [],
    };

    // Add location only if doctor has wilaya
    if (slot.doctor.wilaya) {
      doctor.location = {
        wilaya: slot.doctor.wilaya.nameFr || '',
        wilayaAr: slot.doctor.wilaya.nameAr || '',
        baladya: slot.doctor.baladya?.nameFr || null,
        baladyaAr: slot.doctor.baladya?.nameAr || null,
        latitude: slot.doctor.latitude || null,
        longitude: slot.doctor.longitude || null,
      };
    }

    return {
      slot: {
        id: slot.id,
        date: slot.date.toISOString().slice(0, 10),
        startTime: slot.startTime.toISOString().slice(11, 16),
        endTime: slot.endTime.toISOString().slice(11, 16),
        maxPatients: slot.maxPatients,
        bookedCount,
        availableSpots,
        status: slot.status,
      },
      doctor,
      clinic: slot.clinic ? {
        id: slot.clinic.id,
        nameFr: slot.clinic.nameFr,
        nameAr: slot.clinic.nameAr,
        location: {
          wilaya: slot.clinic.wilaya?.nameFr || '',
          wilayaAr: slot.clinic.wilaya?.nameAr || '',
          baladya: slot.clinic.baladya?.nameFr || null,
          baladyaAr: slot.clinic.baladya?.nameAr || null,
          latitude: slot.clinic.latitude || null,
          longitude: slot.clinic.longitude || null,
        },
        phone: slot.clinic.phone,
        email: slot.clinic.email,
        avgRating: slot.clinic.avgRating,
        totalReviews: slot.clinic.totalReviews,
        facilityType: slot.clinic.facilityType,
      } : null,
      room: slot.room ? {
        id: slot.room.id,
        name: slot.room.name,
      } : null,
    };
  }

  // Get search statistics
  async getSearchStats(): Promise<{
    totalDoctors: number;
    totalClinics: number;
    totalSpecialties: number;
    totalSlotsToday: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [totalDoctors, totalClinics, totalSpecialties, totalSlotsToday] = await Promise.all([
      prisma.doctor.count({
        where: {
          isVerified: true,
          isSuspended: false,
        },
      }),
      prisma.clinic.count({
        where: {
          isVerified: true,
          isSuspended: false,
        },
      }),
      prisma.specialty.count({
        where: {
          isActive: true,
        },
      }),
      prisma.slot.count({
        where: {
          status: 'available',
          date: {
            gte: today,
            lt: tomorrow,
          },
        },
      }),
    ]);

    return {
      totalDoctors,
      totalClinics,
      totalSpecialties,
      totalSlotsToday,
    };
  }
}

export const slotSearchService = new SlotSearchService();

