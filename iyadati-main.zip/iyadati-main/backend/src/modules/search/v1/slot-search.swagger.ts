// slot-search.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Slot Search
 *   description: Search and discover available appointment slots with advanced filtering
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     SlotSearchFilters:
 *       type: object
 *       required:
 *         - date
 *       properties:
 *         date:
 *           type: string
 *           format: date
 *           example: "2026-07-24"
 *           description: Date to search for available slots (YYYY-MM-DD)
 *         specialtyId:
 *           type: string
 *           format: uuid
 *           description: Filter by medical specialty
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Filter by wilaya (state)
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           description: Filter by baladya (city)
 *         doctorName:
 *           type: string
 *           example: "Ahmed"
 *           description: Search doctors by name (partial match in French or Arabic)
 *         clinicId:
 *           type: string
 *           format: uuid
 *           description: Filter by specific clinic
 *         startTimeFrom:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *           example: "09:00"
 *           description: Filter slots starting from this time (HH:MM)
 *         startTimeTo:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *           example: "17:00"
 *           description: Filter slots starting until this time (HH:MM)
 *         minRating:
 *           type: number
 *           minimum: 1
 *           maximum: 5
 *           example: 4
 *           description: Minimum doctor rating (1-5)
 *         maxDistance:
 *           type: number
 *           minimum: 0
 *           maximum: 500
 *           example: 50
 *           description: Maximum distance in KM (if location is provided)
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *           description: Filter by doctor practice type
 *         page:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *           example: 1
 *         limit:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *           example: 20
 *     
 *     AdvancedSearchFilters:
 *       allOf:
 *         - $ref: '#/components/schemas/SlotSearchFilters'
 *         - type: object
 *           properties:
 *             sortBy:
 *               type: string
 *               enum: [time, rating, popularity]
 *               default: time
 *               description: Sort results by time, rating, or popularity
 *             sortOrder:
 *               type: string
 *               enum: [asc, desc]
 *               default: asc
 *               description: Sort order (ascending or descending)
 *     
 *     SlotSearchItem:
 *       type: object
 *       properties:
 *         slot:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             date:
 *               type: string
 *               format: date
 *             startTime:
 *               type: string
 *               example: "09:00"
 *             endTime:
 *               type: string
 *               example: "09:30"
 *             maxPatients:
 *               type: integer
 *               example: 3
 *               description: Maximum capacity for this slot
 *             bookedCount:
 *               type: integer
 *               example: 1
 *               description: Number of appointments currently booked
 *             availableSpots:
 *               type: integer
 *               example: 2
 *               description: Available spots remaining
 *             status:
 *               type: string
 *               enum: [available, full, cancelled]
 *         doctor:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             firstNameFr:
 *               type: string
 *             firstNameAr:
 *               type: string
 *             lastNameFr:
 *               type: string
 *             lastNameAr:
 *               type: string
 *             email:
 *               type: string
 *               format: email
 *             phone:
 *               type: string
 *             avgRating:
 *               type: number
 *               nullable: true
 *               minimum: 0
 *               maximum: 5
 *             totalReviews:
 *               type: integer
 *             photoPath:
 *               type: string
 *               nullable: true
 *             yearsOfExperience:
 *               type: integer
 *               nullable: true
 *             practiceType:
 *               type: string
 *               enum: [INDEPENDENT, CLINIC_BASED]
 *             isVerified:
 *               type: boolean
 *             specialties:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                     format: uuid
 *                   nameFr:
 *                     type: string
 *                   nameAr:
 *                     type: string
 *             location:
 *               type: object
 *               properties:
 *                 wilaya:
 *                   type: string
 *                 wilayaAr:
 *                   type: string
 *                 baladya:
 *                   type: string
 *                   nullable: true
 *                 baladyaAr:
 *                   type: string
 *                   nullable: true
 *                 latitude:
 *                   type: number
 *                   nullable: true
 *                 longitude:
 *                   type: number
 *                   nullable: true
 *         clinic:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             location:
 *               type: object
 *               properties:
 *                 wilaya:
 *                   type: string
 *                 wilayaAr:
 *                   type: string
 *                 baladya:
 *                   type: string
 *                   nullable: true
 *                 baladyaAr:
 *                   type: string
 *                   nullable: true
 *                 latitude:
 *                   type: number
 *                   nullable: true
 *                 longitude:
 *                   type: number
 *                   nullable: true
 *             phone:
 *               type: string
 *             email:
 *               type: string
 *               format: email
 *             avgRating:
 *               type: number
 *               nullable: true
 *             totalReviews:
 *               type: integer
 *             facilityType:
 *               type: string
 *               enum: [CLINIC, HOSPITAL]
 *         room:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             name:
 *               type: string
 *     
 *     SlotSearchResponse:
 *       type: object
 *       properties:
 *         slots:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/SlotSearchItem'
 *         pagination:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *             limit:
 *               type: integer
 *             total:
 *               type: integer
 *             totalPages:
 *               type: integer
 *         filters:
 *           $ref: '#/components/schemas/SlotSearchFilters'
 *         stats:
 *           type: object
 *           properties:
 *             totalDoctors:
 *               type: integer
 *             totalClinics:
 *               type: integer
 *             totalSpecialties:
 *               type: integer
 *     
 *     SearchStatsResponse:
 *       type: object
 *       properties:
 *         totalDoctors:
 *           type: integer
 *           description: Total number of verified doctors
 *         totalClinics:
 *           type: integer
 *           description: Total number of verified clinics
 *         totalSpecialties:
 *           type: integer
 *           description: Total number of active specialties
 *         totalSlotsToday:
 *           type: integer
 *           description: Total number of available slots today
 *     
 *     Error:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         error:
 *           type: object
 *           properties:
 *             code:
 *               type: integer
 *             message:
 *               type: string
 *             details:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   field:
 *                     type: string
 *                   message:
 *                     type: string
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/search:
 *   get:
 *     summary: Search available slots
 *     description: |
 *       Search for available appointment slots with various filters.
 *       
 *       **Features:**
 *       - Filter by date, specialty, location, time range
 *       - Search doctors by name
 *       - Filter by minimum rating
 *       - Paginated results
 *       - Returns slot availability (booked count, available spots)
 *       
 *       **Use Cases:**
 *       - Find a doctor by specialty in your area
 *       - Check availability for a specific date
 *       - Find highly-rated doctors
 *       - Search for specific clinic services
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-24"
 *         description: Search for slots on this date (YYYY-MM-DD)
 *       - in: query
 *         name: specialtyId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by medical specialty ID
 *         example: "123e4567-e89b-12d3-a456-426614174000"
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya (state) ID
 *         example: "223e4567-e89b-12d3-a456-426614174000"
 *       - in: query
 *         name: baladyaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by baladya (city) ID
 *       - in: query
 *         name: doctorName
 *         schema:
 *           type: string
 *         example: "Ahmed"
 *         description: Search doctors by name (matches first/last name in French or Arabic)
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specific clinic ID
 *       - in: query
 *         name: startTimeFrom
 *         schema:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *         example: "09:00"
 *         description: Only show slots starting from this time (HH:MM, 24-hour format)
 *       - in: query
 *         name: startTimeTo
 *         schema:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *         example: "17:00"
 *         description: Only show slots starting until this time (HH:MM, 24-hour format)
 *       - in: query
 *         name: minRating
 *         schema:
 *           type: number
 *           minimum: 1
 *           maximum: 5
 *         example: 4
 *         description: Minimum doctor rating (1-5 stars)
 *       - in: query
 *         name: practiceType
 *         schema:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *         example: "BOTH"
 *         description: Filter by doctor practice type
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Number of results per page
 *     responses:
 *       200:
 *         description: Search completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Slots found
 *                 data:
 *                   $ref: '#/components/schemas/SlotSearchResponse'
 *       400:
 *         description: Validation error or missing required parameters
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               MissingDate:
 *                 summary: Date is required
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Validation failed"
 *                     details:
 *                       - field: "date"
 *                         message: "Date is required"
 *               InvalidDate:
 *                 summary: Invalid date format
 *                 value:
 *                   success: false
 *                   error:
 *                     code: 400
 *                     message: "Validation failed"
 *                     details:
 *                       - field: "date"
 *                         message: "Invalid date format. Use YYYY-MM-DD"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *     examples:
 *       BasicSearch:
 *         summary: Find slots by date and specialty
 *         value:
 *           date: "2026-07-24"
 *           specialtyId: "123e4567-e89b-12d3-a456-426614174000"
 *           page: 1
 *           limit: 20
 *       AdvancedSearch:
 *         summary: Find slots in a city with high rating
 *         value:
 *           date: "2026-07-24"
 *           wilayaId: "223e4567-e89b-12d3-a456-426614174000"
 *           specialtyId: "123e4567-e89b-12d3-a456-426614174000"
 *           minRating: 4.5
 *           startTimeFrom: "09:00"
 *           startTimeTo: "16:00"
 *           page: 1
 *           limit: 20
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/advanced:
 *   get:
 *     summary: Advanced search with sorting
 *     description: |
 *       Extended search with sorting capabilities.
 *       
 *       **Additional Features:**
 *       - Sort by time, rating, or popularity
 *       - Ascending/descending order
 *       - All filters from basic search
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-24"
 *       - in: query
 *         name: specialtyId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: baladyaId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: doctorName
 *         schema:
 *           type: string
 *         example: "Ahmed"
 *       - in: query
 *         name: clinicId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: startTimeFrom
 *         schema:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *         example: "09:00"
 *       - in: query
 *         name: startTimeTo
 *         schema:
 *           type: string
 *           pattern: "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
 *         example: "17:00"
 *       - in: query
 *         name: minRating
 *         schema:
 *           type: number
 *           minimum: 1
 *           maximum: 5
 *         example: 4
 *       - in: query
 *         name: practiceType
 *         schema:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [time, rating, popularity]
 *           default: time
 *         description: Sort results by time (earliest first), rating (highest first), or popularity (most reviewed first)
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: Sort order
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *     responses:
 *       200:
 *         description: Advanced search completed
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Advanced search results
 *                 data:
 *                   $ref: '#/components/schemas/SlotSearchResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       500:
 *         description: Server error
 *     examples:
 *       SortByRating:
 *         summary: Find top-rated doctors in a specialty
 *         value:
 *           date: "2026-07-24"
 *           specialtyId: "123e4567-e89b-12d3-a456-426614174000"
 *           sortBy: "rating"
 *           sortOrder: "desc"
 *           minRating: 4
 *       SortByPopularity:
 *         summary: Find most popular doctors
 *         value:
 *           date: "2026-07-24"
 *           sortBy: "popularity"
 *           sortOrder: "desc"
 *           page: 1
 *           limit: 10
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/doctor/{doctorId}:
 *   get:
 *     summary: Get available slots for a specific doctor
 *     description: |
 *       Convenience endpoint to get all available slots for a specific doctor on a given date.
 *       
 *       **Use Case:** When you already know which doctor you want to book with.
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *         example: "123e4567-e89b-12d3-a456-426614174000"
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-24"
 *         description: Date to check availability (YYYY-MM-DD)
 *     responses:
 *       200:
 *         description: Doctor slots retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor slots found
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotSearchItem'
 *       400:
 *         description: Date is required or invalid
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               error:
 *                 code: 404
 *                 message: "Doctor not found"
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/specialty/{specialtyId}:
 *   get:
 *     summary: Get slots by specialty
 *     description: |
 *       Convenience endpoint to find all available slots for a specific specialty.
 *       Optionally filter by location (wilaya).
 *       
 *       **Use Case:** Find all doctors of a specific specialty in your area.
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: specialtyId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Specialty ID
 *         example: "123e4567-e89b-12d3-a456-426614174000"
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-24"
 *         description: Date to check availability (YYYY-MM-DD)
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya (state) ID
 *         example: "223e4567-e89b-12d3-a456-426614174000"
 *     responses:
 *       200:
 *         description: Specialty slots retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Specialty slots found
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SlotSearchItem'
 *       400:
 *         description: Date is required or invalid
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Specialty not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               error:
 *                 code: 404
 *                 message: "Specialty not found"
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       500:
 *         description: Server error
 *     examples:
 *       FindDermatologistsInAlgiers:
 *         summary: Find dermatologists in Algiers
 *         value:
 *           date: "2026-07-24"
 *           wilayaId: "223e4567-e89b-12d3-a456-426614174000"
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/stats:
 *   get:
 *     summary: Get search statistics
 *     description: |
 *       Get overview statistics for the search feature.
 *       
 *       **Returns:**
 *       - Total number of verified doctors
 *       - Total number of verified clinics
 *       - Total number of active specialties
 *       - Total available slots for today
 *       
 *       **Use Case:** Show on the search page to give users an overview.
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Search statistics
 *                 data:
 *                   $ref: '#/components/schemas/SearchStatsResponse'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       500:
 *         description: Server error
 *     example:
 *       response:
 *         success: true
 *         message: Search statistics
 *         data:
 *           totalDoctors: 450
 *           totalClinics: 120
 *           totalSpecialties: 35
 *           totalSlotsToday: 874
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     SuccessResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *         data:
 *           type: object
 *         timestamp:
 *           type: string
 *           format: date-time
 *         path:
 *           type: string
 *         method:
 *           type: string
 *         statusCode:
 *           type: integer
 */

/**
 * @swagger
 * /api/v1/search/v1/slots/available-count:
 *   get:
 *     summary: Get available slots count for a date range
 *     description: |
 *       Get the count of available slots for each day in a date range.
 *       
 *       **Use Case:** Show availability calendar on the search page.
 *       
 *       **Requires User role.**
 *     tags: [Slot Search]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: startDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-20"
 *         description: Start date (YYYY-MM-DD)
 *       - in: query
 *         name: endDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         example: "2026-07-27"
 *         description: End date (YYYY-MM-DD)
 *       - in: query
 *         name: specialtyId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by specialty
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya
 *     responses:
 *       200:
 *         description: Availability counts retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       date:
 *                         type: string
 *                         format: date
 *                       availableSlots:
 *                         type: integer
 *                       totalDoctors:
 *                         type: integer
 *       400:
 *         description: Validation error
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */