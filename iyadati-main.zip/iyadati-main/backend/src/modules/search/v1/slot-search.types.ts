// slot-search.types.ts

export interface SlotSearchFilters {
  date: string; // YYYY-MM-DD
  specialtyId?: string;
  wilayaId?: string;
  baladyaId?: string;
  doctorName?: string;
  clinicId?: string;
  startTimeFrom?: string; // HH:MM
  startTimeTo?: string; // HH:MM
  minRating?: number;
  maxDistance?: number;
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  page?: number;
  limit?: number;
}

export interface AdvancedSearchFilters extends SlotSearchFilters {
  sortBy?: 'time' | 'rating' | 'popularity';
  sortOrder?: 'asc' | 'desc';
}

export interface SlotSearchResponse {
  slots: SlotSearchItem[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  filters: Partial<SlotSearchFilters>;
  stats?: {
    totalDoctors: number;
    totalClinics: number;
    totalSpecialties: number;
  };
}

export interface SlotSearchItem {
  slot: {
    id: string;
    date: string;
    startTime: string;
    endTime: string;
    maxPatients: number;
    bookedCount: number;
    availableSpots: number;
    status: string;
  };
  
  doctor: {
    id: string;
    firstNameFr: string;
    firstNameAr: string;
    lastNameFr: string;
    lastNameAr: string;
    email: string;
    phone: string;
    avgRating: number | null;
    totalReviews: number;
    photoPath: string | null;
    yearsOfExperience: number | null;
    practiceType: string;
    isVerified: boolean;
    specialties: {
      id: string;
      nameFr: string;
      nameAr: string;
    }[];
    // Add location as optional since some doctors might not have it
    location?: {
      wilaya: string;
      wilayaAr: string;
      baladya: string | null;
      baladyaAr: string | null;
      latitude: number | null;
      longitude: number | null;
    };
  };
  
  clinic: {
    id: string;
    nameFr: string;
    nameAr: string;
    location: {
      wilaya: string;
      wilayaAr: string;
      baladya: string | null;
      baladyaAr: string | null;
      latitude: number | null;
      longitude: number | null;
    };
    phone: string;
    email: string;
    avgRating: number | null;
    totalReviews: number;
    facilityType: string;
  } | null;
  
  room: {
    id: string;
    name: string;
  } | null;
}

