import { Router } from 'express';
import { SlotSearchController } from './slot-search.controller';
import { 
  validateSlotSearch, 
  validateAdvancedSearch 
} from './slot-search.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new SlotSearchController();

// Main search endpoints
router.get(
  '/slots/search', 
  // authenticate, 
  // authorize('USER'), 
  validateSlotSearch, 
  controller.searchSlots
);

router.get(
  '/slots/advanced', 
  // authenticate, 
  // authorize('USER'), 
  validateAdvancedSearch, 
  controller.advancedSearch
);

// Convenience endpoints
router.get(
  '/slots/doctor/:doctorId', 
  // authenticate, 
  // authorize('USER'), 
  controller.searchSlotsByDoctor
);

router.get(
  '/slots/specialty/:specialtyId', 
  // authenticate, 
  // authorize('USER'), 
  controller.searchSlotsBySpecialty
);

// Stats
router.get(
  '/slots/stats', 
  // authenticate, 
  // authorize('USER'), 
  controller.getSearchStats
);

export default router;

