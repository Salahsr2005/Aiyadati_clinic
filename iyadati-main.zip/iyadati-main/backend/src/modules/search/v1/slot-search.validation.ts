import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const slotSearchSchema = Joi.object({
  date: Joi.date().iso().required().messages({
    'date.base': 'Invalid date format. Use YYYY-MM-DD',
    'any.required': 'Date is required',
  }),
  specialtyId: Joi.string().uuid().optional(),
  wilayaId: Joi.string().uuid().optional(),
  baladyaId: Joi.string().uuid().optional(),
  doctorName: Joi.string().min(2).max(100).optional(),
  clinicId: Joi.string().uuid().optional(),
  startTimeFrom: Joi.string().pattern(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).optional()
    .messages({
      'string.pattern.base': 'Invalid time format. Use HH:MM (24-hour)',
    }),
  startTimeTo: Joi.string().pattern(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).optional()
    .messages({
      'string.pattern.base': 'Invalid time format. Use HH:MM (24-hour)',
    }),
  minRating: Joi.number().min(1).max(5).optional(),
  maxDistance: Joi.number().min(0).max(500).optional(),
  practiceType: Joi.string().valid('INDEPENDENT', 'CLINIC_BASED', 'BOTH').optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(20),
});

const advancedSearchSchema = slotSearchSchema.keys({
  sortBy: Joi.string().valid('time', 'rating', 'popularity').default('time'),
  sortOrder: Joi.string().valid('asc', 'desc').default('asc'),
});

export const validateSlotSearch = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = slotSearchSchema.validate(req.query, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateAdvancedSearch = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = advancedSearchSchema.validate(req.query, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

