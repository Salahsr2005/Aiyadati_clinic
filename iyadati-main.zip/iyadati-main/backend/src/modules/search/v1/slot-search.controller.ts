import { Request, Response, NextFunction } from 'express';
import { slotSearchService } from './slot-search.service';
import { ResponseUtil } from '../../../core/utils/response';
import { SlotSearchFilters, AdvancedSearchFilters } from './slot-search.types';

export class SlotSearchController {
  
  searchSlots = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // Cast query params to SlotSearchFilters
      const filters = req.query as unknown as SlotSearchFilters;
      const result = await slotSearchService.searchSlots(filters);
      ResponseUtil.success(res, result, 'Slots found');
    } catch (error) {
      next(error);
    }
  };

  advancedSearch = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = req.query as unknown as AdvancedSearchFilters;
      const result = await slotSearchService.advancedSearch(filters);
      ResponseUtil.success(res, result, 'Advanced search results');
    } catch (error) {
      next(error);
    }
  };

  searchSlotsByDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const { date } = req.query;
      
      if (!date) {
        ResponseUtil.badRequest(res, 'Date query parameter is required');
        return;
      }
      
      const result = await slotSearchService.searchSlotsByDoctor(
        doctorId,
        date as string
      );
      ResponseUtil.success(res, result, 'Doctor slots found');
    } catch (error) {
      next(error);
    }
  };

  searchSlotsBySpecialty = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { specialtyId } = req.params;
      const { date, wilayaId } = req.query;
      
      if (!date) {
        ResponseUtil.badRequest(res, 'Date query parameter is required');
        return;
      }
      
      const result = await slotSearchService.searchSlotsBySpecialty(
        specialtyId,
        date as string,
        wilayaId as string | undefined
      );
      ResponseUtil.success(res, result, 'Specialty slots found');
    } catch (error) {
      next(error);
    }
  };

  getSearchStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const stats = await slotSearchService.getSearchStats();
      ResponseUtil.success(res, stats, 'Search statistics');
    } catch (error) {
      next(error);
    }
  };
}

