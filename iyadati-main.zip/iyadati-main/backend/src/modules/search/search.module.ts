import { Router } from 'express';
import slotSearchRoutes from './v1/slot-search.routes';
import './v1/slot-search.swagger';

const router = Router();
router.use('/v1', slotSearchRoutes);

export { router as searchModule };

