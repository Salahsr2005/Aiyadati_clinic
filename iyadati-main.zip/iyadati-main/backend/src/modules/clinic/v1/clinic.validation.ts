import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createClinicSchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Name (FR) must be at least 2 characters',
    'string.max': 'Name (FR) must be less than 100 characters',
    'any.required': 'Name (FR) is required',
  }),
  nameAr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Name (AR) must be at least 2 characters',
    'string.max': 'Name (AR) must be less than 100 characters',
    'any.required': 'Name (AR) is required',
  }),
  email: Joi.string().email().required().messages({
    'string.email': 'Valid email is required',
    'any.required': 'Email is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.pattern.base': 'Phone must be 10 digits',
    'any.required': 'Phone is required',
  }),
  password: Joi.string().min(8).required().messages({
    'string.min': 'Password must be at least 8 characters',
    'any.required': 'Password is required',
  }),
  wilayaId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid wilaya ID is required',
    'any.required': 'Wilaya is required',
  }),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  facilityType: Joi.string().valid('CLINIC', 'HOSPITAL').optional().default('CLINIC'),
  descriptionAr: Joi.string().max(1000).optional().allow(null, ''),
  descriptionFr: Joi.string().max(1000).optional().allow(null, ''),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
});

const updateClinicSchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).optional(),
  nameAr: Joi.string().min(2).max(100).optional(),
  descriptionAr: Joi.string().max(1000).optional().allow(null, ''),
  descriptionFr: Joi.string().max(1000).optional().allow(null, ''),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).optional(),
  email: Joi.string().email().optional(),
  wilayaId: Joi.string().uuid().optional(),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
  facilityType: Joi.string().valid('CLINIC', 'HOSPITAL').optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });


const suspendClinicSchema = Joi.object({
  reason: Joi.string().min(3).max(500).required().messages({
    'string.min': 'Reason must be at least 3 characters',
    'string.max': 'Reason must be less than 500 characters',
    'any.required': 'Suspension reason is required',
  }),
});

const completeClinicSchema = Joi.object({
  descriptionAr: Joi.string().max(1000).optional().allow(null, ''),
  descriptionFr: Joi.string().max(1000).optional().allow(null, ''),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
});

const registerClinicSchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required(),
  nameAr: Joi.string().min(2).max(100).required(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required(),
  email: Joi.string().email().required(),
  wilayaId: Joi.string().uuid().required(),
});


export const validateCreateClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateSuspendClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = suspendClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateCompleteClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = completeClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateRegisterClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = registerClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};



const workingHoursSchema = Joi.object({
  hours: Joi.array().items(
    Joi.object({
      dayOfWeek: Joi.string().valid('SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY').required(),
      openTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).required().messages({
        'string.pattern.base': 'openTime must be in HH:mm format',
      }),
      closeTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).required().messages({
        'string.pattern.base': 'closeTime must be in HH:mm format',
      }),
      isOpen: Joi.boolean().required(),
    })
  ).min(1).required().messages({
    'array.min': 'At least one day is required',
  }),
});

const createRoomSchema = Joi.object({
  name: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Room name must be at least 2 characters',
    'string.max': 'Room name must be less than 100 characters',
    'any.required': 'Room name is required',
  }),
  specialtyId: Joi.string().uuid().optional().allow(null),
});

const updateRoomSchema = Joi.object({
  name: Joi.string().min(2).max(100).optional(),
  specialtyId: Joi.string().uuid().optional().allow(null),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateWorkingHours = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = workingHoursSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateCreateRoom = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createRoomSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateRoom = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateRoomSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


const inviteDoctorSchema = Joi.object({
  doctorId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid doctor ID is required',
    'any.required': 'Doctor ID is required',
  }),
});

export const validateInviteDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = inviteDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


const updateGalleryImageSchema = Joi.object({
  captionFr: Joi.string().max(200).optional().allow(null, ''),
  captionAr: Joi.string().max(200).optional().allow(null, ''),
  sortOrder: Joi.number().integer().min(0).optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateUpdateGalleryImage = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateGalleryImageSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

