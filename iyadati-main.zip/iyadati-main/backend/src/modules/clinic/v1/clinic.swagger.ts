/**
 * @swagger
 * tags:
 *   name: Clinic
 *   description: Clinic & Hospital management endpoints (Staff and self-service)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     FacilityType:
 *       type: string
 *       enum: [CLINIC, HOSPITAL]
 *       default: HOSPITAL
 *       description: |
 *         Type of medical facility.
 *         **Default: HOSPITAL** when created by admin.
 *         Can be changed later via update endpoint.
 *
 *     ClinicResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         nameFr:
 *           type: string
 *           example: "Hôpital Central"
 *         nameAr:
 *           type: string
 *           example: "المستشفى المركزي"
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *           example: "أفضل مستشفى في الجزائر"
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *           example: "Meilleur hôpital d'Algérie"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *         wilaya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             code:
 *               type: integer
 *               example: 16
 *             name:
 *               type: string
 *               example: "Alger"
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         baladya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             name:
 *               type: string
 *               example: "Sidi M'Hamed"
 *         latitude:
 *           type: number
 *           nullable: true
 *           example: 36.7538
 *         longitude:
 *           type: number
 *           nullable: true
 *           example: 3.0588
 *         phone:
 *           type: string
 *           example: "0555123456"
 *         email:
 *           type: string
 *           example: "hopital@example.com"
 *         logoPath:
 *           type: string
 *           nullable: true
 *           description: Internal storage path (not exposed publicly)
 *         logoUrl:
 *           type: string
 *           nullable: true
 *           description: |
 *             Public URL for clinic/hospital logo.
 *             Generated from fileId (UUID) - secure, doesn't expose file path.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         facilityType:
 *           $ref: '#/components/schemas/FacilityType'
 *           description: Type of medical facility
 *         isVerified:
 *           type: boolean
 *           description: Whether the facility has been verified by admin
 *         isSuspended:
 *           type: boolean
 *           description: Whether the facility is currently suspended
 *         isCompleted:
 *           type: boolean
 *           description: Whether the facility profile is complete
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *
 *     CreateClinicRequest:
 *       type: object
 *       required:
 *         - nameFr
 *         - nameAr
 *         - email
 *         - phone
 *         - password
 *         - wilayaId
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "Hôpital Central"
 *           description: Facility name in French
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "المستشفى المركزي"
 *           description: Facility name in Arabic
 *         email:
 *           type: string
 *           format: email
 *           example: "hopital@example.com"
 *           description: Unique email address for login
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           example: "0555123456"
 *           description: 10-digit Algerian phone number (unique)
 *         password:
 *           type: string
 *           minLength: 8
 *           format: password
 *           example: "SecurePass123"
 *           description: Minimum 8 characters, hashed with bcrypt before storage
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           description: Wilaya ID where the facility is located
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Baladya ID (optional, can be set later)
 *         facilityType:
 *           $ref: '#/components/schemas/FacilityType'
 *           description: |
 *             Type of medical facility.
 *             **Defaults to HOSPITAL** when not provided.
 *         descriptionAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           description: Arabic description (optional)
 *         descriptionFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           description: French description (optional)
 *         latitude:
 *           type: number
 *           minimum: -90
 *           maximum: 90
 *           nullable: true
 *           example: 36.7538
 *           description: GPS latitude coordinate
 *         longitude:
 *           type: number
 *           minimum: -180
 *           maximum: 180
 *           nullable: true
 *           example: 3.0588
 *           description: GPS longitude coordinate
 *
 *     UpdateClinicRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         nameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         nameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         descriptionAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         descriptionFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *         email:
 *           type: string
 *           format: email
 *         wilayaId:
 *           type: string
 *           format: uuid
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         facilityType:
 *           $ref: '#/components/schemas/FacilityType'
 *           description: Change facility type (CLINIC or HOSPITAL)
 *         latitude:
 *           type: number
 *           minimum: -90
 *           maximum: 90
 *           nullable: true
 *         longitude:
 *           type: number
 *           minimum: -180
 *           maximum: 180
 *           nullable: true
 *
 *     SuspendClinicRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500
 *           example: "Violation of terms of service - unverified documents"
 *
 *     CompleteClinicRequest:
 *       type: object
 *       properties:
 *         descriptionAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         descriptionFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         latitude:
 *           type: number
 *           nullable: true
 *         longitude:
 *           type: number
 *           nullable: true
 *
 *     ClinicDocumentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Document record ID
 *         clinicId:
 *           type: string
 *           format: uuid
 *           description: Owning facility ID
 *         fileName:
 *           type: string
 *           description: Original filename as uploaded
 *           example: "license.pdf"
 *         fileType:
 *           type: string
 *           description: MIME type of the document
 *           example: "application/pdf"
 *         fileSize:
 *           type: integer
 *           description: File size in bytes
 *           example: 245760
 *         accessUrl:
 *           type: string
 *           description: |
 *             **Signed URL for secure document access (expires in 30 minutes).**
 *             Uses fileId (UUID) instead of exposing the physical file path.
 *             All documents are stored in private storage with signed URL access.
 *             Format: /api/v1/files/private/{fileId}?expires={timestamp}&signature={hash}
 *           example: "http://localhost:3975/api/v1/files/private/550e8400-e29b-41d4-a716-446655440000?expires=1784569353394&signature=44da603063166cc17ad803c8c7b575ae1b273df0fe4532fafc8bc38bdc4c6a56"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Upload timestamp
 *
 *     WorkingHoursDay:
 *       type: object
 *       required:
 *         - dayOfWeek
 *         - openTime
 *         - closeTime
 *         - isOpen
 *       properties:
 *         dayOfWeek:
 *           type: string
 *           enum: [SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY]
 *           description: Day of the week
 *         openTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           example: "08:00"
 *           description: Opening time in HH:mm format (24h)
 *         closeTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           example: "17:00"
 *           description: Closing time in HH:mm format (24h)
 *         isOpen:
 *           type: boolean
 *           description: Whether the facility is open on this day
 *
 *     WorkingHoursRequest:
 *       type: object
 *       required:
 *         - hours
 *       properties:
 *         hours:
 *           type: array
 *           minItems: 1
 *           description: Array of working hours per day (upsert operation)
 *           items:
 *             $ref: '#/components/schemas/WorkingHoursDay'
 *
 *     WorkingHoursResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         clinicId:
 *           type: string
 *           format: uuid
 *         dayOfWeek:
 *           type: string
 *           enum: [SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY]
 *         openTime:
 *           type: string
 *           example: "08:00"
 *         closeTime:
 *           type: string
 *           example: "17:00"
 *         isOpen:
 *           type: boolean
 *
 *     CreateRoomRequest:
 *       type: object
 *       required:
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "Consultation Room 1"
 *           description: Room name/label
 *         specialtyId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Optional specialty associated with this room
 *
 *     UpdateRoomRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *         specialtyId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *
 *     RoomResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         clinicId:
 *           type: string
 *           format: uuid
 *         name:
 *           type: string
 *         specialtyId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         isActive:
 *           type: boolean
 *           description: Soft delete flag (false = deleted)
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *
 *     InviteDoctorRequest:
 *       type: object
 *       required:
 *         - doctorId
 *       properties:
 *         doctorId:
 *           type: string
 *           format: uuid
 *           description: Doctor ID to invite to the facility
 *
 *     ClinicDoctorResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Clinic-Doctor link ID
 *         clinicId:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         status:
 *           type: string
 *           enum: [PENDING, ACCEPTED, REJECTED]
 *           description: Current invitation/request status
 *         invitedBy:
 *           type: string
 *           enum: [clinic, doctor]
 *           description: Who initiated the relationship
 *         isActive:
 *           type: boolean
 *           description: Whether the doctor is currently active in the facility
 *         joinedAt:
 *           type: string
 *           format: date-time
 *         doctor:
 *           type: object
 *           nullable: true
 *           description: Doctor details (included when available)
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             email:
 *               type: string
 *             firstNameFr:
 *               type: string
 *             firstNameAr:
 *               type: string
 *             lastNameFr:
 *               type: string
 *             lastNameAr:
 *               type: string
 *             phone:
 *               type: string
 *             photoUrl:
 *               type: string
 *               nullable: true
 *               description: Public URL for doctor's photo (fileId-based)
 *             specialties:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                     format: uuid
 *                   nameFr:
 *                     type: string
 *                   nameAr:
 *                     type: string
 *             yearsOfExp:
 *               type: integer
 *               nullable: true
 *         clinic:
 *           type: object
 *           nullable: true
 *           description: Clinic details (included when viewing from doctor side)
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             email:
 *               type: string
 *             phone:
 *               type: string
 *             logoUrl:
 *               type: string
 *               nullable: true
 *
 *     GalleryImageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Gallery image record ID
 *         clinicId:
 *           type: string
 *           format: uuid
 *         imagePath:
 *           type: string
 *           description: Internal storage path (not exposed publicly)
 *         imageUrl:
 *           type: string
 *           description: |
 *             **Public URL for the gallery image.**
 *             Uses fileId (UUID) instead of exposing the physical file path.
 *             Gallery images are stored in public storage for direct access.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         captionFr:
 *           type: string
 *           nullable: true
 *           description: French caption
 *         captionAr:
 *           type: string
 *           nullable: true
 *           description: Arabic caption
 *         sortOrder:
 *           type: integer
 *           description: Display order (auto-incremented on upload)
 *         isActive:
 *           type: boolean
 *           description: Soft delete flag (false = deleted)
 *         createdAt:
 *           type: string
 *           format: date-time
 *
 *     UpdateGalleryImageRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         captionFr:
 *           type: string
 *           maxLength: 200
 *           nullable: true
 *         captionAr:
 *           type: string
 *           maxLength: 200
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *           description: New display position
 */

// ======================================================================
//  STAFF ENDPOINTS (SUPER_ADMIN + ADMIN)
// ======================================================================

/**
 * @swagger
 * /api/v1/clinic/v1:
 *   get:
 *     summary: Get all clinics/hospitals (Staff)
 *     description: |
 *       Retrieve paginated list of all clinics and hospitals with filtering options.
 *       Supports filtering by facilityType, wilaya, verification status, and more.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by name (Fr/Ar), email, or phone number
 *         example: "Central"
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya
 *       - in: query
 *         name: baladyaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by baladya
 *       - in: query
 *         name: facilityType
 *         schema:
 *           $ref: '#/components/schemas/FacilityType'
 *         description: Filter by facility type (CLINIC or HOSPITAL)
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *         description: Filter by verification status (true/false)
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *         description: Filter by suspension status (true/false)
 *       - in: query
 *         name: isCompleted
 *         schema:
 *           type: boolean
 *         description: Filter by profile completion status (true/false)
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, nameFr, nameAr, email, facilityType]
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *     responses:
 *       200:
 *         description: Facilities retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     total:
 *                       type: integer
 *                       example: 50
 *                     page:
 *                       type: integer
 *                       example: 1
 *                     limit:
 *                       type: integer
 *                       example: 10
 *                 message:
 *                   type: string
 *                   example: "Clinics retrieved successfully"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *
 *   post:
 *     summary: Create new clinic/hospital (Staff)
 *     description: |
 *       Create a new clinic or hospital. The facility is **automatically verified** when created by an admin.
 *       **Default facilityType: HOSPITAL** (can be overridden to CLINIC).
 *       Password is hashed with bcrypt (12 rounds) before storage.
 *       
 *       **Events triggered:**
 *       - `audit` - Logs creation action
 *       - `notification` - Sends welcome notification to the facility
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateClinicRequest'
 *           examples:
 *             createHospital:
 *               summary: Create a Hospital
 *               value:
 *                 nameFr: "Hôpital Central"
 *                 nameAr: "المستشفى المركزي"
 *                 email: "hopital@example.com"
 *                 phone: "0555123456"
 *                 password: "SecurePass123"
 *                 wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *                 facilityType: "HOSPITAL"
 *                 descriptionFr: "Meilleur hôpital d'Algérie"
 *                 descriptionAr: "أفضل مستشفى في الجزائر"
 *                 latitude: 36.7538
 *                 longitude: 3.0588
 *             createClinic:
 *               summary: Create a Clinic
 *               value:
 *                 nameFr: "Clinique El Wouroud"
 *                 nameAr: "عيادة الورود"
 *                 email: "clinique@example.com"
 *                 phone: "0666123456"
 *                 password: "SecurePass123"
 *                 wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *                 baladyaId: "660e8400-e29b-41d4-a716-446655440001"
 *                 facilityType: "CLINIC"
 *                 latitude: 36.7538
 *                 longitude: 3.0588
 *             minimalHospital:
 *               summary: Minimal Hospital (defaults)
 *               value:
 *                 nameFr: "Hôpital Est"
 *                 nameAr: "مستشفى الشرق"
 *                 email: "est@example.com"
 *                 phone: "0777123456"
 *                 password: "SecurePass123"
 *                 wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Facility created successfully (auto-verified)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic created successfully"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Validation failed"
 *                 errors:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       field:
 *                         type: string
 *                       message:
 *                         type: string
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *       409:
 *         description: Conflict - Email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Email already in use"
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}:
 *   get:
 *     summary: Get facility by ID (Staff)
 *     description: |
 *       Retrieve a single facility by its ID.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Facility retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *       404:
 *         description: Facility not found
 *
 *   patch:
 *     summary: Update facility (Staff)
 *     description: |
 *       Update facility details. At least one field is required.
 *       Can change facilityType from CLINIC to HOSPITAL or vice versa.
 *       Phone and email uniqueness is validated (excluding current facility).
 *       
 *       **Events triggered:**
 *       - `audit` - Logs update action with changes
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateClinicRequest'
 *           examples:
 *             changeType:
 *               summary: Change facility type
 *               value:
 *                 facilityType: "CLINIC"
 *             updateInfo:
 *               summary: Update basic info and location
 *               value:
 *                 nameFr: "Hôpital Central Updated"
 *                 nameAr: "المستشفى المركزي المحدث"
 *                 latitude: 36.7538
 *                 longitude: 3.0588
 *             updateWithBaladya:
 *               summary: Update with baladya
 *               value:
 *                 baladyaId: "660e8400-e29b-41d4-a716-446655440001"
 *             removeBaladya:
 *               summary: Remove baladya assignment
 *               value:
 *                 baladyaId: null
 *     responses:
 *       200:
 *         description: Facility updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic updated successfully"
 *       400:
 *         description: Validation error (at least one field required)
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 *       409:
 *         description: Email or phone conflict
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/verify:
 *   post:
 *     summary: Verify facility (Staff)
 *     description: |
 *       Manually verify a facility. Fails if already verified.
 *       
 *       **Events triggered:**
 *       - `audit` - Logs verification action
 *       - `notification` - Sends verification confirmation to facility
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Facility verified successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic verified successfully"
 *       400:
 *         description: Already verified
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Clinic is already verified"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/suspend:
 *   post:
 *     summary: Suspend facility (Staff)
 *     description: |
 *       Suspend a facility with a reason. Fails if already suspended.
 *       
 *       **Events triggered:**
 *       - `audit` - Logs suspension action with reason
 *       - `notification` - Sends suspension notice to facility
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SuspendClinicRequest'
 *     responses:
 *       200:
 *         description: Facility suspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic suspended successfully"
 *       400:
 *         description: Already suspended or validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/unsuspend:
 *   post:
 *     summary: Unsuspend facility (Staff)
 *     description: |
 *       Reinstate a suspended facility. Fails if not currently suspended.
 *       
 *       **Events triggered:**
 *       - `audit` - Logs unsuspension action
 *       - `notification` - Sends reinstatement notice to facility
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Facility unsuspended
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic unsuspended successfully"
 *       400:
 *         description: Facility is not suspended
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/logo:
 *   post:
 *     summary: Upload facility logo (Staff)
 *     description: |
 *       Upload a logo for the facility. Accepted: JPEG, PNG, WebP, SVG. Max 2MB.
 *       File is stored with a UUID filename and accessed via `/api/v1/files/public/{fileId}`.
 *       The logo URL in the response uses the fileId, not the physical path.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - logo
 *             properties:
 *               logo:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 2MB)
 *     responses:
 *       200:
 *         description: Logo uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Logo uploaded successfully"
 *       400:
 *         description: No file provided or invalid file type
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 *       413:
 *         description: File too large (max 2MB)
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/documents:
 *   get:
 *     summary: Get facility documents (Staff)
 *     description: |
 *       Returns all documents with **signed access URLs** for a specific facility.
 *       Each document URL uses a secure UUID (fileId) instead of the file path.
 *       URLs expire after 30 minutes and must be regenerated.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicDocumentResponse'
 *                 message:
 *                   type: string
 *                   example: "Documents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 *   post:
 *     summary: Upload facility document (Staff)
 *     description: |
 *       Uploads a document for the facility. Accepted: PDF, JPEG, PNG. Max 20MB.
 *       
 *       **Storage details:**
 *       - Files stored in **private** storage with UUID filenames
 *       - Access granted via **signed URLs** (expire in 30 minutes)
 *       - Document metadata stored: original filename, MIME type, file size, storage path
 *       - Category set to "document", docType to "other"
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - document
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *     responses:
 *       201:
 *         description: Document uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDocumentResponse'
 *                 message:
 *                   type: string
 *                   example: "Document uploaded successfully"
 *       400:
 *         description: Invalid file or missing document
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 *       413:
 *         description: File too large (max 20MB)
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/documents/{documentId}:
 *   delete:
 *     summary: Delete facility document (Staff)
 *     description: |
 *       Deletes a specific document belonging to a facility.
 *       Validates that the document belongs to the specified facility.
 *       Also deletes the physical file from storage.
 *       
 *       **Events triggered:**
 *       - `audit` - Logs deletion action with document details
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *       - in: path
 *         name: documentId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to delete
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Document deleted successfully"
 *       400:
 *         description: Document does not belong to this facility
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility or document not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/working-hours:
 *   get:
 *     summary: Get facility working hours (Staff)
 *     description: |
 *       Returns all working hours for a facility. Times are in HH:mm format (24h).
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Working hours retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/WorkingHoursResponse'
 *                 message:
 *                   type: string
 *                   example: "Working hours retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *   post:
 *     summary: Set facility working hours (Staff)
 *     description: |
 *       **Upserts** working hours for the facility. Replaces all existing entries.
 *       Requires at least one day. Each entry must have valid HH:mm format (24h).
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WorkingHoursRequest'
 *           example:
 *             hours:
 *               - dayOfWeek: "SUNDAY"
 *                 openTime: "08:00"
 *                 closeTime: "17:00"
 *                 isOpen: true
 *               - dayOfWeek: "MONDAY"
 *                 openTime: "08:00"
 *                 closeTime: "17:00"
 *                 isOpen: true
 *               - dayOfWeek: "FRIDAY"
 *                 openTime: "08:00"
 *                 closeTime: "12:00"
 *                 isOpen: true
 *               - dayOfWeek: "SATURDAY"
 *                 openTime: "00:00"
 *                 closeTime: "00:00"
 *                 isOpen: false
 *     responses:
 *       200:
 *         description: Working hours updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/WorkingHoursResponse'
 *                 message:
 *                   type: string
 *                   example: "Working hours updated successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/rooms:
 *   get:
 *     summary: Get facility rooms (Staff)
 *     description: |
 *       Returns all rooms for a facility (including soft-deleted ones from DB,
 *       though typically only active rooms are returned).
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Rooms retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/RoomResponse'
 *                 message:
 *                   type: string
 *                   example: "Rooms retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *   post:
 *     summary: Create room for facility (Staff)
 *     description: |
 *       Create a new room/consultation room for a facility.
 *       Optionally assign a specialty to the room.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true          
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateRoomRequest'
 *           examples:
 *             basicRoom:
 *               summary: Basic room
 *               value:
 *                 name: "Consultation Room 1"
 *             roomWithSpecialty:
 *               summary: Room with specialty
 *               value:
 *                 name: "Cardiology Room"
 *                 specialtyId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Room created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/RoomResponse'
 *                 message:
 *                   type: string
 *                   example: "Room created successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/rooms/{roomId}:
 *   patch:
 *     summary: Update room (Staff)
 *     description: |
 *       Update a room's name or specialty assignment. At least one field required.
 *       Set specialtyId to null to remove specialty assignment.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *       - in: path
 *         name: roomId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Room ID to update
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateRoomRequest'
 *           examples:
 *             rename:
 *               summary: Rename room
 *               value:
 *                 name: "Consultation Room A"
 *             changeSpecialty:
 *               summary: Change specialty
 *               value:
 *                 specialtyId: "660e8400-e29b-41d4-a716-446655440001"
 *             removeSpecialty:
 *               summary: Remove specialty
 *               value:
 *                 specialtyId: null
 *     responses:
 *       200:
 *         description: Room updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/RoomResponse'
 *                 message:
 *                   type: string
 *                   example: "Room updated successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Room not found
 *   delete:
 *     summary: Soft delete room (Staff)
 *     description: |
 *       Soft deletes a room (sets isActive to false).
 *       The room record is preserved but marked as inactive.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *       - in: path
 *         name: roomId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Room ID to delete
 *     responses:
 *       200:
 *         description: Room deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Room deleted successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Room not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/doctors:
 *   get:
 *     summary: Get facility doctors (Staff)
 *     description: |
 *       Returns all doctor relationships for a facility with full doctor profiles.
 *       Includes specialties, experience, and photo URLs.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Doctors retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic doctors retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/gallery:
 *   get:
 *     summary: Get facility gallery (Staff)
 *     description: |
 *       Returns all gallery images for a facility with public URLs.
 *       Each image URL uses a UUID (fileId) instead of the file path.
 *       Images are served from public storage for direct access.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     responses:
 *       200:
 *         description: Gallery retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/GalleryImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Gallery retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *   post:
 *     summary: Upload gallery image (Staff)
 *     description: |
 *       Upload a gallery image for the facility. Accepted: JPEG, PNG, WebP, SVG. Max 5MB.
 *       Use multipart/form-data field `image`.
 *       
 *       **Storage details:**
 *       - Files stored in **public** storage with UUID filenames
 *       - Access via public URL: `/api/v1/files/public/{fileId}`
 *       - Captions support French and Arabic
 *       - Sort order auto-incremented (max + 1)
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 5MB)
 *               captionFr:
 *                 type: string
 *                 maxLength: 200
 *                 description: French caption
 *               captionAr:
 *                 type: string
 *                 maxLength: 200
 *                 description: Arabic caption
 *     responses:
 *       201:
 *         description: Image uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GalleryImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Gallery image uploaded"
 *       400:
 *         description: Invalid file or missing image
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Facility not found
 *       413:
 *         description: File too large (max 5MB)
 */

/**
 * @swagger
 * /api/v1/clinic/v1/{id}/gallery/{imageId}:
 *   patch:
 *     summary: Update gallery image metadata (Staff)
 *     description: |
 *       Update caption or sort order of a gallery image. At least one field required.
 *       Cannot change the image file itself (upload new and delete old if needed).
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Gallery image ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateGalleryImageRequest'
 *           examples:
 *             updateCaptions:
 *               summary: Update captions
 *               value:
 *                 captionFr: "Salle d'attente moderne"
 *                 captionAr: "غرفة انتظار حديثة"
 *             updateOrder:
 *               summary: Change display order
 *               value:
 *                 sortOrder: 1
 *     responses:
 *       200:
 *         description: Gallery image updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GalleryImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Gallery image updated"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Gallery image not found
 *   delete:
 *     summary: Soft delete gallery image (Staff)
 *     description: |
 *       Soft deletes a gallery image (sets isActive to false).
 *       The image record is preserved but hidden from gallery.
 *       
 *       **Access:** SUPER_ADMIN, ADMIN only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Facility ID
 *       - in: path
 *         name: imageId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Gallery image ID to delete
 *     responses:
 *       200:
 *         description: Gallery image deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Gallery image deleted"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: Gallery image not found
 */

// ======================================================================
//  CLINIC SELF-SERVICE ENDPOINTS (CLINIC JWT)
// ======================================================================

/**
 * @swagger
 * /api/v1/clinic/v1/me/profile:
 *   get:
 *     summary: Get my facility profile (Self)
 *     description: |
 *       Returns the authenticated facility's profile.
 *       Facility ID is extracted from JWT token.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profile retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic profile retrieved successfully"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       403:
 *         description: Forbidden - Requires CLINIC role
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/complete:
 *   patch:
 *     summary: Complete my facility profile (Self)
 *     description: |
 *       Complete the facility profile. Must be verified first. Only works once (isCompleted flag).
 *       Can upload a logo via multipart/form-data field `logo`.
 *       
 *       **Requirements:**
 *       - Facility must be verified
 *       - Facility must not already be completed
 *       
 *       **Storage details:**
 *       - Logo stored in public storage with UUID filename
 *       - Access via `/api/v1/files/public/{fileId}`
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               descriptionAr:
 *                 type: string
 *                 maxLength: 1000
 *                 description: Arabic description
 *               descriptionFr:
 *                 type: string
 *                 maxLength: 1000
 *                 description: French description
 *               baladyaId:
 *                 type: string
 *                 format: uuid
 *                 description: Baladya ID
 *               latitude:
 *                 type: number
 *                 minimum: -90
 *                 maximum: 90
 *                 description: GPS latitude
 *               longitude:
 *                 type: number
 *                 minimum: -180
 *                 maximum: 180
 *                 description: GPS longitude
 *               logo:
 *                 type: string
 *                 format: binary
 *                 description: Logo image (JPEG, PNG, WebP, SVG - max 2MB)
 *     responses:
 *       200:
 *         description: Profile completed
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicResponse'
 *                 message:
 *                   type: string
 *                   example: "Profile completed successfully"
 *       400:
 *         description: Not verified or already completed
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Clinic must be verified before completing profile"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       413:
 *         description: File too large (max 2MB)
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/documents:
 *   get:
 *     summary: Get my facility documents (Self)
 *     description: |
 *       Returns all documents with **signed access URLs** for the authenticated facility.
 *       Each document URL uses a secure UUID (fileId) instead of the file path.
 *       URLs expire after 30 minutes and must be regenerated.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Documents retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicDocumentResponse'
 *                 message:
 *                   type: string
 *                   example: "Documents retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *   post:
 *     summary: Upload my facility document (Self)
 *     description: |
 *       Uploads a document for the authenticated facility. Accepted: PDF, JPEG, PNG. Max 20MB.
 *       Uses multipart/form-data field `document`.
 *       
 *       **Storage details:**
 *       - Files stored in **private** storage with UUID filenames
 *       - Access granted via **signed URLs** (expire in 30 minutes)
 *       - Document metadata stored: original filename, MIME type, file size, storage path
 *       - Category set to "document", docType to "other"
 *       - Uploader tracked via JWT
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - document
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *     responses:
 *       201:
 *         description: Document uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDocumentResponse'
 *                 message:
 *                   type: string
 *                   example: "Document uploaded successfully"
 *       400:
 *         description: Invalid file or missing document
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       413:
 *         description: File too large (max 20MB)
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/documents/{id}:
 *   delete:
 *     summary: Delete my facility document (Self)
 *     description: |
 *       Delete a document belonging to the authenticated facility.
 *       Only documents owned by the authenticated clinic can be deleted.
 *       Validates document ownership before deletion.
 *       Also deletes the physical file from storage.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to delete
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Document deleted successfully"
 *       400:
 *         description: Document does not belong to this facility
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Document does not belong to this clinic"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       404:
 *         description: Document not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Document not found"
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/working-hours:
 *   get:
 *     summary: Get my facility working hours (Self)
 *     description: |
 *       Returns all working hours for the authenticated facility.
 *       Times are in HH:mm format (24h).
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Working hours retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/WorkingHoursResponse'
 *                 message:
 *                   type: string
 *                   example: "Working hours retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *   post:
 *     summary: Set my facility working hours (Self)
 *     description: |
 *       **Upserts** working hours for the authenticated facility. Replaces all existing entries.
 *       Requires at least one day. Each entry must have valid HH:mm format (24h).
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WorkingHoursRequest'
 *           example:
 *             hours:
 *               - dayOfWeek: "SUNDAY"
 *                 openTime: "08:00"
 *                 closeTime: "17:00"
 *                 isOpen: true
 *               - dayOfWeek: "MONDAY"
 *                 openTime: "08:00"
 *                 closeTime: "17:00"
 *                 isOpen: true
 *               - dayOfWeek: "THURSDAY"
 *                 openTime: "09:00"
 *                 closeTime: "16:00"
 *                 isOpen: true
 *               - dayOfWeek: "FRIDAY"
 *                 openTime: "00:00"
 *                 closeTime: "00:00"
 *                 isOpen: false
 *     responses:
 *       200:
 *         description: Working hours updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/WorkingHoursResponse'
 *                 message:
 *                   type: string
 *                   example: "Working hours updated successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/rooms:
 *   get:
 *     summary: Get my facility rooms (Self)
 *     description: |
 *       Returns all rooms for the authenticated facility.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Rooms retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/RoomResponse'
 *                 message:
 *                   type: string
 *                   example: "Rooms retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *   post:
 *     summary: Create my facility room (Self)
 *     description: |
 *       Create a new room for the authenticated facility.
 *       Optionally assign a specialty to the room.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateRoomRequest'
 *           examples:
 *             basicRoom:
 *               summary: Basic room
 *               value:
 *                 name: "Salle de consultation 2"
 *             roomWithSpecialty:
 *               summary: Room with specialty
 *               value:
 *                 name: "Salle Cardiologie"
 *                 specialtyId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Room created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/RoomResponse'
 *                 message:
 *                   type: string
 *                   example: "Room created successfully"
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/doctors/invite:
 *   post:
 *     summary: Invite doctor to my facility (Self)
 *     description: |
 *       Send an invitation to a doctor to join the authenticated facility.
 *       Fails if an invitation is already pending or if doctor is already active.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/InviteDoctorRequest'
 *     responses:
 *       201:
 *         description: Doctor invited successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Doctor invited successfully"
 *       400:
 *         description: Already invited or already in facility
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "An invitation is already pending"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       404:
 *         description: Doctor not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/doctors:
 *   get:
 *     summary: Get my facility doctors (Self)
 *     description: |
 *       Returns all doctor relationships for the authenticated facility.
 *       Includes full doctor profiles with specialties and experience.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Doctors retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ClinicDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Clinic doctors retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/doctors/{id}/accept:
 *   post:
 *     summary: Accept doctor's request to join my facility (Self)
 *     description: |
 *       Accept a doctor's request to join the facility.
 *       Only works for requests initiated by the doctor (invitedBy = 'doctor').
 *       Only works when status is PENDING.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: ClinicDoctor link ID
 *     responses:
 *       200:
 *         description: Doctor request accepted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Doctor request accepted"
 *       400:
 *         description: Request not pending or not from a doctor
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Request is no longer pending"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       404:
 *         description: Link not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/doctors/{id}/reject:
 *   post:
 *     summary: Reject doctor's request to join my facility (Self)
 *     description: |
 *       Reject a doctor's request to join the facility.
 *       Only works for requests initiated by the doctor (invitedBy = 'doctor').
 *       Only works when status is PENDING.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: ClinicDoctor link ID
 *     responses:
 *       200:
 *         description: Doctor request rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDoctorResponse'
 *                 message:
 *                   type: string
 *                   example: "Doctor request rejected"
 *       400:
 *         description: Request not pending or not from a doctor
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       404:
 *         description: Link not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/doctors/{id}:
 *   delete:
 *     summary: Remove doctor from my facility (Self)
 *     description: |
 *       Remove a doctor from the authenticated facility.
 *       Validates that the doctor link belongs to the facility.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: ClinicDoctor link ID
 *     responses:
 *       200:
 *         description: Doctor removed from facility
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Doctor removed from clinic"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       404:
 *         description: Link not found
 */

/**
 * @swagger
 * /api/v1/clinic/v1/me/gallery:
 *   get:
 *     summary: Get my facility gallery (Self)
 *     description: |
 *       Returns all gallery images for the authenticated facility.
 *       Each image URL uses a UUID (fileId) for secure access.
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Gallery retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/GalleryImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Gallery retrieved successfully"
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *   post:
 *     summary: Upload my facility gallery image (Self)
 *     description: |
 *       Upload a gallery image for the authenticated facility. Accepted: JPEG, PNG, WebP, SVG. Max 5MB.
 *       Uses multipart/form-data field `image`.
 *       
 *       **Storage details:**
 *       - Files stored in **public** storage with UUID filenames
 *       - Access via public URL: `/api/v1/files/public/{fileId}`
 *       - Captions support French and Arabic
 *       - Sort order auto-incremented (max + 1)
 *       
 *       **Access:** CLINIC only
 *     tags: [Clinic]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, SVG - max 5MB)
 *               captionFr:
 *                 type: string
 *                 maxLength: 200
 *                 description: French caption
 *               captionAr:
 *                 type: string
 *                 maxLength: 200
 *                 description: Arabic caption
 *     responses:
 *       201:
 *         description: Image uploaded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GalleryImageResponse'
 *                 message:
 *                   type: string
 *                   example: "Gallery image uploaded"
 *       400:
 *         description: Invalid file or missing image
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - Requires CLINIC role
 *       413:
 *         description: File too large (max 5MB)
 */