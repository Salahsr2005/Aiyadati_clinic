import { Request, Response, NextFunction } from 'express';
import { clinicService } from './clinic.service';
import { ResponseUtil } from '../../../core/utils/response';

export class ClinicController {
  // === Staff Endpoints ===

  findAll = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { clinics, total } = await clinicService.findAll(req.query);
      ResponseUtil.paginated(res, clinics, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Clinics retrieved successfully');
    } catch (error) { next(error); }
  };

  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const clinic = await clinicService.create(req.body, req.user!.id, req.ip);
        ResponseUtil.created(res, clinic, 'Clinic created successfully');
      } catch (error) { next(error); }
    };

  findById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.findById(req.params.id);
      ResponseUtil.success(res, clinic, 'Clinic retrieved successfully');
    } catch (error) { next(error); }
  };

  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.update(req.params.id, req.body, req.user!.id, req.ip);
      ResponseUtil.success(res, clinic, 'Clinic updated successfully');
    } catch (error) { next(error); }
  };

  verify = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.verify(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, clinic, 'Clinic verified successfully');
    } catch (error) { next(error); }
  };

  suspend = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.suspend(req.params.id, req.body, req.user!.id, req.ip);
      ResponseUtil.success(res, clinic, 'Clinic suspended successfully');
    } catch (error) { next(error); }
  };

  unsuspend = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.unsuspend(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, clinic, 'Clinic unsuspended successfully');
    } catch (error) { next(error); }
  };

  uploadLogo = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Logo file is required'); return; }
      const clinic = await clinicService.uploadLogo(req.params.id, req.file);
      ResponseUtil.success(res, clinic, 'Logo uploaded successfully');
    } catch (error) { next(error); }
  };

  // === Document Endpoints ===

  getDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const documents = await clinicService.getDocuments(req.params.id);
      ResponseUtil.success(res, documents, 'Documents retrieved successfully');
    } catch (error) { next(error); }
  };

  uploadDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Document file is required'); return; }
      const doc = await clinicService.uploadDocument(req.params.id, req.file, req.user!.id);
      ResponseUtil.created(res, doc, 'Document uploaded successfully');
    } catch (error) { next(error); }
  };

  deleteDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicService.deleteDocument(req.params.id, req.params.documentId, req.user!.id, req.ip);
      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) { next(error); }
  };

  // === Clinic Self-Service Endpoints (Clinic JWT) ===

  uploadMyDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Document file is required'); return; }
      const doc = await clinicService.uploadDocument(req.user!.id, req.file, req.user!.id);
      ResponseUtil.created(res, doc, 'Document uploaded successfully');
    } catch (error) { next(error); }
  };

  getMyDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const documents = await clinicService.getDocuments(req.user!.id);
      ResponseUtil.success(res, documents, 'Documents retrieved successfully');
    } catch (error) { next(error); }
  };

  completeMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const logoFile = req.file || undefined;
      const clinic = await clinicService.completeProfile(req.user!.id, req.body, logoFile);
      ResponseUtil.success(res, clinic, 'Profile completed successfully');
    } catch (error) { next(error); }
  };

  getMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await clinicService.findById(req.user!.id);
      ResponseUtil.success(res, clinic, 'Clinic profile retrieved successfully');
    } catch (error) { next(error); }
  };

  setWorkingHours = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const hours = await clinicService.setWorkingHours(req.params.id, req.body.hours);
      ResponseUtil.success(res, hours, 'Working hours updated successfully');
    } catch (error) { next(error); }
  };

  getWorkingHours = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const hours = await clinicService.getWorkingHours(req.params.id);
      ResponseUtil.success(res, hours, 'Working hours retrieved successfully');
    } catch (error) { next(error); }
  };

  // My clinic working hours
  getMyWorkingHours = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const hours = await clinicService.getWorkingHours(req.user!.id);
      ResponseUtil.success(res, hours, 'Working hours retrieved successfully');
    } catch (error) { next(error); }
  };

  setMyWorkingHours = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const hours = await clinicService.setWorkingHours(req.user!.id, req.body.hours);
      ResponseUtil.success(res, hours, 'Working hours updated successfully');
    } catch (error) { next(error); }
  };

  // === Rooms ===

  createRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const room = await clinicService.createRoom(req.params.id, req.body);
      ResponseUtil.created(res, room, 'Room created successfully');
    } catch (error) { next(error); }
  };

  getRooms = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rooms = await clinicService.getRooms(req.params.id);
      ResponseUtil.success(res, rooms, 'Rooms retrieved successfully');
    } catch (error) { next(error); }
  };

  updateRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const room = await clinicService.updateRoom(req.params.roomId, req.body);
      ResponseUtil.success(res, room, 'Room updated successfully');
    } catch (error) { next(error); }
  };

  deleteRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicService.deleteRoom(req.params.roomId);
      ResponseUtil.success(res, null, 'Room deleted successfully');
    } catch (error) { next(error); }
  };

  // My clinic rooms
  getMyRooms = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rooms = await clinicService.getRooms(req.user!.id);
      ResponseUtil.success(res, rooms, 'Rooms retrieved successfully');
    } catch (error) { next(error); }
  };

  createMyRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const room = await clinicService.createRoom(req.user!.id, req.body);
      ResponseUtil.created(res, room, 'Room created successfully');
    } catch (error) { next(error); }
  };

  inviteDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await clinicService.inviteDoctor(req.user!.id, req.body.doctorId, req.user!.id);
      ResponseUtil.created(res, result, 'Doctor invited successfully');
    } catch (error) { next(error); }
  };

  getMyClinicDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctors = await clinicService.getClinicDoctors(req.user!.id);
      ResponseUtil.success(res, doctors, 'Clinic doctors retrieved successfully');
    } catch (error) { next(error); }
  };

  respondToDoctorRequest = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const action = req.params.action === 'accept' ? 'ACCEPTED' : 'REJECTED';
      const result = await clinicService.respondToDoctorRequest(req.params.id, action);
      ResponseUtil.success(res, result, `Doctor request ${action === 'ACCEPTED' ? 'accepted' : 'rejected'}`);
    } catch (error) { next(error); }
  };

  removeDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicService.removeDoctorFromClinic(req.user!.id, req.params.id);
      ResponseUtil.success(res, null, 'Doctor removed from clinic');
    } catch (error) { next(error); }
  };

  getClinicDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctors = await clinicService.getClinicDoctors(req.params.id);
      ResponseUtil.success(res, doctors, 'Clinic doctors retrieved successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // GALLERY METHODS
  // ============================================================

  getGallery = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const images = await clinicService.getGallery(req.params.id);
      ResponseUtil.success(res, images, 'Gallery retrieved successfully');
    } catch (error) { next(error); }
  };

  uploadGalleryImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Image is required'); return; }
      const img = await clinicService.uploadGalleryImage(
        req.params.id,
        req.file,
        req.body.captionFr,
        req.body.captionAr
      );
      ResponseUtil.created(res, img, 'Gallery image uploaded');
    } catch (error) { next(error); }
  };

  updateGalleryImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const img = await clinicService.updateGalleryImage(req.params.imageId, req.body);
      ResponseUtil.success(res, img, 'Gallery image updated');
    } catch (error) { next(error); }
  };

  deleteGalleryImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // ✅ Pass clinicId and imageId to service
      await clinicService.deleteGalleryImage(req.params.imageId, req.params.id);
      ResponseUtil.success(res, null, 'Gallery image deleted');
    } catch (error) { next(error); }
  };

  // Self-service
  getMyGallery = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const images = await clinicService.getGallery(req.user!.id);
      ResponseUtil.success(res, images, 'Gallery retrieved successfully');
    } catch (error) { next(error); }
  };

  uploadMyGalleryImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Image is required'); return; }
      const img = await clinicService.uploadGalleryImage(
        req.user!.id,
        req.file,
        req.body.captionFr,
        req.body.captionAr
      );
      ResponseUtil.created(res, img, 'Gallery image uploaded');
    } catch (error) { next(error); }
  };

  deleteMyDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await clinicService.deleteMyDocument(req.user!.id, req.params.id);
      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) { next(error); }
  };
}

