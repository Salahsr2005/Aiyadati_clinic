// src/modules/clinic/v1/clinic.routes.ts
import { Router } from 'express';
import { ClinicController } from './clinic.controller';
import { 
  validateCreateClinic,
  validateUpdateClinic, 
  validateSuspendClinic, 
  validateCompleteClinic,
  validateWorkingHours,
  validateCreateRoom,
  validateUpdateRoom,
  validateInviteDoctor,
  validateUpdateGalleryImage,
} from './clinic.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { 
  uploadLogo, 
  uploadClinicDocument,
  uploadGalleryImage 
} from '../../../core/middleware/upload.middleware';

const router = Router();
const clinicController = new ClinicController();

// ============================================================
// Clinic Self-Service Routes - MUST be before /:id
// ============================================================

// Profile
router.get('/me/profile', authenticate, authorize('CLINIC'), clinicController.getMyProfile);
router.patch('/me/complete', authenticate, authorize('CLINIC'), uploadLogo, validateCompleteClinic, clinicController.completeMyProfile);

// Documents (self)
router.get('/me/documents', authenticate, authorize('CLINIC'), clinicController.getMyDocuments);
router.post('/me/documents', authenticate, authorize('CLINIC'), uploadClinicDocument, clinicController.uploadMyDocument);  // ✅ Changed

// Working Hours (self)
router.get('/me/working-hours', authenticate, authorize('CLINIC'), clinicController.getMyWorkingHours);
router.post('/me/working-hours', authenticate, authorize('CLINIC'), validateWorkingHours, clinicController.setMyWorkingHours);

// Rooms (self)
router.get('/me/rooms', authenticate, authorize('CLINIC'), clinicController.getMyRooms);
router.post('/me/rooms', authenticate, authorize('CLINIC'), validateCreateRoom, clinicController.createMyRoom);

// Doctor Management (self)
router.post('/me/doctors/invite', authenticate, authorize('CLINIC'), validateInviteDoctor, clinicController.inviteDoctor);
router.get('/me/doctors', authenticate, authorize('CLINIC'), clinicController.getMyClinicDoctors);
router.post('/me/doctors/:id/accept', authenticate, authorize('CLINIC'), clinicController.respondToDoctorRequest);
router.post('/me/doctors/:id/reject', authenticate, authorize('CLINIC'), clinicController.respondToDoctorRequest);
router.delete('/me/doctors/:id', authenticate, authorize('CLINIC'), clinicController.removeDoctor);

// Gallery (self)
router.get('/me/gallery', authenticate, authorize('CLINIC'), clinicController.getMyGallery);
router.post('/me/gallery', authenticate, authorize('CLINIC'), uploadGalleryImage, clinicController.uploadMyGalleryImage);
router.delete('/me/documents/:id', authenticate, authorize('CLINIC'), clinicController.deleteMyDocument);


// ============================================================
// Staff Routes (Super Admin + Admin)
// ============================================================

router.get('/', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.findAll);
router.get('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.findById);
router.post('/', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateCreateClinic, clinicController.create);
router.patch('/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateClinic, clinicController.update);
router.post('/:id/verify', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.verify);
router.post('/:id/suspend', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateSuspendClinic, clinicController.suspend);
router.post('/:id/unsuspend', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.unsuspend);
router.post('/:id/logo', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), uploadLogo, clinicController.uploadLogo);

// Documents (staff)
router.get('/:id/documents', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.getDocuments);
router.post('/:id/documents', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), uploadClinicDocument, clinicController.uploadDocument);  // ✅ Changed
router.delete('/:id/documents/:documentId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.deleteDocument);

// Working Hours (staff)
router.get('/:id/working-hours', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.getWorkingHours);
router.post('/:id/working-hours', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateWorkingHours, clinicController.setWorkingHours);

// Rooms (staff)
router.get('/:id/rooms', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.getRooms);
router.post('/:id/rooms', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateCreateRoom, clinicController.createRoom);
router.patch('/:id/rooms/:roomId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateRoom, clinicController.updateRoom);
router.delete('/:id/rooms/:roomId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.deleteRoom);

// Doctors (staff)
router.get('/:id/doctors', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.getClinicDoctors);

// Gallery (staff)
router.get('/:id/gallery', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.getGallery);
router.post('/:id/gallery', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), uploadGalleryImage, clinicController.uploadGalleryImage);
router.patch('/:id/gallery/:imageId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateUpdateGalleryImage, clinicController.updateGalleryImage);
router.delete('/:id/gallery/:imageId', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), clinicController.deleteGalleryImage);

export default router;

