import { Router } from 'express';
import clinicRoutes from './v1/clinic.routes';
import './v1/clinic.swagger';

const router = Router();
router.use('/v1', clinicRoutes);

export { router as clinicModule };

