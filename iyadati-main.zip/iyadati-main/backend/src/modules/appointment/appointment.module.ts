import { Router } from 'express';
import appointmentRoutes from './v1/appointment.routes';
import './v1/appointment.swagger';

const router = Router();
router.use('/v1', appointmentRoutes);

export { router as appointmentModule };

