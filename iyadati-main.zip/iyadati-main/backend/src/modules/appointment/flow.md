Full Appointment System Flow
Step 1: Doctor Sets Config
text
PUT /api/v1/appointment/v1/doctor/config
{ "slotDuration": 30, "bufferTime": 5 }
Doctor says: "Each appointment is 30 minutes, with 5 minutes between."

Step 2: Doctor/Clinic Generates Slots
text
POST /api/v1/appointment/v1/doctor/slots/generate
{ "startDate": "2026-07-01", "endDate": "2026-07-07" }
System:

Checks doctor's weekly availability (e.g., Sun-Thu 8:00-17:00)

Checks doctor's breaks (vacations, days off)

Checks doctor's config (30min slot, 5min buffer)

Deletes old slots in that date range

Generates new slots based on availability

Creates Slot records in DB with status "available"

Result: 100+ slot records for the week, each with unique ID.

Step 3: Patient Views Available Slots
text
GET /api/v1/appointment/v1/slots/doctor-uuid?date=2026-07-01
Returns only slots with status: "available":

json
[
  { "id": "slot-1", "startTime": "08:00", "endTime": "08:30", "status": "available" },
  { "id": "slot-2", "startTime": "08:35", "endTime": "09:05", "status": "available" },
  { "id": "slot-3", "startTime": "09:10", "endTime": "09:40", "status": "available" }
]
Step 4: Patient Books a Slot
text
POST /api/v1/appointment/v1/book
{ "slotId": "slot-1", "type": "IN_PERSON", "paymentMethod": "CREDIT" }
System (in transaction):

Locks slot: Changes slot status from "available" → "booked"

Creates appointment: Links to slot, doctor, patient

Deducts credit: User wallet -1 credit (if CREDIT payment)

Creates transaction: Records "use" transaction

Appointment status: CONFIRMED (auto-confirmed since slot was available)

Step 5a: Patient Cancels (3+ days before)
text
PATCH /api/v1/appointment/v1/appointment-uuid/status
{ "status": "CANCELLED" }
Appointment marked CANCELLED

Slot goes back to "available" (can be rebooked)

User gets +1 credit refund (3+ days rule)

Transaction: "refund"

Step 5b: Patient Cancels (within 3 days)
text
PATCH /api/v1/appointment/v1/appointment-uuid/status
{ "status": "CANCELLED" }
Appointment marked CANCELLED

Slot goes back to "available"

NO refund (within 3 days)

No credit transaction

Step 5c: Doctor/Clinic Cancels Slot
text
DELETE /api/v1/appointment/v1/doctor/slots/slot-1
Slot marked "cancelled"

If booked, appointment cancelled

Patient always refunded (provider cancellation)

Transaction: "refund"

Step 5d: Doctor Cancels Whole Day
text
POST /api/v1/appointment/v1/doctor/slots/cancel-date
{ "date": "2026-07-01", "reason": "Emergency" }
All slots for that date cancelled

All booked appointments cancelled

All patients refunded

Returns count of cancelled appointments

Step 6: Doctor Marks NO_SHOW
text
PATCH /api/v1/appointment/v1/appointment-uuid/status
{ "status": "NO_SHOW" }
Appointment marked NO_SHOW

User's noShowCount incremented

If noShowCount >= 3 → User suspended

Step 7: Appointment Completes
text
PATCH /api/v1/appointment/v1/appointment-uuid/status
{ "status": "COMPLETED" }
Appointment marked COMPLETED

Nothing else happens

Clinic Flow
Same as above but:

Generate slots for their doctors: POST /clinic/doctors/:doctorId/slots/generate

Book for walk-in patients: POST /clinic/book with patientId - no credit deduction

View all clinic appointments: GET /clinic/appointments?date=

Credit Rules Summary
Action	Credit Effect
User books (CREDIT)	-1 immediately
User books (ON_SITE)	No deduction
Doctor/Clinic books for patient	No deduction
User cancels 3+ days before	+1 refund
User cancels within 3 days	No refund
Provider cancels slot	Always refund
3 no-shows	User suspended
Slot Statuses
Status	Meaning
available	Can be booked
booked	Has an active appointment
cancelled	Cancelled by provider, cannot be rebooked