// backend/src/modules/appointment/v1/appointment.service.ts
import { slotRepository } from '../../../repositories/slot.repository';
import { appointmentRepository } from '../../../repositories/appointment.repository';
import { doctorConfigRepository } from '../../../repositories/doctor-config.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { doctorAvailabilityRepository } from '../../../repositories/doctor-availability.repository';
import { doctorBreakRepository } from '../../../repositories/doctor-break.repository';
import { walletRepository } from '../../../repositories/wallet.repository';
import { providerEarningRepository } from '../../../repositories/provider-earning.repository';
import { providerBalanceRepository } from '../../../repositories/provider-balance.repository';
import { creditPriceRepository } from '../../../repositories/credit-price.repository';
import { guestPatientRepository } from '../../../repositories/guest-patient.repository'; 
import { NotFoundError, BadRequestError, ConflictError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { prisma } from '../../../core/utils/prisma';
import { nowAlgeria, getSlotStartDateTimeAlgeria,isSlotInPastAlgeria  } from '../../../core/utils/timezone';
import { 
  DoctorConfigDTO, 
  DoctorConfigResponse, 
  GenerateSlotsDTO, 
  SlotResponse, 
  BookAppointmentDTO, 
  ClinicBookDTO, 
  CancelSlotsDTO, 
  UpdateStatusDTO, 
  AppointmentResponse, 
  ConfirmAppointmentDTO,
  GuestPatientDTO,
  QuickSlotDTO
} from './appointment.types';
import { Prisma } from '@prisma/client';

export class AppointmentService {

  // ======================== CONFIG ========================

  async getDoctorConfig(doctorId: string): Promise<DoctorConfigResponse | null> {
    const config = await doctorConfigRepository.findByDoctorId(doctorId);
    return config ? { 
      id: config.id, 
      doctorId: config.doctorId, 
      slotDuration: config.slotDuration, 
      bufferTime: config.bufferTime, 
      maxPerSlot: config.maxPerSlot 
    } : null;
  }

  async setDoctorConfig(doctorId: string, data: DoctorConfigDTO): Promise<DoctorConfigResponse> {
    const config = await doctorConfigRepository.upsert(doctorId, {
      slotDuration: data.slotDuration,
      bufferTime: data.bufferTime,
      maxPerSlot: data.maxPerSlot || 1,
    });
    return { 
      id: config.id, 
      doctorId: config.doctorId, 
      slotDuration: config.slotDuration, 
      bufferTime: config.bufferTime, 
      maxPerSlot: config.maxPerSlot 
    };
  }

  // ======================== HELPER: Combine date + time ========================

  private combineSlotDateAndTime(date: Date, time: Date): Date {
    const result = new Date(date);
    result.setHours(time.getHours(), time.getMinutes(), 0, 0);
    return result;
  }

  // ======================== HELPER: Resolve or create patient (NEW) ========================

  /**
   * Resolve or create a patient (registered or guest)
   * Called inside a transaction
   */
  private async resolveOrCreatePatient(
    data: BookAppointmentDTO,
    userId: string,
    userRole: string,
    tx: Prisma.TransactionClient
  ): Promise<{ patientId?: string; guestPatientId?: string; patientType: 'REGISTERED' | 'GUEST' }> {
    

    if (data.patientId && data.guestPatient) {
      throw new BadRequestError('Provide either patientId or guestPatient, not both');
    }
    
    // ============================================================
    // Case 1: Registered patient provided
    // ============================================================
    if (data.patientId) {
      const user = await tx.user.findUnique({
        where: { id: data.patientId },
        select: { id: true, isSuspended: true },
      });
      
      if (!user) {
        throw new BadRequestError('Patient not found');
      }
      
      if (user.isSuspended) {
        throw new BadRequestError('Patient is suspended');
      }
      
      return { 
        patientId: data.patientId, 
        patientType: 'REGISTERED' 
      };
    }
    
    // ============================================================
    // Case 2: Guest patient provided
    // ============================================================
    if (data.guestPatient) {
      const guestData = data.guestPatient;
      
      // Check if this phone already belongs to a registered user
      const existingUser = await tx.user.findUnique({
        where: { phone: guestData.phone },
        select: { id: true },
      });
      
      if (existingUser) {
        // Phone exists as registered user - use that instead
        return { 
          patientId: existingUser.id, 
          patientType: 'REGISTERED' 
        };
      }
      
      // Check if this phone already exists as a guest
      const existingGuest = await tx.guestPatient.findFirst({
        where: { phone: guestData.phone },
        select: { id: true },
      });
      
      if (existingGuest) {
        // Use existing guest patient
        return { 
          guestPatientId: existingGuest.id, 
          patientType: 'GUEST' 
        };
      }
      
      // Create new guest patient
      const guest = await tx.guestPatient.create({
        data: {
          firstName: guestData.firstName,
          lastName: guestData.lastName,
          phone: guestData.phone,
          email: guestData.email,
          dateOfBirth: guestData.dateOfBirth ? new Date(guestData.dateOfBirth) : undefined,
          wilayaId: guestData.wilayaId,
          createdBy: userId,
          createdByType: userRole === 'DOCTOR' ? 'DOCTOR' : 'CLINIC',
          notes: guestData.notes,
        },
      });
      
      return { 
        guestPatientId: guest.id, 
        patientType: 'GUEST' 
      };
    }
    
    throw new BadRequestError('Either patientId or guestPatient must be provided');
  }

  // ======================== SLOTS ========================

  async generateSlots(doctorId: string, data: GenerateSlotsDTO, userId: string, userRole: string): Promise<SlotResponse[]> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor || !doctor.isVerified || doctor.isSuspended) throw new BadRequestError('Doctor not available');

    if (userRole === 'CLINIC') {
      const link = await prisma.clinicDoctor.findFirst({
        where: { clinicId: userId, doctorId, status: 'ACCEPTED', isActive: true },
      });
      if (!link) throw new BadRequestError('Doctor is not in your clinic');
    }

    const config = await this.getDoctorConfig(doctorId);
    const slotDuration = config?.slotDuration || 30;
    const bufferTime = config?.bufferTime || 5;
    const maxPerSlot = config?.maxPerSlot || 1;

    const startDate = new Date(data.startDate);
    const endDate = new Date(data.endDate);
    const clinicId = data.clinicId || (userRole === 'CLINIC' ? userId : undefined);

    // ============================================================
    // DELETE SLOTS - WITH PROTECTION (Force is optional, default: false)
    // ============================================================

    try {
      // Check if force mode is requested (admin only)
      if (data.force === true && ['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
        // FORCE MODE: Cancel all active appointments, refund credits, then delete all slots
        logger.warn(`⚠️ FORCE REGENERATION triggered by ${userRole} ${userId} for doctor ${doctorId} from ${data.startDate} to ${data.endDate}`);
        
        const result = await slotRepository.forceDeleteByDoctorAndDateRange(
          doctorId,
          startDate,
          endDate,
          userId
        );
        
        logger.info(`Force deleted: ${result.deletedSlots} slots, ${result.cancelledAppointments} appointments cancelled, ${result.refundedCredits} credits refunded`);
        
        // Emit notifications for cancelled appointments (if any)
        if (result.cancelledAppointments > 0) {
          logger.info(`${result.cancelledAppointments} appointments were cancelled due to force regeneration`);
        }
      } else {
        // NORMAL MODE: Only delete slots without active appointments
        if (data.force === true && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
          logger.warn(`User ${userRole} ${userId} attempted force regeneration without permission`);
        }
        
        const deletedCount = await slotRepository.deleteByDoctorAndDateRange(
          doctorId,
          startDate,
          endDate
        );
        logger.info(`Deleted ${deletedCount} slots for doctor ${doctorId} (normal mode - no active appointments)`);
      }
    } catch (error: any) {
      if (error.message.includes('Cannot regenerate slots')) {
        throw new BadRequestError(error.message);
      }
      throw error;
    }

    // ============================================================
    // GENERATE NEW SLOTS (UNCHANGED)
    // ============================================================

    const slots: any[] = [];
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      const dayOfWeek = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][currentDate.getUTCDay()];
      const availabilities = await doctorAvailabilityRepository.findByDoctorAndDay(doctorId, dayOfWeek);
      const breaks = await doctorBreakRepository.findByDoctorAndDateRange(doctorId, currentDate, currentDate);

      for (const avail of availabilities) {
        if (!avail.isActive) continue;

        const [startH, startM] = [avail.startTime.getUTCHours(), avail.startTime.getUTCMinutes()];
        const [endH, endM] = [avail.endTime.getUTCHours(), avail.endTime.getUTCMinutes()];

        let slotTime = new Date(currentDate);
        slotTime.setHours(startH, startM, 0, 0);
        const availEnd = new Date(currentDate);
        availEnd.setHours(endH, endM, 0, 0);

        while (slotTime.getTime() + slotDuration * 60000 <= availEnd.getTime()) {
          const slotEnd = new Date(slotTime.getTime() + slotDuration * 60000);
          
          const isBreak = breaks.some(b => {
            if (b.isAllDay) return true;
            
            const breakStart = new Date(currentDate);
            breakStart.setHours(b.startTime!.getHours(), b.startTime!.getMinutes(), 0, 0);
            
            const breakEnd = new Date(currentDate);
            breakEnd.setHours(b.endTime!.getHours(), b.endTime!.getMinutes(), 0, 0);
            
            return slotTime < breakEnd && slotEnd > breakStart;
          });
          
          if (!isBreak) {
            slots.push({
              doctorId,
              clinicId: clinicId || avail.clinicId,
              roomId: data.roomId || avail.roomId,
              date: new Date(currentDate),
              startTime: new Date(slotTime),
              endTime: new Date(slotEnd),
              maxPatients: maxPerSlot,
            });
          }
          slotTime = new Date(slotEnd.getTime() + bufferTime * 60000);
        }
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    if (slots.length > 0) {
      await slotRepository.createMany(slots);
    }

    const created = await slotRepository.findByDoctorAndDate(doctorId, data.startDate);
    return Promise.all(created.map((s: any) => this.enrichSlotResponse(s)));
  }

  private async enrichSlotResponse(s: any): Promise<SlotResponse> {
    const currentPatients = await prisma.appointment.count({
      where: { slotId: s.id, status: { notIn: ['CANCELLED', 'NO_SHOW'] } },
    });

    let status = s.status;
    if (s.status !== 'cancelled' && s.status !== 'expired') {
      status = currentPatients >= s.maxPatients ? 'full' : 'available';
    }

    return {
      id: s.id,
      doctorId: s.doctorId,
      clinicId: s.clinicId,
      roomId: s.roomId,
      date: s.date.toISOString().slice(0, 10),
      startTime: s.startTime.toISOString().slice(11, 16),
      endTime: s.endTime.toISOString().slice(11, 16),
      status,
      maxPatients: s.maxPatients,
      currentPatients,
    };
  }

  async getSlots(doctorId: string, date: string): Promise<SlotResponse[]> {
    const slots = await slotRepository.findByDoctorAndDate(doctorId, date);
    return Promise.all(slots.map((s: any) => this.enrichSlotResponse(s)));
  }

  async getAvailableSlots(doctorId: string, date: string): Promise<SlotResponse[]> {
    const slots = await slotRepository.findAvailableByDoctorAndDate(doctorId, date);
    return Promise.all(slots.map((s: any) => this.enrichSlotResponse(s)));
  }

  async cancelSlot(slotId: string, userId: string, userRole: string): Promise<void> {
    const slot = await slotRepository.findById(slotId);
    if (!slot) throw new NotFoundError('Slot not found');
    if (userRole === 'DOCTOR' && slot.doctorId !== userId) throw new BadRequestError('Not your slot');
    if (userRole === 'CLINIC' && slot.clinicId !== userId) throw new BadRequestError('Not your clinic slot');

    const cancelledAppointments: any[] = [];

    await prisma.$transaction(async (tx) => {
      await tx.slot.update({ where: { id: slotId }, data: { status: 'cancelled' } });

      const appointments = await tx.appointment.findMany({
        where: { slotId, status: { notIn: ['CANCELLED', 'NO_SHOW'] } },
        include: { patient: true, guestPatient: true }, // ✅ UPDATED
      });

      for (const appointment of appointments) {
        await tx.appointment.update({
          where: { id: appointment.id },
          data: { 
            status: 'CANCELLED', 
            cancelledAt: new Date(), 
            cancelledBy: userId, 
            cancelReason: 'Slot cancelled by provider' 
          },
        });

        // ✅ UPDATED: Only refund registered patients with credits
        if (appointment.patientType === 'REGISTERED' && appointment.paymentMethod === 'CREDIT' && appointment.patientId) {
          await tx.userWallet.upsert({
            where: { userId: appointment.patientId },
            create: { userId: appointment.patientId, credits: 1 },
            update: { credits: { increment: 1 } },
          });
          const wallet = await tx.userWallet.findUnique({ where: { userId: appointment.patientId } });
          if (wallet) {
            await tx.creditTransaction.create({
              data: { 
                walletId: wallet.id, 
                amount: 1, 
                type: 'refund', 
                description: 'Slot cancelled by provider', 
                referenceId: appointment.id 
              },
            });
          }
        }

        cancelledAppointments.push({
          patientId: appointment.patientId,
          patientType: appointment.patientType,
          appointmentId: appointment.id,
          slotDate: slot.date.toISOString().slice(0, 10),
        });
      }
    });

    // ✅ Emit notifications AFTER transaction commits (only for registered patients)
    for (const app of cancelledAppointments) {
      if (app.patientType === 'REGISTERED' && app.patientId) {
        eventEmitter.emit('notification', {
          userId: app.patientId,
          title: 'Appointment Cancelled',
          body: `Your appointment on ${app.slotDate} has been cancelled by the provider. Credits have been refunded.`,
          type: 'appointment',
          data: { appointmentId: app.appointmentId, type: 'cancelled_by_provider' },
        });
      }
    }
  }

  async cancelSlotsByDate(doctorId: string, data: CancelSlotsDTO, userId: string, userRole: string): Promise<number> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');
    if (userRole === 'DOCTOR' && doctorId !== userId) throw new BadRequestError('Not your account');
    if (userRole === 'CLINIC') {
      const link = await prisma.clinicDoctor.findFirst({ 
        where: { clinicId: userId, doctorId, status: 'ACCEPTED', isActive: true } 
      });
      if (!link) throw new BadRequestError('Doctor is not in your clinic');
    }

    let cancelledCount = 0;
    const cancelledAppointments: any[] = [];

    await prisma.$transaction(async (tx) => {
      const slots = await tx.slot.findMany({
        where: { doctorId, date: new Date(data.date), status: { in: ['available', 'full'] } },
        include: { 
          appointments: { 
            where: { status: { notIn: ['CANCELLED', 'NO_SHOW'] } },
            include: { patient: true, guestPatient: true },
          } 
        },
      });

      for (const slot of slots) {
        await tx.slot.update({ where: { id: slot.id }, data: { status: 'cancelled' } });
        cancelledCount++;

        for (const appointment of slot.appointments) {
          await tx.appointment.update({
            where: { id: appointment.id },
            data: { 
              status: 'CANCELLED', 
              cancelledAt: new Date(), 
              cancelledBy: userId, 
              cancelReason: data.reason || 'Slot cancelled by provider' 
            },
          });

          // ✅ UPDATED: Only refund registered patients with credits
          if (appointment.patientType === 'REGISTERED' && appointment.paymentMethod === 'CREDIT' && appointment.patientId) {
            await tx.userWallet.upsert({
              where: { userId: appointment.patientId },
              create: { userId: appointment.patientId, credits: 1 },
              update: { credits: { increment: 1 } },
            });
            const wallet = await tx.userWallet.findUnique({ where: { userId: appointment.patientId } });
            if (wallet) {
              await tx.creditTransaction.create({
                data: { 
                  walletId: wallet.id, 
                  amount: 1, 
                  type: 'refund', 
                  description: 'Slot cancelled by provider', 
                  referenceId: appointment.id 
                },
              });
            }
          }

          cancelledAppointments.push({
            patientId: appointment.patientId,
            patientType: appointment.patientType,
            appointmentId: appointment.id,
            slotDate: data.date,
          });
        }
      }
    });

    // ✅ Emit notifications AFTER transaction commits (only for registered patients)
    for (const app of cancelledAppointments) {
      if (app.patientType === 'REGISTERED' && app.patientId) {
        eventEmitter.emit('notification', {
          userId: app.patientId,
          title: 'Appointment Cancelled',
          body: `Your appointment on ${app.slotDate} has been cancelled by the provider. Credits have been refunded.`,
          type: 'appointment',
          data: { appointmentId: app.appointmentId, type: 'cancelled_by_provider' },
        });
      }
    }

    return cancelledCount;
  }

  // ======================== APPOINTMENTS ========================

  // ✅ UPDATED: toAppointmentResponse with guest patient support
  private toAppointmentResponse(a: any): AppointmentResponse {
    // Get patient info
    let patientResponse: any = null;
    let guestPatientResponse: any = null;
    
    if (a.patientType === 'REGISTERED' && a.patient) {
      patientResponse = {
        id: a.patient.id,
        firstName: a.patient.firstName,
        lastName: a.patient.lastName,
        phone: a.patient.phone,
        isGuest: false,
      };
    }
    
    if (a.patientType === 'GUEST' && a.guestPatient) {
      guestPatientResponse = {
        id: a.guestPatient.id,
        firstName: a.guestPatient.firstName,
        lastName: a.guestPatient.lastName,
        phone: a.guestPatient.phone,
        email: a.guestPatient.email,
        isGuest: true,
      };
    }

    return {
      id: a.id, 
      slotId: a.slotId,
      slot: a.slot ? { 
        id: a.slot.id, 
        doctorId: a.slot.doctorId, 
        clinicId: a.slot.clinicId, 
        roomId: a.slot.roomId, 
        date: a.slot.date?.toISOString()?.slice(0, 10), 
        startTime: a.slot.startTime?.toISOString()?.slice(11, 16), 
        endTime: a.slot.endTime?.toISOString()?.slice(11, 16), 
        status: a.slot.status, 
        maxPatients: a.slot.maxPatients, 
        currentPatients: 0 
      } : undefined,
      doctorId: a.doctorId,
      doctor: a.doctor ? { 
        id: a.doctor.id, 
        firstNameFr: a.doctor.firstNameFr, 
        lastNameFr: a.doctor.lastNameFr, 
        photoUrl: a.doctor.photoPath ? `${process.env.BASE_URL}/uploads/${a.doctor.photoPath}` : null 
      } : undefined,
      patientId: a.patientId,
      patient: patientResponse,
      guestPatientId: a.guestPatientId,
      guestPatient: guestPatientResponse,
      patientType: a.patientType as 'REGISTERED' | 'GUEST',
      contactUserId: a.contactUserId,
      contactUser: a.contactUser ? { 
        id: a.contactUser.id, 
        firstName: a.contactUser.firstName, 
        lastName: a.contactUser.lastName 
      } : null,
      clinicId: a.clinicId,
      clinic: a.clinic ? { id: a.clinic.id, nameFr: a.clinic.nameFr } : null,
      type: a.type, 
      paymentMethod: a.paymentMethod, 
      status: a.status, 
      notes: a.notes,
      createdBy: a.createdBy, 
      createdByType: a.createdByType,
      confirmedAt: a.confirmedAt?.toISOString() || null,
      confirmedBy: a.confirmedBy || null,
      cancelledAt: a.cancelledAt?.toISOString() || null, 
      cancelledBy: a.cancelledBy, 
      cancelReason: a.cancelReason,
      createdAt: a.createdAt.toISOString(), 
      updatedAt: a.updatedAt.toISOString(),
    };
  }

  /**
   * Patient books an appointment
   * ✅ UPDATED: Supports guest patients while preserving existing logic
   */
  async bookAppointment(
    data: BookAppointmentDTO,
    userId: string,
    userRole: string,
    idempotencyKey?: string
  ): Promise<AppointmentResponse> {

    // ✅ Check idempotency first
    if (idempotencyKey) {
      const existing = await prisma.appointment.findUnique({
        where: { idempotencyKey },
        include: { 
          slot: true, 
          doctor: true, 
          patient: true, 
          clinic: true, 
          contactUser: true,
          guestPatient: true, // ✅ NEW
        },
      });
      if (existing) {
        return this.toAppointmentResponse(existing);
      }
    }

    let createdAppointment: any;
    let slotData: any;
    let doctorData: any;
    let patientInfo: { patientId?: string; guestPatientId?: string; patientType: 'REGISTERED' | 'GUEST' } | null = null; // ✅ FIXED: initialized to null

    await prisma.$transaction(async (tx) => {

      // =====================================================
      // 1. Lock slot (prevents overselling)
      // =====================================================

      await tx.$queryRaw`
        SELECT id
        FROM "slots"
        WHERE id = ${data.slotId}
        FOR UPDATE
      `;

      // =====================================================
      // 2. Validate slot (exists, not cancelled, not expired)
      // =====================================================

      const slot = await slotRepository.validateSlotIsBookable(
        data.slotId,
        nowAlgeria(),
        tx,
      );

      // =====================================================
      // 3. Count active appointments
      // =====================================================

      const currentCount = await tx.appointment.count({
        where: {
          slotId: slot.id,
          status: { notIn: ['CANCELLED', 'NO_SHOW'] },
        },
      });

      if (currentCount >= slot.maxPatients) {
        throw new ConflictError('Slot is full');
      }

      // =====================================================
      // 4. Doctor validation
      // =====================================================

      const doctor = await tx.doctor.findUnique({
        where: { id: slot.doctorId },
      });

      if (!doctor || !doctor.isVerified || doctor.isSuspended) {
        throw new BadRequestError('Doctor not available');
      }

      if (!doctor.isAvailableForBooking) {
        const message = doctor.messageForUser 
          ? `Doctor is not currently accepting bookings. ${doctor.messageForUser}`
          : 'Doctor is not currently accepting bookings.';
        throw new BadRequestError(message);
      }

      // =====================================================
      // 5. ✅ NEW: Resolve or create patient (registered or guest)
      // =====================================================

      patientInfo = await this.resolveOrCreatePatient(
        data,
        userId,
        userRole,
        tx
      );

      // =====================================================
      // 6. Determine if using credits
      // =====================================================

      const isGuest = patientInfo.patientType === 'GUEST';
      // ✅ PRESERVED: Original credit logic for registered users
      const usingCredits =
        userRole === 'USER' &&
        ((data.paymentMethod as any) === 'CREDIT' || !data.paymentMethod) &&
        !isGuest; // ✅ ADDED: Guest patients don't use credits

      // =====================================================
      // 7. Get current credit price
      // =====================================================

      const creditPrice = await creditPriceRepository.getLatest(tx);
      const priceAtBooking = creditPrice?.price || 0;

      // =====================================================
      // 8. Atomic wallet deduction with balance check (PRESERVED)
      // =====================================================

      if (usingCredits) {
        const result = await tx.$queryRaw`
          UPDATE "user_wallets"
          SET credits = credits - 1
          WHERE user_id = ${userId}
          AND credits >= 1
          RETURNING id, credits
        `;

        const updatedWallet = (result as any[])[0];
        
        if (!updatedWallet) {
          throw new BadRequestError('Insufficient credits');
        }
      }

      // =====================================================
      // 9. Create appointment with PENDING status
      // =====================================================

      const appointment = await tx.appointment.create({
        data: {
          slotId: slot.id,
          doctorId: slot.doctorId,
          // ✅ UPDATED: Use patientInfo instead of always userId
          patientId: patientInfo.patientId || null,
          guestPatientId: patientInfo.guestPatientId || null,
          patientType: patientInfo.patientType,
          contactUserId: data.contactUserId || null,
          clinicId: slot.clinicId || null,
          type: (data.type as any) || 'IN_PERSON',
          // ✅ UPDATED: Guest patients forced to ON_SITE
          paymentMethod: isGuest ? 'ON_SITE' : (data.paymentMethod as any) || 'CREDIT',
          notes: data.notes || null,
          createdBy: userId,
          createdByType: userRole === 'USER' ? 'user' : userRole === 'DOCTOR' ? 'doctor' : 'clinic',
          status: 'PENDING',
          creditPriceAtBooking: priceAtBooking,
          creditPriceId: creditPrice?.id,
          idempotencyKey: idempotencyKey || null,
        },
      });

      // =====================================================
      // 10. Update slot status based on active count
      // =====================================================

      const newCount = currentCount + 1;
      const newSlotStatus = newCount >= slot.maxPatients ? 'full' : 'available';
      
      if (slot.status !== newSlotStatus) {
        await tx.slot.update({
          where: { id: slot.id },
          data: { status: newSlotStatus },
        });
      }

      // =====================================================
      // 11. Wallet transaction history (PRESERVED)
      // =====================================================

      if (usingCredits) {
        const wallet = await tx.userWallet.findUnique({
          where: { userId },
          select: { id: true },
        });

        if (!wallet) {
          throw new Error('Wallet not found after successful deduction.');
        }

        await tx.creditTransaction.create({
          data: {
            walletId: wallet.id,
            amount: -1,
            type: 'use',
            description: `Appointment with Dr. ${doctor.firstNameFr} ${doctor.lastNameFr}`,
            referenceId: appointment.id,
          },
        });
      }

      // Store for use after commit
      createdAppointment = appointment;
      slotData = slot;
      doctorData = doctor;
    });

    // =====================================================
    // ✅ Emit notifications AFTER transaction commits
    // =====================================================

    // Get patient name for notification
    let patientName: string;
    if (patientInfo!.patientType === 'REGISTERED' && patientInfo!.patientId) {
      const user = await prisma.user.findUnique({
        where: { id: patientInfo!.patientId },
        select: { firstName: true, lastName: true },
      });
      patientName = user ? `${user.firstName} ${user.lastName}` : 'A patient';
    } else if (patientInfo!.guestPatientId) {
      const guest = await prisma.guestPatient.findUnique({
        where: { id: patientInfo!.guestPatientId },
        select: { firstName: true, lastName: true },
      });
      patientName = guest ? `${guest.firstName} ${guest.lastName}` : 'A guest patient';
    } else {
      patientName = 'A patient';
    }

    const slotDate = slotData.date.toISOString().slice(0, 10);
    const slotTime = slotData.startTime.toISOString().slice(11, 16);

    eventEmitter.emit('audit', {
      action: 'appointment.created',
      entity: 'Appointment',
      entityId: createdAppointment.id,
      performedBy: userId,
      details: {
        slotId: data.slotId,
        status: 'PENDING',
        patientType: patientInfo!.patientType,
        isGuest: patientInfo!.patientType === 'GUEST',
      },
    });

    eventEmitter.emit('notification', {
      userId: slotData.doctorId,
      title: '📋 Pending Appointment Request',
      body: `${patientName} has requested an appointment for ${slotDate} at ${slotTime} - Please confirm or decline`,
      type: 'appointment',
      data: {
        appointmentId: createdAppointment.id,
        type: 'pending_approval',
        isGuest: patientInfo!.patientType === 'GUEST',
      },
    });

    // Only send notification to registered patients
    if (patientInfo!.patientType === 'REGISTERED' && patientInfo!.patientId) {
      eventEmitter.emit('notification', {
        userId: patientInfo!.patientId,
        title: '⏳ Appointment Request Pending',
        body: `Your appointment with Dr. ${doctorData.firstNameFr} ${doctorData.lastNameFr} is pending confirmation for ${slotDate} at ${slotTime}`,
        type: 'appointment',
        data: {
          appointmentId: createdAppointment.id,
          type: 'pending_confirmation',
        },
      });
    }

    return this.toAppointmentResponse(createdAppointment);
  }

  /**
   * Clinic books an appointment on behalf of a patient
   * ✅ UPDATED: Supports guest patients
   */
  async clinicBookAppointment(data: ClinicBookDTO, clinicId: string): Promise<AppointmentResponse> {
    let createdAppointment: any;
    let slotData: any;
    let doctorData: any;
    let patientInfo: { patientId?: string; guestPatientId?: string; patientType: 'REGISTERED' | 'GUEST' } | null = null; // ✅ FIXED: initialized to null

    await prisma.$transaction(async (tx) => {
      // =====================================================
      // 1. Lock slot (prevents overselling)
      // =====================================================

      await tx.$queryRaw`
        SELECT id
        FROM "slots"
        WHERE id = ${data.slotId}
        FOR UPDATE
      `;

      // =====================================================
      // 2. Validate slot (exists, not cancelled, not expired)
      // =====================================================

      const slot = await slotRepository.validateSlotIsBookable(
        data.slotId,
        nowAlgeria(),
        tx,
      );

      // =====================================================
      // 3. Verify slot belongs to this clinic
      // =====================================================

      if (slot.clinicId !== clinicId) {
        throw new BadRequestError('Slot does not belong to your clinic');
      }

      // =====================================================
      // 4. Count active appointments
      // =====================================================

      const currentCount = await tx.appointment.count({
        where: {
          slotId: slot.id,
          status: { notIn: ['CANCELLED', 'NO_SHOW'] },
        },
      });

      if (currentCount >= slot.maxPatients) {
        throw new ConflictError('Slot is full');
      }

      // =====================================================
      // 5. Get doctor
      // =====================================================

      const doctor = await tx.doctor.findUnique({
        where: { id: slot.doctorId },
      });

      if (!doctor || !doctor.isVerified || doctor.isSuspended) {
        throw new BadRequestError('Doctor not available');
      }

      if (!doctor.isAvailableForBooking) {
        const message = doctor.messageForUser 
          ? `Doctor is not currently accepting bookings. ${doctor.messageForUser}`
          : 'Doctor is not currently accepting bookings.';
        throw new BadRequestError(message);
      }

      // =====================================================
      // 6. ✅ NEW: Resolve or create patient
      // =====================================================

      patientInfo = await this.resolveOrCreatePatient(
        data,
        clinicId,
        'CLINIC',
        tx
      );

      // =====================================================
      // 7. Get current credit price
      // =====================================================

      const creditPrice = await creditPriceRepository.getLatest(tx);
      const priceAtBooking = creditPrice?.price || 0;

      // =====================================================
      // 8. Create appointment with PENDING status
      // =====================================================

      const isGuest = patientInfo.patientType === 'GUEST';

      const appointment = await tx.appointment.create({
        data: {
          slotId: data.slotId,
          doctorId: slot.doctorId,
          // ✅ UPDATED: Use patientInfo
          patientId: patientInfo.patientId || null,
          guestPatientId: patientInfo.guestPatientId || null,
          patientType: patientInfo.patientType,
          clinicId,
          type: (data.type as any) || 'IN_PERSON',
          // ✅ UPDATED: Guest patients forced to ON_SITE
          paymentMethod: isGuest ? 'ON_SITE' : (data.paymentMethod as any) || 'ON_SITE',
          notes: data.notes || null,
          createdBy: clinicId,
          createdByType: 'clinic',
          status: 'PENDING',
          creditPriceAtBooking: priceAtBooking,
          creditPriceId: creditPrice?.id,
        },
      });

      // =====================================================
      // 9. Update slot status based on active count
      // =====================================================

      const newCount = currentCount + 1;
      const newSlotStatus = newCount >= slot.maxPatients ? 'full' : 'available';
      
      if (slot.status !== newSlotStatus) {
        await tx.slot.update({
          where: { id: data.slotId },
          data: { status: newSlotStatus },
        });
      }

      // Store for after commit
      createdAppointment = appointment;
      slotData = slot;
      doctorData = doctor;
    });

    // ✅ Emit notifications AFTER transaction commits
    const slotDate = slotData.date.toISOString().slice(0, 10);
    const slotTime = slotData.startTime.toISOString().slice(11, 16);

    eventEmitter.emit('notification', {
      userId: slotData.doctorId,
      title: '📋 Pending Appointment Request',
      body: `A clinic has booked an appointment for ${patientInfo!.patientType === 'GUEST' ? 'a guest patient' : 'a patient'} on ${slotDate} at ${slotTime} - Please confirm`,
      type: 'appointment',
      data: { 
        appointmentId: createdAppointment.id, 
        type: 'pending_approval',
        isGuest: patientInfo!.patientType === 'GUEST',
      },
    });

    return this.toAppointmentResponse(createdAppointment);
  }

  async confirmAppointment(
    appointmentId: string,
    userId: string,
    userRole: string,
    data?: ConfirmAppointmentDTO
  ): Promise<AppointmentResponse> {
    const appointment = await appointmentRepository.findById(appointmentId);
    if (!appointment) throw new NotFoundError('Appointment');

    if (!['DOCTOR', 'CLINIC'].includes(userRole)) {
      throw new BadRequestError('Only doctors or clinics can confirm appointments');
    }

    if (userRole === 'DOCTOR' && appointment.doctorId !== userId) {
      throw new BadRequestError('Not your appointment');
    }
    if (userRole === 'CLINIC' && appointment.clinicId !== userId) {
      throw new BadRequestError('Not your clinic appointment');
    }

    if (appointment.status !== 'PENDING') {
      throw new BadRequestError(`Cannot confirm appointment with status ${appointment.status}`);
    }

    let updatedAppointment: any;

    await prisma.$transaction(async (tx) => {
      updatedAppointment = await tx.appointment.update({
        where: { id: appointmentId },
        data: {
          status: 'CONFIRMED',
          confirmedAt: new Date(),
          confirmedBy: userId,
        },
      });
    });

    // ✅ Emit notifications AFTER commit
    const slotDate = appointment.slot?.date?.toISOString()?.slice(0, 10) || '';
    const slotTime = appointment.slot?.startTime?.toISOString()?.slice(11, 16) || '';
    const doctor = await doctorRepository.findById(appointment.doctorId);

    // ✅ Only send to registered patients
    if (appointment.patientType === 'REGISTERED' && appointment.patientId) {
      eventEmitter.emit('notification', {
        userId: appointment.patientId,
        title: '✅ Appointment Confirmed',
        body: `Your appointment with Dr. ${doctor?.firstNameFr} ${doctor?.lastNameFr} has been confirmed for ${slotDate} at ${slotTime}`,
        type: 'appointment',
        data: { appointmentId, type: 'confirmed' },
      });
    }

    eventEmitter.emit('audit', {
      action: 'appointment.confirmed',
      entity: 'Appointment',
      entityId: appointmentId,
      performedBy: userId,
      details: {
        previousStatus: appointment.status,
        newStatus: 'CONFIRMED',
        confirmedBy: userRole,
        patientType: appointment.patientType,
      },
    });

    return this.toAppointmentResponse(updatedAppointment);
  }

  async getMyAppointments(userId: string, page = 1, limit = 10) {
    const { appointments, total } = await appointmentRepository.findByPatientId(userId, page, limit);
    return { appointments: appointments.map((a: any) => this.toAppointmentResponse(a)), total };
  }

  async getDoctorAppointments(doctorId: string, page = 1, limit = 10, date?: string) {
    const { appointments, total } = await appointmentRepository.findByDoctorId(doctorId, page, limit, date);
    return { appointments: appointments.map((a: any) => this.toAppointmentResponse(a)), total };
  }

  async getClinicAppointments(clinicId: string, page = 1, limit = 10, date?: string) {
    const { appointments, total } = await appointmentRepository.findByClinicId(clinicId, page, limit, date);
    return { appointments: appointments.map((a: any) => this.toAppointmentResponse(a)), total };
  }

  async getAllAppointments(page = 1, limit = 20, filters?: any) {
    const { appointments, total } = await appointmentRepository.findAll(page, limit, filters);
    return { appointments: appointments.map((a: any) => this.toAppointmentResponse(a)), total };
  }

  /**
   * Update appointment status with proper transaction and notifications
   * ✅ UPDATED: Guest patients don't get trust points or no-show tracking
   */
  async updateStatus(appointmentId: string, data: UpdateStatusDTO, userId: string, userRole: string): Promise<AppointmentResponse> {
    const appointment = await appointmentRepository.findById(appointmentId);
    if (!appointment) throw new NotFoundError('Appointment');

    if (userRole === 'DOCTOR' && appointment.doctorId !== userId) throw new BadRequestError('Not your appointment');
    if (userRole === 'USER' && appointment.patientId !== userId) throw new BadRequestError('Not your appointment');
    if (userRole === 'CLINIC' && appointment.clinicId !== userId) throw new BadRequestError('Not your clinic appointment');

    // Validate status transition (PRESERVED)
    const validTransitions: { [key: string]: string[] } = {
      PENDING: ['CONFIRMED', 'CANCELLED'],
      CONFIRMED: ['IN_PROGRESS', 'CANCELLED', 'NO_SHOW'],
      IN_PROGRESS: ['COMPLETED', 'CANCELLED'],
      COMPLETED: [],
      CANCELLED: [],
      NO_SHOW: [],
    };

    if (!validTransitions[appointment.status].includes(data.status)) {
      throw new BadRequestError(
        `Cannot transition from ${appointment.status} to ${data.status}`
      );
    }

    const extra: any = {};
    const slotDate = appointment.slot?.date?.toISOString()?.slice(0, 10) || '';
    const slotTime = appointment.slot?.startTime?.toISOString()?.slice(11, 16) || '';

    let notificationData: any = null;

    // ============================================================
    // CANCELLED case (PRESERVED + guest support)
    // ============================================================

    if (data.status === 'CANCELLED') {
      const isPatientCancellation = userRole === 'USER';
      
      extra.cancelledAt = new Date();
      extra.cancelledBy = userId;
      extra.cancelReason = data.cancelReason || null;

      await prisma.$transaction(async (tx) => {
        // Update slot status based on active count (PRESERVED)
        const activeCount = await tx.appointment.count({
          where: {
            slotId: appointment.slotId,
            status: { notIn: ['CANCELLED', 'NO_SHOW'] },
          },
        });

        const newActiveCount = activeCount - 1;
        const slotStatus = newActiveCount >= appointment.slot.maxPatients ? 'full' : 'available';
        
        await tx.slot.update({
          where: { id: appointment.slotId },
          data: { status: slotStatus },
        });

        // ✅ UPDATED: Only refund registered patients with credits
        if (appointment.patientType === 'REGISTERED' && appointment.paymentMethod === 'CREDIT' && appointment.patientId) {
          if (!isPatientCancellation) {
            // Provider cancellation - always refund
            const wallet = await walletRepository.getOrCreate(appointment.patientId);
            await walletRepository.addCredits(wallet.id, 1);
            await tx.creditTransaction.create({
              data: {
                walletId: wallet.id,
                amount: 1,
                type: 'refund',
                description: 'Cancelled by provider',
                referenceId: appointmentId,
              },
            });
          } else {
            // Patient cancellation - check 3-day rule (PRESERVED)
            const appointmentDateTime = getSlotStartDateTimeAlgeria(
              appointment.slot?.date || appointment.createdAt,
              appointment.slot?.startTime || new Date()
            );
            
            const now = nowAlgeria();
            const daysUntil = Math.ceil((appointmentDateTime.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

            if (daysUntil >= 3) {
              const wallet = await walletRepository.getOrCreate(appointment.patientId);
              await walletRepository.addCredits(wallet.id, 1);
              await tx.creditTransaction.create({
                data: {
                  walletId: wallet.id,
                  amount: 1,
                  type: 'refund',
                  description: `Refund (${daysUntil} days before)`,
                  referenceId: appointmentId,
                },
              });
            }
          }
        }

        // Update appointment status (PRESERVED)
        await tx.appointment.update({
          where: { id: appointmentId },
          data: {
            status: 'CANCELLED',
            cancelledAt: new Date(),
            cancelledBy: userId,
            cancelReason: data.cancelReason || null,
          },
        });
      });

      notificationData = {
        patientId: appointment.patientId,
        patientType: appointment.patientType,
        doctorId: appointment.doctorId,
        slotDate,
        slotTime,
        cancelReason: data.cancelReason,
        appointmentId,
        isPatientCancellation,
      };
    }

    // ============================================================
    // NO_SHOW case (PRESERVED + guest support)
    // ============================================================

    if (data.status === 'NO_SHOW') {
      await prisma.$transaction(async (tx) => {
        // ✅ UPDATED: Only update trust for registered patients
        if (appointment.patientType === 'REGISTERED' && appointment.patientId) {
          const user = await tx.user.update({
            where: { id: appointment.patientId },
            data: { noShowCount: { increment: 1 } },
          });
          if (user.noShowCount >= 3) {
            await tx.user.update({
              where: { id: appointment.patientId },
              data: { isSuspended: true, suspensionReason: '3 no-show appointments' },
            });
          }
        }

        await tx.appointment.update({
          where: { id: appointmentId },
          data: { status: 'NO_SHOW' },
        });
      });

      notificationData = {
        patientId: appointment.patientId,
        patientType: appointment.patientType,
        type: 'no_show',
        appointmentId,
      };
    }

    // ============================================================
    // CONFIRMED case (PRESERVED)
    // ============================================================

    if (data.status === 'CONFIRMED') {
      if (!['DOCTOR', 'CLINIC'].includes(userRole)) {
        throw new BadRequestError('Only doctors or clinics can confirm appointments');
      }
      if (appointment.status !== 'PENDING') {
        throw new BadRequestError(`Cannot confirm appointment with status ${appointment.status}`);
      }
      
      await prisma.$transaction(async (tx) => {
        await tx.appointment.update({
          where: { id: appointmentId },
          data: {
            status: 'CONFIRMED',
            confirmedAt: new Date(),
            confirmedBy: userId,
          },
        });
      });
      
      notificationData = {
        patientId: appointment.patientId,
        patientType: appointment.patientType,
        slotDate,
        slotTime,
        appointmentId,
        type: 'confirmed',
        doctorName: appointment.doctor ? `${appointment.doctor.firstNameFr} ${appointment.doctor.lastNameFr}` : '',
      };
    }

    // ============================================================
    // IN_PROGRESS case (PRESERVED)
    // ============================================================

    if (data.status === 'IN_PROGRESS') {
      await prisma.$transaction(async (tx) => {
        await tx.appointment.update({
          where: { id: appointmentId },
          data: { status: 'IN_PROGRESS' },
        });
      });
    }

    // ============================================================
    // COMPLETED case with earnings INSIDE transaction (PRESERVED + guest support)
    // ============================================================

    if (data.status === 'COMPLETED') {
      let updatedAppointment: any;

      await prisma.$transaction(async (tx) => {
        // 1. Update appointment to COMPLETED (PRESERVED)
        updatedAppointment = await tx.appointment.update({
          where: { id: appointmentId },
          data: { status: 'COMPLETED' },
        });

        // 2. Create earnings ONLY if appointment was created by USER and patient is REGISTERED (UPDATED)
        if (appointment.createdByType === 'user' && appointment.patientType === 'REGISTERED') {
          const amount = appointment.creditPriceAtBooking || 0;

          if (amount > 0) {
            const slotDateStr = appointment.slot?.date?.toISOString()?.slice(0, 10) || '';
            const slotTimeStr = appointment.slot?.startTime?.toISOString()?.slice(11, 16) || '';

            try {
              // Doctor earning
              await tx.providerEarning.create({
                data: {
                  providerId: appointment.doctorId,
                  providerType: 'DOCTOR',
                  amount: amount,
                  appointmentId: appointment.id,
                  creditPriceId: appointment.creditPriceId,
                  notes: `Appointment completed on ${slotDateStr} at ${slotTimeStr}`,
                },
              });

              // Update doctor's balance
              await tx.providerBalance.upsert({
                where: { providerId: appointment.doctorId },
                create: {
                  providerId: appointment.doctorId,
                  providerType: 'DOCTOR',
                  totalEarned: amount,
                  pendingBalance: amount,
                },
                update: {
                  totalEarned: { increment: amount },
                  pendingBalance: { increment: amount },
                  lastUpdated: new Date(),
                },
              });

              // Clinic commission (if applicable)
              if (appointment.clinicId) {
                const clinicAmount = amount * 0.3;
                
                await tx.providerEarning.create({
                  data: {
                    providerId: appointment.clinicId,
                    providerType: 'CLINIC',
                    amount: clinicAmount,
                    appointmentId: appointment.id,
                    creditPriceId: appointment.creditPriceId,
                    notes: `Commission for appointment completed on ${slotDateStr} at ${slotTimeStr}`,
                  },
                });

                await tx.providerBalance.upsert({
                  where: { providerId: appointment.clinicId },
                  create: {
                    providerId: appointment.clinicId,
                    providerType: 'CLINIC',
                    totalEarned: clinicAmount,
                    pendingBalance: clinicAmount,
                  },
                  update: {
                    totalEarned: { increment: clinicAmount },
                    pendingBalance: { increment: clinicAmount },
                    lastUpdated: new Date(),
                  },
                });
              }
            } catch (error: any) {
              if (error.code === 'P2002') {
                logger.info(`Earnings already exist for appointment ${appointment.id}, skipping`);
              } else {
                throw error;
              }
            }
          }
        }
      });

      notificationData = {
        patientId: appointment.patientId,
        patientType: appointment.patientType,
        type: 'completed',
        appointmentId,
      };
    }

    // ============================================================
    // ✅ Send notifications AFTER transaction commits (UPDATED)
    // ============================================================

    if (notificationData) {
      if (data.status === 'CANCELLED') {
        const { patientId, patientType, doctorId, slotDate, slotTime, cancelReason, isPatientCancellation } = notificationData;
        
        eventEmitter.emit('notification', {
          userId: doctorId,
          title: '❌ Appointment Cancelled',
          body: `Appointment on ${slotDate} at ${slotTime} has been cancelled.`,
          type: 'appointment',
          data: { appointmentId, type: 'cancelled' },
        });

        // ✅ Only send to registered patients
        if (patientType === 'REGISTERED' && patientId) {
          eventEmitter.emit('notification', {
            userId: patientId,
            title: '❌ Appointment Cancelled',
            body: `Your appointment on ${slotDate} at ${slotTime} has been cancelled${cancelReason ? ': ' + cancelReason : ''}.${isPatientCancellation ? '' : ' Credits have been refunded.'}`,
            type: 'appointment',
            data: { appointmentId, type: 'cancelled' },
          });
        }
      }

      if (data.status === 'NO_SHOW') {
        // ✅ Only send to registered patients
        if (notificationData.patientType === 'REGISTERED' && notificationData.patientId) {
          eventEmitter.emit('notification', {
            userId: notificationData.patientId,
            title: '⚠️ Missed Appointment',
            body: 'You have been marked as no-show. This affects your trust score. 3 no-shows will result in account suspension.',
            type: 'appointment',
            data: { appointmentId, type: 'no_show' },
          });
        }
      }

      if (data.status === 'CONFIRMED') {
        // ✅ Only send to registered patients
        if (notificationData.patientType === 'REGISTERED' && notificationData.patientId) {
          eventEmitter.emit('notification', {
            userId: notificationData.patientId,
            title: '✅ Appointment Confirmed',
            body: `Your appointment on ${notificationData.slotDate} at ${notificationData.slotTime} has been confirmed by the provider.`,
            type: 'appointment',
            data: { appointmentId, type: 'confirmed' },
          });
        }
      }

      if (data.status === 'COMPLETED') {
        // ✅ Only send to registered patients
        if (notificationData.patientType === 'REGISTERED' && notificationData.patientId) {
          eventEmitter.emit('notification', {
            userId: notificationData.patientId,
            title: '✅ Appointment Completed',
            body: 'Thank you for your visit! Your trust score has been updated.',
            type: 'appointment',
            data: { appointmentId, type: 'completed' },
          });
        }
      }
    }

    // ============================================================
    // ✅ Trust points - only for registered patients (UPDATED)
    // ============================================================

    if (appointment.patientType === 'REGISTERED' && appointment.patientId) {
      await this.updateTrustPoints(
        appointment.patientId,
        data.status,
        extra.cancelledAt || undefined,
        appointment.slot?.date || appointment.createdAt,
        appointment.slot?.startTime || new Date()
      );
    }

    // Get the updated appointment
    const updated = await appointmentRepository.findById(appointmentId);
    return this.toAppointmentResponse(updated);
  }

  /**
   * Add a single quick slot (Doctor or Clinic)
   * Validates against availability, breaks, and prevents duplicates
   */
  async addQuickSlot(
    doctorId: string,
    data: QuickSlotDTO,
    userId: string,
    userRole: string
  ): Promise<SlotResponse> {
    // =====================================================
    // 1. Validate doctor exists and is available
    // =====================================================

    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor || !doctor.isVerified || doctor.isSuspended) {
      throw new BadRequestError('Doctor not available');
    }

    // =====================================================
    // 2. Validate clinic permissions (if clinic role)
    // =====================================================

    if (userRole === 'CLINIC') {
      const link = await prisma.clinicDoctor.findFirst({
        where: { 
          clinicId: userId, 
          doctorId, 
          status: 'ACCEPTED', 
          isActive: true 
        },
      });
      if (!link) throw new BadRequestError('Doctor is not in your clinic');
    }

    // =====================================================
    // 3. Parse dates
    // =====================================================

    const slotDate = new Date(data.date);
    if (isNaN(slotDate.getTime())) {
      throw new BadRequestError('Invalid date format. Use YYYY-MM-DD');
    }

    // Parse start and end times
    const [startHour, startMinute] = data.startTime.split(':').map(Number);
    const [endHour, endMinute] = data.endTime.split(':').map(Number);

    if (isNaN(startHour) || isNaN(startMinute) || isNaN(endHour) || isNaN(endMinute)) {
      throw new BadRequestError('Invalid time format. Use HH:MM');
    }

    const startTime = new Date(slotDate);
    startTime.setHours(startHour, startMinute, 0, 0);

    const endTime = new Date(slotDate);
    endTime.setHours(endHour, endMinute, 0, 0);

    // Validate time order
    if (startTime >= endTime) {
      throw new BadRequestError('Start time must be before end time');
    }

    // =====================================================
    // 4. Check if slot is in the past (✅ NOW WORKS)
    // =====================================================

    const now = nowAlgeria();
    if (isSlotInPastAlgeria(slotDate, startTime, now)) {
      throw new BadRequestError('Cannot create a slot in the past');
    }

    // =====================================================
    // 5. Validate against doctor's availability
    // =====================================================

    const dayOfWeek = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][slotDate.getUTCDay()];
    
    const availabilities = await doctorAvailabilityRepository.findByDoctorAndDay(doctorId, dayOfWeek);
    
    // Check if the slot falls within any availability window
    const isWithinAvailability = availabilities.some(avail => {
      if (!avail.isActive) return false;
      
      const availStart = new Date(slotDate);
      availStart.setHours(avail.startTime.getHours(), avail.startTime.getMinutes(), 0, 0);
      
      const availEnd = new Date(slotDate);
      availEnd.setHours(avail.endTime.getHours(), avail.endTime.getMinutes(), 0, 0);
      
      return startTime >= availStart && endTime <= availEnd;
    });

    if (!isWithinAvailability) {
      throw new BadRequestError(
        'Slot time is outside doctor\'s availability hours for this day'
      );
    }

    // =====================================================
    // 6. Validate against doctor's breaks
    // =====================================================

    const breaks = await doctorBreakRepository.findByDoctorAndDateRange(
      doctorId, 
      slotDate, 
      slotDate
    );

    const isDuringBreak = breaks.some(b => {
      if (b.isAllDay) return true;
      
      const breakStart = new Date(slotDate);
      breakStart.setHours(b.startTime!.getHours(), b.startTime!.getMinutes(), 0, 0);
      
      const breakEnd = new Date(slotDate);
      breakEnd.setHours(b.endTime!.getHours(), b.endTime!.getMinutes(), 0, 0);
      
      return startTime < breakEnd && endTime > breakStart;
    });

    if (isDuringBreak) {
      throw new BadRequestError('Slot overlaps with a break');
    }

    // =====================================================
    // 7. Check for duplicate slot
    // =====================================================

    const config = await this.getDoctorConfig(doctorId);
    const maxPerSlot = data.maxPatients || config?.maxPerSlot || 1;
    const clinicId = data.clinicId || (userRole === 'CLINIC' ? userId : undefined);

    // Check if a slot already exists at this exact time
    const existingSlot = await prisma.slot.findFirst({
      where: {
        doctorId,
        date: slotDate,
        startTime,
        clinicId: clinicId || null,
        roomId: data.roomId || null,
      },
    });

    if (existingSlot) {
      throw new ConflictError('A slot already exists at this time');
    }

    // =====================================================
    // 8. Create the slot
    // =====================================================

    const slot = await slotRepository.create({
      doctorId,
      clinicId: clinicId || undefined,
      roomId: data.roomId || undefined,
      date: slotDate,
      startTime,
      endTime,
      maxPatients: maxPerSlot,
    });

    // =====================================================
    // 9. Audit log
    // =====================================================

    eventEmitter.emit('audit', {
      action: 'slot.quick_added',
      entity: 'Slot',
      entityId: slot.id,
      performedBy: userId,
      details: {
        doctorId,
        date: data.date,
        startTime: data.startTime,
        endTime: data.endTime,
        isQuickSlot: true,
      },
    });

    // =====================================================
    // 10. Return enriched response
    // =====================================================

    return this.enrichSlotResponse(slot);
  }

  // ======================== SLOT AUTOMATION ========================

  /**
   * Enable automation for a doctor
   */
  async setupAutomation(
    doctorId: string,
    data: {
      frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY';
      bookingWindowDays: number;
      clinicId?: string;
      roomId?: string;
    }
  ): Promise<any> {
    // Validate doctor exists
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor || !doctor.isVerified || doctor.isSuspended) {
      throw new BadRequestError('Doctor not available');
    }

    // Validate clinic link if clinicId provided
    if (data.clinicId) {
      const link = await prisma.clinicDoctor.findFirst({
        where: {
          clinicId: data.clinicId,
          doctorId,
          status: 'ACCEPTED',
          isActive: true,
        },
      });
      if (!link) {
        throw new BadRequestError('Doctor is not affiliated with this clinic');
      }
    }

    // Validate room belongs to clinic if roomId provided
    if (data.roomId && data.clinicId) {
      const room = await prisma.clinicRoom.findFirst({
        where: {
          id: data.roomId,
          clinicId: data.clinicId,
        },
      });
      if (!room) {
        throw new BadRequestError('Room does not belong to this clinic');
      }
    }

    // Use the repository
    const rule = await slotRepository.upsertAutomationRule(doctorId, {
      frequency: data.frequency,
      bookingWindowDays: data.bookingWindowDays,
      clinicId: data.clinicId,
      roomId: data.roomId,
    });

    logger.info(`Slot automation enabled for doctor ${doctorId}: ${data.frequency}, booking window: ${data.bookingWindowDays} days`);

    return rule;
  }

  /**
   * Disable slot automation for a doctor
   */
  async disableAutomation(doctorId: string): Promise<void> {
    const rule = await slotRepository.getAutomationRule(doctorId);
    if (!rule) {
      throw new NotFoundError('No automation rule found for this doctor');
    }

    await slotRepository.disableAutomationRule(doctorId);
    logger.info(`Slot automation disabled for doctor ${doctorId}`);
  }

  /**
   * Get automation status for a doctor
   */
  async getAutomationStatus(doctorId: string): Promise<any | null> {
    return slotRepository.getAutomationRule(doctorId);
  }

  /**
   * Generate missing slots for automation
   * This is called by the worker
   */
  async generateAutomationSlots(
    doctorId: string,
    bookingWindowDays: number,
    clinicId?: string,
    roomId?: string
  ): Promise<{ created: number; existing: number; errors: number }> {
    // 1. Get the current booking horizon (SCOPED to clinic/room)
    const horizon = await slotRepository.getBookingHorizon(doctorId, clinicId, roomId);
    const now = nowAlgeria();
    const targetDate = new Date(now);
    targetDate.setDate(targetDate.getDate() + bookingWindowDays);

    // 2. If horizon is already beyond target, we're done
    if (horizon && horizon >= targetDate) {
      logger.info(`Horizon ${horizon.toISOString().slice(0, 10)} is already beyond target ${targetDate.toISOString().slice(0, 10)}, skipping`);
      return { created: 0, existing: 0, errors: 0 };
    }

    // 3. Calculate start date (day after horizon, or today)
    const startDate = horizon ? new Date(horizon) : new Date(now);
    startDate.setDate(startDate.getDate() + 1);
    startDate.setHours(0, 0, 0, 0);

    // 4. Get doctor config
    const config = await this.getDoctorConfig(doctorId);
    const slotDuration = config?.slotDuration || 30;
    const bufferTime = config?.bufferTime || 5;
    const maxPerSlot = config?.maxPerSlot || 1;

    // 5. Generate slots for the missing dates
    const slots: any[] = [];
    const currentDate = new Date(startDate);

    while (currentDate <= targetDate) {
      const dayOfWeek = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][currentDate.getUTCDay()];
      const availabilities = await doctorAvailabilityRepository.findByDoctorAndDay(doctorId, dayOfWeek);
      const breaks = await doctorBreakRepository.findByDoctorAndDateRange(doctorId, currentDate, currentDate);

      for (const avail of availabilities) {
        if (!avail.isActive) continue;

        const [startH, startM] = [avail.startTime.getUTCHours(), avail.startTime.getUTCMinutes()];
        const [endH, endM] = [avail.endTime.getUTCHours(), avail.endTime.getUTCMinutes()];

        let slotTime = new Date(currentDate);
        slotTime.setHours(startH, startM, 0, 0);
        const availEnd = new Date(currentDate);
        availEnd.setHours(endH, endM, 0, 0);

        while (slotTime.getTime() + slotDuration * 60000 <= availEnd.getTime()) {
          const slotEnd = new Date(slotTime.getTime() + slotDuration * 60000);

          const isBreak = breaks.some(b => {
            if (b.isAllDay) return true;
            const breakStart = new Date(currentDate);
            breakStart.setHours(b.startTime!.getHours(), b.startTime!.getMinutes(), 0, 0);
            const breakEnd = new Date(currentDate);
            breakEnd.setHours(b.endTime!.getHours(), b.endTime!.getMinutes(), 0, 0);
            return slotTime < breakEnd && slotEnd > breakStart;
          });

          if (!isBreak) {
            slots.push({
              doctorId,
              clinicId: clinicId || avail.clinicId,
              roomId: roomId || avail.roomId,
              date: new Date(currentDate),
              startTime: new Date(slotTime),
              endTime: new Date(slotEnd),
              maxPatients: maxPerSlot,
            });
          }
          slotTime = new Date(slotEnd.getTime() + bufferTime * 60000);
        }
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // 6. Save slots idempotently
    const result = await slotRepository.generateMissingSlots(doctorId, slots);

    logger.info(`Generated ${result.created} new slots for doctor ${doctorId} (${result.existing} already existed)`);

    return result;
  }

  // ============================================================
  // ✅ Trust points - integer only (UNCHANGED)
  // ============================================================

  private async updateTrustPoints(
    userId: string, 
    appointmentStatus: string, 
    cancelledAt?: Date, 
    slotDate?: Date,
    slotTime?: Date
  ) {
    let pointsChange = 0;

    if (appointmentStatus === 'COMPLETED') {
      pointsChange = 1;
    } else if (appointmentStatus === 'NO_SHOW') {
      pointsChange = -2;
    } else if (appointmentStatus === 'CANCELLED' && cancelledAt && slotDate) {
      const appointmentDateTime = getSlotStartDateTimeAlgeria(slotDate, slotTime || new Date());
      const now = nowAlgeria();
      const daysUntil = Math.ceil((appointmentDateTime.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      if (daysUntil < 3) {
        pointsChange = -1;
      }
    }

    if (pointsChange !== 0) {
      const user = await prisma.user.update({
        where: { id: userId },
        data: { trustPoints: { increment: pointsChange } },
      });

      const newLevel = this.calculateTrustLevel(user.trustPoints);
      await prisma.user.update({
        where: { id: userId },
        data: { trustLevel: newLevel },
      });

      const oldLevel = this.calculateTrustLevel(user.trustPoints - pointsChange);
      if (newLevel !== oldLevel) {
        const levelNames = ['Unreliable', 'New Patient', 'Trusted Patient', 'VIP Patient'];
        eventEmitter.emit('notification', {
          userId,
          title: '⭐ Trust Level Updated',
          body: `You are now a ${levelNames[newLevel]}!`,
          type: 'system',
          data: { trustLevel: newLevel, type: 'trust_level_change' },
        });
      }

      logger.info(`User ${userId} trust: ${pointsChange > 0 ? '+' : ''}${pointsChange} points, now level ${newLevel}`);
    }
  }

  private calculateTrustLevel(points: number): number {
    if (points < 0) return 0;
    if (points <= 2) return 1;
    if (points <= 9) return 2;
    return 3;
  }
}

export const appointmentService = new AppointmentService();

