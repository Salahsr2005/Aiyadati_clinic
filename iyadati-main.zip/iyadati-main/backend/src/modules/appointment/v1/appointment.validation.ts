import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

// ============================================================
// EXISTING SCHEMAS (Unchanged)
// ============================================================

const doctorConfigSchema = Joi.object({
  slotDuration: Joi.number().integer().min(5).max(120).required(),
  bufferTime: Joi.number().integer().min(0).max(60).required(),
  maxPerSlot: Joi.number().integer().min(1).max(20).default(1),
});

const generateSlotsSchema = Joi.object({
  startDate: Joi.date().iso().required(),
  endDate: Joi.date().iso().min(Joi.ref('startDate')).required(),
  clinicId: Joi.string().uuid().optional(),
  roomId: Joi.string().uuid().optional(),
  force: Joi.boolean().optional().default(false),
});

const cancelSlotsSchema = Joi.object({
  date: Joi.date().iso().required(),
  reason: Joi.string().max(500).optional(),
});

const updateStatusSchema = Joi.object({
  status: Joi.string().valid('CONFIRMED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'NO_SHOW').required(),
  cancelReason: Joi.string().max(500).optional(),
});

const confirmAppointmentSchema = Joi.object({
  notes: Joi.string().max(500).optional(),
});

// ============================================================
// GUEST PATIENT SCHEMA (NEW)
// ============================================================

const guestPatientSchema = Joi.object({
  firstName: Joi.string().required().max(100).messages({
    'string.empty': 'First name is required',
    'string.max': 'First name cannot exceed 100 characters',
  }),
  lastName: Joi.string().required().max(100).messages({
    'string.empty': 'Last name is required',
    'string.max': 'Last name cannot exceed 100 characters',
  }),
  phone: Joi.string().required().pattern(/^[0-9]{10,15}$/).messages({
    'string.empty': 'Phone number is required',
    'string.pattern.base': 'Phone number must be 10-15 digits',
  }),
  email: Joi.string().email().optional().allow(null, '').messages({
    'string.email': 'Invalid email format',
  }),
  dateOfBirth: Joi.date().iso().optional().allow(null).messages({
    'date.iso': 'Date of birth must be a valid ISO date (YYYY-MM-DD)',
  }),
  wilayaId: Joi.string().uuid().optional().allow(null),
  notes: Joi.string().max(500).optional().allow(null, ''),
});

// ============================================================
// BOOK APPOINTMENT SCHEMA (UPDATED)
// ============================================================

const bookAppointmentSchema = Joi.object({
  slotId: Joi.string().uuid().required().messages({
    'string.empty': 'Slot ID is required',
    'string.uuid': 'Invalid slot ID format',
  }),
  type: Joi.string().valid('IN_PERSON', 'VIDEO', 'HOME_VISIT').default('IN_PERSON'),
  paymentMethod: Joi.string().valid('CREDIT', 'ON_SITE').default('CREDIT'),
  
  // EITHER patientId OR guestPatient
  patientId: Joi.string().uuid().optional().messages({
    'string.uuid': 'Invalid patient ID format',
  }),
  guestPatient: guestPatientSchema.optional(),
  
  contactUserId: Joi.string().uuid().optional().allow(null),
  notes: Joi.string().max(500).optional().allow(null, ''),
})
.custom((value, helpers) => {
  // Exactly one of patientId or guestPatient must be provided
  const hasPatientId = !!value.patientId;
  const hasGuestPatient = !!value.guestPatient;
  
  if (!hasPatientId && !hasGuestPatient) {
    return helpers.error('any.required', {
      message: 'Either patientId or guestPatient must be provided',
    });
  }
  
  if (hasPatientId && hasGuestPatient) {
    return helpers.error('any.invalid', {
      message: 'Provide either patientId OR guestPatient, not both',
    });
  }
  
  return value;
})
.messages({
  'any.required': 'Either patientId or guestPatient must be provided',
  'any.invalid': 'Provide either patientId OR guestPatient, not both',
});

// ============================================================
// CLINIC BOOK SCHEMA (UPDATED - extends book schema)
// ============================================================

const clinicBookSchema = bookAppointmentSchema;

// ============================================================
// GUEST PATIENT MANAGEMENT SCHEMAS (NEW)
// ============================================================

const updateGuestPatientSchema = Joi.object({
  firstName: Joi.string().max(100).optional(),
  lastName: Joi.string().max(100).optional(),
  phone: Joi.string().pattern(/^[0-9]{10,15}$/).optional().messages({
    'string.pattern.base': 'Phone number must be 10-15 digits',
  }),
  email: Joi.string().email().optional().allow(null, ''),
  dateOfBirth: Joi.date().iso().optional().allow(null),
  wilayaId: Joi.string().uuid().optional().allow(null),
  notes: Joi.string().max(500).optional().allow(null, ''),
});

const guestPatientSearchSchema = Joi.object({
  query: Joi.string().required().min(1).messages({
    'string.empty': 'Search query is required',
  }),
});

// ============================================================
// VALIDATORS - EXPORT ALL
// ============================================================

export const validateDoctorConfig = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = doctorConfigSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateGenerateSlots = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = generateSlotsSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateBookAppointment = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = bookAppointmentSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateClinicBook = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = clinicBookSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateCancelSlots = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = cancelSlotsSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateUpdateStatus = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateStatusSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateConfirmAppointment = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = confirmAppointmentSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

// ============================================================
// NEW VALIDATORS - GUEST PATIENT MANAGEMENT
// ============================================================

export const validateGuestPatient = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = guestPatientSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateUpdateGuestPatient = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateGuestPatientSchema.validate(req.body, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};

export const validateGuestPatientSearch = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = guestPatientSearchSchema.validate(req.query, { abortEarly: false });
  if (error) { 
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); 
    ResponseUtil.validationError(res, 'Validation failed', errors); 
    return; 
  }
  next();
};


// Quick Slot validation
const quickSlotSchema = Joi.object({
  date: Joi.date().iso().required().messages({
    'date.iso': 'Date must be in YYYY-MM-DD format',
    'any.required': 'Date is required',
  }),
  startTime: Joi.string().pattern(/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/).required().messages({
    'string.pattern.base': 'Start time must be in HH:MM format (24h)',
    'any.required': 'Start time is required',
  }),
  endTime: Joi.string().pattern(/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/).required().messages({
    'string.pattern.base': 'End time must be in HH:MM format (24h)',
    'any.required': 'End time is required',
  }),
  clinicId: Joi.string().uuid().optional(),
  roomId: Joi.string().uuid().optional(),
  maxPatients: Joi.number().integer().min(1).max(20).optional(),
})
.custom((value, helpers) => {
  // Validate that startTime < endTime
  const [startHour, startMinute] = value.startTime.split(':').map(Number);
  const [endHour, endMinute] = value.endTime.split(':').map(Number);
  
  const startMinutes = startHour * 60 + startMinute;
  const endMinutes = endHour * 60 + endMinute;
  
  if (startMinutes >= endMinutes) {
    return helpers.error('any.invalid', {
      message: 'Start time must be before end time',
    });
  }
  
  return value;
});

// Export new validator
export const validateQuickSlot = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = quickSlotSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


// ============================================================
// SLOT AUTOMATION VALIDATION (UPDATED)
// ============================================================

const slotAutomationSchema = Joi.object({
  frequency: Joi.string().valid('DAILY', 'WEEKLY', 'MONTHLY').required().messages({
    'any.required': 'Frequency is required',
    'string.valid': 'Frequency must be DAILY, WEEKLY, or MONTHLY',
  }),
  bookingWindowDays: Joi.number().integer().min(1).max(365).default(30).messages({
    'number.min': 'Booking window must be at least 1 day',
    'number.max': 'Booking window cannot exceed 365 days',
  }),
  clinicId: Joi.string().uuid().optional(),
  roomId: Joi.string().uuid().optional(),
});

export const validateSlotAutomation = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = slotAutomationSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

