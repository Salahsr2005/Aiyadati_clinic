import { Request, Response, NextFunction } from 'express';
import { appointmentService } from './appointment.service';
import { guestPatientRepository } from '../../../repositories/guest-patient.repository'; // ✅ NEW
import { ResponseUtil } from '../../../core/utils/response';
import { NotFoundError } from '../../../core/utils/error';

export class AppointmentController {
  // ============================================================
  // CONFIG (UNCHANGED)
  // ============================================================

  getMyConfig = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const config = await appointmentService.getDoctorConfig(req.user!.id); 
      ResponseUtil.success(res, config, 'Config retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  setMyConfig = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const config = await appointmentService.setDoctorConfig(req.user!.id, req.body); 
      ResponseUtil.success(res, config, 'Config updated'); 
    } catch (error) { 
      next(error); 
    }
  };

  // ============================================================
  // SLOTS (UNCHANGED)
  // ============================================================

  getAvailableSlots = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const slots = await appointmentService.getAvailableSlots(req.params.doctorId, req.query.date as string); 
      ResponseUtil.success(res, slots, 'Slots retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  getSlots = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const slots = await appointmentService.getSlots(req.params.doctorId || req.user!.id, req.query.date as string); 
      ResponseUtil.success(res, slots, 'Slots retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  generateSlots = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const slots = await appointmentService.generateSlots(req.params.doctorId || req.user!.id, req.body, req.user!.id, req.user!.role); 
      ResponseUtil.created(res, slots, 'Slots generated'); 
    } catch (error) { 
      next(error); 
    }
  };

  cancelSlot = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      await appointmentService.cancelSlot(req.params.id, req.user!.id, req.user!.role); 
      ResponseUtil.success(res, null, 'Slot cancelled'); 
    } catch (error) { 
      next(error); 
    }
  };

  cancelSlotsByDate = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const count = await appointmentService.cancelSlotsByDate(req.params.doctorId || req.user!.id, req.body, req.user!.id, req.user!.role); 
      ResponseUtil.success(res, { cancelledCount: count }, 'Slots cancelled'); 
    } catch (error) { 
      next(error); 
    }
  };

  // ============================================================
  // APPOINTMENTS (UNCHANGED - guest support is in service)
  // ============================================================

  bookAppointment = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const a = await appointmentService.bookAppointment(req.body, req.user!.id, req.user!.role); 
      ResponseUtil.created(res, a, 'Appointment requested'); 
    } catch (error) { 
      next(error); 
    }
  };

  clinicBook = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const a = await appointmentService.clinicBookAppointment(req.body, req.user!.id); 
      ResponseUtil.created(res, a, 'Appointment requested'); 
    } catch (error) { 
      next(error); 
    }
  };

  confirmAppointment = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const a = await appointmentService.confirmAppointment(
        req.params.id, 
        req.user!.id, 
        req.user!.role,
        req.body
      ); 
      ResponseUtil.success(res, a, 'Appointment confirmed'); 
    } catch (error) { 
      next(error); 
    }
  };

  getMyAppointments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const { appointments, total } = await appointmentService.getMyAppointments(
        req.user!.id, 
        parseInt(req.query.page as string) || 1, 
        parseInt(req.query.limit as string) || 10
      ); 
      ResponseUtil.paginated(res, appointments, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Appointments retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  getDoctorAppointments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const { appointments, total } = await appointmentService.getDoctorAppointments(
        req.user!.id, 
        parseInt(req.query.page as string) || 1, 
        parseInt(req.query.limit as string) || 10, 
        req.query.date as string
      ); 
      ResponseUtil.paginated(res, appointments, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Appointments retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  getClinicAppointments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const { appointments, total } = await appointmentService.getClinicAppointments(
        req.user!.id, 
        parseInt(req.query.page as string) || 1, 
        parseInt(req.query.limit as string) || 10, 
        req.query.date as string
      ); 
      ResponseUtil.paginated(res, appointments, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Appointments retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  getAllAppointments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const { appointments, total } = await appointmentService.getAllAppointments(
        parseInt(req.query.page as string) || 1, 
        parseInt(req.query.limit as string) || 20, 
        req.query
      ); 
      ResponseUtil.paginated(res, appointments, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 20, 'Appointments retrieved'); 
    } catch (error) { 
      next(error); 
    }
  };

  updateStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { 
      const a = await appointmentService.updateStatus(req.params.id, req.body, req.user!.id, req.user!.role); 
      ResponseUtil.success(res, a, 'Status updated'); 
    } catch (error) { 
      next(error); 
    }
  };

  // ============================================================
  // 🆕 GUEST PATIENT MANAGEMENT (OPTIONAL ENDPOINTS)
  // ============================================================

  /**
   * Get guest patients created by the authenticated user
   */
  getMyGuestPatients = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const { guests, total } = await guestPatientRepository.findByCreator(req.user!.id, page, limit);
      ResponseUtil.paginated(res, guests, total, page, limit, 'Guest patients retrieved');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Search guest patients by name or phone
   */
  searchGuestPatients = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const query = req.query.q as string;
      if (!query || query.length < 2) {
        // ✅ FIXED: Return the Response to avoid type error
        ResponseUtil.validationError(res, 'Search query must be at least 2 characters');
        return;
      }
      const guests = await guestPatientRepository.search(query, req.user!.id);
      ResponseUtil.success(res, guests, 'Guest patients found');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get a specific guest patient by ID
   */
  getGuestPatient = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const guest = await guestPatientRepository.findById(req.params.id);
      if (!guest) {
        throw new NotFoundError('Guest patient not found');
      }
      // Only allow access if created by this user (security)
      if (guest.createdBy !== req.user!.id) {
        throw new NotFoundError('Guest patient not found');
      }
      ResponseUtil.success(res, guest, 'Guest patient retrieved');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Update a guest patient
   */
  updateGuestPatient = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const guest = await guestPatientRepository.findById(req.params.id);
      if (!guest) {
        throw new NotFoundError('Guest patient not found');
      }
      // Only allow update if created by this user (security)
      if (guest.createdBy !== req.user!.id) {
        throw new NotFoundError('Guest patient not found');
      }
      
      const updated = await guestPatientRepository.update(req.params.id, req.body);
      ResponseUtil.success(res, updated, 'Guest patient updated');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Create a guest patient independently (without booking)
   */
  createGuestPatient = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const guest = await guestPatientRepository.create({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone,
        email: req.body.email,
        dateOfBirth: req.body.dateOfBirth ? new Date(req.body.dateOfBirth) : undefined,
        wilayaId: req.body.wilayaId,
        createdBy: req.user!.id,
        createdByType: req.user!.role as 'DOCTOR' | 'CLINIC',
        notes: req.body.notes,
      });
      ResponseUtil.created(res, guest, 'Guest patient created');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Add a single quick slot (Doctor or Clinic)
   * Creates one slot without deleting existing ones
   */
  addQuickSlot = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const slot = await appointmentService.addQuickSlot(
        req.params.doctorId || req.user!.id,
        req.body,
        req.user!.id,
        req.user!.role
      );
      ResponseUtil.created(res, slot, 'Quick slot added successfully');
    } catch (error) {
      next(error);
    }
  };


  // ============================================================
  // SLOT AUTOMATION
  // ============================================================

  /**
   * Enable slot automation
   */
  enableAutomation = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rule = await appointmentService.setupAutomation(req.user!.id, req.body);
      ResponseUtil.success(res, rule, 'Slot automation enabled');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Disable slot automation
   */
  disableAutomation = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await appointmentService.disableAutomation(req.user!.id);
      ResponseUtil.success(res, null, 'Slot automation disabled');
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get automation status
   */
  getAutomation = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rule = await appointmentService.getAutomationStatus(req.user!.id);
      ResponseUtil.success(res, rule, 'Automation status retrieved');
    } catch (error) {
      next(error);
    }
  };

}

