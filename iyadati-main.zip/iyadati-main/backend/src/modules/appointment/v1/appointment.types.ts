// ============================================================
// GUEST PATIENT DTO (NEW)
// ============================================================

export interface GuestPatientDTO {
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
  dateOfBirth?: string; // YYYY-MM-DD
  wilayaId?: string;
  notes?: string;
}

// ============================================================
// EXISTING DTOS (UPDATED)
// ============================================================

export interface DoctorConfigDTO {
  slotDuration: number;
  bufferTime: number;
  maxPerSlot?: number;
}

export interface DoctorConfigResponse {
  id: string;
  doctorId: string;
  slotDuration: number;
  bufferTime: number;
  maxPerSlot: number;
}

export interface GenerateSlotsDTO {
  startDate: string;  // YYYY-MM-DD
  endDate: string;    // YYYY-MM-DD
  clinicId?: string;
  roomId?: string;
  force?: boolean;
}

export interface SlotResponse {
  id: string;
  doctorId: string;
  clinicId: string | null;
  roomId: string | null;
  date: string;
  startTime: string;
  endTime: string;
  status: string; // 'available' | 'full' | 'cancelled' | 'expired'
  maxPatients: number;
  currentPatients: number;
}

// ============================================================
// BOOK APPOINTMENT DTO (UPDATED - Supports both patient types)
// ============================================================

export interface BookAppointmentDTO {
  slotId: string;
  type?: 'IN_PERSON' | 'VIDEO' | 'HOME_VISIT';
  paymentMethod?: 'CREDIT' | 'ON_SITE';
  
  // EITHER: registered patient
  patientId?: string;
  
  // OR: guest patient data
  guestPatient?: GuestPatientDTO;
  
  contactUserId?: string;
  notes?: string;
}

// ============================================================
// CLINIC BOOK DTO (UPDATED - patientId is now optional)
// ============================================================

export interface ClinicBookDTO extends BookAppointmentDTO {
  // patientId is now optional (can be guest)
  // guestPatient can be provided instead
}

export interface CancelSlotsDTO {
  date: string;
  reason?: string;
}

export interface UpdateStatusDTO {
  status: 'CONFIRMED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
  cancelReason?: string;
}

export interface ConfirmAppointmentDTO {
  notes?: string;
}

// ============================================================
// APPOINTMENT RESPONSE (UPDATED - Supports both patient types)
// ============================================================

export interface AppointmentResponse {
  id: string;
  slotId: string;
  slot?: SlotResponse;
  doctorId: string;
  doctor?: { id: string; firstNameFr: string; lastNameFr: string; photoUrl: string | null };
  
  // UPDATED: Patient can be registered OR guest
  patientId: string | null;
  patient?: { 
    id: string; 
    firstName: string; 
    lastName: string; 
    phone: string;
    isGuest: false;
  } | null;
  
  guestPatientId: string | null;
  guestPatient?: {
    id: string;
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
    isGuest: true;
  } | null;
  
  patientType: 'REGISTERED' | 'GUEST';
  
  contactUserId: string | null;
  contactUser?: { id: string; firstName: string; lastName: string } | null;
  clinicId: string | null;
  clinic?: { id: string; nameFr: string } | null;
  type: string;
  paymentMethod: string;
  status: string;
  notes: string | null;
  createdBy: string;
  createdByType: string;
  confirmedAt: string | null;
  confirmedBy: string | null;
  cancelledAt: string | null;
  cancelledBy: string | null;
  cancelReason: string | null;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// GUEST PATIENT RESPONSE (For guest management endpoints)
// ============================================================

export interface GuestPatientResponse {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
  dateOfBirth?: string;
  wilayaId?: string;
  wilaya?: {
    id: string;
    nameFr: string;
    nameAr: string;
  };
  createdBy: string;
  createdByType: 'DOCTOR' | 'CLINIC';
  convertedToUserId?: string;
  convertedAt?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  appointmentCount?: number;
}

// ============================================================
// GUEST PATIENT SEARCH DTO
// ============================================================

export interface GuestPatientSearchDTO {
  query: string;
  createdBy?: string;
}


export interface QuickSlotDTO {
  date: string;           // YYYY-MM-DD
  startTime: string;      // HH:MM (24h format)
  endTime: string;        // HH:MM (24h format)
  clinicId?: string;
  roomId?: string;
  maxPatients?: number;
}


// ============================================================
// SLOT AUTOMATION TYPES
// ============================================================

export enum SlotGenerationFrequency {
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  MONTHLY = 'MONTHLY',
}

export interface SlotAutomationDTO {
  frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY';
  bookingWindowDays: number;
  clinicId?: string;
  roomId?: string;
}

export interface SlotAutomationResponse {
  id: string;
  doctorId: string;
  frequency: string;
  bookingWindowDays: number;
  enabled: boolean;
  clinicId?: string;
  roomId?: string;
  lastRunAt?: string;
  nextRunAt: string;
  errorCount: number;
  lastError?: string;
  createdAt: string;
  updatedAt: string;
}

