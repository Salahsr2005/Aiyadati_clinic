One thing I would improve even further

There is one tiny improvement I'd still make if this were my code.

Right now you do:

Deduct wallet
↓
Create appointment

If, for any reason, appointment.create() fails (duplicate constraint, database error, etc.), the transaction rolls back, so the wallet deduction also rolls back. Functionally this is perfectly correct.

However, I usually prefer this order:

Lock slot
↓

Validate slot

↓

Validate doctor

↓

Create appointment

↓

Update slot status

↓

Atomic wallet deduction

↓

Credit transaction

Why?

Because the expensive operation (wallet update) is postponed until after the appointment has been successfully inserted. Since everything is inside the same database transaction, a later failure still rolls back everything, but the intent of the code reads more naturally: reserve the appointment first, then charge for it.

It's a small design preference rather than a correctness issue. From a concurrency standpoint, your slot lock is doing the heavy lifting, and the atomic wallet update is already the right solution.