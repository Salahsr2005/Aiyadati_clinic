Step 1: First Appointment (Simple)
text
┌─────────────────────────────────────────────────────────┐
│  📋 Dr. Ahmed would like to access your medical        │
│     records for your upcoming appointment.             │
│                                                         │
│  Choose what to share:                                 │
│                                                         │
│  ● Share everything (recommended)                     │
│     Dr. Ahmed will see all your medical history       │
│                                                         │
│  ○ Share only what's relevant                         │
│     Dr. Ahmed will only see documents related        │
│     to this appointment                               │
│                                                         │
│  ○ Let me choose what to share                        │
│     You'll manually select documents                  │
│                                                         │
│  ○ Don't share anything                               │
│     (May affect quality of care)                      │
│                                                         │
│  [Continue]  [Ask me later]                            │
└─────────────────────────────────────────────────────────┘
Step 2: If "Let me choose"
text
┌─────────────────────────────────────────────────────────┐
│  📄 Select documents to share with Dr. Ahmed           │
│                                                         │
│  ☑️ Blood Test Results (2026-07-15)                    │
│  ☑️ X-Ray (2026-06-22)                                │
│  ☐  MRI Scan (2026-05-10)                             │
│  ☐  Prescription History                              │
│  ☐  Allergy Test (2026-04-01)                         │
│                                                         │
│  [Share 2 Documents]                                   │
└─────────────────────────────────────────────────────────┘
Step 3: Doctor Requests (Simple)
text
┌─────────────────────────────────────────────────────────┐
│  📋 Dr. Ahmed is requesting access to:                 │
│                                                         │
│  • MRI Scan (2026-05-10)                              │
│  • Prescription History                               │
│                                                         │
│  Reason: "Need these for treatment planning"          │
│                                                         │
│  [Approve All]  [Approve Some]  [Deny]                │
└─────────────────────────────────────────────────────────┘
