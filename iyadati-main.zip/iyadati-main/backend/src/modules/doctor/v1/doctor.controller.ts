// src/modules/doctor/doctor.controller.ts

import { Request, Response, NextFunction } from 'express';
import { doctorService } from './doctor.service';
import { ResponseUtil } from '../../../core/utils/response';

export class DoctorController {
  // Staff
  findAll = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctors, total } = await doctorService.findAll(req.query);
      ResponseUtil.paginated(res, doctors, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Doctors retrieved successfully');
    } catch (error) { next(error); }
  };

  findById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.findById(req.params.id);
      ResponseUtil.success(res, doctor, 'Doctor retrieved successfully');
    } catch (error) { next(error); }
  };

  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.update(req.params.id, req.body);
      ResponseUtil.success(res, doctor, 'Doctor updated successfully');
    } catch (error) { next(error); }
  };

  verify = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.verify(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, doctor, 'Doctor verified successfully');
    } catch (error) { next(error); }
  };

  reject = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.reject(req.params.id, req.body, req.user!.id, req.ip);
      ResponseUtil.success(res, doctor, 'Doctor rejected');
    } catch (error) { next(error); }
  };

  suspend = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.suspend(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, doctor, 'Doctor suspended successfully');
    } catch (error) { next(error); }
  };

  unsuspend = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.unsuspend(req.params.id, req.user!.id, req.ip);
      ResponseUtil.success(res, doctor, 'Doctor unsuspended successfully');
    } catch (error) { next(error); }
  };

  getDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const documents = await doctorService.getDocuments(req.params.id);
      ResponseUtil.success(res, documents, 'Documents retrieved successfully');
    } catch (error) { next(error); }
  };

  // Self-service
  getMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.findById(req.user!.id);
      ResponseUtil.success(res, doctor, 'Profile retrieved successfully');
    } catch (error) { next(error); }
  };

  // ✅ UPDATED: Pass the full file object to service
  completeMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const photoFile = req.file || undefined;
      const doctor = await doctorService.completeProfile(req.user!.id, req.body, photoFile);
      ResponseUtil.success(res, doctor, 'Profile completed successfully');
    } catch (error) { next(error); }
  };

  uploadMyDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Document file is required'); return; }
      const docType = (req.body as any).docType || 'other';
      const doc = await doctorService.uploadDocument(req.user!.id, req.file, docType);
      ResponseUtil.created(res, doc, 'Document uploaded successfully');
    } catch (error) { next(error); }
  };

  getMyDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const documents = await doctorService.getDocuments(req.user!.id);
      ResponseUtil.success(res, documents, 'Documents retrieved successfully');
    } catch (error) { next(error); }
  };

  deleteMyDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await doctorService.deleteDocument(
        req.params.id, 
        req.user!.id, 
        req.user!.role
      );
      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) { next(error); }
  };


  requestToJoinClinic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await doctorService.requestToJoinClinic(req.user!.id, req.body.clinicId);
      ResponseUtil.created(res, result, 'Request sent to clinic');
    } catch (error) { next(error); }
  };

  getMyInvitations = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const invitations = await doctorService.getMyInvitations(req.user!.id);
      ResponseUtil.success(res, invitations, 'Invitations retrieved successfully');
    } catch (error) { next(error); }
  };

  respondToInvitation = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const action = req.params.action === 'accept' ? 'ACCEPTED' : 'REJECTED';
      const result = await doctorService.respondToClinicInvitation(req.params.id, req.user!.id, action);
      ResponseUtil.success(res, result, `Invitation ${action === 'ACCEPTED' ? 'accepted' : 'rejected'}`);
    } catch (error) { next(error); }
  };

  getMyAvailability = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const slots = await doctorService.getMyAvailability(req.user!.id);
      ResponseUtil.success(res, slots, 'Availability retrieved successfully');
    } catch (error) { next(error); }
  };

  setMyAvailability = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const slots = await doctorService.setMyAvailability(req.user!.id, req.body);
      ResponseUtil.success(res, slots, 'Availability updated successfully');
    } catch (error) { next(error); }
  };

  deleteAvailabilitySlot = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await doctorService.deleteAvailabilitySlot(req.params.id, req.user!.id);
      ResponseUtil.success(res, null, 'Availability slot removed');
    } catch (error) { next(error); }
  };

  getDoctorAvailability = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const slots = await doctorService.getDoctorAvailability(req.params.id);
      ResponseUtil.success(res, slots, 'Doctor availability retrieved');
    } catch (error) { next(error); }
  };

  getMyBreaks = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const breaks = await doctorService.getMyBreaks(req.user!.id);
      ResponseUtil.success(res, breaks, 'Breaks retrieved successfully');
    } catch (error) { next(error); }
  };

  createBreak = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const b = await doctorService.createBreak(req.user!.id, req.body);
      ResponseUtil.created(res, b, 'Break created successfully');
    } catch (error) { next(error); }
  };

  updateBreak = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const b = await doctorService.updateBreak(req.user!.id, req.params.id, req.body);
      ResponseUtil.success(res, b, 'Break updated successfully');
    } catch (error) { next(error); }
  };

  deleteBreak = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await doctorService.deleteBreak(req.user!.id, req.params.id);
      ResponseUtil.success(res, null, 'Break deleted successfully');
    } catch (error) { next(error); }
  };

  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.createDoctor(req.body, req.user!.id, req.ip);
      ResponseUtil.created(res, doctor, 'Doctor created successfully');
    } catch (error) { next(error); }
  };

  uploadDocumentForDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) {
        ResponseUtil.badRequest(res, 'Document file is required');
        return;
      }
      const docType = (req.body as any).docType || 'other';
      const doc = await doctorService.uploadDocumentForDoctor(
        req.params.id,
        req.file,
        docType,
        req.user!.id,
        req.ip
      );
      ResponseUtil.created(res, doc, 'Document uploaded successfully');
    } catch (error) {
      next(error);
    }
  };

  deleteDoctorDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await doctorService.deleteDoctorDocument(
        req.params.id,
        req.params.documentId,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) {
      next(error);
    }
  };

  // Add new controller method
  createComplete = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const file = req.file || undefined;
      const doctor = await doctorService.createCompleteDoctor(
        req.body,
        file,
        req.user!.id,
        req.ip
      );
      ResponseUtil.created(res, doctor, 'Doctor created successfully');
    } catch (error) {
      next(error);
    }
  };

  // NEW: Update booking availability
  updateBookingAvailability = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await doctorService.updateBookingAvailability(
        req.params.id,
        req.body,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, doctor, 'Booking availability updated successfully');
    } catch (error) {
      next(error);
    }
  };
}

