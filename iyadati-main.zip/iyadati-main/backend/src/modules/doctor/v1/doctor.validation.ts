import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const completeDoctorSchema = Joi.object({
  bioFr: Joi.string().max(1000).optional().allow(null, ''),
  bioAr: Joi.string().max(1000).optional().allow(null, ''),
  yearsOfExp: Joi.number().integer().min(0).max(60).optional(),
  practiceType: Joi.string().valid('INDEPENDENT', 'CLINIC_BASED', 'BOTH').optional(),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
  // Accept both array and comma-separated string
  specialtyIds: Joi.alternatives().try(
    Joi.array().items(Joi.string().uuid()).min(1),
    Joi.string().pattern(/^[0-9a-fA-F-]+(,[0-9a-fA-F-]+)*$/)
  ).optional(),
});

const updateDoctorSchema = Joi.object({
  // Basic info
  firstNameFr: Joi.string().min(2).max(50).optional(),
  firstNameAr: Joi.string().min(2).max(50).optional(),
  lastNameFr: Joi.string().min(2).max(50).optional(),
  lastNameAr: Joi.string().min(2).max(50).optional(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).optional(),
  email: Joi.string().email().optional(),
  wilayaId: Joi.string().uuid().optional(),
  baladyaId: Joi.string().uuid().optional().allow(null),
  
  // Profile details
  bioFr: Joi.string().max(1000).optional().allow(null),
  bioAr: Joi.string().max(1000).optional().allow(null),
  yearsOfExp: Joi.number().integer().min(0).max(60).optional().allow(null),
  practiceType: Joi.string().valid('INDEPENDENT', 'CLINIC_BASED', 'BOTH').optional(),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
  
  // Status fields (admin only)
  isVerified: Joi.boolean().optional(),
  isSuspended: Joi.boolean().optional(),
  isCompleted: Joi.boolean().optional(),
  isRegistered: Joi.boolean().optional(),
  rejectionReason: Joi.string().max(500).optional().allow(null),
  
  // Specialties - accept array or comma-separated string
  specialtyIds: Joi.alternatives().try(
    Joi.array().items(Joi.string().uuid()),
    Joi.string().pattern(/^[0-9a-fA-F-]+(,[0-9a-fA-F-]+)*$/)
  ).optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

const rejectDoctorSchema = Joi.object({
  reason: Joi.string().min(3).max(500).required().messages({
    'string.min': 'Reason must be at least 3 characters',
    'string.max': 'Reason must be less than 500 characters',
    'any.required': 'Rejection reason is required',
  }),
});

// NEW: Update booking availability validation schema
const updateBookingAvailabilitySchema = Joi.object({
  isAvailableForBooking: Joi.boolean().required().messages({
    'any.required': 'isAvailableForBooking is required',
  }),
  messageForUser: Joi.string().max(500).optional().allow(null, '').messages({
    'string.max': 'Message must be less than 500 characters',
  }),
});

export const validateCompleteDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = completeDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateRejectDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = rejectDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// NEW: Validate update booking availability
export const validateUpdateBookingAvailability = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateBookingAvailabilitySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

const requestClinicSchema = Joi.object({
  clinicId: Joi.string().uuid().required().messages({
    'string.uuid': 'Valid clinic ID is required',
    'any.required': 'Clinic ID is required',
  }),
});

export const validateRequestClinic = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = requestClinicSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


const availabilitySlotSchema = Joi.object({
  dayOfWeek: Joi.string().valid('SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY').required(),
  startTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).required().messages({
    'string.pattern.base': 'startTime must be in HH:mm format',
  }),
  endTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).required().messages({
    'string.pattern.base': 'endTime must be in HH:mm format',
  }),
  clinicId: Joi.string().uuid().optional().allow(null),
  roomId: Joi.string().uuid().optional().allow(null),
});

const setAvailabilitySchema = Joi.object({
  slots: Joi.array().items(availabilitySlotSchema).min(1).required().messages({
    'array.min': 'At least one time slot is required',
  }),
});

export const validateSetAvailability = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = setAvailabilitySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


const createBreakSchema = Joi.object({
  startDate: Joi.date().iso().required().messages({
    'date.format': 'startDate must be in YYYY-MM-DD format',
    'any.required': 'Start date is required',
  }),
  endDate: Joi.date().iso().min(Joi.ref('startDate')).required().messages({
    'date.format': 'endDate must be in YYYY-MM-DD format',
    'date.min': 'endDate must be after startDate',
    'any.required': 'End date is required',
  }),
  reason: Joi.string().max(200).optional(),
  isAllDay: Joi.boolean().default(true),
  startTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().messages({
    'string.pattern.base': 'startTime must be in HH:mm format',
  }),
  endTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().messages({
    'string.pattern.base': 'endTime must be in HH:mm format',
  }),
});

const updateBreakSchema = Joi.object({
  startDate: Joi.date().iso().optional(),
  endDate: Joi.date().iso().optional(),
  reason: Joi.string().max(200).optional().allow(null, ''),
  isAllDay: Joi.boolean().optional(),
  startTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().allow(null),
  endTime: Joi.string().pattern(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().allow(null),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateBreak = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createBreakSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateBreak = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateBreakSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};


const createDoctorSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(100).required(),
  firstNameFr: Joi.string().min(2).max(50).required(),
  firstNameAr: Joi.string().min(2).max(50).required(),
  lastNameFr: Joi.string().min(2).max(50).required(),
  lastNameAr: Joi.string().min(2).max(50).required(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required(),
  wilayaId: Joi.string().uuid().required(),
  specialtyIds: Joi.array().items(Joi.string().uuid()).optional(),
});

export const validateCreateDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

const createCompleteDoctorSchema = Joi.object({
  // Required basic info
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(100).required(),
  firstNameFr: Joi.string().min(2).max(50).required(),
  firstNameAr: Joi.string().min(2).max(50).required(),
  lastNameFr: Joi.string().min(2).max(50).required(),
  lastNameAr: Joi.string().min(2).max(50).required(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required(),
  wilayaId: Joi.string().uuid().required(),
  
  // ✅ Updated: Accept both array AND string formats
  specialtyIds: Joi.alternatives()
    .try(
      Joi.array().items(Joi.string().uuid()).min(1),
      Joi.string().custom((value, helpers) => {
        try {
          // Try to parse as JSON array
          const parsed = JSON.parse(value);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
          return helpers.error('any.invalid');
        } catch {
          // If not JSON, treat as comma-separated
          const ids = value.split(',').map((id: string) => id.trim()).filter(Boolean);
          if (ids.length > 0) {
            return ids;
          }
          return helpers.error('any.invalid');
        }
      })
    )
    .required()
    .messages({
      'any.required': 'Specialties are required',
      'alternatives.match': 'Specialties must be an array of UUIDs or a comma-separated string'
    }),
  
  // Optional profile fields
  bioFr: Joi.string().max(1000).optional().allow(null, ''),
  bioAr: Joi.string().max(1000).optional().allow(null, ''),
  yearsOfExp: Joi.number().integer().min(0).max(60).optional(),
  practiceType: Joi.string().valid('INDEPENDENT', 'CLINIC_BASED', 'BOTH').optional(),
  latitude: Joi.number().min(-90).max(90).optional().allow(null),
  longitude: Joi.number().min(-180).max(180).optional().allow(null),
  baladyaId: Joi.string().uuid().optional().allow(null, ''),
});

export const validateCreateCompleteDoctor = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createCompleteDoctorSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

