/**
 * @swagger
 * tags:
 *   name: Doctor
 *   description: Doctor management endpoints (Staff and Doctor self-service)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     DoctorResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         email:
 *           type: string
 *           example: "doctor@example.com"
 *         firstNameFr:
 *           type: string
 *           example: "Mohamed"
 *         firstNameAr:
 *           type: string
 *           example: "محمد"
 *         lastNameFr:
 *           type: string
 *           example: "Benali"
 *         lastNameAr:
 *           type: string
 *           example: "بن علي"
 *         phone:
 *           type: string
 *           example: "0665123456"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *         wilaya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             code:
 *               type: integer
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         baladyaId:
 *           type: string
 *           nullable: true
 *         baladya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         bioFr:
 *           type: string
 *           nullable: true
 *           example: "Médecin cardiologue avec 15 ans d'expérience"
 *         bioAr:
 *           type: string
 *           nullable: true
 *           example: "طبيب قلب مع 15 سنة من الخبرة"
 *         photoPath:
 *           type: string
 *           nullable: true
 *         photoUrl:
 *           type: string
 *           nullable: true
 *           description: |
 *             Secure public URL for profile photo.
 *             Uses fileId (UUID) instead of exposing the file path.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         photoFileId:
 *           type: string
 *           nullable: true
 *         yearsOfExp:
 *           type: integer
 *           nullable: true
 *           example: 15
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *           example: "BOTH"
 *         latitude:
 *           type: number
 *           nullable: true
 *         longitude:
 *           type: number
 *           nullable: true
 *         specialties:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               nameFr:
 *                 type: string
 *               nameAr:
 *                 type: string
 *         isVerified:
 *           type: boolean
 *           example: false
 *         isSuspended:
 *           type: boolean
 *           example: false
 *         isRegistered:
 *           type: boolean
 *           example: true
 *           description: Whether the doctor registered themselves (true) or was created by staff (false)
 *         rejectionReason:
 *           type: string
 *           nullable: true
 *         isCompleted:
 *           type: boolean
 *           example: false
 *         # NEW: Booking availability fields
 *         isAvailableForBooking:
 *           type: boolean
 *           example: true
 *           description: Whether the doctor is accepting bookings
 *         messageForUser:
 *           type: string
 *           nullable: true
 *           example: "Available from September 2026"
 *           description: Custom message shown to patients about availability
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time

 *     DoctorDocumentResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         fileName:
 *           type: string
 *           example: "medical_degree.pdf"
 *         fileType:
 *           type: string
 *           example: "application/pdf"
 *         fileSize:
 *           type: integer
 *           example: 2048000
 *         docType:
 *           type: string
 *           enum: [degree, license, id_card, other, cv, certificate]
 *           example: "degree"
 *         accessUrl:
 *           type: string
 *           description: |
 *             Signed URL for document access (expires in 30 minutes).
 *             The URL uses a secure UUID (fileId) instead of exposing the file path.
 *             Format: /api/v1/files/private/{fileId}?expires={timestamp}&signature={hash}
 *           example: "http://localhost:3975/api/v1/files/private/550e8400-e29b-41d4-a716-446655440000?expires=1784569353394&signature=44da603063166cc17ad803c8c7b575ae1b273df0fe4532fafc8bc38bdc4c6a56"
 *         uploadedAt:
 *           type: string
 *           format: date-time

 *     CompleteDoctorRequest:
 *       type: object
 *       properties:
 *         bioFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         bioAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *         yearsOfExp:
 *           type: integer
 *           minimum: 0
 *           maximum: 60
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *         latitude:
 *           type: number
 *           nullable: true
 *         longitude:
 *           type: number
 *           nullable: true
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         specialtyIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         logo:
 *           type: string
 *           format: binary
 *           description: |
 *             Profile photo (JPEG, PNG, WebP, SVG - max 2MB).
 *             File will be stored with a secure UUID and accessible via /api/v1/files/public/{fileId}

 *     UpdateDoctorRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         firstNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "Mohamed"
 *         firstNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "محمد"
 *         lastNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "Benali"
 *         lastNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "بن علي"
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           example: "0665123456"
 *         email:
 *           type: string
 *           format: email
 *           example: "doctor@example.com"
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           example: "660e8400-e29b-41d4-a716-446655440000"
 *         bioFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           example: "Médecin cardiologue avec 15 ans d'expérience"
 *         bioAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           example: "طبيب قلب مع 15 سنة من الخبرة"
 *         yearsOfExp:
 *           type: integer
 *           minimum: 0
 *           maximum: 60
 *           nullable: true
 *           example: 15
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *           example: "BOTH"
 *         latitude:
 *           type: number
 *           minimum: -90
 *           maximum: 90
 *           nullable: true
 *           example: 36.7538
 *         longitude:
 *           type: number
 *           minimum: -180
 *           maximum: 180
 *           nullable: true
 *           example: 3.0588
 *         isVerified:
 *           type: boolean
 *           example: true
 *           description: "Admin only - verify/unverify doctor"
 *         isSuspended:
 *           type: boolean
 *           example: false
 *           description: "Admin only - suspend/unsuspend doctor"
 *         isCompleted:
 *           type: boolean
 *           example: true
 *           description: "Admin only - mark profile as complete/incomplete"
 *         isRegistered:
 *           type: boolean
 *           example: true
 *           description: "Admin only - mark as self-registered or staff-created"
 *         rejectionReason:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "Documents are unclear. Please re-upload."
 *           description: "Admin only - reason for rejection"
 *         specialtyIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           example: ["specialty-1-uuid", "specialty-2-uuid"]
 *           description: "Replace all specialties. Send empty array to remove all."
 *       description: |
 *         All fields are optional. At least one field must be provided.
 *         Admin can update ANY field including status fields.
 *         If updating specialties, all existing specialties will be replaced.

 *     RejectDoctorRequest:
 *       type: object
 *       required:
 *         - reason
 *       properties:
 *         reason:
 *           type: string
 *           minLength: 3
 *           maxLength: 500
 *           example: "Documents are unclear. Please re-upload."

 *     CreateDoctorRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstNameFr
 *         - firstNameAr
 *         - lastNameFr
 *         - lastNameAr
 *         - phone
 *         - wilayaId
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *         firstNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         firstNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         lastNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         lastNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *         wilayaId:
 *           type: string
 *           format: uuid
 *         specialtyIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid

 *     CreateCompleteDoctorRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - firstNameFr
 *         - firstNameAr
 *         - lastNameFr
 *         - lastNameAr
 *         - phone
 *         - wilayaId
 *         - specialtyIds
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           example: "dr.complete@iyadati.dz"
 *           description: Doctor's email address (must be unique)
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           maxLength: 100
 *           example: "doctor123456"
 *           description: Minimum 6 characters
 *         firstNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "Karim"
 *           description: First name in French
 *         firstNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "كريم"
 *           description: First name in Arabic
 *         lastNameFr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "Touati"
 *           description: Last name in French
 *         lastNameAr:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "تواتي"
 *           description: Last name in Arabic
 *         phone:
 *           type: string
 *           pattern: '^[0-9]{10}$'
 *           example: "0665999999"
 *           description: Phone number (10 digits, must be unique)
 *         wilayaId:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *           description: Wilaya ID where doctor is located
 *         specialtyIds:
 *           type: array
 *           minItems: 1
 *           items:
 *             type: string
 *             format: uuid
 *           example: ["specialty-1-uuid", "specialty-2-uuid"]
 *           description: At least one specialty is required
 *         bioFr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           example: "Cardiologue expert avec 15 ans d'expérience"
 *           description: Biography in French (optional)
 *         bioAr:
 *           type: string
 *           maxLength: 1000
 *           nullable: true
 *           example: "طبيب قلب خبير مع 15 سنة من الخبرة"
 *           description: Biography in Arabic (optional)
 *         yearsOfExp:
 *           type: integer
 *           minimum: 0
 *           maximum: 60
 *           nullable: true
 *           example: 15
 *           description: Years of experience (optional)
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *           example: "BOTH"
 *           description: |
 *             Practice type (optional):
 *             - INDEPENDENT: Works independently
 *             - CLINIC_BASED: Works in clinics
 *             - BOTH: Works both independently and in clinics
 *         latitude:
 *           type: number
 *           minimum: -90
 *           maximum: 90
 *           nullable: true
 *           example: 36.7538
 *           description: GPS latitude for location (optional)
 *         longitude:
 *           type: number
 *           minimum: -180
 *           maximum: 180
 *           nullable: true
 *           example: 3.0588
 *           description: GPS longitude for location (optional)
 *         baladyaId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Baladya/commune ID for more specific location (optional)
 *         logo:
 *           type: string
 *           format: binary
 *           description: |
 *             Profile photo (optional).
 *             Supported formats: JPEG, PNG, WebP, SVG
 *             Max size: 2MB
 *             File will be stored with a secure UUID and accessible via /api/v1/files/public/{fileId}

 *     RequestClinicRequest:
 *       type: object
 *       required:
 *         - clinicId
 *       properties:
 *         clinicId:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"

 *     DoctorClinicInvitationResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         clinicId:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         status:
 *           type: string
 *           enum: [PENDING, ACCEPTED, REJECTED]
 *           example: "PENDING"
 *         invitedBy:
 *           type: string
 *           example: "clinic"
 *         isActive:
 *           type: boolean
 *           example: true
 *         joinedAt:
 *           type: string
 *           format: date-time
 *         clinic:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *             email:
 *               type: string
 *             phone:
 *               type: string
 *             logoUrl:
 *               type: string
 *               nullable: true

 *     AvailabilitySlotDTO:
 *       type: object
 *       required:
 *         - dayOfWeek
 *         - startTime
 *         - endTime
 *       properties:
 *         dayOfWeek:
 *           type: string
 *           enum: [SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY]
 *           example: "SUNDAY"
 *         startTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           example: "08:00"
 *         endTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           example: "12:00"
 *         clinicId:
 *           type: string
 *           format: uuid
 *           nullable: true
 *         roomId:
 *           type: string
 *           format: uuid
 *           nullable: true

 *     SetAvailabilityRequest:
 *       type: object
 *       required:
 *         - slots
 *       properties:
 *         slots:
 *           type: array
 *           minItems: 1
 *           items:
 *             $ref: '#/components/schemas/AvailabilitySlotDTO'

 *     AvailabilityResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           format: uuid
 *         dayOfWeek:
 *           type: string
 *           example: "SUNDAY"
 *         startTime:
 *           type: string
 *           example: "08:00"
 *         endTime:
 *           type: string
 *           example: "12:00"
 *         isActive:
 *           type: boolean
 *           example: true
 *         clinicId:
 *           type: string
 *           nullable: true
 *         clinic:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         roomId:
 *           type: string
 *           nullable: true
 *         room:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             name:
 *               type: string
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time

 *     CreateBreakRequest:
 *       type: object
 *       required:
 *         - startDate
 *         - endDate
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *           description: Start date (YYYY-MM-DD)
 *           example: "2026-06-25"
 *         endDate:
 *           type: string
 *           format: date
 *           description: End date (YYYY-MM-DD)
 *           example: "2026-06-27"
 *         reason:
 *           type: string
 *           maxLength: 200
 *           description: Reason for the break
 *           example: "Vacation"
 *         isAllDay:
 *           type: boolean
 *           default: true
 *         startTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           description: Start time if not all day (HH:mm)
 *           example: "08:00"
 *         endTime:
 *           type: string
 *           pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$'
 *           description: End time if not all day (HH:mm)
 *           example: "12:00"

 *     UpdateBreakRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *         endDate:
 *           type: string
 *           format: date
 *         reason:
 *           type: string
 *           nullable: true
 *         isAllDay:
 *           type: boolean
 *         startTime:
 *           type: string
 *           nullable: true
 *         endTime:
 *           type: string
 *           nullable: true

 *     BreakResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *         startDate:
 *           type: string
 *           format: date
 *           example: "2026-06-25"
 *         endDate:
 *           type: string
 *           format: date
 *           example: "2026-06-27"
 *         reason:
 *           type: string
 *           nullable: true
 *           example: "Vacation"
 *         isAllDay:
 *           type: boolean
 *           example: true
 *         startTime:
 *           type: string
 *           nullable: true
 *           example: "08:00"
 *         endTime:
 *           type: string
 *           nullable: true
 *           example: "12:00"
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time

 *     UpdateBookingAvailabilityRequest:
 *       type: object
 *       required:
 *         - isAvailableForBooking
 *       properties:
 *         isAvailableForBooking:
 *           type: boolean
 *           description: Whether the doctor is accepting bookings
 *           example: true
 *         messageForUser:
 *           type: string
 *           nullable: true
 *           maxLength: 500
 *           description: |
 *             Custom message shown to patients when trying to book.
 *             Examples:
 *             - "Available from September 2026"
 *             - "Returns from vacation on 1 October"
 *             - "Currently not accepting new patients"
 *           example: "Available from September 2026"
 */

/**
 * @swagger
 * /api/v1/doctor/v1:
 *   get:
 *     summary: Get all doctors (Staff)
 *     description: Returns a paginated list of doctors with filtering options. Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by name, email, or phone
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: specialtyId
 *         schema:
 *           type: string
 *           format: uuid
 *       - in: query
 *         name: practiceType
 *         schema:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: isCompleted
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: isAvailableForBooking
 *         schema:
 *           type: boolean
 *         description: Filter by booking availability status
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, firstNameFr, lastNameFr, email]
 *           default: createdAt
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *     responses:
 *       200:
 *         description: Doctors retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctors retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/DoctorResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     total:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'

 *   post:
 *     summary: Create a basic doctor (Staff) - LEGACY
 *     description: |
 *       Creates a basic doctor WITHOUT specialties or logo.
 *       
 *       **⚠️ This endpoint creates an INCOMPLETE doctor.**
 *       The doctor must complete their profile later via `/me/complete`.
 *       
 *       **Differences from POST /create-complete:**
 *       - POST / → Basic/incomplete doctor (`isCompleted: false`)
 *       - POST /create-complete → Complete doctor (`isCompleted: true`)
 *       
 *       **What you get with this endpoint:**
 *       - Basic info only (email, password, names, phone, wilaya)
 *       - Auto-verified (`isVerified: true`)
 *       - Incomplete (`isCompleted: false`)
 *       - No specialties assigned
 *       - No photo/logo
 *       - Doctor must complete profile later
 *       
 *       **Use POST /create-complete for fully completed doctors.**
 *       
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateDoctorRequest'
 *           example:
 *             email: "dr.basic@iyadati.dz"
 *             password: "doctor123456"
 *             firstNameFr: "Ahmed"
 *             firstNameAr: "أحمد"
 *             lastNameFr: "Bensaid"
 *             lastNameAr: "بن سعيد"
 *             phone: "0665888888"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             specialtyIds: ["specialty-uuid-1", "specialty-uuid-2"]
 *     responses:
 *       201:
 *         description: Basic doctor created successfully (needs completion)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor created successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       409:
 *         description: Email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/create-complete:
 *   post:
 *     summary: Create a fully completed doctor with all information (Staff)
 *     description: |
 *       Creates a doctor with ALL information in one go:
 *       - ✅ Basic info (email, password, names, phone, wilaya)
 *       - ✅ Specialties (required - at least 1)
 *       - ✅ Profile details (bio, experience, practice type, location) - optional
 *       - ✅ Logo upload - optional
 *       
 *       **Key Features:**
 *       - Doctor is auto-verified (`isVerified: true`)
 *       - Doctor is marked as complete (`isCompleted: true`)
 *       - Doctor is ready to use immediately
 *       - No need for doctor to complete profile later
 *       
 *       **Difference from POST /:**
 *       - POST / creates a basic/incomplete doctor (needs profile completion)
 *       - POST /create-complete creates a fully completed doctor (ready to use)
 *       
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             $ref: '#/components/schemas/CreateCompleteDoctorRequest'
 *           example:
 *             email: "dr.complete@iyadati.dz"
 *             password: "doctor123456"
 *             firstNameFr: "Karim"
 *             firstNameAr: "كريم"
 *             lastNameFr: "Touati"
 *             lastNameAr: "تواتي"
 *             phone: "0665999999"
 *             wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *             specialtyIds: ["specialty-1-uuid", "specialty-2-uuid"]
 *             bioFr: "Cardiologue expert avec 15 ans d'expérience"
 *             bioAr: "طبيب قلب خبير مع 15 سنة من الخبرة"
 *             yearsOfExp: 15
 *             practiceType: "BOTH"
 *             latitude: 36.7538
 *             longitude: 3.0588
 *             baladyaId: "baladya-uuid"
 *     responses:
 *       201:
 *         description: Complete doctor created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor created successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *               example:
 *                 success: true
 *                 message: Doctor created successfully
 *                 data:
 *                   id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "dr.complete@iyadati.dz"
 *                   firstNameFr: "Karim"
 *                   firstNameAr: "كريم"
 *                   lastNameFr: "Touati"
 *                   lastNameAr: "تواتي"
 *                   phone: "0665999999"
 *                   wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *                   wilaya:
 *                     id: "550e8400-e29b-41d4-a716-446655440000"
 *                     code: 16
 *                     nameFr: "Alger"
 *                     nameAr: "الجزائر"
 *                   baladyaId: "baladya-uuid"
 *                   baladya:
 *                     id: "baladya-uuid"
 *                     nameFr: "Alger Centre"
 *                     nameAr: "الجزائر الوسطى"
 *                   bioFr: "Cardiologue expert avec 15 ans d'expérience"
 *                   bioAr: "طبيب قلب خبير مع 15 سنة من الخبرة"
 *                   photoPath: null
 *                   photoUrl: null
 *                   photoFileId: null
 *                   yearsOfExp: 15
 *                   practiceType: "BOTH"
 *                   latitude: 36.7538
 *                   longitude: 3.0588
 *                   specialties:
 *                     - id: "specialty-1-uuid"
 *                       nameFr: "Cardiologie"
 *                       nameAr: "أمراض القلب"
 *                     - id: "specialty-2-uuid"
 *                       nameFr: "Médecine Interne"
 *                       nameAr: "الطب الباطني"
 *                   isVerified: true
 *                   isSuspended: false
 *                   isRegistered: false
 *                   rejectionReason: null
 *                   isCompleted: true
 *                   isAvailableForBooking: false
 *                   messageForUser: null
 *                   createdAt: "2026-08-04T12:00:00.000Z"
 *                   updatedAt: "2026-08-04T12:00:00.000Z"
 *       400:
 *         description: |
 *           Validation error - possible reasons:
 *           - Missing required fields
 *           - No specialties provided (min 1 required)
 *           - Invalid email format
 *           - Invalid phone format
 *           - Invalid UUID format
 *           - Invalid file type
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *             example:
 *               success: false
 *               message: Validation failed
 *               error: Validation failed
 *               errors:
 *                 - field: "specialtyIds"
 *                   message: "At least one specialty is required"
 *                 - field: "email"
 *                   message: "Email must be a valid email"
 *       409:
 *         description: |
 *           Conflict - email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *           examples:
 *             email_exists:
 *               summary: Email already exists
 *               value:
 *                 success: false
 *                 message: Email already exists
 *                 error: Email already exists
 *             phone_exists:
 *               summary: Phone already exists
 *               value:
 *                 success: false
 *                 message: Phone already exists
 *                 error: Phone already exists
 *       401:
 *         description: Not authenticated (missing or invalid JWT token)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: No token provided
 *               error: No token provided
 *       403:
 *         description: |
 *           Not authorized - user doesn't have required role
 *           Requires: SUPER_ADMIN or ADMIN
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: You do not have permission to access this resource
 *               error: You do not have permission to access this resource
 *       413:
 *         description: File too large (logo exceeds 2MB limit)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: File too large. Maximum size is 2MB
 *               error: File too large
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: Internal server error
 *               error: Internal server error
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}:
 *   get:
 *     summary: Get doctor by ID (Staff)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Doctor retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'

 *   patch:
 *     summary: Update doctor (Staff - Full Update)
 *     description: |
 *       Admin can update ANY field of a doctor including:
 *       - Basic info (name, phone, email, location)
 *       - Profile details (bio, experience, practice type, coordinates)
 *       - Status fields (verification, suspension, completion, registration)
 *       - Specialties (replace all)
 *       
 *       All fields are optional. At least one field must be provided.
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateDoctorRequest'
 *           examples:
 *             update_basic:
 *               summary: Update basic info
 *               value:
 *                 firstNameFr: "Karim"
 *                 lastNameFr: "Touati"
 *                 phone: "0665999999"
 *             update_profile:
 *               summary: Update profile details
 *               value:
 *                 bioFr: "Cardiologue expert avec 15 ans d'expérience"
 *                 yearsOfExp: 15
 *                 practiceType: "BOTH"
 *                 latitude: 36.7538
 *                 longitude: 3.0588
 *             update_status:
 *               summary: Update status (admin only)
 *               value:
 *                 isVerified: true
 *                 isSuspended: false
 *                 isCompleted: true
 *                 rejectionReason: null
 *             update_specialties:
 *               summary: Replace all specialties
 *               value:
 *                 specialtyIds: ["specialty-1-uuid", "specialty-2-uuid"]
 *             update_all:
 *               summary: Update everything
 *               value:
 *                 firstNameFr: "Karim"
 *                 firstNameAr: "كريم"
 *                 lastNameFr: "Touati"
 *                 lastNameAr: "تواتي"
 *                 phone: "0665999999"
 *                 email: "dr.touati@iyadati.dz"
 *                 wilayaId: "550e8400-e29b-41d4-a716-446655440000"
 *                 baladyaId: "660e8400-e29b-41d4-a716-446655440000"
 *                 bioFr: "Cardiologue expert avec 15 ans d'expérience"
 *                 bioAr: "طبيب قلب خبير مع 15 سنة من الخبرة"
 *                 yearsOfExp: 15
 *                 practiceType: "BOTH"
 *                 latitude: 36.7538
 *                 longitude: 3.0588
 *                 isVerified: true
 *                 isSuspended: false
 *                 isCompleted: true
 *                 isRegistered: false
 *                 rejectionReason: null
 *                 specialtyIds: ["specialty-1-uuid", "specialty-2-uuid"]
 *     responses:
 *       200:
 *         description: Doctor updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor updated successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       409:
 *         description: Email or phone already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires SUPER_ADMIN or ADMIN)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/verify:
 *   post:
 *     summary: Verify doctor (Staff)
 *     description: Approves a doctor after reviewing documents.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Doctor verified successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor verified successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Doctor already verified
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/reject:
 *   post:
 *     summary: Reject doctor (Staff)
 *     description: Rejects a doctor with a reason. Doctor can re-upload documents.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RejectDoctorRequest'
 *           example:
 *             reason: "Documents are unclear. Please re-upload."
 *     responses:
 *       200:
 *         description: Doctor rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor rejected
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/suspend:
 *   post:
 *     summary: Suspend doctor (Staff)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Doctor suspended successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor suspended successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Doctor already suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/unsuspend:
 *   post:
 *     summary: Unsuspend doctor (Staff)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Doctor unsuspended successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor unsuspended successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Doctor is not suspended
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/documents:
 *   get:
 *     summary: Get doctor documents (Staff)
 *     description: |
 *       Returns all documents with signed access URLs for a specific doctor.
 *       Each document URL contains a secure UUID (fileId) instead of the file path.
 *       URLs expire after 30 minutes.
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Documents retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Documents retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/DoctorDocumentResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'

 *   post:
 *     summary: Upload document for doctor (Staff)
 *     description: |
 *       Uploads a document on behalf of a doctor.
 *       Accepted PDF, JPEG, PNG. Max 20MB.
 *       Use multipart/form-data with field `document` and body field `docType`.
 *       
 *       **Security:** Files are stored with UUID filenames and accessed via signed URLs.
 *       The access URL will contain only the file ID, not the file path.
 *       
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *               docType:
 *                 type: string
 *                 enum: [degree, license, id_card, other, cv, certificate]
 *                 default: other
 *                 description: Type of document
 *           example:
 *             docType: "license"
 *     responses:
 *       201:
 *         description: Document uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Document uploaded successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorDocumentResponse'
 *       400:
 *         description: Invalid file or missing document
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       413:
 *         description: File too large (max 20MB)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/documents/{documentId}:
 *   delete:
 *     summary: Delete a doctor's document (Staff)
 *     description: |
 *       Deletes a specific document belonging to a doctor.
 *       Also deletes the physical file from storage.
 *       Requires Super Admin or Admin.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *       - in: path
 *         name: documentId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to delete
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Document deleted successfully
 *       400:
 *         description: Document does not belong to this doctor
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor or document not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/availability:
 *   get:
 *     summary: Get doctor availability (Staff)
 *     description: Returns the doctor's recurring weekly availability schedule.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Availability retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Doctor availability retrieved
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AvailabilityResponse'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/profile:
 *   get:
 *     summary: Get my doctor profile (Doctor)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profile retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Profile retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/complete:
 *   patch:
 *     summary: Complete doctor profile (Doctor)
 *     description: |
 *       Completes the doctor profile after verification.
 *       Can upload photo via multipart/form-data field `logo`.
 *       Requires Doctor JWT token.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             $ref: '#/components/schemas/CompleteDoctorRequest'
 *           example:
 *             bioFr: "Médecin cardiologue avec 15 ans d'expérience"
 *             bioAr: "طبيب قلب مع 15 سنة من الخبرة"
 *             yearsOfExp: 15
 *             practiceType: "BOTH"
 *             latitude: 36.7538
 *             longitude: 3.0588
 *             baladyaId: "550e8400-e29b-41d4-a716-446655440000"
 *             specialtyIds: ["specialty-uuid-1", "specialty-uuid-2"]
 *     responses:
 *       200:
 *         description: Profile completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Profile completed successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Doctor not verified
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/documents:
 *   get:
 *     summary: Get my documents (Doctor)
 *     description: |
 *       Returns all documents with signed access URLs.
 *       Each document URL contains a secure UUID (fileId) instead of the file path.
 *       URLs expire after 30 minutes.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Documents retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Documents retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/DoctorDocumentResponse'

 *   post:
 *     summary: Upload my document (Doctor)
 *     description: |
 *       Uploads a document. Accepted PDF, JPEG, PNG. Max 20MB.
 *       Use multipart/form-data with field `document` and body field `docType`.
 *       
 *       **How it works:**
 *       1. File is uploaded and stored with a secure UUID filename
 *       2. Database stores the fileId (UUID) and storageKey
 *       3. Access URL uses fileId only - no path exposure
 *       4. URL is signed and expires in 30 minutes
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               document:
 *                 type: string
 *                 format: binary
 *                 description: Document file (PDF, JPEG, PNG - max 20MB)
 *               docType:
 *                 type: string
 *                 enum: [degree, license, id_card, other, cv, certificate]
 *                 default: other
 *                 description: Type of document being uploaded
 *           example:
 *             docType: "degree"
 *     responses:
 *       201:
 *         description: Document uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Document uploaded successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorDocumentResponse'
 *       400:
 *         description: Invalid file or missing document
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       413:
 *         description: File too large (max 20MB)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/documents/{id}:
 *   delete:
 *     summary: Delete my document (Doctor)
 *     description: |
 *       Deletes a document owned by the authenticated doctor.
 *       Also deletes the physical file from storage.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Document ID to delete
 *     responses:
 *       200:
 *         description: Document deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Document deleted successfully
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (document doesn't belong to you)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Document not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/clinics/request:
 *   post:
 *     summary: Request to join a clinic (Doctor)
 *     description: Doctor sends a request to join a clinic. Clinic must accept.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RequestClinicRequest'
 *           example:
 *             clinicId: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       201:
 *         description: Request sent to clinic
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Request sent to clinic
 *                 data:
 *                   $ref: '#/components/schemas/DoctorClinicInvitationResponse'
 *       400:
 *         description: Already pending or already a member
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Clinic not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/clinic-invitations:
 *   get:
 *     summary: Get my clinic invitations (Doctor)
 *     description: Returns all clinic invitations and requests for the doctor.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Invitations retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Invitations retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/DoctorClinicInvitationResponse'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/clinic-invitations/{id}/accept:
 *   post:
 *     summary: Accept clinic invitation (Doctor)
 *     description: Doctor accepts a clinic's invitation.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Invitation ID
 *     responses:
 *       200:
 *         description: Invitation accepted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Invitation accepted
 *                 data:
 *                   $ref: '#/components/schemas/DoctorClinicInvitationResponse'
 *       400:
 *         description: Invitation is no longer pending
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Invitation not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/clinic-invitations/{id}/reject:
 *   post:
 *     summary: Reject clinic invitation (Doctor)
 *     description: Doctor rejects a clinic's invitation.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Invitation ID
 *     responses:
 *       200:
 *         description: Invitation rejected
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Invitation rejected
 *                 data:
 *                   $ref: '#/components/schemas/DoctorClinicInvitationResponse'
 *       400:
 *         description: Invitation is no longer pending
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Invitation not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/availability:
 *   get:
 *     summary: Get my availability (Doctor)
 *     description: Returns the doctor's recurring weekly availability schedule.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Availability retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Availability retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AvailabilityResponse'

 *   put:
 *     summary: Set my availability (Doctor)
 *     description: |
 *       Replaces the doctor's entire weekly availability schedule.
 *       This is a recurring weekly template - it applies to every week.
 *       Sending new slots DELETES all existing slots and creates new ones.
 *       Use clinicId and roomId for clinic-based availability slots.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SetAvailabilityRequest'
 *           example:
 *             slots:
 *               - dayOfWeek: "SUNDAY"
 *                 startTime: "08:00"
 *                 endTime: "12:00"
 *               - dayOfWeek: "SUNDAY"
 *                 startTime: "13:00"
 *                 endTime: "17:00"
 *                 clinicId: "550e8400-e29b-41d4-a716-446655440000"
 *                 roomId: "660e8400-e29b-41d4-a716-446655440000"
 *               - dayOfWeek: "MONDAY"
 *                 startTime: "08:00"
 *                 endTime: "17:00"
 *     responses:
 *       200:
 *         description: Availability updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Availability updated successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AvailabilityResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/availability/{id}:
 *   delete:
 *     summary: Remove availability slot (Doctor)
 *     description: Soft deletes a single availability time slot.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Availability slot ID
 *     responses:
 *       200:
 *         description: Availability slot removed
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Availability slot removed
 *       404:
 *         description: Slot not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/breaks:
 *   get:
 *     summary: Get my breaks (Doctor)
 *     description: Returns all scheduled breaks (vacations, sick leave, etc.)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Breaks retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Breaks retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/BreakResponse'

 *   post:
 *     summary: Create a break (Doctor)
 *     description: |
 *       Creates a break/vacation. Overrides recurring availability for specific dates.
 *       For all-day breaks, only startDate and endDate are required.
 *       For partial breaks, set isAllDay=false and provide startTime/endTime.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateBreakRequest'
 *           examples:
 *             vacation:
 *               summary: All-day vacation
 *               value:
 *                 startDate: "2026-07-01"
 *                 endDate: "2026-07-15"
 *                 reason: "Summer vacation"
 *                 isAllDay: true
 *             partialDay:
 *               summary: Partial day off
 *               value:
 *                 startDate: "2026-06-25"
 *                 endDate: "2026-06-25"
 *                 reason: "Conference"
 *                 isAllDay: false
 *                 startTime: "08:00"
 *                 endTime: "12:00"
 *     responses:
 *       201:
 *         description: Break created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Break created successfully
 *                 data:
 *                   $ref: '#/components/schemas/BreakResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/me/breaks/{id}:
 *   patch:
 *     summary: Update a break (Doctor)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateBreakRequest'
 *     responses:
 *       200:
 *         description: Break updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Break updated successfully
 *                 data:
 *                   $ref: '#/components/schemas/BreakResponse'
 *       404:
 *         description: Break not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'

 *   delete:
 *     summary: Delete a break (Doctor)
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *     responses:
 *       200:
 *         description: Break deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Break deleted successfully
 *       404:
 *         description: Break not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/doctor/v1/{id}/booking-availability:
 *   patch:
 *     summary: Update doctor booking availability (Staff)
 *     description: |
 *       Controls whether a doctor is available for patient bookings and displays a custom message.
 *       
 *       **Use Cases:**
 *       - **Enable Immediately:** 
 *         ```json
 *         { "isAvailableForBooking": true }
 *         ```
 *         → Doctor appears as available now
 *       
 *       - **Enable with Custom Message:** 
 *         ```json
 *         {
 *           "isAvailableForBooking": true,
 *           "messageForUser": "Available from September 2026"
 *         }
 *         ```
 *         → Shows custom message to patients
 *       
 *       - **Disable:** 
 *         ```json
 *         { "isAvailableForBooking": false }
 *         ```
 *         → Doctor not shown for booking (message automatically cleared)
 *       
 *       **Why:** 
 *       - Allows pre-registering doctors before they can accept patients
 *       - Admin can set custom messages like "Returns from vacation on 15 September"
 *       - Patient-friendly: Clear communication about availability status
 *       
 *       **Note:** When a doctor is suspended, booking availability is automatically disabled.
 *     tags: [Doctor]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Doctor ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateBookingAvailabilityRequest'
 *           examples:
 *             enable:
 *               summary: Make available now
 *               value:
 *                 isAvailableForBooking: true
 *             enable_with_message:
 *               summary: Available with custom message
 *               value:
 *                 isAvailableForBooking: true
 *                 messageForUser: "Available from September 2026"
 *             disable:
 *               summary: Disable bookings
 *               value:
 *                 isAvailableForBooking: false
 *     responses:
 *       200:
 *         description: Booking availability updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Booking availability updated successfully
 *                 data:
 *                   $ref: '#/components/schemas/DoctorResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires SUPER_ADMIN or ADMIN)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

