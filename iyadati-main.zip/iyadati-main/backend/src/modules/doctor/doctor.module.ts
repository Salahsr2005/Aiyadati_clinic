import { Router } from 'express';
import doctorRoutes from './v1/doctor.routes';
import './v1/doctor.swagger';

const router = Router();
router.use('/v1', doctorRoutes);

export { router as doctorModule };

