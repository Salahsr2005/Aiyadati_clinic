import { Router } from 'express';
import { ChatController } from './chat.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const c = new ChatController();

// All authenticated users
router.get('/rooms', authenticate, authorize('USER', 'DOCTOR', 'CLINIC'), c.getMyRooms);
router.post('/rooms', authenticate, authorize('USER', 'DOCTOR', 'CLINIC'), c.createRoom);
router.get('/rooms/:id/messages', authenticate, authorize('USER', 'DOCTOR', 'CLINIC', 'SUPPORT'), c.getMessages);

// Super admin,admin,support
router.get('/support/rooms', authenticate, authorize('SUPER_ADMIN','ADMIN','SUPPORT'), c.getSupportRooms);
router.patch('/support/rooms/:id/close', authenticate, authorize('SUPER_ADMIN','ADMIN','SUPPORT'), c.closeRoom);

export default router;

