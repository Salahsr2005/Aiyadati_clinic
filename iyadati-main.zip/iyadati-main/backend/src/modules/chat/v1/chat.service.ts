import { chatRepository } from '../../../repositories/chat.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { eventEmitter } from '../../../core/events/event-emitter';
import { logger } from '../../../core/utils/logger';
import { RoomResponse, MessageResponse } from './chat.types';

export class ChatService {

  async getMyRooms(userId: string): Promise<RoomResponse[]> {
    const rooms = await chatRepository.findRoomsByUserId(userId);

    return rooms.map(room => ({
      id: room.id,
      userId: room.userId,
      userRole: room.userRole,
      userName: room.userName,
      userEmail: room.userEmail,
      supportId: room.supportId,
      status: room.status,
      lastMessage: room.lastMessage,
      unreadCount: 0,
      createdAt: room.createdAt.toISOString(),
      updatedAt: room.updatedAt.toISOString(),
    }));
  }

  async createRoom(userId: string, userRole: string, userName: string, userEmail: string, firstMessage: string): Promise<RoomResponse> {
    const existing = await chatRepository.findOpenRoomByUserId(userId);

    if (existing) {
      return {
        id: existing.id, userId: existing.userId, userRole: existing.userRole,
        userName: existing.userName, userEmail: existing.userEmail,
        supportId: existing.supportId, status: existing.status,
        lastMessage: existing.lastMessage, unreadCount: 0,
        createdAt: existing.createdAt.toISOString(), updatedAt: existing.updatedAt.toISOString(),
      };
    }

    const room = await chatRepository.createRoom({ userId, userRole, userName, userEmail });

    await chatRepository.createMessage({
      roomId: room.id,
      senderId: userId,
      senderRole: userRole,
      senderName: userName,
      message: firstMessage,
    });

    await chatRepository.updateRoom(room.id, { lastMessage: firstMessage });

    // Notify support team about new chat
    eventEmitter.emit('notification', {
      userId: 'SUPPORT',
      title: '💬 New Support Request',
      body: `${userName} (${userRole}) needs help: "${firstMessage.substring(0, 50)}${firstMessage.length > 50 ? '...' : ''}"`,
      type: 'chat',
      data: { roomId: room.id, type: 'new_chat', userId, userRole, userName },
    });

    // Notify user that support has been notified
    eventEmitter.emit('notification', {
      userId,
      title: '💬 Support Request Sent',
      body: 'Your support request has been sent. A support agent will respond shortly.',
      type: 'chat',
      data: { roomId: room.id, type: 'chat_created' },
    });

    logger.info(`Chat room created for ${userName} (${userRole})`);

    return {
      id: room.id, userId: room.userId, userRole: room.userRole,
      userName: room.userName, userEmail: room.userEmail,
      supportId: room.supportId, status: room.status,
      lastMessage: firstMessage, unreadCount: 0,
      createdAt: room.createdAt.toISOString(), updatedAt: room.updatedAt.toISOString(),
    };
  }

  async getMessages(roomId: string, userId: string, userRole: string): Promise<MessageResponse[]> {
    const room = await chatRepository.findRoomById(roomId);
    if (!room) throw new NotFoundError('Room not found');
    if (userRole !== 'SUPPORT' && room.userId !== userId) throw new BadRequestError('Access denied');

    const messages = await chatRepository.findMessagesByRoomId(roomId);

    return messages.map(m => ({
      id: m.id, roomId: m.roomId, senderId: m.senderId,
      senderRole: m.senderRole, senderName: m.senderName,
      message: m.message, createdAt: m.createdAt.toISOString(),
    }));
  }

  async getSupportRooms(): Promise<RoomResponse[]> {
    const rooms = await chatRepository.findAllOpenRooms();

    return rooms.map(room => ({
      id: room.id, userId: room.userId, userRole: room.userRole,
      userName: room.userName, userEmail: room.userEmail,
      supportId: room.supportId, status: room.status,
      lastMessage: room.lastMessage, unreadCount: 0,
      createdAt: room.createdAt.toISOString(), updatedAt: room.updatedAt.toISOString(),
    }));
  }

  async closeRoom(roomId: string, supportId: string): Promise<void> {
    const room = await chatRepository.findRoomById(roomId);
    if (!room) throw new NotFoundError('Room not found');

    await chatRepository.updateRoom(roomId, { status: 'closed', supportId });

    // Notify user that chat was closed
    eventEmitter.emit('notification', {
      userId: room.userId,
      title: '💬 Support Chat Closed',
      body: 'Your support request has been resolved and closed. If you need further assistance, start a new chat.',
      type: 'chat',
      data: { roomId, type: 'chat_closed' },
    });

    // Notify support that chat was closed
    eventEmitter.emit('notification', {
      userId: 'SUPPORT',
      title: '📋 Support Chat Closed',
      body: `Chat with ${room.userName} (${room.userRole}) has been closed.`,
      type: 'chat',
      data: { roomId, type: 'chat_closed_by_support' },
    });

    logger.info(`Chat room ${roomId} closed by support ${supportId}`);
  }
}

export const chatService = new ChatService();

