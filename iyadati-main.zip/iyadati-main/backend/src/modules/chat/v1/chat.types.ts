export interface CreateRoomDTO {
  message: string; // First message
}

export interface RoomResponse {
  id: string;
  userId: string;
  userRole: string;
  userName: string;
  userEmail: string;
  supportId: string | null;
  status: string;
  lastMessage: string | null;
  unreadCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface MessageResponse {
  id: string;
  roomId: string;
  senderId: string;
  senderRole: string;
  senderName: string;
  message: string;
  createdAt: string;
}

