import { Request, Response, NextFunction } from 'express';
import { chatService } from './chat.service';
import { ResponseUtil } from '../../../core/utils/response';

export class ChatController {
  getMyRooms = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rooms = await chatService.getMyRooms(req.user!.id);
      ResponseUtil.success(res, rooms, 'Rooms retrieved');
    } catch (error) { next(error); }
  };

  createRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userName = (req.user! as any).firstName
        ? `${(req.user! as any).firstName} ${(req.user! as any).lastName}`
        : (req.user! as any).name || req.user!.email;
      const room = await chatService.createRoom(req.user!.id, req.user!.role, userName, req.user!.email, req.body.message);
      ResponseUtil.created(res, room, 'Room created');
    } catch (error) { next(error); }
  };

  getMessages = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const messages = await chatService.getMessages(req.params.id, req.user!.id, req.user!.role);
      ResponseUtil.success(res, messages, 'Messages retrieved');
    } catch (error) { next(error); }
  };

  getSupportRooms = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const rooms = await chatService.getSupportRooms();
      ResponseUtil.success(res, rooms, 'Support rooms retrieved');
    } catch (error) { next(error); }
  };

  closeRoom = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await chatService.closeRoom(req.params.id, req.user!.id);
      ResponseUtil.success(res, null, 'Room closed');
    } catch (error) { next(error); }
  };
}

