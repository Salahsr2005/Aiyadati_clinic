// backend/src/modules/chat/v1/chat.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Chat
 *   description: Real-time support chat via Socket.io and REST endpoints
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     ChatRoomResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         userId:
 *           type: string
 *         userRole:
 *           type: string
 *           enum: [USER, DOCTOR, CLINIC]
 *         userName:
 *           type: string
 *         userEmail:
 *           type: string
 *         supportId:
 *           type: string
 *           nullable: true
 *         status:
 *           type: string
 *           enum: [open, closed]
 *         lastMessage:
 *           type: string
 *           nullable: true
 *         unreadCount:
 *           type: integer
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     
 *     ChatMessageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         roomId:
 *           type: string
 *         senderId:
 *           type: string
 *         senderRole:
 *           type: string
 *           enum: [USER, DOCTOR, CLINIC, SUPPORT, ADMIN, SUPER_ADMIN]
 *         senderName:
 *           type: string
 *         message:
 *           type: string
 *         createdAt:
 *           type: string
 *     
 *     CreateRoomRequest:
 *       type: object
 *       required:
 *         - message
 *       properties:
 *         message:
 *           type: string
 *           description: First message to send
 *           example: "Hello, I need help with booking an appointment"
 * 
 *     SocketAccess:
 *       type: object
 *       description: |
 *         ## Socket.io Access Control
 *         
 *         | Action | USER/DOCTOR/CLINIC | SUPPORT | ADMIN | SUPER_ADMIN |
 *         |--------|-------------------|---------|-------|-------------|
 *         | join_room | ✅ Own rooms only | ✅ Any room | ✅ Any room | ✅ Any room |
 *         | send_message | ✅ Own rooms only | ✅ Any room | ✅ Any room | ✅ Any room |
 *         | typing | ✅ Any room | ✅ Any room | ✅ Any room | ✅ Any room |
 *         | stop_typing | ✅ Any room | ✅ Any room | ✅ Any room | ✅ Any room |
 *         | receive new_message | ✅ In room | ✅ In room | ✅ In room | ✅ In room |
 *         | receive new_support_request | ❌ | ✅ | ✅ | ✅ |
 * 
 *     # ===== SOCKET.IO EVENTS =====
 *     SocketConnection:
 *       type: object
 *       description: |
 *         ## Socket.io Connection
 *         
 *         **URL:** `ws://localhost:3975` or `http://localhost:3975`  
 *         **Auth:** JWT token required in auth object or query params
 *         
 *         ```javascript
 *         const socket = io('http://localhost:3975', {
 *           auth: { token: 'your-jwt-token' }
 *         });
 *         ```
 *         
 *         Or with query param:
 *         ```javascript
 *         const socket = io('http://localhost:3975?token=your-jwt-token');
 *         ```
 *       x-socket-events:
 *         client:
 *           join_room:
 *             description: |
 *               Join a chat room to receive messages
 *               
 *               **Access:**
 *               - **Users (USER, DOCTOR, CLINIC):** Can only join their own rooms
 *               - **Support Staff (SUPPORT, ADMIN, SUPER_ADMIN):** Can join ANY room
 *             payload:
 *               roomId:
 *                 type: string
 *                 required: true
 *                 description: Chat room ID
 *             example: |
 *               socket.emit('join_room', '550e8400-e29b-41d4-a716-446655440000');
 *           
 *           send_message:
 *             description: |
 *               Send a message to the chat room
 *               
 *               **Access:**
 *               - **Users (USER, DOCTOR, CLINIC):** Can only send to their own rooms
 *               - **Support Staff (SUPPORT, ADMIN, SUPER_ADMIN):** Can send to ANY room
 *               
 *               **Note:** When a non-support user sends a message, a `new_support_request`
 *               event is broadcasted to all support staff.
 *             payload:
 *               roomId:
 *                 type: string
 *                 required: true
 *               message:
 *                 type: string
 *                 required: true
 *                 maxLength: 1000
 *             example: |
 *               socket.emit('send_message', {
 *                 roomId: '550e8400-e29b-41d4-a716-446655440000',
 *                 message: 'Hello, I need help!'
 *               });
 *           
 *           typing:
 *             description: |
 *               Notify that user is typing
 *               
 *               **Access:** Any authenticated user
 *             payload:
 *               roomId:
 *                 type: string
 *                 required: true
 *             example: |
 *               socket.emit('typing', '550e8400-e29b-41d4-a716-446655440000');
 *           
 *           stop_typing:
 *             description: |
 *               Notify that user stopped typing
 *               
 *               **Access:** Any authenticated user
 *             payload:
 *               roomId:
 *                 type: string
 *                 required: true
 *             example: |
 *               socket.emit('stop_typing', '550e8400-e29b-41d4-a716-446655440000');
 *         
 *         server:
 *           joined_room:
 *             description: Confirmation of joining a room
 *             payload:
 *               roomId:
 *                 type: string
 *             example: |
 *               socket.on('joined_room', (data) => {
 *                 console.log('Joined room:', data.roomId);
 *               });
 *           
 *           new_message:
 *             description: |
 *               New message received in the room
 *               
 *               **Sent to:** All users in the room
 *             payload:
 *               id:
 *                 type: string
 *               roomId:
 *                 type: string
 *               senderId:
 *                 type: string
 *               senderRole:
 *                 type: string
 *                 enum: [USER, DOCTOR, CLINIC, SUPPORT, ADMIN, SUPER_ADMIN]
 *               senderName:
 *                 type: string
 *               message:
 *                 type: string
 *               createdAt:
 *                 type: string
 *             example: |
 *               socket.on('new_message', (data) => {
 *                 console.log(`${data.senderName}: ${data.message}`);
 *               });
 *           
 *           new_support_request:
 *             description: |
 *               New support request notification
 *               
 *               **Sent to:** Support staff only (SUPPORT, ADMIN, SUPER_ADMIN)
 *               
 *               **Triggered when:** A non-support user sends their first message
 *             payload:
 *               roomId:
 *                 type: string
 *               userName:
 *                 type: string
 *               userRole:
 *                 type: string
 *                 enum: [USER, DOCTOR, CLINIC]
 *               userEmail:
 *                 type: string
 *               message:
 *                 type: string
 *               from:
 *                 type: string
 *                 description: Sender's name
 *               timestamp:
 *                 type: string
 *             example: |
 *               socket.on('new_support_request', (data) => {
 *                 console.log(`New request from ${data.userName} (${data.userRole})`);
 *                 console.log(`Message: ${data.message}`);
 *               });
 *           
 *           user_typing:
 *             description: Another user is typing
 *             payload:
 *               userId:
 *                 type: string
 *               userName:
 *                 type: string
 *               userRole:
 *                 type: string
 *             example: |
 *               socket.on('user_typing', (data) => {
 *                 console.log(`${data.userName} is typing...`);
 *               });
 *           
 *           user_stop_typing:
 *             description: Another user stopped typing
 *             payload:
 *               userId:
 *                 type: string
 *               userName:
 *                 type: string
 *             example: |
 *               socket.on('user_stop_typing', (data) => {
 *                 console.log(`${data.userName} stopped typing`);
 *               });
 *           
 *           error:
 *             description: Error event
 *             payload:
 *               message:
 *                 type: string
 *             example: |
 *               socket.on('error', (data) => {
 *                 console.error('Error:', data.message);
 *               });
 */

/**
 * @swagger
 * /api/v1/chat/v1/rooms:
 *   get:
 *     summary: Get my chat rooms
 *     description: |
 *       Returns all open chat rooms for the authenticated user.
 *       
 *       **Access:** USER, DOCTOR, CLINIC only
 *     tags: [Chat]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Rooms retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ChatRoomResponse'
 *   
 *   post:
 *     summary: Create support chat room
 *     description: |
 *       Creates a new support chat room (or returns existing open one).
 *       
 *       **Access:** USER, DOCTOR, CLINIC only
 *       
 *       **Flow:**
 *       1. POST this endpoint to create room
 *       2. Connect Socket.io with JWT token
 *       3. `socket.emit('join_room', roomId)`
 *       4. Start chatting in real-time!
 *     tags: [Chat]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateRoomRequest'
 *     responses:
 *       201:
 *         description: Room created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ChatRoomResponse'
 */

/**
 * @swagger
 * /api/v1/chat/v1/rooms/{id}/messages:
 *   get:
 *     summary: Get room messages
 *     description: |
 *       Returns all messages in a chat room.
 *       
 *       **Access:**
 *       - **Users (USER, DOCTOR, CLINIC):** Can only view their own rooms
 *       - **Support Staff (SUPPORT, ADMIN, SUPER_ADMIN):** Can view ANY room
 *     tags: [Chat]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Chat room ID
 *     responses:
 *       200:
 *         description: Messages retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ChatMessageResponse'
 *       403:
 *         description: Access denied - Not your room
 *       404:
 *         description: Room not found
 */

/**
 * @swagger
 * /api/v1/chat/v1/support/rooms:
 *   get:
 *     summary: Get all open rooms (Support & Admin)
 *     description: |
 *       Returns all open support chat rooms.
 *       
 *       **Access:** 
 *       - SUPPORT
 *       - ADMIN
 *       - SUPER_ADMIN
 *       - USER, DOCTOR, CLINIC (cannot access)
 *     tags: [Chat]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Rooms retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ChatRoomResponse'
 *       403:
 *         description: Forbidden - Insufficient permissions
 */

/**
 * @swagger
 * /api/v1/chat/v1/support/rooms/{id}/close:
 *   patch:
 *     summary: Close a chat room (Support & Admin)
 *     description: |
 *       Closes a support chat room.
 *       
 *       **Access:** 
 *       - SUPPORT
 *       - ADMIN
 *       - SUPER_ADMIN
 *       - USER, DOCTOR, CLINIC (cannot access)
 *     tags: [Chat]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Chat room ID to close
 *     responses:
 *       200:
 *         description: Room closed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *       403:
 *         description: Forbidden - Insufficient permissions
 *       404:
 *         description: Room not found
 */

/**
 * @swagger
 * /socket.io:
 *   get:
 *     summary: WebSocket Connection (Socket.io)
 *     description: |
 *       ## Real-Time Chat via Socket.io
 *       
 *       **Connection:** `ws://localhost:3975` or `http://localhost:3975`  
 *       **Auth:** JWT token as `token` in auth or query params
 *       
 *       ### Client Events (send to server)
 *       
 *       | Event | Payload | Access | Description |
 *       |-------|---------|--------|-------------|
 *       | `join_room` | `roomId: string` | Users: own rooms only, Support: any room | Join a chat room |
 *       | `send_message` | `{ roomId, message }` | Users: own rooms only, Support: any room | Send a message |
 *       | `typing` | `roomId: string` | All authenticated | User is typing |
 *       | `stop_typing` | `roomId: string` | All authenticated | User stopped typing |
 *       
 *       ### Server Events (listen from server)
 *       
 *       | Event | Payload | Sent To | Description |
 *       |-------|---------|---------|-------------|
 *       | `joined_room` | `{ roomId }` | Sender only | Confirmed join |
 *       | `new_message` | `{ id, roomId, senderId, senderRole, senderName, message, createdAt }` | Everyone in room | New message |
 *       | `new_support_request` | `{ roomId, userName, userRole, userEmail, message, from, timestamp }` | Support staff only | New support request |
 *       | `user_typing` | `{ userId, userName, userRole }` | Others in room | User typing |
 *       | `user_stop_typing` | `{ userId, userName }` | Others in room | User stopped |
 *       | `error` | `{ message }` | Sender only | Error |
 *       
 *       ### Typical Flow
 *       
 *       **User:**
 *       1. `POST /api/v1/chat/v1/rooms` → Get `roomId`
 *       2. Connect Socket.io with JWT token
 *       3. `socket.emit('join_room', roomId)`
 *       4. Chat in real-time!
 *       
 *       **Support/Admin:**
 *       1. `GET /api/v1/chat/v1/support/rooms` → Pick a room
 *       2. Connect Socket.io with JWT token
 *       3. `socket.emit('join_room', roomId)`
 *       4. Chat in real-time!
 *       
 *       ### Full Example
 *       
 *       ```javascript
 *       // 1. Create room (User)
 *       const response = await fetch('/api/v1/chat/v1/rooms', {
 *         method: 'POST',
 *         headers: { 'Authorization': 'Bearer token' },
 *         body: JSON.stringify({ message: 'I need help!' })
 *       });
 *       const { data: { id: roomId } } = await response.json();
 *       
 *       // 2. Connect to Socket.io
 *       const socket = io('http://localhost:3975', {
 *         auth: { token: 'your-jwt-token' }
 *       });
 *       
 *       // 3. Join room
 *       socket.emit('join_room', roomId);
 *       
 *       // 4. Listen for messages
 *       socket.on('new_message', (data) => {
 *         console.log(`${data.senderName}: ${data.message}`);
 *       });
 *       
 *       // 5. Send message
 *       socket.emit('send_message', {
 *         roomId: roomId,
 *         message: 'Hello!'
 *       });
 *       
 *       // 6. Typing indicator
 *       socket.emit('typing', roomId);
 *       socket.emit('stop_typing', roomId);
 *       ```
 *     tags: [Chat]
 *     responses:
 *       101:
 *         description: WebSocket upgrade - Switching to Socket.io protocol
 *       400:
 *         description: Bad request - Missing JWT token
 *       401:
 *         description: Unauthorized - Invalid token
 */