import { Router } from 'express';
import chatRoutes from './v1/chat.routes';

const router = Router();

router.use('/v1', chatRoutes);

export { router as chatModule };
