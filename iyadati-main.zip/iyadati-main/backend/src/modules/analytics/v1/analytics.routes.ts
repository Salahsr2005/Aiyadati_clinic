import { Router } from 'express';
import { AnalyticsController } from './analytics.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const c = new AnalyticsController();

router.use(authenticate, authorize('SUPER_ADMIN', 'ADMIN'));

router.get('/overview', c.getOverview);
router.get('/appointments', c.getAppointments);
router.get('/revenue', c.getRevenue);
router.get('/users', c.getUsers);
router.get('/doctors', c.getDoctors);
router.get('/clinics', c.getClinics);

export default router;

