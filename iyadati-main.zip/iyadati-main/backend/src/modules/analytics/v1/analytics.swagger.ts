/**
 * @swagger
 * tags:
 *   name: Analytics
 *   description: Admin dashboard analytics and statistics endpoints
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     OverviewStats:
 *       type: object
 *       properties:
 *         totalUsers:
 *           type: integer
 *           example: 1250
 *         totalDoctors:
 *           type: integer
 *           example: 85
 *         totalClinics:
 *           type: integer
 *           example: 32
 *         totalAppointments:
 *           type: integer
 *           example: 5400
 *         completedAppointments:
 *           type: integer
 *           example: 4800
 *         cancelledAppointments:
 *           type: integer
 *           example: 350
 *         pendingAppointments:
 *           type: integer
 *           example: 250
 *         totalRevenue:
 *           type: number
 *           example: 1250000
 *     AppointmentStats:
 *       type: object
 *       properties:
 *         byStatus:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               status:
 *                 type: string
 *               count:
 *                 type: integer
 *         byDate:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               date:
 *                 type: string
 *               count:
 *                 type: integer
 *         byDoctor:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               count:
 *                 type: integer
 *     RevenueStats:
 *       type: object
 *       properties:
 *         total:
 *           type: number
 *           example: 1250000
 *         byMonth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *                 example: "2026-07"
 *               amount:
 *                 type: number
 *               count:
 *                 type: integer
 *     UserStats:
 *       type: object
 *       properties:
 *         total:
 *           type: integer
 *         newThisMonth:
 *           type: integer
 *         byTrustLevel:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               level:
 *                 type: integer
 *               count:
 *                 type: integer
 *         byWilaya:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               wilayaId:
 *                 type: string
 *               wilayaName:
 *                 type: string
 *               count:
 *                 type: integer
 *     DoctorStats:
 *       type: object
 *       properties:
 *         topByAppointments:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               count:
 *                 type: integer
 *               avgRating:
 *                 type: number
 *                 nullable: true
 *         topByRating:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               avgRating:
 *                 type: number
 *                 nullable: true
 *               totalReviews:
 *                 type: integer
 *     ClinicStats:
 *       type: object
 *       properties:
 *         topByAppointments:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               clinicId:
 *                 type: string
 *               clinicName:
 *                 type: string
 *               count:
 *                 type: integer
 *               avgRating:
 *                 type: number
 *                 nullable: true
 *         topByRating:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               clinicId:
 *                 type: string
 *               clinicName:
 *                 type: string
 *               avgRating:
 *                 type: number
 *                 nullable: true
 *               totalReviews:
 *                 type: integer
 */

/**
 * @swagger
 * /api/v1/analytics/v1/overview:
 *   get:
 *     summary: Get overview statistics (Admin)
 *     description: Returns total counts for users, doctors, clinics, appointments, and total revenue.
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/OverviewStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v1/appointments:
 *   get:
 *     summary: Get appointment statistics (Admin)
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 30
 *         description: Number of days to analyze
 *     responses:
 *       200:
 *         description: Appointment stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v1/revenue:
 *   get:
 *     summary: Get revenue statistics (Admin)
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Revenue stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/RevenueStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v1/users:
 *   get:
 *     summary: Get user statistics (Admin)
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: User stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v1/doctors:
 *   get:
 *     summary: Get top doctors statistics (Admin)
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Doctor stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v1/clinics:
 *   get:
 *     summary: Get top clinics statistics (Admin)
 *     tags: [Analytics]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Clinic stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ClinicStats'
 */