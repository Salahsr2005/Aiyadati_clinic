// backend/src/modules/analytics/v1/analytics.service.ts
import { prisma } from '../../../core/utils/prisma';
import { creditPriceRepository } from '../../../repositories/credit-price.repository';
import { OverviewStats, AppointmentStats, RevenueStats, UserStats, DoctorStats, ClinicStats } from './analytics.types';

// ============================================================
// ✅ HELPER: Safe string conversion
// ============================================================

function safeString(value: string | null | undefined): string {
  return value || '';
}

export class AnalyticsService {

  async getOverview(): Promise<OverviewStats> {
    const [users, doctors, clinics, appointments, completedAppointments, cancelledAppointments, pendingAppointments] = await Promise.all([
      prisma.user.count(),
      prisma.doctor.count({ where: { isVerified: true } }),
      prisma.clinic.count({ where: { isVerified: true } }),
      prisma.appointment.count(),
      prisma.appointment.count({ where: { status: 'COMPLETED' } }),
      prisma.appointment.count({ where: { status: 'CANCELLED' } }),
      prisma.appointment.count({ where: { status: 'CONFIRMED' } }),
    ]);

    const revenueResult = await prisma.creditTransaction.aggregate({
      where: { type: 'purchase' },
      _sum: { amount: true },
    });

    const creditPrice = await creditPriceRepository.getCurrentPrice();

    return {
      totalUsers: users,
      totalDoctors: doctors,
      totalClinics: clinics,
      totalAppointments: appointments,
      completedAppointments,
      cancelledAppointments,
      pendingAppointments,
      totalRevenue: (revenueResult._sum.amount || 0) * creditPrice,
    };
  }

  async getAppointmentStats(days = 30): Promise<AppointmentStats> {
    const byStatus = await prisma.appointment.groupBy({
      by: ['status'],
      _count: { status: true },
    });

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const byDate = await prisma.appointment.groupBy({
      by: ['createdAt'],
      where: { createdAt: { gte: startDate } },
      _count: { id: true },
      orderBy: { createdAt: 'asc' },
    });

    const byDoctor = await prisma.appointment.groupBy({
      by: ['doctorId'],
      _count: { doctorId: true },
      orderBy: { _count: { doctorId: 'desc' } },
      take: 10,
    });

    const doctorIds = byDoctor.map(d => d.doctorId);
    const doctors = await prisma.doctor.findMany({
      where: { id: { in: doctorIds } },
      select: { id: true, firstNameFr: true, lastNameFr: true },
    });

    return {
      byStatus: byStatus.map(s => ({ status: s.status, count: s._count.status })),
      byDate: byDate.map(d => ({ date: d.createdAt.toISOString().slice(0, 10), count: d._count.id })),
      byDoctor: byDoctor.map(d => {
        const doc = doctors.find(dd => dd.id === d.doctorId);
        return { doctorId: d.doctorId, doctorName: doc ? `${doc.firstNameFr} ${doc.lastNameFr}` : 'Unknown', count: d._count.doctorId };
      }),
    };
  }

  async getRevenueStats(): Promise<RevenueStats> {
    const total = await prisma.creditTransaction.aggregate({
      where: { type: 'purchase' },
      _sum: { amount: true },
    });

    const creditPrice = await creditPriceRepository.getCurrentPrice();

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const transactions = await prisma.creditTransaction.findMany({
      where: { type: 'purchase', createdAt: { gte: sixMonthsAgo } },
      orderBy: { createdAt: 'asc' },
    });

    const byMonth: Record<string, { amount: number; count: number }> = {};
    for (const t of transactions) {
      const month = t.createdAt.toISOString().slice(0, 7);
      if (!byMonth[month]) byMonth[month] = { amount: 0, count: 0 };
      byMonth[month].amount += t.amount * creditPrice;
      byMonth[month].count += t.amount;
    }

    return {
      total: (total._sum.amount || 0) * creditPrice,
      byMonth: Object.entries(byMonth).map(([month, data]) => ({ month, ...data })),
    };
  }

  async getUserStats(): Promise<UserStats> {
    const total = await prisma.user.count();

    const thisMonth = new Date();
    thisMonth.setDate(1);
    thisMonth.setHours(0, 0, 0, 0);

    const newThisMonth = await prisma.user.count({
      where: { createdAt: { gte: thisMonth } },
    });

    const byTrustLevel = await prisma.user.groupBy({
      by: ['trustLevel'],
      _count: { trustLevel: true },
    });

    const byWilaya = await prisma.user.groupBy({
      by: ['wilayaId'],
      _count: { wilayaId: true },
      orderBy: { _count: { wilayaId: 'desc' } },
      take: 10,
    });

    // ✅ FIX: Filter out null wilayaId
    const wilayaIds = byWilaya.map(w => w.wilayaId).filter((id): id is string => id !== null);
    const wilayas = await prisma.wilaya.findMany({
      where: { id: { in: wilayaIds } },
      select: { id: true, nameFr: true },
    });

    return {
      total,
      newThisMonth,
      byTrustLevel: byTrustLevel.map(t => ({ level: t.trustLevel, count: t._count.trustLevel })),
      byWilaya: byWilaya.map(w => ({
        wilayaId: w.wilayaId || 'unknown',
        wilayaName: w.wilayaId ? (wilayas.find(ww => ww.id === w.wilayaId)?.nameFr || 'Unknown') : 'Unknown',
        count: w._count.wilayaId,
      })),
    };
  }

  async getDoctorStats(): Promise<DoctorStats> {
    const topByAppointments = await prisma.appointment.groupBy({
      by: ['doctorId'],
      _count: { doctorId: true },
      orderBy: { _count: { doctorId: 'desc' } },
      take: 10,
    });

    const topByRating = await prisma.doctor.findMany({
      where: { isVerified: true, totalReviews: { gt: 0 } },
      orderBy: { avgRating: 'desc' },
      take: 10,
      select: { id: true, firstNameFr: true, lastNameFr: true, avgRating: true, totalReviews: true },
    });

    const docIds = topByAppointments.map(d => d.doctorId);
    const doctors = await prisma.doctor.findMany({
      where: { id: { in: docIds } },
      select: { id: true, firstNameFr: true, lastNameFr: true, avgRating: true },
    });

    return {
      topByAppointments: topByAppointments.map(d => {
        const doc = doctors.find(dd => dd.id === d.doctorId);
        return { doctorId: d.doctorId, doctorName: doc ? `${doc.firstNameFr} ${doc.lastNameFr}` : 'Unknown', count: d._count.doctorId, avgRating: doc?.avgRating || null };
      }),
      topByRating: topByRating.map(d => ({
        doctorId: d.id, doctorName: `${d.firstNameFr} ${d.lastNameFr}`, avgRating: d.avgRating, totalReviews: d.totalReviews,
      })),
    };
  }

  async getClinicStats(): Promise<ClinicStats> {
    const topByAppointments = await prisma.appointment.groupBy({
      by: ['clinicId'],
      where: { clinicId: { not: null } },
      _count: { clinicId: true },
      orderBy: { _count: { clinicId: 'desc' } },
      take: 10,
    });

    const topByRating = await prisma.clinic.findMany({
      where: { isVerified: true, totalReviews: { gt: 0 } },
      orderBy: { avgRating: 'desc' },
      take: 10,
      select: { id: true, nameFr: true, avgRating: true, totalReviews: true },
    });

    // ✅ FIX: Filter out null clinicId
    const clinicIds = topByAppointments.map(c => c.clinicId).filter((id): id is string => id !== null);
    const clinics = await prisma.clinic.findMany({
      where: { id: { in: clinicIds } },
      select: { id: true, nameFr: true, avgRating: true },
    });

    return {
      topByAppointments: topByAppointments.map(c => {
        const clinic = clinics.find(cc => cc.id === c.clinicId);
        return { 
          clinicId: c.clinicId!, 
          clinicName: clinic?.nameFr || 'Unknown', 
          count: c._count.clinicId, 
          avgRating: clinic?.avgRating || null 
        };
      }),
      topByRating: topByRating.map(c => ({
        clinicId: c.id, clinicName: c.nameFr, avgRating: c.avgRating, totalReviews: c.totalReviews,
      })),
    };
  }
}

export const analyticsService = new AnalyticsService();

