import { Request, Response, NextFunction } from 'express';
import { analyticsService } from './analytics.service';
import { ResponseUtil } from '../../../core/utils/response';

export class AnalyticsController {
  getOverview = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getOverview(); ResponseUtil.success(res, data, 'Overview retrieved'); } catch (error) { next(error); }
  };
  getAppointments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getAppointmentStats(parseInt(req.query.days as string) || 30); ResponseUtil.success(res, data, 'Appointment stats retrieved'); } catch (error) { next(error); }
  };
  getRevenue = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getRevenueStats(); ResponseUtil.success(res, data, 'Revenue stats retrieved'); } catch (error) { next(error); }
  };
  getUsers = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getUserStats(); ResponseUtil.success(res, data, 'User stats retrieved'); } catch (error) { next(error); }
  };
  getDoctors = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getDoctorStats(); ResponseUtil.success(res, data, 'Doctor stats retrieved'); } catch (error) { next(error); }
  };
  getClinics = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const data = await analyticsService.getClinicStats(); ResponseUtil.success(res, data, 'Clinic stats retrieved'); } catch (error) { next(error); }
  };
}

