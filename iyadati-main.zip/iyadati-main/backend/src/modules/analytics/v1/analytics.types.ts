export interface OverviewStats {
  totalUsers: number;
  totalDoctors: number;
  totalClinics: number;
  totalAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  pendingAppointments: number;
  totalRevenue: number;
}

export interface AppointmentStats {
  byStatus: { status: string; count: number }[];
  byDate: { date: string; count: number }[];
  byDoctor: { doctorId: string; doctorName: string; count: number }[];
}

export interface RevenueStats {
  total: number;
  byMonth: { month: string; amount: number; count: number }[];
}

export interface UserStats {
  total: number;
  newThisMonth: number;
  byTrustLevel: { level: number; count: number }[];
  byWilaya: { wilayaId: string; wilayaName: string; count: number }[];
}

export interface DoctorStats {
  topByAppointments: { doctorId: string; doctorName: string; count: number; avgRating: number | null }[];
  topByRating: { doctorId: string; doctorName: string; avgRating: number | null; totalReviews: number }[];
}

export interface ClinicStats {
  topByAppointments: { clinicId: string; clinicName: string; count: number; avgRating: number | null }[];
  topByRating: { clinicId: string; clinicName: string; avgRating: number | null; totalReviews: number }[];
}

