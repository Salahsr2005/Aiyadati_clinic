import { Router } from 'express';
import analyticsRoutes from './v1/analytics.routes';
import analyticsRoutes2 from './v2/analytics.routes'
const router = Router();
router.use('/v1', analyticsRoutes);
router.use('/v2',analyticsRoutes2)
export { router as analyticsModule };

