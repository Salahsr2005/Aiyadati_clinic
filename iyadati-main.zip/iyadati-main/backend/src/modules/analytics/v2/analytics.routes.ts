// backend/src/modules/analytics/v2/analytics.routes.ts

import { Router } from 'express';
import { AnalyticsController } from './analytics.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new AnalyticsController();

// All routes require admin authentication
router.use(authenticate, authorize('SUPER_ADMIN', 'ADMIN'));

// ================================
// OVERVIEW & DASHBOARD
// ================================
router.get('/overview', controller.getOverview);
router.get('/overview/advanced', controller.getAdvancedOverview);
router.get('/realtime', controller.getRealtimeDashboard);

// ================================
// DOCTOR ANALYTICS
// ================================
router.get('/doctors/overview', controller.getDoctorOverview);
router.get('/doctors/top', controller.getTopDoctors);
router.get('/doctors/comparison', controller.getDoctorsComparison);
router.get('/doctors/:doctorId/details', controller.getDoctorDetails);
router.get('/doctors/:doctorId/revenue', controller.getDoctorRevenue);
router.get('/doctors/:doctorId/retention', controller.getDoctorRetention);

// ================================
// CLINIC ANALYTICS
// ================================
router.get('/clinics/overview', controller.getClinicOverview);
router.get('/clinics/comparison', controller.getClinicsComparison);
router.get('/clinics/:clinicId/details', controller.getClinicDetails);

// ================================
// USER/PATIENT ANALYTICS
// ================================
router.get('/users/overview', controller.getUserOverview);
router.get('/users/retention', controller.getUserRetention);
router.get('/users/:userId/details', controller.getUserDetails);

// ================================
// APPOINTMENT ANALYTICS
// ================================
router.get('/appointments/overview', controller.getAppointmentAnalytics);
router.get('/appointments/cancellations', controller.getCancellationAnalysis);
router.get('/appointments/no-shows', controller.getNoShowAnalysis);

// ================================
// FINANCIAL ANALYTICS
// ================================
router.get('/financial/overview', controller.getFinancialOverview);

// ================================
// GROWTH ANALYTICS
// ================================
router.get('/growth/metrics', controller.getGrowthMetrics);

// ================================
// COMPARATIVE ANALYTICS
// ================================
router.post('/compare', controller.getComparativeAnalytics);

// ================================
// EXPORT
// ================================
router.post('/export', controller.exportAnalytics);

export default router;

