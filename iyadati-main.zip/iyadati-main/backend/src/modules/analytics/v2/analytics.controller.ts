// backend/src/modules/analytics/v2/analytics.controller.ts

import { Request, Response, NextFunction } from 'express';
import { analyticsService } from './analytics.service';
import { ResponseUtil } from '../../../core/utils/response';

export class AnalyticsController {
  
  // ================================
  // OVERVIEW & DASHBOARD
  // ================================
  
  getOverview = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await analyticsService.getOverview();
      ResponseUtil.success(res, data, 'Overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  getAdvancedOverview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getAdvancedOverview(dateRange);
      ResponseUtil.success(res, data, 'Advanced overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  getRealtimeDashboard = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await analyticsService.getRealtimeDashboard();
      ResponseUtil.success(res, data, 'Real-time dashboard data retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // DOCTOR ANALYTICS
  // ================================
  
  getDoctorOverview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = {
        doctorIds: req.query.doctorIds ? (req.query.doctorIds as string).split(',') : undefined,
        specialtyIds: req.query.specialtyIds ? (req.query.specialtyIds as string).split(',') : undefined,
        practiceType: req.query.practiceType as any,
        wilayaIds: req.query.wilayaIds ? (req.query.wilayaIds as string).split(',') : undefined,
        isVerified: req.query.isVerified !== undefined ? req.query.isVerified === 'true' : undefined,
        isSuspended: req.query.isSuspended !== undefined ? req.query.isSuspended === 'true' : undefined,
        minRating: req.query.minRating ? parseFloat(req.query.minRating as string) : undefined,
        maxRating: req.query.maxRating ? parseFloat(req.query.maxRating as string) : undefined,
      };
      const data = await analyticsService.getDoctorOverview(filters);
      ResponseUtil.success(res, data, 'Doctor overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  getDoctorDetails = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getDoctorDetails(doctorId, dateRange);
      ResponseUtil.success(res, data, 'Doctor details retrieved');
    } catch (error) {
      next(error);
    }
  };

  getTopDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const metric = (req.query.metric as string) || 'appointments';
      const limit = parseInt(req.query.limit as string) || 10;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getTopDoctors(metric, limit, dateRange);
      ResponseUtil.success(res, data, 'Top doctors retrieved');
    } catch (error) {
      next(error);
    }
  };

  getDoctorsComparison = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorIds, metrics } = req.body;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getDoctorsComparison(doctorIds, metrics, dateRange);
      ResponseUtil.success(res, data, 'Doctors comparison retrieved');
    } catch (error) {
      next(error);
    }
  };

  getDoctorRevenue = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getDoctorRevenueAnalytics(doctorId, dateRange);
      ResponseUtil.success(res, data, 'Doctor revenue analytics retrieved');
    } catch (error) {
      next(error);
    }
  };

  getDoctorRetention = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctorId } = req.params;
      const data = await analyticsService.getDoctorRetention(doctorId);
      ResponseUtil.success(res, data, 'Doctor retention stats retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // CLINIC ANALYTICS
  // ================================
  
  getClinicOverview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = {
        clinicIds: req.query.clinicIds ? (req.query.clinicIds as string).split(',') : undefined,
        facilityType: req.query.facilityType as any,
        wilayaIds: req.query.wilayaIds ? (req.query.wilayaIds as string).split(',') : undefined,
        isVerified: req.query.isVerified !== undefined ? req.query.isVerified === 'true' : undefined,
        isSuspended: req.query.isSuspended !== undefined ? req.query.isSuspended === 'true' : undefined,
        minRating: req.query.minRating ? parseFloat(req.query.minRating as string) : undefined,
        maxRating: req.query.maxRating ? parseFloat(req.query.maxRating as string) : undefined,
      };
      const data = await analyticsService.getClinicOverview(filters);
      ResponseUtil.success(res, data, 'Clinic overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  getClinicDetails = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { clinicId } = req.params;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getClinicDetails(clinicId, dateRange);
      ResponseUtil.success(res, data, 'Clinic details retrieved');
    } catch (error) {
      next(error);
    }
  };

  getClinicsComparison = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { clinicIds, metrics } = req.body;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.compareClinics(clinicIds, metrics, dateRange);
      ResponseUtil.success(res, data, 'Clinics comparison retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // USER/PATIENT ANALYTICS
  // ================================
  
  getUserOverview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = {
        userIds: req.query.userIds ? (req.query.userIds as string).split(',') : undefined,
        wilayaIds: req.query.wilayaIds ? (req.query.wilayaIds as string).split(',') : undefined,
        trustLevels: req.query.trustLevels ? (req.query.trustLevels as string).split(',').map(Number) : undefined,
        isVerified: req.query.isVerified !== undefined ? req.query.isVerified === 'true' : undefined,
        isSuspended: req.query.isSuspended !== undefined ? req.query.isSuspended === 'true' : undefined,
      };
      const data = await analyticsService.getUserOverview(filters);
      ResponseUtil.success(res, data, 'User overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  getUserDetails = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { userId } = req.params;
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getUserDetails(userId, dateRange);
      ResponseUtil.success(res, data, 'User details retrieved');
    } catch (error) {
      next(error);
    }
  };

  getUserRetention = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await analyticsService.getUserRetention();
      ResponseUtil.success(res, data, 'User retention stats retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // APPOINTMENT ANALYTICS
  // ================================
  
  getAppointmentAnalytics = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const filters = {
        statuses: req.query.statuses ? (req.query.statuses as string).split(',') : undefined,
        types: req.query.types ? (req.query.types as string).split(',') : undefined,
        paymentMethods: req.query.paymentMethods ? (req.query.paymentMethods as string).split(',') : undefined,
        slotDateFrom: req.query.slotDateFrom as string,
        slotDateTo: req.query.slotDateTo as string,
      };
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getAppointmentAnalytics(filters, dateRange);
      ResponseUtil.success(res, data, 'Appointment analytics retrieved');
    } catch (error) {
      next(error);
    }
  };

  getCancellationAnalysis = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getCancellationAnalysis(dateRange);
      ResponseUtil.success(res, data, 'Cancellation analysis retrieved');
    } catch (error) {
      next(error);
    }
  };

  getNoShowAnalysis = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getNoShowAnalysis(dateRange);
      ResponseUtil.success(res, data, 'No-show analysis retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // FINANCIAL ANALYTICS
  // ================================
  
  getFinancialOverview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const dateRange = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        period: req.query.period as any,
      };
      const data = await analyticsService.getFinancialOverview(dateRange);
      ResponseUtil.success(res, data, 'Financial overview retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // GROWTH ANALYTICS
  // ================================
  
  getGrowthMetrics = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await analyticsService.getGrowthMetrics();
      ResponseUtil.success(res, data, 'Growth metrics retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // COMPARATIVE ANALYTICS
  // ================================
  
  getComparativeAnalytics = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { period1, period2, metrics } = req.body;
      const data = await analyticsService.getComparativeAnalytics({
        period1,
        period2,
        metrics,
      });
      ResponseUtil.success(res, data, 'Comparative analytics retrieved');
    } catch (error) {
      next(error);
    }
  };

  // ================================
  // EXPORT
  // ================================
  
  exportAnalytics = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { type, format = 'csv', filters } = req.body;
      const data = await analyticsService.exportAnalytics(type, format, filters);
      
      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=analytics_${type}_${Date.now()}.csv`);
        res.send(data);
      } else {
        ResponseUtil.success(res, data, 'Export generated');
      }
    } catch (error) {
      next(error);
    }
  };
}