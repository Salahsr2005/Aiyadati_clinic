/**
 * @swagger
 * tags:
 *   name: Analytics V2
 *   description: Advanced admin dashboard analytics with detailed filtering, comparisons, and exports
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     DateRangeFilter:
 *       type: object
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *           example: "2026-01-01"
 *         endDate:
 *           type: string
 *           format: date
 *           example: "2026-07-19"
 *         period:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth, thisYear, custom]
 *           example: "last30days"
 *     
 *     OverviewStats:
 *       type: object
 *       properties:
 *         totalUsers:
 *           type: integer
 *           example: 1250
 *         totalDoctors:
 *           type: integer
 *           example: 85
 *         totalClinics:
 *           type: integer
 *           example: 32
 *         totalAppointments:
 *           type: integer
 *           example: 5400
 *         completedAppointments:
 *           type: integer
 *           example: 4800
 *         cancelledAppointments:
 *           type: integer
 *           example: 350
 *         pendingAppointments:
 *           type: integer
 *           example: 250
 *         totalRevenue:
 *           type: number
 *           example: 1250000
 *
 *     AdvancedOverview:
 *       type: object
 *       properties:
 *         currentPeriod:
 *           type: object
 *           properties:
 *             appointments:
 *               type: integer
 *             completedAppointments:
 *               type: integer
 *             revenue:
 *               type: number
 *             newUsers:
 *               type: integer
 *             newDoctors:
 *               type: integer
 *         changes:
 *           type: object
 *           properties:
 *             appointments:
 *               type: number
 *               description: Percentage change
 *             trend:
 *               type: string
 *               enum: [up, down, stable]
 *         today:
 *           type: object
 *           properties:
 *             appointments:
 *               type: integer
 *             revenue:
 *               type: number
 *             activeDoctors:
 *               type: integer
 *             newUsers:
 *               type: integer
 *         averages:
 *           type: object
 *           properties:
 *             appointmentsPerDay:
 *               type: number
 *             revenuePerDay:
 *               type: number
 *
 *     RealtimeStats:
 *       type: object
 *       properties:
 *         activeUsers:
 *           type: integer
 *         appointmentsToday:
 *           type: object
 *           properties:
 *             scheduled:
 *               type: integer
 *             completed:
 *               type: integer
 *             inProgress:
 *               type: integer
 *         revenueToday:
 *           type: number
 *         onlineDoctors:
 *           type: integer
 *         waitingPatients:
 *           type: integer
 *         averageWaitTime:
 *           type: number
 *         alerts:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [warning, critical, info]
 *               message:
 *                 type: string
 *               timestamp:
 *                 type: string
 *
 *     DoctorOverview:
 *       type: object
 *       properties:
 *         totals:
 *           type: object
 *           properties:
 *             totalDoctors:
 *               type: integer
 *             verifiedDoctors:
 *               type: integer
 *             suspendedDoctors:
 *               type: integer
 *             verificationRate:
 *               type: number
 *             avgRating:
 *               type: number
 *             reviewedDoctors:
 *               type: integer
 *         bySpecialty:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               specialtyId:
 *                 type: string
 *               specialtyName:
 *                 type: string
 *               count:
 *                 type: integer
 *         byPracticeType:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *               count:
 *                 type: integer
 *         byWilaya:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               wilayaId:
 *                 type: string
 *               wilayaName:
 *                 type: string
 *               count:
 *                 type: integer
 *
 *     DoctorDetailedStats:
 *       type: object
 *       properties:
 *         totalAppointments:
 *           type: integer
 *         completedAppointments:
 *           type: integer
 *         cancelledAppointments:
 *           type: integer
 *         noShowAppointments:
 *           type: integer
 *         completionRate:
 *           type: number
 *         cancellationRate:
 *           type: number
 *         noShowRate:
 *           type: number
 *         avgRating:
 *           type: number
 *         totalReviews:
 *           type: integer
 *         totalRevenue:
 *           type: number
 *         avgRevenuePerAppointment:
 *           type: number
 *         uniquePatients:
 *           type: integer
 *         returningPatients:
 *           type: integer
 *         retentionRate:
 *           type: number
 *         appointmentTypeDistribution:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *         monthlyTrends:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               revenue:
 *                 type: number
 *         patientDemographics:
 *           type: object
 *           properties:
 *             byWilaya:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   wilayaId:
 *                     type: string
 *                   wilayaName:
 *                     type: string
 *                   count:
 *                     type: integer
 *         peakHours:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               hour:
 *                 type: integer
 *               count:
 *                 type: integer
 *         busiestDays:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *
 *     ClinicOverview:
 *       type: object
 *       properties:
 *         totals:
 *           type: object
 *           properties:
 *             totalClinics:
 *               type: integer
 *             verifiedClinics:
 *               type: integer
 *             suspendedClinics:
 *               type: integer
 *             verificationRate:
 *               type: number
 *         byFacilityType:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *               count:
 *                 type: integer
 *         byWilaya:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               wilayaId:
 *                 type: string
 *               wilayaName:
 *                 type: string
 *               count:
 *                 type: integer
 *         topRated:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               nameFr:
 *                 type: string
 *               avgRating:
 *                 type: number
 *               totalReviews:
 *                 type: integer
 *         mostAppointments:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               clinicId:
 *                 type: string
 *               clinicName:
 *                 type: string
 *               count:
 *                 type: integer
 *               avgRating:
 *                 type: number
 *
 *     ClinicDetailedStats:
 *       type: object
 *       properties:
 *         totalAppointments:
 *           type: integer
 *         totalDoctors:
 *           type: integer
 *         activeDoctors:
 *           type: integer
 *         totalRooms:
 *           type: integer
 *         avgRating:
 *           type: number
 *         totalReviews:
 *           type: integer
 *         totalRevenue:
 *           type: number
 *         avgRevenuePerDoctor:
 *           type: number
 *         doctorPerformance:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               revenue:
 *                 type: number
 *               avgRating:
 *                 type: number
 *         appointmentTypeDistribution:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *         monthlyTrends:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               revenue:
 *                 type: number
 *               newPatients:
 *                 type: integer
 *         patientSatisfaction:
 *           type: object
 *           properties:
 *             avgRating:
 *               type: number
 *             ratingDistribution:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   rating:
 *                     type: integer
 *                   count:
 *                     type: integer
 *         peakHours:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               hour:
 *                 type: integer
 *               count:
 *                 type: integer
 *         busiestDays:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *
 *     UserOverview:
 *       type: object
 *       properties:
 *         totals:
 *           type: object
 *           properties:
 *             totalUsers:
 *               type: integer
 *             verifiedUsers:
 *               type: integer
 *             suspendedUsers:
 *               type: integer
 *             verificationRate:
 *               type: number
 *             newToday:
 *               type: integer
 *         byTrustLevel:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               level:
 *                 type: integer
 *               label:
 *                 type: string
 *               count:
 *                 type: integer
 *         byWilaya:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               wilayaId:
 *                 type: string
 *               wilayaName:
 *                 type: string
 *               count:
 *                 type: integer
 *
 *     UserDetailedStats:
 *       type: object
 *       properties:
 *         totalAppointments:
 *           type: integer
 *         completedAppointments:
 *           type: integer
 *         cancelledAppointments:
 *           type: integer
 *         noShowCount:
 *           type: integer
 *         cancellationRate:
 *           type: number
 *         noShowRate:
 *           type: number
 *         trustPoints:
 *           type: integer
 *         trustLevel:
 *           type: integer
 *         totalSpent:
 *           type: number
 *         avgSpentPerAppointment:
 *           type: number
 *         walletBalance:
 *           type: integer
 *         favoriteDoctors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               lastAppointment:
 *                 type: string
 *         favoriteClinics:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               clinicId:
 *                 type: string
 *               clinicName:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               lastAppointment:
 *                 type: string
 *         appointmentTypes:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *         monthlyActivity:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               spent:
 *                 type: number
 *         timeSlots:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               hour:
 *                 type: integer
 *               count:
 *                 type: integer
 *         dayPreference:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *         avgAdvanceBookingDays:
 *           type: number
 *         documentsCount:
 *           type: integer
 *         contactUsersCount:
 *           type: integer
 *         reviewsGiven:
 *           type: integer
 *
 *     AppointmentAnalytics:
 *       type: object
 *       properties:
 *         totalAppointments:
 *           type: integer
 *         byStatus:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               status:
 *                 type: string
 *               count:
 *                 type: integer
 *               percentage:
 *                 type: number
 *         byType:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *               count:
 *                 type: integer
 *               percentage:
 *                 type: number
 *         byPaymentMethod:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               method:
 *                 type: string
 *               count:
 *                 type: integer
 *               percentage:
 *                 type: number
 *         byDayOfWeek:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *         byHour:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               hour:
 *                 type: integer
 *               count:
 *                 type: integer
 *         noShowRate:
 *           type: number
 *         cancellationRate:
 *           type: number
 *         monthlyTrends:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               total:
 *                 type: integer
 *               completed:
 *                 type: integer
 *               cancelled:
 *                 type: integer
 *
 *     FinancialStats:
 *       type: object
 *       properties:
 *         totalRevenue:
 *           type: number
 *         totalCreditsSold:
 *           type: integer
 *         totalTransactions:
 *           type: integer
 *         avgTransactionValue:
 *           type: number
 *         revenueByMonth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               revenue:
 *                 type: number
 *               transactions:
 *                 type: integer
 *         revenueByWilaya:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               wilayaId:
 *                 type: string
 *               wilayaName:
 *                 type: string
 *               revenue:
 *                 type: number
 *         topSpenders:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               userId:
 *                 type: string
 *               userName:
 *                 type: string
 *               totalSpent:
 *                 type: number
 *         creditUtilization:
 *           type: object
 *           properties:
 *             purchased:
 *               type: integer
 *             used:
 *               type: integer
 *             refunded:
 *               type: integer
 *             active:
 *               type: integer
 *             utilizationRate:
 *               type: number
 *         arpu:
 *           type: number
 *         arppu:
 *           type: number
 *         conversionRate:
 *           type: number
 *
 *     GrowthStats:
 *       type: object
 *       properties:
 *         userGrowth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               newUsers:
 *                 type: integer
 *               totalUsers:
 *                 type: integer
 *               growthRate:
 *                 type: number
 *         doctorGrowth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               newDoctors:
 *                 type: integer
 *               totalDoctors:
 *                 type: integer
 *               growthRate:
 *                 type: number
 *         clinicGrowth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               newClinics:
 *                 type: integer
 *               totalClinics:
 *                 type: integer
 *               growthRate:
 *                 type: number
 *         appointmentGrowth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               appointments:
 *                 type: integer
 *               growthRate:
 *                 type: number
 *         revenueGrowth:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               month:
 *                 type: string
 *               revenue:
 *                 type: number
 *               growthRate:
 *                 type: number
 *
 *     RetentionStats:
 *       type: object
 *       properties:
 *         overallRetentionRate:
 *           type: number
 *         cohortRetention:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               cohort:
 *                 type: string
 *               size:
 *                 type: integer
 *               month1:
 *                 type: integer
 *               month2:
 *                 type: integer
 *               month3:
 *                 type: integer
 *               month6:
 *                 type: integer
 *         userSegments:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               segment:
 *                 type: string
 *               count:
 *                 type: integer
 *               percentage:
 *                 type: number
 *
 *     CancellationAnalysis:
 *       type: object
 *       properties:
 *         reasons:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               reason:
 *                 type: string
 *               count:
 *                 type: integer
 *         byDay:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *         topDoctorsWithCancellations:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               doctorName:
 *                 type: string
 *               count:
 *                 type: integer
 *         topPatientsWithCancellations:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               patientId:
 *                 type: string
 *               count:
 *                 type: integer
 *
 *     NoShowAnalysis:
 *       type: object
 *       properties:
 *         totalNoShows:
 *           type: integer
 *         noShowRate:
 *           type: number
 *         byDoctor:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               doctorId:
 *                 type: string
 *               count:
 *                 type: integer
 *         byPatient:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               patientId:
 *                 type: string
 *               count:
 *                 type: integer
 *         byDay:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               day:
 *                 type: string
 *               count:
 *                 type: integer
 *         byTime:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               hour:
 *                 type: integer
 *               count:
 *                 type: integer
 *
 *     ComparisonResponse:
 *       type: object
 *       properties:
 *         period1:
 *           type: object
 *           additionalProperties:
 *             type: number
 *         period2:
 *           type: object
 *           additionalProperties:
 *             type: number
 *         changes:
 *           type: object
 *           additionalProperties:
 *             type: object
 *             properties:
 *               absolute:
 *                 type: number
 *               percentage:
 *                 type: number
 *               trend:
 *                 type: string
 *                 enum: [up, down, stable]
 *
 *     ErrorResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: "Error message"
 */

// ================================
// OVERVIEW & DASHBOARD ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/overview:
 *   get:
 *     summary: Get basic overview statistics
 *     description: Returns total counts for users, doctors, clinics, appointments, and total revenue. Quick snapshot for dashboard.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Overview retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/OverviewStats'
 *                 message:
 *                   type: string
 *                   example: "Overview retrieved"
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/overview/advanced:
 *   get:
 *     summary: Get advanced overview with trends and comparisons
 *     description: Returns detailed statistics with period-over-period comparisons, today's metrics, and daily averages.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth, thisYear]
 *         description: Predefined time period
 *         example: "last30days"
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date (YYYY-MM-DD). Use with endDate for custom ranges.
 *         example: "2026-01-01"
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date (YYYY-MM-DD)
 *         example: "2026-07-19"
 *     responses:
 *       200:
 *         description: Advanced overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AdvancedOverview'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/realtime:
 *   get:
 *     summary: Get real-time dashboard data
 *     description: Returns live metrics including today's appointments, active doctors, waiting patients, and system alerts.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Real-time dashboard data retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/RealtimeStats'
 */

// ================================
// DOCTOR ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/overview:
 *   get:
 *     summary: Get doctor overview with filters
 *     description: Returns aggregated doctor statistics with optional filtering by specialty, wilaya, practice type, ratings, and verification status.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: specialtyIds
 *         schema:
 *           type: string
 *         description: Comma-separated specialty IDs to filter
 *         example: "spec-1,spec-2"
 *       - in: query
 *         name: practiceType
 *         schema:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *         description: Filter by practice type
 *       - in: query
 *         name: wilayaIds
 *         schema:
 *           type: string
 *         description: Comma-separated wilaya IDs
 *         example: "wilaya-1,wilaya-2"
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *         description: Filter by verification status
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *         description: Filter by suspension status
 *       - in: query
 *         name: minRating
 *         schema:
 *           type: number
 *         description: Minimum average rating filter
 *         example: 4.0
 *       - in: query
 *         name: maxRating
 *         schema:
 *           type: number
 *         description: Maximum average rating filter
 *         example: 5.0
 *     responses:
 *       200:
 *         description: Doctor overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorOverview'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/top:
 *   get:
 *     summary: Get top performing doctors
 *     description: Returns top doctors ranked by different metrics (appointments, rating, patients, revenue).
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: metric
 *         schema:
 *           type: string
 *           enum: [appointments, rating, patients]
 *           default: appointments
 *         description: Metric to rank doctors by
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of top doctors to return
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period for ranking
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Top doctors retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       doctorId:
 *                         type: string
 *                       doctorName:
 *                         type: string
 *                       count:
 *                         type: integer
 *                       avgRating:
 *                         type: number
 */

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/comparison:
 *   post:
 *     summary: Compare multiple doctors
 *     description: Compare multiple doctors across different metrics with date range filtering.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period for comparison
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - doctorIds
 *               - metrics
 *             properties:
 *               doctorIds:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Array of doctor IDs to compare
 *                 example: ["doc-1", "doc-2", "doc-3"]
 *               metrics:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [appointments, revenue, patients]
 *                 description: Metrics to compare
 *                 example: ["appointments", "revenue"]
 *     responses:
 *       200:
 *         description: Doctors comparison retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       doctor:
 *                         type: object
 *                       appointments:
 *                         type: object
 *                       revenue:
 *                         type: number
 *                       patients:
 *                         type: integer
 */

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/{doctorId}/details:
 *   get:
 *     summary: Get detailed doctor analytics
 *     description: Returns comprehensive analytics for a specific doctor including appointments, revenue, patient demographics, peak hours, and monthly trends.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Doctor details retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/DoctorDetailedStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/{doctorId}/revenue:
 *   get:
 *     summary: Get doctor revenue analytics
 *     description: Returns detailed revenue breakdown, monthly trends, and growth metrics for a specific doctor.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last30days, last90days, thisMonth, lastMonth, thisYear]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Doctor revenue analytics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     summary:
 *                       type: object
 *                       properties:
 *                         totalRevenue:
 *                           type: number
 *                         totalAppointments:
 *                           type: integer
 *                         avgRevenuePerAppointment:
 *                           type: number
 *                     monthlyBreakdown:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           month:
 *                             type: string
 *                           appointments:
 *                             type: integer
 *                           revenue:
 *                             type: number
 *                           avgPerAppointment:
 *                             type: number
 *                     growth:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           month:
 *                             type: string
 *                           revenue:
 *                             type: number
 *                           growth:
 *                             type: number
 *                           trend:
 *                             type: string
 */

/**
 * @swagger
 * /api/v1/analytics/v2/doctors/{doctorId}/retention:
 *   get:
 *     summary: Get doctor patient retention
 *     description: Returns cohort-based patient retention analysis for a specific doctor.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Doctor retention stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       cohort:
 *                         type: string
 *                       initialPatients:
 *                         type: integer
 *                       returnedPatients:
 *                         type: integer
 *                       retentionRate:
 *                         type: number
 */

// ================================
// CLINIC ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/clinics/overview:
 *   get:
 *     summary: Get clinic overview with filters
 *     description: Returns aggregated clinic statistics with optional filtering by facility type, wilaya, verification status, and ratings.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: facilityType
 *         schema:
 *           type: string
 *           enum: [CLINIC, HOSPITAL]
 *         description: Filter by facility type
 *       - in: query
 *         name: wilayaIds
 *         schema:
 *           type: string
 *         description: Comma-separated wilaya IDs
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *         description: Filter by verification status
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *         description: Filter by suspension status
 *       - in: query
 *         name: minRating
 *         schema:
 *           type: number
 *         description: Minimum average rating
 *       - in: query
 *         name: maxRating
 *         schema:
 *           type: number
 *         description: Maximum average rating
 *     responses:
 *       200:
 *         description: Clinic overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ClinicOverview'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/clinics/comparison:
 *   post:
 *     summary: Compare multiple clinics
 *     description: Compare multiple clinics across different metrics with date range filtering.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last30days, last90days, thisMonth, lastMonth]
 *         description: Time period for comparison
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - clinicIds
 *               - metrics
 *             properties:
 *               clinicIds:
 *                 type: array
 *                 items:
 *                   type: string
 *                 example: ["clinic-1", "clinic-2"]
 *               metrics:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [appointments, doctors, revenue]
 *                 example: ["appointments", "revenue"]
 *     responses:
 *       200:
 *         description: Clinics comparison retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 */

/**
 * @swagger
 * /api/v1/analytics/v2/clinics/{clinicId}/details:
 *   get:
 *     summary: Get detailed clinic analytics
 *     description: Returns comprehensive analytics for a specific clinic including appointments, doctor performance, revenue, patient satisfaction, and utilization metrics.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *         description: Clinic ID
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Clinic details retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ClinicDetailedStats'
 */

// ================================
// USER ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/users/overview:
 *   get:
 *     summary: Get user overview with filters
 *     description: Returns aggregated user statistics with filtering by wilaya, trust level, and verification status.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: wilayaIds
 *         schema:
 *           type: string
 *         description: Comma-separated wilaya IDs
 *       - in: query
 *         name: trustLevels
 *         schema:
 *           type: string
 *         description: Comma-separated trust levels (0-3)
 *         example: "1,2,3"
 *       - in: query
 *         name: isVerified
 *         schema:
 *           type: boolean
 *         description: Filter by verification status
 *       - in: query
 *         name: isSuspended
 *         schema:
 *           type: boolean
 *         description: Filter by suspension status
 *     responses:
 *       200:
 *         description: User overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserOverview'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/users/retention:
 *   get:
 *     summary: Get user retention analytics
 *     description: Returns cohort-based retention analysis and user segmentation (new, active, at-risk, lost, power users).
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: User retention stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/RetentionStats'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/users/{userId}/details:
 *   get:
 *     summary: Get detailed user analytics
 *     description: Returns comprehensive analytics for a specific user including appointment history, spending patterns, favorite doctors/clinics, and behavioral metrics.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: User ID
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: User details retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/UserDetailedStats'
 */

// ================================
// APPOINTMENT ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/appointments/overview:
 *   get:
 *     summary: Get appointment analytics with filters
 *     description: Returns comprehensive appointment statistics with filtering by status, type, payment method, and date ranges. Includes breakdowns by day, hour, and monthly trends.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: statuses
 *         schema:
 *           type: string
 *         description: Comma-separated appointment statuses
 *         example: "COMPLETED,CANCELLED,PENDING"
 *       - in: query
 *         name: types
 *         schema:
 *           type: string
 *         description: Comma-separated appointment types
 *         example: "IN_PERSON,VIDEO"
 *       - in: query
 *         name: paymentMethods
 *         schema:
 *           type: string
 *         description: Comma-separated payment methods
 *         example: "CREDIT,ON_SITE"
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [today, yesterday, last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *       - in: query
 *         name: slotDateFrom
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter appointments by slot date from
 *       - in: query
 *         name: slotDateTo
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter appointments by slot date to
 *     responses:
 *       200:
 *         description: Appointment analytics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/AppointmentAnalytics'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/appointments/cancellations:
 *   get:
 *     summary: Get cancellation analysis
 *     description: Returns detailed cancellation analysis including reasons, patterns by day, and top doctors/patients with most cancellations.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Cancellation analysis retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/CancellationAnalysis'
 */

/**
 * @swagger
 * /api/v1/analytics/v2/appointments/no-shows:
 *   get:
 *     summary: Get no-show analysis
 *     description: Returns detailed no-show analysis including rates, patterns by day/time, and top doctors/patients with most no-shows.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last7days, last30days, last90days, thisMonth, lastMonth]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: No-show analysis retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/NoShowAnalysis'
 */

// ================================
// FINANCIAL ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/financial/overview:
 *   get:
 *     summary: Get financial overview
 *     description: Returns comprehensive financial statistics including revenue, credit utilization, top spenders, ARPU, ARPPU, and conversion rates.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [last7days, last30days, last90days, thisMonth, lastMonth, thisYear]
 *         description: Time period
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom start date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: Custom end date
 *     responses:
 *       200:
 *         description: Financial overview retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/FinancialStats'
 */

// ================================
// GROWTH ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/growth/metrics:
 *   get:
 *     summary: Get growth metrics
 *     description: Returns 12-month growth trends for users, doctors, clinics, appointments, and revenue with month-over-month growth rates.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Growth metrics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/GrowthStats'
 */

// ================================
// COMPARATIVE ANALYTICS ENDPOINTS
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/compare:
 *   post:
 *     summary: Compare two time periods
 *     description: Compare metrics between two different time periods with absolute and percentage changes.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - period1
 *               - period2
 *               - metrics
 *             properties:
 *               period1:
 *                 $ref: '#/components/schemas/DateRangeFilter'
 *               period2:
 *                 $ref: '#/components/schemas/DateRangeFilter'
 *               metrics:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [appointments, revenue, newUsers, newDoctors]
 *                 description: Metrics to compare
 *                 example: ["appointments", "revenue"]
 *             example:
 *               period1:
 *                 period: "lastMonth"
 *               period2:
 *                 period: "thisMonth"
 *               metrics: ["appointments", "revenue", "newUsers"]
 *     responses:
 *       200:
 *         description: Comparative analytics retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ComparisonResponse'
 */

// ================================
// EXPORT ENDPOINT
// ================================

/**
 * @swagger
 * /api/v1/analytics/v2/export:
 *   post:
 *     summary: Export analytics data
 *     description: Export analytics data in CSV format. Supports exporting doctors, clinics, users, appointments, and financial data with filters.
 *     tags: [Analytics V2]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - type
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [doctors, clinics, users, appointments, financial]
 *                 description: Type of analytics to export
 *               format:
 *                 type: string
 *                 enum: [csv]
 *                 default: csv
 *                 description: Export format
 *               filters:
 *                 type: object
 *                 description: Optional filters to apply to the exported data
 *             example:
 *               type: "doctors"
 *               format: "csv"
 *               filters:
 *                 isVerified: true
 *                 minRating: 4.0
 *     responses:
 *       200:
 *         description: CSV file download
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *       400:
 *         description: Bad request
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */