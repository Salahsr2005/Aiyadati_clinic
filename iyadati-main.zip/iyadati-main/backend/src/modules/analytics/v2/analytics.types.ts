export interface OverviewStats {
  totalUsers: number;
  totalDoctors: number;
  totalClinics: number;
  totalAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  pendingAppointments: number;
  totalRevenue: number;
}

export interface DateRangeFilter {
  startDate?: string;
  endDate?: string;
  period?: 'today' | 'yesterday' | 'last7days' | 'last30days' | 'last90days' | 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom';
}

export interface DoctorFilter {
  doctorIds?: string[];
  specialtyIds?: string[];
  practiceType?: 'INDEPENDENT' | 'CLINIC_BASED' | 'BOTH';
  wilayaIds?: string[];
  isVerified?: boolean;
  isSuspended?: boolean;
  minRating?: number;
  maxRating?: number;
}

export interface ClinicFilter {
  clinicIds?: string[];
  facilityType?: 'CLINIC' | 'HOSPITAL';
  wilayaIds?: string[];
  isVerified?: boolean;
  isSuspended?: boolean;
  minRating?: number;
  maxRating?: number;
}

export interface UserFilter {
  userIds?: string[];
  wilayaIds?: string[];
  trustLevels?: number[];
  isVerified?: boolean;
  isSuspended?: boolean;
}

export interface AppointmentFilter {
  statuses?: string[];
  types?: string[];
  paymentMethods?: string[];
  slotDateFrom?: string;
  slotDateTo?: string;
}

export interface DoctorDetailedStats {
  totalAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  noShowAppointments: number;
  completionRate: number;
  cancellationRate: number;
  noShowRate: number;
  avgRating: number;
  totalReviews: number;
  totalRevenue: number;
  avgRevenuePerAppointment: number;
  uniquePatients: number;
  returningPatients: number;
  retentionRate: number;
  appointmentTypeDistribution: Record<string, number>;
  monthlyTrends: Array<{ month: string; appointments: number; revenue: number }>;
  patientDemographics: {
    byWilaya: Array<{ wilayaId: string; wilayaName: string; count: number }>;
  };
  peakHours: Array<{ hour: number; count: number }>;
  busiestDays: Array<{ day: string; count: number }>;
}

export interface ClinicDetailedStats {
  totalAppointments: number;
  totalDoctors: number;
  activeDoctors: number;
  totalRooms: number;
  avgRating: number;
  totalReviews: number;
  totalRevenue: number;
  avgRevenuePerDoctor: number;
  doctorPerformance: Array<{
    doctorId: string;
    doctorName: string;
    appointments: number;
    revenue: number;
    avgRating: number;
  }>;
  appointmentTypeDistribution: Record<string, number>;
  monthlyTrends: Array<{ month: string; appointments: number; revenue: number; newPatients: number }>;
  patientSatisfaction: {
    avgRating: number;
    ratingDistribution: Array<{ rating: number; count: number }>;
  };
  peakHours: Array<{ hour: number; count: number }>;
  busiestDays: Array<{ day: string; count: number }>;
}

export interface UserDetailedStats {
  totalAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  noShowCount: number;
  cancellationRate: number;
  noShowRate: number;
  trustPoints: number;
  trustLevel: number;
  totalSpent: number;
  avgSpentPerAppointment: number;
  walletBalance: number;
  favoriteDoctors: Array<{
    doctorId: string;
    doctorName: string;
    appointments: number;
    lastAppointment: string;
  }>;
  favoriteClinics: Array<{
    clinicId: string;
    clinicName: string;
    appointments: number;
    lastAppointment: string;
  }>;
  appointmentTypes: Record<string, number>;
  monthlyActivity: Array<{ month: string; appointments: number; spent: number }>;
  timeSlots: Array<{ hour: number; count: number }>;
  dayPreference: Array<{ day: string; count: number }>;
  avgAdvanceBookingDays: number;
  documentsCount: number;
  contactUsersCount: number;
  reviewsGiven: number;
}

export interface FinancialStats {
  totalRevenue: number;
  totalCreditsSold: number;
  totalTransactions: number;
  avgTransactionValue: number;
  revenueByMonth: Array<{ month: string; revenue: number; transactions: number }>;
  revenueByWilaya: Array<{ wilayaId: string; wilayaName: string; revenue: number }>;
  topSpenders: Array<{ userId: string; userName: string; totalSpent: number }>;
  creditUtilization: {
    purchased: number;
    used: number;
    refunded: number;
    active: number;
    utilizationRate: number;
  };
  arpu: number;
  arppu: number;
  conversionRate: number;
}

export interface AppointmentAnalytics {
  totalAppointments: number;
  byStatus: Array<{ status: string; count: number; percentage: number }>;
  byType: Array<{ type: string; count: number; percentage: number }>;
  byPaymentMethod: Array<{ method: string; count: number; percentage: number }>;
  byDayOfWeek: Array<{ day: string; count: number }>;
  byHour: Array<{ hour: number; count: number }>;
  noShowRate: number;
  cancellationRate: number;
  monthlyTrends: Array<{ month: string; total: number; completed: number; cancelled: number }>;
}

export interface RetentionStats {
  overallRetentionRate: number;
  cohortRetention: Array<{
    cohort: string;
    size: number;
    month1: number;
    month2: number;
    month3: number;
    month6: number;
  }>;
  userSegments: Array<{
    segment: string;
    count: number;
    percentage: number;
  }>;
}

export interface GrowthStats {
  userGrowth: Array<{ month: string; newUsers: number; totalUsers: number; growthRate: number }>;
  doctorGrowth: Array<{ month: string; newDoctors: number; totalDoctors: number; growthRate: number }>;
  clinicGrowth: Array<{ month: string; newClinics: number; totalClinics: number; growthRate: number }>;
  appointmentGrowth: Array<{ month: string; appointments: number; growthRate: number }>;
  revenueGrowth: Array<{ month: string; revenue: number; growthRate: number }>;
}

export interface RealtimeStats {
  activeUsers: number;
  appointmentsToday: {
    scheduled: number;
    completed: number;
    inProgress: number;
  };
  revenueToday: number;
  onlineDoctors: number;
  waitingPatients: number;
  averageWaitTime: number;
  alerts: Array<{
    type: 'warning' | 'critical' | 'info';
    message: string;
    timestamp: string;
  }>;
}

export interface ComparisonResponse {
  period1: Record<string, number>;
  period2: Record<string, number>;
  changes: Record<string, {
    absolute: number;
    percentage: number;
    trend: 'up' | 'down' | 'stable';
  }>;
}

