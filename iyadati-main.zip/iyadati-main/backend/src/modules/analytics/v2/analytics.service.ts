// backend/src/modules/analytics/v2/analytics.service.ts

import { prisma } from '../../../core/utils/prisma';
import { Prisma } from '@prisma/client';
import { creditPriceRepository } from '../../../repositories/credit-price.repository';
import {
  OverviewStats,
  DoctorDetailedStats,
  ClinicDetailedStats,
  UserDetailedStats,
  FinancialStats,
  AppointmentAnalytics,
  RetentionStats,
  GrowthStats,
  RealtimeStats,
  ComparisonResponse,
  DateRangeFilter,
  DoctorFilter,
  ClinicFilter,
  UserFilter,
  AppointmentFilter,
} from './analytics.types';

// ============================================================
// ✅ HELPER: Safe string conversion (FIXES null/undefined errors)
// ============================================================

function safeString(value: string | null | undefined): string {
  return value || '';
}

function safeStringArray(arr: (string | null | undefined)[]): string[] {
  return arr.filter((item): item is string => item !== null && item !== undefined);
}

export class AnalyticsService {
  
  // ================================
  // HELPER METHODS
  // ================================
  
  private getDateRange(filter?: DateRangeFilter): { startDate: Date; endDate: Date } {
    const now = new Date();
    const startDate = new Date();
    const endDate = new Date();

    if (filter?.startDate && filter?.endDate) {
      return {
        startDate: new Date(filter.startDate),
        endDate: new Date(filter.endDate),
      };
    }

    switch (filter?.period) {
      case 'today':
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'yesterday':
        startDate.setDate(startDate.getDate() - 1);
        startDate.setHours(0, 0, 0, 0);
        endDate.setDate(endDate.getDate() - 1);
        endDate.setHours(23, 59, 59, 999);
        break;
      case 'last7days':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'last30days':
        startDate.setDate(startDate.getDate() - 30);
        break;
      case 'last90days':
        startDate.setDate(startDate.getDate() - 90);
        break;
      case 'thisMonth':
        startDate.setDate(1);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'lastMonth':
        startDate.setMonth(startDate.getMonth() - 1, 1);
        startDate.setHours(0, 0, 0, 0);
        endDate.setDate(0);
        endDate.setHours(23, 59, 59, 999);
        break;
      case 'thisYear':
        startDate.setMonth(0, 1);
        startDate.setHours(0, 0, 0, 0);
        break;
      default:
        startDate.setDate(startDate.getDate() - 30);
    }

    return { startDate, endDate };
  }

  private buildDoctorWhereClause(filters?: DoctorFilter): Prisma.DoctorWhereInput {
    const where: Prisma.DoctorWhereInput = {};
    
    if (filters?.doctorIds?.length) where.id = { in: filters.doctorIds };
    if (filters?.specialtyIds?.length) where.specialties = { some: { specialtyId: { in: filters.specialtyIds } } };
    if (filters?.practiceType) where.practiceType = filters.practiceType;
    if (filters?.wilayaIds?.length) where.wilayaId = { in: filters.wilayaIds };
    if (filters?.isVerified !== undefined) where.isVerified = filters.isVerified;
    if (filters?.isSuspended !== undefined) where.isSuspended = filters.isSuspended;
    if (filters?.minRating !== undefined || filters?.maxRating !== undefined) {
      where.avgRating = {};
      if (filters.minRating) where.avgRating.gte = filters.minRating;
      if (filters.maxRating) where.avgRating.lte = filters.maxRating;
    }
    
    return where;
  }

  private buildClinicWhereClause(filters?: ClinicFilter): Prisma.ClinicWhereInput {
    const where: Prisma.ClinicWhereInput = {};
    
    if (filters?.clinicIds?.length) where.id = { in: filters.clinicIds };
    if (filters?.facilityType) where.facilityType = filters.facilityType;
    if (filters?.wilayaIds?.length) where.wilayaId = { in: filters.wilayaIds };
    if (filters?.isVerified !== undefined) where.isVerified = filters.isVerified;
    if (filters?.isSuspended !== undefined) where.isSuspended = filters.isSuspended;
    if (filters?.minRating !== undefined || filters?.maxRating !== undefined) {
      where.avgRating = {};
      if (filters.minRating) where.avgRating.gte = filters.minRating;
      if (filters.maxRating) where.avgRating.lte = filters.maxRating;
    }
    
    return where;
  }

  private buildUserWhereClause(filters?: UserFilter): Prisma.UserWhereInput {
    const where: Prisma.UserWhereInput = {};
    
    if (filters?.userIds?.length) where.id = { in: filters.userIds };
    if (filters?.wilayaIds?.length) where.wilayaId = { in: filters.wilayaIds };
    if (filters?.trustLevels?.length) where.trustLevel = { in: filters.trustLevels };
    if (filters?.isVerified !== undefined) where.isVerified = filters.isVerified;
    if (filters?.isSuspended !== undefined) where.isSuspended = filters.isSuspended;
    
    return where;
  }

  private buildAppointmentWhereClause(filters?: AppointmentFilter, dateRange?: { startDate: Date; endDate: Date }): Prisma.AppointmentWhereInput {
    const where: Prisma.AppointmentWhereInput = {};
    
    if (filters?.statuses?.length) where.status = { in: filters.statuses as any };
    if (filters?.types?.length) where.type = { in: filters.types as any };
    if (filters?.paymentMethods?.length) where.paymentMethod = { in: filters.paymentMethods as any };
    
    if (dateRange) {
      where.createdAt = { gte: dateRange.startDate, lte: dateRange.endDate };
    }
    
    if (filters?.slotDateFrom || filters?.slotDateTo) {
      where.slot = {};
      if (filters.slotDateFrom) where.slot.date = { gte: new Date(filters.slotDateFrom) };
      if (filters.slotDateTo) where.slot.date = { ...where.slot.date as any, lte: new Date(filters.slotDateTo) };
    }
    
    return where;
  }

  private calculatePercentageChange(oldValue: number, newValue: number): number {
    if (oldValue === 0) return newValue > 0 ? 100 : 0;
    return ((newValue - oldValue) / oldValue) * 100;
  }

  private getTrend(change: number): 'up' | 'down' | 'stable' {
    if (change > 5) return 'up';
    if (change < -5) return 'down';
    return 'stable';
  }

  private groupByMonth<T extends { createdAt: Date }>(items: T[]): Map<string, T[]> {
    const groups = new Map<string, T[]>();
    for (const item of items) {
      const month = item.createdAt.toISOString().slice(0, 7);
      const group = groups.get(month) || [];
      group.push(item);
      groups.set(month, group);
    }
    return groups;
  }

  private groupByDay<T extends { createdAt: Date }>(items: T[]): Map<string, T[]> {
    const groups = new Map<string, T[]>();
    for (const item of items) {
      const day = item.createdAt.toLocaleDateString('en-US', { weekday: 'long' });
      const group = groups.get(day) || [];
      group.push(item);
      groups.set(day, group);
    }
    return groups;
  }

  // ================================
  // OVERVIEW & DASHBOARD
  // ================================

  async getOverview(): Promise<OverviewStats> {
    const [
      totalUsers,
      totalDoctors,
      totalClinics,
      totalAppointments,
      completedAppointments,
      cancelledAppointments,
      pendingAppointments,
      revenueData,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.doctor.count({ where: { isVerified: true } }),
      prisma.clinic.count({ where: { isVerified: true } }),
      prisma.appointment.count(),
      prisma.appointment.count({ where: { status: 'COMPLETED' } }),
      prisma.appointment.count({ where: { status: 'CANCELLED' } }),
      prisma.appointment.count({ where: { status: 'PENDING' } }),
      prisma.creditTransaction.aggregate({
        where: { type: 'purchase' },
        _sum: { amount: true },
      }),
    ]);

    const creditPrice = await creditPriceRepository.getCurrentPrice();

    return {
      totalUsers,
      totalDoctors,
      totalClinics,
      totalAppointments,
      completedAppointments,
      cancelledAppointments,
      pendingAppointments,
      totalRevenue: (revenueData._sum.amount || 0) * creditPrice,
    };
  }

  async getAdvancedOverview(dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      currentAppointments,
      completedCurrent,
      revenueCurrent,
      newUsersCurrent,
      newDoctorsCurrent,
      previousAppointments,
      todayAppointments,
      todayRevenue,
      activeDoctors,
      newUsersToday,
    ] = await Promise.all([
      prisma.appointment.count({ where: { createdAt: { gte: startDate, lte: endDate } } }),
      prisma.appointment.count({ where: { status: 'COMPLETED', createdAt: { gte: startDate, lte: endDate } } }),
      prisma.creditTransaction.aggregate({
        where: { type: 'purchase', createdAt: { gte: startDate, lte: endDate } },
        _sum: { amount: true },
      }),
      prisma.user.count({ where: { createdAt: { gte: startDate, lte: endDate } } }),
      prisma.doctor.count({ where: { createdAt: { gte: startDate, lte: endDate }, isVerified: true } }),
      prisma.appointment.count({
        where: {
          createdAt: {
            gte: new Date(startDate.getTime() - (endDate.getTime() - startDate.getTime())),
            lte: startDate,
          },
        },
      }),
      prisma.appointment.count({ where: { createdAt: { gte: today } } }),
      prisma.creditTransaction.aggregate({
        where: { type: 'purchase', createdAt: { gte: today } },
        _sum: { amount: true },
      }),
      prisma.doctor.count({ where: { isVerified: true, isSuspended: false } }),
      prisma.user.count({ where: { createdAt: { gte: today } } }),
    ]);

    const creditPrice = await creditPriceRepository.getCurrentPrice();
    const currentRevenue = (revenueCurrent._sum.amount || 0) * creditPrice;
    const daysInPeriod = Math.max(1, (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

    return {
      currentPeriod: {
        appointments: currentAppointments,
        completedAppointments: completedCurrent,
        revenue: currentRevenue,
        newUsers: newUsersCurrent,
        newDoctors: newDoctorsCurrent,
      },
      changes: {
        appointments: this.calculatePercentageChange(previousAppointments, currentAppointments),
        trend: this.getTrend(this.calculatePercentageChange(previousAppointments, currentAppointments)),
      },
      today: {
        appointments: todayAppointments,
        revenue: (todayRevenue._sum.amount || 0) * creditPrice,
        activeDoctors,
        newUsers: newUsersToday,
      },
      averages: {
        appointmentsPerDay: Math.round(currentAppointments / daysInPeriod),
        revenuePerDay: Math.round(currentRevenue / daysInPeriod),
      },
    };
  }

  async getRealtimeDashboard(): Promise<RealtimeStats> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      appointmentsByStatus,
      revenueToday,
      activeDoctors,
      waitingPatients,
    ] = await Promise.all([
      prisma.appointment.groupBy({
        by: ['status'],
        where: { createdAt: { gte: today } },
        _count: true,
      }),
      prisma.creditTransaction.aggregate({
        where: { type: 'purchase', createdAt: { gte: today } },
        _sum: { amount: true },
      }),
      prisma.doctor.count({ where: { isVerified: true, isSuspended: false } }),
      prisma.appointment.count({ where: { status: 'PENDING' } }),
    ]);

    const creditPrice = await creditPriceRepository.getCurrentPrice();

    const statusMap: Record<string, number> = {};
    for (const status of appointmentsByStatus) {
      statusMap[status.status] = status._count;
    }

    const alerts: Array<{ type: 'warning' | 'critical' | 'info'; message: string; timestamp: string }> = [];
    
    if (waitingPatients > 50) {
      alerts.push({
        type: 'warning',
        message: `High number of waiting patients: ${waitingPatients}`,
        timestamp: new Date().toISOString(),
      });
    }

    if (activeDoctors === 0) {
      alerts.push({
        type: 'critical',
        message: 'No active doctors available',
        timestamp: new Date().toISOString(),
      });
    }

    return {
      activeUsers: 0,
      appointmentsToday: {
        scheduled: statusMap['CONFIRMED'] || 0,
        completed: statusMap['COMPLETED'] || 0,
        inProgress: statusMap['IN_PROGRESS'] || 0,
      },
      revenueToday: (revenueToday._sum.amount || 0) * creditPrice,
      onlineDoctors: activeDoctors,
      waitingPatients,
      averageWaitTime: 0,
      alerts,
    };
  }

  // ================================
  // DOCTOR ANALYTICS
  // ================================

  async getDoctorOverview(filters?: DoctorFilter): Promise<any> {
    const where = this.buildDoctorWhereClause(filters);
    
    const [
      totalDoctors,
      verifiedDoctors,
      suspendedDoctors,
      bySpecialty,
      byPracticeType,
      byWilaya,
      avgRatingData,
      doctorsWithReviews,
    ] = await Promise.all([
      prisma.doctor.count({ where }),
      prisma.doctor.count({ where: { ...where, isVerified: true } }),
      prisma.doctor.count({ where: { ...where, isSuspended: true } }),
      prisma.doctorSpecialty.groupBy({
        by: ['specialtyId'],
        _count: true,
        orderBy: { _count: { specialtyId: 'desc' } },
        take: 10,
      }),
      prisma.doctor.groupBy({
        by: ['practiceType'],
        where,
        _count: true,
      }),
      prisma.doctor.groupBy({
        by: ['wilayaId'],
        where,
        _count: true,
        orderBy: { _count: { wilayaId: 'desc' } },
        take: 10,
      }),
      prisma.doctor.aggregate({
        where: { ...where, avgRating: { not: null } },
        _avg: { avgRating: true },
      }),
      prisma.doctor.count({
        where: { ...where, totalReviews: { gt: 0 } },
      }),
    ]);

    // Get specialty names
    const specialtyIds = bySpecialty.map(s => s.specialtyId);
    const specialties = await prisma.specialty.findMany({
      where: { id: { in: specialtyIds } },
      select: { id: true, nameFr: true },
    });

    // Get wilaya names - FIXED: handle null wilayaId
    const wilayaIds = byWilaya
      .map(w => w.wilayaId)
      .filter((id): id is string => id !== null);
    
    const wilayas = await prisma.wilaya.findMany({
      where: { id: { in: wilayaIds } },
      select: { id: true, nameFr: true },
    });

    return {
      totals: {
        totalDoctors,
        verifiedDoctors,
        suspendedDoctors,
        verificationRate: totalDoctors > 0 ? (verifiedDoctors / totalDoctors) * 100 : 0,
        avgRating: avgRatingData._avg.avgRating || 0,
        reviewedDoctors: doctorsWithReviews,
      },
      bySpecialty: bySpecialty.map(s => ({
        specialtyId: s.specialtyId,
        specialtyName: specialties.find(sp => sp.id === s.specialtyId)?.nameFr || 'Unknown',
        count: s._count,
      })),
      byPracticeType: byPracticeType.map(p => ({
        type: p.practiceType,
        count: p._count,
      })),
      byWilaya: byWilaya.map(w => ({
        wilayaId: w.wilayaId || 'unknown',
        wilayaName: w.wilayaId ? (wilayas.find(wi => wi.id === w.wilayaId)?.nameFr || 'Unknown') : 'Unknown',
        count: w._count,
      })),
    };
  }

  async getDoctorDetails(doctorId: string, dateRange?: DateRangeFilter): Promise<DoctorDetailedStats> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const [
      doctor,
      appointments,
      transactions,
      reviews,
      slots,
    ] = await Promise.all([
      prisma.doctor.findUnique({
        where: { id: doctorId },
        select: {
          id: true,
          firstNameFr: true,
          lastNameFr: true,
          avgRating: true,
          totalReviews: true,
          specialties: {
            include: { specialty: { select: { nameFr: true } } },
          },
          clinicLinks: {
            where: { isActive: true },
            include: { clinic: { select: { id: true, nameFr: true } } },
          },
        },
      }),
      prisma.appointment.findMany({
        where: { doctorId, createdAt: { gte: startDate, lte: endDate } },
        select: {
          id: true,
          status: true,
          type: true,
          patientId: true,
          createdAt: true,
          slot: { select: { date: true, startTime: true } },
        },
        orderBy: { createdAt: 'asc' },
      }),
      prisma.creditTransaction.findMany({
        where: {
          type: 'use',
          referenceId: { not: null },
          createdAt: { gte: startDate, lte: endDate },
        },
        select: { amount: true, referenceId: true, createdAt: true },
      }),
      prisma.doctorReview.findMany({
        where: { doctorId },
        select: { rating: true, patientId: true },
      }),
      prisma.slot.findMany({
        where: { doctorId, date: { gte: startDate, lte: endDate } },
        select: { id: true, date: true, startTime: true },
      }),
    ]);

    // Process appointments
    const totalAppointments = appointments.length;
    const completed = appointments.filter(a => a.status === 'COMPLETED').length;
    const cancelled = appointments.filter(a => a.status === 'CANCELLED').length;
    const noShows = appointments.filter(a => a.status === 'NO_SHOW').length;
    const uniquePatients = new Set(appointments.map(a => a.patientId)).size;

    // Calculate returning patients
    const patientAppointmentCount = new Map<string, number>();
    for (const appt of appointments) {
      const patientId = safeString(appt.patientId);
      patientAppointmentCount.set(patientId, (patientAppointmentCount.get(patientId) || 0) + 1);
    }
    const returningPatients = Array.from(patientAppointmentCount.values()).filter(c => c > 1).length;

    // Process revenue
    const appointmentRevenue = new Map<string, number>();
    for (const trans of transactions) {
      if (trans.referenceId) {
        appointmentRevenue.set(trans.referenceId, (appointmentRevenue.get(trans.referenceId) || 0) + Math.abs(trans.amount));
      }
    }
    const totalRevenue = Array.from(appointmentRevenue.values()).reduce((sum, r) => sum + r, 0);

    // Monthly trends
    const monthlyGroups = this.groupByMonth(appointments);
    const monthlyRevenue = new Map<string, number>();
    for (const trans of transactions) {
      const month = trans.createdAt.toISOString().slice(0, 7);
      monthlyRevenue.set(month, (monthlyRevenue.get(month) || 0) + Math.abs(trans.amount));
    }
    
    const monthlyTrends = Array.from(monthlyGroups.entries())
      .map(([month, apps]) => ({
        month,
        appointments: apps.length,
        revenue: monthlyRevenue.get(month) || 0,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    // Appointment types
    const typeDistribution: Record<string, number> = {};
    for (const appt of appointments) {
      typeDistribution[appt.type] = (typeDistribution[appt.type] || 0) + 1;
    }

    // Patient demographics by wilaya - FIXED: use safeString
    const patientIds = [...new Set(appointments.map(a => safeString(a.patientId)))];
    const patients = await prisma.user.findMany({
      where: { id: { in: patientIds } },
      select: { 
        wilayaId: true, 
        wilaya: { select: { nameFr: true } } 
      },
    });
    
    const wilayaGroups = new Map<string, { wilayaId: string; wilayaName: string; count: number }>();
    for (const patient of patients) {
      const wilayaId = safeString(patient.wilayaId);
      const existing = wilayaGroups.get(wilayaId) || {
        wilayaId: wilayaId,
        wilayaName: patient.wilaya ? patient.wilaya.nameFr : 'Unknown',
        count: 0,
      };
      existing.count++;
      wilayaGroups.set(wilayaId, existing);
    }

    // Peak hours
    const hourGroups = new Map<number, number>();
    for (const appt of appointments) {
      if (appt.slot?.startTime) {
        const hour = new Date(appt.slot.startTime).getHours();
        hourGroups.set(hour, (hourGroups.get(hour) || 0) + 1);
      }
    }
    const peakHours = Array.from(hourGroups.entries())
      .map(([hour, count]) => ({ hour, count }))
      .sort((a, b) => b.count - a.count);

    // Busiest days
    const dayGroups = this.groupByDay(appointments);
    const busiestDays = Array.from(dayGroups.entries())
      .map(([day, apps]) => ({ day, count: apps.length }))
      .sort((a, b) => b.count - a.count);

    return {
      totalAppointments,
      completedAppointments: completed,
      cancelledAppointments: cancelled,
      noShowAppointments: noShows,
      completionRate: totalAppointments > 0 ? (completed / totalAppointments) * 100 : 0,
      cancellationRate: totalAppointments > 0 ? (cancelled / totalAppointments) * 100 : 0,
      noShowRate: totalAppointments > 0 ? (noShows / totalAppointments) * 100 : 0,
      avgRating: doctor?.avgRating || 0,
      totalReviews: doctor?.totalReviews || 0,
      totalRevenue,
      avgRevenuePerAppointment: totalAppointments > 0 ? totalRevenue / totalAppointments : 0,
      uniquePatients,
      returningPatients,
      retentionRate: uniquePatients > 0 ? (returningPatients / uniquePatients) * 100 : 0,
      appointmentTypeDistribution: typeDistribution,
      monthlyTrends,
      patientDemographics: {
        byWilaya: Array.from(wilayaGroups.values()).sort((a, b) => b.count - a.count),
      },
      peakHours,
      busiestDays,
    };
  }

  async getTopDoctors(metric: string, limit: number, dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);

    switch (metric) {
      case 'appointments': {
        const doctors = await prisma.doctor.findMany({
          where: { isVerified: true },
          include: {
            _count: {
              select: {
                appointments: {
                  where: { createdAt: { gte: startDate, lte: endDate } },
                },
              },
            },
          },
          orderBy: {
            appointments: { _count: 'desc' },
          },
          take: limit,
        });

        return doctors.map(d => ({
          doctorId: d.id,
          doctorName: `${d.firstNameFr} ${d.lastNameFr}`,
          count: d._count.appointments,
          avgRating: d.avgRating,
        }));
      }

      case 'rating': {
        return prisma.doctor.findMany({
          where: { isVerified: true, totalReviews: { gt: 0 } },
          orderBy: { avgRating: 'desc' },
          take: limit,
          select: {
            id: true,
            firstNameFr: true,
            lastNameFr: true,
            avgRating: true,
            totalReviews: true,
          },
        });
      }

      case 'patients': {
        const doctors = await prisma.doctor.findMany({
          where: { isVerified: true },
          include: {
            appointments: {
              where: { createdAt: { gte: startDate, lte: endDate } },
              select: { patientId: true },
            },
          },
          take: 50,
        });

        return doctors
          .map(d => ({
            doctorId: d.id,
            doctorName: `${d.firstNameFr} ${d.lastNameFr}`,
            count: new Set(d.appointments.map(a => a.patientId)).size,
            avgRating: d.avgRating,
          }))
          .sort((a, b) => b.count - a.count)
          .slice(0, limit);
      }

      default:
        return [];
    }
  }

  async getDoctorsComparison(doctorIds: string[], metrics: string[], dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const doctors = await prisma.doctor.findMany({
      where: { id: { in: doctorIds } },
      select: {
        id: true,
        firstNameFr: true,
        lastNameFr: true,
        avgRating: true,
        totalReviews: true,
        yearsOfExp: true,
        practiceType: true,
      },
    });

    const comparisons = await Promise.all(
      doctors.map(async (doctor) => {
        const data: any = { doctor };

        if (metrics.includes('appointments')) {
          const appointments = await prisma.appointment.groupBy({
            by: ['status'],
            where: { doctorId: doctor.id, createdAt: { gte: startDate, lte: endDate } },
            _count: true,
          });
          
          const total = appointments.reduce((sum, a) => sum + a._count, 0);
          data.appointments = {
            total,
            completed: appointments.find(a => a.status === 'COMPLETED')?._count || 0,
            cancelled: appointments.find(a => a.status === 'CANCELLED')?._count || 0,
            completionRate: total > 0 
              ? ((appointments.find(a => a.status === 'COMPLETED')?._count || 0) / total) * 100 
              : 0,
          };
        }

        if (metrics.includes('revenue')) {
          const transactions = await prisma.creditTransaction.findMany({
            where: {
              type: 'use',
              referenceId: { not: null },
              createdAt: { gte: startDate, lte: endDate },
            },
            select: { amount: true, referenceId: true },
          });

          const doctorAppointments = await prisma.appointment.findMany({
            where: { doctorId: doctor.id, createdAt: { gte: startDate, lte: endDate } },
            select: { id: true },
          });

          const doctorAppointmentIds = new Set(doctorAppointments.map(a => a.id));
          data.revenue = transactions
            .filter(t => t.referenceId && doctorAppointmentIds.has(t.referenceId))
            .reduce((sum, t) => sum + Math.abs(t.amount), 0);
        }

        if (metrics.includes('patients')) {
          const uniquePatients = await prisma.appointment.groupBy({
            by: ['patientId'],
            where: { doctorId: doctor.id, createdAt: { gte: startDate, lte: endDate } },
          });
          data.patients = uniquePatients.length;
        }

        return data;
      })
    );

    return comparisons;
  }

  async getDoctorRevenueAnalytics(doctorId: string, dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const appointments = await prisma.appointment.findMany({
      where: {
        doctorId,
        status: 'COMPLETED',
        createdAt: { gte: startDate, lte: endDate },
      },
      select: { id: true, createdAt: true },
    });

    const appointmentIds = appointments.map(a => a.id);
    const transactions = await prisma.creditTransaction.findMany({
      where: {
        type: 'use',
        referenceId: { in: appointmentIds },
      },
      select: { amount: true, referenceId: true, createdAt: true },
    });

    // Group by month
    const monthlyData = new Map<string, { appointments: number; revenue: number }>();
    
    for (const appt of appointments) {
      const month = appt.createdAt.toISOString().slice(0, 7);
      const data = monthlyData.get(month) || { appointments: 0, revenue: 0 };
      data.appointments++;
      
      const trans = transactions.find(t => t.referenceId === appt.id);
      if (trans) {
        data.revenue += Math.abs(trans.amount);
      }
      
      monthlyData.set(month, data);
    }

    const monthlyBreakdown = Array.from(monthlyData.entries())
      .map(([month, data]) => ({
        month,
        ...data,
        avgPerAppointment: data.appointments > 0 ? data.revenue / data.appointments : 0,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    const totalRevenue = monthlyBreakdown.reduce((sum, m) => sum + m.revenue, 0);
    const totalAppointments = monthlyBreakdown.reduce((sum, m) => sum + m.appointments, 0);

    return {
      summary: {
        totalRevenue,
        totalAppointments,
        avgRevenuePerAppointment: totalAppointments > 0 ? totalRevenue / totalAppointments : 0,
        monthlyAvg: monthlyBreakdown.length > 0 ? totalRevenue / monthlyBreakdown.length : 0,
      },
      monthlyBreakdown,
      growth: monthlyBreakdown.map((current, index) => {
        const previous = monthlyBreakdown[index - 1];
        const growth = previous ? this.calculatePercentageChange(previous.revenue, current.revenue) : 0;
        return {
          month: current.month,
          revenue: current.revenue,
          growth,
          trend: this.getTrend(growth),
        };
      }),
    };
  }

  async getDoctorRetention(doctorId: string): Promise<any> {
    const patients = await prisma.appointment.groupBy({
      by: ['patientId'],
      where: { doctorId },
      _min: { createdAt: true },
      _max: { createdAt: true },
    });

    const cohorts = new Map<string, { initialPatients: number; returnedPatients: number }>();

    for (const patient of patients) {
      if (!patient._min.createdAt) continue;
      
      const cohortMonth = patient._min.createdAt.toISOString().slice(0, 7);
      const cohort = cohorts.get(cohortMonth) || { initialPatients: 0, returnedPatients: 0 };
      
      cohort.initialPatients++;
      
      if (patient._max.createdAt && patient._max.createdAt > patient._min.createdAt) {
        cohort.returnedPatients++;
      }

      cohorts.set(cohortMonth, cohort);
    }

    return Array.from(cohorts.entries())
      .map(([cohort, data]) => ({
        cohort,
        ...data,
        retentionRate: data.initialPatients > 0 ? (data.returnedPatients / data.initialPatients) * 100 : 0,
      }))
      .sort((a, b) => b.cohort.localeCompare(a.cohort));
  }

  // ================================
  // CLINIC ANALYTICS
  // ================================

  async getClinicOverview(filters?: ClinicFilter): Promise<any> {
    const where = this.buildClinicWhereClause(filters);
    
    const [
      totalClinics,
      verifiedClinics,
      suspendedClinics,
      byFacilityType,
      byWilaya,
      topRated,
    ] = await Promise.all([
      prisma.clinic.count({ where }),
      prisma.clinic.count({ where: { ...where, isVerified: true } }),
      prisma.clinic.count({ where: { ...where, isSuspended: true } }),
      prisma.clinic.groupBy({
        by: ['facilityType'],
        where,
        _count: true,
      }),
      prisma.clinic.groupBy({
        by: ['wilayaId'],
        where,
        _count: true,
        orderBy: { _count: { wilayaId: 'desc' } },
        take: 10,
      }),
      prisma.clinic.findMany({
        where: { ...where, totalReviews: { gt: 0 } },
        orderBy: { avgRating: 'desc' },
        take: 5,
        select: { id: true, nameFr: true, avgRating: true, totalReviews: true },
      }),
    ]);

    // Get most active clinics
    const clinicsWithAppointments = await prisma.clinic.findMany({
      where: { ...where, appointments: { some: {} } },
      include: {
        _count: { select: { appointments: true } },
      },
      orderBy: { appointments: { _count: 'desc' } },
      take: 5,
    });

    // FIXED: filter out null wilayaId
    const wilayaIds = byWilaya
      .map(w => w.wilayaId)
      .filter((id): id is string => id !== null);
    
    const wilayas = await prisma.wilaya.findMany({
      where: { id: { in: wilayaIds } },
      select: { id: true, nameFr: true },
    });

    return {
      totals: {
        totalClinics,
        verifiedClinics,
        suspendedClinics,
        verificationRate: totalClinics > 0 ? (verifiedClinics / totalClinics) * 100 : 0,
      },
      byFacilityType: byFacilityType.map(f => ({
        type: f.facilityType,
        count: f._count,
      })),
      byWilaya: byWilaya.map(w => ({
        wilayaId: w.wilayaId || 'unknown',
        wilayaName: w.wilayaId ? (wilayas.find(wi => wi.id === w.wilayaId)?.nameFr || 'Unknown') : 'Unknown',
        count: w._count,
      })),
      topRated,
      mostAppointments: clinicsWithAppointments.map(c => ({
        clinicId: c.id,
        clinicName: c.nameFr,
        count: c._count.appointments,
        avgRating: c.avgRating,
      })),
    };
  }

  async getClinicDetails(clinicId: string, dateRange?: DateRangeFilter): Promise<ClinicDetailedStats> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const [
      clinic,
      appointments,
      transactions,
      reviews,
      activeDoctors,
      rooms,
    ] = await Promise.all([
      prisma.clinic.findUnique({
        where: { id: clinicId },
        select: {
          id: true,
          nameFr: true,
          avgRating: true,
          totalReviews: true,
          rooms: { select: { id: true, name: true } },
        },
      }),
      prisma.appointment.findMany({
        where: { clinicId, createdAt: { gte: startDate, lte: endDate } },
        select: {
          id: true,
          status: true,
          type: true,
          doctorId: true,
          patientId: true,
          createdAt: true,
          slot: { select: { date: true, startTime: true } },
        },
        orderBy: { createdAt: 'asc' },
      }),
      prisma.creditTransaction.findMany({
        where: {
          type: 'use',
          referenceId: { not: null },
          createdAt: { gte: startDate, lte: endDate },
        },
        select: { amount: true, referenceId: true, createdAt: true },
      }),
      prisma.clinicReview.findMany({
        where: { clinicId },
        select: { rating: true },
      }),
      prisma.clinicDoctor.count({
        where: { clinicId, isActive: true },
      }),
      prisma.clinicRoom.count({
        where: { clinicId, isActive: true },
      }),
    ]);

    // Process appointments
    const totalAppointments = appointments.length;
    const typeDistribution: Record<string, number> = {};
    const doctorPerformance = new Map<string, { appointments: number; revenue: number }>();
    const patientSet = new Set<string>();

    for (const appt of appointments) {
      typeDistribution[appt.type] = (typeDistribution[appt.type] || 0) + 1;
      const patientId = safeString(appt.patientId);
      patientSet.add(patientId);
      
      const doctorStats = doctorPerformance.get(appt.doctorId) || { appointments: 0, revenue: 0 };
      doctorStats.appointments++;
      doctorPerformance.set(appt.doctorId, doctorStats);
    }

    // Process revenue
    const appointmentRevenue = new Map<string, number>();
    for (const trans of transactions) {
      if (trans.referenceId) {
        appointmentRevenue.set(trans.referenceId, (appointmentRevenue.get(trans.referenceId) || 0) + Math.abs(trans.amount));
      }
    }

    // Update doctor revenue
    for (const appt of appointments) {
      const revenue = appointmentRevenue.get(appt.id) || 0;
      const doctorStats = doctorPerformance.get(appt.doctorId);
      if (doctorStats) {
        doctorStats.revenue += revenue;
      }
    }

    const totalRevenue = Array.from(appointmentRevenue.values()).reduce((sum, r) => sum + r, 0);

    // Monthly trends
    const monthlyGroups = this.groupByMonth(appointments);
    const monthlyRevenue = new Map<string, number>();
    const monthlyNewPatients = new Map<string, Set<string>>();
    
    for (const trans of transactions) {
      const month = trans.createdAt.toISOString().slice(0, 7);
      monthlyRevenue.set(month, (monthlyRevenue.get(month) || 0) + Math.abs(trans.amount));
    }
    
    for (const appt of appointments) {
      const month = appt.createdAt.toISOString().slice(0, 7);
      const patients = monthlyNewPatients.get(month) || new Set();
      patients.add(safeString(appt.patientId));
      monthlyNewPatients.set(month, patients);
    }

    const monthlyTrends = Array.from(monthlyGroups.entries())
      .map(([month, apps]) => ({
        month,
        appointments: apps.length,
        revenue: monthlyRevenue.get(month) || 0,
        newPatients: monthlyNewPatients.get(month)?.size || 0,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    // Doctor performance with names
    const doctorIds = [...doctorPerformance.keys()];
    const doctors = await prisma.doctor.findMany({
      where: { id: { in: doctorIds } },
      select: { id: true, firstNameFr: true, lastNameFr: true, avgRating: true },
    });

    const doctorPerformanceArray = Array.from(doctorPerformance.entries())
      .map(([doctorId, stats]) => {
        const doctor = doctors.find(d => d.id === doctorId);
        return {
          doctorId,
          doctorName: doctor ? `${doctor.firstNameFr} ${doctor.lastNameFr}` : 'Unknown',
          appointments: stats.appointments,
          revenue: stats.revenue,
          avgRating: doctor?.avgRating || 0,
        };
      })
      .sort((a, b) => b.appointments - a.appointments);

    // Rating distribution
    const ratingDistribution = new Map<number, number>();
    for (const review of reviews) {
      if (review.rating) {
        ratingDistribution.set(review.rating, (ratingDistribution.get(review.rating) || 0) + 1);
      }
    }

    // Peak hours
    const hourGroups = new Map<number, number>();
    for (const appt of appointments) {
      if (appt.slot?.startTime) {
        const hour = new Date(appt.slot.startTime).getHours();
        hourGroups.set(hour, (hourGroups.get(hour) || 0) + 1);
      }
    }
    const peakHours = Array.from(hourGroups.entries())
      .map(([hour, count]) => ({ hour, count }))
      .sort((a, b) => b.count - a.count);

    // Busiest days
    const dayGroups = this.groupByDay(appointments);
    const busiestDays = Array.from(dayGroups.entries())
      .map(([day, apps]) => ({ day, count: apps.length }))
      .sort((a, b) => b.count - a.count);

    return {
      totalAppointments,
      totalDoctors: doctorIds.length,
      activeDoctors,
      totalRooms: rooms,
      avgRating: clinic?.avgRating || 0,
      totalReviews: clinic?.totalReviews || 0,
      totalRevenue,
      avgRevenuePerDoctor: doctorIds.length > 0 ? totalRevenue / doctorIds.length : 0,
      doctorPerformance: doctorPerformanceArray,
      appointmentTypeDistribution: typeDistribution,
      monthlyTrends,
      patientSatisfaction: {
        avgRating: clinic?.avgRating || 0,
        ratingDistribution: Array.from(ratingDistribution.entries()).map(([rating, count]) => ({
          rating,
          count,
        })),
      },
      peakHours,
      busiestDays,
    };
  }

  async compareClinics(clinicIds: string[], metrics: string[], dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const clinics = await prisma.clinic.findMany({
      where: { id: { in: clinicIds } },
      select: {
        id: true,
        nameFr: true,
        avgRating: true,
        totalReviews: true,
        facilityType: true,
        _count: { select: { doctorLinks: true, rooms: true } },
      },
    });

    const comparisons = await Promise.all(
      clinics.map(async (clinic) => {
        const data: any = { clinic };

        if (metrics.includes('appointments')) {
          data.appointments = await prisma.appointment.count({
            where: { clinicId: clinic.id, createdAt: { gte: startDate, lte: endDate } },
          });
        }

        if (metrics.includes('doctors')) {
          data.doctors = clinic._count.doctorLinks;
        }

        if (metrics.includes('revenue')) {
          const clinicAppointments = await prisma.appointment.findMany({
            where: { clinicId: clinic.id, createdAt: { gte: startDate, lte: endDate } },
            select: { id: true },
          });

          const appointmentIds = clinicAppointments.map(a => a.id);
          const transactions = await prisma.creditTransaction.aggregate({
            where: {
              type: 'use',
              referenceId: { in: appointmentIds },
            },
            _sum: { amount: true },
          });

          data.revenue = Math.abs(transactions._sum.amount || 0);
        }

        return data;
      })
    );

    return comparisons;
  }

  // ================================
  // USER ANALYTICS
  // ================================

  async getUserOverview(filters?: UserFilter): Promise<any> {
    const where = this.buildUserWhereClause(filters);
    
    const [
      totalUsers,
      verifiedUsers,
      suspendedUsers,
      byTrustLevel,
      byWilaya,
      newUsersToday,
    ] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.count({ where: { ...where, isVerified: true } }),
      prisma.user.count({ where: { ...where, isSuspended: true } }),
      prisma.user.groupBy({
        by: ['trustLevel'],
        where,
        _count: true,
        orderBy: { trustLevel: 'asc' },
      }),
      prisma.user.groupBy({
        by: ['wilayaId'],
        where,
        _count: true,
        orderBy: { _count: { wilayaId: 'desc' } },
        take: 10,
      }),
      prisma.user.count({
        where: {
          ...where,
          createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
        },
      }),
    ]);

    // FIXED: filter out null wilayaId
    const wilayaIds = byWilaya
      .map(w => w.wilayaId)
      .filter((id): id is string => id !== null);
    
    const wilayas = await prisma.wilaya.findMany({
      where: { id: { in: wilayaIds } },
      select: { id: true, nameFr: true },
    });

    const getTrustLabel = (level: number): string => {
      switch (level) {
        case 0: return 'Unreliable';
        case 1: return 'New';
        case 2: return 'Trusted';
        case 3: return 'VIP';
        default: return 'Unknown';
      }
    };

    return {
      totals: {
        totalUsers,
        verifiedUsers,
        suspendedUsers,
        verificationRate: totalUsers > 0 ? (verifiedUsers / totalUsers) * 100 : 0,
        newToday: newUsersToday,
      },
      byTrustLevel: byTrustLevel.map(t => ({
        level: t.trustLevel,
        label: getTrustLabel(t.trustLevel),
        count: t._count,
      })),
      byWilaya: byWilaya.map(w => ({
        wilayaId: w.wilayaId || 'unknown',
        wilayaName: w.wilayaId ? (wilayas.find(wi => wi.id === w.wilayaId)?.nameFr || 'Unknown') : 'Unknown',
        count: w._count,
      })),
    };
  }

  async getUserDetails(userId: string, dateRange?: DateRangeFilter): Promise<UserDetailedStats> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const [
      user,
      appointments,
      transactions,
      wallet,
    ] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: {
          trustPoints: true,
          trustLevel: true,
          documents: { select: { id: true } },
          contactUsers: { select: { id: true } },
          doctorReviews: { select: { id: true } },
          clinicReviews: { select: { id: true } },
        },
      }),
      prisma.appointment.findMany({
        where: { patientId: userId, createdAt: { gte: startDate, lte: endDate } },
        select: {
          id: true,
          status: true,
          type: true,
          doctorId: true,
          clinicId: true,
          createdAt: true,
          slot: { select: { date: true, startTime: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.creditTransaction.findMany({
        where: {
          wallet: { userId },
          type: 'use',
          createdAt: { gte: startDate, lte: endDate },
        },
        select: { amount: true, referenceId: true, createdAt: true },
      }),
      prisma.userWallet.findUnique({
        where: { userId },
        select: { credits: true },
      }),
    ]);

    const totalAppointments = appointments.length;
    const completed = appointments.filter(a => a.status === 'COMPLETED').length;
    const cancelled = appointments.filter(a => a.status === 'CANCELLED').length;
    const noShows = appointments.filter(a => a.status === 'NO_SHOW').length;

    // Total spent
    const totalSpent = transactions.reduce((sum, t) => sum + Math.abs(t.amount), 0);

    // Favorite doctors
    const doctorFreq = new Map<string, { count: number; lastAppointment: Date }>();
    for (const appt of appointments) {
      const existing = doctorFreq.get(appt.doctorId) || { count: 0, lastAppointment: appt.createdAt };
      existing.count++;
      if (appt.createdAt > existing.lastAppointment) {
        existing.lastAppointment = appt.createdAt;
      }
      doctorFreq.set(appt.doctorId, existing);
    }

    const topDoctorIds = Array.from(doctorFreq.entries())
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5)
      .map(([id]) => id);

    const favoriteDoctorsData = await prisma.doctor.findMany({
      where: { id: { in: topDoctorIds } },
      select: { id: true, firstNameFr: true, lastNameFr: true },
    });

    const favoriteDoctors = topDoctorIds.map(id => {
      const doctor = favoriteDoctorsData.find(d => d.id === id);
      const stats = doctorFreq.get(id)!;
      return {
        doctorId: id,
        doctorName: doctor ? `${doctor.firstNameFr} ${doctor.lastNameFr}` : 'Unknown',
        appointments: stats.count,
        lastAppointment: stats.lastAppointment.toISOString(),
      };
    });

    // Favorite clinics
    const clinicFreq = new Map<string, { count: number; lastAppointment: Date }>();
    for (const appt of appointments) {
      if (!appt.clinicId) continue;
      const existing = clinicFreq.get(appt.clinicId) || { count: 0, lastAppointment: appt.createdAt };
      existing.count++;
      if (appt.createdAt > existing.lastAppointment) {
        existing.lastAppointment = appt.createdAt;
      }
      clinicFreq.set(appt.clinicId, existing);
    }

    const topClinicIds = Array.from(clinicFreq.entries())
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5)
      .map(([id]) => id);

    const favoriteClinicsData = await prisma.clinic.findMany({
      where: { id: { in: topClinicIds } },
      select: { id: true, nameFr: true },
    });

    const favoriteClinics = topClinicIds.map(id => {
      const clinic = favoriteClinicsData.find(c => c.id === id);
      const stats = clinicFreq.get(id)!;
      return {
        clinicId: id,
        clinicName: clinic?.nameFr || 'Unknown',
        appointments: stats.count,
        lastAppointment: stats.lastAppointment.toISOString(),
      };
    });

    // Appointment types
    const typeDistribution: Record<string, number> = {};
    for (const appt of appointments) {
      typeDistribution[appt.type] = (typeDistribution[appt.type] || 0) + 1;
    }

    // Monthly activity
    const monthlyGroups = this.groupByMonth(appointments);
    const monthlySpending = new Map<string, number>();
    for (const trans of transactions) {
      const month = trans.createdAt.toISOString().slice(0, 7);
      monthlySpending.set(month, (monthlySpending.get(month) || 0) + Math.abs(trans.amount));
    }

    const monthlyActivity = Array.from(monthlyGroups.entries())
      .map(([month, apps]) => ({
        month,
        appointments: apps.length,
        spent: monthlySpending.get(month) || 0,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    // Time slots
    const hourGroups = new Map<number, number>();
    for (const appt of appointments) {
      if (appt.slot?.startTime) {
        const hour = new Date(appt.slot.startTime).getHours();
        hourGroups.set(hour, (hourGroups.get(hour) || 0) + 1);
      }
    }

    // Day preference
    const dayGroups = this.groupByDay(appointments);

    // Average advance booking
    let totalAdvanceDays = 0;
    let advanceCount = 0;
    for (const appt of appointments) {
      if (appt.slot?.date) {
        const bookingDate = appt.createdAt;
        const appointmentDate = new Date(appt.slot.date);
        const days = (appointmentDate.getTime() - bookingDate.getTime()) / (1000 * 60 * 60 * 24);
        if (days >= 0) {
          totalAdvanceDays += days;
          advanceCount++;
        }
      }
    }

    return {
      totalAppointments,
      completedAppointments: completed,
      cancelledAppointments: cancelled,
      noShowCount: noShows,
      cancellationRate: totalAppointments > 0 ? (cancelled / totalAppointments) * 100 : 0,
      noShowRate: totalAppointments > 0 ? (noShows / totalAppointments) * 100 : 0,
      trustPoints: user?.trustPoints || 0,
      trustLevel: user?.trustLevel || 1,
      totalSpent,
      avgSpentPerAppointment: totalAppointments > 0 ? totalSpent / totalAppointments : 0,
      walletBalance: wallet?.credits || 0,
      favoriteDoctors,
      favoriteClinics,
      appointmentTypes: typeDistribution,
      monthlyActivity,
      timeSlots: Array.from(hourGroups.entries())
        .map(([hour, count]) => ({ hour, count }))
        .sort((a, b) => b.count - a.count),
      dayPreference: Array.from(dayGroups.entries())
        .map(([day, apps]) => ({ day, count: apps.length }))
        .sort((a, b) => b.count - a.count),
      avgAdvanceBookingDays: advanceCount > 0 ? totalAdvanceDays / advanceCount : 0,
      documentsCount: user?.documents.length || 0,
      contactUsersCount: user?.contactUsers.length || 0,
      reviewsGiven: (user?.doctorReviews.length || 0) + (user?.clinicReviews.length || 0),
    };
  }

  async getUserRetention(): Promise<RetentionStats> {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        createdAt: true,
        appointments: {
          select: { createdAt: true },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    // Cohort analysis
    const cohorts = new Map<string, { size: number; month1: number; month2: number; month3: number; month6: number }>();
    
    for (const user of users) {
      const cohortMonth = user.createdAt.toISOString().slice(0, 7);
      const cohort = cohorts.get(cohortMonth) || { size: 0, month1: 0, month2: 0, month3: 0, month6: 0 };
      cohort.size++;

      if (user.appointments.length > 0) {
        const firstMonth = new Date(user.createdAt);
        firstMonth.setMonth(firstMonth.getMonth() + 1);
        
        // Check activity in subsequent months
        if (user.appointments.some(a => a.createdAt >= new Date(firstMonth.getFullYear(), firstMonth.getMonth(), 1) && a.createdAt < new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 1, 1))) {
          cohort.month1++;
        }
        if (user.appointments.some(a => a.createdAt >= new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 1, 1) && a.createdAt < new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 2, 1))) {
          cohort.month2++;
        }
        if (user.appointments.some(a => a.createdAt >= new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 2, 1) && a.createdAt < new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 3, 1))) {
          cohort.month3++;
        }
        if (user.appointments.some(a => a.createdAt >= new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 5, 1) && a.createdAt < new Date(firstMonth.getFullYear(), firstMonth.getMonth() + 6, 1))) {
          cohort.month6++;
        }
      }

      cohorts.set(cohortMonth, cohort);
    }

    // User segments
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    const segments = {
      new: 0,
      active: 0,
      atRisk: 0,
      lost: 0,
      powerUser: 0,
    };

    for (const user of users) {
      const recentAppointments = user.appointments.filter(a => a.createdAt >= thirtyDaysAgo).length;
      const totalAppointments = user.appointments.length;

      if (user.createdAt >= thirtyDaysAgo) {
        segments.new++;
      } else if (recentAppointments > 0 && totalAppointments > 10) {
        segments.powerUser++;
      } else if (recentAppointments > 0) {
        segments.active++;
      } else if (totalAppointments === 0) {
        segments.lost++;
      } else {
        segments.atRisk++;
      }
    }

    const total = users.length;

    return {
      overallRetentionRate: cohorts.size > 0
        ? Array.from(cohorts.values()).reduce((sum, c) => sum + (c.month1 / c.size) * 100, 0) / cohorts.size
        : 0,
      cohortRetention: Array.from(cohorts.entries())
        .map(([cohort, data]) => ({ cohort, ...data }))
        .sort((a, b) => b.cohort.localeCompare(a.cohort)),
      userSegments: [
        { segment: 'new', count: segments.new, percentage: total > 0 ? (segments.new / total) * 100 : 0 },
        { segment: 'active', count: segments.active, percentage: total > 0 ? (segments.active / total) * 100 : 0 },
        { segment: 'at_risk', count: segments.atRisk, percentage: total > 0 ? (segments.atRisk / total) * 100 : 0 },
        { segment: 'lost', count: segments.lost, percentage: total > 0 ? (segments.lost / total) * 100 : 0 },
        { segment: 'power_user', count: segments.powerUser, percentage: total > 0 ? (segments.powerUser / total) * 100 : 0 },
      ],
    };
  }

  // ================================
  // APPOINTMENT ANALYTICS
  // ================================

  async getAppointmentAnalytics(filters?: AppointmentFilter, dateRange?: DateRangeFilter): Promise<AppointmentAnalytics> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    const where = this.buildAppointmentWhereClause(filters, { startDate, endDate });
    
    const appointments = await prisma.appointment.findMany({
      where,
      select: {
        status: true,
        type: true,
        paymentMethod: true,
        createdAt: true,
        slot: { select: { date: true, startTime: true } },
      },
    });

    const total = appointments.length;

    // By status
    const statusGroups = new Map<string, number>();
    const typeGroups = new Map<string, number>();
    const paymentGroups = new Map<string, number>();
    const dayGroups = new Map<string, number>();
    const hourGroups = new Map<number, number>();
    const monthlyGroups = new Map<string, { total: number; completed: number; cancelled: number }>();

    for (const appt of appointments) {
      // Status
      statusGroups.set(appt.status, (statusGroups.get(appt.status) || 0) + 1);
      
      // Type
      typeGroups.set(appt.type, (typeGroups.get(appt.type) || 0) + 1);
      
      // Payment method
      paymentGroups.set(appt.paymentMethod, (paymentGroups.get(appt.paymentMethod) || 0) + 1);
      
      // Day of week
      const day = appt.createdAt.toLocaleDateString('en-US', { weekday: 'long' });
      dayGroups.set(day, (dayGroups.get(day) || 0) + 1);
      
      // Hour
      if (appt.slot?.startTime) {
        const hour = new Date(appt.slot.startTime).getHours();
        hourGroups.set(hour, (hourGroups.get(hour) || 0) + 1);
      }
      
      // Monthly
      const month = appt.createdAt.toISOString().slice(0, 7);
      const monthly = monthlyGroups.get(month) || { total: 0, completed: 0, cancelled: 0 };
      monthly.total++;
      if (appt.status === 'COMPLETED') monthly.completed++;
      if (appt.status === 'CANCELLED') monthly.cancelled++;
      monthlyGroups.set(month, monthly);
    }

    const noShows = statusGroups.get('NO_SHOW') || 0;
    const cancelled = statusGroups.get('CANCELLED') || 0;

    return {
      totalAppointments: total,
      byStatus: Array.from(statusGroups.entries()).map(([status, count]) => ({
        status,
        count,
        percentage: total > 0 ? (count / total) * 100 : 0,
      })),
      byType: Array.from(typeGroups.entries()).map(([type, count]) => ({
        type,
        count,
        percentage: total > 0 ? (count / total) * 100 : 0,
      })),
      byPaymentMethod: Array.from(paymentGroups.entries()).map(([method, count]) => ({
        method,
        count,
        percentage: total > 0 ? (count / total) * 100 : 0,
      })),
      byDayOfWeek: Array.from(dayGroups.entries())
        .map(([day, count]) => ({ day, count }))
        .sort((a, b) => b.count - a.count),
      byHour: Array.from(hourGroups.entries())
        .map(([hour, count]) => ({ hour, count }))
        .sort((a, b) => a.hour - b.hour),
      noShowRate: total > 0 ? (noShows / total) * 100 : 0,
      cancellationRate: total > 0 ? (cancelled / total) * 100 : 0,
      monthlyTrends: Array.from(monthlyGroups.entries())
        .map(([month, data]) => ({ month, ...data }))
        .sort((a, b) => a.month.localeCompare(b.month)),
    };
  }

  async getCancellationAnalysis(dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const cancelledAppointments = await prisma.appointment.findMany({
      where: {
        status: 'CANCELLED',
        cancelledAt: { gte: startDate, lte: endDate },
      },
      select: {
        cancelReason: true,
        cancelledAt: true,
        doctorId: true,
        patientId: true,
      },
    });

    // Group by reasons
    const reasonGroups = new Map<string, number>();
    const doctorGroups = new Map<string, number>();
    const patientGroups = new Map<string, number>();
    const dayGroups = new Map<string, number>();

    for (const appt of cancelledAppointments) {
      const reason = appt.cancelReason || 'Unknown';
      reasonGroups.set(reason, (reasonGroups.get(reason) || 0) + 1);
      doctorGroups.set(appt.doctorId, (doctorGroups.get(appt.doctorId) || 0) + 1);
      const patientId = safeString(appt.patientId);
      patientGroups.set(patientId, (patientGroups.get(patientId) || 0) + 1);
      
      if (appt.cancelledAt) {
        const day = appt.cancelledAt.toLocaleDateString('en-US', { weekday: 'long' });
        dayGroups.set(day, (dayGroups.get(day) || 0) + 1);
      }
    }

    // Get top doctor names
    const topDoctorIds = Array.from(doctorGroups.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([id]) => id);

    const doctors = await prisma.doctor.findMany({
      where: { id: { in: topDoctorIds } },
      select: { id: true, firstNameFr: true, lastNameFr: true },
    });

    return {
      reasons: Array.from(reasonGroups.entries())
        .map(([reason, count]) => ({ reason, count }))
        .sort((a, b) => b.count - a.count),
      byDay: Array.from(dayGroups.entries())
        .map(([day, count]) => ({ day, count }))
        .sort((a, b) => b.count - a.count),
      topDoctorsWithCancellations: Array.from(doctorGroups.entries())
        .map(([doctorId, count]) => {
          const doctor = doctors.find(d => d.id === doctorId);
          return {
            doctorId,
            doctorName: doctor ? `${doctor.firstNameFr} ${doctor.lastNameFr}` : 'Unknown',
            count,
          };
        })
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      topPatientsWithCancellations: Array.from(patientGroups.entries())
        .map(([patientId, count]) => ({ patientId, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
    };
  }

  async getNoShowAnalysis(dateRange?: DateRangeFilter): Promise<any> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    
    const noShowAppointments = await prisma.appointment.findMany({
      where: {
        status: 'NO_SHOW',
        createdAt: { gte: startDate, lte: endDate },
      },
      select: {
        doctorId: true,
        patientId: true,
        slot: { select: { date: true, startTime: true } },
      },
    });

    const totalAppointments = await prisma.appointment.count({
      where: { createdAt: { gte: startDate, lte: endDate } },
    });

    const doctorGroups = new Map<string, number>();
    const patientGroups = new Map<string, number>();
    const dayGroups = new Map<string, number>();
    const hourGroups = new Map<number, number>();

    for (const appt of noShowAppointments) {
      doctorGroups.set(appt.doctorId, (doctorGroups.get(appt.doctorId) || 0) + 1);
      const patientId = safeString(appt.patientId);
      patientGroups.set(patientId, (patientGroups.get(patientId) || 0) + 1);
      
      if (appt.slot?.date) {
        const day = new Date(appt.slot.date).toLocaleDateString('en-US', { weekday: 'long' });
        dayGroups.set(day, (dayGroups.get(day) || 0) + 1);
      }
      
      if (appt.slot?.startTime) {
        const hour = new Date(appt.slot.startTime).getHours();
        hourGroups.set(hour, (hourGroups.get(hour) || 0) + 1);
      }
    }

    return {
      totalNoShows: noShowAppointments.length,
      noShowRate: totalAppointments > 0 ? (noShowAppointments.length / totalAppointments) * 100 : 0,
      byDoctor: Array.from(doctorGroups.entries())
        .map(([doctorId, count]) => ({ doctorId, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      byPatient: Array.from(patientGroups.entries())
        .map(([patientId, count]) => ({ patientId, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      byDay: Array.from(dayGroups.entries())
        .map(([day, count]) => ({ day, count }))
        .sort((a, b) => b.count - a.count),
      byTime: Array.from(hourGroups.entries())
        .map(([hour, count]) => ({ hour, count }))
        .sort((a, b) => b.count - a.count),
    };
  }

  // ================================
  // FINANCIAL ANALYTICS
  // ================================

  async getFinancialOverview(dateRange?: DateRangeFilter): Promise<FinancialStats> {
    const { startDate, endDate } = this.getDateRange(dateRange);
    const creditPrice = await creditPriceRepository.getCurrentPrice();
    
    const [
      purchaseTransactions,
      allTransactions,
      topSpenders,
      revenueByWilaya,
      totalUsers,
      payingUsers,
      walletBalance,
    ] = await Promise.all([
      prisma.creditTransaction.findMany({
        where: { type: 'purchase', createdAt: { gte: startDate, lte: endDate } },
        select: { amount: true, createdAt: true },
      }),
      prisma.creditTransaction.findMany({
        where: { createdAt: { gte: startDate, lte: endDate } },
        select: { amount: true, type: true },
      }),
      prisma.payment.findMany({
        where: { status: 'PAID', completedAt: { gte: startDate, lte: endDate } },
        select: {
          amount: true,
          credits: true,
          user: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: { amount: 'desc' },
        take: 10,
      }),
      prisma.payment.findMany({
        where: { status: 'PAID', completedAt: { gte: startDate, lte: endDate } },
        select: {
          amount: true,
          user: { select: { wilaya: { select: { id: true, nameFr: true } } } },
        },
      }),
      prisma.user.count(),
      prisma.user.count({
        where: { payments: { some: { status: 'PAID' } } },
      }),
      prisma.userWallet.aggregate({ _sum: { credits: true } }),
    ]);

    // Process revenue
    const totalRevenue = purchaseTransactions.reduce((sum, t) => sum + t.amount, 0) * creditPrice;
    const totalCreditsSold = purchaseTransactions.reduce((sum, t) => sum + t.amount, 0);

    // Credit utilization
    const purchased = allTransactions.filter(t => t.type === 'purchase').reduce((sum, t) => sum + t.amount, 0);
    const used = Math.abs(allTransactions.filter(t => t.type === 'use').reduce((sum, t) => sum + t.amount, 0));
    const refunded = Math.abs(allTransactions.filter(t => t.type === 'refund').reduce((sum, t) => sum + t.amount, 0));

    // Monthly breakdown
    const monthlyGroups = this.groupByMonth(purchaseTransactions);
    const monthlyRevenue = Array.from(monthlyGroups.entries())
      .map(([month, transactions]) => ({
        month,
        revenue: transactions.reduce((sum, t) => sum + t.amount, 0) * creditPrice,
        transactions: transactions.length,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));

    // Revenue by wilaya - FIXED: handle null wilaya
    const wilayaGroups = new Map<string, { wilayaId: string; wilayaName: string; revenue: number }>();
    for (const payment of revenueByWilaya) {
      const wilaya = payment.user.wilaya;
      if (wilaya) {
        const existing = wilayaGroups.get(wilaya.id) || { wilayaId: wilaya.id, wilayaName: wilaya.nameFr, revenue: 0 };
        existing.revenue += payment.amount;
        wilayaGroups.set(wilaya.id, existing);
      }
    }

    return {
      totalRevenue,
      totalCreditsSold,
      totalTransactions: allTransactions.length,
      avgTransactionValue: allTransactions.length > 0 ? totalRevenue / allTransactions.length : 0,
      revenueByMonth: monthlyRevenue,
      revenueByWilaya: Array.from(wilayaGroups.values()).sort((a, b) => b.revenue - a.revenue),
      topSpenders: topSpenders.map(p => ({
        userId: p.user.id,
        userName: `${p.user.firstName} ${p.user.lastName}`,
        totalSpent: p.amount,
      })),
      creditUtilization: {
        purchased,
        used,
        refunded,
        active: walletBalance._sum.credits || 0,
        utilizationRate: purchased > 0 ? (used / purchased) * 100 : 0,
      },
      arpu: totalUsers > 0 ? totalRevenue / totalUsers : 0,
      arppu: payingUsers > 0 ? totalRevenue / payingUsers : 0,
      conversionRate: totalUsers > 0 ? (payingUsers / totalUsers) * 100 : 0,
    };
  }

  // ================================
  // GROWTH ANALYTICS
  // ================================

  async getGrowthMetrics(): Promise<GrowthStats> {
    const months = this.getLast12Months();
    
    const monthlyData = await Promise.all(
      months.map(async ({ start, end }) => {
        const [
          newUsers,
          totalUsers,
          newDoctors,
          totalDoctors,
          newClinics,
          totalClinics,
          appointments,
          revenueData,
        ] = await Promise.all([
          prisma.user.count({ where: { createdAt: { gte: start, lte: end } } }),
          prisma.user.count({ where: { createdAt: { lte: end } } }),
          prisma.doctor.count({ where: { createdAt: { gte: start, lte: end }, isVerified: true } }),
          prisma.doctor.count({ where: { createdAt: { lte: end }, isVerified: true } }),
          prisma.clinic.count({ where: { createdAt: { gte: start, lte: end }, isVerified: true } }),
          prisma.clinic.count({ where: { createdAt: { lte: end }, isVerified: true } }),
          prisma.appointment.count({ where: { createdAt: { gte: start, lte: end } } }),
          prisma.creditTransaction.aggregate({
            where: { type: 'purchase', createdAt: { gte: start, lte: end } },
            _sum: { amount: true },
          }),
        ]);

        const creditPrice = await creditPriceRepository.getCurrentPrice();

        return {
          month: start.toISOString().slice(0, 7),
          newUsers,
          totalUsers,
          newDoctors,
          totalDoctors,
          newClinics,
          totalClinics,
          appointments,
          revenue: (revenueData._sum.amount || 0) * creditPrice,
        };
      })
    );

    return {
      userGrowth: monthlyData.map((d, i) => ({
        month: d.month,
        newUsers: d.newUsers,
        totalUsers: d.totalUsers,
        growthRate: i > 0 ? this.calculatePercentageChange(monthlyData[i - 1].newUsers, d.newUsers) : 0,
      })),
      doctorGrowth: monthlyData.map((d, i) => ({
        month: d.month,
        newDoctors: d.newDoctors,
        totalDoctors: d.totalDoctors,
        growthRate: i > 0 ? this.calculatePercentageChange(monthlyData[i - 1].newDoctors, d.newDoctors) : 0,
      })),
      clinicGrowth: monthlyData.map((d, i) => ({
        month: d.month,
        newClinics: d.newClinics,
        totalClinics: d.totalClinics,
        growthRate: i > 0 ? this.calculatePercentageChange(monthlyData[i - 1].newClinics, d.newClinics) : 0,
      })),
      appointmentGrowth: monthlyData.map((d, i) => ({
        month: d.month,
        appointments: d.appointments,
        growthRate: i > 0 ? this.calculatePercentageChange(monthlyData[i - 1].appointments, d.appointments) : 0,
      })),
      revenueGrowth: monthlyData.map((d, i) => ({
        month: d.month,
        revenue: d.revenue,
        growthRate: i > 0 ? this.calculatePercentageChange(monthlyData[i - 1].revenue, d.revenue) : 0,
      })),
    };
  }

  // ================================
  // COMPARATIVE ANALYTICS
  // ================================

  async getComparativeAnalytics(comparison: {
    period1: DateRangeFilter;
    period2: DateRangeFilter;
    metrics: string[];
  }): Promise<ComparisonResponse> {
    const period1Dates = this.getDateRange(comparison.period1);
    const period2Dates = this.getDateRange(comparison.period2);

    const getMetrics = async (startDate: Date, endDate: Date): Promise<Record<string, number>> => {
      const metrics: Record<string, number> = {};
      
      if (comparison.metrics.includes('appointments')) {
        metrics.appointments = await prisma.appointment.count({
          where: { createdAt: { gte: startDate, lte: endDate } },
        });
      }
      
      if (comparison.metrics.includes('revenue')) {
        const revenue = await prisma.creditTransaction.aggregate({
          where: { type: 'purchase', createdAt: { gte: startDate, lte: endDate } },
          _sum: { amount: true },
        });
        const creditPrice = await creditPriceRepository.getCurrentPrice();
        metrics.revenue = (revenue._sum.amount || 0) * creditPrice;
      }
      
      if (comparison.metrics.includes('newUsers')) {
        metrics.newUsers = await prisma.user.count({
          where: { createdAt: { gte: startDate, lte: endDate } },
        });
      }
      
      if (comparison.metrics.includes('newDoctors')) {
        metrics.newDoctors = await prisma.doctor.count({
          where: { createdAt: { gte: startDate, lte: endDate }, isVerified: true },
        });
      }
      
      return metrics;
    };

    const [period1Metrics, period2Metrics] = await Promise.all([
      getMetrics(period1Dates.startDate, period1Dates.endDate),
      getMetrics(period2Dates.startDate, period2Dates.endDate),
    ]);

    const changes: Record<string, { absolute: number; percentage: number; trend: 'up' | 'down' | 'stable' }> = {};
    
    for (const metric of comparison.metrics) {
      const oldValue = period1Metrics[metric] || 0;
      const newValue = period2Metrics[metric] || 0;
      const change = this.calculatePercentageChange(oldValue, newValue);
      changes[metric] = {
        absolute: newValue - oldValue,
        percentage: change,
        trend: this.getTrend(change),
      };
    }

    return { period1: period1Metrics, period2: period2Metrics, changes };
  }

  // ================================
  // EXPORT
  // ================================

  async exportAnalytics(type: string, format: string, filters: any): Promise<any> {
    let data: any;
    
    switch (type) {
      case 'doctors':
        data = await this.getDoctorOverview(filters);
        break;
      case 'clinics':
        data = await this.getClinicOverview(filters);
        break;
      case 'users':
        data = await this.getUserOverview(filters);
        break;
      case 'appointments':
        data = await this.getAppointmentAnalytics(filters);
        break;
      case 'financial':
        data = await this.getFinancialOverview(filters);
        break;
      default:
        throw new Error(`Unknown export type: ${type}`);
    }

    if (format === 'csv') {
      return this.convertToCSV(data);
    }

    return data;
  }

  // ================================
  // PRIVATE HELPERS
  // ================================

  private getLast12Months(): Array<{ start: Date; end: Date }> {
    const months = [];
    const now = new Date();
    
    for (let i = 11; i >= 0; i--) {
      const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59, 999);
      months.push({ start, end });
    }
    
    return months;
  }

  private convertToCSV(data: any): string {
    if (!data || typeof data !== 'object') return '';
    
    const flatten = (obj: any, prefix = ''): Record<string, any> => {
      return Object.keys(obj).reduce((acc: Record<string, any>, key: string) => {
        const value = obj[key];
        const newKey = prefix ? `${prefix}.${key}` : key;
        
        if (value && typeof value === 'object' && !Array.isArray(value)) {
          Object.assign(acc, flatten(value, newKey));
        } else if (Array.isArray(value)) {
          acc[newKey] = JSON.stringify(value);
        } else {
          acc[newKey] = value;
        }
        
        return acc;
      }, {});
    };

    const flat = flatten(data);
    const headers = Object.keys(flat).join(',');
    const values = Object.values(flat).map(v => `"${v}"`).join(',');
    
    return `${headers}\n${values}`;
  }
}

export const analyticsService = new AnalyticsService();

