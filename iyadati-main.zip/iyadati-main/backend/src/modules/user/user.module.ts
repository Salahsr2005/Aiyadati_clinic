import { Router } from 'express';
import userRoutes from './v1/user.routes';
import './v1/user.swagger';

const router = Router();
router.use('/v1', userRoutes);

export { router as userModule };

