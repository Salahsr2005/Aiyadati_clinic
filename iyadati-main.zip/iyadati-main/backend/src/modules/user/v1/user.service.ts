import { userRepository } from '../../../repositories/user.repository';
import { NotFoundError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { UserResponse, SuspendUserDTO, UserFilters ,CreateContactUserDTO , UpdateContactUserDTO , ContactUserResponse, UpdateUserDocumentDTO , CreateUserDocumentDTO} from './user.types';
import { contactUserRepository } from '../../../repositories/contact-user.repository';
import { userDocumentRepository } from '../../../repositories/user-document.repository';
import { generateSignedUrl } from '../../../core/utils/signed-url';
import { fileService } from '../../../modules/file/v1/file.service';

export class UserService {
  private toResponse(user: any): UserResponse {
    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
      dateOfBirth: user.dateOfBirth.toISOString(),
      wilayaId: user.wilayaId,
      wilaya: user.wilaya ? {
        id: user.wilaya.id,
        code: user.wilaya.code,
        name: user.wilaya.name,
      } : undefined,
      isVerified: user.isVerified,
      isSuspended: user.isSuspended,
      suspensionReason: user.suspensionReason,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
      noShowCount: user.noShowCount,
      trustPoints: user.trustPoints,
      trustLevel: user.trustLevel,
    };
  }

  async getUsers(filters: UserFilters) {
    const { users, total } = await userRepository.findAllWithFilters(filters);
    return {
        users: users.map((u: any) => this.toResponse(u)),
        total,
    };
  }

  async getUserById(id: string): Promise<UserResponse> {
    const user = await userRepository.findById(id);
    if (!user) throw new NotFoundError('User');
    return this.toResponse(user);
  }

  async getUserByEmail(email: string): Promise<UserResponse> {
    const user = await userRepository.findByEmail(email);
    if (!user) throw new NotFoundError('User');
    return this.toResponse(user);
  }

  async getUserByPhone(phone: string): Promise<UserResponse> {
    const user = await userRepository.findByPhone(phone);
    if (!user) throw new NotFoundError('User');
    return this.toResponse(user);
  }

  async suspendUser(id: string, data: SuspendUserDTO, performedBy: string, ip?: string): Promise<UserResponse> {
    const user = await userRepository.findById(id);
    if (!user) throw new NotFoundError('User');
    
    if (user.isSuspended) {
      throw new BadRequestError('User is already suspended');
    }

    const updated = await userRepository.suspend(id, data.reason);

    eventEmitter.emit('audit', {
      action: 'user.suspended',
      entity: 'User',
      entityId: id,
      performedBy,
      details: { reason: data.reason, userEmail: user.email },
      ip,
    });

    logger.info(`User suspended: ${user.email} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: '⚠️ Account Suspended',
      body: `Your account has been suspended. Reason: ${data.reason}. Please contact support for more information.`,
      type: 'system',
      data: { type: 'account_suspended' },
    });

    return this.toResponse(updated);
  }

  async unsuspendUser(id: string, performedBy: string, ip?: string): Promise<UserResponse> {
    const user = await userRepository.findById(id);
    if (!user) throw new NotFoundError('User');
    
    if (!user.isSuspended) {
      throw new BadRequestError('User is not suspended');
    }

    const updated = await userRepository.unsuspend(id);

    eventEmitter.emit('audit', {
      action: 'user.unsuspended',
      entity: 'User',
      entityId: id,
      performedBy,
      details: { userEmail: user.email },
      ip,
    });

    logger.info(`User unsuspended: ${user.email} by ${performedBy}`);

    eventEmitter.emit('notification', {
      userId: id,
      title: '✅ Account Reinstated',
      body: 'Your account has been unsuspended. Welcome back!',
      type: 'system',
      data: { type: 'account_unsuspended' },
    });

    return this.toResponse(updated);
  }

  async getMyContacts(userId: string): Promise<ContactUserResponse[]> {
    const contacts = await contactUserRepository.findByUserId(userId);
    return contacts.map((c: any) => ({
      id: c.id,
      userId: c.userId,
      firstName: c.firstName,
      lastName: c.lastName,
      phone: c.phone,
      dateOfBirth: c.dateOfBirth.toISOString().slice(0, 10),
      relationship: c.relationship,
      isActive: c.isActive,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    }));
  }

  async createContact(userId: string, data: CreateContactUserDTO): Promise<ContactUserResponse> {
    const c = await contactUserRepository.create({
      userId,
      firstName: data.firstName,
      lastName: data.lastName,
      phone: data.phone,
      dateOfBirth: new Date(data.dateOfBirth),
      relationship: data.relationship,
    });

    return {
      id: c.id,
      userId: c.userId,
      firstName: c.firstName,
      lastName: c.lastName,
      phone: c.phone,
      dateOfBirth: c.dateOfBirth.toISOString().slice(0, 10),
      relationship: c.relationship,
      isActive: c.isActive,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    };
  }

  async updateContact(userId: string, contactId: string, data: UpdateContactUserDTO): Promise<ContactUserResponse> {
    const existing = await contactUserRepository.findById(contactId);
    if (!existing || existing.userId !== userId) throw new NotFoundError('Contact not found');

    const updateData: any = {};
    if (data.firstName) updateData.firstName = data.firstName;
    if (data.lastName) updateData.lastName = data.lastName;
    if (data.phone) updateData.phone = data.phone;
    if (data.dateOfBirth) updateData.dateOfBirth = new Date(data.dateOfBirth);
    if (data.relationship !== undefined) updateData.relationship = data.relationship;

    const c = await contactUserRepository.update(contactId, updateData);
    return {
      id: c.id,
      userId: c.userId,
      firstName: c.firstName,
      lastName: c.lastName,
      phone: c.phone,
      dateOfBirth: c.dateOfBirth.toISOString().slice(0, 10),
      relationship: c.relationship,
      isActive: c.isActive,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    };
  }

  async deleteContact(userId: string, contactId: string): Promise<void> {
    const existing = await contactUserRepository.findById(contactId);
    if (!existing || existing.userId !== userId) throw new NotFoundError('Contact not found');
    await contactUserRepository.softDelete(contactId);
  }

  // ============================================================
  // DOCUMENT METHODS - Using fileId instead of filePath
  // ============================================================

  async getMyDocuments(userId: string, page = 1, limit = 10) {
    const { documents, total } = await userDocumentRepository.findByUserId(userId, page, limit);
    return {
      documents: documents.map((d: any) => ({
        id: d.id,
        userId: d.userId,
        fileName: d.fileName,
        fileType: d.fileType,
        fileSize: d.fileSize,
        title: d.title,
        description: d.description,
        docDate: d.docDate?.toISOString()?.slice(0, 10) || null,
        tags: d.tags ? d.tags.join(', ') : null, // ✅ FIX: Convert array to string
        accessUrl: generateSignedUrl(d.fileId),
        createdAt: d.createdAt.toISOString(),
        updatedAt: d.updatedAt.toISOString(),
      })),
      total,
    };
  }

  async uploadDocument(userId: string, file: Express.Multer.File, data: CreateUserDocumentDTO) {
    // ✅ FIX: Convert comma-separated string to array
    const tags = data.tags ? data.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

    const doc = await userDocumentRepository.create({
      userId,
      fileName: file.originalname,
      filePath: `private/user-documents/${file.filename}`,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: file.filename,
      title: data.title,
      description: data.description,
      docDate: data.docDate ? new Date(data.docDate) : undefined,
      tags: tags, // ✅ FIX: Pass array
      storageType: 'private',
      category: 'document',
    });

    return {
      id: doc.id,
      userId: doc.userId,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      title: doc.title,
      description: doc.description,
      docDate: doc.docDate?.toISOString()?.slice(0, 10) || null,
      tags: doc.tags ? doc.tags.join(', ') : null, // ✅ FIX: Convert array to string
      accessUrl: generateSignedUrl(doc.fileId),
      createdAt: doc.createdAt.toISOString(),
      updatedAt: doc.updatedAt.toISOString(),
    };
  }

  async updateDocument(userId: string, docId: string, data: UpdateUserDocumentDTO) {
    const doc = await userDocumentRepository.findById(docId);
    if (!doc || doc.userId !== userId) throw new NotFoundError('Document not found');
    
    // ✅ FIX: Convert comma-separated string to array (if provided)
    const tags = data.tags ? data.tags.split(',').map(t => t.trim()).filter(Boolean) : undefined;
    
    const updated = await userDocumentRepository.update(docId, {
      title: data.title,
      description: data.description,
      docDate: data.docDate ? new Date(data.docDate) : undefined,
      tags: tags, // ✅ FIX: Pass array (or undefined)
    });
    
    return {
      id: updated.id,
      userId: updated.userId,
      fileName: updated.fileName,
      fileType: updated.fileType,
      fileSize: updated.fileSize,
      title: updated.title,
      description: updated.description,
      docDate: updated.docDate?.toISOString()?.slice(0, 10) || null,
      tags: updated.tags ? updated.tags.join(', ') : null, // ✅ FIX: Convert array to string
      accessUrl: generateSignedUrl(updated.fileId),
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    };
  }

  async deleteDocument(userId: string, docId: string, userRole: string = 'USER'): Promise<void> {
    const doc = await userDocumentRepository.findById(docId);
    if (!doc) throw new NotFoundError('Document not found');
    
    // Check ownership
    if (doc.userId !== userId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('You can only delete your own documents');
    }
    
    // Delete from disk using file service (uses Phase 2 abstraction)
    await fileService.deleteFile(doc.fileId, userId, userRole, false);
    
    // Delete from database
    // await userDocumentRepository.delete(docId);
    
    logger.info(`User document deleted: ${doc.fileName} by user ${userId}`);
  }

}

export const userService = new UserService();

