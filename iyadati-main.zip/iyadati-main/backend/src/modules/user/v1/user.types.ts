export interface UserResponse {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  dateOfBirth: string;
  wilayaId: string;
  wilaya?: {
    id: string;
    code: number;
    name: string;
  };
  isVerified: boolean;
  isSuspended: boolean;
  suspensionReason: string | null;
  createdAt: string;
  updatedAt: string;
  noShowCount: number;
  trustPoints: number;
  trustLevel: number;
}

export interface SuspendUserDTO {
  reason: string;
}

export interface UserFilters {
  search?: string;
  email?: string;
  phone?: string;
  firstName?: string;
  lastName?: string;
  wilayaId?: string;
  isVerified?: boolean;
  isSuspended?: boolean;
  dateOfBirthFrom?: string;
  dateOfBirthTo?: string;
  createdAtFrom?: string;
  createdAtTo?: string;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface CreateContactUserDTO {
  firstName: string;
  lastName: string;
  phone: string;
  dateOfBirth: string;
  relationship?: string;
}

export interface UpdateContactUserDTO {
  firstName?: string;
  lastName?: string;
  phone?: string;
  dateOfBirth?: string;
  relationship?: string;
}

export interface ContactUserResponse {
  id: string;
  userId: string;
  firstName: string;
  lastName: string;
  phone: string;
  dateOfBirth: string;
  relationship: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateUserDocumentDTO {
  title?: string;
  description?: string;
  docDate?: string;
  tags?: string;
}

export interface UpdateUserDocumentDTO {
  title?: string;
  description?: string;
  docDate?: string;
  tags?: string;
}

export interface UserDocumentResponse {
  id: string;
  userId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  title: string | null;
  description: string | null;
  docDate: string | null;
  tags: string | null;
  accessUrl: string;
  createdAt: string;
  updatedAt: string;
}

