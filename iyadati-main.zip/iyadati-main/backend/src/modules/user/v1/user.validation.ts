import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const suspendUserSchema = Joi.object({
  reason: Joi.string()
    .min(3)
    .max(500)
    .required()
    .messages({
      'string.min': 'Reason must be at least 3 characters',
      'string.max': 'Reason must be less than 500 characters',
      'any.required': 'Suspension reason is required',
    }),
});

const userFiltersSchema = Joi.object({
  search: Joi.string().optional().allow(''),
  email: Joi.string().email().optional(),
  phone: Joi.string().optional(),
  firstName: Joi.string().optional(),
  lastName: Joi.string().optional(),
  wilayaId: Joi.string().uuid().optional(),
  isVerified: Joi.boolean().optional(),
  isSuspended: Joi.boolean().optional(),
  dateOfBirthFrom: Joi.date().iso().optional(),
  dateOfBirthTo: Joi.date().iso().optional(),
  createdAtFrom: Joi.date().iso().optional(),
  createdAtTo: Joi.date().iso().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sortBy: Joi.string().valid('createdAt', 'firstName', 'lastName', 'email', 'dateOfBirth').default('createdAt'),
  sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
});

export const validateSuspendUser = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = suspendUserSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUserFilters = (req: Request, res: Response, next: NextFunction): void => {
  const { error, value } = userFiltersSchema.validate(req.query, { abortEarly: false, stripUnknown: true });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  req.query = value;
  next();
};

const createContactUserSchema = Joi.object({
  firstName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'First name must be at least 2 characters',
    'any.required': 'First name is required',
  }),
  lastName: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Last name must be at least 2 characters',
    'any.required': 'Last name is required',
  }),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).required().messages({
    'string.length': 'Phone must be exactly 10 digits',
    'any.required': 'Phone is required',
  }),
  dateOfBirth: Joi.date().iso().max('now').required().messages({
    'date.format': 'Date of birth must be in ISO format (YYYY-MM-DD)',
    'any.required': 'Date of birth is required',
  }),
  relationship: Joi.string().valid('parent', 'child', 'spouse', 'sibling', 'other').optional(),
});

const updateContactUserSchema = Joi.object({
  firstName: Joi.string().min(2).max(50).optional(),
  lastName: Joi.string().min(2).max(50).optional(),
  phone: Joi.string().length(10).pattern(/^[0-9]+$/).optional(),
  dateOfBirth: Joi.date().iso().max('now').optional(),
  relationship: Joi.string().valid('parent', 'child', 'spouse', 'sibling', 'other').optional().allow(null, ''),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateContactUser = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createContactUserSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateContactUser = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateContactUserSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

const createUserDocumentSchema = Joi.object({
  title: Joi.string().max(200).optional(),
  description: Joi.string().max(500).optional().allow(null, ''),
  docDate: Joi.date().iso().optional(),
  tags: Joi.string().max(300).optional(),
});

const updateUserDocumentSchema = Joi.object({
  title: Joi.string().max(200).optional(),
  description: Joi.string().max(500).optional().allow(null, ''),
  docDate: Joi.date().iso().optional().allow(null),
  tags: Joi.string().max(300).optional().allow(null, ''),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateUserDocument = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createUserDocumentSchema.validate(req.body, { abortEarly: false });
  if (error) { const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); ResponseUtil.validationError(res, 'Validation failed', errors); return; }
  next();
};

export const validateUpdateUserDocument = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateUserDocumentSchema.validate(req.body, { abortEarly: false });
  if (error) { const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); ResponseUtil.validationError(res, 'Validation failed', errors); return; }
  next();
};
