import { Router } from 'express';
import { UserController } from './user.controller';
import { 
  validateSuspendUser, 
  validateUserFilters,
  validateCreateContactUser, 
  validateUpdateContactUser,
  validateCreateUserDocument, 
  validateUpdateUserDocument,
} from './user.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import { uploadUserDocument } from '../../../core/middleware/upload.middleware';

const router = Router();
const userController = new UserController();

// ============================================================
// User Self-Service Routes - MUST be before /:id staff routes
// ============================================================

// Contacts
router.get('/me/contacts', authenticate, authorize('USER'), userController.getMyContacts);
router.post('/me/contacts', authenticate, authorize('USER'), validateCreateContactUser, userController.createContact);
router.patch('/me/contacts/:id', authenticate, authorize('USER'), validateUpdateContactUser, userController.updateContact);
router.delete('/me/contacts/:id', authenticate, authorize('USER'), userController.deleteContact);

// Medical Documents
router.get('/me/documents', authenticate, authorize('USER'), userController.getMyDocuments);
router.post('/me/documents', authenticate, authorize('USER'), uploadUserDocument, validateCreateUserDocument, userController.uploadDocument);
router.patch('/me/documents/:id', authenticate, authorize('USER'), validateUpdateUserDocument, userController.updateDocument);
router.delete('/me/documents/:id', authenticate, authorize('USER'), userController.deleteDocument);

// ============================================================
// Staff Routes (Super Admin + Admin)
// ============================================================

router.get(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN','DOCTOR'), 
  validateUserFilters,
  userController.getUsers
);

router.get('/id/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN','DOCTOR'), userController.getUserById);
router.get('/email/:email', authenticate, authorize('SUPER_ADMIN', 'ADMIN','DOCTOR'), userController.getUserByEmail);
router.get('/phone/:phone', authenticate, authorize('SUPER_ADMIN', 'ADMIN','DOCTOR'), userController.getUserByPhone);

router.post(
  '/:id/suspend',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({ windowMinutes: 15, maxRequests: 20, message: 'Too many suspension requests' }),
  validateSuspendUser,
  userController.suspendUser
);

router.patch(
  '/:id/unsuspend',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  createRateLimiter({ windowMinutes: 15, maxRequests: 20, message: 'Too many unsuspension requests' }),
  userController.unsuspendUser
);

export default router;

