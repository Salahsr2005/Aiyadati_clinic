import { doctorRepository } from '../../../repositories/doctor.repository';
import { doctorAvailabilityRepository } from '../../../repositories/doctor-availability.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { specialtyRepository } from '../../../repositories/specialty.repository';
import { NotFoundError } from '../../../core/utils/error';
import { env } from '../../../config/env';
import { PublicDoctorResponse, PublicClinicResponse } from './public.types';
import { prisma } from '../../../core/utils/prisma';
import { clinicGalleryRepository } from '../../../repositories/clinic-gallery.repository';
import { generatePublicUrl } from '../../../core/utils/signed-url';

export class PublicService {
  // === Doctors ===

  private toPublicDoctor(d: any): PublicDoctorResponse {
    const latestLogo = d.logos && d.logos.length > 0 ? d.logos[0] : null;

    return {
      id: d.id,
      email: d.email,
      firstNameFr: d.firstNameFr,
      firstNameAr: d.firstNameAr,
      lastNameFr: d.lastNameFr,
      lastNameAr: d.lastNameAr,
      photoUrl: d.photoFileId 
        ? generatePublicUrl(d.photoFileId) 
        : latestLogo?.fileId 
          ? generatePublicUrl(latestLogo.fileId)
          : d.photoPath 
            ? `${env.BASE_URL}/uploads/${d.photoPath}` 
            : null,
      bioFr: d.bioFr,
      bioAr: d.bioAr,
      yearsOfExp: d.yearsOfExp,
      practiceType: d.practiceType,
      latitude: d.latitude,
      longitude: d.longitude,
      wilaya: d.wilaya ? { id: d.wilaya.id, code: d.wilaya.code, nameFr: d.wilaya.nameFr, nameAr: d.wilaya.nameAr } : null,
      baladya: d.baladya ? { id: d.baladya.id, nameFr: d.baladya.nameFr, nameAr: d.baladya.nameAr } : null,
      specialties: d.specialties?.map((s: any) => ({ id: s.specialty.id, nameFr: s.specialty.nameFr, nameAr: s.specialty.nameAr })) || [],
      isCompleted: d.isCompleted,
      isAvailableForBooking: d.isAvailableForBooking,
      messageForUser: d.messageForUser,
    };
  }

  async getDoctors(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      search: params.search || undefined,
      wilayaId: params.wilayaId || undefined,
      specialtyId: params.specialtyId || undefined,
      practiceType: params.practiceType || undefined,
      isVerified: true,
      isSuspended: false,
      isCompleted: true,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };

    const { doctors, total } = await doctorRepository.findAll(parsedParams);
    return {
      doctors: doctors.map((d: any) => this.toPublicDoctor(d)),
      total,
    };
  }

  async getDoctorById(id: string): Promise<PublicDoctorResponse> {
    const doctor = await doctorRepository.findById(id);
    if (!doctor || !doctor.isVerified || doctor.isSuspended || !doctor.isCompleted) {
      throw new NotFoundError('Doctor not found');
    }
    return this.toPublicDoctor(doctor);
  }

  async getDoctorAvailability(doctorId: string) {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor || !doctor.isVerified || doctor.isSuspended) {
      throw new NotFoundError('Doctor not found');
    }
    const slots = await doctorAvailabilityRepository.findByDoctorId(doctorId);
    return slots.map((s: any) => ({
      id: s.id,
      dayOfWeek: s.dayOfWeek,
      startTime: s.startTime.toISOString().slice(11, 16),
      endTime: s.endTime.toISOString().slice(11, 16),
      clinicId: s.clinicId,
      clinic: s.clinic ? { id: s.clinic.id, nameFr: s.clinic.nameFr, nameAr: s.clinic.nameAr } : null,
    }));
  }

  // === Clinics ===

  private toPublicClinic(c: any): PublicClinicResponse {
    return {
      id: c.id,
      nameFr: c.nameFr,
      nameAr: c.nameAr,
      descriptionFr: c.descriptionFr,
      descriptionAr: c.descriptionAr,
      logoUrl: c.logoFileId 
        ? generatePublicUrl(c.logoFileId) 
        : c.logoPath 
          ? `${env.BASE_URL}/uploads/${c.logoPath}` 
          : null,
      latitude: c.latitude,
      longitude: c.longitude,
      phone: c.phone,
      wilaya: c.wilaya ? { id: c.wilaya.id, code: c.wilaya.code, nameFr: c.wilaya.nameFr, nameAr: c.wilaya.nameAr } : null,
      baladya: c.baladya ? { id: c.baladya.id, nameFr: c.baladya.nameFr, nameAr: c.baladya.nameAr } : null,
      isCompleted: c.isCompleted,
    };
  }

  async getClinics(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      search: params.search || undefined,
      wilayaId: params.wilayaId || undefined,
      isVerified: true,
      isSuspended: false,
      isCompleted: true,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };

    const { clinics, total } = await clinicRepository.findAll(parsedParams);
    return {
      clinics: clinics.map((c: any) => this.toPublicClinic(c)),
      total,
    };
  }

  async getClinicById(id: string): Promise<PublicClinicResponse> {
    const clinic = await clinicRepository.findById(id);
    if (!clinic || !clinic.isVerified || clinic.isSuspended) {
      throw new NotFoundError('Clinic not found');
    }
    return this.toPublicClinic(clinic);
  }

  async getClinicDoctors(clinicId: string) {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic || !clinic.isVerified || clinic.isSuspended) {
      throw new NotFoundError('Clinic not found');
    }
    const links = await prisma.clinicDoctor.findMany({
      where: { clinicId, status: 'ACCEPTED', isActive: true },
      include: { 
        doctor: { 
          include: { 
            specialties: { include: { specialty: true } }, 
            wilaya: true,
            logos: {
              orderBy: { createdAt: 'desc' },
              take: 1,
            },
          } 
        } 
      },
    });
    return links.map((l: any) => this.toPublicDoctor(l.doctor));
  }

  // === Specialties ===

  async getSpecialties(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 10,
      search: params.search || undefined,
      isActive: true,
      sortBy: params.sortBy || 'createdAt',
      sortOrder: params.sortOrder || 'desc',
    };
    const result = await specialtyRepository.findAll(parsedParams);
    return {
      ...result,
      specialties: result.specialties.map((s: any) => ({
        ...s,
        imageUrl: s.fileId 
          ? generatePublicUrl(s.fileId) 
          : s.imagePath 
            ? `${env.BASE_URL}/uploads/${s.imagePath}` 
            : null,
      })),
    };
  }

  async getClinicGallery(clinicId: string) {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic || !clinic.isVerified || clinic.isSuspended) {
      throw new NotFoundError('Clinic not found');
    }
    const images = await clinicGalleryRepository.findByClinicId(clinicId);
    return images.map((img: any) => ({
      id: img.id,
      imageUrl: img.fileId 
        ? generatePublicUrl(img.fileId) 
        : `${env.BASE_URL}/uploads/${img.imagePath}`,
      captionFr: img.captionFr,
      captionAr: img.captionAr,
      sortOrder: img.sortOrder,
    }));
  }
}

export const publicService = new PublicService();

