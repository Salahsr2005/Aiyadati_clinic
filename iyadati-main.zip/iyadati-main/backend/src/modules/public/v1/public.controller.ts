import { Request, Response, NextFunction } from 'express';
import { publicService } from './public.service';
import { ResponseUtil } from '../../../core/utils/response';

export class PublicController {
  // Doctors
  getDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { doctors, total } = await publicService.getDoctors(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      ResponseUtil.paginated(res, doctors, total, page, limit, 'Doctors retrieved successfully');
    } catch (error) { next(error); }
  };

  getDoctorById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctor = await publicService.getDoctorById(req.params.id);
      ResponseUtil.success(res, doctor, 'Doctor retrieved successfully');
    } catch (error) { next(error); }
  };

  getDoctorAvailability = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const slots = await publicService.getDoctorAvailability(req.params.id);
      ResponseUtil.success(res, slots, 'Doctor availability retrieved');
    } catch (error) { next(error); }
  };

  // Clinics
  getClinics = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { clinics, total } = await publicService.getClinics(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      ResponseUtil.paginated(res, clinics, total, page, limit, 'Clinics retrieved successfully');
    } catch (error) { next(error); }
  };

  getClinicById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const clinic = await publicService.getClinicById(req.params.id);
      ResponseUtil.success(res, clinic, 'Clinic retrieved successfully');
    } catch (error) { next(error); }
  };

  getClinicDoctors = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doctors = await publicService.getClinicDoctors(req.params.id);
      ResponseUtil.success(res, doctors, 'Clinic doctors retrieved');
    } catch (error) { next(error); }
  };

  // Specialties
  getSpecialties = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { specialties, total } = await publicService.getSpecialties(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      ResponseUtil.paginated(res, specialties, total, page, limit, 'Specialties retrieved successfully');
    } catch (error) { next(error); }
  };

  getClinicGallery = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const images = await publicService.getClinicGallery(req.params.id);
      ResponseUtil.success(res, images, 'Clinic gallery retrieved');
    } catch (error) { next(error); }
  };
}

