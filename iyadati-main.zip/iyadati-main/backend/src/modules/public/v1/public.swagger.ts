/**
 * @swagger
 * tags:
 *   name: Public
 *   description: Public endpoints for browsing doctors, clinics, and specialties (no auth required)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     PublicDoctorResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         firstNameFr:
 *           type: string
 *         firstNameAr:
 *           type: string
 *         email:
 *           type: string
 *           format: email
 *         lastNameFr:
 *           type: string
 *         lastNameAr:
 *           type: string
 *         photoUrl:
 *           type: string
 *           nullable: true
 *         bioFr:
 *           type: string
 *           nullable: true
 *         bioAr:
 *           type: string
 *           nullable: true
 *         yearsOfExp:
 *           type: integer
 *           nullable: true
 *         practiceType:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *         latitude:
 *           type: number
 *           nullable: true
 *         longitude:
 *           type: number
 *           nullable: true
 *         wilaya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             code:
 *               type: integer
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         baladya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         specialties:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               nameFr:
 *                 type: string
 *               nameAr:
 *                 type: string
 *         isCompleted:
 *           type: boolean
 *         isAvailableForBooking:
 *           type: boolean
 *           description: Indicates if the doctor is currently available for booking
 *         messageForUser:
 *           type: string
 *           nullable: true
 *           description: Optional message displayed to users when the doctor is not available
 *     PublicClinicResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         nameFr:
 *           type: string
 *         nameAr:
 *           type: string
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         logoUrl:
 *           type: string
 *           nullable: true
 *         latitude:
 *           type: number
 *           nullable: true
 *         longitude:
 *           type: number
 *           nullable: true
 *         phone:
 *           type: string
 *         wilaya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             code:
 *               type: integer
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         baladya:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *         isCompleted:
 *           type: boolean
 *     PublicAvailabilityResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         dayOfWeek:
 *           type: string
 *           enum: [SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY]
 *         startTime:
 *           type: string
 *           example: "09:00"
 *         endTime:
 *           type: string
 *           example: "17:00"
 *         clinicId:
 *           type: string
 *           nullable: true
 *         clinic:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             nameFr:
 *               type: string
 *             nameAr:
 *               type: string
 *     PublicGalleryImageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         imageUrl:
 *           type: string
 *           description: Public URL for gallery image
 *         captionFr:
 *           type: string
 *           nullable: true
 *         captionAr:
 *           type: string
 *           nullable: true
 *         sortOrder:
 *           type: integer
 *     SpecialtyResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         nameFr:
 *           type: string
 *         nameAr:
 *           type: string
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *         imageUrl:
 *           type: string
 *           nullable: true
 *         isActive:
 *           type: boolean
 *     Error:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         error:
 *           type: string
 *         statusCode:
 *           type: integer
 *     PaginatedResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *         data:
 *           type: array
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *             limit:
 *               type: integer
 *             total:
 *               type: integer
 *             totalPages:
 *               type: integer
 */

/**
 * @swagger
 * /api/v1/public/v1/doctors:
 *   get:
 *     summary: Browse doctors (Public)
 *     description: Returns a paginated list of verified, active doctors. No auth required.
 *     tags: [Public]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by name, email, or phone
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *         description: Filter by wilaya ID
 *       - in: query
 *         name: specialtyId
 *         schema:
 *           type: string
 *         description: Filter by specialty ID
 *       - in: query
 *         name: practiceType
 *         schema:
 *           type: string
 *           enum: [INDEPENDENT, CLINIC_BASED, BOTH]
 *         description: Filter by practice type
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of items per page
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           default: createdAt
 *         description: Field to sort by
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           default: desc
 *           enum: [asc, desc]
 *         description: Sort order
 *     responses:
 *       200:
 *         description: Doctors retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/PaginatedResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/PublicDoctorResponse'
 *       400:
 *         description: Invalid query parameters
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/doctors/{id}:
 *   get:
 *     summary: Get doctor profile (Public)
 *     description: Returns detailed information about a specific doctor.
 *     tags: [Public]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Doctor retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                 data:
 *                   $ref: '#/components/schemas/PublicDoctorResponse'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/doctors/{id}/availability:
 *   get:
 *     summary: Get doctor availability (Public)
 *     description: Returns the doctor's recurring weekly schedule.
 *     tags: [Public]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Doctor ID
 *     responses:
 *       200:
 *         description: Availability retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/PublicAvailabilityResponse'
 *       404:
 *         description: Doctor not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/clinics:
 *   get:
 *     summary: Browse clinics (Public)
 *     description: Returns a paginated list of verified, active clinics. No auth required.
 *     tags: [Public]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by clinic name or phone
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *         description: Filter by wilaya ID
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of items per page
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           default: createdAt
 *         description: Field to sort by
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           default: desc
 *           enum: [asc, desc]
 *         description: Sort order
 *     responses:
 *       200:
 *         description: Clinics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/PaginatedResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/PublicClinicResponse'
 *       400:
 *         description: Invalid query parameters
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/clinics/{id}:
 *   get:
 *     summary: Get clinic profile (Public)
 *     description: Returns detailed information about a specific clinic.
 *     tags: [Public]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Clinic ID
 *     responses:
 *       200:
 *         description: Clinic retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                 data:
 *                   $ref: '#/components/schemas/PublicClinicResponse'
 *       404:
 *         description: Clinic not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/clinics/{id}/doctors:
 *   get:
 *     summary: Get clinic's doctors (Public)
 *     description: Returns all active doctors at a clinic.
 *     tags: [Public]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Clinic ID
 *     responses:
 *       200:
 *         description: Doctors retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/PublicDoctorResponse'
 *       404:
 *         description: Clinic not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/clinics/{id}/gallery:
 *   get:
 *     summary: Get clinic gallery (Public)
 *     description: Returns all gallery images for a clinic.
 *     tags: [Public]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Clinic ID
 *     responses:
 *       200:
 *         description: Gallery retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/PublicGalleryImageResponse'
 *       404:
 *         description: Clinic not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/public/v1/specialties:
 *   get:
 *     summary: Browse specialties (Public)
 *     description: Returns a paginated list of active medical specialties. No auth required.
 *     tags: [Public]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by specialty name
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of items per page
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           default: createdAt
 *         description: Field to sort by
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           default: desc
 *           enum: [asc, desc]
 *         description: Sort order
 *     responses:
 *       200:
 *         description: Specialties retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/PaginatedResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/SpecialtyResponse'
 *       400:
 *         description: Invalid query parameters
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */