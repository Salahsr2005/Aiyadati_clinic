import { Router } from 'express';
import { PublicController } from './public.controller';

const router = Router();
const publicController = new PublicController();

// Doctors
router.get('/doctors', publicController.getDoctors);
router.get('/doctors/:id', publicController.getDoctorById);
router.get('/doctors/:id/availability', publicController.getDoctorAvailability);

// Clinics
router.get('/clinics', publicController.getClinics);
router.get('/clinics/:id', publicController.getClinicById);
router.get('/clinics/:id/doctors', publicController.getClinicDoctors);

// Specialties
router.get('/specialties', publicController.getSpecialties);

router.get('/clinics/:id/gallery', publicController.getClinicGallery);

export default router;

