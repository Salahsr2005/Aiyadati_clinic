export interface PublicDoctorResponse {
  id: string;
  email: string;
  firstNameFr: string;
  firstNameAr: string;
  lastNameFr: string;
  lastNameAr: string;
  photoUrl: string | null;
  bioFr: string | null;
  bioAr: string | null;
  yearsOfExp: number | null;
  practiceType: string;
  latitude: number | null;
  longitude: number | null;
  wilaya: { id: string; code: number; nameFr: string; nameAr: string } | null;
  baladya: { id: string; nameFr: string; nameAr: string } | null;
  specialties: { id: string; nameFr: string; nameAr: string }[];
  isCompleted: boolean;
  isAvailableForBooking: boolean;
  messageForUser: string | null;
}

export interface PublicClinicResponse {
  id: string;
  nameFr: string;
  nameAr: string;
  descriptionFr: string | null;
  descriptionAr: string | null;
  logoUrl: string | null;
  latitude: number | null;
  longitude: number | null;
  phone: string;
  wilaya: { id: string; code: number; nameFr: string; nameAr: string } | null;
  baladya: { id: string; nameFr: string; nameAr: string } | null;
  isCompleted: boolean;
}

