import { Router } from 'express';
import publicRoutes from './v1/public.routes';
import './v1/public.swagger';

const router = Router();
router.use('/v1', publicRoutes);

export { router as publicModule };

