import { userDeviceRepository } from '../../../repositories/user-device.repository';
import { notificationRepository } from '../../../repositories/notification.repository';
import { RegisterDeviceDTO, NotificationResponse } from './notification.types';

export class NotificationService {
  async registerDevice(userId: string, data: RegisterDeviceDTO) {
    return userDeviceRepository.upsert(userId, data.deviceToken, data.platform);
  }

  async unregisterDevice(userId: string, deviceToken: string) {
    return userDeviceRepository.deactivate(userId, deviceToken);
  }

  async getMyNotifications(userId: string, page = 1, limit = 20) {
    const { notifications, total } = await notificationRepository.findByUserId(userId, page, limit);
    return {
      notifications: notifications.map(n => ({
        id: n.id, userId: n.userId, title: n.title, body: n.body,
        type: n.type, data: n.data, isRead: n.isRead,
        createdAt: n.createdAt.toISOString(),
      })),
      total,
    };
  }

  async markAsRead(id: string) {
    return notificationRepository.markAsRead(id);
  }

  async markAllAsRead(userId: string) {
    return notificationRepository.markAllAsRead(userId);
  }
}

export const notificationService = new NotificationService();

