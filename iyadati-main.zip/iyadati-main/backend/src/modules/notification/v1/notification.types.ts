export interface RegisterDeviceDTO {
  deviceToken: string;
  platform: 'android' | 'ios' | 'web';
}

export interface NotificationResponse {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: string;
  data: any;
  isRead: boolean;
  createdAt: string;
}

