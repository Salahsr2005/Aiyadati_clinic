/**
 * @swagger
 * tags:
 *   name: Notification
 *   description: Push notifications and device registration endpoints
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     RegisterDeviceRequest:
 *       type: object
 *       required:
 *         - deviceToken
 *         - platform
 *       properties:
 *         deviceToken:
 *           type: string
 *           description: FCM device token from Firebase
 *           example: "f7bNn9s3Q0qS5n8r2pL4mA:APA91bH..."
 *         platform:
 *           type: string
 *           enum: [android, ios, web]
 *           description: Device platform
 *           example: "android"
 *     UnregisterDeviceRequest:
 *       type: object
 *       required:
 *         - deviceToken
 *       properties:
 *         deviceToken:
 *           type: string
 *           description: FCM device token to unregister
 *           example: "f7bNn9s3Q0qS5n8r2pL4mA:APA91bH..."
 *     NotificationResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         userId:
 *           type: string
 *         title:
 *           type: string
 *           example: "New Appointment"
 *         body:
 *           type: string
 *           example: "Patient Ahmed Benali booked for July 5 at 10:00"
 *         type:
 *           type: string
 *           enum: [appointment, chat, payment, system]
 *           description: |
 *             Notification type:
 *             - appointment: Appointment updates
 *             - chat: New support messages
 *             - payment: Credit/payment updates
 *             - system: Account updates, verifications
 *         data:
 *           type: object
 *           nullable: true
 *           description: Extra data (appointmentId, roomId, etc.)
 *           example: { "appointmentId": "uuid", "type": "new_booking" }
 *         isRead:
 *           type: boolean
 *           example: false
 *         createdAt:
 *           type: string
 *           format: date-time
 */

/**
 * @swagger
 * /api/v1/notification/v1/register-device:
 *   post:
 *     summary: Register device for push notifications
 *     description: |
 *       Registers a device token for receiving push notifications.
 *       Call this when user logs in and grants notification permission.
 *       Supports Android, iOS, and Web platforms via Firebase Cloud Messaging.
 *     tags: [Notification]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterDeviceRequest'
 *           example:
 *             deviceToken: "f7bNn9s3Q0qS5n8r2pL4mA:APA91bH..."
 *             platform: "android"
 *     responses:
 *       200:
 *         description: Device registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Device registered
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/notification/v1/unregister-device:
 *   delete:
 *     summary: Unregister device from push notifications
 *     description: |
 *       Removes a device token. Call this when user logs out.
 *     tags: [Notification]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UnregisterDeviceRequest'
 *     responses:
 *       200:
 *         description: Device unregistered
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Device unregistered
 */

/**
 * @swagger
 * /api/v1/notification/v1/my-notifications:
 *   get:
 *     summary: Get my notifications
 *     description: |
 *       Returns paginated list of notifications for the authenticated user.
 *       Includes in-app notifications and push notification history.
 *     tags: [Notification]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Items per page
 *     responses:
 *       200:
 *         description: Notifications retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Notifications retrieved
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/NotificationResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     total:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *             example:
 *               success: true
 *               message: "Notifications retrieved"
 *               data:
 *                 - id: "uuid"
 *                   userId: "uuid"
 *                   title: "New Appointment"
 *                   body: "Patient Ahmed Benali booked for July 5 at 10:00"
 *                   type: "appointment"
 *                   data: { "appointmentId": "uuid" }
 *                   isRead: false
 *                   createdAt: "2026-07-03T10:00:00.000Z"
 *                 - id: "uuid"
 *                   userId: "uuid"
 *                   title: "Payment Confirmed"
 *                   body: "5 credits added to your wallet"
 *                   type: "payment"
 *                   data: { "credits": 5 }
 *                   isRead: true
 *                   createdAt: "2026-07-02T15:30:00.000Z"
 */

/**
 * @swagger
 * /api/v1/notification/v1/{id}/read:
 *   patch:
 *     summary: Mark notification as read
 *     tags: [Notification]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Notification ID
 *     responses:
 *       200:
 *         description: Marked as read
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Marked as read
 */

/**
 * @swagger
 * /api/v1/notification/v1/read-all:
 *   patch:
 *     summary: Mark all notifications as read
 *     tags: [Notification]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All marked as read
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: All marked as read
 */

/**
 * @swagger
 * /push-notifications:
 *   description: |
 *     ## Push Notification System
 *     
 *     Iyadati uses **Firebase Cloud Messaging (FCM)** for push notifications on Android and iOS.
 *     
 *     ### Notification Types & Triggers
 *     
 *     | Type | When | Recipient | Example |
 *     |------|------|-----------|---------|
 *     | `appointment` | New booking | Doctor | "Patient X booked for July 5" |
 *     | `appointment` | Confirmed | Patient | "Your appointment is confirmed" |
 *     | `appointment` | Reminder (24h before) | Patient | "Appointment tomorrow at 10:00" |
 *     | `appointment` | Cancelled | Both | "Appointment cancelled" |
 *     | `appointment` | No-show marked | Patient | "Missed appointment recorded" |
 *     | `chat` | New support message | User/Doctor/Clinic | "Support: How can I help?" |
 *     | `payment` | Credits purchased | User | "5 credits added to wallet" |
 *     | `payment` | Credit refunded | User | "1 credit refunded" |
 *     | `system` | Account verified | Doctor/Clinic | "Your account is verified!" |
 *     | `system` | Account suspended | User/Doctor/Clinic | "Account suspended: ..." |
 *     | `system` | Trust level change | User | "You are now a Trusted Patient!" |
 *     
 *     ### Mobile Integration
 *     
 *     ```javascript
 *     // 1. Get FCM token
 *     import messaging from '@react-native-firebase/messaging';
 *     const token = await messaging().getToken();
 *     
 *     // 2. Register with backend
 *     await fetch('/api/v1/notification/v1/register-device', {
 *       method: 'POST',
 *       headers: { 'Authorization': 'Bearer ' + jwt },
 *       body: JSON.stringify({ deviceToken: token, platform: 'android' })
 *     });
 *     
 *     // 3. Handle incoming notifications
 *     messaging().onMessage(async (remoteMessage) => {
 *       // Show in-app notification
 *     });
 *     ```
 */