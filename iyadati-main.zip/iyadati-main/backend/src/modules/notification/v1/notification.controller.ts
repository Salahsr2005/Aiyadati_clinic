import { Request, Response, NextFunction } from 'express';
import { notificationService } from './notification.service';
import { ResponseUtil } from '../../../core/utils/response';
import { sendPushNotification } from '../../../config/firebase';

export class NotificationController {
  registerDevice = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await notificationService.registerDevice(req.user!.id, req.body);
      ResponseUtil.success(res, null, 'Device registered');
    } catch (error) { next(error); }
  };

  unregisterDevice = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await notificationService.unregisterDevice(req.user!.id, req.body.deviceToken);
      ResponseUtil.success(res, null, 'Device unregistered');
    } catch (error) { next(error); }
  };

  getMyNotifications = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { notifications, total } = await notificationService.getMyNotifications(
        req.user!.id,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20
      );
      ResponseUtil.paginated(res, notifications, total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20,
        'Notifications retrieved'
      );
    } catch (error) { next(error); }
  };

  markAsRead = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await notificationService.markAsRead(req.params.id);
      ResponseUtil.success(res, null, 'Marked as read');
    } catch (error) { next(error); }
  };

  markAllAsRead = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await notificationService.markAllAsRead(_req.user!.id);
      ResponseUtil.success(res, null, 'All marked as read');
    } catch (error) { next(error); }
  };
  
    sendTestNotification = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { title, body, deviceToken } = req.body;
        
        const success = await sendPushNotification({
        deviceToken,
        title: title || 'Test Notification',
        body: body || 'This is a test notification from Iyadati!',
        data: { type: 'test', timestamp: new Date().toISOString() },
        });

        if (success) {
        ResponseUtil.success(res, null, 'Test notification sent');
        } else {
        ResponseUtil.error(res, 'Failed to send notification', 500);
        }
    } catch (error) { next(error); }
    };

}

