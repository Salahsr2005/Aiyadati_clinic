import { Router } from 'express';
import { NotificationController } from './notification.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';

const router = Router();
const c = new NotificationController();

router.use(authenticate);

router.post('/register-device', c.registerDevice);
router.delete('/unregister-device', c.unregisterDevice);
router.get('/my-notifications', c.getMyNotifications);
router.patch('/:id/read', c.markAsRead);
router.patch('/read-all', c.markAllAsRead);
router.post('/test', c.sendTestNotification);

export default router;

