import { Router } from 'express';
import notificationRoutes from './v1/notification.routes';
const router = Router();
router.use('/v1', notificationRoutes);
export { router as notificationModule };

