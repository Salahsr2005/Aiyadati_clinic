import bcrypt from 'bcryptjs';
import { adminRepository } from '../../../repositories/admin.repository';
import { ConflictError, NotFoundError, DatabaseError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { CreateAdminDTO, UpdateAdminDTO, AdminResponse } from './admin.types';

export class AdminService {
  /**
   * Convert Prisma Admin to AdminResponse
   */
  private toResponse(admin: any): AdminResponse {
    return {
      id: admin.id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
      adminRole: admin.adminRole,
      createdBy: admin.createdBy,
      createdAt: admin.createdAt.toISOString(),
      updatedAt: admin.updatedAt.toISOString(),
    };
  }

  /**
   * Create a new admin
   */
  async create(data: CreateAdminDTO, createdBy: string, ip?: string): Promise<AdminResponse> {
    // Check if email already exists
    const emailExists = await adminRepository.emailExists(data.email);
    if (emailExists) {
      throw new ConflictError('Email already exists', [
        { field: 'email', message: 'An admin with this email already exists' },
      ]);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password, 12);

    try {
      const admin = await adminRepository.create({
        email: data.email,
        password: hashedPassword,
        name: data.name,
        adminRole: data.adminRole || null,
        createdBy,
      });

      // Emit audit event (non-blocking)
      eventEmitter.emit('audit', {
        action: 'admin.created',
        entity: 'Admin',
        entityId: admin.id,
        performedBy: createdBy,
        details: {
          email: admin.email,
          name: admin.name,
          adminRole: admin.adminRole,
        },
        ip,
      });

      logger.info(`Admin created: ${admin.email} by ${createdBy}`);
      return this.toResponse(admin);
    } catch (error) {
      logger.error('Failed to create admin', { error });
      throw new DatabaseError('Failed to create admin');
    }
  }

  /**
   * Get admin by ID
   */
  async findById(id: string): Promise<AdminResponse> {
    const admin = await adminRepository.findById(id);
    if (!admin) {
      throw new NotFoundError('Admin');
    }
    return this.toResponse(admin);
  }

  /**
   * Get all admins with pagination
   */
  async findAll(page = 1, limit = 10): Promise<{ admins: AdminResponse[]; total: number }> {
    const { admins, total } = await adminRepository.findAll(page, limit);
    return {
      admins: admins.map(admin => this.toResponse(admin)),
      total,
    };
  }

  /**
   * Update an admin
   */
  async update(id: string, data: UpdateAdminDTO, updatedBy: string, ip?: string): Promise<AdminResponse> {
    // Check if admin exists
    const existing = await adminRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Admin');
    }

    // Check email uniqueness if email is being changed
    if (data.email && data.email !== existing.email) {
      const emailExists = await adminRepository.emailExists(data.email, id);
      if (emailExists) {
        throw new ConflictError('Email already exists', [
          { field: 'email', message: 'An admin with this email already exists' },
        ]);
      }
    }

    try {
      const admin = await adminRepository.update(id, {
        ...(data.email && { email: data.email }),
        ...(data.name && { name: data.name }),
        ...(data.adminRole !== undefined && { adminRole: data.adminRole }),
      });

      // Emit audit event
      eventEmitter.emit('audit', {
        action: 'admin.updated',
        entity: 'Admin',
        entityId: admin.id,
        performedBy: updatedBy,
        details: {
          changes: data,
          previous: {
            email: existing.email,
            name: existing.name,
            adminRole: existing.adminRole,
          },
        },
        ip,
      });

      return this.toResponse(admin);
    } catch (error) {
      logger.error('Failed to update admin', { error });
      throw new DatabaseError('Failed to update admin');
    }
  }

  /**
   * Delete an admin
   */
  async delete(id: string, deletedBy: string, ip?: string): Promise<void> {
    const existing = await adminRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Admin');
    }

    try {
      await adminRepository.delete(id);

      // Emit audit event
      eventEmitter.emit('audit', {
        action: 'admin.deleted',
        entity: 'Admin',
        entityId: id,
        performedBy: deletedBy,
        details: {
          email: existing.email,
          name: existing.name,
          adminRole: existing.adminRole,
        },
        ip,
      });

      logger.info(`Admin deleted: ${existing.email} by ${deletedBy}`);
    } catch (error) {
      logger.error('Failed to delete admin', { error });
      throw new DatabaseError('Failed to delete admin');
    }
  }
}

export const adminService = new AdminService();

