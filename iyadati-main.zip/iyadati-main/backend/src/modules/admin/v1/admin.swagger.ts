/**
 * @swagger
 * tags:
 *   name: Admin
 *   description: Admin management endpoints (Super Admin only)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     CreateAdminRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *         - name
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: Admin email address
 *           example: admin@iyadati.com
 *         password:
 *           type: string
 *           format: password
 *           minLength: 6
 *           description: Admin password (min 6 characters)
 *           example: admin123456
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           description: Admin display name
 *           example: John Admin
 *         adminRole:
 *           type: string
 *           description: Custom admin role (e.g., manager, editor, support)
 *           example: manager
 *     UpdateAdminRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           description: New email address
 *           example: newadmin@iyadati.com
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           description: New display name
 *           example: John Updated
 *         adminRole:
 *           type: string
 *           description: New custom admin role
 *           example: editor
 *     AdminResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Admin unique identifier
 *           example: 550e8400-e29b-41d4-a716-446655440000
 *         email:
 *           type: string
 *           format: email
 *           description: Admin email address
 *           example: admin@iyadati.com
 *         name:
 *           type: string
 *           description: Admin display name
 *           example: John Admin
 *         role:
 *           type: string
 *           enum: [SUPER_ADMIN, ADMIN]
 *           description: System role
 *           example: ADMIN
 *         adminRole:
 *           type: string
 *           nullable: true
 *           description: Custom admin role
 *           example: manager
 *         createdBy:
 *           type: string
 *           format: uuid
 *           nullable: true
 *           description: Super Admin ID who created this admin
 *           example: 660e8400-e29b-41d4-a716-446655440000
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Creation timestamp
 *           example: "2024-06-13T10:00:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: Last update timestamp
 *           example: "2024-06-13T12:00:00.000Z"
 */

/**
 * @swagger
 * /api/v1/admin/v1:
 *   post:
 *     summary: Create a new admin
 *     description: |
 *       Creates a new admin account. **Only Super Admin can access this endpoint.**
 *       
 *       Requires authentication via cookie or Bearer token.
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateAdminRequest'
 *           examples:
 *             basic:
 *               summary: Basic admin
 *               value:
 *                 email: "admin@iyadati.com"
 *                 password: "admin123456"
 *                 name: "John Admin"
 *             withRole:
 *               summary: Admin with custom role
 *               value:
 *                 email: "manager@iyadati.com"
 *                 password: "manager123456"
 *                 name: "Jane Manager"
 *                 adminRole: "manager"
 *     responses:
 *       201:
 *         description: Admin created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Admin created successfully
 *                 data:
 *                   $ref: '#/components/schemas/AdminResponse'
 *             example:
 *               success: true
 *               message: "Admin created successfully"
 *               data:
 *                 id: "550e8400-e29b-41d4-a716-446655440000"
 *                 email: "admin@iyadati.com"
 *                 name: "John Admin"
 *                 role: "ADMIN"
 *                 adminRole: "manager"
 *                 createdBy: "660e8400-e29b-41d4-a716-446655440000"
 *                 createdAt: "2024-06-13T10:00:00.000Z"
 *                 updatedAt: "2024-06-13T10:00:00.000Z"
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *             examples:
 *               missingFields:
 *                 summary: Missing required fields
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Email is required"
 *                     - field: "password"
 *                       message: "Password is required"
 *                     - field: "name"
 *                       message: "Name is required"
 *               invalidEmail:
 *                 summary: Invalid email
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "email"
 *                       message: "Valid email is required"
 *               shortPassword:
 *                 summary: Password too short
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   errors:
 *                     - field: "password"
 *                       message: "Password must be at least 6 characters"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "No token provided"
 *               error: "No token provided"
 *       403:
 *         description: Not authorized (not Super Admin)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "You do not have permission to access this resource"
 *               error: "You do not have permission to access this resource"
 *       409:
 *         description: Email already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Email already exists"
 *               errors:
 *                 - field: "email"
 *                   message: "An admin with this email already exists"
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/admin/v1:
 *   get:
 *     summary: Get all admins (paginated)
 *     description: |
 *       Returns a paginated list of all admins. **Only Super Admin can access this endpoint.**
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Items per page
 *         example: 10
 *     responses:
 *       200:
 *         description: Admins retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Admins retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                       example: 1
 *                     limit:
 *                       type: integer
 *                       example: 10
 *                     total:
 *                       type: integer
 *                       example: 25
 *                     totalPages:
 *                       type: integer
 *                       example: 3
 *                     hasNextPage:
 *                       type: boolean
 *                       example: true
 *                     hasPreviousPage:
 *                       type: boolean
 *                       example: false
 *             example:
 *               success: true
 *               message: "Admins retrieved successfully"
 *               data:
 *                 - id: "550e8400-e29b-41d4-a716-446655440000"
 *                   email: "admin@iyadati.com"
 *                   name: "John Admin"
 *                   role: "ADMIN"
 *                   adminRole: "manager"
 *                   createdBy: "660e8400-e29b-41d4-a716-446655440000"
 *                   createdAt: "2024-06-13T10:00:00.000Z"
 *                   updatedAt: "2024-06-13T10:00:00.000Z"
 *               meta:
 *                 page: 1
 *                 limit: 10
 *                 total: 1
 *                 totalPages: 1
 *                 hasNextPage: false
 *                 hasPreviousPage: false
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (not Super Admin)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/admin/v1/{id}:
 *   get:
 *     summary: Get admin by ID
 *     description: |
 *       Returns a single admin by their ID. **Only Super Admin can access this endpoint.**
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Admin ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Admin retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Admin retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/AdminResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (not Super Admin)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Admin not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               success: false
 *               message: "Admin not found"
 *               error: "Admin not found"
 */

/**
 * @swagger
 * /api/v1/admin/v1/{id}:
 *   put:
 *     summary: Update an admin
 *     description: |
 *       Updates an admin's details. At least one field must be provided. **Only Super Admin can access this endpoint.**
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Admin ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateAdminRequest'
 *           examples:
 *             updateName:
 *               summary: Update name only
 *               value:
 *                 name: "John Updated"
 *             updateEmail:
 *               summary: Update email
 *               value:
 *                 email: "newemail@iyadati.com"
 *             updateRole:
 *               summary: Update custom role
 *               value:
 *                 adminRole: "editor"
 *             updateAll:
 *               summary: Update all fields
 *               value:
 *                 email: "newadmin@iyadati.com"
 *                 name: "John Updated"
 *                 adminRole: "editor"
 *     responses:
 *       200:
 *         description: Admin updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Admin updated successfully
 *                 data:
 *                   $ref: '#/components/schemas/AdminResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *             example:
 *               success: false
 *               message: "Validation failed"
 *               errors:
 *                 - field: "email"
 *                   message: "Valid email is required"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (not Super Admin)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Admin not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       409:
 *         description: Email already exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/admin/v1/{id}:
 *   delete:
 *     summary: Delete an admin
 *     description: |
 *       Permanently deletes an admin account. **Only Super Admin can access this endpoint.**
 *       
 *       This action cannot be undone.
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Admin ID to delete
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Admin deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Admin deleted successfully
 *             example:
 *               success: true
 *               message: "Admin deleted successfully"
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (not Super Admin)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Admin not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */