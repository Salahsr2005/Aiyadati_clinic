import { Router } from 'express';
import { AdminController } from './admin.controller';
import { validateCreateAdmin, validateUpdateAdmin } from './admin.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';

const router = Router();
const adminController = new AdminController();

router.use(authenticate, authorize('SUPER_ADMIN'));

router.post(
  '/',
  createRateLimiter({ windowMinutes: 15, maxRequests: 20, message: 'Too many admin creations' }),
  validateCreateAdmin,
  adminController.create
);

router.get(
  '/',
  createRateLimiter({ windowMinutes: 1, maxRequests: 60, message: 'Too many requests' }),
  adminController.findAll
);

router.get('/:id', adminController.findById);
router.put('/:id', validateUpdateAdmin, adminController.update);

router.delete(
  '/:id',
  createRateLimiter({ windowMinutes: 15, maxRequests: 30, message: 'Too many delete attempts' }),
  adminController.delete
);

export default router;

