import { Request, Response, NextFunction } from 'express';
import { adminService } from './admin.service';
import { ResponseUtil } from '../../../core/utils/response';

export class AdminController {
  /**
   * POST /api/v1/admin/v1 - Create admin
   */
  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const admin = await adminService.create(
        req.body,
        req.user!.id,
        req.ip
      );
      ResponseUtil.created(res, admin, 'Admin created successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * GET /api/v1/admin/v1 - Get all admins
   */
  findAll = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const { admins, total } = await adminService.findAll(page, limit);
      ResponseUtil.paginated(res, admins, total, page, limit, 'Admins retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * GET /api/v1/admin/v1/:id - Get admin by ID
   */
  findById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const admin = await adminService.findById(req.params.id);
      ResponseUtil.success(res, admin, 'Admin retrieved successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * PATCH /api/v1/admin/v1/:id - Update admin
   */
  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const admin = await adminService.update(
        req.params.id,
        req.body,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, admin, 'Admin updated successfully');
    } catch (error) {
      next(error);
    }
  };

  /**
   * DELETE /api/v1/admin/v1/:id - Delete admin
   */
  delete = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await adminService.delete(
        req.params.id,
        req.user!.id,
        req.ip
      );
      ResponseUtil.success(res, null, 'Admin deleted successfully');
    } catch (error) {
      next(error);
    }
  };
}

