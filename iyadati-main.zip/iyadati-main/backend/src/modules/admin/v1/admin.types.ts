export interface CreateAdminDTO {
  email: string;
  password: string;
  name: string;
  adminRole?: string;
}

export interface UpdateAdminDTO {
  email?: string;
  name?: string;
  adminRole?: string;
}

export interface AdminResponse {
  id: string;
  email: string;
  name: string;
  role: string;
  adminRole: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}