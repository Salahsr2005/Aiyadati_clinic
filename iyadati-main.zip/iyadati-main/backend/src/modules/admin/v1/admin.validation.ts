import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createAdminSchema = Joi.object({
  email: Joi.string()
    .email()
    .required()
    .messages({
      'string.email': 'Valid email is required',
      'any.required': 'Email is required',
    }),
  password: Joi.string()
    .min(6)
    .required()
    .messages({
      'string.min': 'Password must be at least 6 characters',
      'any.required': 'Password is required',
    }),
  name: Joi.string()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.min': 'Name must be at least 2 characters',
      'string.max': 'Name must be less than 100 characters',
      'any.required': 'Name is required',
    }),
  adminRole: Joi.string()
    .optional()
    .allow(null, ''),
});

const updateAdminSchema = Joi.object({
  email: Joi.string()
    .email()
    .optional()
    .messages({
      'string.email': 'Valid email is required',
    }),
  name: Joi.string()
    .min(2)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Name must be at least 2 characters',
      'string.max': 'Name must be less than 100 characters',
    }),
  adminRole: Joi.string()
    .optional()
    .allow(null, ''),
}).min(1).messages({
  'object.min': 'At least one field must be provided for update',
});

export const validateCreateAdmin = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createAdminSchema.validate(req.body, { abortEarly: false });

  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }

  next();
};

export const validateUpdateAdmin = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateAdminSchema.validate(req.body, { abortEarly: false });

  if (error) {
    const errors = error.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
    }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }

  next();
};

