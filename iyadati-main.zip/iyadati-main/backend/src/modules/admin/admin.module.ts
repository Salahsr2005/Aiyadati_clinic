import { Router } from 'express';
import adminRoutes from './v1/admin.routes';
import './v1/admin.swagger';

const router = Router();

router.use('/v1', adminRoutes);

export { router as adminModule };

