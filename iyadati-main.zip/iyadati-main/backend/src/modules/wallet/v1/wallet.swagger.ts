/**
 * @swagger
 * tags:
 *   name: Wallet
 *   description: User wallet and credit management endpoints
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     WalletResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         userId:
 *           type: string
 *           format: uuid
 *         credits:
 *           type: integer
 *           description: Current credit balance (1 credit = 1 appointment)
 *           example: 5
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *         transactions:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/TransactionResponse'
 *     TransactionResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         walletId:
 *           type: string
 *           format: uuid
 *         amount:
 *           type: integer
 *           description: Positive = credits added, Negative = credits used
 *           example: 5
 *         type:
 *           type: string
 *           enum: [purchase, use, refund, admin_grant]
 *           example: "purchase"
 *         description:
 *           type: string
 *           nullable: true
 *           example: "Purchased 5 credits (2500 DZD)"
 *         referenceId:
 *           type: string
 *           nullable: true
 *         performedBy:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *     PaymentInitiateResponse:
 *       type: object
 *       properties:
 *         paymentId:
 *           type: string
 *           format: uuid
 *           description: Payment record ID
 *         checkoutUrl:
 *           type: string
 *           description: Chargily checkout URL - redirect user here
 *         amount:
 *           type: number
 *           description: Total amount in DZD
 *         credits:
 *           type: integer
 *           description: Number of credits being purchased
 *     PaymentStatusResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         credits:
 *           type: integer
 *         amount:
 *           type: number
 *         status:
 *           type: string
 *           enum: [PENDING, PAID, FAILED, EXPIRED]
 *         chargilyUrl:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *           format: date-time
 *     PurchaseCreditsRequest:
 *       type: object
 *       required:
 *         - credits
 *       properties:
 *         credits:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           description: Number of credits to purchase (1 credit = 500 DZD)
 *           example: 5
 *     GrantCreditsRequest:
 *       type: object
 *       required:
 *         - credits
 *       properties:
 *         credits:
 *           type: integer
 *           minimum: 1
 *           maximum: 1000
 *           description: Number of free credits to grant
 *           example: 10
 *         reason:
 *           type: string
 *           maxLength: 200
 *           description: Reason for granting free credits
 *           example: "Welcome bonus for new user"
 *     AdminTransactionResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         walletId:
 *           type: string
 *         amount:
 *           type: integer
 *         type:
 *           type: string
 *         description:
 *           type: string
 *           nullable: true
 *         referenceId:
 *           type: string
 *           nullable: true
 *         performedBy:
 *           type: string
 *           nullable: true
 *         user:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             email:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *         createdAt:
 *           type: string
 */

/**
 * @swagger
 * /api/v1/wallet/v1/me:
 *   get:
 *     summary: Get my wallet
 *     description: |
 *       Returns the authenticated user's wallet with current credit balance
 *       and last 10 transactions. Wallet is auto-created on first access.
 *       **Requires User role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Wallet retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Wallet retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/WalletResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/wallet/v1/me/purchase/initiate:
 *   post:
 *     summary: Initiate credit purchase via Chargily
 *     description: |
 *       Creates a payment and returns a Chargily checkout URL for the user to complete payment.
 *       Each credit costs 500 DZD. 1 credit = 1 appointment booking.
 *       
 *       **Flow:**
 *       1. POST this endpoint with number of credits
 *       2. Redirect user to the returned `checkoutUrl`
 *       3. User pays on Chargily's page (EDAHABIA or CIB)
 *       4. Chargily sends webhook to confirm payment
 *       5. Credits are automatically added to wallet
 *       
 *       **Requires User role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/PurchaseCreditsRequest'
 *           examples:
 *             single:
 *               summary: Buy 1 credit
 *               value:
 *                 credits: 1
 *             pack:
 *               summary: Buy 5 credits
 *               value:
 *                 credits: 5
 *     responses:
 *       200:
 *         description: Payment initiated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Payment initiated. Redirect to checkout URL.
 *                 data:
 *                   $ref: '#/components/schemas/PaymentInitiateResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/wallet/v1/me/payment/{id}/status:
 *   get:
 *     summary: Check payment status
 *     description: |
 *       Returns the status of a payment. Use this to check if payment was completed.
 *       Status PENDING means the user hasn't paid yet on Chargily.
 *       Status PAID means credits have been added to the wallet.
 *       **Requires User role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Payment ID from initiate response
 *     responses:
 *       200:
 *         description: Payment status retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Payment status retrieved
 *                 data:
 *                   $ref: '#/components/schemas/PaymentStatusResponse'
 *       404:
 *         description: Payment not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/wallet/v1/user/{id}:
 *   get:
 *     summary: Get user wallet (Admin)
 *     description: |
 *       Returns any user's wallet with current balance and transaction history.
 *       **Requires Super Admin or Admin role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: User ID
 *     responses:
 *       200:
 *         description: Wallet retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Wallet retrieved successfully
 *                 data:
 *                   $ref: '#/components/schemas/WalletResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Wallet not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/wallet/v1/user/{id}/grant:
 *   post:
 *     summary: Grant free credits to user (Admin)
 *     description: |
 *       Grants free credits to a user's wallet. Used for promotions, refunds, or welcome bonuses.
 *       **Requires Super Admin or Admin role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GrantCreditsRequest'
 *           examples:
 *             welcome:
 *               summary: Welcome bonus
 *               value:
 *                 credits: 3
 *                 reason: "Welcome bonus for new registration"
 *             compensation:
 *               summary: Compensation
 *               value:
 *                 credits: 2
 *                 reason: "Compensation for cancelled appointment"
 *     responses:
 *       200:
 *         description: Credits granted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Credits granted successfully
 *                 data:
 *                   $ref: '#/components/schemas/WalletResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 */

/**
 * @swagger
 * /api/v1/wallet/v1/transactions:
 *   get:
 *     summary: Get all transactions (Admin)
 *     description: |
 *       Returns a paginated list of all credit transactions across all users.
 *       Can filter by wallet or transaction type.
 *       **Requires Super Admin or Admin role.**
 *     tags: [Wallet]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: walletId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wallet ID
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [purchase, use, refund, admin_grant]
 *         description: Filter by transaction type
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *     responses:
 *       200:
 *         description: Transactions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Transactions retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminTransactionResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     total:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */