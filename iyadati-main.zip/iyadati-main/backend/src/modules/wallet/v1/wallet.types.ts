export interface WalletResponse {
  id: string;
  userId: string;
  credits: number;
  createdAt: string;
  updatedAt: string;
  transactions: TransactionResponse[];
}

export interface TransactionResponse {
  id: string;
  walletId: string;
  amount: number;
  type: string;
  description: string | null;
  referenceId: string | null;
  performedBy: string | null;
  createdAt: string;
}

export interface PurchaseCreditsDTO {
  credits: number;
}

export interface GrantCreditsDTO {
  credits: number;
  reason?: string;
}

