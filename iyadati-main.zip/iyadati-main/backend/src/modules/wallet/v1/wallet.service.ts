// backend/src/modules/wallet/wallet.service.ts
import { walletRepository } from '../../../repositories/wallet.repository';
import { creditPriceRepository } from '../../../repositories/credit-price.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { WalletResponse, TransactionResponse, PurchaseCreditsDTO, GrantCreditsDTO } from './wallet.types';
import { env } from '../../../config/env';
import { chargilyClient } from '../../../config/chargily';
import { paymentRepository } from '../../../repositories/payment.repository';
import { prisma } from '../../../core/utils/prisma';

export class WalletService {
  private toResponse(wallet: any): WalletResponse {
    return {
      id: wallet.id,
      userId: wallet.userId,
      credits: wallet.credits,
      createdAt: wallet.createdAt.toISOString(),
      updatedAt: wallet.updatedAt.toISOString(),
      transactions: wallet.transactions?.map((t: any) => ({
        id: t.id,
        walletId: t.walletId,
        amount: t.amount,
        type: t.type,
        description: t.description,
        referenceId: t.referenceId,
        performedBy: t.performedBy,
        createdAt: t.createdAt.toISOString(),
      })) || [],
    };
  }

  async getMyWallet(userId: string): Promise<WalletResponse> {
    const wallet = await walletRepository.getOrCreate(userId);
    return this.toResponse(wallet);
  }

  async getUserWallet(userId: string): Promise<WalletResponse> {
    const wallet = await walletRepository.findByUserId(userId);
    if (!wallet) throw new NotFoundError('Wallet not found');
    return this.toResponse(wallet);
  }

  async purchaseCredits(userId: string, data: PurchaseCreditsDTO): Promise<WalletResponse> {
    // Get current credit price from database
    const creditPrice = await creditPriceRepository.getCurrentPrice();
    const totalPrice = data.credits * creditPrice;
    
    const wallet = await walletRepository.getOrCreate(userId);

    
    await walletRepository.addCredits(wallet.id, data.credits);
    
    await walletRepository.createTransaction({
      walletId: wallet.id,
      amount: data.credits,
      type: 'purchase',
      description: `Purchased ${data.credits} credits (${totalPrice} DZD)`,
    });

    eventEmitter.emit('audit', {
      action: 'wallet.purchase',
      entity: 'Wallet',
      entityId: wallet.id,
      performedBy: userId,
      details: { 
        credits: data.credits, 
        amount: totalPrice,
        pricePerCredit: creditPrice 
      },
    });

    // Notify user
    eventEmitter.emit('notification', {
      userId,
      title: '💰 Credits Purchased',
      body: `${data.credits} credits have been added to your wallet (${totalPrice} DZD).`,
      type: 'payment',
      data: { 
        credits: data.credits, 
        amount: totalPrice, 
        pricePerCredit: creditPrice,
        type: 'purchase' 
      },
    });

    logger.info(`User ${userId} purchased ${data.credits} credits at ${creditPrice} DZD each`);

    const updated = await walletRepository.findByUserId(userId);
    return this.toResponse(updated);
  }

  async grantCredits(userId: string, data: GrantCreditsDTO, performedBy: string, ip?: string): Promise<WalletResponse> {
    const wallet = await walletRepository.getOrCreate(userId);
    
    await walletRepository.addCredits(wallet.id, data.credits);
    
    await walletRepository.createTransaction({
      walletId: wallet.id,
      amount: data.credits,
      type: 'admin_grant',
      description: data.reason || `Granted ${data.credits} credits by admin`,
      performedBy,
    });

    eventEmitter.emit('audit', {
      action: 'wallet.admin_grant',
      entity: 'Wallet',
      entityId: wallet.id,
      performedBy,
      details: { credits: data.credits, reason: data.reason, targetUser: userId },
      ip,
    });

    // Notify user
    eventEmitter.emit('notification', {
      userId,
      title: '🎁 Credits Received',
      body: `${data.credits} credits have been granted to your wallet${data.reason ? ': ' + data.reason : ''}.`,
      type: 'payment',
      data: { credits: data.credits, type: 'admin_grant' },
    });

    logger.info(`Admin ${performedBy} granted ${data.credits} credits to user ${userId}`);

    const updated = await walletRepository.findByUserId(userId);
    return this.toResponse(updated);
  }

  async useCredit(walletId: string, appointmentId: string, description: string): Promise<void> {
    await walletRepository.deductCredits(walletId, 1);
    await walletRepository.createTransaction({
      walletId,
      amount: -1,
      type: 'use',
      description,
      referenceId: appointmentId,
    });
  }

  async refundCredit(walletId: string, appointmentId: string, description: string): Promise<void> {
    await walletRepository.addCredits(walletId, 1);
    await walletRepository.createTransaction({
      walletId,
      amount: 1,
      type: 'refund',
      description,
      referenceId: appointmentId,
    });
  }

  async getTransactions(params: any) {
    const parsedParams = {
      page: parseInt(params.page) || 1,
      limit: parseInt(params.limit) || 20,
      walletId: params.walletId || undefined,
      type: params.type || undefined,
    };

    const { transactions, total } = await walletRepository.getTransactions(parsedParams);
    return {
      transactions: transactions.map((t: any) => ({
        id: t.id,
        walletId: t.walletId,
        amount: t.amount,
        type: t.type,
        description: t.description,
        referenceId: t.referenceId,
        performedBy: t.performedBy,
        user: t.wallet?.user ? {
          id: t.wallet.user.id,
          email: t.wallet.user.email,
          firstName: t.wallet.user.firstName,
          lastName: t.wallet.user.lastName,
        } : null,
        createdAt: t.createdAt.toISOString(),
      })),
      total,
    };
  }

  async hasCredits(userId: string): Promise<boolean> {
    const wallet = await walletRepository.findByUserId(userId);
    return wallet ? wallet.credits > 0 : false;
  }

  async initiatePayment(userId: string, credits: number, userEmail: string, userName: string) {
    // Get current credit price from database
    const creditPrice = await creditPriceRepository.getCurrentPrice();
    const amount = credits * creditPrice;

    const result = await prisma.$transaction(async (tx) => {
      const payment = await tx.payment.create({
        data: { 
          userId, 
          credits, 
          amount,
          metadata: {
            pricePerCredit: creditPrice,
            credits: credits,
            totalAmount: amount
          }
        },
      });

      let checkout;
      try {
        checkout = await chargilyClient.createCheckout({
          amount,
          currency: 'dzd',
          success_url: `${env.BASE_URL}/payment/success`,
          failure_url: `${env.BASE_URL}/payment/failure`,
          metadata: {
            paymentId: payment.id,
            credits: credits.toString(),
            pricePerCredit: creditPrice.toString(),
          },
        });
      } catch (error) {
        logger.error('Chargily checkout creation failed', { error, userId, credits, creditPrice });
        throw new BadRequestError('Payment initiation failed. Please try again.');
      }

      const updatedPayment = await tx.payment.update({
        where: { id: payment.id },
        data: {
          chargilyId: checkout.id,
          chargilyUrl: checkout.checkout_url,
        },
      });

      logger.info(`Payment initiated: ${updatedPayment.id} for ${credits} credits at ${creditPrice} DZD each`);

      return {
        paymentId: updatedPayment.id,
        checkoutUrl: checkout.checkout_url,
        amount,
        credits,
        pricePerCredit: creditPrice,
      };
    });

    return result;
  }

  async getPaymentStatus(userId: string, paymentId: string) {
    const payment = await paymentRepository.findById(paymentId);
    if (!payment || payment.userId !== userId) {
      throw new NotFoundError('Payment not found');
    }
    return {
      id: payment.id,
      credits: payment.credits,
      amount: payment.amount,
      status: payment.status,
      chargilyUrl: payment.chargilyUrl,
      createdAt: payment.createdAt?.toISOString(),
      metadata: payment.metadata,
    };
  }

  /**
   * Get current credit price (useful for frontend)
   */
  async getCurrentCreditPrice(): Promise<{ price: number }> {
    const price = await creditPriceRepository.getCurrentPrice();
    return { price };
  }
}

export const walletService = new WalletService();

