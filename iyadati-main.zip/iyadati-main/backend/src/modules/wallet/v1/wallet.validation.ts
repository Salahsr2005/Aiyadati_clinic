import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const purchaseCreditsSchema = Joi.object({
  credits: Joi.number().integer().min(1).max(100).required().messages({
    'number.min': 'Must purchase at least 1 credit',
    'number.max': 'Maximum 100 credits per purchase',
    'any.required': 'Number of credits is required',
  }),
});

const grantCreditsSchema = Joi.object({
  credits: Joi.number().integer().min(1).max(1000).required().messages({
    'number.min': 'Must grant at least 1 credit',
    'number.max': 'Maximum 1000 credits per grant',
    'any.required': 'Number of credits is required',
  }),
  reason: Joi.string().max(200).optional(),
});

export const validatePurchaseCredits = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = purchaseCreditsSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateGrantCredits = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = grantCreditsSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

