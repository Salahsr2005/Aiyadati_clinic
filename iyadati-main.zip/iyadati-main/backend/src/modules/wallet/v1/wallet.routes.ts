import { Router } from 'express';
import { WalletController } from './wallet.controller';
import { validatePurchaseCredits, validateGrantCredits } from './wallet.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const walletController = new WalletController();

// User routes
router.get('/me', authenticate, authorize('USER'), walletController.getMyWallet);
router.post('/me/purchase/initiate', authenticate, authorize('USER'), validatePurchaseCredits, walletController.initiatePayment);
router.get('/me/payment/:id/status', authenticate, authorize('USER'), walletController.getPaymentStatus);

// Admin routes
router.get('/transactions', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), walletController.getTransactions);
router.get('/user/:id', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), walletController.getUserWallet);
router.post('/user/:id/grant', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), validateGrantCredits, walletController.grantCredits);

export default router;

