import { Request, Response, NextFunction } from 'express';
import { walletService } from './wallet.service';
import { ResponseUtil } from '../../../core/utils/response';
import { paymentRepository } from '../../../repositories/payment.repository';

export class WalletController {
  getMyWallet = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const wallet = await walletService.getMyWallet(req.user!.id);
      ResponseUtil.success(res, wallet, 'Wallet retrieved successfully');
    } catch (error) { next(error); }
  };

  purchaseCredits = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const wallet = await walletService.purchaseCredits(req.user!.id, req.body);
      ResponseUtil.success(res, wallet, 'Credits purchased successfully');
    } catch (error) { next(error); }
  };

  getUserWallet = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const wallet = await walletService.getUserWallet(req.params.id);
      ResponseUtil.success(res, wallet, 'Wallet retrieved successfully');
    } catch (error) { next(error); }
  };

  grantCredits = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const wallet = await walletService.grantCredits(req.params.id, req.body, req.user!.id, req.ip);
      ResponseUtil.success(res, wallet, 'Credits granted successfully');
    } catch (error) { next(error); }
  };

  getTransactions = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { transactions, total } = await walletService.getTransactions(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      ResponseUtil.paginated(res, transactions, total, page, limit, 'Transactions retrieved successfully');
    } catch (error) { next(error); }
  };

  initiatePayment = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await walletService.initiatePayment(
        req.user!.id,
        req.body.credits,
        req.user!.email,
        `${(req.user! as any).firstName || (req.user! as any).name} ${(req.user! as any).lastName || ''}`.trim()
      );
      ResponseUtil.success(res, result, 'Payment initiated. Redirect to checkout URL.');
    } catch (error) { next(error); }
  };

  getPaymentStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const payment = await walletService.getPaymentStatus(req.user!.id, req.params.id);
      ResponseUtil.success(res, payment, 'Payment status retrieved');
    } catch (error) { next(error); }
  };

}

