import { Router } from 'express';
import walletRoutes from './v1/wallet.routes';
import './v1/wallet.swagger';

const router = Router();
router.use('/v1', walletRoutes);

export { router as walletModule };

