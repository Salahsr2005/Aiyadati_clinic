import { Router } from 'express';
import { AdvertisementController } from './advertisement.controller';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { uploadAdvertisement } from '../../../core/middleware/upload.middleware';
import { validateCreateAdvertisement, validateUpdateAdvertisement } from './advertisement.validation';

const router = Router();
const controller = new AdvertisementController();

// ============================================================
// PUBLIC ROUTES (No Auth Required)
// ============================================================

/**
 * GET /api/v1/advertisements/v1/public/active
 * Get active advertisements for display
 * No authentication required
 * 
 * Query Parameters:
 * - position: AdPosition (filter by display position)
 * - wilayaId: string (filter by wilaya)
 * - audience: string (filter by target audience)
 * - language: AdLanguage (filter by language, e.g., ARABIC, FRENCH, ENGLISH)
 * - limit: number (default 10)
 */
router.get('/public/active', controller.getActive);

/**
 * POST /api/v1/advertisements/v1/public/:id/view
 * Track ad view (increments view count)
 * No authentication required
 */
router.post('/public/:id/view', controller.trackView);

/**
 * POST /api/v1/advertisements/v1/public/:id/click
 * Track ad click (increments click count)
 * No authentication required
 */
router.post('/public/:id/click', controller.trackClick);

// ============================================================
// STAFF ROUTES (Admin Only)
// ============================================================

/**
 * GET /api/v1/advertisements/v1
 * Get all advertisements with pagination
 * Requires Super Admin or Admin
 * 
 * Query Parameters:
 * - page: number
 * - limit: number
 * - status: AdStatus
 * - language: AdLanguage
 * - search: string
 */
router.get(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.findAll
);

/**
 * GET /api/v1/advertisements/v1/:id
 * Get advertisement by ID
 * Requires Super Admin or Admin
 */
router.get(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.findById
);

/**
 * POST /api/v1/advertisements/v1
 * Create new advertisement with image
 * Requires Super Admin or Admin
 * Multipart/form-data with field 'image'
 * 
 * Form fields:
 * - language: AdLanguage (default FRENCH)
 * - title: string (required)
 * - description: string (optional)
 * - link: string (optional)
 * - titleAr, titleFr, titleEn: string (optional translations)
 * - descriptionAr, descriptionFr, descriptionEn: string (optional translations)
 * - position: AdPosition (default HOME_TOP)
 * - sortOrder: number
 * - isActive: boolean
 * - status: AdStatus
 * - startsAt: date-time
 * - expiresAt: date-time
 * - targetAudience: string[]
 * - targetWilayas: string[]
 * - image: file (required)
 */
router.post(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  uploadAdvertisement,
  validateCreateAdvertisement,
  controller.create
);

/**
 * PATCH /api/v1/advertisements/v1/:id
 * Update advertisement
 * Requires Super Admin or Admin
 * Can update with or without new image
 */
router.patch(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  uploadAdvertisement,
  validateUpdateAdvertisement,
  controller.update
);

/**
 * DELETE /api/v1/advertisements/v1/:id
 * Soft delete advertisement
 * Requires Super Admin or Admin
 */
router.delete(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.delete
);

export default router;

