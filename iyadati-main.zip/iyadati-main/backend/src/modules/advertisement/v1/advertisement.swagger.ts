// backend/src/modules/advertisement/v1/advertisement.swagger.ts

/**
 * @swagger
 * tags:
 *   name: Advertisement
 *   description: Advertising/Announcement panel management with multilingual support (Public viewing + Admin management)
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     AdLanguage:
 *       type: string
 *       enum: [ARABIC, FRENCH, ENGLISH]
 *       description: Language of the advertisement content
 *       example: "FRENCH"
 *
 *     AdPosition:
 *       type: string
 *       enum: [HOME_TOP, HOME_MIDDLE, HOME_BOTTOM, DOCTOR_LIST, CLINIC_LIST, APPOINTMENT_SUCCESS, CUSTOM]
 *       description: Display position of the advertisement
 *
 *     AdStatus:
 *       type: string
 *       enum: [DRAFT, ACTIVE, SCHEDULED, EXPIRED, ARCHIVED]
 *       description: Status of the advertisement
 *
 *     AdvertisementResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         language:
 *           $ref: '#/components/schemas/AdLanguage'
 *         title:
 *           type: string
 *           example: "Soldes d'été - 50% de réduction!"
 *           description: Ad title in the selected language
 *         description:
 *           type: string
 *           nullable: true
 *           example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *         link:
 *           type: string
 *           nullable: true
 *           example: "https://iyadati.com/promotions/summer-sale"
 *         titleAr:
 *           type: string
 *           nullable: true
 *           example: "تخفيضات الصيف - خصم 50%!"
 *           description: Arabic translation of the title
 *         titleFr:
 *           type: string
 *           nullable: true
 *           example: "Soldes d'été - 50% de réduction!"
 *           description: French translation of the title
 *         titleEn:
 *           type: string
 *           nullable: true
 *           example: "Summer Sale - 50% Off!"
 *           description: English translation of the title
 *         descriptionAr:
 *           type: string
 *           nullable: true
 *           example: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *           description: Arabic translation of the description
 *         descriptionFr:
 *           type: string
 *           nullable: true
 *           example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *           description: French translation of the description
 *         descriptionEn:
 *           type: string
 *           nullable: true
 *           example: "Get 50% off on all consultations this summer"
 *           description: English translation of the description
 *         imageUrl:
 *           type: string
 *           description: |
 *             Public URL for the ad image.
 *             Uses fileId (UUID) instead of exposing the file path.
 *             Format: /api/v1/files/public/{fileId}
 *           example: "http://localhost:3975/api/v1/files/public/550e8400-e29b-41d4-a716-446655440000"
 *         position:
 *           $ref: '#/components/schemas/AdPosition'
 *         sortOrder:
 *           type: integer
 *           example: 1
 *           description: Display order (lower numbers first)
 *         isActive:
 *           type: boolean
 *           example: true
 *         status:
 *           $ref: '#/components/schemas/AdStatus'
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-01T00:00:00.000Z"
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-31T23:59:59.000Z"
 *         targetAudience:
 *           type: array
 *           items:
 *             type: string
 *             enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *           example: ["ALL"]
 *           description: Target audience types
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           example: []
 *           description: Target wilayas (empty = all wilayas)
 *         viewCount:
 *           type: integer
 *           example: 1523
 *           description: Number of times ad was viewed
 *         clickCount:
 *           type: integer
 *           example: 89
 *           description: Number of times ad was clicked
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2026-06-15T10:30:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-06-20T14:45:00.000Z"
 *
 *     CreateAdvertisementRequest:
 *       type: object
 *       required:
 *         - title
 *       properties:
 *         language:
 *           $ref: '#/components/schemas/AdLanguage'
 *           default: FRENCH
 *           description: Language of the main content
 *         title:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           example: "Soldes d'été - 50% de réduction!"
 *           description: Content must match the selected language
 *         description:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *         link:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "https://iyadati.com/promotions/summer-sale"
 *         titleAr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *           example: "تخفيضات الصيف - خصم 50%!"
 *           description: Arabic translation of the title
 *         titleFr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *           example: "Soldes d'été - 50% de réduction!"
 *           description: French translation of the title
 *         titleEn:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *           example: "Summer Sale - 50% Off!"
 *           description: English translation of the title
 *         descriptionAr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *           description: Arabic translation of the description
 *         descriptionFr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *           description: French translation of the description
 *         descriptionEn:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *           example: "Get 50% off on all consultations this summer"
 *           description: English translation of the description
 *         position:
 *           $ref: '#/components/schemas/AdPosition'
 *           default: HOME_TOP
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *           default: 0
 *         isActive:
 *           type: boolean
 *           default: true
 *         status:
 *           $ref: '#/components/schemas/AdStatus'
 *           default: DRAFT
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-01T00:00:00.000Z"
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-31T23:59:59.000Z"
 *         targetAudience:
 *           type: array
 *           items:
 *             type: string
 *             enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *           default: ["ALL"]
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           default: []
 *       example:
 *         language: "FRENCH"
 *         title: "Soldes d'été - 50% de réduction!"
 *         description: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *         link: "https://iyadati.com/promotions/summer-sale"
 *         titleAr: "تخفيضات الصيف - خصم 50%!"
 *         descriptionAr: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *         titleEn: "Summer Sale - 50% Off!"
 *         descriptionEn: "Get 50% off on all consultations this summer"
 *         position: "HOME_TOP"
 *         sortOrder: 1
 *         isActive: true
 *         status: "ACTIVE"
 *         startsAt: "2026-07-01T00:00:00.000Z"
 *         expiresAt: "2026-07-31T23:59:59.000Z"
 *         targetAudience: ["ALL"]
 *         targetWilayas: []
 *
 *     UpdateAdvertisementRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         language:
 *           $ref: '#/components/schemas/AdLanguage'
 *         title:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           example: "Updated: Summer Sale - 60% Off!"
 *         description:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         link:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         titleAr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *         titleFr:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *         titleEn:
 *           type: string
 *           minLength: 3
 *           maxLength: 200
 *           nullable: true
 *         descriptionAr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         descriptionFr:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         descriptionEn:
 *           type: string
 *           maxLength: 500
 *           nullable: true
 *         position:
 *           $ref: '#/components/schemas/AdPosition'
 *         sortOrder:
 *           type: integer
 *           minimum: 0
 *         isActive:
 *           type: boolean
 *         status:
 *           $ref: '#/components/schemas/AdStatus'
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         targetAudience:
 *           type: array
 *           items:
 *             type: string
 *             enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *       example:
 *         title: "Updated: Summer Sale - 60% Off!"
 *         isActive: false
 *         titleAr: "تحديث: تخفيضات الصيف - خصم 60%!"
 *         descriptionAr: "احصل على خصم 60% على جميع الاستشارات هذا الصيف"
 *
 *     ErrorResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *               message:
 *                 type: string
 *       example:
 *         success: false
 *         message: "Validation failed"
 *         errors:
 *           - field: "title"
 *             message: "Content must contain French characters for FRENCH language"
 */

// ============================================================
// PUBLIC ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/advertisements/v1/public/active:
 *   get:
 *     summary: Get active advertisements
 *     description: |
 *       Retrieves all active and valid advertisements for display.
 *       Filters by position, audience, language, and wilaya.
 *       No authentication required.
 *       
 *       **Language Behavior:**
 *       - If `language` parameter is provided, the API will return content in that language
 *       - If translation exists in the requested language, it will be used
 *       - If translation doesn't exist, it falls back to the main content
 *       - The `language` field in response indicates the original ad language
 *       
 *       **Content Validation:**
 *       - ARABIC: Content must contain Arabic characters (Unicode: \u0600-\u06FF)
 *       - FRENCH: Content must contain French characters (é, è, ê, etc.)
 *       - ENGLISH: Content must contain English characters without French-specific chars
 *     tags: [Advertisement]
 *     parameters:
 *       - in: query
 *         name: position
 *         schema:
 *           $ref: '#/components/schemas/AdPosition'
 *         description: Filter by display position
 *         example: "HOME_TOP"
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Filter by wilaya (shows ads targeting this wilaya or all wilayas)
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *       - in: query
 *         name: audience
 *         schema:
 *           type: string
 *           enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *         description: Filter by target audience
 *         example: "PATIENTS"
 *       - in: query
 *         name: language
 *         schema:
 *           $ref: '#/components/schemas/AdLanguage'
 *         description: |
 *           Filter by language and get content in that language.
 *           If translation exists, it will be returned in title/description fields.
 *         example: "FRENCH"
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 50
 *           default: 10
 *         description: Maximum number of ads to return
 *         example: 5
 *     responses:
 *       200:
 *         description: Active advertisements retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Active advertisements retrieved"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdvertisementResponse'
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/advertisements/v1/public/{id}/view:
 *   post:
 *     summary: Track advertisement view
 *     description: |
 *       Increments the view count for an advertisement.
 *       Used when the ad is displayed to a user.
 *       No authentication required.
 *     tags: [Advertisement]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Advertisement ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: View tracked successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "View tracked successfully"
 *                 data:
 *                   type: null
 *       404:
 *         description: Advertisement not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/advertisements/v1/public/{id}/click:
 *   post:
 *     summary: Track advertisement click
 *     description: |
 *       Increments the click count for an advertisement.
 *       Used when a user clicks on the ad.
 *       No authentication required.
 *     tags: [Advertisement]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Advertisement ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Click tracked successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Click tracked successfully"
 *                 data:
 *                   type: null
 *       404:
 *         description: Advertisement not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

// ============================================================
// STAFF ENDPOINTS (Admin Only)
// ============================================================

/**
 * @swagger
 * /api/v1/advertisements/v1:
 *   get:
 *     summary: Get all advertisements with pagination (Admin)
 *     description: |
 *       Retrieves all advertisements with pagination and filtering.
 *       Requires Super Admin or Admin role.
 *       
 *       **Admin Features:**
 *       - View all advertisements including draft and archived
 *       - Filter by status and language
 *       - Search across all title and description fields (including translations)
 *       - Full pagination support
 *     tags: [Advertisement]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Items per page
 *         example: 10
 *       - in: query
 *         name: status
 *         schema:
 *           $ref: '#/components/schemas/AdStatus'
 *         description: Filter by advertisement status
 *         example: "ACTIVE"
 *       - in: query
 *         name: language
 *         schema:
 *           $ref: '#/components/schemas/AdLanguage'
 *         description: Filter by advertisement language
 *         example: "FRENCH"
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by title or description (including translations)
 *         example: "summer"
 *     responses:
 *       200:
 *         description: Advertisements retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Advertisements retrieved successfully"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdvertisementResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                       example: 1
 *                     limit:
 *                       type: integer
 *                       example: 10
 *                     total:
 *                       type: integer
 *                       example: 25
 *                     totalPages:
 *                       type: integer
 *                       example: 3
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   post:
 *     summary: Create advertisement with multilingual support (Admin)
 *     description: |
 *       Creates a new advertisement with an image and multilingual support.
 *       Requires Super Admin or Admin role.
 *       Uses multipart/form-data with field 'image'.
 *       
 *       **File requirements:**
 *       - Formats: JPEG, PNG, WebP, GIF, SVG
 *       - Max size: 10MB
 *       
 *       **Language Validation:**
 *       - The content (title and description) must match the selected language
 *       - Arabic content must contain Arabic characters
 *       - French content must contain French characters (é, è, ê, etc.)
 *       - English content must contain English characters
 *       
 *       **Translations:**
 *       - You can optionally provide translations for all three languages
 *       - Translations are stored separately and can be used when displaying ads
 *       - The main content (title, description) is used as the primary content
 *     tags: [Advertisement]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - image
 *             properties:
 *               language:
 *                 $ref: '#/components/schemas/AdLanguage'
 *                 default: FRENCH
 *               title:
 *                 type: string
 *                 description: Ad title in the selected language
 *                 example: "Soldes d'été - 50% de réduction!"
 *               description:
 *                 type: string
 *                 nullable: true
 *                 description: Ad description in the selected language
 *                 example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *               link:
 *                 type: string
 *                 nullable: true
 *                 description: URL to redirect when ad is clicked
 *                 example: "https://iyadati.com/promotions/summer-sale"
 *               titleAr:
 *                 type: string
 *                 nullable: true
 *                 description: Arabic translation of the title
 *                 example: "تخفيضات الصيف - خصم 50%!"
 *               titleFr:
 *                 type: string
 *                 nullable: true
 *                 description: French translation of the title
 *                 example: "Soldes d'été - 50% de réduction!"
 *               titleEn:
 *                 type: string
 *                 nullable: true
 *                 description: English translation of the title
 *                 example: "Summer Sale - 50% Off!"
 *               descriptionAr:
 *                 type: string
 *                 nullable: true
 *                 description: Arabic translation of the description
 *                 example: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *               descriptionFr:
 *                 type: string
 *                 nullable: true
 *                 description: French translation of the description
 *                 example: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *               descriptionEn:
 *                 type: string
 *                 nullable: true
 *                 description: English translation of the description
 *                 example: "Get 50% off on all consultations this summer"
 *               position:
 *                 $ref: '#/components/schemas/AdPosition'
 *                 default: HOME_TOP
 *               sortOrder:
 *                 type: integer
 *                 minimum: 0
 *                 default: 0
 *                 description: Display order (lower numbers appear first)
 *               isActive:
 *                 type: boolean
 *                 default: true
 *               status:
 *                 $ref: '#/components/schemas/AdStatus'
 *                 default: DRAFT
 *               startsAt:
 *                 type: string
 *                 format: date-time
 *                 nullable: true
 *                 description: Start date for scheduled ads
 *                 example: "2026-07-01T00:00:00.000Z"
 *               expiresAt:
 *                 type: string
 *                 format: date-time
 *                 nullable: true
 *                 description: Expiration date
 *                 example: "2026-07-31T23:59:59.000Z"
 *               targetAudience:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *                 default: ["ALL"]
 *               targetWilayas:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: uuid
 *                 default: []
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: Image file (JPEG, PNG, WebP, GIF, SVG - max 10MB)
 *           example:
 *             language: "FRENCH"
 *             title: "Soldes d'été - 50% de réduction!"
 *             description: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *             link: "https://iyadati.com/promotions/summer-sale"
 *             titleAr: "تخفيضات الصيف - خصم 50%!"
 *             descriptionAr: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *             titleEn: "Summer Sale - 50% Off!"
 *             descriptionEn: "Get 50% off on all consultations this summer"
 *             position: "HOME_TOP"
 *             sortOrder: 1
 *             isActive: true
 *             status: "ACTIVE"
 *             startsAt: "2026-07-01T00:00:00.000Z"
 *             expiresAt: "2026-07-31T23:59:59.000Z"
 *             targetAudience: ["ALL"]
 *             targetWilayas: []
 *     responses:
 *       201:
 *         description: Advertisement created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Advertisement created successfully"
 *                 data:
 *                   $ref: '#/components/schemas/AdvertisementResponse'
 *       400:
 *         description: |
 *           Validation error or missing image.
 *           Common errors:
 *           - Missing image file
 *           - Content doesn't match selected language
 *           - Invalid date range (startsAt >= expiresAt)
 *           - Invalid field values
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       413:
 *         description: File too large (max 10MB)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/advertisements/v1/{id}:
 *   get:
 *     summary: Get advertisement by ID (Admin)
 *     description: |
 *       Retrieves a single advertisement by its ID with all translations.
 *       Requires Super Admin or Admin role.
 *     tags: [Advertisement]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Advertisement ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Advertisement retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Advertisement retrieved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/AdvertisementResponse'
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Advertisement not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   patch:
 *     summary: Update advertisement with multilingual support (Admin)
 *     description: |
 *       Updates an existing advertisement.
 *       Can update with or without a new image.
 *       Requires Super Admin or Admin role.
 *       
 *       **To update image:** Include 'image' field in multipart/form-data
 *       **To remove image:** Not supported (upload new to replace)
 *       
 *       **Language Validation:**
 *       - When changing language, content is re-validated
 *       - When updating title/description, content is validated against current language
 *       
 *       **Translations:**
 *       - Update individual translations by providing the specific field
 *       - Set to null to remove a translation
 *     tags: [Advertisement]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Advertisement ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             minProperties: 1
 *             properties:
 *               language:
 *                 $ref: '#/components/schemas/AdLanguage'
 *               title:
 *                 type: string
 *                 minLength: 3
 *                 maxLength: 200
 *                 example: "Updated: Summer Sale - 60% Off!"
 *               description:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *               link:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *               titleAr:
 *                 type: string
 *                 minLength: 3
 *                 maxLength: 200
 *                 nullable: true
 *                 example: "تحديث: تخفيضات الصيف - خصم 60%!"
 *               titleFr:
 *                 type: string
 *                 minLength: 3
 *                 maxLength: 200
 *                 nullable: true
 *               titleEn:
 *                 type: string
 *                 minLength: 3
 *                 maxLength: 200
 *                 nullable: true
 *               descriptionAr:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *                 example: "احصل على خصم 60% على جميع الاستشارات هذا الصيف"
 *               descriptionFr:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *               descriptionEn:
 *                 type: string
 *                 maxLength: 500
 *                 nullable: true
 *               position:
 *                 $ref: '#/components/schemas/AdPosition'
 *               sortOrder:
 *                 type: integer
 *                 minimum: 0
 *               isActive:
 *                 type: boolean
 *               status:
 *                 $ref: '#/components/schemas/AdStatus'
 *               startsAt:
 *                 type: string
 *                 format: date-time
 *                 nullable: true
 *               expiresAt:
 *                 type: string
 *                 format: date-time
 *                 nullable: true
 *               targetAudience:
 *                 type: array
 *                 items:
 *                   type: string
 *                   enum: [ALL, PATIENTS, DOCTORS, CLINICS]
 *               targetWilayas:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: uuid
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: New image file (optional - omit to keep current)
 *           example:
 *             title: "Updated: Summer Sale - 60% Off!"
 *             isActive: false
 *             titleAr: "تحديث: تخفيضات الصيف - خصم 60%!"
 *             descriptionAr: "احصل على خصم 60% على جميع الاستشارات هذا الصيف"
 *     responses:
 *       200:
 *         description: Advertisement updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Advertisement updated successfully"
 *                 data:
 *                   $ref: '#/components/schemas/AdvertisementResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Advertisement not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   delete:
 *     summary: Delete advertisement (Admin)
 *     description: |
 *       Soft deletes an advertisement (marks as ARCHIVED).
 *       Also deletes the image file from storage.
 *       Requires Super Admin or Admin role.
 *       
 *       **Soft Delete Behavior:**
 *       - Sets `deletedAt` timestamp
 *       - Sets `isActive` to false
 *       - Sets `status` to ARCHIVED
 *       - Records who deleted the ad
 *       - The ad is no longer visible to public
 *       - Admins can still see it in the list
 *     tags: [Advertisement]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Advertisement ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: Advertisement deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Advertisement deleted successfully"
 *                 data:
 *                   type: null
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Advertisement not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

// ============================================================
// ADDITIONAL EXAMPLES
// ============================================================

/**
 * @swagger
 * components:
 *   examples:
 *     ArabicAdExample:
 *       summary: Arabic Advertisement Example
 *       value:
 *         language: "ARABIC"
 *         title: "تخفيضات الصيف - خصم 50%!"
 *         description: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *         link: "https://iyadati.com/promotions/summer-sale"
 *         position: "HOME_TOP"
 *         targetAudience: ["ALL"]
 *
 *     FrenchAdExample:
 *       summary: French Advertisement Example
 *       value:
 *         language: "FRENCH"
 *         title: "Soldes d'été - 50% de réduction!"
 *         description: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *         link: "https://iyadati.com/promotions/summer-sale"
 *         position: "HOME_TOP"
 *         targetAudience: ["ALL"]
 *
 *     EnglishAdExample:
 *       summary: English Advertisement Example
 *       value:
 *         language: "ENGLISH"
 *         title: "Summer Sale - 50% Off!"
 *         description: "Get 50% off on all consultations this summer"
 *         link: "https://iyadati.com/promotions/summer-sale"
 *         position: "HOME_TOP"
 *         targetAudience: ["ALL"]
 *
 *     MultilingualAdExample:
 *       summary: Multilingual Advertisement Example
 *       value:
 *         language: "FRENCH"
 *         title: "Soldes d'été - 50% de réduction!"
 *         description: "Obtenez 50% de réduction sur toutes les consultations cet été"
 *         titleAr: "تخفيضات الصيف - خصم 50%!"
 *         descriptionAr: "احصل على خصم 50% على جميع الاستشارات هذا الصيف"
 *         titleEn: "Summer Sale - 50% Off!"
 *         descriptionEn: "Get 50% off on all consultations this summer"
 *         link: "https://iyadati.com/promotions/summer-sale"
 *         position: "HOME_TOP"
 *         targetAudience: ["ALL"]
 */