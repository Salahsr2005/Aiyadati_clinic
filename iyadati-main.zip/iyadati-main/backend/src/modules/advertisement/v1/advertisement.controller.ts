import { Request, Response, NextFunction } from 'express';
import { advertisementService } from './advertisement.service';
import { ResponseUtil } from '../../../core/utils/response';
import { AdPosition, AdStatus, AdLanguage } from '@prisma/client';

export class AdvertisementController {
  // ============================================================
  // PUBLIC ENDPOINTS (No Auth Required)
  // ============================================================

  getActive = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const ads = await advertisementService.getActiveAds({
        position: req.query.position as AdPosition,
        wilayaId: req.query.wilayaId as string,
        audience: req.query.audience as string,
        language: req.query.language as AdLanguage,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10,
      });
      ResponseUtil.success(res, ads, 'Active advertisements retrieved');
    } catch (error) { next(error); }
  };

  trackView = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await advertisementService.trackView(req.params.id);
      ResponseUtil.success(res, null, 'View tracked successfully');
    } catch (error) { next(error); }
  };

  trackClick = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await advertisementService.trackClick(req.params.id);
      ResponseUtil.success(res, null, 'Click tracked successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // STAFF ENDPOINTS (Admin Only)
  // ============================================================

  findAll = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { ads, total } = await advertisementService.findAll({
        page: parseInt(req.query.page as string) || 1,
        limit: parseInt(req.query.limit as string) || 10,
        status: req.query.status as AdStatus,
        language: req.query.language as AdLanguage,
        search: req.query.search as string,
      });
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      ResponseUtil.paginated(res, ads, total, page, limit, 'Advertisements retrieved successfully');
    } catch (error) { next(error); }
  };

  findById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const ad = await advertisementService.findById(req.params.id);
      ResponseUtil.success(res, ad, 'Advertisement retrieved successfully');
    } catch (error) { next(error); }
  };

  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) {
        ResponseUtil.badRequest(res, 'Image file is required');
        return;
      }
      const ad = await advertisementService.create(req.body, req.file, req.user!.id);
      ResponseUtil.created(res, ad, 'Advertisement created successfully');
    } catch (error) { next(error); }
  };

  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const ad = await advertisementService.update(
        req.params.id,
        req.body,
        req.file || null,
        req.user!.id
      );
      ResponseUtil.success(res, ad, 'Advertisement updated successfully');
    } catch (error) { next(error); }
  };

  delete = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await advertisementService.delete(req.params.id, req.user!.id);
      ResponseUtil.success(res, null, 'Advertisement deleted successfully');
    } catch (error) { next(error); }
  };
}

