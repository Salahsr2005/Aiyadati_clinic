// backend/src/modules/advertisement/v1/advertisement.validation.ts

import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';
import { AdPosition, AdStatus, AdLanguage } from '@prisma/client';

// Helper: allows array, empty string, or undefined
const arrayOrEmpty = (uuid: boolean = false) => {
  const itemSchema = uuid ? Joi.string().uuid() : Joi.string();
  return Joi.alternatives()
    .try(
      Joi.array().items(itemSchema),
      Joi.string().valid(''),
      Joi.string().valid('[]'),
      Joi.any().strip()
    )
    .optional();
};

// Helper: validate language-specific content
const validateLanguageContent = (value: any, helpers: any) => {
  const language = helpers.state.ancestors[0]?.language || 'FRENCH';
  const title = value;
  const description = helpers.state.ancestors[0]?.description || '';

  if (!title && !description) return value;

  // Check if content matches the selected language
  const content = title + ' ' + description;
  
  // Arabic detection: Arabic Unicode range
  const hasArabic = /[\u0600-\u06FF]/.test(content);
  // French detection: French-specific characters
  const hasFrench = /[éèêëàâäôöûüçîïœæ]/.test(content) || /[a-zA-Z]/.test(content);
  // English detection: Basic Latin with no French-specific chars
  const hasEnglish = /[a-zA-Z]/.test(content) && !/[éèêëàâäôöûüçîïœæ]/.test(content);

  if (language === 'ARABIC' && !hasArabic) {
    return helpers.error('any.invalid', {
      message: 'Content must contain Arabic characters for ARABIC language'
    });
  }

  if (language === 'FRENCH' && !hasFrench) {
    return helpers.error('any.invalid', {
      message: 'Content must contain French characters for FRENCH language'
    });
  }

  if (language === 'ENGLISH' && !hasEnglish) {
    return helpers.error('any.invalid', {
      message: 'Content must contain English characters for ENGLISH language'
    });
  }

  return value;
};

const createAdvertisementSchema = Joi.object({
  language: Joi.string().valid(...Object.values(AdLanguage)).optional().default('FRENCH'),
  
  // Main content
  title: Joi.string().min(3).max(200).required()
    .custom(validateLanguageContent, 'Language validation')
    .messages({
      'string.min': 'Title must be at least 3 characters',
      'string.max': 'Title must be less than 200 characters',
      'any.required': 'Title is required',
    }),
  description: Joi.string().max(500).optional().allow(null, ''),
  link: Joi.string().max(500).optional().allow(null, ''),
  
  // Translations
  titleAr: Joi.string().min(3).max(200).optional().allow(null, ''),
  titleFr: Joi.string().min(3).max(200).optional().allow(null, ''),
  titleEn: Joi.string().min(3).max(200).optional().allow(null, ''),
  descriptionAr: Joi.string().max(500).optional().allow(null, ''),
  descriptionFr: Joi.string().max(500).optional().allow(null, ''),
  descriptionEn: Joi.string().max(500).optional().allow(null, ''),
  
  position: Joi.string().valid(...Object.values(AdPosition)).optional(),
  sortOrder: Joi.number().integer().min(0).optional(),
  isActive: Joi.boolean().optional(),
  status: Joi.string().valid(...Object.values(AdStatus)).optional(),
  startsAt: Joi.date().iso().optional().allow(null, ''),
  expiresAt: Joi.date().iso().optional().allow(null, ''),
  targetAudience: arrayOrEmpty(false),
  targetWilayas: arrayOrEmpty(true),
});

const updateAdvertisementSchema = Joi.object({
  language: Joi.string().valid(...Object.values(AdLanguage)).optional(),
  
  // Main content
  title: Joi.string().min(3).max(200)
    .custom(validateLanguageContent, 'Language validation')
    .optional(),
  description: Joi.string().max(500).optional().allow(null, ''),
  link: Joi.string().max(500).optional().allow(null, ''),
  
  // Translations
  titleAr: Joi.string().min(3).max(200).optional().allow(null, ''),
  titleFr: Joi.string().min(3).max(200).optional().allow(null, ''),
  titleEn: Joi.string().min(3).max(200).optional().allow(null, ''),
  descriptionAr: Joi.string().max(500).optional().allow(null, ''),
  descriptionFr: Joi.string().max(500).optional().allow(null, ''),
  descriptionEn: Joi.string().max(500).optional().allow(null, ''),
  
  position: Joi.string().valid(...Object.values(AdPosition)).optional(),
  sortOrder: Joi.number().integer().min(0).optional(),
  isActive: Joi.boolean().optional(),
  status: Joi.string().valid(...Object.values(AdStatus)).optional(),
  startsAt: Joi.date().iso().optional().allow(null, ''),
  expiresAt: Joi.date().iso().optional().allow(null, ''),
  targetAudience: arrayOrEmpty(false),
  targetWilayas: arrayOrEmpty(true),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateAdvertisement = (req: Request, res: Response, next: NextFunction): void => {
  const { error, value } = createAdvertisementSchema.validate(req.body, { abortEarly: false });
  
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  
  req.body = value;
  next();
};

export const validateUpdateAdvertisement = (req: Request, res: Response, next: NextFunction): void => {
  const { error, value } = updateAdvertisementSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  req.body = value;
  next();
};

