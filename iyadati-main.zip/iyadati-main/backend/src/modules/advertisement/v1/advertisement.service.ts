import { advertisementRepository } from '../../../repositories/advertisement.repository';
import { fileService } from '../../file/v1/file.service';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { generatePublicUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { 
  AdvertisementResponse, 
  CreateAdvertisementDTO, 
  UpdateAdvertisementDTO,
  ActiveAdsQueryDTO 
} from './advertisement.types';
import { AdPosition, AdStatus, AdLanguage } from '@prisma/client';

export class AdvertisementService {
  private toResponse(ad: any): AdvertisementResponse {
    return {
      id: ad.id,
      language: ad.language,
      title: ad.title,
      description: ad.description,
      link: ad.link,
      // Translations
      titleAr: ad.titleAr || null,
      titleFr: ad.titleFr || null,
      titleEn: ad.titleEn || null,
      descriptionAr: ad.descriptionAr || null,
      descriptionFr: ad.descriptionFr || null,
      descriptionEn: ad.descriptionEn || null,
      imageUrl: generatePublicUrl(ad.fileId),
      position: ad.position,
      sortOrder: ad.sortOrder,
      isActive: ad.isActive,
      status: ad.status,
      startsAt: ad.startsAt?.toISOString() || null,
      expiresAt: ad.expiresAt?.toISOString() || null,
      targetAudience: ad.targetAudience,
      targetWilayas: ad.targetWilayas,
      viewCount: ad.viewCount,
      clickCount: ad.clickCount,
      createdAt: ad.createdAt.toISOString(),
      updatedAt: ad.updatedAt.toISOString(),
    };
  }

  /**
   * Validate that content matches the selected language
   */
  private validateLanguageContent(language: AdLanguage, title: string, description?: string): void {
    const content = title + ' ' + (description || '');
    
    // Arabic detection: Arabic Unicode range
    const hasArabic = /[\u0600-\u06FF]/.test(content);
    
    // French detection: French-specific characters
    const hasFrench = /[éèêëàâäôöûüçîïœæ]/.test(content) || /[a-zA-Z]/.test(content);
    
    // English detection: Basic Latin with no French-specific chars
    const hasEnglish = /[a-zA-Z]/.test(content) && !/[éèêëàâäôöûüçîïœæ]/.test(content);

    let isValid = true;
    let message = '';

    switch (language) {
      case AdLanguage.ARABIC:
        isValid = hasArabic;
        message = 'Title and description must contain Arabic characters for ARABIC language';
        break;
      case AdLanguage.FRENCH:
        isValid = hasFrench;
        message = 'Title and description must contain French characters for FRENCH language';
        break;
      case AdLanguage.ENGLISH:
        isValid = hasEnglish;
        message = 'Title and description must contain English characters for ENGLISH language';
        break;
    }

    if (!isValid) {
      throw new BadRequestError(message);
    }
  }

  /**
   * Get content in the appropriate language for response
   */
  private getContentForLanguage(ad: any, language?: AdLanguage): { title: string; description: string | null } {
    // If specific language requested, try to get translation
    if (language) {
      const titleKey = `title${language.charAt(0) + language.slice(1).toLowerCase()}`;
      const descKey = `description${language.charAt(0) + language.slice(1).toLowerCase()}`;
      
      // Check if translation exists
      if (ad[titleKey]) {
        return {
          title: ad[titleKey],
          description: ad[descKey] || null,
        };
      }
    }

    // Fallback to main content
    return {
      title: ad.title,
      description: ad.description,
    };
  }

  // ============================================================
  // PUBLIC METHODS (No Auth Required)
  // ============================================================

  async getActiveAds(params: ActiveAdsQueryDTO): Promise<AdvertisementResponse[]> {
    const ads = await advertisementRepository.findActiveAds({
      position: params.position,
      wilayaId: params.wilayaId,
      audience: params.audience,
      language: params.language,
      limit: params.limit || 10,
    });

    return ads.map((ad: any) => {
      const response = this.toResponse(ad);
      
      // If language is specified, override content with translation
      if (params.language) {
        const content = this.getContentForLanguage(ad, params.language);
        response.title = content.title;
        response.description = content.description;
      }
      
      return response;
    });
  }

  async trackView(id: string): Promise<void> {
    await advertisementRepository.incrementViewCount(id);
  }

  async trackClick(id: string): Promise<void> {
    await advertisementRepository.incrementClickCount(id);
  }

  // ============================================================
  // STAFF METHODS (Admin Only)
  // ============================================================

  async findAll(params: {
    page?: number;
    limit?: number;
    status?: AdStatus;
    language?: AdLanguage;
    search?: string;
  }) {
    const { items, total } = await advertisementRepository.findAll({
      page: params.page || 1,
      limit: params.limit || 10,
      status: params.status,
      language: params.language,
      search: params.search,
    });

    return {
      ads: items.map((ad: any) => this.toResponse(ad)),
      total,
    };
  }

  async findById(id: string): Promise<AdvertisementResponse> {
    const ad = await advertisementRepository.findById(id);
    if (!ad) {
      throw new NotFoundError('Advertisement');
    }
    return this.toResponse(ad);
  }

  async create(
    data: CreateAdvertisementDTO, 
    file: Express.Multer.File, 
    userId: string
  ): Promise<AdvertisementResponse> {
    // Set default language
    const language = data.language || AdLanguage.FRENCH;

    // Validate content language
    this.validateLanguageContent(language, data.title, data.description);

    // Validate dates
    if (data.startsAt && data.expiresAt) {
      const start = new Date(data.startsAt);
      const end = new Date(data.expiresAt);
      if (start >= end) {
        throw new BadRequestError('Start date must be before end date');
      }
    }

    // Determine status
    let status: AdStatus = data.status || AdStatus.DRAFT;
    if (status === AdStatus.ACTIVE && data.startsAt) {
      const now = new Date();
      const start = new Date(data.startsAt);
      if (start > now) {
        status = AdStatus.SCHEDULED;
      }
    }

    // Prepare translations
    const translations: any = {};
    if (data.titleAr) translations.titleAr = data.titleAr;
    if (data.titleFr) translations.titleFr = data.titleFr;
    if (data.titleEn) translations.titleEn = data.titleEn;
    if (data.descriptionAr) translations.descriptionAr = data.descriptionAr;
    if (data.descriptionFr) translations.descriptionFr = data.descriptionFr;
    if (data.descriptionEn) translations.descriptionEn = data.descriptionEn;

    // Validate that at least one translation exists
    const hasTranslations = Object.values(translations).some(v => v !== undefined && v !== null && v !== '');
    if (!hasTranslations && language !== 'FRENCH') {
      // If language is not French, we should have at least the main content
      // which is already stored in title and description fields
    }

    const ad = await advertisementRepository.create({
      language,
      title: data.title,
      description: data.description,
      link: data.link,
      ...translations,
      fileId: file.filename.replace(/\.[^.]+$/, ''),
      storageKey: file.filename,
      filePath: `public/advertisements/${file.filename}`,
      fileName: file.originalname,
      fileType: file.mimetype,
      fileSize: file.size,
      storageType: 'public',
      position: data.position || AdPosition.HOME_TOP,
      sortOrder: data.sortOrder || 0,
      isActive: data.isActive !== undefined ? data.isActive : true,
      status: status,
      startsAt: data.startsAt ? new Date(data.startsAt) : null,
      expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
      targetAudience: data.targetAudience || ['ALL'],
      targetWilayas: data.targetWilayas || [],
      createdBy: userId,
    });

    logger.info(`Advertisement created: ${ad.title} (${language}) by ${userId}`);
    return this.toResponse(ad);
  }

  async update(
    id: string, 
    data: UpdateAdvertisementDTO, 
    file: Express.Multer.File | null, 
    userId: string
  ): Promise<AdvertisementResponse> {
    const existing = await advertisementRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Advertisement');
    }

    const updateData: any = {};

    // Handle language change
    if (data.language !== undefined && data.language !== existing.language) {
      // When language changes, validate the content
      const title = data.title || existing.title;
      const description = data.description !== undefined ? data.description : existing.description;
      this.validateLanguageContent(data.language, title, description || '');
      updateData.language = data.language;
    }

    // Handle content updates
    if (data.title !== undefined) {
      const language = data.language || existing.language;
      const description = data.description !== undefined ? data.description : existing.description;
      this.validateLanguageContent(language, data.title, description || '');
      updateData.title = data.title;
    }

    if (data.description !== undefined) {
      const language = data.language || existing.language;
      const title = data.title !== undefined ? data.title : existing.title;
      this.validateLanguageContent(language, title, data.description || '');
      updateData.description = data.description;
    }

    if (data.link !== undefined) updateData.link = data.link;
    if (data.position !== undefined) updateData.position = data.position;
    if (data.sortOrder !== undefined) updateData.sortOrder = data.sortOrder;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.targetAudience !== undefined) updateData.targetAudience = data.targetAudience;
    if (data.targetWilayas !== undefined) updateData.targetWilayas = data.targetWilayas;

    // Handle translations
    if (data.titleAr !== undefined) updateData.titleAr = data.titleAr;
    if (data.titleFr !== undefined) updateData.titleFr = data.titleFr;
    if (data.titleEn !== undefined) updateData.titleEn = data.titleEn;
    if (data.descriptionAr !== undefined) updateData.descriptionAr = data.descriptionAr;
    if (data.descriptionFr !== undefined) updateData.descriptionFr = data.descriptionFr;
    if (data.descriptionEn !== undefined) updateData.descriptionEn = data.descriptionEn;

    if (data.startsAt !== undefined) {
      updateData.startsAt = data.startsAt ? new Date(data.startsAt) : null;
    }
    if (data.expiresAt !== undefined) {
      updateData.expiresAt = data.expiresAt ? new Date(data.expiresAt) : null;
    }

    // Handle file replacement
    if (file) {
      // Delete old file
      if (existing.fileId) {
        await fileService.deleteFile(existing.fileId, userId, 'ADMIN', true);
      }

      updateData.fileId = file.filename.replace(/\.[^.]+$/, '');
      updateData.storageKey = file.filename;
      updateData.filePath = `public/advertisements/${file.filename}`;
      updateData.fileName = file.originalname;
      updateData.fileType = file.mimetype;
      updateData.fileSize = file.size;
    }

    updateData.updatedBy = userId;

    const updated = await advertisementRepository.update(id, updateData);
    logger.info(`Advertisement updated: ${updated.title} by ${userId}`);
    return this.toResponse(updated);
  }

  async delete(id: string, userId: string): Promise<void> {
    const existing = await advertisementRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('Advertisement');
    }

    // Delete file from storage
    if (existing.fileId) {
      await fileService.deleteFile(existing.fileId, userId, 'ADMIN', true);
    }

    // Soft delete
    await advertisementRepository.softDelete(id, userId);
    logger.info(`Advertisement deleted: ${existing.title} by ${userId}`);
  }
}

export const advertisementService = new AdvertisementService();

