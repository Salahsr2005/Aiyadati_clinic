// backend/src/modules/advertisement/v1/advertisement.types.ts

import { AdPosition, AdStatus, AdLanguage } from '@prisma/client';

export interface AdvertisementResponse {
  id: string;
  language: AdLanguage;
  title: string;
  description: string | null;
  link: string | null;
  // Translations
  titleAr: string | null;
  titleFr: string | null;
  titleEn: string | null;
  descriptionAr: string | null;
  descriptionFr: string | null;
  descriptionEn: string | null;
  imageUrl: string;
  position: AdPosition;
  sortOrder: number;
  isActive: boolean;
  status: AdStatus;
  startsAt: string | null;
  expiresAt: string | null;
  targetAudience: string[];
  targetWilayas: string[];
  viewCount: number;
  clickCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateAdvertisementDTO {
  language?: AdLanguage;
  title: string;
  description?: string;
  link?: string;
  // Translations
  titleAr?: string;
  titleFr?: string;
  titleEn?: string;
  descriptionAr?: string;
  descriptionFr?: string;
  descriptionEn?: string;
  position?: AdPosition;
  sortOrder?: number;
  isActive?: boolean;
  status?: AdStatus;
  startsAt?: string;
  expiresAt?: string;
  targetAudience?: string[];
  targetWilayas?: string[];
}

export interface UpdateAdvertisementDTO {
  language?: AdLanguage;
  title?: string;
  description?: string;
  link?: string;
  // Translations
  titleAr?: string;
  titleFr?: string;
  titleEn?: string;
  descriptionAr?: string;
  descriptionFr?: string;
  descriptionEn?: string;
  position?: AdPosition;
  sortOrder?: number;
  isActive?: boolean;
  status?: AdStatus;
  startsAt?: string | null;
  expiresAt?: string | null;
  targetAudience?: string[];
  targetWilayas?: string[];
}

export interface ActiveAdsQueryDTO {
  position?: AdPosition;
  wilayaId?: string;
  audience?: string;
  language?: AdLanguage;
  limit?: number;
}

// Helper type for language validation
export interface LanguageValidationResult {
  isValid: boolean;
  detectedLanguage?: AdLanguage;
  message?: string;
}