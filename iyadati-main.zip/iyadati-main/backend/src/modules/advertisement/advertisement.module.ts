import { Router } from 'express';
import advertisementRoutes from './v1/advertisement.routes';

const router = Router();
router.use('/v1', advertisementRoutes);

export { router as advertisementModule };

