import { Router } from 'express';
import newsRoutes from './v1/news.routes';

const router = Router();
router.use('/v1', newsRoutes);

export { router as newsModule };

