// backend/src/modules/news/v1/news.service.ts
import { newsTapeRepository } from '../../../repositories/news-tape.repository';
import { auditLogRepository } from '../../../repositories/audit-log.repository';
import { NotFoundError, ForbiddenError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { NewsStatus, NewsTargetAudience } from '@prisma/client';
import {
  CreateNewsDTO,
  UpdateNewsDTO,
  GetActiveNewsQuery,
  NewsListQuery,
} from './news.types';

export class NewsService {
  async getActiveNews(params: GetActiveNewsQuery) {
    return newsTapeRepository.findActiveForUser({
      userId: params.userId,
      userType: params.userType,
      wilayaId: params.wilayaId,
      limit: params.limit,
      page: params.page,
    });
  }

  async createNews(
    data: CreateNewsDTO,
    createdBy: string,
    createdByType: 'SUPER_ADMIN' | 'ADMIN'
  ) {
    // Empty targetAudience = ALL (simplified)
    if (!data.targetAudience || data.targetAudience.length === 0) {
      data.targetAudience = [];
      data.targetUserIds = [];
      data.targetDoctorIds = [];
      data.targetClinicIds = [];
      data.targetWilayas = [];
    }

    // If ALL is explicitly set, clear others
    if (data.targetAudience && data.targetAudience.includes(NewsTargetAudience.ALL)) {
      data.targetAudience = [NewsTargetAudience.ALL];
      data.targetUserIds = [];
      data.targetDoctorIds = [];
      data.targetClinicIds = [];
      data.targetWilayas = [];
    }

    // Determine status
    let status: NewsStatus = data.status || NewsStatus.DRAFT;
    
    // Auto-update status based on dates if status is DRAFT or not explicitly set
    if (!data.status || data.status === NewsStatus.DRAFT) {
      if (data.startsAt && data.startsAt > new Date()) {
        status = NewsStatus.SCHEDULED;
      } else if (data.startsAt && data.startsAt <= new Date()) {
        status = NewsStatus.ACTIVE;
      }
    }

    const news = await newsTapeRepository.create({
      content: data.content,
      contentAr: data.contentAr,
      contentFr: data.contentFr,
      contentEn: data.contentEn,
      link: data.link,
      targetAudience: data.targetAudience || [],
      targetUserIds: data.targetUserIds || [],
      targetDoctorIds: data.targetDoctorIds || [],
      targetClinicIds: data.targetClinicIds || [],
      targetWilayas: data.targetWilayas || [],
      startsAt: data.startsAt,
      expiresAt: data.expiresAt,
      priority: data.priority || 0,
      status,
      isActive: status === NewsStatus.ACTIVE || status === NewsStatus.SCHEDULED,
      createdBy,
      createdByType,
    });

    await auditLogRepository.create({
      action: 'news.created',
      entity: 'NewsTape',
      entityId: news.id,
      performedBy: createdBy,
      details: {
        content: data.content.substring(0, 100),
        targetAudience: data.targetAudience || 'ALL',
        status,
      },
    });

    logger.info(`News created by ${createdBy} (${createdByType})`);

    return news;
  }

  async updateNews(
    id: string,
    data: UpdateNewsDTO,
    updatedBy: string,
    userRole: 'SUPER_ADMIN' | 'ADMIN'
  ) {
    const existing = await newsTapeRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('News not found');
    }

    if (userRole === 'ADMIN' && existing.createdByType === 'SUPER_ADMIN') {
      throw new ForbiddenError('Cannot update news created by Super Admin');
    }

    // Simplify targeting: if ALL, clear others
    if (data.targetAudience && data.targetAudience.includes(NewsTargetAudience.ALL)) {
      data.targetAudience = [NewsTargetAudience.ALL];
      data.targetUserIds = [];
      data.targetDoctorIds = [];
      data.targetClinicIds = [];
      data.targetWilayas = [];
    }

    // Auto-update status if not explicitly provided
    if (!data.status && data.startsAt !== undefined) {
      if (data.startsAt && data.startsAt > new Date()) {
        data.status = NewsStatus.SCHEDULED;
      } else if (data.startsAt && data.startsAt <= new Date()) {
        data.status = NewsStatus.ACTIVE;
      }
    }

    const updated = await newsTapeRepository.update(id, {
      ...data,
      updatedBy,
    });

    await auditLogRepository.create({
      action: 'news.updated',
      entity: 'NewsTape',
      entityId: id,
      performedBy: updatedBy,
      details: {
        changes: Object.keys(data),
      },
    });

    logger.info(`News updated by ${updatedBy}`);

    return updated;
  }

  async deleteNews(id: string, deletedBy: string, userRole: 'SUPER_ADMIN' | 'ADMIN') {
    const existing = await newsTapeRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('News not found');
    }

    if (userRole === 'ADMIN' && existing.createdByType === 'SUPER_ADMIN') {
      throw new ForbiddenError('Cannot delete news created by Super Admin');
    }

    await newsTapeRepository.softDelete(id, deletedBy);

    await auditLogRepository.create({
      action: 'news.deleted',
      entity: 'NewsTape',
      entityId: id,
      performedBy: deletedBy,
      details: {
        id: existing.id,
      },
    });

    logger.info(`News deleted by ${deletedBy}`);
  }

  async getAllNews(params: NewsListQuery) {
    return newsTapeRepository.findAll(params);
  }

  async getNewsById(id: string) {
    const news = await newsTapeRepository.findById(id);
    if (!news) {
      throw new NotFoundError('News not found');
    }
    return news;
  }

  async toggleStatus(id: string, isActive: boolean, updatedBy: string, userRole: 'SUPER_ADMIN' | 'ADMIN') {
    const existing = await newsTapeRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('News not found');
    }

    if (userRole === 'ADMIN' && existing.createdByType === 'SUPER_ADMIN') {
      throw new ForbiddenError('Cannot modify news created by Super Admin');
    }

    let status: NewsStatus;
    if (isActive) {
      if (existing.startsAt && existing.startsAt > new Date()) {
        status = NewsStatus.SCHEDULED;
      } else {
        status = NewsStatus.ACTIVE;
      }
    } else {
      status = NewsStatus.ARCHIVED;
    }

    const updated = await newsTapeRepository.update(id, {
      isActive,
      status,
      updatedBy,
    });

    await auditLogRepository.create({
      action: `news.${isActive ? 'activated' : 'deactivated'}`,
      entity: 'NewsTape',
      entityId: id,
      performedBy: updatedBy,
      details: {
        isActive,
      },
    });

    logger.info(`News ${isActive ? 'activated' : 'deactivated'} by ${updatedBy}`);

    return updated;
  }

  async trackView(id: string) {
    const exists = await newsTapeRepository.findById(id);
    if (!exists) {
      throw new NotFoundError('News not found');
    }
    return newsTapeRepository.incrementViewCount(id);
  }

  async getStats() {
    return newsTapeRepository.getStats();
  }

  async getExpiringSoon(days: number = 3) {
    return newsTapeRepository.getExpiringSoon(days);
  }

  async publishNews(id: string, publishedBy: string, userRole: 'SUPER_ADMIN' | 'ADMIN') {
    const existing = await newsTapeRepository.findById(id);
    if (!existing) {
      throw new NotFoundError('News not found');
    }

    if (userRole === 'ADMIN' && existing.createdByType === 'SUPER_ADMIN') {
      throw new ForbiddenError('Cannot publish news created by Super Admin');
    }

    const status = existing.startsAt && existing.startsAt > new Date() 
      ? NewsStatus.SCHEDULED 
      : NewsStatus.ACTIVE;

    const updated = await newsTapeRepository.update(id, {
      status,
      isActive: true,
      updatedBy: publishedBy,
    });

    await auditLogRepository.create({
      action: 'news.published',
      entity: 'NewsTape',
      entityId: id,
      performedBy: publishedBy,
      details: {
        status,
      },
    });

    logger.info(`News published by ${publishedBy}`);

    return updated;
  }
}

export const newsService = new NewsService();

