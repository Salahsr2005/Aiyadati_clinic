// backend/src/modules/news/v1/news.swagger.ts

/**
 * @swagger
 * tags:
 *   name: News
 *   description: News tape / announcements management with multilingual content support
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     NewsTargetAudience:
 *       type: string
 *       enum: [ALL, PATIENTS, DOCTORS, CLINICS, ADMINS, SUPER_ADMINS]
 *       description: |
 *         Target audience types:
 *         - ALL: All users
 *         - PATIENTS: Only patients
 *         - DOCTORS: Only doctors
 *         - CLINICS: Only clinics
 *         - ADMINS: Only admins
 *         - SUPER_ADMINS: Only super admins
 *     
 *     NewsStatus:
 *       type: string
 *       enum: [DRAFT, ACTIVE, SCHEDULED, EXPIRED, ARCHIVED]
 *       description: |
 *         News status:
 *         - DRAFT: Not published yet (in progress)
 *         - ACTIVE: Currently active and visible to users
 *         - SCHEDULED: Will be active in the future (based on startsAt)
 *         - EXPIRED: Past expiration date
 *         - ARCHIVED: Soft deleted (not visible)
 *     
 *     NewsTapeResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: "550e8400-e29b-41d4-a716-446655440000"
 *         content:
 *           type: string
 *           example: "We've added new features to improve your experience..."
 *         contentAr:
 *           type: string
 *           nullable: true
 *           example: "لقد أضفنا ميزات جديدة لتحسين تجربتك..."
 *         contentFr:
 *           type: string
 *           nullable: true
 *           example: "Nous avons ajouté de nouvelles fonctionnalités pour améliorer votre expérience..."
 *         contentEn:
 *           type: string
 *           nullable: true
 *           example: "We've added new features to improve your experience..."
 *         link:
 *           type: string
 *           nullable: true
 *           example: "https://iyadati.com/updates"
 *         status:
 *           $ref: '#/components/schemas/NewsStatus'
 *           example: ACTIVE
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-15T08:00:00.000Z"
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-08-15T08:00:00.000Z"
 *         isActive:
 *           type: boolean
 *           example: true
 *         targetAudience:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/NewsTargetAudience'
 *           description: "Empty array = ALL users"
 *           example: ["PATIENTS", "DOCTORS"]
 *         targetUserIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: "Empty = ALL users"
 *           example: []
 *         targetDoctorIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: "Empty = ALL doctors"
 *           example: []
 *         targetClinicIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: "Empty = ALL clinics"
 *           example: []
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           description: "Empty = ALL wilayas"
 *           example: ["wilaya-id-1"]
 *         priority:
 *           type: integer
 *           default: 0
 *           example: 10
 *         viewCount:
 *           type: integer
 *           default: 0
 *           example: 1523
 *         createdBy:
 *           type: string
 *           format: uuid
 *           example: "admin-user-id"
 *         createdByType:
 *           type: string
 *           enum: [SUPER_ADMIN, ADMIN]
 *           example: SUPER_ADMIN
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-10T10:00:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2026-07-12T15:30:00.000Z"
 *     
 *     CreateNewsRequest:
 *       type: object
 *       required:
 *         - content
 *       properties:
 *         content:
 *           type: string
 *           example: "We've added new features to improve your experience..."
 *         contentAr:
 *           type: string
 *           nullable: true
 *           example: "لقد أضفنا ميزات جديدة لتحسين تجربتك..."
 *         contentFr:
 *           type: string
 *           nullable: true
 *           example: "Nous avons ajouté de nouvelles fonctionnalités pour améliorer votre expérience..."
 *         contentEn:
 *           type: string
 *           nullable: true
 *           example: "We've added new features to improve your experience..."
 *         link:
 *           type: string
 *           nullable: true
 *           example: "https://iyadati.com/updates"
 *         targetAudience:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/NewsTargetAudience'
 *           default: []
 *           description: "Empty = ALL users. Use ['ALL'] for explicit all users."
 *           example: ["PATIENTS", "DOCTORS"]
 *         targetUserIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           default: []
 *           description: "Specific user IDs to target (empty = ALL users)"
 *         targetDoctorIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           default: []
 *           description: "Specific doctor IDs to target (empty = ALL doctors)"
 *         targetClinicIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           default: []
 *           description: "Specific clinic IDs to target (empty = ALL clinics)"
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *           default: []
 *           description: "Specific wilaya IDs to target (empty = ALL wilayas)"
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-07-15T08:00:00.000Z"
 *           description: "When the news should start being visible"
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2026-08-15T08:00:00.000Z"
 *           description: "When the news should expire"
 *         priority:
 *           type: integer
 *           minimum: 0
 *           maximum: 100
 *           default: 0
 *           example: 10
 *           description: "Higher priority = displayed first"
 *         status:
 *           $ref: '#/components/schemas/NewsStatus'
 *           default: DRAFT
 *           description: "If not provided, auto-detected based on startsAt"
 *       example:
 *         content: "We've added new features to improve your experience..."
 *         contentAr: "لقد أضفنا ميزات جديدة لتحسين تجربتك..."
 *         contentFr: "Nous avons ajouté de nouvelles fonctionnalités pour améliorer votre expérience..."
 *         contentEn: "We've added new features to improve your experience..."
 *         link: "https://iyadati.com/updates"
 *         targetAudience: ["PATIENTS", "DOCTORS"]
 *         targetWilayas: ["550e8400-e29b-41d4-a716-446655440000"]
 *         startsAt: "2026-07-15T08:00:00.000Z"
 *         expiresAt: "2026-08-15T08:00:00.000Z"
 *         priority: 10
 *         status: DRAFT
 *     
 *     UpdateNewsRequest:
 *       type: object
 *       minProperties: 1
 *       properties:
 *         content:
 *           type: string
 *         contentAr:
 *           type: string
 *           nullable: true
 *         contentFr:
 *           type: string
 *           nullable: true
 *         contentEn:
 *           type: string
 *           nullable: true
 *         link:
 *           type: string
 *           nullable: true
 *         targetAudience:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/NewsTargetAudience'
 *         targetUserIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         targetDoctorIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         targetClinicIds:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         targetWilayas:
 *           type: array
 *           items:
 *             type: string
 *             format: uuid
 *         startsAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *         priority:
 *           type: integer
 *           minimum: 0
 *           maximum: 100
 *         status:
 *           $ref: '#/components/schemas/NewsStatus'
 *         isActive:
 *           type: boolean
 *           description: "Manually activate/deactivate the news"
 *       example:
 *         content: "Updated content about the platform..."
 *         contentAr: "محتوى محدث حول المنصة..."
 *         contentFr: "Contenu mis à jour sur la plateforme..."
 *         contentEn: "Updated content about the platform..."
 *         isActive: false
 *         status: DRAFT
 *         priority: 15
 *         targetAudience: ["ALL"]
 *     
 *     ErrorResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: "Validation failed"
 *         errors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: "content"
 *               message:
 *                 type: string
 *                 example: "Content is required"
 *     
 *     PaginatedResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "News retrieved successfully"
 *         data:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/NewsTapeResponse'
 *         meta:
 *           type: object
 *           properties:
 *             page:
 *               type: integer
 *               example: 1
 *             limit:
 *               type: integer
 *               example: 10
 *             total:
 *               type: integer
 *               example: 25
 *             totalPages:
 *               type: integer
 *               example: 3
 *             hasNextPage:
 *               type: boolean
 *               example: true
 *             hasPreviousPage:
 *               type: boolean
 *               example: false
 *     
 *     NewsStats:
 *       type: object
 *       properties:
 *         total:
 *           type: integer
 *           example: 45
 *           description: "Total number of news items (all statuses)"
 *         active:
 *           type: integer
 *           example: 12
 *           description: "Currently active news"
 *         scheduled:
 *           type: integer
 *           example: 5
 *           description: "Scheduled for future publication"
 *         expired:
 *           type: integer
 *           example: 18
 *           description: "Expired news (past expiration date)"
 *         archived:
 *           type: integer
 *           example: 10
 *           description: "Archived/soft deleted news"
 *         draft:
 *           type: integer
 *           example: 8
 *           description: "Draft news (not published yet)"
 */

// ============================================================
// PUBLIC / AUTHENTICATED ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/news/v1/active:
 *   get:
 *     summary: Get active news for user
 *     description: |
 *       Retrieves active news targeted to the current user.
 *       
 *       **Targeting Logic:**
 *       - Empty arrays = ALL (e.g., targetAudience: [] means all users)
 *       - Specific values = filtered (e.g., targetAudience: ["PATIENTS"] means only patients)
 *       - Explicit ["ALL"] = ALL users (overrides other targets)
 *       
 *       **Wilaya Logic:**
 *       - Empty targetWilayas = ALL wilayas
 *       - Specific wilaya IDs = filtered
 *       
 *       **Status Logic:**
 *       - Only news with status = ACTIVE are returned
 *       - News with status = SCHEDULED are not returned until their startsAt time
 *       - News with status = DRAFT are not returned
 *       - News with status = EXPIRED are not returned
 *       - News with status = ARCHIVED are not returned
 *       
 *       **Content Logic:**
 *       - `content` field contains the default content
 *       - `contentAr`, `contentFr`, `contentEn` contain translations
 *       - Clients can display the appropriate language version based on user preference
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: userType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [PATIENT, DOCTOR, CLINIC, ADMIN, SUPER_ADMIN]
 *         description: Type of user requesting news
 *         example: PATIENT
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: User ID for specific targeting
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *       - in: query
 *         name: wilayaId
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Wilaya ID for location-based targeting
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *         description: Number of results per page
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *         description: Page number
 *     responses:
 *       200:
 *         description: Active news retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Active news retrieved"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/NewsTapeResponse'
 *                 meta:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                       example: 1
 *                     limit:
 *                       type: integer
 *                       example: 10
 *                     total:
 *                       type: integer
 *                       example: 25
 *                     totalPages:
 *                       type: integer
 *                       example: 3
 *                     hasNextPage:
 *                       type: boolean
 *                       example: true
 *                     hasPreviousPage:
 *                       type: boolean
 *                       example: false
 *       401:
 *         description: Unauthorized - No valid token provided
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       422:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/{id}/view:
 *   post:
 *     summary: Track news view
 *     description: |
 *       Increments the view count for a news item. Used for analytics.
 *       This endpoint is called when a user views a news item.
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: View tracked successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "View tracked successfully"
 *                 data:
 *                   type: null
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

// ============================================================
// ADMIN ENDPOINTS
// ============================================================

/**
 * @swagger
 * /api/v1/news/v1:
 *   get:
 *     summary: Get all news (Admin)
 *     description: |
 *       Retrieves all news with pagination and filtering.
 *       Requires Super Admin or Admin role.
 *       
 *       **Admin Restrictions:**
 *       - Admin can view all news (including Super Admin's news)
 *       - Admin cannot modify Super Admin's news (update/delete/toggle/publish)
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *           minimum: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *           minimum: 1
 *           maximum: 100
 *         description: Items per page
 *       - in: query
 *         name: status
 *         schema:
 *           $ref: '#/components/schemas/NewsStatus'
 *         description: Filter by status
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search by content (including translations)
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, updatedAt, priority, viewCount]
 *           default: createdAt
 *         description: Sort field
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: Sort order
 *     responses:
 *       200:
 *         description: News retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PaginatedResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   post:
 *     summary: Create news (Admin)
 *     description: |
 *       Creates a new news item.
 *       Requires Super Admin or Admin role.
 *       
 *       **Targeting Logic:**
 *       - Empty targetAudience = ALL users
 *       - Specific targetAudience = filtered
 *       - Explicit ["ALL"] = ALL users
 *       
 *       **Status Logic:**
 *       - If status is DRAFT (default), news is not visible
 *       - If startsAt is in future, status auto-changes to SCHEDULED
 *       - If startsAt is in past/now, status auto-changes to ACTIVE
 *       - Admin can override status manually
 *       
 *       **Multilingual Content:**
 *       - `content` field is required (default content)
 *       - `contentAr`, `contentFr`, `contentEn` are optional translations
 *       - All content fields support rich text (HTML/Markdown)
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateNewsRequest'
 *           example:
 *             content: "We've added new features to improve your experience..."
 *             contentAr: "لقد أضفنا ميزات جديدة لتحسين تجربتك..."
 *             contentFr: "Nous avons ajouté de nouvelles fonctionnalités pour améliorer votre expérience..."
 *             contentEn: "We've added new features to improve your experience..."
 *             link: "https://iyadati.com/updates"
 *             targetAudience: ["PATIENTS", "DOCTORS"]
 *             targetWilayas: ["550e8400-e29b-41d4-a716-446655440000"]
 *             startsAt: "2026-07-15T08:00:00.000Z"
 *             expiresAt: "2026-08-15T08:00:00.000Z"
 *             priority: 10
 *             status: DRAFT
 *     responses:
 *       201:
 *         description: News created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News created successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsTapeResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/stats:
 *   get:
 *     summary: Get news statistics (Admin)
 *     description: |
 *       Returns statistics about news items for dashboard.
 *       Requires Super Admin or Admin role.
 *       
 *       **Stats Breakdown:**
 *       - total: All news (including deleted)
 *       - active: Currently visible news
 *       - scheduled: News scheduled for future
 *       - expired: News past their expiration
 *       - archived: Soft deleted news
 *       - draft: News in draft status
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Stats retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News stats retrieved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsStats'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/{id}:
 *   get:
 *     summary: Get news by ID (Admin)
 *     description: |
 *       Retrieves a single news item by its ID.
 *       Requires Super Admin or Admin role.
 *       
 *       **Includes:**
 *       - All fields
 *       - Status information
 *       - Multilingual content (contentAr, contentFr, contentEn)
 *       - Targeting details
 *       - Audit information (who created/updated)
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: News retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News retrieved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsTapeResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   put:
 *     summary: Update news (Admin)
 *     description: |
 *       Updates an existing news item.
 *       Requires Super Admin or Admin role.
 *       
 *       **Restrictions:**
 *       - Admin cannot modify news created by Super Admin
 *       - Super Admin can modify all news
 *       
 *       **Update Logic:**
 *       - If startsAt is changed, status auto-updates
 *       - If status is manually set, it overrides auto-detection
 *       - isActive can be toggled
 *       - Multilingual content can be updated independently
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateNewsRequest'
 *           example:
 *             content: "Updated content about the platform..."
 *             contentAr: "محتوى محدث حول المنصة..."
 *             contentFr: "Contenu mis à jour sur la plateforme..."
 *             contentEn: "Updated content about the platform..."
 *             isActive: false
 *             status: DRAFT
 *             priority: 15
 *             targetAudience: ["ALL"]
 *     responses:
 *       200:
 *         description: News updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News updated successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsTapeResponse'
 *       400:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: |
 *           Forbidden - Either requires ADMIN role or cannot modify Super Admin's news
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *
 *   delete:
 *     summary: Delete news (Admin)
 *     description: |
 *       Soft deletes a news item (marks as ARCHIVED).
 *       Requires Super Admin or Admin role.
 *       
 *       **Restrictions:**
 *       - Admin cannot delete news created by Super Admin
 *       - Super Admin can delete all news
 *       - Deletion is soft: news is marked as ARCHIVED and not visible
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *     responses:
 *       200:
 *         description: News deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News deleted successfully"
 *                 data:
 *                   type: null
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: |
 *           Forbidden - Either requires ADMIN role or cannot delete Super Admin's news
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/{id}/toggle:
 *   patch:
 *     summary: Toggle news status (Admin)
 *     description: |
 *       Activates or deactivates a news item.
 *       Requires Super Admin or Admin role.
 *       
 *       **Behavior:**
 *       - When isActive = true:
 *         - If startsAt is in future → status becomes SCHEDULED
 *         - If startsAt is in past or null → status becomes ACTIVE
 *       - When isActive = false:
 *         - status becomes ARCHIVED
 *       
 *       **Restrictions:**
 *       - Admin cannot toggle news created by Super Admin
 *       - Super Admin can toggle all news
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - isActive
 *             properties:
 *               isActive:
 *                 type: boolean
 *                 description: "Set to true to activate, false to deactivate"
 *                 example: false
 *           example:
 *             isActive: false
 *     responses:
 *       200:
 *         description: Status toggled successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News deactivated successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsTapeResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: |
 *           Forbidden - Either requires ADMIN role or cannot modify Super Admin's news
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/{id}/publish:
 *   post:
 *     summary: Publish news (Admin)
 *     description: |
 *       Publishes a draft or scheduled news item.
 *       Requires Super Admin or Admin role.
 *       
 *       **Behavior:**
 *       - Sets isActive = true
 *       - If startsAt is in future → status becomes SCHEDULED
 *       - If startsAt is in past or null → status becomes ACTIVE
 *       - Useful for publishing drafts that were in progress
 *       
 *       **Restrictions:**
 *       - Admin cannot publish news created by Super Admin
 *       - Super Admin can publish all news
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: News ID
 *         example: "550e8400-e29b-41d4-a716-446655440000"
 *     responses:
 *       200:
 *         description: News published successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "News published successfully"
 *                 data:
 *                   $ref: '#/components/schemas/NewsTapeResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: |
 *           Forbidden - Either requires ADMIN role or cannot publish Super Admin's news
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: News not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * /api/v1/news/v1/expiring-soon:
 *   get:
 *     summary: Get news expiring soon (Admin)
 *     description: |
 *       Returns news that will expire within the next X days.
 *       Requires Super Admin or Admin role.
 *       
 *       **Use Cases:**
 *       - Manage expiring content
 *       - Extend expiration dates if needed
 *       - Monitor content lifecycle
 *       
 *       **Default:** 3 days
 *     tags: [News]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: days
 *         schema:
 *           type: integer
 *           default: 3
 *           minimum: 1
 *           maximum: 30
 *         description: Number of days to look ahead
 *         example: 7
 *     responses:
 *       200:
 *         description: Expiring soon news retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Expiring soon news retrieved successfully"
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/NewsTapeResponse'
 *       401:
 *         description: Unauthorized
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: Forbidden - Requires SUPER_ADMIN or ADMIN role
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *       description: |
 *         JWT token authentication.
 *         Include the token in the Authorization header:
 *         `Authorization: Bearer <token>`
 */

// This export is needed for the file to be a module
export default {};

