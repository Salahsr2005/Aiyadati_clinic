// backend/src/modules/news/v1/news.types.ts
import { NewsStatus, NewsTargetAudience } from '@prisma/client';

export interface CreateNewsDTO {
  content: string;
  contentAr?: string;
  contentFr?: string;
  contentEn?: string;
  link?: string;
  targetAudience?: NewsTargetAudience[]; // Empty = ALL
  targetUserIds?: string[];
  targetDoctorIds?: string[];
  targetClinicIds?: string[];
  targetWilayas?: string[];
  startsAt?: Date;
  expiresAt?: Date;
  priority?: number;
  status?: NewsStatus;
}

export interface UpdateNewsDTO {
  content?: string;
  contentAr?: string;
  contentFr?: string;
  contentEn?: string;
  link?: string;
  targetAudience?: NewsTargetAudience[];
  targetUserIds?: string[];
  targetDoctorIds?: string[];
  targetClinicIds?: string[];
  targetWilayas?: string[];
  startsAt?: Date;
  expiresAt?: Date;
  priority?: number;
  status?: NewsStatus;
  isActive?: boolean;
}

export interface GetActiveNewsQuery {
  userId?: string;
  userType: 'PATIENT' | 'DOCTOR' | 'CLINIC' | 'ADMIN' | 'SUPER_ADMIN';
  wilayaId?: string;
  limit?: number;
  page?: number;
}

export interface NewsListQuery {
  page?: number;
  limit?: number;
  status?: NewsStatus;
  search?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

