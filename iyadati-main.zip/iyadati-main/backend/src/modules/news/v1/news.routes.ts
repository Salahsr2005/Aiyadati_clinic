// backend/src/modules/news/v1/news.routes.ts
import { Router } from 'express';
import { NewsController } from './news.controller';
import {
  validateCreateNews,
  validateUpdateNews,
  validateGetActiveNews,
  validateGetAllNews,
} from './news.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new NewsController();

// ============================================================
// PUBLIC / AUTHENTICATED
// ============================================================

/**
 * GET /api/news/v1/active
 * Get active news for current user
 */
router.get(
  '/active',
  authenticate,
  validateGetActiveNews,
  controller.getActiveNews
);

/**
 * POST /api/news/v1/:id/view
 * Track a news view
 */
router.post(
  '/:id/view',
  authenticate,
  controller.trackView
);

// ============================================================
// ADMIN ROUTES (Admin & Super Admin)
// ============================================================

/**
 * GET /api/news/v1
 * Get all news with pagination
 */
router.get(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateGetAllNews,
  controller.getAllNews
);

/**
 * GET /api/news/v1/stats
 * Get news stats for dashboard
 */
router.get(
  '/stats',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getStats
);

/**
 * GET /api/news/v1/:id
 * Get news by ID
 */
router.get(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getNewsById
);

/**
 * POST /api/news/v1
 * Create news
 */
router.post(
  '/',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateNews,
  controller.createNews
);

/**
 * PUT /api/news/v1/:id
 * Update news
 */
router.put(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateNews,
  controller.updateNews
);

/**
 * DELETE /api/news/v1/:id
 * Delete news (soft delete)
 */
router.delete(
  '/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.deleteNews
);

/**
 * PATCH /api/news/v1/:id/toggle
 * Toggle news active status
 */
router.patch(
  '/:id/toggle',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.toggleStatus
);

export default router;

