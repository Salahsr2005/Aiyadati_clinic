// backend/src/modules/news/v1/news.controller.ts
import { Request, Response, NextFunction } from 'express';
import { newsService } from './news.service';
import { ResponseUtil } from '../../../core/utils/response';

export class NewsController {
  async getActiveNews(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userType, userId, wilayaId, limit, page } = req.query;

      const result = await newsService.getActiveNews({
        userType: userType as any,
        userId: userId as string,
        wilayaId: wilayaId as string,
        limit: limit ? parseInt(limit as string) : 10,
        page: page ? parseInt(page as string) : 1,
      });

      ResponseUtil.success(res, result.items, 'Active news retrieved', 200, {
        page: result.page,
        limit: result.limit,
        total: result.total,
        totalPages: Math.ceil(result.total / result.limit),
        hasNextPage: result.page * result.limit < result.total,
        hasPreviousPage: result.page > 1,
      });
    } catch (error) {
      next(error);
    }
  }

  async createNews(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const user = req.user!;
      const userType = user.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN';

      const result = await newsService.createNews(
        req.body,
        user.id,
        userType
      );

      ResponseUtil.created(res, result, 'News created successfully');
    } catch (error) {
      next(error);
    }
  }

  async updateNews(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const user = req.user!;
      const userRole = user.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN';

      const result = await newsService.updateNews(
        id,
        req.body,
        user.id,
        userRole
      );

      ResponseUtil.success(res, result, 'News updated successfully');
    } catch (error) {
      next(error);
    }
  }

  async deleteNews(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const user = req.user!;
      const userRole = user.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN';

      await newsService.deleteNews(id, user.id, userRole);

      ResponseUtil.success(res, null, 'News deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  async getAllNews(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const result = await newsService.getAllNews(req.query);

      ResponseUtil.success(res, result.items, 'News retrieved successfully', 200, {
        page: result.page,
        limit: result.limit,
        total: result.total,
        totalPages: Math.ceil(result.total / result.limit),
        hasNextPage: result.page * result.limit < result.total,
        hasPreviousPage: result.page > 1,
      });
    } catch (error) {
      next(error);
    }
  }

  async getNewsById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const result = await newsService.getNewsById(id);

      ResponseUtil.success(res, result, 'News retrieved successfully');
    } catch (error) {
      next(error);
    }
  }

  async toggleStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      const user = req.user!;
      const userRole = user.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN';

      const result = await newsService.toggleStatus(
        id,
        isActive,
        user.id,
        userRole
      );

      ResponseUtil.success(
        res,
        result,
        `News ${isActive ? 'activated' : 'deactivated'} successfully`
      );
    } catch (error) {
      next(error);
    }
  }

  async trackView(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      await newsService.trackView(id);

      ResponseUtil.success(res, null, 'View tracked successfully');
    } catch (error) {
      next(error);
    }
  }

  async getStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const stats = await newsService.getStats();

      ResponseUtil.success(res, stats, 'News stats retrieved successfully');
    } catch (error) {
      next(error);
    }
  }
}

