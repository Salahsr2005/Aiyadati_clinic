// backend/src/modules/news/v1/news.validation.ts
import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';
import { NewsStatus, NewsTargetAudience } from '@prisma/client';

const targetAudienceValues = Object.values(NewsTargetAudience);
const statusValues = Object.values(NewsStatus);

const createNewsSchema = Joi.object({
  content: Joi.string().required().messages({
    'string.empty': 'Content is required',
    'any.required': 'Content is required',
  }),
  contentAr: Joi.string().optional().allow('', null),
  contentFr: Joi.string().optional().allow('', null),
  contentEn: Joi.string().optional().allow('', null),
  link: Joi.string().uri().max(500).optional().allow('', null),
  targetAudience: Joi.array()
    .items(Joi.string().valid(...targetAudienceValues))
    .optional()
    .default([]),
  targetUserIds: Joi.array().items(Joi.string().uuid()).optional().default([]),
  targetDoctorIds: Joi.array().items(Joi.string().uuid()).optional().default([]),
  targetClinicIds: Joi.array().items(Joi.string().uuid()).optional().default([]),
  targetWilayas: Joi.array().items(Joi.string().uuid()).optional().default([]),
  startsAt: Joi.date().iso().optional().allow(null),
  expiresAt: Joi.date().iso().optional().allow(null),
  priority: Joi.number().integer().min(0).max(100).default(0),
  status: Joi.string().valid(...statusValues).optional(),
});

const updateNewsSchema = Joi.object({
  content: Joi.string().optional(),
  contentAr: Joi.string().optional().allow('', null),
  contentFr: Joi.string().optional().allow('', null),
  contentEn: Joi.string().optional().allow('', null),
  link: Joi.string().uri().max(500).optional().allow('', null),
  targetAudience: Joi.array()
    .items(Joi.string().valid(...targetAudienceValues))
    .optional(),
  targetUserIds: Joi.array().items(Joi.string().uuid()).optional(),
  targetDoctorIds: Joi.array().items(Joi.string().uuid()).optional(),
  targetClinicIds: Joi.array().items(Joi.string().uuid()).optional(),
  targetWilayas: Joi.array().items(Joi.string().uuid()).optional(),
  startsAt: Joi.date().iso().optional().allow(null),
  expiresAt: Joi.date().iso().optional().allow(null),
  priority: Joi.number().integer().min(0).max(100).optional(),
  status: Joi.string().valid(...statusValues).optional(),
  isActive: Joi.boolean().optional(),
}).min(1);

const getActiveNewsSchema = Joi.object({
  userType: Joi.string().valid('PATIENT', 'DOCTOR', 'CLINIC', 'ADMIN', 'SUPER_ADMIN').required(),
  userId: Joi.string().uuid().optional(),
  wilayaId: Joi.string().uuid().optional(),
  limit: Joi.number().integer().min(1).max(100).default(10),
  page: Joi.number().integer().min(1).default(1),
});

const getAllNewsSchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  status: Joi.string().valid(...statusValues).optional(),
  search: Joi.string().optional(),
  sortBy: Joi.string().valid('createdAt', 'updatedAt', 'priority', 'viewCount').default('createdAt'),
  sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
});

export const validateCreateNews = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createNewsSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateNews = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateNewsSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateGetActiveNews = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = getActiveNewsSchema.validate(req.query, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateGetAllNews = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = getAllNewsSchema.validate(req.query, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

