import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const transferSchema = Joi.object({
  recipientQrCode: Joi.string().uuid().required().messages({
    'string.guid': 'Invalid QR code format',
    'any.required': 'Recipient QR code is required',
  }),
  amount: Joi.number().integer().min(1).max(1000).required().messages({
    'number.min': 'Minimum transfer is 1 credit',
    'number.max': 'Maximum transfer is 1000 credits',
    'any.required': 'Transfer amount is required',
  }),
});

// NEW: Email transfer validation
const emailTransferSchema = Joi.object({
  recipientEmail: Joi.string().email().required().messages({
    'string.email': 'Invalid email format',
    'any.required': 'Recipient email is required',
  }),
  amount: Joi.number().integer().min(1).max(1000).required().messages({
    'number.min': 'Minimum transfer is 1 credit',
    'number.max': 'Maximum transfer is 1000 credits',
    'any.required': 'Transfer amount is required',
  }),
});

export const validateTransfer = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = transferSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// NEW: Email transfer validation middleware
export const validateEmailTransfer = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = emailTransferSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

