import { userRepository } from '../../../repositories/user.repository';
import { walletRepository } from '../../../repositories/wallet.repository';
import { NotFoundError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { QrLookupResponse, TransferResponse, RegenerateQrResponse } from './credit-transfer.types';

export class CreditTransferService {
  async lookupByQr(qrCode: string): Promise<QrLookupResponse> {
    const user = await userRepository.findByQrCode(qrCode);
    if (!user) throw new NotFoundError('User not found');
    return user as QrLookupResponse;
  }

  async transferCredits(
    senderUserId: string,
    recipientQrCode: string,
    amount: number,
    ip?: string
  ): Promise<TransferResponse> {
    // 1. Lookup recipient
    const recipient = await userRepository.findByQrCode(recipientQrCode);
    if (!recipient) throw new NotFoundError('Recipient not found');

    // 2. Cannot send to self
    if (recipient.id === senderUserId) {
      throw new BadRequestError('Cannot send credits to yourself');
    }

    // 3. Check recipient not suspended
    if (recipient.isSuspended) {
      throw new BadRequestError('Recipient account is suspended');
    }

    // 4. Get sender wallet
    const senderWallet = await walletRepository.findByUserId(senderUserId);
    if (!senderWallet) throw new NotFoundError('Sender wallet not found');

    // 5. Check sender has enough credits
    if (senderWallet.credits < amount) {
      throw new BadRequestError('Insufficient credits');
    }

    // 6. Get or create recipient wallet
    const receiverWallet = await walletRepository.getOrCreate(recipient.id);

    // 7. Execute atomic transfer
    const { sentTx, receivedTx, transferId } = await walletRepository.createTransfer({
      senderWalletId: senderWallet.id,
      senderUserId,
      receiverWalletId: receiverWallet.id,
      receiverUserId: recipient.id,
      amount,
    });

    // 8. Audit log
    eventEmitter.emit('audit', {
      action: 'credit.transfer_sent',
      entity: 'CreditTransaction',
      entityId: sentTx.id,
      performedBy: senderUserId,
      details: {
        transferId,
        amount,
        recipientId: recipient.id,
        recipientName: `${recipient.firstName} ${recipient.lastName}`,
      },
      ip,
    });

    // 9. Notify sender
    eventEmitter.emit('notification', {
      userId: senderUserId,
      title: '💸 Credits Sent',
      body: `You sent ${amount} credits to ${recipient.firstName} ${recipient.lastName}.`,
      type: 'transfer',
      data: { transferId, amount, type: 'transfer_sent', otherParty: recipient.id },
    });

    // 10. Notify receiver
    eventEmitter.emit('notification', {
      userId: recipient.id,
      title: '🎁 Credits Received',
      body: `You received ${amount} credits. Check your wallet!`,
      type: 'transfer',
      data: { transferId, amount, type: 'transfer_received' },
    });

    logger.info(`Credit transfer: ${senderUserId} → ${recipient.id}, amount: ${amount}, transferId: ${transferId}`);

    // 11. Get updated sender wallet balance
    const updatedSenderWallet = await walletRepository.findById(senderWallet.id);

    return {
      transferId,
      amount,
      sender: {
        walletId: senderWallet.id,
        remainingCredits: updatedSenderWallet!.credits,
      },
      receiver: {
        userId: recipient.id,
        firstName: recipient.firstName,
        lastName: recipient.lastName,
        walletId: receiverWallet.id,
      },
      sentTxId: sentTx.id,
      receivedTxId: receivedTx.id,
    };
  }

  // NEW: Transfer by email
  async transferByEmail(
    senderUserId: string,
    recipientEmail: string,
    amount: number,
    ip?: string
  ): Promise<TransferResponse> {
    // 1. Lookup recipient by email
    const recipient = await userRepository.findByEmail(recipientEmail);
    if (!recipient) throw new NotFoundError('User not found with this email');

    // 2. Cannot send to self
    if (recipient.id === senderUserId) {
      throw new BadRequestError('Cannot send credits to yourself');
    }

    // 3. Check recipient not suspended
    if (recipient.isSuspended) {
      throw new BadRequestError('Recipient account is suspended');
    }

    // 4. Get sender wallet
    const senderWallet = await walletRepository.findByUserId(senderUserId);
    if (!senderWallet) throw new NotFoundError('Sender wallet not found');

    // 5. Check sender has enough credits
    if (senderWallet.credits < amount) {
      throw new BadRequestError('Insufficient credits');
    }

    // 6. Get or create recipient wallet
    const receiverWallet = await walletRepository.getOrCreate(recipient.id);

    // 7. Execute atomic transfer
    const { sentTx, receivedTx, transferId } = await walletRepository.createTransfer({
      senderWalletId: senderWallet.id,
      senderUserId,
      receiverWalletId: receiverWallet.id,
      receiverUserId: recipient.id,
      amount,
    });

    // 8. Audit log
    eventEmitter.emit('audit', {
      action: 'credit.transfer_sent',
      entity: 'CreditTransaction',
      entityId: sentTx.id,
      performedBy: senderUserId,
      details: {
        transferId,
        amount,
        recipientId: recipient.id,
        recipientName: `${recipient.firstName} ${recipient.lastName}`,
        transferMethod: 'email',
      },
      ip,
    });

    // 9. Notify sender
    eventEmitter.emit('notification', {
      userId: senderUserId,
      title: '💸 Credits Sent',
      body: `You sent ${amount} credits to ${recipient.firstName} ${recipient.lastName} (${recipientEmail}).`,
      type: 'transfer',
      data: { transferId, amount, type: 'transfer_sent', otherParty: recipient.id, method: 'email' },
    });

    // 10. Notify receiver
    eventEmitter.emit('notification', {
      userId: recipient.id,
      title: '🎁 Credits Received',
      body: `You received ${amount} credits from ${senderUserId}. Check your wallet!`,
      type: 'transfer',
      data: { transferId, amount, type: 'transfer_received', method: 'email' },
    });

    logger.info(`Credit transfer (email): ${senderUserId} → ${recipient.id}, amount: ${amount}, transferId: ${transferId}`);

    // 11. Get updated sender wallet balance
    const updatedSenderWallet = await walletRepository.findById(senderWallet.id);

    return {
      transferId,
      amount,
      sender: {
        walletId: senderWallet.id,
        remainingCredits: updatedSenderWallet!.credits,
      },
      receiver: {
        userId: recipient.id,
        firstName: recipient.firstName,
        lastName: recipient.lastName,
        walletId: receiverWallet.id,
      },
      sentTxId: sentTx.id,
      receivedTxId: receivedTx.id,
    };
  }

  async regenerateQrCode(userId: string): Promise<RegenerateQrResponse> {
    const result = await userRepository.regenerateQrCode(userId);
    return result;
  }

  async getMyQrCode(userId: string): Promise<RegenerateQrResponse> {
    const user = await userRepository.findById(userId);
    return { qrCode: user!.qrCode! };
  }
}

export const creditTransferService = new CreditTransferService();

