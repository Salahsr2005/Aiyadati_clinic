export interface QrLookupResponse {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  trustLevel: number;
  trustPoints: number;
  isSuspended: boolean;
  wallet: {
    id: string;
    credits: number;
  } | null;
}

export interface TransferRequestDTO {
  recipientQrCode: string;
  amount: number;
}

export interface TransferResponse {
  transferId: string;
  amount: number;
  sender: {
    walletId: string;
    remainingCredits: number;
  };
  receiver: {
    userId: string;
    firstName: string;
    lastName: string;
    walletId: string;
  };
  sentTxId: string;
  receivedTxId: string;
}

export interface RegenerateQrResponse {
  qrCode: string;
}

