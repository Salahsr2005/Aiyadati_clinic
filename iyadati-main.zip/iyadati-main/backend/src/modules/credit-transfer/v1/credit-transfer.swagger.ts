/**
 * @swagger
 * tags:
 *   name: Credit Transfer
 *   description: P2P credit transfer via QR code scanning or email
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     QrLookupResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         firstName:
 *           type: string
 *           example: "Ahmed"
 *         lastName:
 *           type: string
 *           example: "Benali"
 *         email:
 *           type: string
 *           format: email
 *         phone:
 *           type: string
 *         trustLevel:
 *           type: integer
 *           description: "0=unreliable, 1=new, 2=trusted, 3=VIP"
 *           example: 2
 *         trustPoints:
 *           type: integer
 *           example: 150
 *         isSuspended:
 *           type: boolean
 *         wallet:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *               format: uuid
 *             credits:
 *               type: integer
 *     
 *     TransferRequest:
 *       type: object
 *       required:
 *         - recipientQrCode
 *         - amount
 *       properties:
 *         recipientQrCode:
 *           type: string
 *           format: uuid
 *           description: QR code value scanned from recipient's QR
 *           example: "x8k2m9n4-p1q5-r7t3-w6v8-y2a4b6c8d0e2"
 *         amount:
 *           type: integer
 *           minimum: 1
 *           maximum: 1000
 *           description: Number of credits to send
 *           example: 5
 *     
 *     EmailTransferRequest:
 *       type: object
 *       required:
 *         - recipientEmail
 *         - amount
 *       properties:
 *         recipientEmail:
 *           type: string
 *           format: email
 *           description: Email address of the recipient
 *           example: "john.doe@example.com"
 *         amount:
 *           type: integer
 *           minimum: 1
 *           maximum: 1000
 *           description: Number of credits to send
 *           example: 5
 *     
 *     TransferResponse:
 *       type: object
 *       properties:
 *         transferId:
 *           type: string
 *           format: uuid
 *           description: Shared ID linking both transactions
 *         amount:
 *           type: integer
 *           example: 5
 *         sender:
 *           type: object
 *           properties:
 *             walletId:
 *               type: string
 *               format: uuid
 *             remainingCredits:
 *               type: integer
 *               example: 45
 *         receiver:
 *           type: object
 *           properties:
 *             userId:
 *               type: string
 *               format: uuid
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *             walletId:
 *               type: string
 *               format: uuid
 *         sentTxId:
 *           type: string
 *           format: uuid
 *         receivedTxId:
 *           type: string
 *           format: uuid
 *     
 *     RegenerateQrResponse:
 *       type: object
 *       properties:
 *         qrCode:
 *           type: string
 *           format: uuid
 *           description: New QR code value
 *     
 *     Error:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         error:
 *           type: string
 *         message:
 *           type: string
 *         statusCode:
 *           type: integer
 *         timestamp:
 *           type: string
 *           format: date-time
 *         path:
 *           type: string
 *         method:
 *           type: string
 *         validationErrors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *               message:
 *                 type: string
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/qr/{qrCode}:
 *   get:
 *     summary: Lookup user by QR code
 *     description: |
 *       Scans a QR code and returns the user's public profile information.
 *       Used before confirming a transfer so the sender can verify the recipient's identity.
 *       **Requires authentication (any role).**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: qrCode
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: QR code value extracted from scanned QR
 *         example: "x8k2m9n4-p1q5-r7t3-w6v8-y2a4b6c8d0e2"
 *     responses:
 *       200:
 *         description: User found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: User found
 *                 data:
 *                   $ref: '#/components/schemas/QrLookupResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found (invalid or expired QR code)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/transfer:
 *   post:
 *     summary: Send credits to another user (by QR code)
 *     description: |
 *       Transfers credits from the authenticated user's wallet to another user's wallet.
 *       The recipient is identified by their QR code (obtained via the lookup endpoint first).
 *       
 *       **Business rules:**
 *       - Cannot send to yourself
 *       - Cannot send to suspended users
 *       - Sender must have sufficient credits
 *       - Both parties receive a notification
 *       - Transaction is atomic (both sides succeed or both fail)
 *       - Minimum transfer: 1 credit
 *       - Maximum transfer: 1000 credits
 *       
 *       **Requires User role.**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/TransferRequest'
 *           examples:
 *             small:
 *               summary: Send 5 credits
 *               value:
 *                 recipientQrCode: "x8k2m9n4-p1q5-r7t3-w6v8-y2a4b6c8d0e2"
 *                 amount: 5
 *             medium:
 *               summary: Send 50 credits
 *               value:
 *                 recipientQrCode: "x8k2m9n4-p1q5-r7t3-w6v8-y2a4b6c8d0e2"
 *                 amount: 50
 *             max:
 *               summary: Send 1000 credits (maximum)
 *               value:
 *                 recipientQrCode: "x8k2m9n4-p1q5-r7t3-w6v8-y2a4b6c8d0e2"
 *                 amount: 1000
 *     responses:
 *       201:
 *         description: Transfer completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Transfer completed successfully
 *                 data:
 *                   $ref: '#/components/schemas/TransferResponse'
 *       400:
 *         description: Validation error, insufficient credits, or invalid recipient
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               validation:
 *                 summary: Validation error
 *                 value:
 *                   success: false
 *                   error: Validation failed
 *                   message: Please check your input
 *                   statusCode: 400
 *                   timestamp: "2024-01-15T10:30:00.000Z"
 *                   path: "/api/v1/credit-transfer/v1/transfer"
 *                   method: "POST"
 *                   validationErrors:
 *                     - field: "recipientQrCode"
 *                       message: "Recipient QR code is required"
 *                     - field: "amount"
 *                       message: "Minimum transfer is 1 credit"
 *               insufficient:
 *                 summary: Insufficient credits
 *                 value:
 *                   success: false
 *                   error: Insufficient credits
 *                   message: "You don't have enough credits for this transfer"
 *                   statusCode: 400
 *                   timestamp: "2024-01-15T10:30:00.000Z"
 *               self:
 *                 summary: Self transfer attempt
 *                 value:
 *                   success: false
 *                   error: Cannot send to yourself
 *                   message: "You cannot send credits to your own account"
 *                   statusCode: 400
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: Recipient not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/transfer/email:
 *   post:
 *     summary: Send credits to another user (by email)
 *     description: |
 *       Transfers credits from the authenticated user's wallet to another user's wallet.
 *       The recipient is identified by their email address.
 *       
 *       **Business rules:**
 *       - Cannot send to yourself
 *       - Cannot send to suspended users
 *       - Recipient must have a valid account with the email
 *       - Sender must have sufficient credits
 *       - Both parties receive a notification
 *       - Transaction is atomic (both sides succeed or both fail)
 *       - Minimum transfer: 1 credit
 *       - Maximum transfer: 1000 credits
 *       - Email must be valid format
 *       
 *       **Use cases:**
 *       - Sending credits to a friend when you don't have their QR code
 *       - Sending credits from desktop/web app where scanning QR is not convenient
 *       - Sending credits to users who haven't generated their QR code yet
 *       
 *       **Requires User role.**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/EmailTransferRequest'
 *           examples:
 *             small:
 *               summary: Send 5 credits
 *               value:
 *                 recipientEmail: "john.doe@example.com"
 *                 amount: 5
 *             medium:
 *               summary: Send 50 credits
 *               value:
 *                 recipientEmail: "jane.smith@example.com"
 *                 amount: 50
 *             max:
 *               summary: Send 1000 credits (maximum)
 *               value:
 *                 recipientEmail: "mary.johnson@example.com"
 *                 amount: 1000
 *     responses:
 *       201:
 *         description: Transfer completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Transfer completed successfully
 *                 data:
 *                   $ref: '#/components/schemas/TransferResponse'
 *       400:
 *         description: Validation error, insufficient credits, or invalid recipient
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               validation:
 *                 summary: Validation error
 *                 value:
 *                   success: false
 *                   error: Validation failed
 *                   message: Please check your input
 *                   statusCode: 400
 *                   timestamp: "2024-01-15T10:30:00.000Z"
 *                   path: "/api/v1/credit-transfer/v1/transfer/email"
 *                   method: "POST"
 *                   validationErrors:
 *                     - field: "recipientEmail"
 *                       message: "Invalid email format"
 *                     - field: "amount"
 *                       message: "Minimum transfer is 1 credit"
 *               insufficient:
 *                 summary: Insufficient credits
 *                 value:
 *                   success: false
 *                   error: Insufficient credits
 *                   message: "You don't have enough credits for this transfer"
 *                   statusCode: 400
 *               self:
 *                 summary: Self transfer attempt
 *                 value:
 *                   success: false
 *                   error: Cannot send to yourself
 *                   message: "You cannot send credits to your own account"
 *                   statusCode: 400
 *               suspended:
 *                 summary: Recipient suspended
 *                 value:
 *                   success: false
 *                   error: Recipient account is suspended
 *                   message: "Cannot send credits to a suspended account"
 *                   statusCode: 400
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: User not found with this email
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               not_found:
 *                 summary: User not found
 *                 value:
 *                   success: false
 *                   error: User not found with this email
 *                   message: "No user registered with this email address"
 *                   statusCode: 404
 *                   timestamp: "2024-01-15T10:30:00.000Z"
 *                   path: "/api/v1/credit-transfer/v1/transfer/email"
 *                   method: "POST"
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/qr/regenerate:
 *   post:
 *     summary: Regenerate own QR code
 *     description: |
 *       Generates a new QR code for the authenticated user.
 *       The old QR code becomes invalid immediately.
 *       Use this if your QR code has been compromised or shared unintentionally.
 *       
 *       **Important:** After regeneration, any pending transfers using the old QR code will fail.
 *       Share your new QR code with contacts who need to send you credits.
 *       
 *       **Requires User role.**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: QR code regenerated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: QR code regenerated
 *                 data:
 *                   $ref: '#/components/schemas/RegenerateQrResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/qr/me:
 *   get:
 *     summary: Get my QR code
 *     description: |
 *       Returns the authenticated user's QR code payload. 
 *       This string should be encoded into a QR image on the frontend for others to scan.
 *       
 *       **How to use:**
 *       1. Call this endpoint to get your QR code string
 *       2. Generate a QR image using a library like `qrcode` (frontend)
 *       3. Display the QR code in your profile/wallet section
 *       4. Others can scan it using the `/qr/{qrCode}` lookup endpoint
 *       
 *       **Requires User role.**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: QR code retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: QR code retrieved
 *                 data:
 *                   $ref: '#/components/schemas/RegenerateQrResponse'
 *       401:
 *         description: Not authenticated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: Not authorized (requires User role)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/v1/credit-transfer/v1/transfer/history:
 *   get:
 *     summary: Get transfer history (optional - if you plan to add)
 *     description: |
 *       Retrieves the authenticated user's credit transfer history.
 *       Returns both sent and received transactions.
 *       
 *       **Requires User role.**
 *     tags: [Credit Transfer]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [all, sent, received]
 *         description: Filter transactions by type
 *         default: all
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Number of records to return
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *     responses:
 *       200:
 *         description: Transfer history retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: History retrieved
 *                 data:
 *                   type: object
 *                   properties:
 *                     transactions:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                           amount:
 *                             type: integer
 *                           type:
 *                             type: string
 *                             enum: [transfer_sent, transfer_received]
 *                           otherParty:
 *                             type: object
 *                             properties:
 *                               id:
 *                                 type: string
 *                               firstName:
 *                                 type: string
 *                               lastName:
 *                                 type: string
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                     pagination:
 *                       type: object
 *                       properties:
 *                         page:
 *                           type: integer
 *                         limit:
 *                           type: integer
 *                         total:
 *                           type: integer
 *                         pages:
 *                           type: integer
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 */