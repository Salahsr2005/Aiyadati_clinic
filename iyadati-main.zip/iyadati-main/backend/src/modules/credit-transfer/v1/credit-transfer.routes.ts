import { Router } from 'express';
import { CreditTransferController } from './credit-transfer.controller';
import { validateTransfer, validateEmailTransfer } from './credit-transfer.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';

const router = Router();
const controller = new CreditTransferController();

// QR lookup (any authenticated user can scan)
router.get('/qr/:qrCode', authenticate, controller.lookupByQr);

// Transfer credits
router.post('/transfer', authenticate, authorize('USER'), validateTransfer, controller.transferCredits);

// Transfer by email
router.post('/transfer/email', authenticate, authorize('USER'), validateEmailTransfer, controller.transferByEmail);

// Regenerate own QR code
router.post('/qr/regenerate', authenticate, authorize('USER'), controller.regenerateQrCode);

// Get own QR code
router.get('/qr/me', authenticate, authorize('USER'), controller.getMyQrCode);

export default router;

