import { Request, Response, NextFunction } from 'express';
import { creditTransferService } from './credit-transfer.service';
import { ResponseUtil } from '../../../core/utils/response';

export class CreditTransferController {
  lookupByQr = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await creditTransferService.lookupByQr(req.params.qrCode);
      ResponseUtil.success(res, user, 'User found');
    } catch (error) { next(error); }
  };

  transferCredits = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await creditTransferService.transferCredits(
        req.user!.id,
        req.body.recipientQrCode,
        req.body.amount,
        req.ip
      );
      ResponseUtil.created(res, result, 'Transfer completed successfully');
    } catch (error) { next(error); }
  };

  // NEW: Transfer by email
  transferByEmail = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await creditTransferService.transferByEmail(
        req.user!.id,
        req.body.recipientEmail,
        req.body.amount,
        req.ip
      );
      ResponseUtil.created(res, result, 'Transfer completed successfully');
    } catch (error) { next(error); }
  };

  regenerateQrCode = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await creditTransferService.regenerateQrCode(req.user!.id);
      ResponseUtil.success(res, result, 'QR code regenerated');
    } catch (error) { next(error); }
  };

  getMyQrCode = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await creditTransferService.getMyQrCode(req.user!.id);
      ResponseUtil.success(res, result, 'QR code retrieved');
    } catch (error) { next(error); }
  };
}



