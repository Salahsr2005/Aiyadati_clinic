import { Router } from 'express';
import creditTransferRoutes from './v1/credit-transfer.routes';
import './v1/credit-transfer.swagger';

const router = Router();
router.use('/v1', creditTransferRoutes);

export { router as creditTransferModule };

