import { Router } from 'express';
import reviewRoutes from './v1/review.routes';
const router = Router();
router.use('/v1', reviewRoutes);
export { router as reviewModule };
