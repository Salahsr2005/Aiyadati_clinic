import { Router } from 'express';
import { ReviewController } from './review.controller';
import { validateCreateReview } from './review.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { validateVisibility } from './review.validation';

const router = Router();
const c = new ReviewController();

// Public - view reviews & stats
router.get('/doctor/:doctorId', c.getDoctorReviews);
router.get('/doctor/:doctorId/stats', c.getDoctorStats);
router.get('/clinic/:clinicId', c.getClinicReviews);
router.get('/clinic/:clinicId/stats', c.getClinicStats);

// User - create review
router.post('/doctor/:doctorId', authenticate, authorize('USER'), validateCreateReview, c.createDoctorReview);
router.post('/clinic/:clinicId', authenticate, authorize('USER'), validateCreateReview, c.createClinicReview);

// Doctor/Clinic visibility settings
router.patch('/doctor/me/visibility', authenticate, authorize('DOCTOR'), validateVisibility, c.updateDoctorVisibility);
router.patch('/clinic/me/visibility', authenticate, authorize('CLINIC'), validateVisibility, c.updateClinicVisibility);


export default router;

