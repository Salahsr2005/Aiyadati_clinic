import { doctorReviewRepository } from '../../../repositories/doctor-review.repository';
import { clinicReviewRepository } from '../../../repositories/clinic-review.repository';
import { doctorRepository } from '../../../repositories/doctor.repository';
import { clinicRepository } from '../../../repositories/clinic.repository';
import { NotFoundError, BadRequestError } from '../../../core/utils/error';
import { CreateReviewDTO, ReviewResponse, ReviewStatsResponse } from './review.types';

export class ReviewService {

  // ======================== DOCTOR REVIEWS ========================

  async getDoctorReviews(doctorId: string, page = 1, limit = 10) {
    const { reviews, total } = await doctorReviewRepository.findByDoctorId(doctorId, page, limit);
    return {
      reviews: reviews.map((r: any) => ({
        id: r.id, doctorId: r.doctorId, patientId: r.patientId,
        patient: r.patient ? { id: r.patient.id, firstName: r.patient.firstName, lastName: r.patient.lastName } : undefined,
        rating: r.rating, review: r.review,
        createdAt: r.createdAt.toISOString(), updatedAt: r.updatedAt.toISOString(),
      })),
      total,
    };
  }

  async getDoctorStats(doctorId: string): Promise<ReviewStatsResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');
    return {
      avgRating: doctor.avgRating,
      totalReviews: doctor.totalReviews,
      reviewVisibility: doctor.reviewVisibility,
    };
  }

  async createDoctorReview(doctorId: string, patientId: string, data: CreateReviewDTO): Promise<ReviewResponse> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');

    // Check visibility settings
    if (doctor.reviewVisibility === 'NONE') throw new BadRequestError('Reviews are disabled');
    if (doctor.reviewVisibility === 'RATING_ONLY' && data.review && !data.rating) throw new BadRequestError('Only ratings are allowed');
    if (doctor.reviewVisibility === 'REVIEW_ONLY' && data.rating && !data.review) throw new BadRequestError('Only reviews are allowed');

    const review = await doctorReviewRepository.upsert(doctorId, patientId, {
      rating: doctor.reviewVisibility === 'REVIEW_ONLY' ? undefined : data.rating,
      review: doctor.reviewVisibility === 'RATING_ONLY' ? undefined : data.review,
    });

    await doctorReviewRepository.updateAvgRating(doctorId);

    return {
      id: review.id, doctorId: review.doctorId, patientId: review.patientId,
      rating: review.rating, review: review.review,
      createdAt: review.createdAt.toISOString(), updatedAt: review.updatedAt.toISOString(),
    };
  }

  // ======================== CLINIC REVIEWS ========================

  async getClinicReviews(clinicId: string, page = 1, limit = 10) {
    const { reviews, total } = await clinicReviewRepository.findByClinicId(clinicId, page, limit);
    return {
      reviews: reviews.map((r: any) => ({
        id: r.id, clinicId: r.clinicId, patientId: r.patientId,
        patient: r.patient ? { id: r.patient.id, firstName: r.patient.firstName, lastName: r.patient.lastName } : undefined,
        rating: r.rating, review: r.review,
        createdAt: r.createdAt.toISOString(), updatedAt: r.updatedAt.toISOString(),
      })),
      total,
    };
  }

  async getClinicStats(clinicId: string): Promise<ReviewStatsResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');
    return {
      avgRating: clinic.avgRating,
      totalReviews: clinic.totalReviews,
      reviewVisibility: clinic.reviewVisibility,
    };
  }

  async createClinicReview(clinicId: string, patientId: string, data: CreateReviewDTO): Promise<ReviewResponse> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');

    if (clinic.reviewVisibility === 'NONE') throw new BadRequestError('Reviews are disabled');
    if (clinic.reviewVisibility === 'RATING_ONLY' && data.review && !data.rating) throw new BadRequestError('Only ratings are allowed');
    if (clinic.reviewVisibility === 'REVIEW_ONLY' && data.rating && !data.review) throw new BadRequestError('Only reviews are allowed');

    const review = await clinicReviewRepository.upsert(clinicId, patientId, {
      rating: clinic.reviewVisibility === 'REVIEW_ONLY' ? undefined : data.rating,
      review: clinic.reviewVisibility === 'RATING_ONLY' ? undefined : data.review,
    });

    await clinicReviewRepository.updateAvgRating(clinicId);

    return {
      id: review.id, clinicId: review.clinicId, patientId: review.patientId,
      rating: review.rating, review: review.review,
      createdAt: review.createdAt.toISOString(), updatedAt: review.updatedAt.toISOString(),
    };
  }

    async updateDoctorVisibility(doctorId: string, visibility: string): Promise<void> {
    const doctor = await doctorRepository.findById(doctorId);
    if (!doctor) throw new NotFoundError('Doctor');
    await doctorRepository.update(doctorId, { reviewVisibility: visibility as any });
    }

    async updateClinicVisibility(clinicId: string, visibility: string): Promise<void> {
    const clinic = await clinicRepository.findById(clinicId);
    if (!clinic) throw new NotFoundError('Clinic');
    await clinicRepository.update(clinicId, { reviewVisibility: visibility as any });
    }
}

export const reviewService = new ReviewService();

