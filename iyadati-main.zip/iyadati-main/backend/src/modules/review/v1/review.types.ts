export interface CreateReviewDTO {
  rating?: number;
  review?: string;
}

export interface ReviewResponse {
  id: string;
  doctorId?: string;
  clinicId?: string;
  patientId: string;
  patient?: { id: string; firstName: string; lastName: string };
  rating: number | null;
  review: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ReviewStatsResponse {
  avgRating: number | null;
  totalReviews: number;
  reviewVisibility: string;
}

export interface UpdateVisibilityDTO {
  reviewVisibility: 'BOTH' | 'RATING_ONLY' | 'REVIEW_ONLY' | 'NONE';
}

