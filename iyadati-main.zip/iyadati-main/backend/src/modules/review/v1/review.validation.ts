import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';

const createReviewSchema = Joi.object({
  rating: Joi.number().integer().min(1).max(5).optional(),
  review: Joi.string().max(1000).optional().allow(null, ''),
}).or('rating', 'review').messages({
  'object.missing': 'At least rating or review is required',
});

export const validateCreateReview = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createReviewSchema.validate(req.body, { abortEarly: false });
  if (error) { const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); ResponseUtil.validationError(res, 'Validation failed', errors); return; }
  next();
};


const visibilitySchema = Joi.object({
  reviewVisibility: Joi.string().valid('BOTH', 'RATING_ONLY', 'REVIEW_ONLY', 'NONE').required().messages({
    'any.required': 'reviewVisibility is required',
  }),
});

export const validateVisibility = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = visibilitySchema.validate(req.body, { abortEarly: false });
  if (error) { const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message })); ResponseUtil.validationError(res, 'Validation failed', errors); return; }
  next();
};

