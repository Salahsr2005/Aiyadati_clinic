import { Request, Response, NextFunction } from 'express';
import { reviewService } from './review.service';
import { ResponseUtil } from '../../../core/utils/response';

export class ReviewController {
  // Doctor Reviews
  getDoctorReviews = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const { reviews, total } = await reviewService.getDoctorReviews(req.params.doctorId, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10); ResponseUtil.paginated(res, reviews, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Reviews retrieved'); } catch (error) { next(error); }
  };
  getDoctorStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const stats = await reviewService.getDoctorStats(req.params.doctorId); ResponseUtil.success(res, stats, 'Stats retrieved'); } catch (error) { next(error); }
  };
  createDoctorReview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const review = await reviewService.createDoctorReview(req.params.doctorId, req.user!.id, req.body); ResponseUtil.created(res, review, 'Review submitted'); } catch (error) { next(error); }
  };

  // Clinic Reviews
  getClinicReviews = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const { reviews, total } = await reviewService.getClinicReviews(req.params.clinicId, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10); ResponseUtil.paginated(res, reviews, total, parseInt(req.query.page as string) || 1, parseInt(req.query.limit as string) || 10, 'Reviews retrieved'); } catch (error) { next(error); }
  };
  getClinicStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const stats = await reviewService.getClinicStats(req.params.clinicId); ResponseUtil.success(res, stats, 'Stats retrieved'); } catch (error) { next(error); }
  };
  createClinicReview = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try { const review = await reviewService.createClinicReview(req.params.clinicId, req.user!.id, req.body); ResponseUtil.created(res, review, 'Review submitted'); } catch (error) { next(error); }
  };

updateDoctorVisibility = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    await reviewService.updateDoctorVisibility(req.user!.id, req.body.reviewVisibility);
    ResponseUtil.success(res, null, 'Review visibility updated');
  } catch (error) { next(error); }
};

updateClinicVisibility = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    await reviewService.updateClinicVisibility(req.user!.id, req.body.reviewVisibility);
    ResponseUtil.success(res, null, 'Review visibility updated');
  } catch (error) { next(error); }
};

}

