/**
 * @swagger
 * tags:
 *   name: Review
 *   description: Doctor and clinic reviews, ratings, and visibility settings
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     ReviewResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *         doctorId:
 *           type: string
 *           nullable: true
 *         clinicId:
 *           type: string
 *           nullable: true
 *         patientId:
 *           type: string
 *         patient:
 *           type: object
 *           nullable: true
 *           properties:
 *             id:
 *               type: string
 *             firstName:
 *               type: string
 *             lastName:
 *               type: string
 *         rating:
 *           type: integer
 *           nullable: true
 *           minimum: 1
 *           maximum: 5
 *         review:
 *           type: string
 *           nullable: true
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     ReviewStatsResponse:
 *       type: object
 *       properties:
 *         avgRating:
 *           type: number
 *           nullable: true
 *           example: 4.5
 *         totalReviews:
 *           type: integer
 *           example: 25
 *         reviewVisibility:
 *           type: string
 *           enum: [BOTH, RATING_ONLY, REVIEW_ONLY, NONE]
 *     CreateReviewRequest:
 *       type: object
 *       properties:
 *         rating:
 *           type: integer
 *           minimum: 1
 *           maximum: 5
 *           example: 4
 *         review:
 *           type: string
 *           maxLength: 1000
 *           example: "Excellent doctor, very professional"
 *     ReviewVisibilityRequest:
 *       type: object
 *       required:
 *         - reviewVisibility
 *       properties:
 *         reviewVisibility:
 *           type: string
 *           enum: [BOTH, RATING_ONLY, REVIEW_ONLY, NONE]
 *           description: |
 *             BOTH - Allow rating + review
 *             RATING_ONLY - Only star ratings
 *             REVIEW_ONLY - Only text reviews
 *             NONE - Disable all reviews
 */

/**
 * @swagger
 * /api/v1/review/v1/doctor/{doctorId}:
 *   get:
 *     summary: Get doctor reviews (Public)
 *     tags: [Review]
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Reviews retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ReviewResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Submit doctor review (User)
 *     tags: [Review]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateReviewRequest'
 *     responses:
 *       201:
 *         description: Review submitted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ReviewResponse'
 */

/**
 * @swagger
 * /api/v1/review/v1/doctor/{doctorId}/stats:
 *   get:
 *     summary: Get doctor review stats (Public)
 *     tags: [Review]
 *     parameters:
 *       - in: path
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ReviewStatsResponse'
 */

/**
 * @swagger
 * /api/v1/review/v1/doctor/me/visibility:
 *   patch:
 *     summary: Set doctor review visibility (Doctor)
 *     tags: [Review]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ReviewVisibilityRequest'
 *     responses:
 *       200:
 *         description: Visibility updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 */

/**
 * @swagger
 * /api/v1/review/v1/clinic/{clinicId}:
 *   get:
 *     summary: Get clinic reviews (Public)
 *     tags: [Review]
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Reviews retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/ReviewResponse'
 *                 meta:
 *                   type: object
 *   post:
 *     summary: Submit clinic review (User)
 *     tags: [Review]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateReviewRequest'
 *     responses:
 *       201:
 *         description: Review submitted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ReviewResponse'
 */

/**
 * @swagger
 * /api/v1/review/v1/clinic/{clinicId}/stats:
 *   get:
 *     summary: Get clinic review stats (Public)
 *     tags: [Review]
 *     parameters:
 *       - in: path
 *         name: clinicId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Stats retrieved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/ReviewStatsResponse'
 */

/**
 * @swagger
 * /api/v1/review/v1/clinic/me/visibility:
 *   patch:
 *     summary: Set clinic review visibility (Clinic)
 *     tags: [Review]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ReviewVisibilityRequest'
 *     responses:
 *       200:
 *         description: Visibility updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 */