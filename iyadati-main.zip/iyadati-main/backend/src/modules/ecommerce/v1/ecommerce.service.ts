// src/modules/ecommerce/ecommerce.service.ts

import { categoryRepository } from '../../../repositories/category.repository';
import { productRepository } from '../../../repositories/product.repository';
import { productImageRepository } from '../../../repositories/product-image.repository';
import { shippingCompanyRepository } from '../../../repositories/shipping-company.repository';
import { orderRepository } from '../../../repositories/order.repository';
import { sellerDocumentRepository } from '../../../repositories/seller-document.repository';
import { NotFoundError, BadRequestError, ForbiddenError } from '../../../core/utils/error';
import { generatePublicUrl, generateSignedUrl } from '../../../core/utils/signed-url';
import { logger } from '../../../core/utils/logger';
import { eventEmitter } from '../../../core/events/event-emitter';
import { fileService } from '../../../modules/file/v1/file.service';
import {
  CreateCategoryDTO, UpdateCategoryDTO, CategoryResponse,
  CreateProductDTO, UpdateProductDTO, ProductFilters, ProductResponse, ProductImageResponse,
  CreateShippingCompanyDTO, UpdateShippingCompanyDTO, ShippingCompanyResponse,
  CreateOrderDTO, OrderFilters, OrderResponse, OrderItemResponse, OrderStatusHistoryResponse,
  UpdateOrderStatusDTO, UpdateTrackingDTO, CancelOrderDTO,
  SellerDocumentResponse,
} from './ecommerce.types';

export class EcommerceService {
  // ============================================================
  // CATEGORIES
  // ============================================================

  private toCategoryResponse(category: any): CategoryResponse {
    return {
      id: category.id,
      nameFr: category.nameFr,
      nameAr: category.nameAr,
      slug: category.slug,
      descriptionFr: category.descriptionFr,
      descriptionAr: category.descriptionAr,
      imagePath: category.imagePath,
      parentId: category.parentId,
      parent: category.parent ? {
        id: category.parent.id,
        nameFr: category.parent.nameFr,
        nameAr: category.parent.nameAr,
        slug: category.parent.slug,
      } : null,
      children: category.children?.map((c: any) => ({
        id: c.id,
        nameFr: c.nameFr,
        nameAr: c.nameAr,
        slug: c.slug,
        descriptionFr: c.descriptionFr || null,
        descriptionAr: c.descriptionAr || null,
        imagePath: c.imagePath || null,
        parentId: c.parentId,
        sortOrder: c.sortOrder,
        isActive: c.isActive,
        createdAt: c.createdAt?.toISOString(),
        updatedAt: c.updatedAt?.toISOString(),
      })),
      sortOrder: category.sortOrder,
      isActive: category.isActive,
      productCount: category._count?.products,
      createdAt: category.createdAt.toISOString(),
      updatedAt: category.updatedAt.toISOString(),
    };
  }

  async getCategories(params: {
    parentId?: string | null;
    isActive?: boolean;
    search?: string;
    page?: number;
    limit?: number;
  }) {
    const { categories, total } = await categoryRepository.findAll(params);
    return {
      categories: categories.map((c: any) => this.toCategoryResponse(c)),
      total,
    };
  }

  async getCategoryTree() {
    const categories = await categoryRepository.findTree();
    return categories.map((c: any) => this.toCategoryResponse(c));
  }

  async getCategoryById(id: string): Promise<CategoryResponse> {
    const category = await categoryRepository.findById(id);
    if (!category) throw new NotFoundError('Category not found');
    return this.toCategoryResponse(category);
  }

  async getCategoryBySlug(slug: string): Promise<CategoryResponse> {
    const category = await categoryRepository.findBySlug(slug);
    if (!category) throw new NotFoundError('Category not found');
    return this.toCategoryResponse(category);
  }

  async createCategory(data: CreateCategoryDTO): Promise<CategoryResponse> {
    const exists = await categoryRepository.slugExists(data.slug);
    if (exists) throw new BadRequestError('A category with this slug already exists');

    if (data.parentId) {
      const parent = await categoryRepository.findById(data.parentId);
      if (!parent) throw new NotFoundError('Parent category not found');
    }

    const category = await categoryRepository.create(data);
    return this.toCategoryResponse(category);
  }

  async updateCategory(id: string, data: UpdateCategoryDTO): Promise<CategoryResponse> {
    const category = await categoryRepository.findById(id);
    if (!category) throw new NotFoundError('Category not found');

    if (data.slug && data.slug !== category.slug) {
      const exists = await categoryRepository.slugExists(data.slug, id);
      if (exists) throw new BadRequestError('A category with this slug already exists');
    }

    const updated = await categoryRepository.update(id, data);
    return this.toCategoryResponse(updated);
  }

  async deleteCategory(id: string): Promise<void> {
    const category = await categoryRepository.findById(id);
    if (!category) throw new NotFoundError('Category not found');
    await categoryRepository.delete(id);
  }

  // ============================================================
  // PRODUCTS
  // ============================================================

  private toProductResponse(product: any): ProductResponse {
    return {
      id: product.id,
      sellerId: product.sellerId,
      seller: product.seller ? {
        id: product.seller.id,
        firstName: product.seller.firstName,
        lastName: product.seller.lastName,
        email: product.seller.email,
        phone: product.seller.phone,
        wilaya: product.seller.wilaya,
      } : undefined,
      categoryId: product.categoryId,
      category: product.category ? {
        id: product.category.id,
        nameFr: product.category.nameFr,
        nameAr: product.category.nameAr,
        slug: product.category.slug,
        parent: product.category.parent || null,
      } : undefined,
      titleFr: product.titleFr,
      titleAr: product.titleAr,
      descriptionFr: product.descriptionFr,
      descriptionAr: product.descriptionAr,
      price: product.price,
      comparePrice: product.comparePrice,
      stock: product.stock,
      sku: product.sku,
      status: product.status,
      isApproved: product.isApproved,
      approvedBy: product.approvedBy,
      approvedAt: product.approvedAt?.toISOString() || null,
      viewCount: product.viewCount,
      saleCount: product.saleCount,
      images: product.images?.map((img: any) => this.toProductImageResponse(img)) || [],
      orderCount: product._count?.orderItems,
      createdAt: product.createdAt.toISOString(),
      updatedAt: product.updatedAt.toISOString(),
    };
  }

  private toProductImageResponse(image: any): ProductImageResponse {
    return {
      id: image.id,
      productId: image.productId,
      fileId: image.fileId,
      fileName: image.fileName,
      fileType: image.fileType,
      fileSize: image.fileSize,
      isPrimary: image.isPrimary,
      sortOrder: image.sortOrder,
      accessUrl: generatePublicUrl(image.fileId),
      createdAt: image.createdAt.toISOString(),
      updatedAt: image.updatedAt.toISOString(),
    };
  }

  async getProducts(filters: ProductFilters, userId?: string, userRole?: string) {
      // For admins viewing all, don't filter by approval
      if (userRole && ['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
        const { products, total } = await productRepository.findAll(filters);
        return {
          products: products.map((p: any) => this.toProductResponse(p)),
          total,
        };
      }
      
      const { products, total } = await productRepository.findAll(filters);
      
      // Filter: show approved products OR user's own products (even if unapproved)
      const filteredProducts = products.filter((p: any) => {
        return p.isApproved || p.sellerId === userId;
      });
      
      return {
        products: filteredProducts.map((p: any) => this.toProductResponse(p)),
        total: filteredProducts.length,
      };
    }

async getProductById(id: string, userId?: string, userRole?: string): Promise<ProductResponse> {
    const product = await productRepository.findById(id);
    if (!product) throw new NotFoundError('Product not found');

    // Check access: admin, owner, or approved product
    const isAdmin = userRole && ['SUPER_ADMIN', 'ADMIN'].includes(userRole);
    const isOwner = userId && product.sellerId === userId;
    
    if (!isAdmin && !isOwner && !product.isApproved) {
      throw new NotFoundError('Product not found');
    }

    await productRepository.incrementViewCount(id);

    return this.toProductResponse(product);
  }

  async createProduct(sellerId: string, data: CreateProductDTO): Promise<ProductResponse> {
    const { userRepository } = await import('../../../repositories/user.repository');
    const user = await userRepository.findById(sellerId);
    if (!user?.canPost) throw new ForbiddenError('You are not authorized to sell products');

    const category = await categoryRepository.findById(data.categoryId);
    if (!category) throw new NotFoundError('Category not found');

    if (data.sku) {
      const existing = await productRepository.findBySku(data.sku);
      if (existing) throw new BadRequestError('A product with this SKU already exists');
    }

    const product = await productRepository.create({
      ...data,
      sellerId,
    });

    return this.toProductResponse(product);
  }

  async updateProduct(productId: string, sellerId: string, userRole: string, data: UpdateProductDTO): Promise<ProductResponse> {
    const product = await productRepository.findById(productId);
    if (!product) throw new NotFoundError('Product not found');

    if (product.sellerId !== sellerId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('You can only update your own products');
    }

    if (data.sku && data.sku !== product.sku) {
      const existing = await productRepository.findBySku(data.sku);
      if (existing) throw new BadRequestError('A product with this SKU already exists');
    }

    const updated = await productRepository.update(productId, data);
    return this.toProductResponse(updated);
  }

  async deleteProduct(productId: string, sellerId: string, userRole: string): Promise<void> {
    const product = await productRepository.findById(productId);
    if (!product) throw new NotFoundError('Product not found');

    if (product.sellerId !== sellerId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('You can only delete your own products');
    }

    // Delete all product images from disk first
    const images = await productImageRepository.findByProductId(productId);
    for (const image of images) {
      await fileService.deleteFile(image.fileId, sellerId, userRole, true);
    }

    await productRepository.delete(productId);
  }

  async getMyProducts(sellerId: string, page: number, limit: number) {
    const { products, total } = await productRepository.findBySellerId(sellerId, page, limit);
    return {
      products: products.map((p: any) => this.toProductResponse(p)),
      total,
    };
  }

  async approveProduct(productId: string, adminId: string): Promise<ProductResponse> {
    const product = await productRepository.findById(productId);
    if (!product) throw new NotFoundError('Product not found');

    const updated = await productRepository.approve(productId, adminId);
    return this.toProductResponse(updated);
  }

  async rejectProduct(productId: string): Promise<ProductResponse> {
    const product = await productRepository.findById(productId);
    if (!product) throw new NotFoundError('Product not found');

    const updated = await productRepository.reject(productId);
    return this.toProductResponse(updated);
  }

  // ============================================================
  // PRODUCT IMAGES
  // ============================================================

  async uploadProductImage(productId: string, sellerId: string, file: Express.Multer.File, isPrimary?: boolean) {
    const product = await productRepository.findById(productId);
    if (!product) throw new NotFoundError('Product not found');
    if (product.sellerId !== sellerId) throw new ForbiddenError('You can only add images to your own products');

    const image = await productImageRepository.create({
      productId,
      fileName: file.originalname,
      filePath: `public/products/${file.filename}`,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: file.filename,
      isPrimary: isPrimary || false,
      sortOrder: 0,
    });

    return this.toProductImageResponse(image);
  }

  // ============================================================
  // UPDATED: Delete product image from both DB and disk
  // ============================================================

  async deleteProductImage(imageId: string, sellerId: string): Promise<void> {
    const image = await productImageRepository.findById(imageId);
    if (!image) throw new NotFoundError('Image not found');

    const product = await productRepository.findById(image.productId);
    if (!product || product.sellerId !== sellerId) {
      throw new ForbiddenError('You can only delete images from your own products');
    }

    // Delete from disk (public file)
    await fileService.deleteFile(image.fileId, sellerId, 'USER', true);

    // Delete from database
    await productImageRepository.delete(imageId);
  }

  async setPrimaryImage(imageId: string, sellerId: string): Promise<ProductImageResponse> {
    const image = await productImageRepository.findById(imageId);
    if (!image) throw new NotFoundError('Image not found');

    const product = await productRepository.findById(image.productId);
    if (!product || product.sellerId !== sellerId) {
      throw new ForbiddenError('You can only manage images of your own products');
    }

    const updated = await productImageRepository.setPrimary(imageId);
    return this.toProductImageResponse(updated);
  }

  // ============================================================
  // SHIPPING COMPANIES
  // ============================================================

  private toShippingCompanyResponse(company: any): ShippingCompanyResponse {
    return {
      id: company.id,
      name: company.name,
      trackingUrl: company.trackingUrl,
      logoPath: company.logoPath,
      isActive: company.isActive,
      orderCount: company._count?.orders,
      createdAt: company.createdAt.toISOString(),
      updatedAt: company.updatedAt.toISOString(),
    };
  }

  async getShippingCompanies(isActive?: boolean) {
    const companies = await shippingCompanyRepository.findAll(isActive);
    return companies.map((c: any) => this.toShippingCompanyResponse(c));
  }

  async createShippingCompany(data: CreateShippingCompanyDTO): Promise<ShippingCompanyResponse> {
    const existing = await shippingCompanyRepository.findByName(data.name);
    if (existing) throw new BadRequestError('A shipping company with this name already exists');

    const company = await shippingCompanyRepository.create(data);
    return this.toShippingCompanyResponse(company);
  }

  async updateShippingCompany(id: string, data: UpdateShippingCompanyDTO): Promise<ShippingCompanyResponse> {
    const company = await shippingCompanyRepository.findById(id);
    if (!company) throw new NotFoundError('Shipping company not found');

    if (data.name && data.name !== company.name) {
      const existing = await shippingCompanyRepository.findByName(data.name);
      if (existing) throw new BadRequestError('A shipping company with this name already exists');
    }

    const updated = await shippingCompanyRepository.update(id, data);
    return this.toShippingCompanyResponse(updated);
  }

  async deleteShippingCompany(id: string): Promise<void> {
    const company = await shippingCompanyRepository.findById(id);
    if (!company) throw new NotFoundError('Shipping company not found');
    await shippingCompanyRepository.delete(id);
  }

  // ============================================================
  // ORDERS
  // ============================================================

  private toOrderResponse(order: any): OrderResponse {
    return {
      id: order.id,
      buyerId: order.buyerId,
      buyer: order.buyer ? {
        id: order.buyer.id,
        firstName: order.buyer.firstName,
        lastName: order.buyer.lastName,
        email: order.buyer.email,
        phone: order.buyer.phone,
      } : undefined,
      sellerId: order.sellerId,
      seller: order.seller ? {
        id: order.seller.id,
        firstName: order.seller.firstName,
        lastName: order.seller.lastName,
        email: order.seller.email,
      } : undefined,
      status: order.status,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      chargilyId: order.chargilyId,
      shippingCompanyId: order.shippingCompanyId,
      shippingCompany: order.shippingCompany ? {
        id: order.shippingCompany.id,
        name: order.shippingCompany.name,
        trackingUrl: order.shippingCompany.trackingUrl,
      } : null,
      trackingNumber: order.trackingNumber,
      subtotal: order.subtotal,
      shippingCost: order.shippingCost,
      totalAmount: order.totalAmount,
      notes: order.notes,
      sellerNotes: order.sellerNotes,
      cancelledAt: order.cancelledAt?.toISOString() || null,
      cancelledBy: order.cancelledBy,
      cancelReason: order.cancelReason,
      deliveredAt: order.deliveredAt?.toISOString() || null,
      items: order.items?.map((item: any) => ({
        id: item.id,
        orderId: item.orderId,
        productId: item.productId,
        product: item.product ? {
          id: item.product.id,
          titleFr: item.product.titleFr,
          titleAr: item.product.titleAr,
          images: item.product.images?.map((img: any) => ({
            fileId: img.fileId,
            accessUrl: generatePublicUrl(img.fileId),
          })),
        } : undefined,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice,
      })) || [],
      statusHistory: order.statusHistory?.map((h: any) => ({
        id: h.id,
        orderId: h.orderId,
        status: h.status,
        notes: h.notes,
        changedBy: h.changedBy,
        createdAt: h.createdAt.toISOString(),
      })) || [],
      createdAt: order.createdAt.toISOString(),
      updatedAt: order.updatedAt.toISOString(),
    };
  }

  async getOrders(filters: OrderFilters) {
    const { orders, total } = await orderRepository.findAll(filters);
    return {
      orders: orders.map((o: any) => this.toOrderResponse(o)),
      total,
    };
  }

  async getOrderById(orderId: string, userId: string, userRole: string): Promise<OrderResponse> {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new NotFoundError('Order not found');

    if (order.buyerId !== userId && order.sellerId !== userId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('You cannot view this order');
    }

    return this.toOrderResponse(order);
  }

  async createOrder(buyerId: string, data: CreateOrderDTO): Promise<OrderResponse> {
    let subtotal = 0;
    const items: Array<{
      productId: string;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
    }> = [];

    let sellerId: string | null = null;

    for (const item of data.items) {
      const product = await productRepository.findById(item.productId);
      if (!product) throw new NotFoundError(`Product ${item.productId} not found`);
      if (product.status !== 'ACTIVE' || !product.isApproved) {
        throw new BadRequestError(`Product ${product.titleFr} is not available`);
      }
      if (product.stock < item.quantity) {
        throw new BadRequestError(`Insufficient stock for ${product.titleFr}. Available: ${product.stock}`);
      }

      if (sellerId && product.sellerId !== sellerId) {
        throw new BadRequestError('All items must be from the same seller');
      }
      sellerId = product.sellerId;

      if (product.sellerId === buyerId) {
        throw new BadRequestError('You cannot buy your own products');
      }

      const unitPrice = product.price;
      const totalPrice = unitPrice * item.quantity;
      subtotal += totalPrice;

      items.push({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice,
        totalPrice,
      });
    }

    const shippingCost = data.shippingCost || 0;
    const totalAmount = subtotal + shippingCost;

    const order = await orderRepository.create({
      buyerId,
      sellerId: sellerId!,
      paymentMethod: data.paymentMethod,
      shippingCompanyId: data.shippingCompanyId,
      subtotal,
      shippingCost,
      totalAmount,
      notes: data.notes,
      items,
    });

    eventEmitter.emit('notification', {
      userId: sellerId!,
      title: 'New Order!',
      body: `You have received a new order #${order.id.slice(0, 8)} for ${totalAmount} DZD`,
      type: 'system',
      data: { type: 'new_order', orderId: order.id },
    });

    logger.info(`Order created: ${order.id} by buyer ${buyerId}`);

    return this.toOrderResponse(order);
  }

  async updateOrderStatus(orderId: string, userId: string, userRole: string, data: UpdateOrderStatusDTO): Promise<OrderResponse> {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new NotFoundError('Order not found');

    if (order.sellerId !== userId && !['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
      throw new ForbiddenError('Only the seller can update order status');
    }

    const updated = await orderRepository.updateStatus(orderId, data.status, userId, data.notes);

    eventEmitter.emit('notification', {
      userId: order.buyerId,
      title: 'Order Updated',
      body: `Your order #${order.id.slice(0, 8)} status changed to: ${data.status}`,
      type: 'system',
      data: { type: 'order_status', orderId: order.id, status: data.status },
    });

    return this.toOrderResponse(updated);
  }

  async updateTracking(orderId: string, userId: string, data: UpdateTrackingDTO): Promise<OrderResponse> {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new NotFoundError('Order not found');

    if (order.sellerId !== userId) {
      throw new ForbiddenError('Only the seller can update tracking');
    }

    const updated = await orderRepository.updateTracking(orderId, data.shippingCompanyId, data.trackingNumber);

    eventEmitter.emit('notification', {
      userId: order.buyerId,
      title: 'Order Shipped',
      body: `Your order #${order.id.slice(0, 8)} has been shipped! Tracking: ${data.trackingNumber}`,
      type: 'system',
      data: { type: 'order_shipped', orderId: order.id, trackingNumber: data.trackingNumber },
    });

    return this.toOrderResponse(updated);
  }

  async cancelOrder(orderId: string, userId: string, userRole: string, data: CancelOrderDTO): Promise<OrderResponse> {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new NotFoundError('Order not found');

    const isBuyer = order.buyerId === userId;
    const isAdmin = ['SUPER_ADMIN', 'ADMIN'].includes(userRole);

    if (!isBuyer && !isAdmin) {
      throw new ForbiddenError('You cannot cancel this order');
    }

    if (isBuyer && order.status !== 'PENDING') {
      throw new BadRequestError('You can only cancel pending orders');
    }

    const updated = await orderRepository.cancelOrder(orderId, userId, data.reason);

    if (isBuyer) {
      eventEmitter.emit('notification', {
        userId: order.sellerId,
        title: 'Order Cancelled',
        body: `Order #${order.id.slice(0, 8)} has been cancelled by buyer`,
        type: 'system',
        data: { type: 'order_cancelled', orderId: order.id },
      });
    }

    return this.toOrderResponse(updated);
  }

  async getMyOrders(userId: string, page: number, limit: number) {
    return this.getOrders({ buyerId: userId, page, limit });
  }

  async getMySales(userId: string, page: number, limit: number) {
    return this.getOrders({ sellerId: userId, page, limit });
  }

  async getSellerStats(sellerId: string) {
    return orderRepository.getOrderStats(sellerId);
  }

  // ============================================================
  // SELLER DOCUMENTS
  // ============================================================

  async uploadSellerDocument(userId: string, file: Express.Multer.File, docType?: string) {
    const doc = await sellerDocumentRepository.create({
      userId,
      fileName: file.originalname,
      filePath: `private/ecommerce-documents/${file.filename}`,
      fileType: file.mimetype,
      fileSize: file.size,
      storageKey: file.filename,
      docType: docType || 'license',
    });

    return {
      id: doc.id,
      userId: doc.userId,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      docType: doc.docType,
      isVerified: doc.isVerified,
      verifiedBy: doc.verifiedBy,
      verifiedAt: doc.verifiedAt?.toISOString() || null,
      accessUrl: generateSignedUrl(doc.fileId),
      createdAt: doc.createdAt.toISOString(),
      updatedAt: doc.updatedAt.toISOString(),
    };
  }

  async getSellerDocuments(userId: string) {
    const docs = await sellerDocumentRepository.findByUserId(userId);
    return docs.map((d: any) => ({
      id: d.id,
      userId: d.userId,
      fileName: d.fileName,
      fileType: d.fileType,
      fileSize: d.fileSize,
      docType: d.docType,
      isVerified: d.isVerified,
      verifiedBy: d.verifiedBy,
      verifiedAt: d.verifiedAt?.toISOString() || null,
      accessUrl: generateSignedUrl(d.fileId),
      createdAt: d.createdAt.toISOString(),
      updatedAt: d.updatedAt.toISOString(),
    }));
  }

  async verifySellerDocument(docId: string, adminId: string) {
    const doc = await sellerDocumentRepository.findById(docId);
    if (!doc) throw new NotFoundError('Document not found');

    const verified = await sellerDocumentRepository.verify(docId, adminId);

    eventEmitter.emit('notification', {
      userId: doc.userId,
      title: 'Document Verified',
      body: 'Your seller document has been verified.',
      type: 'system',
      data: { type: 'document_verified' },
    });

    return {
      ...verified,
      accessUrl: generateSignedUrl(verified.fileId),
      createdAt: verified.createdAt.toISOString(),
      updatedAt: verified.updatedAt.toISOString(),
    };
  }

  // ============================================================
  // UPDATED: Delete seller document from both DB and disk
  // ============================================================

  async deleteSellerDocument(docId: string, userId: string): Promise<void> {
    const doc = await sellerDocumentRepository.findById(docId);
    if (!doc) throw new NotFoundError('Document not found');
    if (doc.userId !== userId) throw new ForbiddenError('You can only delete your own documents');

    // Delete from disk (private file)
    await fileService.deleteFile(doc.fileId, userId, 'USER', false);

    // Delete from database
    await sellerDocumentRepository.delete(docId);
  }

  async toggleCanPost(userId: string, canPost: boolean) {
    const { userRepository } = await import('../../../repositories/user.repository');
    const user = await userRepository.findById(userId);
    if (!user) throw new NotFoundError('User not found');

    return userRepository.update(userId, { canPost } as any);
  }
}

export const ecommerceService = new EcommerceService();

