import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ResponseUtil } from '../../../core/utils/response';
import { OrderStatus, ProductStatus, OrderPaymentMethod } from '@prisma/client';

// ============================================================
// Category Validators
// ============================================================

const createCategorySchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'French name must be at least 2 characters',
    'any.required': 'French name is required',
  }),
  nameAr: Joi.string().min(2).max(100).required().messages({
    'string.min': 'Arabic name must be at least 2 characters',
    'any.required': 'Arabic name is required',
  }),
  slug: Joi.string().min(2).max(150).pattern(/^[a-z0-9-]+$/).required().messages({
    'string.pattern.base': 'Slug must contain only lowercase letters, numbers, and hyphens',
    'any.required': 'Slug is required',
  }),
  descriptionFr: Joi.string().max(500).optional(),
  descriptionAr: Joi.string().max(500).optional(),
  parentId: Joi.string().uuid().optional().allow(null),
  sortOrder: Joi.number().integer().min(0).optional(),
});

const updateCategorySchema = Joi.object({
  nameFr: Joi.string().min(2).max(100).optional(),
  nameAr: Joi.string().min(2).max(100).optional(),
  slug: Joi.string().min(2).max(150).pattern(/^[a-z0-9-]+$/).optional(),
  descriptionFr: Joi.string().max(500).optional().allow(null, ''),
  descriptionAr: Joi.string().max(500).optional().allow(null, ''),
  parentId: Joi.string().uuid().optional().allow(null),
  sortOrder: Joi.number().integer().min(0).optional(),
  isActive: Joi.boolean().optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateCategory = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createCategorySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateCategory = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateCategorySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// Product Validators
// ============================================================

const createProductSchema = Joi.object({
  categoryId: Joi.string().uuid().required().messages({
    'any.required': 'Category is required',
  }),
  titleFr: Joi.string().min(3).max(200).required().messages({
    'string.min': 'French title must be at least 3 characters',
    'any.required': 'French title is required',
  }),
  titleAr: Joi.string().min(3).max(200).required().messages({
    'string.min': 'Arabic title must be at least 3 characters',
    'any.required': 'Arabic title is required',
  }),
  descriptionFr: Joi.string().max(5000).optional().allow(null, ''),
  descriptionAr: Joi.string().max(5000).optional().allow(null, ''),
  price: Joi.number().min(0).required().messages({
    'number.min': 'Price must be a positive number',
    'any.required': 'Price is required',
  }),
  comparePrice: Joi.number().min(0).optional().allow(null),
  stock: Joi.number().integer().min(0).default(0),
  sku: Joi.string().max(50).optional().allow(null, ''),
});

const updateProductSchema = Joi.object({
  titleFr: Joi.string().min(3).max(200).optional(),
  titleAr: Joi.string().min(3).max(200).optional(),
  descriptionFr: Joi.string().max(5000).optional().allow(null, ''),
  descriptionAr: Joi.string().max(5000).optional().allow(null, ''),
  price: Joi.number().min(0).optional(),
  comparePrice: Joi.number().min(0).optional().allow(null),
  stock: Joi.number().integer().min(0).optional(),
  sku: Joi.string().max(50).optional().allow(null, ''),
  status: Joi.string().valid(...Object.values(ProductStatus)).optional(),
  categoryId: Joi.string().uuid().optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateProduct = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createProductSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateProduct = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateProductSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// Shipping Company Validators
// ============================================================

const createShippingCompanySchema = Joi.object({
  name: Joi.string().min(2).max(100).required().messages({
    'any.required': 'Company name is required',
  }),
  trackingUrl: Joi.string().uri().optional().allow(null, ''),
  logoPath: Joi.string().optional().allow(null, ''),
});

const updateShippingCompanySchema = Joi.object({
  name: Joi.string().min(2).max(100).optional(),
  trackingUrl: Joi.string().uri().optional().allow(null, ''),
  logoPath: Joi.string().optional().allow(null, ''),
  isActive: Joi.boolean().optional(),
}).min(1).messages({ 'object.min': 'At least one field must be provided' });

export const validateCreateShippingCompany = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createShippingCompanySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateShippingCompany = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateShippingCompanySchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

// ============================================================
// Order Validators
// ============================================================

const createOrderSchema = Joi.object({
  shippingCompanyId: Joi.string().uuid().optional().allow(null),
  shippingCost: Joi.number().min(0).optional().default(0),
  notes: Joi.string().max(500).optional().allow(null, ''),
  paymentMethod: Joi.string().valid(...Object.values(OrderPaymentMethod)).required().messages({
    'any.required': 'Payment method is required',
    'any.only': 'Payment method must be CHARGILY or CASH_ON_DELIVERY',
  }),
  items: Joi.array().min(1).items(Joi.object({
    productId: Joi.string().uuid().required().messages({
      'any.required': 'Product ID is required',
    }),
    quantity: Joi.number().integer().min(1).required().messages({
      'number.min': 'Quantity must be at least 1',
      'any.required': 'Quantity is required',
    }),
  })).required().messages({
    'array.min': 'At least one item is required',
    'any.required': 'Order items are required',
  }),
});

const updateOrderStatusSchema = Joi.object({
  status: Joi.string().valid(...Object.values(OrderStatus)).required().messages({
    'any.required': 'Status is required',
    'any.only': 'Invalid order status',
  }),
  notes: Joi.string().max(500).optional(),
});

const updateTrackingSchema = Joi.object({
  shippingCompanyId: Joi.string().uuid().required().messages({
    'any.required': 'Shipping company is required',
  }),
  trackingNumber: Joi.string().max(100).required().messages({
    'any.required': 'Tracking number is required',
  }),
});

const cancelOrderSchema = Joi.object({
  reason: Joi.string().min(3).max(500).required().messages({
    'string.min': 'Cancellation reason must be at least 3 characters',
    'any.required': 'Reason is required',
  }),
});

export const validateCreateOrder = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = createOrderSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateOrderStatus = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateOrderStatusSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateUpdateTracking = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = updateTrackingSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};

export const validateCancelOrder = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = cancelOrderSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const errors = error.details.map(d => ({ field: d.path.join('.'), message: d.message }));
    ResponseUtil.validationError(res, 'Validation failed', errors);
    return;
  }
  next();
};