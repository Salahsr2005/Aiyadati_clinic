import { Router } from 'express';
import { EcommerceController } from './ecommerce.controller';
import {
  validateCreateCategory,
  validateUpdateCategory,
  validateCreateProduct,
  validateUpdateProduct,
  validateCreateShippingCompany,
  validateUpdateShippingCompany,
  validateCreateOrder,
  validateUpdateOrderStatus,
  validateUpdateTracking,
  validateCancelOrder,
} from './ecommerce.validation';
import { authenticate } from '../../../core/middleware/auth.middleware';
import { authorize } from '../../../core/middleware/authorize.middleware';
import { createRateLimiter } from '../../../core/middleware/rateLimit.middleware';
import { uploadProductImage, uploadSellerDocument } from '../../../core/middleware/upload.middleware';

const router = Router();
const controller = new EcommerceController();

// ============================================================
// PUBLIC ROUTES (No authentication required)
// ============================================================

// Categories (public read)
router.get('/categories', controller.getCategories);
router.get('/categories/tree', controller.getCategoryTree);
router.get('/categories/slug/:slug', controller.getCategoryBySlug);
router.get('/categories/:id', controller.getCategoryById);

// Products (public read)
router.get('/products', controller.getProducts);
router.get('/products/:id', controller.getProductById);

// Shipping companies (public read)
router.get('/shipping-companies', controller.getShippingCompanies);

// ============================================================
// ADMIN ROUTES (Category & Shipping Management)
// ============================================================

// Categories (admin write)
router.post(
  '/categories',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateCategory,
  controller.createCategory
);

router.patch(
  '/categories/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateCategory,
  controller.updateCategory
);

router.delete(
  '/categories/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.deleteCategory
);

// Shipping companies (admin write)
router.post(
  '/shipping-companies',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateCreateShippingCompany,
  controller.createShippingCompany
);

router.patch(
  '/shipping-companies/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  validateUpdateShippingCompany,
  controller.updateShippingCompany
);

router.delete(
  '/shipping-companies/:id',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.deleteShippingCompany
);

// ============================================================
// SELLER ROUTES (Product Management)
// ============================================================

router.get(
  '/my/products',
  authenticate,
  authorize('USER'),
  controller.getMyProducts
);

router.post(
  '/products',
  authenticate,
  authorize('USER'),
  validateCreateProduct,
  controller.createProduct
);

router.patch(
  '/products/:id',
  authenticate,
  authorize('USER'),
  validateUpdateProduct,
  controller.updateProduct
);

router.delete(
  '/products/:id',
  authenticate,
  authorize('USER'),
  controller.deleteProduct
);

// Product Images
router.post(
  '/products/:id/images',
  authenticate,
  authorize('USER'),
  uploadProductImage,
  controller.uploadProductImage
);

router.delete(
  '/products/:id/images/:imageId',
  authenticate,
  authorize('USER'),
  controller.deleteProductImage
);

router.patch(
  '/products/:id/images/:imageId/primary',
  authenticate,
  authorize('USER'),
  controller.setPrimaryImage
);

// ============================================================
// ADMIN ROUTES (Product Approval)
// ============================================================

router.patch(
  '/products/:id/approve',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.approveProduct
);

router.patch(
  '/products/:id/reject',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.rejectProduct
);

// ============================================================
// BUYER ROUTES (Orders)
// ============================================================

router.get(
  '/my/orders',
  authenticate,
  authorize('USER'),
  controller.getMyOrders
);

router.post(
  '/orders',
  authenticate,
  authorize('USER'),
  createRateLimiter({ windowMinutes: 1, maxRequests: 10, message: 'Too many orders' }),
  validateCreateOrder,
  controller.createOrder
);

router.get(
  '/orders/:id',
  authenticate,
  authorize('USER'),
  controller.getOrderById
);

router.post(
  '/orders/:id/cancel',
  authenticate,
  authorize('USER'),
  validateCancelOrder,
  controller.cancelOrder
);

// ============================================================
// SELLER ROUTES (Order Management)
// ============================================================

router.get(
  '/my/sales',
  authenticate,
  authorize('USER'),
  controller.getMySales
);

router.patch(
  '/orders/:id/status',
  authenticate,
  authorize('USER'),
  validateUpdateOrderStatus,
  controller.updateOrderStatus
);

router.patch(
  '/orders/:id/tracking',
  authenticate,
  authorize('USER'),
  validateUpdateTracking,
  controller.updateTracking
);

router.get(
  '/my/stats',
  authenticate,
  authorize('USER'),
  controller.getSellerStats
);

// ============================================================
// ADMIN ROUTES (Orders)
// ============================================================

router.get(
  '/admin/orders',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.getOrders
);

// ============================================================
// SELLER DOCUMENTS
// ============================================================

router.get(
  '/seller/documents',
  authenticate,
  authorize('USER'),
  controller.getSellerDocuments
);

router.post(
  '/seller/documents',
  authenticate,
  authorize('USER'),
  uploadSellerDocument,
  controller.uploadSellerDocument
);

router.delete(
  '/seller/documents/:id',
  authenticate,
  authorize('USER'),
  controller.deleteSellerDocument
);

// Admin: Verify documents
router.patch(
  '/seller/documents/:id/verify',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.verifySellerDocument
);

// ============================================================
// ADMIN: Toggle user selling permission
// ============================================================

router.patch(
  '/users/:userId/can-post',
  authenticate,
  authorize('SUPER_ADMIN', 'ADMIN'),
  controller.toggleCanPost
);

export default router;

