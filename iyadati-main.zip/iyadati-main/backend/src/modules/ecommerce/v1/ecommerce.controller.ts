import { Request, Response, NextFunction } from 'express';
import { ecommerceService } from './ecommerce.service';
import { ResponseUtil } from '../../../core/utils/response';

export class EcommerceController {
  // ============================================================
  // CATEGORIES
  // ============================================================

  getCategories = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await ecommerceService.getCategories(req.query as any);
      ResponseUtil.paginated(
        res, result.categories, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 50,
        'Categories retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  getCategoryTree = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const categories = await ecommerceService.getCategoryTree();
      ResponseUtil.success(res, categories, 'Category tree retrieved successfully');
    } catch (error) { next(error); }
  };

  getCategoryById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const category = await ecommerceService.getCategoryById(req.params.id);
      ResponseUtil.success(res, category, 'Category retrieved successfully');
    } catch (error) { next(error); }
  };

  getCategoryBySlug = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const category = await ecommerceService.getCategoryBySlug(req.params.slug);
      ResponseUtil.success(res, category, 'Category retrieved successfully');
    } catch (error) { next(error); }
  };

  createCategory = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const category = await ecommerceService.createCategory(req.body);
      ResponseUtil.created(res, category, 'Category created successfully');
    } catch (error) { next(error); }
  };

  updateCategory = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const category = await ecommerceService.updateCategory(req.params.id, req.body);
      ResponseUtil.success(res, category, 'Category updated successfully');
    } catch (error) { next(error); }
  };

  deleteCategory = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await ecommerceService.deleteCategory(req.params.id);
      ResponseUtil.success(res, null, 'Category deleted successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // PRODUCTS
  // ============================================================

  getProducts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const result = await ecommerceService.getProducts(
          req.query as any,
          req.user?.id,
          req.user?.role
        );
        ResponseUtil.paginated(
          res, result.products, result.total,
          parseInt(req.query.page as string) || 1,
          parseInt(req.query.limit as string) || 20,
          'Products retrieved successfully'
        );
      } catch (error) { next(error); }
    };

    getProductById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
          const product = await ecommerceService.getProductById(
            req.params.id,
            req.user?.id,
            req.user?.role
          );
          ResponseUtil.success(res, product, 'Product retrieved successfully');
        } catch (error) { next(error); }
      };

  createProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const product = await ecommerceService.createProduct(req.user!.id, req.body);
      ResponseUtil.created(res, product, 'Product created successfully');
    } catch (error) { next(error); }
  };

  updateProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const product = await ecommerceService.updateProduct(
        req.params.id,
        req.user!.id,
        req.user!.role,
        req.body
      );
      ResponseUtil.success(res, product, 'Product updated successfully');
    } catch (error) { next(error); }
  };

  deleteProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await ecommerceService.deleteProduct(req.params.id, req.user!.id, req.user!.role);
      ResponseUtil.success(res, null, 'Product deleted successfully');
    } catch (error) { next(error); }
  };

  getMyProducts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await ecommerceService.getMyProducts(
        req.user!.id,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20
      );
      ResponseUtil.paginated(res, result.products, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20,
        'Your products retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  approveProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const product = await ecommerceService.approveProduct(req.params.id, req.user!.id);
      ResponseUtil.success(res, product, 'Product approved successfully');
    } catch (error) { next(error); }
  };

  rejectProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const product = await ecommerceService.rejectProduct(req.params.id);
      ResponseUtil.success(res, product, 'Product rejected');
    } catch (error) { next(error); }
  };

  // ============================================================
  // PRODUCT IMAGES
  // ============================================================

  uploadProductImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Image is required'); return; }
      const image = await ecommerceService.uploadProductImage(
        req.params.id,
        req.user!.id,
        req.file,
        req.body.isPrimary === 'true' || req.body.isPrimary === true
      );
      ResponseUtil.created(res, image, 'Image uploaded successfully');
    } catch (error) { next(error); }
  };

  deleteProductImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await ecommerceService.deleteProductImage(req.params.imageId, req.user!.id);
      ResponseUtil.success(res, null, 'Image deleted successfully');
    } catch (error) { next(error); }
  };

  setPrimaryImage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const image = await ecommerceService.setPrimaryImage(req.params.imageId, req.user!.id);
      ResponseUtil.success(res, image, 'Primary image set successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // SHIPPING COMPANIES
  // ============================================================

  getShippingCompanies = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;
      const companies = await ecommerceService.getShippingCompanies(isActive);
      ResponseUtil.success(res, companies, 'Shipping companies retrieved successfully');
    } catch (error) { next(error); }
  };

  createShippingCompany = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const company = await ecommerceService.createShippingCompany(req.body);
      ResponseUtil.created(res, company, 'Shipping company created successfully');
    } catch (error) { next(error); }
  };

  updateShippingCompany = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const company = await ecommerceService.updateShippingCompany(req.params.id, req.body);
      ResponseUtil.success(res, company, 'Shipping company updated successfully');
    } catch (error) { next(error); }
  };

  deleteShippingCompany = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await ecommerceService.deleteShippingCompany(req.params.id);
      ResponseUtil.success(res, null, 'Shipping company deleted successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // ORDERS
  // ============================================================

  getOrders = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await ecommerceService.getOrders(req.query as any);
      ResponseUtil.paginated(
        res, result.orders, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20,
        'Orders retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  getOrderById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const order = await ecommerceService.getOrderById(req.params.id, req.user!.id, req.user!.role);
      ResponseUtil.success(res, order, 'Order retrieved successfully');
    } catch (error) { next(error); }
  };

  createOrder = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const order = await ecommerceService.createOrder(req.user!.id, req.body);
      ResponseUtil.created(res, order, 'Order created successfully');
    } catch (error) { next(error); }
  };

  updateOrderStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const order = await ecommerceService.updateOrderStatus(
        req.params.id,
        req.user!.id,
        req.user!.role,
        req.body
      );
      ResponseUtil.success(res, order, 'Order status updated successfully');
    } catch (error) { next(error); }
  };

  updateTracking = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const order = await ecommerceService.updateTracking(req.params.id, req.user!.id, req.body);
      ResponseUtil.success(res, order, 'Tracking updated successfully');
    } catch (error) { next(error); }
  };

  cancelOrder = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const order = await ecommerceService.cancelOrder(req.params.id, req.user!.id, req.user!.role, req.body);
      ResponseUtil.success(res, order, 'Order cancelled successfully');
    } catch (error) { next(error); }
  };

  getMyOrders = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await ecommerceService.getMyOrders(
        req.user!.id,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20
      );
      ResponseUtil.paginated(res, result.orders, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20,
        'Your orders retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  getMySales = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await ecommerceService.getMySales(
        req.user!.id,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20
      );
      ResponseUtil.paginated(res, result.orders, result.total,
        parseInt(req.query.page as string) || 1,
        parseInt(req.query.limit as string) || 20,
        'Your sales retrieved successfully'
      );
    } catch (error) { next(error); }
  };

  getSellerStats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const stats = await ecommerceService.getSellerStats(req.user!.id);
      ResponseUtil.success(res, stats, 'Seller stats retrieved successfully');
    } catch (error) { next(error); }
  };

  // ============================================================
  // SELLER DOCUMENTS
  // ============================================================

  uploadSellerDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.file) { ResponseUtil.badRequest(res, 'Document is required'); return; }
      const doc = await ecommerceService.uploadSellerDocument(req.user!.id, req.file, req.body.docType);
      ResponseUtil.created(res, doc, 'Document uploaded successfully');
    } catch (error) { next(error); }
  };

  getSellerDocuments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const docs = await ecommerceService.getSellerDocuments(req.user!.id);
      ResponseUtil.success(res, docs, 'Documents retrieved successfully');
    } catch (error) { next(error); }
  };

  verifySellerDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const doc = await ecommerceService.verifySellerDocument(req.params.id, req.user!.id);
      ResponseUtil.success(res, doc, 'Document verified successfully');
    } catch (error) { next(error); }
  };

  deleteSellerDocument = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await ecommerceService.deleteSellerDocument(req.params.id, req.user!.id);
      ResponseUtil.success(res, null, 'Document deleted successfully');
    } catch (error) { next(error); }
  };

  toggleCanPost = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await ecommerceService.toggleCanPost(req.params.userId, req.body.canPost);
      ResponseUtil.success(res, user, `User selling ${req.body.canPost ? 'enabled' : 'disabled'} successfully`);
    } catch (error) { next(error); }
  };
}

