import { Router } from 'express';
import ecommerceRoutes from './v1/ecommerce.routes';
import './v1/ecommerce.swagger';

const router = Router();
router.use('/v1', ecommerceRoutes);

export { router as ecommerceModule };
