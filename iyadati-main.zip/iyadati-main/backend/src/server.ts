import http from 'http';
import app from './app';
import { initSocket } from './config/socket';
import { logger } from './core/utils/logger';
import { env } from './config/env';

import './infrastructure/queues/workers';

app.set('trust proxy', 1);

const server = http.createServer(app);

initSocket(server);

server.listen(env.PORT, '0.0.0.0', () => {
  logger.info(`Server running on port ${env.PORT}`);
  logger.info(`Environment: ${env.NODE_ENV}`);
  logger.info(`Health: http://localhost:${env.PORT}`);
});

