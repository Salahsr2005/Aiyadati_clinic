import {
  FileInput,
  UploadOptions,
  UploadResult,
  DownloadOptions,
  FileOutput,
  FileMetadata,
  DeleteResult,
  DeleteOptions,
  CopyResult,
  MoveResult,
} from '../storage/storage.types';

/**
 * STORAGE PROVIDER INTERFACE
 * 
 * Any storage system (Local, MinIO, S3) MUST implement ALL of these functions
 */
export interface StorageProvider {
  /**
   * Upload a file to storage
   */
  upload(file: FileInput, options?: UploadOptions): Promise<UploadResult>;

  /**
   * Download a file from storage
   */
  download(identifier: string, options?: DownloadOptions): Promise<FileOutput>;

  /**
   * Delete a file from storage
   */
  delete(identifier: string, options?: DeleteOptions): Promise<DeleteResult>;

  /**
   * Check if a file exists in storage
   */
  exists(identifier: string): Promise<boolean>;

  /**
   * Generate a signed URL for temporary access
   */
  getSignedUrl(identifier: string, expiresIn?: number): Promise<string>;

  /**
   * Get public URL for a file (no authentication needed)
   */
  getPublicUrl(identifier: string): string;

  /**
   * Get file metadata
   */
  getMetadata(identifier: string): Promise<FileMetadata>;

  /**
   * Update file metadata
   */
  updateMetadata(identifier: string, metadata: Partial<FileMetadata>): Promise<FileMetadata>;

  /**
   * Copy a file within storage
   */
  copy(source: string, destination: string): Promise<CopyResult>;

  /**
   * Move a file within storage
   */
  move(source: string, destination: string): Promise<MoveResult>;
}