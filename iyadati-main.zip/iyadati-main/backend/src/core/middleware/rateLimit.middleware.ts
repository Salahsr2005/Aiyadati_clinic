import rateLimit from 'express-rate-limit';
import { Request } from 'express';
import { env } from '../../config/env';
import { ResponseUtil } from '../utils/response';

interface RateLimitConfig {
  windowMinutes?: number;
  maxRequests?: number;
  message?: string;
}

export const createRateLimiter = (config: RateLimitConfig = {}) => {
  const {
    windowMinutes = 15,
    maxRequests = 100,
    message = 'Too many requests, please try again later',
  } = config;

  const effectiveMax = env.isDevelopment ? maxRequests * 100 : maxRequests;

  return rateLimit({
    windowMs: windowMinutes * 60 * 1000,
    max: effectiveMax,
    standardHeaders: true,
    legacyHeaders: false,
    // Don't set keyGenerator - use default which handles IPv6 correctly
    handler: (_req, res) => {
      ResponseUtil.tooManyRequests(res, message);
    },
  });
};

