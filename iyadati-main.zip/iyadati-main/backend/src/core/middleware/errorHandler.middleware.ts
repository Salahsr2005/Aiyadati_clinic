import { Request, Response, NextFunction } from 'express';
import { Prisma } from '@prisma/client';
import { AppError } from '../utils/error';
import { ResponseUtil } from '../utils/response';
import { logger } from '../utils/logger';
import { env } from '../../config/env';

export const notFoundHandler = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const error = new AppError(`Route ${req.method} ${req.originalUrl} not found`, 404);
  next(error);
};

export const globalErrorHandler = (
  error: Error | AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void => {

  if (env.isDevelopment) {
      logger.error({
        message: error.message,
        stack: error.stack,
        url: req.url,
        method: req.method,
      });
    }

  // Handle Prisma known errors
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    switch (error.code) {
      case 'P2002':
        ResponseUtil.conflict(
          res,
          `Duplicate field value: ${error.meta?.target}`,
          [{ field: error.meta?.target, message: 'Must be unique' }]
        );
        return;
      case 'P2003':
        ResponseUtil.badRequest(
          res,
          'Foreign key constraint failed',
          [{ message: 'Referenced record does not exist' }]
        );
        return;
      case 'P2025':
        ResponseUtil.notFound(res, 'Record not found');
        return;
      case 'P2014':
        ResponseUtil.badRequest(
          res,
          'Invalid ID format or related record not found'
        );
        return;
      default:
        ResponseUtil.error(res, 'Database error', 500, [
          { code: error.code, message: error.message }
        ]);
        return;
    }
  }

  // Handle Prisma validation errors
  if (error instanceof Prisma.PrismaClientValidationError) {
    ResponseUtil.validationError(
      res,
      'Invalid data provided',
      [{ message: error.message }]
    );
    return;
  }

  // Handle custom AppError
  if (error instanceof AppError) {
    ResponseUtil.error(
      res,
      error.message,
      error.statusCode,
      error.details
    );
    return;
  }

  // Handle JWT errors
  if (error.name === 'JsonWebTokenError') {
    ResponseUtil.unauthorized(res, 'Invalid token');
    return;
  }

  if (error.name === 'TokenExpiredError') {
    ResponseUtil.unauthorized(res, 'Token expired');
    return;
  }

  // Handle unknown errors
  const statusCode = (error as any).statusCode || 500;
  const message = statusCode === 500 ? 'Internal server error' : error.message;

  // Don't expose internal error details in production
  if (process.env.NODE_ENV === 'production' && statusCode === 500) {
    ResponseUtil.error(res, 'Something went wrong', 500);
    return;
  }

  ResponseUtil.error(res, message, statusCode);
};