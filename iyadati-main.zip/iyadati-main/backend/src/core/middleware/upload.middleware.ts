import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { env } from '../../config/env';
import { BadRequestError } from '../utils/error';

// ============================================================
// CONFIGURATION
// ============================================================

// Base directories
const UPLOAD_DIR = path.join(__dirname, '../../../', env.UPLOAD_DIR || 'uploads');
const PUBLIC_DIR = path.join(UPLOAD_DIR, 'public');
const PRIVATE_DIR = path.join(UPLOAD_DIR, 'private');

// File size limits
const LIMITS = {
  LOGO: 2 * 1024 * 1024,           // 2MB
  DOCUMENT: 20 * 1024 * 1024,      // 20MB
  GALLERY: 5 * 1024 * 1024,        // 5MB
  SERVICE_IMAGE: 5 * 1024 * 1024,  // 5MB
};

// Allowed file types
const ALLOWED = {
  IMAGE: ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'],
  DOCUMENT: ['application/pdf', 'image/jpeg', 'image/png'],
};

// Directory mapping - No paths exposed in URLs!
const DIRECTORIES = {
  // Public files (accessible without auth)
  PUBLIC: {
    LOGOS: path.join(PUBLIC_DIR, 'logos'),
    GALLERY: path.join(PUBLIC_DIR, 'gallery'),
    SERVICE_IMAGES: path.join(PUBLIC_DIR, 'service-images'),
    PRODUCTS: path.join(PUBLIC_DIR, 'products'),
    SPECIALTY_IMAGES: path.join(PUBLIC_DIR, 'specialty-images'),
    ADVERTISEMENTS: path.join(PUBLIC_DIR, 'advertisements'),
  },
  // Private files (require auth)
  PRIVATE: {
    DOCTOR_DOCUMENTS: path.join(PRIVATE_DIR, 'doctor-documents'),
    USER_DOCUMENTS: path.join(PRIVATE_DIR, 'user-documents'),
    CLINIC_DOCUMENTS: path.join(PRIVATE_DIR, 'clinic-documents'),
    SELLER_DOCUMENTS: path.join(PRIVATE_DIR, 'ecommerce-documents'),
  },
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Ensure all directories exist
 */
const ensureDirectories = () => {
  const allDirs = [
    UPLOAD_DIR,
    PUBLIC_DIR,
    PRIVATE_DIR,
    ...Object.values(DIRECTORIES.PUBLIC),
    ...Object.values(DIRECTORIES.PRIVATE),
  ];
  
  for (const dir of allDirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
};
ensureDirectories();

/**
 * Generate a secure filename (UUID only, no path info)
 */
const generateSecureFilename = (originalName: string): string => {
  const ext = path.extname(originalName);
  const uuid = crypto.randomUUID(); // Uses UUID v4 - cryptographically secure
  return `${uuid}${ext}`;
};

/**
 * Create multer storage with specific destination
 */
const createStorage = (destination: string) => {
  return multer.diskStorage({
    destination: (_req, _file, cb) => {
      cb(null, destination);
    },
    filename: (_req, file, cb) => {
      const filename = generateSecureFilename(file.originalname);
      cb(null, filename);
    },
  });
};

/**
 * Create multer upload instance
 */
const createUpload = (
  destination: string,
  maxSize: number,
  allowedTypes: string[],
  fieldName: string = 'file'
) => {
  const storage = createStorage(destination);
  
  return multer({
    storage,
    limits: { fileSize: maxSize },
    fileFilter: (_req, file, cb) => {
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new BadRequestError(
          `Invalid file type. Allowed: ${allowedTypes.join(', ')}`
        ) as any);
      }
    },
  }).single(fieldName);
};

// ============================================================
// EXPORTED UPLOAD MIDDLEWARE
// ============================================================

// ========== PUBLIC FILES (No auth needed for viewing) ==========

/**
 * Upload clinic/doctor logo - PUBLIC
 * File is stored with UUID, accessed by ID
 */
export const uploadLogo = createUpload(
  DIRECTORIES.PUBLIC.LOGOS,
  LIMITS.LOGO,
  ALLOWED.IMAGE,
  'logo'
);

/**
 * Upload gallery image - PUBLIC
 */
export const uploadGalleryImage = createUpload(
  DIRECTORIES.PUBLIC.GALLERY,
  LIMITS.GALLERY,
  ALLOWED.IMAGE,
  'image'
);

/**
 * Upload service image - PUBLIC
 */
export const uploadServiceImage = createUpload(
  DIRECTORIES.PUBLIC.SERVICE_IMAGES,
  LIMITS.SERVICE_IMAGE,
  ALLOWED.IMAGE,
  'image'
);

export const uploadSpecialtyImage = createUpload(
  DIRECTORIES.PUBLIC.SPECIALTY_IMAGES,
  LIMITS.GALLERY,
  ALLOWED.IMAGE,
  'image'
);


// ========== PRIVATE FILES (Auth required) ==========

/**
 * Upload doctor document - PRIVATE
 */
export const uploadDoctorDocument = createUpload(
  DIRECTORIES.PRIVATE.DOCTOR_DOCUMENTS,
  LIMITS.DOCUMENT,
  ALLOWED.DOCUMENT,
  'document'
);

/**
 * Upload user document - PRIVATE
 */
export const uploadUserDocument = createUpload(
  DIRECTORIES.PRIVATE.USER_DOCUMENTS,
  LIMITS.DOCUMENT,
  ALLOWED.DOCUMENT,
  'document'
);

/**
 * Upload clinic document - PRIVATE
 */
export const uploadClinicDocument = createUpload(
  DIRECTORIES.PRIVATE.CLINIC_DOCUMENTS,
  LIMITS.DOCUMENT,
  ALLOWED.DOCUMENT,
  'document'
);


export const uploadProductImage = createUpload(
  DIRECTORIES.PUBLIC.PRODUCTS,
  LIMITS.GALLERY,
  ALLOWED.IMAGE,
  'image'
);

export const uploadSellerDocument = createUpload(
  DIRECTORIES.PRIVATE.SELLER_DOCUMENTS,
  LIMITS.DOCUMENT,
  ALLOWED.DOCUMENT,
  'document'
);

// ========== MULTIPLE FILES ==========

/**
 * Upload multiple documents - PRIVATE
 * Allows up to 5 files, 20MB each
 */
export const uploadMultipleDocuments = multer({
  storage: createStorage(DIRECTORIES.PRIVATE.DOCTOR_DOCUMENTS),
  limits: { fileSize: LIMITS.DOCUMENT, files: 5 },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED.DOCUMENT.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new BadRequestError('Only PDF, JPEG, and PNG files are allowed') as any);
    }
  },
}).array('documents', 5);

// ============================================================
// EXPORT DIRECTORIES FOR OTHER MODULES
// ============================================================

export const UPLOAD_PATHS = {
  PUBLIC: DIRECTORIES.PUBLIC,
  PRIVATE: DIRECTORIES.PRIVATE,
};

// ============================================================
// UTILITY: Get file info from database by ID
// ============================================================

/**
 * Get the full file path from fileId
 * This is used by the file controller to serve files
 */
export const getFilePathByFileId = async (
  fileId: string,
  repository: any // Pass the specific repository
): Promise<string | null> => {
  const file = await repository.findByFileId(fileId);
  if (!file) return null;
  
  // file.filePath already contains the relative path
  return path.join(UPLOAD_DIR, file.filePath);
};

/**
 * Get file URL by fileId (for API responses)
 */
export const getFileUrl = (fileId: string, isPublic: boolean = false): string => {
  const baseUrl = env.BASE_URL || 'http://localhost:3975';
  const endpoint = isPublic ? 'public' : 'private';
  return `${baseUrl}/api/v1/files/${endpoint}/${fileId}`;
};


export const uploadAdvertisement = createUpload(
  DIRECTORIES.PUBLIC.ADVERTISEMENTS,
  10 * 1024 * 1024,  // 10MB (larger for ads)
  ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'],
  'image'  // field name
);


