/**
 * INPUT: What you give to the storage system when uploading
 */
export interface FileInput {
  buffer: Buffer;
  originalName: string;
  mimeType: string;
  size: number;
}

/**
 * OPTIONS: Extra settings when uploading
 */
export interface UploadOptions {
  path?: string;
  metadata?: Record<string, string>;
  isPublic?: boolean;
  contentType?: string;
  cacheControl?: string;
}

/**
 * RESULT: What the storage system returns after saving
 */
export interface UploadResult {
  id: string;
  key: string;
  path: string;
  publicUrl?: string;
  metadata: Record<string, string>;
  size: number;
  uploadedAt: Date;
}

/**
 * OPTIONS: Options for downloading
 */
export interface DownloadOptions {
  range?: { start: number; end: number };
}

/**
 * METADATA: All the information about a file
 */
export interface FileMetadata {
  id: string;
  key: string;
  path: string;
  originalName: string;
  mimeType: string;
  size: number;
  isPublic: boolean;
  metadata: Record<string, string>;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * OUTPUT: What you get when you ask for a file
 */
export interface FileOutput {
  buffer: Buffer;
  metadata: FileMetadata;
  size: number;
  contentType: string;
}

/**
 * DELETE: Result of deleting a file
 */
export interface DeleteResult {
  success: boolean;
  message?: string;
}

/**
 * DELETE: Options for deleting
 */
export interface DeleteOptions {
  permanent?: boolean;
}

/**
 * COPY: Result of copying a file
 */
export interface CopyResult {
  success: boolean;
  newId: string;
  newKey: string;
}

/**
 * MOVE: Result of moving a file
 */
export interface MoveResult {
  success: boolean;
  newId: string;
  newKey: string;
}
