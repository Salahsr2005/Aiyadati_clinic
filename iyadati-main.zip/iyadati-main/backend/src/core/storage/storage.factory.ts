import { StorageProvider } from '../interfaces/storage.interface';
import { LocalStorageProvider } from './providers/local.provider';
import { env } from '../../config/env';

/**
 * STORAGE FACTORY
 * 
 * Decides which storage provider to use based on configuration
 * 
 * Usage:
 *   const storage = StorageFactory.getInstance();
 *   await storage.upload(file, options);
 * 
 * Environment Variables:
 *   STORAGE_TYPE=local   # Use local filesystem (default)
 *   STORAGE_TYPE=minio   # Use MinIO (future)
 *   STORAGE_TYPE=s3      # Use AWS S3 (future)
 */
export class StorageFactory {
  private static instance: StorageProvider | null = null;

  /**
   * Get the storage provider instance
   * Uses singleton pattern to avoid recreating the provider
   */
  static getInstance(): StorageProvider {
    if (!StorageFactory.instance) {
      const type = env.STORAGE_TYPE || 'local';

      switch (type) {
        case 'local':
          StorageFactory.instance = new LocalStorageProvider();
          break;
        // Future providers (uncomment when implemented)
        // case 'minio':
        //   StorageFactory.instance = new MinioStorageProvider();
        //   break;
        // case 's3':
        //   StorageFactory.instance = new S3StorageProvider();
        //   break;
        default:
          throw new Error(`Unsupported storage type: ${type}`);
      }
    }

    return StorageFactory.instance;
  }

  /**
   * Reset the instance (useful for testing)
   */
  static reset(): void {
    StorageFactory.instance = null;
  }
}

