import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { StorageProvider } from '../../interfaces/storage.interface';
import {
  FileInput,
  UploadOptions,
  UploadResult,
  DownloadOptions,
  FileOutput,
  FileMetadata,
  DeleteResult,
  DeleteOptions,
  CopyResult,
  MoveResult,
} from '../storage.types';
import { env } from '../../../config/env';
import { NotFoundError } from '../../utils/error';

export class LocalStorageProvider implements StorageProvider {
  private basePath: string;
  private baseUrl: string;
  private secret: string;

  constructor() {
    this.basePath = path.join(process.cwd(), env.UPLOAD_DIR || 'uploads');
    this.baseUrl = env.BASE_URL || 'http://localhost:3000';
    this.secret = env.FILE_SECRET || 'default-secret-change-me';
  }

  private generateId(): string {
    return crypto.randomUUID();
  }

  private getFullPath(filePath: string): string {
    return path.join(this.basePath, filePath);
  }

  private async ensureDirectory(dir: string): Promise<void> {
    await fs.mkdir(dir, { recursive: true });
  }

  async upload(file: FileInput, options: UploadOptions = {}): Promise<UploadResult> {
    const { path: subPath = '', metadata = {}, isPublic = false } = options;

    const ext = path.extname(file.originalName);
    const key = `${this.generateId()}${ext}`;
    const fullPath = this.getFullPath(path.join(subPath, key));

    await this.ensureDirectory(path.dirname(fullPath));
    await fs.writeFile(fullPath, file.buffer);

    const result: UploadResult = {
      id: this.generateId(),
      key,
      path: path.join(subPath, key),
      metadata: {
        ...metadata,
        originalName: file.originalName,
        mimeType: file.mimeType,
        size: String(file.size),
        isPublic: String(isPublic),
      },
      size: file.size,
      uploadedAt: new Date(),
    };

    if (isPublic) {
      result.publicUrl = this.getPublicUrl(path.join(subPath, key));
    }

    return result;
  }

  async download(identifier: string, options?: DownloadOptions): Promise<FileOutput> {
    const fullPath = this.getFullPath(identifier);

    try {
      const buffer = await fs.readFile(fullPath);
      const stats = await fs.stat(fullPath);

      return {
        buffer,
        metadata: {
          id: this.generateId(),
          key: path.basename(identifier),
          path: identifier,
          originalName: path.basename(identifier),
          mimeType: 'application/octet-stream',
          size: stats.size,
          isPublic: false,
          metadata: {},
          createdAt: stats.birthtime,
          updatedAt: stats.mtime,
        },
        size: stats.size,
        contentType: 'application/octet-stream',
      };
    } catch (error) {
      throw new NotFoundError('File not found');
    }
  }

  async delete(identifier: string, options?: DeleteOptions): Promise<DeleteResult> {
    const fullPath = this.getFullPath(identifier);
    
    try {
      // Check if file exists first
      const fileExists = await this.exists(identifier);
      if (!fileExists) {
        return { success: true, message: 'File already deleted' };
      }
      
      await fs.unlink(fullPath);
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        message: error instanceof Error ? error.message : 'Unknown error' 
      };
    }
  }

  async exists(identifier: string): Promise<boolean> {
    const fullPath = this.getFullPath(identifier);
    try {
      await fs.access(fullPath);
      return true;
    } catch {
      return false;
    }
  }

  async getSignedUrl(identifier: string, expiresIn: number = 1800): Promise<string> {
    const expiry = Date.now() + expiresIn * 1000;
    const data = `${identifier}:${expiry}`;
    const signature = crypto
      .createHmac('sha256', this.secret)
      .update(data)
      .digest('hex');

    return `${this.baseUrl}/api/v1/files/private/${identifier}?expires=${expiry}&signature=${signature}`;
  }

  getPublicUrl(identifier: string): string {
    return `${this.baseUrl}/api/v1/files/public/${identifier}`;
  }

  async getMetadata(identifier: string): Promise<FileMetadata> {
    const fullPath = this.getFullPath(identifier);
    const stats = await fs.stat(fullPath);
    
    return {
      id: this.generateId(),
      key: path.basename(identifier),
      path: identifier,
      originalName: path.basename(identifier),
      mimeType: 'application/octet-stream',
      size: stats.size,
      isPublic: false,
      metadata: {},
      createdAt: stats.birthtime,
      updatedAt: stats.mtime,
    };
  }

  async updateMetadata(identifier: string, metadata: Partial<FileMetadata>): Promise<FileMetadata> {
    const current = await this.getMetadata(identifier);
    return {
      ...current,
      ...metadata,
      updatedAt: new Date(),
    };
  }

  async copy(source: string, destination: string): Promise<CopyResult> {
    const sourcePath = this.getFullPath(source);
    const destPath = this.getFullPath(destination);

    await this.ensureDirectory(path.dirname(destPath));
    await fs.copyFile(sourcePath, destPath);

    return {
      success: true,
      newId: this.generateId(),
      newKey: path.basename(destination),
    };
  }

  async move(source: string, destination: string): Promise<MoveResult> {
    const sourcePath = this.getFullPath(source);
    const destPath = this.getFullPath(destination);

    await this.ensureDirectory(path.dirname(destPath));
    await fs.rename(sourcePath, destPath);

    return {
      success: true,
      newId: this.generateId(),
      newKey: path.basename(destination),
    };
  }
}

