import { eventEmitter } from '../event-emitter';
import { logger } from '../../utils/logger';

import { notificationQueue } from '../../../infrastructure/queues/notification/notification.queue';

export interface NotificationEvent {
  userId: string;
  title: string;
  body: string;
  type: string;
  data?: Record<string, string>;
}

export const registerNotificationListener = (): void => {
  eventEmitter.on(
    'notification',
    async (event: NotificationEvent) => {
      try {

        await notificationQueue.enqueue(event);

        logger.info('[Notification Queue] Notification queued.', {
          userId: event.userId,
          title: event.title,
        });
      } catch (error) {
        logger.error(
          '[Notification Queue] Failed to enqueue notification.',
          {
            error,
            userId: event.userId,
          }
        );
      }
    }
  );

  logger.info('Notification listener registered.');
};

