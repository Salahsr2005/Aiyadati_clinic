import { eventEmitter } from '../event-emitter';
import { sendEmail } from '../../utils/email';
import { logger } from '../../utils/logger';

export const registerOtpEmailListener = (): void => {
  eventEmitter.on('send-otp-email', async (event: { email: string; name: string; otp: string }) => {
    try {
      const sent = await sendEmail({
        to: event.email,
        subject: 'Iyadati - Email Verification Code',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #6B21A8;">Welcome to Iyadati, ${event.name}!</h1>
            <p>Thank you for registering. Your verification code is:</p>
            <div style="background: #F3E8FF; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;">
              <span style="font-size: 32px; font-weight: bold; color: #6B21A8; letter-spacing: 8px;">${event.otp}</span>
            </div>
            <p style="color: #6B7280;">This code expires in 10 minutes.</p>
            <p style="color: #6B7280;">If you didn't create this account, please ignore this email.</p>
          </div>
        `,
      });

      if (sent) {
        logger.info(`OTP email sent to ${event.email}`);
      } else {
        logger.error(`Failed to send OTP email to ${event.email}`);
      }
    } catch (error) {
      logger.error('Failed to send OTP email', { error, email: event.email });
    }
  });

  logger.info('OTP email listener registered');
};

