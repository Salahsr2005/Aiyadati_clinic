import { prisma } from '../../utils/prisma';
import { logger } from '../../utils/logger';
import { eventEmitter } from '../event-emitter';

export interface AuditEvent {
  action: string;
  entity: string;
  entityId: string;
  performedBy: string;
  details?: Record<string, any>;
  ip?: string;
}

export const registerAuditListener = (): void => {
  eventEmitter.on('audit', async (event: AuditEvent) => {
    try {
      // Fire and forget - don't await in the event handler
      prisma.auditLog.create({
        data: {
          action: event.action,
          entity: event.entity,
          entityId: event.entityId,
          performedBy: event.performedBy,
          details: event.details || {},
          ip: event.ip || null,
        },
      }).catch(error => {
        logger.error('Failed to create audit log', { error, event });
      });
    } catch (error) {
      logger.error('Audit listener error', { error });
    }
  });

  logger.info('Audit listener registered');
};

