import { eventEmitter } from '../event-emitter';
import { logger } from '../../utils/logger';
import { emailQueue } from '../../../infrastructure/queues/email/email.queue';

export const registerOtpEmailListener = (): void => {
  eventEmitter.on(
    'send-otp-email',
    async (event: { email: string; name: string; otp: string }) => {
      try {
        await emailQueue.enqueueOtp(event);

        logger.info('[Email Queue] OTP email queued.', {
          email: event.email,
        });
      } catch (error) {
        logger.error('Failed to enqueue OTP email.', {
          error,
          email: event.email,
        });
      }
    }
  );

  logger.info('OTP email listener registered.');
};



