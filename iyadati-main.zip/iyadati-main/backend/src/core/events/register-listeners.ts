import { registerAuditListener } from './listeners/audit.listener';
import { registerOtpEmailListener } from './listeners/otp-email.listener';
import { registerNotificationListener } from './listeners/notification.listener';

export const registerAllListeners = (): void => {
  registerAuditListener();
  registerOtpEmailListener();
  registerNotificationListener();
  console.log('All event listeners registered');
};

