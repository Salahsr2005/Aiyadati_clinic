import { Router } from 'express';
import { handleChargilyWebhook } from './chargily.webhook';

const router = Router();

// Chargily webhook - public, secured by signature verification
router.post('/chargily', handleChargilyWebhook);

export default router;

