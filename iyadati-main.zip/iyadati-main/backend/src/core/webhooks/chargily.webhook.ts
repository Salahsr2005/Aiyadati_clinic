import { Request, Response } from 'express';
import { verifySignature } from '@chargily/chargily-pay';
import { env } from '../../config/env';
import { paymentRepository } from '../../repositories/payment.repository';
import { logger } from '../utils/logger';
import { prisma } from '../utils/prisma';

export const handleChargilyWebhook = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const signature = req.get("signature") || "";
    const payload = req.body;

    if (!signature) {
      logger.warn("Webhook: Missing signature header");
      res.status(400).json({
        success: false,
        message: "Missing signature",
      });
      return;
    }

    if (!payload || !Buffer.isBuffer(payload)) {
      logger.warn("Webhook: No raw body received");
      res.status(400).json({
        success: false,
        message: "No payload",
      });
      return;
    }

    const isValid = verifySignature(
      payload,
      signature,
      env.CHARGILY_SECRET_KEY
    );

    if (!isValid) {
      logger.warn("Webhook: Invalid signature");
      res.status(403).json({
        success: false,
        message: "Invalid signature",
      });
      return;
    }

    const event = JSON.parse(payload.toString());

    logger.info(`Webhook received: ${event.type}`);

    // =====================================================
    // PAYMENT SUCCESS
    // =====================================================

    if (event.type === "checkout.paid") {
      const checkoutData = event.data;
      const paymentId = checkoutData.metadata?.paymentId;

      if (!paymentId) {
        logger.warn("Webhook: No paymentId in metadata");
        res.status(400).json({
          success: false,
          message: "No paymentId in metadata",
        });
        return;
      }

      await prisma.$transaction(async (tx) => {

        // -----------------------------------------------
        // Lock payment row (Idempotency)
        // -----------------------------------------------

        await tx.$queryRaw`
          SELECT id
          FROM "payments"
          WHERE id = ${paymentId}
          FOR UPDATE
        `;

        const payment = await tx.payment.findUnique({
          where: {
            id: paymentId,
          },
        });

        if (!payment) {
          throw new Error(`Payment not found: ${paymentId}`);
        }

        // Already processed?
        if (payment.status === "PAID") {
          return;
        }

        // -----------------------------------------------
        // Mark payment as paid
        // -----------------------------------------------

        await tx.payment.update({
          where: {
            id: payment.id,
          },
          data: {
            status: "PAID",
            metadata: event,
            completedAt: new Date(),
          },
        });

        // -----------------------------------------------
        // Add credits
        // -----------------------------------------------

        const wallet = await tx.userWallet.upsert({
          where: {
            userId: payment.userId,
          },
          create: {
            userId: payment.userId,
            credits: payment.credits,
          },
          update: {
            credits: {
              increment: payment.credits,
            },
          },
        });

        // -----------------------------------------------
        // Credit transaction
        // -----------------------------------------------

        await tx.creditTransaction.create({
          data: {
            walletId: wallet.id,
            amount: payment.credits,
            type: "purchase",
            description: `Purchased ${payment.credits} credits (${payment.amount} DZD)`,
            referenceId: payment.id,
          },
        });

        logger.info(
          `Payment confirmed: ${payment.id}, credits: ${payment.credits}`
        );
      });
    }

    // =====================================================
    // PAYMENT FAILED
    // =====================================================

    if (event.type === "checkout.failed") {
      const paymentId = event.data?.metadata?.paymentId;

      if (paymentId) {
        await paymentRepository.markAsFailed(paymentId, event);
        logger.info(`Payment failed: ${paymentId}`);
      }
    }

    res.status(200).json({
      success: true,
    });

  } catch (error) {
    logger.error("Webhook error:", error);

    res.status(200).json({
      success: false,
      message: "Webhook processing error",
    });
  }
};

