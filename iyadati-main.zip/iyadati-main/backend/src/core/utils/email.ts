// import nodemailer from 'nodemailer';
// import dns from 'dns';
// import { logger } from './logger';
// import { env } from '../../config/env';

// // Force IPv4 - fixes IPv6 connection issues
// dns.setDefaultResultOrder('ipv4first');

// const transporter = nodemailer.createTransport({
//   host: env.MAILTRAP_HOST,
//   port: env.MAILTRAP_PORT,
//   secure: false,
//   auth: {
//     user: env.MAILTRAP_USER,
//     pass: env.MAILTRAP_PASS,
//   },
// });

// interface EmailOptions {
//   to: string;
//   subject: string;
//   html: string;
//   from?: string;
// }

// export const sendEmail = async (options: EmailOptions): Promise<boolean> => {
//   try {
//     const info = await transporter.sendMail({
//       from: options.from || env.MAIL_FROM || 'noreply@iyadati.com',
//       to: options.to,
//       subject: options.subject,
//       html: options.html,
//     });

//     logger.info(`Email sent: ${info.messageId}`);
//     return true;
//   } catch (error) {
//     logger.error('Failed to send email', { error, to: options.to });
//     return false;
//   }
// };

import nodemailer from 'nodemailer';
import dns from 'dns';
import { logger } from './logger';
import { env } from '../../config/env';

// Force IPv4 for Render compatibility
dns.setDefaultResultOrder('ipv4first');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: env.MAILTRAP_USER,
    pass: env.MAILTRAP_PASS,
  },
});

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  from?: string;
}

export const sendEmail = async (options: EmailOptions): Promise<boolean> => {
  try {
    const info = await transporter.sendMail({
      from: options.from || env.MAIL_FROM || 'noreply@iyadati.com',
      to: options.to,
      subject: options.subject,
      html: options.html,
    });

    logger.info(`Email sent: ${info.messageId}`);
    return true;
  } catch (error) {
    logger.error('Failed to send email', { error, to: options.to });
    return false;
  }
};


