import winston from 'winston';
import path from 'path';
import { env } from '../../config/env';



// Simple console format for development
const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    const metaStr = Object.keys(meta).length ? `\n  ${JSON.stringify(meta, null, 2)}` : '';
    return `${timestamp} [${level}]: ${message}${metaStr}`;
  })
);

// Create the logger
export const logger = winston.createLogger({
  level: env.isDevelopment ? 'debug' : 'info',
  transports: [
    new winston.transports.Console({
      format: consoleFormat,
    })
  ],
});

