/**
 * Iyadati operates in Algeria timezone (UTC+1)
 * All dates should be stored in UTC but displayed in Algeria time
 */

/**
 * Get the current time in Algeria timezone
 */
export function nowAlgeria(): Date {
  const now = new Date();
  // Algeria is UTC+1 (no DST)
  return new Date(now.getTime() + 60 * 60 * 1000);
}

/**
 * Convert a UTC date to Algeria timezone
 */
export function toAlgeriaTime(date: Date): Date {
  return new Date(date.getTime() + 60 * 60 * 1000);
}

/**
 * Check if a slot has passed in Algeria timezone
 */
export function isSlotInPastAlgeria(
  slotDate: Date,
  startTime: Date,
  now = nowAlgeria()
): boolean {
  const slotStart = new Date(slotDate);
  slotStart.setHours(
    startTime.getHours(),
    startTime.getMinutes(),
    0,
    0
  );
  return slotStart <= now;
}

/**
 * Get slot start time as a proper Date object
 */
export function getSlotStartDateTimeAlgeria(
  slotDate: Date,
  startTime: Date
): Date {
  const result = new Date(slotDate);
  result.setHours(
    startTime.getHours(),
    startTime.getMinutes(),
    0,
    0
  );
  return result;
}

