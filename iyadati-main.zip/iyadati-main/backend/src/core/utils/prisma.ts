import { PrismaClient } from '@prisma/client';
import { env } from '../../config/env';

const prisma = new PrismaClient({
  log: env.isDevelopment ? ['query', 'info', 'warn', 'error'] : ['error'],
});

export { prisma };
