// src/core/utils/signed-url.ts
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import { env } from '../../config/env';
import { logger } from './logger';

const SECRET = env.FILE_SECRET || 'default-secret-change-me';
const UPLOAD_DIR = path.join(__dirname, '../../../', env.UPLOAD_DIR || 'uploads');
const BASE_URL = env.BASE_URL || 'http://localhost:3975';
const DEFAULT_EXPIRY = 30 * 60; // 30 minutes in seconds

// ============================================================
// CORE FUNCTIONS
// ============================================================

/**
 * Generate a signed URL for private file access
 * Uses fileId (UUID) instead of file path for security
 * 
 * @param fileId - The UUID of the file
 * @param expiresIn - Expiry time in seconds (default: 30 minutes)
 * @returns Signed URL with fileId only (no path info)
 * 
 * Example: /api/v1/files/private/550e8400-e29b-41d4-a716-446655440000?expires=123456&signature=abc
 */
export const generateSignedUrl = (fileId: string, expiresIn: number = DEFAULT_EXPIRY): string => {
  const expires = Date.now() + expiresIn * 1000;
  
  // Sign using fileId + expiry (no path info!)
  const data = `${fileId}:${expires}`;
  const signature = crypto
    .createHmac('sha256', SECRET)
    .update(data)
    .digest('hex');

  return `${BASE_URL}/api/v1/files/private/${fileId}?expires=${expires}&signature=${signature}`;
};

/**
 * Generate a public file URL (no signature needed)
 * 
 * @param fileId - The UUID of the file
 * @returns Public URL
 * 
 * Example: /api/v1/files/public/550e8400-e29b-41d4-a716-446655440000
 */
export const generatePublicUrl = (fileId: string): string => {
  return `${BASE_URL}/api/v1/files/public/${fileId}`;
};

/**
 * Verify a signed URL
 * 
 * @param fileId - The UUID of the file
 * @param expires - Expiry timestamp from URL
 * @param signature - Signature from URL
 * @returns true if valid, false otherwise
 */
export const verifySignedUrl = (fileId: string, expires: string, signature: string): boolean => {
  // Check if expired
  const expiryTimestamp = Number(expires);
  if (isNaN(expiryTimestamp) || Date.now() > expiryTimestamp) {
    logger.warn(`Signed URL expired for file: ${fileId}`);
    return false;
  }

  // Recreate signature and compare (constant time)
  const data = `${fileId}:${expires}`;
  const expected = crypto
    .createHmac('sha256', SECRET)
    .update(data)
    .digest('hex');

  // Use timing-safe comparison to prevent timing attacks
  try {
    return crypto.timingSafeEqual(
      Buffer.from(expected),
      Buffer.from(signature)
    );
  } catch {
    return false;
  }
};

/**
 * Get file path on disk using storageKey
 * 
 * @param storageKey - The actual filename on disk (UUID + extension)
 * @returns Full file path
 * 
 * Note: This searches all possible directories
 */
export const getFilePath = (storageKey: string): string => {
  const locations = [
    // Public directories
    path.join(UPLOAD_DIR, 'public', 'logos', storageKey),
    path.join(UPLOAD_DIR, 'public', 'gallery', storageKey),
    path.join(UPLOAD_DIR, 'public', 'service-images', storageKey),
    
    // Private directories
    path.join(UPLOAD_DIR, 'private', 'doctor-documents', storageKey),
    path.join(UPLOAD_DIR, 'private', 'user-documents', storageKey),
    path.join(UPLOAD_DIR, 'private', 'clinic-documents', storageKey),
    
    // Fallback for old files (backward compatibility)
    path.join(UPLOAD_DIR, 'doctor-documents', storageKey),
    path.join(UPLOAD_DIR, 'user-documents', storageKey),
    path.join(UPLOAD_DIR, 'clinics', 'services-images', storageKey),
    path.join(UPLOAD_DIR, storageKey),

    path.join(UPLOAD_DIR, 'public', 'products', storageKey),
    path.join(UPLOAD_DIR, 'private', 'ecommerce-documents', storageKey),

  ];

  for (const location of locations) {
    if (fs.existsSync(location)) {
      return location;
    }
  }

  // Return the first location as fallback (will fail if not found)
  logger.warn(`File not found: ${storageKey}`);
  return path.join(UPLOAD_DIR, storageKey);
};

/**
 * Check if file exists on disk using storageKey
 * 
 * @param storageKey - The actual filename on disk
 * @returns true if file exists
 */
export const fileExists = (storageKey: string): boolean => {
  const locations = [
    // Public directories
    path.join(UPLOAD_DIR, 'public', 'logos', storageKey),
    path.join(UPLOAD_DIR, 'public', 'gallery', storageKey),
    path.join(UPLOAD_DIR, 'public', 'service-images', storageKey),
    
    // Private directories
    path.join(UPLOAD_DIR, 'private', 'doctor-documents', storageKey),
    path.join(UPLOAD_DIR, 'private', 'user-documents', storageKey),
    path.join(UPLOAD_DIR, 'private', 'clinic-documents', storageKey),
    
    // Fallback for old files
    path.join(UPLOAD_DIR, 'doctor-documents', storageKey),
    path.join(UPLOAD_DIR, 'user-documents', storageKey),
    path.join(UPLOAD_DIR, 'clinics', 'services-images', storageKey),
    path.join(UPLOAD_DIR, storageKey),

    path.join(UPLOAD_DIR, 'public', 'products', storageKey),
    path.join(UPLOAD_DIR, 'private', 'ecommerce-documents', storageKey),

  ];

  return locations.some(loc => fs.existsSync(loc));
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Validate fileId format (UUID v4)
 */
export const isValidFileId = (fileId: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(fileId);
};

/**
 * Check if a private file URL is expired
 */
export const isUrlExpired = (expires: string): boolean => {
  const expiryTimestamp = Number(expires);
  if (isNaN(expiryTimestamp)) return true;
  return Date.now() > expiryTimestamp;
};

/**
 * Get expiry time from signed URL
 */
export const getExpiryFromUrl = (expires: string): number => {
  return Number(expires);
};

/**
 * Generate multiple signed URLs for batch operations
 */
export const generateSignedUrls = (
  fileIds: string[],
  expiresIn: number = DEFAULT_EXPIRY
): Record<string, string> => {
  const result: Record<string, string> = {};
  for (const fileId of fileIds) {
    result[fileId] = generateSignedUrl(fileId, expiresIn);
  }
  return result;
};

/**
 * Extract fileId from a signed URL
 */
export const extractFileIdFromUrl = (url: string): string | null => {
  const match = url.match(/\/files\/private\/([^?]+)/);
  return match ? match[1] : null;
};

/**
 * Extract fileId from a public URL
 */
export const extractFileIdFromPublicUrl = (url: string): string | null => {
  const match = url.match(/\/files\/public\/([^?]+)/);
  return match ? match[1] : null;
};

// ============================================================
// BACKWARD COMPATIBILITY (DEPRECATED - REMOVE LATER)
// ============================================================

/**
 * @deprecated Use generateSignedUrl with fileId instead
 * Old function kept for backward compatibility during migration
 */
export const generateSignedUrlLegacy = (fileName: string): string => {
  const expires = Date.now() + 3 * 60 * 1000;
  const data = `${fileName}:${expires}`;
  const signature = crypto
    .createHmac('sha256', SECRET)
    .update(data)
    .digest('hex');

  return `${BASE_URL}/api/v1/files/${fileName}?expires=${expires}&signature=${signature}`;
};

/**
 * @deprecated Use verifySignedUrl with fileId instead
 */
export const verifySignedUrlLegacy = (fileName: string, expires: string, signature: string): boolean => {
  if (Date.now() > Number(expires)) return false;

  const data = `${fileName}:${expires}`;
  const expected = crypto
    .createHmac('sha256', SECRET)
    .update(data)
    .digest('hex');

  return expected === signature;
};

