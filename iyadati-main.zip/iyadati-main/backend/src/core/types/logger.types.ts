export interface LogMeta {
  requestId?: string;
  userId?: string;
  ip?: string;
  userAgent?: string;
  duration?: number;
  [key: string]: any;
}

export interface HttpLogMeta extends LogMeta {
  method: string;
  url: string;
  statusCode: number;
  responseTime: number;
}

export interface DatabaseLogMeta extends LogMeta {
  model: string;
  operation: string;
  duration: number;
}

export interface ErrorLogMeta extends LogMeta {
  error: Error;
  stack?: string;
}

