import { redis } from './client';

import { RedisService } from './redis.service';

export { redis } from './client';
export { redisConfig } from './config';
export type { IRedisService } from './redis.types';
export { RedisService } from './redis.service';

export const redisService = new RedisService(redis);

