maxRetriesPerRequest: null

BullMQ recommends this setting.

Without it, ioredis may throw errors if Redis is temporarily unavailable. BullMQ expects to manage retries itself.

enableReadyCheck: true

The client waits until Redis is actually ready before marking the connection usable.

lazyConnect: false

Connect immediately when the application starts.

I prefer failing fast. If Redis is unavailable, I'd rather know during startup than discover it later when the first job is added.

One thing we're intentionally not adding

You may see tutorials with:

retryStrategy(times) {
    ...
}

I'm intentionally leaving that out.

ioredis already has a sensible retry strategy, and unless you have specific operational requirements (backoff tuning, maximum retry duration, etc.), the default behavior is perfectly acceptable. We can revisit it if your deployment environment demands it.


Why did I add SIGINT and SIGTERM?

This is a production practice.

When Docker stops a container:

docker compose down

it sends a signal:

SIGTERM

Instead of killing Redis immediately, we politely tell the client:

await redis.quit();

This:

closes the connection cleanly
flushes pending commands
avoids hanging sockets
prevents warning messages during shutdown

It's called graceful shutdown, and you'll see this pattern in databases, queues, HTTP servers, and message brokers.

