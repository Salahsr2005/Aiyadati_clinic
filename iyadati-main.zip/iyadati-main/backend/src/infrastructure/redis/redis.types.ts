export interface IRedisService {
  get<T>(key: string): Promise<T | null>;

  getString(key: string): Promise<string | null>;

  set<T>(
    key: string,
    value: T,
    ttlSeconds?: number,
  ): Promise<void>;

  setString(
    key: string,
    value: string,
    ttlSeconds?: number,
  ): Promise<void>;

  delete(key: string): Promise<void>;

  increment(key: string): Promise<number>;

  remember<T>(
    key: string,
    ttlSeconds: number,
    loader: () => Promise<T>,
  ): Promise<T>;
}


