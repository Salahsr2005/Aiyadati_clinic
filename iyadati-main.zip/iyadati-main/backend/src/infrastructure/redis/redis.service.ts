import type { Redis } from 'ioredis';

import { logger } from '../../core/utils/logger';

import type { IRedisService } from './redis.types';

export class RedisService implements IRedisService {
  constructor(private readonly redis: Redis) {}

  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await this.redis.get(key);

      if (value === null) {
        return null;
      }

      return JSON.parse(value) as T;
    } catch (error) {
      logger.warn('[Redis] Failed to retrieve cache.', {
        key,
        error,
      });

      return null;
    }
  }

  async set<T>(
    key: string,
    value: T,
    ttlSeconds?: number,
  ): Promise<void> {
    try {
      const serialized = JSON.stringify(value);

      if (ttlSeconds !== undefined) {
        await this.redis.set(key, serialized, 'EX', ttlSeconds);
      } else {
        await this.redis.set(key, serialized);
      }
    } catch (error) {
      logger.warn('[Redis] Failed to store cache.', {
        key,
        error,
      });
    }
  }

  async delete(key: string): Promise<void> {
    try {
      await this.redis.del(key);
    } catch (error) {
      logger.warn('[Redis] Failed to delete cache.', {
        key,
        error,
      });
    }
  }

async remember<T>(
  key: string,
  ttlSeconds: number,
  loader: () => Promise<T>,
): Promise<T> {
  const cached = await this.get<T>(key);

  if (cached !== null) {
    return cached;
  }

  const value = await loader();

  await this.set(key, value, ttlSeconds);

  return value;
}

    async getString(
    key: string,
    ): Promise<string | null> {
    try {
        return await this.redis.get(key);
    } catch (error) {
        logger.warn('[Redis] Failed to retrieve string.', {
        key,
        error,
        });

        return null;
    }
    }

    async setString(
    key: string,
    value: string,
    ttlSeconds?: number,
    ): Promise<void> {
    try {
        if (ttlSeconds !== undefined) {
        await this.redis.set(
            key,
            value,
            'EX',
            ttlSeconds,
        );
        } else {
        await this.redis.set(key, value);
        }
    } catch (error) {
        logger.warn('[Redis] Failed to store string.', {
        key,
        error,
        });
    }
    }

    async increment(
    key: string,
    ): Promise<number> {
    try {
        return await this.redis.incr(key);
    } catch (error) {
        logger.warn('[Redis] Failed to increment key.', {
        key,
        error,
        });

        throw error;
    }
    }
}

