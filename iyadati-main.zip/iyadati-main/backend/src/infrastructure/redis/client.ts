import Redis from 'ioredis';

import { logger } from '../../core/utils/logger';

import { redisConfig } from './config';

export const redis = new Redis({
  ...redisConfig,

  enableReadyCheck: true,
  lazyConnect: false,
});

redis.on('connect', () => {
  logger.info('[Redis] Connecting...');
});

redis.on('ready', () => {
  logger.info('[Redis] Connection established.');
});

redis.on('error', (error) => {
  logger.error('[Redis] Connection error.', { error });
});

redis.on('close', () => {
  logger.warn('[Redis] Connection closed.');
});

redis.on('reconnecting', () => {
  logger.warn('[Redis] Reconnecting...');
});

redis.on('end', () => {
  logger.warn('[Redis] Connection ended.');
});

export const closeRedis = async (): Promise<void> => {
  logger.info('[Redis] Closing connection...');
  await redis.quit();
};

process.on('SIGINT', closeRedis);
process.on('SIGTERM', closeRedis);
