console.log('>>> email.worker.ts loaded');
import { Job, Worker } from 'bullmq';

import { bullMqConnection } from '../connection';
import { logger } from '../../../core/utils/logger';
import { sendEmail } from '../../../core/utils/email';

import { EmailJobName } from './email.jobs';
import { SendOtpEmailPayload } from './email.types';
import { generateOtpEmail } from './templates/otp.template';

class EmailWorkerService {
  private readonly worker: Worker;

  constructor() {

    console.log('>>> EmailWorkerService constructor');

    this.worker = new Worker(
      'email',
      this.process.bind(this),
      {
        connection: bullMqConnection,
      }
    );

    this.registerEvents();
  }

  private async process(job: Job): Promise<void> {
    switch (job.name) {
      case EmailJobName.SEND_OTP:
        await this.processOtp(job as Job<SendOtpEmailPayload>);
        break;

      default:
        throw new Error(`Unknown email job: ${job.name}`);
    }
  }

  private async processOtp(
    job: Job<SendOtpEmailPayload>
  ): Promise<void> {
    const payload = job.data;

    const template = generateOtpEmail(payload);

    const sent = await sendEmail({
      to: payload.email,
      subject: template.subject,
      html: template.html,
    });

    if (!sent) {
      throw new Error(`Failed to send OTP email to ${payload.email}`);
    }

    logger.info('[Email Worker] OTP email sent.', {
      jobId: job.id,
      jobName: job.name,
      email: payload.email,
    });
  }

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Email Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Email Worker] Job completed.', {
        jobId: job.id,
        jobName: job.name,
      });
    });

    this.worker.on('failed', (job, error) => {
    logger.error('[Email Worker] Job failed.', {
        jobId: job?.id,
        jobName: job?.name,
        message: error.message,
        stack: error.stack,
        attemptsMade: job?.attemptsMade,
    });
    });

    this.worker.on('error', (error) => {
      logger.error('[Email Worker] Worker error.', { error });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const emailWorker = new EmailWorkerService();

