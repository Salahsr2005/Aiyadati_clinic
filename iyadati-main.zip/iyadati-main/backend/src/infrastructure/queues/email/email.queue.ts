import { JobsOptions, Queue } from 'bullmq';

import { bullMqConnection } from '../connection';
import { EmailJobName } from './email.jobs';
import { SendOtpEmailPayload } from './email.types';

class EmailQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('email', {
      connection: bullMqConnection,
    });
  }

  public async enqueueOtp(payload: SendOtpEmailPayload): Promise<void> {
    await this.enqueue(EmailJobName.SEND_OTP, payload);
  }

    private async enqueue(
    jobName: EmailJobName,
    payload: unknown,
    options?: JobsOptions,
    ): Promise<void> {
    console.log("ADDING JOB");

    const job = await this.queue.add(jobName, payload, {
        attempts: 5,
        backoff: {
        type: "exponential",
        delay: 5000,
        },
        removeOnComplete: 1000,
        removeOnFail: 5000,
        ...options,
    });

    console.log("JOB ID:", job.id);
    }

  public getQueue() {
    return this.queue;
  }

  public async close(): Promise<void> {
    await this.queue.close();
  }
}

export const emailQueue = new EmailQueueService();


