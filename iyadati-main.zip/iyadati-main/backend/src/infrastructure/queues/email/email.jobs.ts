


export enum EmailJobName {
  SEND_OTP = 'send-otp',

  // Future matnsach tzidhom
  SEND_WELCOME = 'send-welcome',
  RESET_PASSWORD = 'reset-password',
  APPOINTMENT_REMINDER = 'appointment-reminder',
}

