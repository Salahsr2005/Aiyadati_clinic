import { SendOtpEmailPayload } from '../email.types';

export interface EmailTemplate {
  subject: string;
  html: string;
}

export const generateOtpEmail = (
  payload: SendOtpEmailPayload
): EmailTemplate => ({
  subject: 'Iyadati - Email Verification Code',

  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #6B21A8;">Welcome to Iyadati, ${payload.name}!</h1>

      <p>Thank you for registering. Your verification code is:</p>

      <div style="
        background:#F3E8FF;
        padding:20px;
        border-radius:8px;
        text-align:center;
        margin:20px 0;
      ">
        <span style="
          font-size:32px;
          font-weight:bold;
          color:#6B21A8;
          letter-spacing:8px;
        ">
          ${payload.otp}
        </span>
      </div>

      <p style="color:#6B7280;">
        This code expires in 10 minutes.
      </p>

      <p style="color:#6B7280;">
        If you didn't create this account, please ignore this email.
      </p>
    </div>
  `,
});

