

export interface SendOtpEmailPayload {
  email: string;
  name: string;
  otp: string;
}

