import { Job, Worker } from 'bullmq';
import { bullMqConnection } from '../connection';
import { logger } from '../../../core/utils/logger';
import { appointmentService } from '../../../modules/appointment/v1/appointment.service';
import { slotRepository } from '../../../repositories/slot.repository';
import { prisma } from '../../../core/utils/prisma';
import { nowAlgeria } from '../../../core/utils/timezone';
import { SlotGenerationJobName, GenerateSlotsPayload } from './slot-generation.queue';

class SlotGenerationWorkerService {
  private readonly worker: Worker;
  // Track which rules are currently being processed (prevent duplicate processing)
  private processingRules = new Set<string>();

  constructor() {
    this.worker = new Worker(
      'slot-generation',
      this.process.bind(this),
      {
        connection: bullMqConnection,
        concurrency: 5,
      }
    );

    this.registerEvents();
    this.startScheduler();
  }

  private async startScheduler() {
    // Check for due rules every hour
    const { slotGenerationQueue } = await import('./slot-generation.queue');
    
    await slotGenerationQueue.enqueueCheckRules();
    
    // Also add a recurring job
    await slotGenerationQueue.getQueue().add(
      'check-rules-recurring',
      {},
      {
        repeat: {
          pattern: '0 * * * *', // Every hour
        },
        jobId: 'check-rules-recurring',
      }
    );
  }

  private async process(job: Job): Promise<void> {
    switch (job.name) {
      case SlotGenerationJobName.GENERATE_SLOTS:
        await this.processGenerateSlots(job as Job<GenerateSlotsPayload>);
        break;

      case SlotGenerationJobName.CHECK_RULES:
        await this.processCheckRules();
        break;

      default:
        throw new Error(`Unknown slot generation job: ${job.name}`);
    }
  }

  private async processGenerateSlots(job: Job<GenerateSlotsPayload>): Promise<void> {
    const { ruleId, doctorId, bookingWindowDays, clinicId, roomId } = job.data;

    // ✅ FIXED: Prevent duplicate processing of the same rule
    const lockKey = `processing:${ruleId}`;
    if (this.processingRules.has(lockKey)) {
      logger.info(`Rule ${ruleId} is already being processed, skipping duplicate`);
      return;
    }

    try {
      this.processingRules.add(lockKey);

      logger.info(`Processing slot generation for doctor ${doctorId}, rule ${ruleId}`);

      const result = await appointmentService.generateAutomationSlots(
        doctorId,
        bookingWindowDays,
        clinicId || undefined,
        roomId || undefined
      );

      // Update rule - success
      await this.updateRuleSuccess(ruleId);

      logger.info(`Slot generation completed for doctor ${doctorId}: ${result.created} created, ${result.existing} existing`);

    } catch (error: any) {
      logger.error(`Failed to generate slots for doctor ${doctorId}: ${error.message}`);
      await this.updateRuleError(ruleId, error.message);
      throw error;
    } finally {
      this.processingRules.delete(lockKey);
    }
  }

  private async processCheckRules(): Promise<void> {
    const now = nowAlgeria();

    const rules = await prisma.slotGenerationRule.findMany({
      where: {
        enabled: true,
        nextRunAt: { lte: now },
      },
    });

    logger.info(`Found ${rules.length} due slot generation rules`);

    for (const rule of rules) {
      const { slotGenerationQueue } = await import('./slot-generation.queue');
      
      // ✅ FIXED: Use unique job ID to prevent duplicate processing
      const jobId = `generate-${rule.id}-${now.getTime()}`;
      
      await slotGenerationQueue.enqueueGenerateSlots({
        ruleId: rule.id,
        doctorId: rule.doctorId,
        bookingWindowDays: rule.bookingWindowDays,
        clinicId: rule.clinicId || undefined,
        roomId: rule.roomId || undefined,
        frequency: rule.frequency,
      }, {
        jobId, // ← Prevents duplicate jobs for the same rule at the same time
      });
    }
  }

  private async updateRuleSuccess(ruleId: string): Promise<void> {
    const rule = await prisma.slotGenerationRule.findUnique({
      where: { id: ruleId },
    });

    if (!rule) return;

    // ✅ FIXED: Use consistent timezone
    const now = nowAlgeria();
    const nextRunAt = this.calculateNextRun(rule.frequency, now);

    await prisma.slotGenerationRule.update({
      where: { id: ruleId },
      data: {
        lastRunAt: new Date(now),
        nextRunAt,
        errorCount: 0,
        lastError: null,
      },
    });
  }

  private async updateRuleError(ruleId: string, error: string): Promise<void> {
    const rule = await prisma.slotGenerationRule.findUnique({
      where: { id: ruleId },
    });

    if (!rule) return;

    const newErrorCount = rule.errorCount + 1;
    
    // ✅ FIXED: Only disable after 3 CONSECUTIVE scheduled runs failed
    // The errorCount resets on success, so this is "consecutive failures"
    const shouldDisable = newErrorCount >= 3;

    await prisma.slotGenerationRule.update({
      where: { id: ruleId },
      data: {
        errorCount: newErrorCount,
        lastError: error,
        enabled: shouldDisable ? false : true,
      },
    });

    if (shouldDisable) {
      logger.warn(`Slot automation disabled for rule ${ruleId} after 3 consecutive failures`);
    }
  }

  // ✅ FIXED: Uses passed in 'now' for consistency
  private calculateNextRun(frequency: string, now: Date): Date {
    const next = new Date(now);
    switch (frequency) {
      case 'DAILY':
        next.setDate(next.getDate() + 1);
        next.setHours(0, 0, 0, 0);
        break;
      case 'WEEKLY':
        next.setDate(next.getDate() + 7);
        next.setHours(0, 0, 0, 0);
        break;
      case 'MONTHLY':
        next.setMonth(next.getMonth() + 1);
        next.setDate(1);
        next.setHours(0, 0, 0, 0);
        break;
    }
    return next;
  }

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Slot Generation Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Slot Generation Worker] Job completed.', {
        jobId: job.id,
        jobName: job.name,
      });
    });

    this.worker.on('failed', (job, error) => {
      logger.error('[Slot Generation Worker] Job failed.', {
        jobId: job?.id,
        jobName: job?.name,
        message: error.message,
        stack: error.stack,
        attemptsMade: job?.attemptsMade,
      });
    });

    this.worker.on('error', (error) => {
      logger.error('[Slot Generation Worker] Worker error.', { error });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const slotGenerationWorker = new SlotGenerationWorkerService();

