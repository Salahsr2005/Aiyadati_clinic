After that

Then we can improve it step by step:

Phase 2
EmailProcessor
Phase 3
Notification Queue
Phase 4
Audit Queue
Phase 5
Bull Board
Phase 6
Rate limiting
Priority jobs
Delayed jobs
Scheduled jobs
Dead-letter queue

