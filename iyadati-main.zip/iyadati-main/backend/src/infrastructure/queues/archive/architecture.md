enqueueOtp()
        │
        ▼
Create HTML
        │
        ▼
enqueue()
        │
        ▼
Redis
        │
        ▼
Worker
        │
        ▼
sendEmail()

