import IORedis from 'ioredis';

import { redisConfig } from '../redis';

export const bullMqConnection = new IORedis({
  ...redisConfig,

  maxRetriesPerRequest: null,
});

export const closeBullMqConnection = async (): Promise<void> => {
  await bullMqConnection.quit();
};

