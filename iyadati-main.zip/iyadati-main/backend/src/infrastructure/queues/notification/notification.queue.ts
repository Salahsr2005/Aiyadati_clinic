import { JobsOptions, Queue } from 'bullmq';

import { bullMqConnection } from '../connection';

import { NotificationJobName } from './notification.jobs';
import { SendNotificationPayload } from './notification.types';

class NotificationQueueService {
  private readonly queue: Queue;

  constructor() {
    this.queue = new Queue('notification', {
      connection: bullMqConnection,
    });
  }

  public async enqueue(
    payload: SendNotificationPayload,
    options?: JobsOptions
  ): Promise<void> {
    await this.queue.add(
      NotificationJobName.SEND_NOTIFICATION,
      payload,
      {
        attempts: 3,

        backoff: {
          type: 'exponential',
          delay: 2000,
        },

        removeOnComplete: 1000,
        removeOnFail: 5000,

        ...options,
      }
    );
  }

  public getQueue(): Queue {
    return this.queue;
  }

  public async close(): Promise<void> {
    await this.queue.close();
  }
}

export const notificationQueue = new NotificationQueueService();

