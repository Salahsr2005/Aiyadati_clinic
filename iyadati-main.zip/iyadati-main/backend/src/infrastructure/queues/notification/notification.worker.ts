import { Job, Worker } from 'bullmq';

import { bullMqConnection } from '../connection';

import { logger } from '../../../core/utils/logger';

import { notificationRepository } from '../../../repositories/notification.repository';
import { userDeviceRepository } from '../../../repositories/user-device.repository';

import { sendPushNotification } from '../../../config/firebase';

import { NotificationJobName } from './notification.jobs';
import { SendNotificationPayload } from './notification.types';

class NotificationWorkerService {
  private readonly worker: Worker;

  constructor() {
    this.worker = new Worker(
      'notification',
      this.process.bind(this),
      {
        connection: bullMqConnection,
      }
    );

    this.registerEvents();
  }

  private async process(job: Job): Promise<void> {
    switch (job.name) {
      case NotificationJobName.SEND_NOTIFICATION:
        await this.processNotification(
          job as Job<SendNotificationPayload>
        );
        break;

      default:
        throw new Error(`Unknown notification job: ${job.name}`);
    }
  }

  private async processNotification(
    job: Job<SendNotificationPayload>
  ): Promise<void> {
    const payload = job.data;

    // Save notification
    await notificationRepository.create({
      userId: payload.userId,
      title: payload.title,
      body: payload.body,
      type: payload.type,
      data: payload.data,
    });

    // Get active devices
    const devices = await userDeviceRepository.findByUserId(
      payload.userId
    );

    // Push notifications
    for (const device of devices) {
      const success = await sendPushNotification({
        deviceToken: device.deviceToken,
        title: payload.title,
        body: payload.body,
        data: payload.data,
      });

      if (!success) {
        await userDeviceRepository.deactivate(
          payload.userId,
          device.deviceToken
        );
      }
    }

    logger.info('[Notification Worker] Notification processed.', {
      jobId: job.id,
      userId: payload.userId,
      title: payload.title,
    });
  }

  private registerEvents(): void {
    this.worker.on('ready', () => {
      logger.info('[Notification Worker] Ready.');
    });

    this.worker.on('completed', (job) => {
      logger.info('[Notification Worker] Job completed.', {
        jobId: job.id,
        jobName: job.name,
      });
    });

    this.worker.on('failed', (job, error) => {
    logger.error('[Notification Worker] Job failed.', {
        jobId: job?.id,
        jobName: job?.name,
        message: error.message,
        stack: error.stack,
        attemptsMade: job?.attemptsMade,
    });
    });

    this.worker.on('error', (error) => {
      logger.error('[Notification Worker] Worker error.', {
        error,
      });
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

export const notificationWorker =
  new NotificationWorkerService();

