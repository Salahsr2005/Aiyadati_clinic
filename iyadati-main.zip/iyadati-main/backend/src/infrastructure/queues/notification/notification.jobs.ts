export enum NotificationJobName {
  SEND_NOTIFICATION = 'send-notification',
}