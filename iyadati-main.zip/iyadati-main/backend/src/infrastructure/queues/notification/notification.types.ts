export interface SendNotificationPayload {
  userId: string;
  title: string;
  body: string;
  type: string;
  data?: Record<string, string>;
}