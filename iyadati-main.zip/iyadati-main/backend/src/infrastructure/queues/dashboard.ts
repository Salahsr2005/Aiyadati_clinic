import { ExpressAdapter } from '@bull-board/express';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';

import { emailQueue } from './email/email.queue';
import { notificationQueue } from './notification/notification.queue';
import { slotGenerationQueue } from './slot-generation/slot-generation.queue';

const serverAdapter = new ExpressAdapter();

serverAdapter.setBasePath('/admin/queues');

createBullBoard({
  queues: [
    new BullMQAdapter(emailQueue.getQueue()),
    new BullMQAdapter(notificationQueue.getQueue()),
    new BullMQAdapter(slotGenerationQueue.getQueue()),
  ],
  serverAdapter,
});

export { serverAdapter };

