import dotenv from 'dotenv';

dotenv.config({
  path: process.env.NODE_ENV === 'test' ? '.env.test' : '.env',
});

export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: parseInt(process.env.PORT || '3975', 10),
  DATABASE_URL : process.env.DATABASE_URL! || '',
  DATABASE_URL_PGBOUNCER : process.env.DATABASE_URL_PGBOUNCER! || '',
  DIRECT_DATABASE_URL : process.env.DIRECT_DATABASE_URL! || '' ,

  // Mail
  MAILTRAP_HOST: process.env.MAILTRAP_HOST || '',
  MAILTRAP_PORT: parseInt(process.env.MAILTRAP_PORT || '2525', 10),
  MAILTRAP_USER: process.env.MAILTRAP_USER || '',
  MAILTRAP_PASS: process.env.MAILTRAP_PASS || '',
  MAIL_FROM: process.env.MAIL_FROM || 'noreply@iyadati.com',

  // Files
  UPLOAD_DIR: process.env.UPLOAD_DIR || 'uploads',
  FILE_SECRET: process.env.FILE_SECRET || 'default-secret',
  BASE_URL: process.env.BASE_URL || 'http://localhost:3975',

  MAILTRAP_TOKEN: process.env.MAILTRAP_TOKEN || '',

  CHARGILY_SECRET_KEY: process.env.CHARGILY_SECRET_KEY || '',
  CHARGILY_PUBLIC_KEY: process.env.CHARGILY_PUBLIC_KEY || '',
  CHARGILY_MODE: (process.env.CHARGILY_MODE as 'test' | 'live') || 'test',
  // CREDIT_PRICE: parseInt(process.env.CREDIT_PRICE || '500', 10),

  // Helpers
  isDevelopment: process.env.NODE_ENV !== 'production',
  isProduction: process.env.NODE_ENV === 'production',
  isTest: process.env.NODE_ENV === 'test',

  JWT_SECRET: process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production',

  FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID || '',
  FIREBASE_SERVICE_ACCOUNT: process.env.FIREBASE_SERVICE_ACCOUNT || '',


  // Storage configuration
  STORAGE_TYPE: process.env.STORAGE_TYPE || 'local',


  // Redis
  REDIS_HOST: process.env.REDIS_HOST || 'redis',
  REDIS_PORT: parseInt(process.env.REDIS_PORT || '6379', 10),
  REDIS_USERNAME: process.env.REDIS_USERNAME || '',
  REDIS_PASSWORD: process.env.REDIS_PASSWORD || '',

};

