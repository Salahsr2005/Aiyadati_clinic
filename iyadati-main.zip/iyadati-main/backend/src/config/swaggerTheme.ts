export const swaggerCustomCss = `
  /* ===== LAYOUT: SIDEBAR + MAIN ===== */
  #swagger-layout-wrapper {
    display: flex !important;
    align-items: flex-start !important;
    min-height: 100vh !important;
  }

  /* ─── SIDEBAR – LIGHT MODE (default) ─── */
  #swagger-sidebar {
    width: 240px !important;
    min-width: 240px !important;
    max-width: 240px !important;
    position: sticky !important;
    top: 0 !important;
    height: 100vh !important;
    overflow-y: auto !important;
    background: #FFFFFF !important;
    border-right: 1px solid #E5E7EB !important;
    padding: 0 !important;
    box-shadow: 2px 0 8px rgba(107, 33, 168, 0.06) !important;
    z-index: 100 !important;
    display: flex !important;
    flex-direction: column !important;
  }

  .sidebar-header {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    padding: 18px 16px 14px !important;
    font-size: 13px !important;
    font-weight: 700 !important;
    letter-spacing: 0.08em !important;
    text-transform: uppercase !important;
    color: #6B21A8 !important;
    border-bottom: 1px solid #EDE9FE !important;
    background: #FFFFFF !important;
  }

  .sidebar-header svg {
    color: #7C3AED !important;
    flex-shrink: 0 !important;
  }

  .sidebar-search-wrap {
    padding: 10px 12px !important;
    border-bottom: 1px solid #EDE9FE !important;
    background: #FFFFFF !important;
  }

  #sidebar-search {
    width: 100% !important;
    padding: 7px 10px !important;
    font-size: 13px !important;
    border: 1.5px solid #DDD6FE !important;
    border-radius: 6px !important;
    background: #F9FAFB !important;
    color: #111827 !important;
    outline: none !important;
    box-sizing: border-box !important;
    transition: border-color 0.15s !important;
  }

  #sidebar-search::placeholder {
    color: #9CA3AF !important;
  }

  #sidebar-search:focus {
    border-color: #7C3AED !important;
    background: #FFFFFF !important;
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.12) !important;
  }

  #sidebar-module-list {
    list-style: none !important;
    margin: 0 !important;
    padding: 8px 0 !important;
    flex: 1 !important;
    background: #FFFFFF !important;
  }

  .sidebar-module-item {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 9px 16px !important;
    cursor: pointer !important;
    border-radius: 0 !important;
    transition: background 0.12s, color 0.12s !important;
    border-left: 3px solid transparent !important;
  }

  .sidebar-module-item:hover {
    background: rgba(139, 92, 246, 0.07) !important;
    border-left-color: #C4B5FD !important;
  }

  .sidebar-module-item.active {
    background: rgba(124, 58, 237, 0.1) !important;
    border-left-color: #7C3AED !important;
  }

  .sidebar-module-name {
    font-size: 13.5px !important;
    font-weight: 500 !important;
    color: #111827 !important;
    line-height: 1.3 !important;
    word-break: break-word !important;
  }

  .sidebar-module-item:hover .sidebar-module-name {
    color: #6B21A8 !important;
  }

  .sidebar-module-item.active .sidebar-module-name {
    color: #6B21A8 !important;
    font-weight: 600 !important;
  }

  .sidebar-module-count {
    font-size: 11px !important;
    font-weight: 600 !important;
    background: #EDE9FE !important;
    color: #7C3AED !important;
    border-radius: 10px !important;
    padding: 1px 7px !important;
    min-width: 20px !important;
    text-align: center !important;
    flex-shrink: 0 !important;
    margin-left: 6px !important;
  }

  .sidebar-module-item.active .sidebar-module-count {
    background: #7C3AED !important;
    color: #fff !important;
  }

  /* Swagger UI main content fills remaining width */
  #swagger-layout-wrapper #swagger-ui {
    flex: 1 !important;
    min-width: 0 !important;
    overflow-x: auto !important;
  }

  /* ===== LIGHT MODE ===== */
  .swagger-ui .topbar {
    background-color: #6B21A8 !important;
  }
  
  .swagger-ui .topbar .download-url-wrapper .select-label {
    color: #F3E8FF !important;
  }
  
  .swagger-ui .topbar .download-url-wrapper input[type=text] {
    border: 2px solid #8B5CF6 !important;
  }
  
  .swagger-ui .topbar .download-url-wrapper .download-url-button {
    background: #7C3AED !important;
  }

  /* ── Module name tags: BLACK text in light mode, including anchor links ── */
  .swagger-ui .opblock-tag-section .opblock-tag,
  .swagger-ui .opblock-tag-section .opblock-tag a,
  .swagger-ui .opblock-tag-section .opblock-tag span,
  .swagger-ui .opblock-tag {
    color: #000000 !important;
    font-size: 18px !important;
    font-weight: 700 !important;
  }

  .swagger-ui .opblock-tag-section .opblock-tag {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    border-bottom: 2px solid #8B5CF6 !important;
  }

  /* Kill any default link styling on the anchor inside the tag */
  .swagger-ui .opblock-tag a {
    color: #000000 !important;
    text-decoration: none !important;
  }

  .swagger-ui .opblock-tag a:hover,
  .swagger-ui .opblock-tag a:visited,
  .swagger-ui .opblock-tag a:focus {
    color: #000000 !important;
    text-decoration: none !important;
  }
  
  .swagger-ui .opblock-tag-section .opblock-tag small {
    color: #7C3AED !important;
  }
  
  .swagger-ui .opblock-tag:hover {
    background: rgba(139, 92, 246, 0.1) !important;
  }
  
  /* Export buttons */
  .export-module-btn, .export-endpoint-btn {
    background-color: #7C3AED !important;
    color: white !important;
    border: 1px solid #6B21A8 !important;
    padding: 6px 16px !important;
    border-radius: 6px !important;
    cursor: pointer !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    transition: all 0.2s ease !important;
    white-space: nowrap !important;
  }
  
  .export-module-btn:hover, .export-endpoint-btn:hover {
    background-color: #6B21A8 !important;
    border-color: #5B21B6 !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 6px rgba(107, 33, 168, 0.2) !important;
  }
  
  .export-module-btn {
    font-size: 14px !important;
    padding: 8px 20px !important;
    margin-left: auto !important;
  }
  
  .export-endpoint-btn {
    margin-left: auto !important;
    order: 2 !important;
  }
  
  .export-all-btn {
    margin-top: 20px !important;
    margin-bottom: 20px !important;
    font-size: 15px !important;
    padding: 10px 24px !important;
    display: inline-block !important;
  }
  
  .swagger-ui .opblock-tag-section {
    margin-bottom: 20px !important;
  }
  
  .swagger-ui .opblock {
    margin-bottom: 12px !important;
  }
  
  .swagger-ui .opblock-summary {
    padding: 10px 16px !important;
    display: flex !important;
    align-items: center !important;
  }
  
  .swagger-ui .opblock-summary-path {
    flex: 1 !important;
    margin-left: 12px !important;
  }
  
  .swagger-ui .information-container {
    margin-bottom: 30px !important;
    padding: 20px !important;
  }
  
  .swagger-ui .scheme-container {
    padding: 20px !important;
    margin-bottom: 20px !important;
    background: rgba(139, 92, 246, 0.05) !important;
    box-shadow: 0 1px 2px 0 rgba(107, 33, 168, 0.15) !important;
  }
  
  .swagger-ui .btn.execute {
    background-color: #7C3AED !important;
    border-color: #7C3AED !important;
  }
  
  .swagger-ui .btn.execute:hover {
    background-color: #6B21A8 !important;
  }
  
  .swagger-ui .btn.authorize {
    background-color: #7C3AED !important;
    border-color: #7C3AED !important;
    color: white !important;
  }
  
  .swagger-ui .btn.authorize:hover {
    background-color: #6B21A8 !important;
  }
  
  .swagger-ui .btn.authorize svg {
    fill: white !important;
  }
  
  .swagger-ui select {
    border: 2px solid #8B5CF6 !important;
  }
  
  .swagger-ui .model-box-control:focus, 
  .swagger-ui input[type=text]:focus, 
  .swagger-ui textarea:focus {
    border-color: #8B5CF6 !important;
    outline-color: #8B5CF6 !important;
  }
  
  .swagger-ui .loading-container .loading::after {
    border-color: #8B5CF6 transparent transparent !important;
  }

  /* ===== MODELS SECTION ===== */
  .swagger-ui .models {
    margin-top: 40px !important;
  }
  
  .swagger-ui .models h4 {
    color: #000000 !important;
    font-size: 18px !important;
    font-weight: 700 !important;
  }
  
  .swagger-ui .model-container {
    margin: 12px 0 !important;
    background: rgba(139, 92, 246, 0.03) !important;
    border-radius: 8px !important;
    padding: 12px !important;
  }
  
  .swagger-ui .model-title {
    color: #000000 !important;
    font-size: 16px !important;
    font-weight: 600 !important;
  }
  
  .swagger-ui .model-box {
    background: white !important;
    border: 1px solid rgba(139, 92, 246, 0.2) !important;
    border-radius: 6px !important;
  }

  /* ===== DARK MODE ===== */
  @media (prefers-color-scheme: dark) {

    /* ─── Sidebar – dark ─── */
    #swagger-sidebar {
      background: #18181B !important;
      border-right-color: #27272A !important;
    }

    .sidebar-header {
      color: #A78BFA !important;
      border-bottom-color: #3F3F46 !important;
      background: #18181B !important;
    }

    .sidebar-header svg {
      color: #A78BFA !important;
    }

    .sidebar-search-wrap {
      border-bottom-color: #3F3F46 !important;
      background: #18181B !important;
    }

    #sidebar-search {
      background: #27272A !important;
      border-color: #52525B !important;
      color: #E4E4E7 !important;
    }

    #sidebar-search:focus {
      border-color: #8B5CF6 !important;
      background: #3F3F46 !important;
    }

    #sidebar-search::placeholder {
      color: #71717A !important;
    }

    #sidebar-module-list {
      background: #18181B !important;
    }

    .sidebar-module-item:hover {
      background: rgba(139, 92, 246, 0.12) !important;
    }

    .sidebar-module-item.active {
      background: rgba(124, 58, 237, 0.18) !important;
    }

    .sidebar-module-name {
      color: #E4E4E7 !important;
    }

    .sidebar-module-item:hover .sidebar-module-name {
      color: #C4B5FD !important;
    }

    .sidebar-module-item.active .sidebar-module-name {
      color: #C4B5FD !important;
    }

    .sidebar-module-count {
      background: #3F3F46 !important;
      color: #A78BFA !important;
    }

    .sidebar-module-item.active .sidebar-module-count {
      background: #7C3AED !important;
      color: #fff !important;
    }

    /* ─── Swagger UI – dark ─── */
    .swagger-ui .topbar {
      background-color: #4C1D95 !important;
    }
    
    .swagger-ui .btn.authorize {
      background-color: #7C3AED !important;
      border: 1px solid #8B5CF6 !important;
      color: #F3E8FF !important;
    }
    
    .swagger-ui .btn.authorize:hover {
      background-color: #6B21A8 !important;
    }
    
    /* White text for module names in dark mode — including anchor links */
    .swagger-ui .opblock-tag-section .opblock-tag,
    .swagger-ui .opblock-tag-section .opblock-tag a,
    .swagger-ui .opblock-tag-section .opblock-tag span,
    .swagger-ui .opblock-tag {
      color: #FFFFFF !important;
    }

    .swagger-ui .opblock-tag a,
    .swagger-ui .opblock-tag a:hover,
    .swagger-ui .opblock-tag a:visited,
    .swagger-ui .opblock-tag a:focus {
      color: #FFFFFF !important;
      text-decoration: none !important;
    }
    
    .swagger-ui .opblock-tag:hover {
      background: rgba(196, 181, 253, 0.1) !important;
    }
    
    .swagger-ui .scheme-container {
      background: rgba(139, 92, 246, 0.08) !important;
    }
    
    .export-module-btn, .export-endpoint-btn {
      background-color: #5B21B6 !important;
      border-color: #7C3AED !important;
    }
    
    .export-module-btn:hover, .export-endpoint-btn:hover {
      background-color: #6B21A8 !important;
      border-color: #8B5CF6 !important;
      box-shadow: 0 4px 8px rgba(139, 92, 246, 0.3) !important;
    }
    
    .swagger-ui .information-container {
      background: rgba(139, 92, 246, 0.05) !important;
      border-radius: 8px !important;
      padding: 24px !important;
      margin-bottom: 30px !important;
    }
    
    .swagger-ui .models h4 {
      color: #FFFFFF !important;
    }
    
    .swagger-ui .model-title {
      color: #FFFFFF !important;
    }
    
    .swagger-ui .model-container {
      background: rgba(139, 92, 246, 0.08) !important;
    }
    
    .swagger-ui .model-box {
      background: #1E1E1E !important;
      border-color: rgba(139, 92, 246, 0.3) !important;
    }
  }
`;

