import swaggerJsdoc from 'swagger-jsdoc';

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Iyadati API',
      version: '1.0.0',
      description: 'API documentation for the Iyadati Platform',
      contact: {
        name: 'API Support',
        email: 'support@iyadati.com',
      },
    },
    servers: [
      {
        url: 'http://localhost:3975',
        description: 'Local server',
      },
      {
        url : 'https://finicky-canyon-unsightly.ngrok-free.dev',
        description : 'Ngrok test server',
      },
      {
        url : 'https://api.serirsalah.me/',
        description: 'Dev server',         
      },
      {
        url : 'https://iyadati.onrender.com',
        description: 'Render test server',
      }
    ],
    tags: [
      { 
        name: 'Health', 
        description: 'System health and monitoring endpoints' 
      },
    ],
    components: {
      securitySchemes: {
        cookieAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'token',
          description: 'HTTP-only cookie authentication (automatic for web clients)',
        },
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
      schemas: {
        HealthResponse: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              example: 'OK'
            },
            timestamp: {
              type: 'string',
              format: 'date-time',
              example: '2024-01-01T00:00:00.000Z'
            },
            uptime: {
              type: 'number',
              example: 123.456
            }
          }
        },
        ErrorResponse: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: false
            },
            error: {
              type: 'string',
              example: 'Error message description'
            }
          }
        }
      },
    },
  },
  apis: ['./src/modules/**/*.swagger.ts'],
};

export const swaggerSpec = swaggerJsdoc(options);

