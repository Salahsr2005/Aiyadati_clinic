import { ChargilyClient } from '@chargily/chargily-pay';
import { env } from './env';

export const chargilyClient = new ChargilyClient({
  api_key: env.CHARGILY_SECRET_KEY,
  mode: env.CHARGILY_MODE,
});

