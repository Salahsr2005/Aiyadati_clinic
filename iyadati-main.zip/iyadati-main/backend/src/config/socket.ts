import { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import { logger } from '../core/utils/logger';
import { env } from '../config/env';
import { chatRepository } from '../repositories/chat.repository';

const JWT_SECRET = env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

let io: Server;

// Support staff roles that can access any room
const SUPPORT_STAFF_ROLES = ['SUPPORT', 'ADMIN', 'SUPER_ADMIN'];

export const initSocket = (server: HttpServer) => {
  io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    },
  });

  // Authentication middleware
  io.use(async (socket: Socket, next) => {
    try {
      const token = socket.handshake.auth.token || socket.handshake.query.token;
      if (!token) {
        return next(new Error('Authentication required'));
      }

      const decoded = jwt.verify(token as string, JWT_SECRET) as any;
      socket.data.user = decoded;
      next();
    } catch (error) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket: Socket) => {
    const user = socket.data.user;
    logger.info(`Socket connected: ${user.name} (${user.role}) - ${socket.id}`);

    // ============================================================
    // JOIN ROOM
    // ============================================================
    socket.on('join_room', async (roomId: string) => {
      try {
        const room = await chatRepository.findRoomById(roomId);
        if (!room) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        // Check if user can join this room
        const isSupportStaff = SUPPORT_STAFF_ROLES.includes(user.role);
        const isOwnRoom = room.userId === user.id;

        if (isSupportStaff || isOwnRoom) {
          socket.join(roomId);
          socket.emit('joined_room', { roomId });
          logger.info(`${user.name} (${user.role}) joined room ${roomId}`);
        } else {
          socket.emit('error', { message: 'Access denied - you can only join your own rooms' });
        }
      } catch (error) {
        logger.error('Failed to join room:', error);
        socket.emit('error', { message: 'Failed to join room' });
      }
    });

    // ============================================================
    // SEND MESSAGE
    // ============================================================
    socket.on('send_message', async (data: { roomId: string; message: string }) => {
      try {
        // Validate message
        if (!data.message || data.message.trim().length === 0) {
          socket.emit('error', { message: 'Message cannot be empty' });
          return;
        }

        if (data.message.length > 1000) {
          socket.emit('error', { message: 'Message too long (max 1000 characters)' });
          return;
        }

        const room = await chatRepository.findRoomById(data.roomId);
        if (!room) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        if (room.status === 'closed') {
          socket.emit('error', { message: 'Room is closed' });
          return;
        }

        // Check if user can send to this room
        const isSupportStaff = SUPPORT_STAFF_ROLES.includes(user.role);
        const isOwnRoom = room.userId === user.id;

        if (!isSupportStaff && !isOwnRoom) {
          socket.emit('error', { message: 'Access denied - you can only message in your own rooms' });
          return;
        }

        // Save message to database
        const message = await chatRepository.createMessage({
          roomId: data.roomId,
          senderId: user.id,
          senderRole: user.role,
          senderName: user.name,
          message: data.message.trim(),
        });

        // Update room with last message
        await chatRepository.updateRoom(data.roomId, { lastMessage: data.message.trim() });

        // Broadcast message to everyone in the room
        io.to(data.roomId).emit('new_message', {
          id: message.id,
          roomId: message.roomId,
          senderId: message.senderId,
          senderRole: message.senderRole,
          senderName: message.senderName,
          message: message.message,
          createdAt: message.createdAt.toISOString(),
        });

        // If NOT support staff, notify support staff about new request
        if (!isSupportStaff) {
          // Notify all support staff (SUPPORT, ADMIN, SUPER_ADMIN)
          io.emit('new_support_request', {
            roomId: data.roomId,
            userName: room.userName,
            userRole: room.userRole,
            userEmail: room.userEmail,
            message: data.message.trim(),
            from: user.name,
            timestamp: new Date().toISOString(),
          });

          logger.info(`New support request from ${user.name} (${user.role}) in room ${data.roomId}`);
        }

        logger.debug(`Message sent in room ${data.roomId} by ${user.name}`);
      } catch (error) {
        logger.error('Failed to send message:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // ============================================================
    // TYPING INDICATORS
    // ============================================================
    socket.on('typing', (roomId: string) => {
      socket.to(roomId).emit('user_typing', {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
      });
    });

    socket.on('stop_typing', (roomId: string) => {
      socket.to(roomId).emit('user_stop_typing', {
        userId: user.id,
        userName: user.name,
      });
    });

    // ============================================================
    // DISCONNECT
    // ============================================================
    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${user.name} (${user.role}) - ${socket.id}`);
    });

    // ============================================================
    // ERROR HANDLING
    // ============================================================
    socket.on('error', (error) => {
      logger.error(`Socket error for ${user.name}:`, error);
    });
  });

  return io;
};

export const getIO = () => io;

