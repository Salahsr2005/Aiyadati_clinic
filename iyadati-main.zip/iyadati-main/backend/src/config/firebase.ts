import admin from 'firebase-admin';
import { env } from './env';
import { logger } from '../core/utils/logger';
import path from 'path';
import fs from 'fs';

let messaging: admin.messaging.Messaging | null = null;

try {
  const serviceAccountPath = path.join(__dirname, 'firebase-service-account.json');
  
  if (fs.existsSync(serviceAccountPath)) {
    const serviceAccount = require(serviceAccountPath);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
    messaging = admin.messaging();
    logger.info('Firebase initialized successfully');
  } else {
    logger.warn('Firebase: firebase-service-account.json not found. Push notifications disabled.');
  }
} catch (error) {
  logger.error('Firebase initialization failed:', error);
}

export const sendPushNotification = async (params: {
  deviceToken: string;
  title: string;
  body: string;
  data?: Record<string, string>;
}): Promise<boolean> => {
  if (!messaging) {
    logger.warn('Firebase not initialized, skipping push notification');
    return false;
  }

  try {
    await messaging.send({
      token: params.deviceToken,
      notification: {
        title: params.title,
        body: params.body,
      },
      data: params.data || {},
      android: {
        priority: 'high',
        notification: { channelId: 'iyadati_default', sound: 'default' },
      },
      apns: {
        payload: { aps: { sound: 'default', badge: 1 } },
      },
    });
    return true;
  } catch (error: any) {
    logger.error('Push notification failed:', { error: error.message });
    return false;
  }
};

export { messaging };

