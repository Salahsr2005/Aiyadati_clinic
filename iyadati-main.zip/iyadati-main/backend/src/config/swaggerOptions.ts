import { SwaggerUiOptions } from 'swagger-ui-express';
import { swaggerCustomCss } from './swaggerTheme';

export const swaggerUiOptions: SwaggerUiOptions = {
  explorer: true,
  customCss: swaggerCustomCss,
  customSiteTitle: 'Iyadati API Docs',
  // customfavIcon: '/favicon.ico',
  swaggerOptions: {
    filter: true,
    displayRequestDuration: true,
    deepLinking: true,
    persistAuthorization: true,
    tagsSorter: 'alpha',
    operationsSorter: 'method',
    docExpansion: 'none', // Modules closed by default

    // Models section controls
    defaultModelsExpandDepth: 1,  // Show models section
    defaultModelExpandDepth: 1,   // Expand models by default
    defaultModelRendering: 'model', // Show model/schema view

    displayOperationId: false,
    showExtensions: true,
    showCommonExtensions: true,
    tryItOutEnabled: true,
  },
};

