import swaggerJsdoc from 'swagger-jsdoc';

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Iyadati API',
      version: '1.0.0',
      description: 'API documentation for the Iyadati Platform',
      contact: {
        name: 'API Support',
        email: 'support@iyadati.com',
      },
    },
    servers: [
      {
        url: 'http://localhost:3000/api/v1',
        description: 'Development server',
      },
    ],
    tags: [
      { 
        name: 'System Health', 
        description: 'System monitoring and health checks' 
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
      schemas: {
        HealthResponse: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              example: 'OK'
            },
            timestamp: {
              type: 'string',
              format: 'date-time',
              example: '2024-01-01T00:00:00.000Z'
            },
            uptime: {
              type: 'number',
              example: 123.456
            }
          }
        },
        ErrorResponse: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: false
            },
            error: {
              type: 'string',
              example: 'Error message description'
            }
          }
        }
      },
    },
  },
  apis: ['./src/modules/**/*.swagger.ts'],
};

export const swaggerSpec = swaggerJsdoc(options);


export const swaggerCustomJs = `
  // ─── SIDEBAR ────────────────────────────────────────────────────────────────

  function buildSidebar() {
    if (document.getElementById('swagger-sidebar')) return;

    const swaggerRoot = document.getElementById('swagger-ui');
    if (!swaggerRoot) return;

    const wrapper = document.createElement('div');
    wrapper.id = 'swagger-layout-wrapper';
    swaggerRoot.parentNode.insertBefore(wrapper, swaggerRoot);
    wrapper.appendChild(swaggerRoot);

    const sidebar = document.createElement('nav');
    sidebar.id = 'swagger-sidebar';
    sidebar.innerHTML = \`
      <div class="sidebar-header">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        <span>Modules</span>
      </div>
      <div class="sidebar-search-wrap">
        <input id="sidebar-search" type="text" placeholder="Search modules…" autocomplete="off" />
      </div>
      <ul id="sidebar-module-list"></ul>
    \`;
    wrapper.insertBefore(sidebar, swaggerRoot);

    document.getElementById('sidebar-search').addEventListener('input', function() {
      const q = this.value.toLowerCase();
      document.querySelectorAll('#sidebar-module-list li').forEach(li => {
        li.style.display = li.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });

    populateSidebar();
  }

  function populateSidebar() {
    const list = document.getElementById('sidebar-module-list');
    if (!list) return;

    const tags = document.querySelectorAll('.opblock-tag-section .opblock-tag');
    if (tags.length === 0) return;

    list.innerHTML = '';

    tags.forEach(tag => {
      const rawName = tag.getAttribute('data-tag') ||
                      tag.querySelector('span')?.textContent?.trim() ||
                      tag.textContent?.trim() ||
                      'Module';
      const endpointCount = tag.closest('.opblock-tag-section')?.querySelectorAll('.opblock').length || 0;

      const li = document.createElement('li');
      li.className = 'sidebar-module-item';
      li.setAttribute('data-tag', rawName);
      li.innerHTML = \`
        <span class="sidebar-module-name">\${rawName}</span>
        <span class="sidebar-module-count">\${endpointCount}</span>
      \`;

      li.addEventListener('click', () => {
        document.querySelectorAll('.sidebar-module-item').forEach(el => el.classList.remove('active'));
        li.classList.add('active');

        const allSections = document.querySelectorAll('.opblock-tag-section');
        allSections.forEach(section => {
          const sectionTag = section.querySelector('.opblock-tag');
          const sectionName = sectionTag?.getAttribute('data-tag') ||
                              sectionTag?.querySelector('span')?.textContent?.trim() || '';

          const isTarget = sectionName === rawName;
          const isExpanded = section.classList.contains('is-open');

          if (isTarget) {
            if (!isExpanded) {
              sectionTag?.click();
            }
            setTimeout(() => {
              section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 150);
          } else {
            if (isExpanded) {
              sectionTag?.click();
            }
          }
        });
      });

      list.appendChild(li);
    });
  }

  // ─── EXPORT BUTTONS ─────────────────────────────────────────────────────────

  function addEndpointExportButtons() {
    const operations = document.querySelectorAll('.opblock');
    operations.forEach(op => {
      if (op.querySelector('.export-endpoint-btn')) return;
      
      const summary = op.querySelector('.opblock-summary');
      if (summary) {
        const exportBtn = document.createElement('button');
        exportBtn.className = 'export-endpoint-btn';
        exportBtn.textContent = 'Export';
        exportBtn.style.cssText = 'margin-left: auto; margin-right: 8px;';
        exportBtn.onclick = function(e) {
          e.stopPropagation();
          e.preventDefault();
          
          const path = op.querySelector('.opblock-summary-path')?.textContent?.trim() || '';
          const method = op.querySelector('.opblock-summary-method')?.textContent?.trim() || '';
          const description = op.querySelector('.opblock-summary-description')?.textContent?.trim() || '';
          
          const operationData = {
            path: path,
            method: method,
            description: description,
            operationId: op.getAttribute('id')?.replace('operations-', '') || '',
            timestamp: new Date().toISOString(),
          };
          
          const blob = new Blob([JSON.stringify(operationData, null, 2)], { type: 'application/json' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = method.toLowerCase() + '-' + path.replace(/\\//g, '-').replace(/[{}]/g, '') + '.json';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        };
        
        summary.appendChild(exportBtn);
      }
    });
  }
  
  function addModuleExportButtons() {
    const tagSections = document.querySelectorAll('.opblock-tag-section');
    tagSections.forEach(section => {
      if (section.querySelector('.export-module-btn')) return;
      
      const tagElement = section.querySelector('.opblock-tag');
      if (tagElement) {
        const tagName = tagElement.getAttribute('data-tag') || 
                       tagElement.querySelector('span')?.textContent?.trim() || 
                       'Module';
        
        const exportBtn = document.createElement('button');
        exportBtn.className = 'export-module-btn';
        exportBtn.textContent = 'Export Module';
        exportBtn.style.cssText = 'margin-left: auto;';
        exportBtn.onclick = function(e) {
          e.stopPropagation();
          e.preventDefault();
          
          const operations = [];
          const opBlocks = section.querySelectorAll('.opblock');
          
          opBlocks.forEach(op => {
            const path = op.querySelector('.opblock-summary-path')?.textContent?.trim() || '';
            const method = op.querySelector('.opblock-summary-method')?.textContent?.trim() || '';
            const description = op.querySelector('.opblock-summary-description')?.textContent?.trim() || '';
            
            operations.push({
              path: path,
              method: method,
              description: description,
              operationId: op.getAttribute('id')?.replace('operations-', '') || '',
            });
          });
          
          const moduleData = {
            module: tagName,
            endpoints: operations,
            totalEndpoints: operations.length,
            timestamp: new Date().toISOString(),
          };
          
          const blob = new Blob([JSON.stringify(moduleData, null, 2)], { type: 'application/json' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = tagName.toLowerCase().replace(/\\s+/g, '-') + '-module.json';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        };
        
        tagElement.appendChild(exportBtn);
      }
    });
  }
  
  function addExportAllButton() {
    const infoContainer = document.querySelector('.information-container');
    if (infoContainer && !document.querySelector('.export-all-btn')) {
      const wrapperDiv = document.createElement('div');
      wrapperDiv.style.cssText = 'margin-top: 24px; padding-top: 16px; border-top: 1px solid rgba(139, 92, 246, 0.2);';
      
      const exportAllBtn = document.createElement('button');
      exportAllBtn.className = 'export-module-btn export-all-btn';
      exportAllBtn.textContent = 'Export All Documentation';
      exportAllBtn.style.cssText = 'display: block; width: auto;';
      exportAllBtn.onclick = function() {
        fetch('/api-docs.json')
          .then(response => response.json())
          .then(data => {
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'api-documentation-' + new Date().toISOString().split('T')[0] + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
          })
          .catch(error => console.error('Error exporting documentation:', error));
      };
      
      wrapperDiv.appendChild(exportAllBtn);
      infoContainer.appendChild(wrapperDiv);
    }
  }

  // ─── SIDEBAR SYNC ────────────────────────────────────────────────────────────

  function syncSidebarCounts() {
    document.querySelectorAll('.sidebar-module-item').forEach(li => {
      const tagName = li.getAttribute('data-tag');
      const section = [...document.querySelectorAll('.opblock-tag-section')].find(s => {
        const t = s.querySelector('.opblock-tag');
        return (t?.getAttribute('data-tag') || t?.querySelector('span')?.textContent?.trim()) === tagName;
      });
      if (section) {
        const count = section.querySelectorAll('.opblock').length;
        const badge = li.querySelector('.sidebar-module-count');
        if (badge) badge.textContent = count;
      }
    });
  }

  // ─── MAIN INIT ───────────────────────────────────────────────────────────────
  
  function initializeExportButtons() {
    addModuleExportButtons();
    addEndpointExportButtons();
    addExportAllButton();
  }

  function initializeAll() {
    buildSidebar();
    populateSidebar();
    syncSidebarCounts();
    initializeExportButtons();
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(initializeAll, 500);
      
      const observer = new MutationObserver((mutations) => {
        let shouldRefresh = false;
        mutations.forEach((mutation) => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            const target = mutation.target;
            if (target.classList?.contains('opblock-tag-section') || 
                target.closest?.('.opblock-tag-section')) {
              shouldRefresh = true;
            }
          }
          if (mutation.type === 'childList') {
            shouldRefresh = true;
          }
        });
        if (shouldRefresh) {
          setTimeout(() => {
            populateSidebar();
            syncSidebarCounts();
            initializeExportButtons();
          }, 100);
        }
      });
      
      const swaggerUI = document.getElementById('swagger-ui');
      if (swaggerUI) {
        observer.observe(swaggerUI, {
          attributes: true,
          subtree: true,
          childList: true,
          attributeFilter: ['class', 'style']
        });
      }
      
      document.addEventListener('click', (e) => {
        const tagElement = e.target.closest('.opblock-tag');
        if (tagElement) {
          setTimeout(() => {
            populateSidebar();
            syncSidebarCounts();
            initializeExportButtons();
          }, 200);
        }
      });
    });
  } else {
    setTimeout(initializeAll, 500);
  }
`;

