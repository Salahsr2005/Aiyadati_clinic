import { PrismaClient } from '@prisma/client';
import { env } from './env';

const datasource =
    process.env.USE_PGBOUNCER === "true"
        ? env.DATABASE_URL_PGBOUNCER
        : env.DATABASE_URL;

export const prisma = new PrismaClient({
    datasourceUrl: datasource
});