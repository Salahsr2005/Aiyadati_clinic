// src/repositories/clinic.repository.ts

import { prisma } from '../core/utils/prisma';
import { Prisma, FacilityType } from '@prisma/client';

export class ClinicRepository {
  async findById(id: string) {
    return prisma.clinic.findUnique({
      where: { id },
      include: { wilaya: true, baladya: true },
    });
  }

  async findByEmail(email: string) {
    return prisma.clinic.findUnique({ where: { email } });
  }

  async findByPhone(phone: string) {
    return prisma.clinic.findUnique({ where: { phone } });
  }

  // ✅ ADD: findByFileId for clinic logos
  async findByFileId(fileId: string) {
    return prisma.clinic.findFirst({
      where: { logoFileId: fileId },
      include: { wilaya: true, baladya: true },
    });
  }

  async create(data: Prisma.ClinicCreateInput) {
    return prisma.clinic.create({
      data,
      include: { wilaya: true, baladya: true },
    });
  }

  async update(id: string, data: Prisma.ClinicUpdateInput) {
    return prisma.clinic.update({
      where: { id },
      data: {
        ...data,
        logoFileId: data.logoFileId,
      },
      include: { wilaya: true, baladya: true },
    });
  }

  async delete(id: string) {
    return prisma.clinic.delete({ where: { id } });
  }

  // ✅ ADD: deleteByFileId for clinic logos
  async deleteByFileId(fileId: string) {
    const clinic = await this.findByFileId(fileId);
    if (!clinic) return null;
    return prisma.clinic.update({
      where: { id: clinic.id },
      data: { logoPath: null, logoFileId: null },
    });
  }

  // ✅ ADD: incrementAccessCount for clinic logos
  async incrementAccessCount(fileId: string): Promise<void> {
    // Clinic doesn't have an access count field for logos
    // We could add one, but for now we just log it
    // If you want to track access, you can add `logoAccessCount` field to Clinic model
    // For now, we'll just return
    return Promise.resolve();
  }

  async findAll(params: {
    page?: number;
    limit?: number;
    wilayaId?: string;
    baladyaId?: string;
    facilityType?: FacilityType;
    isVerified?: boolean;
    isSuspended?: boolean;
    isCompleted?: boolean;
    search?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      page = 1, limit = 10, wilayaId, baladyaId,
      facilityType,
      isVerified, isSuspended, isCompleted,
      search, sortBy = 'createdAt', sortOrder = 'desc',
    } = params;

    const where: any = {};

    if (wilayaId) where.wilayaId = wilayaId;
    if (baladyaId) where.baladyaId = baladyaId;
    if (facilityType) where.facilityType = facilityType;
    if (isVerified !== undefined) where.isVerified = isVerified;
    if (isSuspended !== undefined) where.isSuspended = isSuspended;
    if (isCompleted !== undefined) where.isCompleted = isCompleted;

    if (search) {
      where.OR = [
        { nameFr: { contains: search, mode: 'insensitive' } },
        { nameAr: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const skip = (page - 1) * limit;

    const [clinics, total] = await Promise.all([
      prisma.clinic.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: { wilaya: true, baladya: true },
      }),
      prisma.clinic.count({ where }),
    ]);

    return { clinics, total };
  }

  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const clinic = await prisma.clinic.findUnique({ where: { email } });
    if (!clinic) return false;
    if (excludeId && clinic.id === excludeId) return false;
    return true;
  }

  async phoneExists(phone: string, excludeId?: string): Promise<boolean> {
    const clinic = await prisma.clinic.findUnique({ where: { phone } });
    if (!clinic) return false;
    if (excludeId && clinic.id === excludeId) return false;
    return true;
  }

  async updateLogo(id: string, logoPath: string, logoFileId: string) {
    return prisma.clinic.update({
      where: { id },
      data: { 
        logoPath, 
        logoFileId 
      },
      include: { wilaya: true, baladya: true },
    });
  }

  async verify(id: string) {
    return prisma.clinic.update({
      where: { id },
      data: { isVerified: true },
      include: { wilaya: true, baladya: true },
    });
  }

  async suspend(id: string) {
    return prisma.clinic.update({
      where: { id },
      data: { isSuspended: true },
      include: { wilaya: true, baladya: true },
    });
  }

  async unsuspend(id: string) {
    return prisma.clinic.update({
      where: { id },
      data: { isSuspended: false },
      include: { wilaya: true, baladya: true },
    });
  }
}

export const clinicRepository = new ClinicRepository();

