import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';

export class GuestPatientRepository {
  
  /**
   * Find guest patient by ID
   */
  async findById(id: string) {
    return prisma.guestPatient.findUnique({
      where: { id },
      include: {
        wilaya: true,
        appointments: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });
  }

  /**
   * Find guest patient by phone number
   */
  async findByPhone(phone: string) {
    return prisma.guestPatient.findFirst({
      where: { phone },
    });
  }

  /**
   * Find guest patient by phone and return minimal data
   */
  async findByPhoneMinimal(phone: string) {
    return prisma.guestPatient.findFirst({
      where: { phone },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        phone: true,
        email: true,
      },
    });
  }

  /**
   * Create a new guest patient
   */
  async create(data: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
    dateOfBirth?: Date;
    wilayaId?: string;
    createdBy: string;
    createdByType: string;
    notes?: string;
  }) {
    return prisma.guestPatient.create({
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        email: data.email,
        dateOfBirth: data.dateOfBirth,
        wilayaId: data.wilayaId,
        createdBy: data.createdBy,
        createdByType: data.createdByType,
        notes: data.notes,
      },
    });
  }

  /**
   * Update guest patient
   */
  async update(id: string, data: {
    firstName?: string;
    lastName?: string;
    phone?: string;
    email?: string;
    dateOfBirth?: Date;
    wilayaId?: string;
    notes?: string;
  }) {
    return prisma.guestPatient.update({
      where: { id },
      data,
    });
  }

  /**
   * Convert guest patient to registered user
   * Links the guest profile to a newly created user account
   */
  async convertToUser(
    guestId: string,
    userId: string,
    tx?: Prisma.TransactionClient
  ) {
    const client = tx || prisma;
    return client.guestPatient.update({
      where: { id: guestId },
      data: {
        convertedToUserId: userId,
        convertedAt: new Date(),
      },
    });
  }

  /**
   * Check if a phone number is already used (by registered user or guest)
   */
  async isPhoneUsed(phone: string): Promise<{
    used: boolean;
    type: 'USER' | 'GUEST' | null;
    id?: string;
  }> {
    // Check registered users
    const user = await prisma.user.findUnique({
      where: { phone },
      select: { id: true },
    });

    if (user) {
      return { used: true, type: 'USER', id: user.id };
    }

    // Check guest patients
    const guest = await prisma.guestPatient.findFirst({
      where: { phone },
      select: { id: true },
    });

    if (guest) {
      return { used: true, type: 'GUEST', id: guest.id };
    }

    return { used: false, type: null };
  }

  /**
   * Find guest patients by creator (doctor or clinic)
   */
  async findByCreator(createdBy: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [guests, total] = await Promise.all([
      prisma.guestPatient.findMany({
        where: { createdBy },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          wilaya: true,
        },
      }),
      prisma.guestPatient.count({ where: { createdBy } }),
    ]);
    return { guests, total };
  }

  /**
   * Search guest patients by name or phone
   */
  async search(query: string, createdBy?: string) {
    const where: any = {
      OR: [
        { firstName: { contains: query, mode: 'insensitive' } },
        { lastName: { contains: query, mode: 'insensitive' } },
        { phone: { contains: query } },
      ],
    };

    if (createdBy) {
      where.createdBy = createdBy;
    }

    return prisma.guestPatient.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        wilaya: true,
      },
    });
  }
}

export const guestPatientRepository = new GuestPatientRepository();

