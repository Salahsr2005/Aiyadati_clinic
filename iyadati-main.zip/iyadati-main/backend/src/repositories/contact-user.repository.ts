import { prisma } from '../core/utils/prisma';

export class ContactUserRepository {
  async findByUserId(userId: string) {
    return prisma.contactUser.findMany({
      where: { userId, isActive: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findById(id: string) {
    return prisma.contactUser.findUnique({ where: { id } });
  }

  async create(data: {
    userId: string;
    firstName: string;
    lastName: string;
    phone: string;
    dateOfBirth: Date;
    relationship?: string;
  }) {
    return prisma.contactUser.create({ data });
  }

  async update(id: string, data: {
    firstName?: string;
    lastName?: string;
    phone?: string;
    dateOfBirth?: Date;
    relationship?: string;
  }) {
    return prisma.contactUser.update({ where: { id }, data });
  }

  async softDelete(id: string) {
    return prisma.contactUser.update({ where: { id }, data: { isActive: false } });
  }
}

export const contactUserRepository = new ContactUserRepository();


