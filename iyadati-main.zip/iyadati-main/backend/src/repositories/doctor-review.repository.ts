import { prisma } from '../core/utils/prisma';

export class DoctorReviewRepository {
  async findByDoctorId(doctorId: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [reviews, total] = await Promise.all([
      prisma.doctorReview.findMany({
        where: { doctorId },
        skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: { patient: { select: { id: true, firstName: true, lastName: true } } },
      }),
      prisma.doctorReview.count({ where: { doctorId } }),
    ]);
    return { reviews, total };
  }

  async findByDoctorAndPatient(doctorId: string, patientId: string) {
    return prisma.doctorReview.findUnique({
      where: { doctorId_patientId: { doctorId, patientId } },
    });
  }

  async upsert(doctorId: string, patientId: string, data: { rating?: number; review?: string }) {
    return prisma.doctorReview.upsert({
      where: { doctorId_patientId: { doctorId, patientId } },
      create: { doctorId, patientId, ...data },
      update: data,
    });
  }

  async delete(doctorId: string, patientId: string) {
    return prisma.doctorReview.delete({
      where: { doctorId_patientId: { doctorId, patientId } },
    });
  }

  async updateAvgRating(doctorId: string) {
    const result = await prisma.doctorReview.aggregate({
      where: { doctorId, rating: { not: null } },
      _avg: { rating: true },
      _count: { rating: true },
    });

    const avgRating = result._avg.rating
      ? Math.round(result._avg.rating * 10) / 10
      : null;

    await prisma.doctor.update({
      where: { id: doctorId },
      data: {
        avgRating,
        totalReviews: result._count.rating,
      },
    });
  }
}

export const doctorReviewRepository = new DoctorReviewRepository();

