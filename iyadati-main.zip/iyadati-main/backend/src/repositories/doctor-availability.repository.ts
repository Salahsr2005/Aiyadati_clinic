import { prisma } from '../core/utils/prisma';

export class DoctorAvailabilityRepository {
  async findByDoctorId(doctorId: string) {
    return prisma.doctorAvailability.findMany({
      where: { doctorId, isActive: true },
      orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }],
    });
  }

  async findByDoctorAndDay(doctorId: string, dayOfWeek: string) {
    return prisma.doctorAvailability.findMany({
      where: { doctorId, dayOfWeek: dayOfWeek as any, isActive: true },
      orderBy: { startTime: 'asc' },
    });
  }

  async findById(id: string) {
    return prisma.doctorAvailability.findUnique({ where: { id } });
  }

  async create(data: {
    doctorId: string;
    dayOfWeek: string;
    startTime: Date;
    endTime: Date;
    clinicId?: string;
    roomId?: string;
  }) {
    return prisma.doctorAvailability.create({
      data: {
        ...data,
        dayOfWeek: data.dayOfWeek as any,
        clinicId: data.clinicId || undefined,
        roomId: data.roomId || undefined,
      },
    });
  }

  async update(id: string, data: {
    startTime?: Date;
    endTime?: Date;
    isActive?: boolean;
    clinicId?: string | null;
    roomId?: string | null;
  }) {
    return prisma.doctorAvailability.update({ where: { id }, data });
  }

  async softDelete(id: string) {
    return prisma.doctorAvailability.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async deleteByDoctorId(doctorId: string) {
    return prisma.doctorAvailability.updateMany({
      where: { doctorId },
      data: { isActive: false },
    });
  }

  async bulkCreate(doctorId: string, slots: Array<{
    dayOfWeek: string;
    startTime: Date;
    endTime: Date;
    clinicId?: string;
    roomId?: string;
  }>) {
    // First deactivate all existing slots
    await this.deleteByDoctorId(doctorId);

    // Then create new ones
    const created = [];
    for (const slot of slots) {
      const c = await this.create({
        doctorId,
        dayOfWeek: slot.dayOfWeek,
        startTime: slot.startTime,
        endTime: slot.endTime,
        clinicId: slot.clinicId,
        roomId: slot.roomId,
      });
      created.push(c);
    }
    return created;
  }
}

export const doctorAvailabilityRepository = new DoctorAvailabilityRepository();

