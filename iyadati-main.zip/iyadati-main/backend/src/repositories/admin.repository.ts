import { prisma } from '../core/utils/prisma';
import { Admin, Prisma } from '@prisma/client';

export class AdminRepository {
  /**
   * Find admin by ID
   */
  async findById(id: string): Promise<Admin | null> {
    return prisma.admin.findUnique({
      where: { id },
    });
  }

  /**
   * Find admin by email
   */
  async findByEmail(email: string): Promise<Admin | null> {
    return prisma.admin.findUnique({
      where: { email },
    });
  }

  /**
   * Create a new admin
   */
  async create(data: Prisma.AdminCreateInput): Promise<Admin> {
    return prisma.admin.create({
      data,
    });
  }

  /**
   * Update an admin
   */
  async update(id: string, data: Prisma.AdminUpdateInput): Promise<Admin> {
    return prisma.admin.update({
      where: { id },
      data,
    });
  }

  /**
   * Delete an admin
   */
  async delete(id: string): Promise<Admin> {
    return prisma.admin.delete({
      where: { id },
    });
  }

  /**
   * Find all admins with pagination
   */
  async findAll(page = 1, limit = 10): Promise<{ admins: Admin[]; total: number }> {
    const skip = (page - 1) * limit;

    const [admins, total] = await Promise.all([
      prisma.admin.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.admin.count(),
    ]);

    return { admins, total };
  }

  /**
   * Update admin password
   */
  async updatePassword(id: string, hashedPassword: string): Promise<Admin> {
    return prisma.admin.update({
      where: { id },
      data: { password: hashedPassword },
    });
  }

  /**
   * Check if email exists
   */
  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const admin = await prisma.admin.findUnique({
      where: { email },
    });
    
    if (!admin) return false;
    if (excludeId && admin.id === excludeId) return false;
    
    return true;
  }
}

// Export singleton instance
export const adminRepository = new AdminRepository();

