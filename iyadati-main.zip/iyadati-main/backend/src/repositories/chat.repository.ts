import { prisma } from '../core/utils/prisma';

export class ChatRepository {
  async findRoomById(id: string) {
    return prisma.chatRoom.findUnique({ where: { id } });
  }

  async findOpenRoomByUserId(userId: string) {
    return prisma.chatRoom.findFirst({
      where: { userId, status: 'open' },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async findRoomsByUserId(userId: string) {
    return prisma.chatRoom.findMany({
      where: { userId, status: 'open' },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async findAllOpenRooms() {
    return prisma.chatRoom.findMany({
      where: { status: 'open' },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async createRoom(data: {
    userId: string;
    userRole: string;
    userName: string;
    userEmail: string;
  }) {
    return prisma.chatRoom.create({ data });
  }

  async updateRoom(id: string, data: { lastMessage?: string; status?: string; supportId?: string }) {
    return prisma.chatRoom.update({ where: { id }, data });
  }

  async createMessage(data: {
    roomId: string;
    senderId: string;
    senderRole: string;
    senderName: string;
    message: string;
  }) {
    return prisma.chatMessage.create({ data });
  }

  async findMessagesByRoomId(roomId: string) {
    return prisma.chatMessage.findMany({
      where: { roomId },
      orderBy: { createdAt: 'asc' },
    });
  }
}

export const chatRepository = new ChatRepository();

