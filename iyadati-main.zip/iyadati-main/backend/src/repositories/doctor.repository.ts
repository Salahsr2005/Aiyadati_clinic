import { prisma } from '../core/utils/prisma';

export class DoctorRepository {
  async findById(id: string) {
    return prisma.doctor.findUnique({
      where: { id },
      include: { 
        wilaya: true, 
        baladya: true, 
        specialties: { include: { specialty: true } },
        logos: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });
  }

  async findByEmail(email: string) {
    return prisma.doctor.findUnique({ where: { email } });
  }

  async findByPhone(phone: string) {
    return prisma.doctor.findUnique({ where: { phone } });
  }

  async create(data: {
    email: string;
    password: string;
    firstNameFr: string;
    firstNameAr: string;
    lastNameFr: string;
    lastNameAr: string;
    phone: string;
    wilayaId: string;
    isRegistered?: boolean;
    isVerified?: boolean;
    isCompleted?: boolean;
  }) {
    return prisma.doctor.create({
      data: {
        email: data.email,
        password: data.password,
        firstNameFr: data.firstNameFr,
        firstNameAr: data.firstNameAr,
        lastNameFr: data.lastNameFr,
        lastNameAr: data.lastNameAr,
        phone: data.phone,
        wilaya: { connect: { id: data.wilayaId } },
        isRegistered: data.isRegistered ?? true,
        isVerified: data.isVerified ?? false,
        isCompleted: data.isCompleted ?? false,
      },
      include: { wilaya: true, baladya: true },
    });
  }

  async update(id: string, data: any) {
    return prisma.doctor.update({
      where: { id },
      data: {
        ...data,
        photoFileId: data.photoFileId,
      },
      include: { 
        wilaya: true, 
        baladya: true, 
        specialties: { include: { specialty: true } },
        logos: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });
  }

  async findAll(params: {
    page?: number;
    limit?: number;
    search?: string;
    wilayaId?: string;
    specialtyId?: string;
    practiceType?: string;
    isVerified?: boolean;
    isSuspended?: boolean;
    isCompleted?: boolean;
    isAvailableForBooking?: boolean;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      page = 1, limit = 10, search, wilayaId, specialtyId,
      practiceType, isVerified, isSuspended, isCompleted, isAvailableForBooking,
      sortBy = 'createdAt', sortOrder = 'desc',
    } = params;

    const where: any = {};

    if (wilayaId) where.wilayaId = wilayaId;
    if (practiceType) where.practiceType = practiceType;
    if (isVerified !== undefined) where.isVerified = isVerified;
    if (isSuspended !== undefined) where.isSuspended = isSuspended;
    if (isCompleted !== undefined) where.isCompleted = isCompleted;
    if (isAvailableForBooking !== undefined) where.isAvailableForBooking = isAvailableForBooking;

    if (specialtyId) {
      where.specialties = { some: { specialtyId } };
    }

    if (search) {
      where.OR = [
        { firstNameFr: { contains: search, mode: 'insensitive' } },
        { firstNameAr: { contains: search, mode: 'insensitive' } },
        { lastNameFr: { contains: search, mode: 'insensitive' } },
        { lastNameAr: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const skip = (page - 1) * limit;

    const [doctors, total] = await Promise.all([
      prisma.doctor.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: { 
          wilaya: true, 
          baladya: true, 
          specialties: { include: { specialty: true } },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      }),
      prisma.doctor.count({ where }),
    ]);

    return { doctors, total };
  }

  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const doctor = await prisma.doctor.findUnique({ where: { email } });
    if (!doctor) return false;
    if (excludeId && doctor.id === excludeId) return false;
    return true;
  }

  async phoneExists(phone: string, excludeId?: string): Promise<boolean> {
    const doctor = await prisma.doctor.findUnique({ where: { phone } });
    if (!doctor) return false;
    if (excludeId && doctor.id === excludeId) return false;
    return true;
  }

  async updatePhoto(id: string, photoPath: string, photoFileId: string) {
    return prisma.doctor.update({
      where: { id },
      data: { 
        photoPath, 
        photoFileId 
      },
      include: { 
        wilaya: true, 
        baladya: true,
        logos: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });
  }

  async verify(id: string) {
    return prisma.doctor.update({
      where: { id },
      data: { isVerified: true, rejectionReason: null },
      include: { wilaya: true, baladya: true },
    });
  }

  async reject(id: string, reason: string) {
    return prisma.doctor.update({
      where: { id },
      data: { rejectionReason: reason, isVerified: false },
    });
  }

  async suspend(id: string) {
    return prisma.doctor.update({
      where: { id },
      data: { isSuspended: true },
    });
  }

  async unsuspend(id: string) {
    return prisma.doctor.update({
      where: { id },
      data: { isSuspended: false },
    });
  }

  async setSpecialties(doctorId: string, specialtyIds: string[]) {
    await prisma.doctorSpecialty.deleteMany({ where: { doctorId } });
    if (specialtyIds.length > 0) {
      await prisma.doctorSpecialty.createMany({
        data: specialtyIds.map(specialtyId => ({ doctorId, specialtyId })),
      });
    }
  }

  // NEW: Update booking availability
  async updateBookingAvailability(id: string, data: {
    isAvailableForBooking: boolean;
    messageForUser?: string | null;
  }) {
    return prisma.doctor.update({
      where: { id },
      data: {
        isAvailableForBooking: data.isAvailableForBooking,
        messageForUser: data.messageForUser ?? null,
      },
      include: { 
        wilaya: true, 
        baladya: true, 
        specialties: { include: { specialty: true } },
        logos: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });
  }
}

export const doctorRepository = new DoctorRepository();

