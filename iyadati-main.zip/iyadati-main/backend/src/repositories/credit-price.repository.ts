import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';

export class CreditPriceRepository {
  /**
   * Get current price with fallback to default (500 DZD)
   * ✅ Supports transaction client
   */
  async getCurrentPrice(tx?: Prisma.TransactionClient): Promise<number> {
    const client = tx || prisma;
    
    const latest = await client.creditPrice.findFirst({
      orderBy: { createdAt: 'desc' }
    });

    if (!latest) {
      const created = await client.creditPrice.create({
        data: { price: 500 } // ✅ Consistent default with getLatest()
      });
      return created.price;
    }

    return latest.price;
  }

  /**
   * Get the latest CreditPrice record
   * ✅ Supports transaction client
   * ✅ Consistent default (500 DZD)
   */
  async getLatest(tx?: Prisma.TransactionClient): Promise<any> {
    const client = tx || prisma;
    
    const latest = await client.creditPrice.findFirst({
      orderBy: { createdAt: 'desc' }
    });

    if (!latest) {
      return await client.creditPrice.create({
        data: { price: 500 } // ✅ Consistent with getCurrentPrice()
      });
    }

    return latest;
  }

  /**
   * Get all credit prices (history)
   */
  async getAll(): Promise<any[]> {
    return await prisma.creditPrice.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Create a new credit price
   * ✅ Supports transaction client
   */
  async updatePrice(price: number, tx?: Prisma.TransactionClient): Promise<any> {
    const client = tx || prisma;
    return await client.creditPrice.create({
      data: { price }
    });
  }

  /**
   * Get price history with limit
   */
  async getHistory(limit: number = 10): Promise<any[]> {
    return await prisma.creditPrice.findMany({
      orderBy: { createdAt: 'desc' },
      take: limit
    });
  }
}

export const creditPriceRepository = new CreditPriceRepository();

