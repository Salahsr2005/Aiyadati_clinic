import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateSellerDocumentDTO {
  userId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  docType?: string;
}

interface UpdateSellerDocumentDTO {
  docType?: string;
}

class SellerDocumentRepository extends BaseRepository<any> {
  protected modelName = 'sellerDocument';

  async findByUserId(userId: string) {
    return this.prisma.sellerDocument.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.sellerDocument.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.sellerDocument.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateSellerDocumentDTO) {
    return this.prisma.sellerDocument.create({
      data: {
        userId: data.userId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        docType: data.docType || 'license',
        storageType: 'private',
      },
    });
  }

  async update(id: string, data: UpdateSellerDocumentDTO) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    return this.prisma.sellerDocument.delete({ where: { id } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.sellerDocument.delete({ where: { fileId } });
  }

  async verify(id: string, adminId: string) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data: {
        isVerified: true,
        verifiedBy: adminId,
        verifiedAt: new Date(),
      },
    });
  }

  async unverify(id: string) {
    return this.prisma.sellerDocument.update({
      where: { id },
      data: {
        isVerified: false,
        verifiedBy: null,
        verifiedAt: null,
      },
    });
  }
}

export const sellerDocumentRepository = new SellerDocumentRepository();

