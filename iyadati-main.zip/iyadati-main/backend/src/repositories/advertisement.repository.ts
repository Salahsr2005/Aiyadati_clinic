import { prisma } from '../core/utils/prisma';
import { Prisma, AdPosition, AdStatus, AdLanguage } from '@prisma/client';

export class AdvertisementRepository {
  async findActiveAds(params: {
    position?: AdPosition;
    wilayaId?: string;
    audience?: string;
    language?: AdLanguage;
    limit?: number;
  }) {
    const { position, wilayaId, audience, language, limit = 10 } = params;

    const where: Prisma.AdvertisementWhereInput = {
      isActive: true,
      status: AdStatus.ACTIVE,
      deletedAt: null,
      AND: [
        {
          OR: [
            { startsAt: null },
            { startsAt: { lte: new Date() } }
          ]
        },
        {
          OR: [
            { expiresAt: null },
            { expiresAt: { gte: new Date() } }
          ]
        }
      ]
    };

    if (position) {
      where.position = position;
    }

    if (language) {
      where.language = language;
    }

    if (audience) {
      where.targetAudience = {
        has: audience
      };
    }

    if (wilayaId) {
      where.AND = [
        ...(where.AND as any[] || []),
        {
          OR: [
            { targetWilayas: { isEmpty: true } },
            { targetWilayas: { has: wilayaId } }
          ]
        }
      ];
    }

    return prisma.advertisement.findMany({
      where,
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
      take: limit,
    });
  }

  async findById(id: string) {
    return prisma.advertisement.findUnique({
      where: { id },
    });
  }

  async findByFileId(fileId: string) {
    return prisma.advertisement.findUnique({
      where: { fileId },
    });
  }

  async create(data: Prisma.AdvertisementCreateInput) {
    return prisma.advertisement.create({
      data,
    });
  }

  async update(id: string, data: Prisma.AdvertisementUpdateInput) {
    return prisma.advertisement.update({
      where: { id },
      data,
    });
  }

  async softDelete(id: string, deletedBy: string) {
    return prisma.advertisement.update({
      where: { id },
      data: {
        isActive: false,
        status: AdStatus.ARCHIVED,
        deletedAt: new Date(),
        deletedBy,
      },
    });
  }

  async incrementViewCount(id: string) {
    return prisma.advertisement.update({
      where: { id },
      data: {
        viewCount: { increment: 1 },
      },
    });
  }

  async incrementClickCount(id: string) {
    return prisma.advertisement.update({
      where: { id },
      data: {
        clickCount: { increment: 1 },
      },
    });
  }

  async findAll(params: {
    page?: number;
    limit?: number;
    status?: AdStatus;
    language?: AdLanguage;
    search?: string;
  }) {
    const { page = 1, limit = 10, status, language, search } = params;
    const skip = (page - 1) * limit;

    const where: Prisma.AdvertisementWhereInput = {};

    if (status) {
      where.status = status;
    }

    if (language) {
      where.language = language;
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { titleAr: { contains: search, mode: 'insensitive' } },
        { titleFr: { contains: search, mode: 'insensitive' } },
        { titleEn: { contains: search, mode: 'insensitive' } },
        { descriptionAr: { contains: search, mode: 'insensitive' } },
        { descriptionFr: { contains: search, mode: 'insensitive' } },
        { descriptionEn: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [items, total] = await Promise.all([
      prisma.advertisement.findMany({
        where,
        orderBy: [{ createdAt: 'desc' }],
        skip,
        take: limit,
      }),
      prisma.advertisement.count({ where }),
    ]);

    return { items, total };
  }
}

export const advertisementRepository = new AdvertisementRepository();

