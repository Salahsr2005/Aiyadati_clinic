import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateFileRegistryDTO {
  fileId: string;
  storageKey: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  filePath: string;
  mimeType: string;
  storageType: string;
  category: string;
  ownerId: string;
  ownerType: string;
  tableName: string;
  tableId: string;
  metadata?: any;
  expiresAt?: Date;
}

interface FileSearchFilters {
  ownerId?: string;
  ownerType?: string;
  storageType?: string;
  category?: string;
  fileName?: string;
  fromDate?: Date;
  toDate?: Date;
}

class FileRegistryRepository extends BaseRepository<any> {
  protected modelName = 'fileRegistry';

  async create(data: CreateFileRegistryDTO) {
    return this.prisma.fileRegistry.create({
      data: {
        fileId: data.fileId,
        storageKey: data.storageKey,
        fileName: data.fileName,
        fileType: data.fileType,
        fileSize: data.fileSize,
        filePath: data.filePath,
        mimeType: data.mimeType,
        storageType: data.storageType,
        category: data.category,
        ownerId: data.ownerId,
        ownerType: data.ownerType,
        tableName: data.tableName,
        tableId: data.tableId,
        metadata: data.metadata,
        expiresAt: data.expiresAt,
      },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.fileRegistry.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.fileRegistry.findUnique({
      where: { storageKey },
    });
  }

  async findByOwner(ownerId: string, ownerType: string) {
    return this.prisma.fileRegistry.findMany({
      where: {
        ownerId,
        ownerType,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async search(filters: FileSearchFilters) {
    const where: any = {};

    if (filters.ownerId) where.ownerId = filters.ownerId;
    if (filters.ownerType) where.ownerType = filters.ownerType;
    if (filters.storageType) where.storageType = filters.storageType;
    if (filters.category) where.category = filters.category;
    if (filters.fileName) {
      where.fileName = {
        contains: filters.fileName,
        mode: 'insensitive',
      };
    }
    if (filters.fromDate || filters.toDate) {
      where.createdAt = {};
      if (filters.fromDate) where.createdAt.gte = filters.fromDate;
      if (filters.toDate) where.createdAt.lte = filters.toDate;
    }

    return this.prisma.fileRegistry.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  async delete(id: string) {
    return this.prisma.fileRegistry.delete({ where: { id } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.fileRegistry.delete({ where: { fileId } });
  }

  async deleteByOwner(ownerId: string, ownerType: string) {
    return this.prisma.fileRegistry.deleteMany({
      where: {
        ownerId,
        ownerType,
      },
    });
  }

  async incrementAccessCount(fileId: string): Promise<void> {
    await this.prisma.fileRegistry.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }

  async findExpiredFiles() {
    return this.prisma.fileRegistry.findMany({
      where: {
        expiresAt: {
          lte: new Date(),
        },
      },
    });
  }
}

export const fileRegistryRepository = new FileRegistryRepository();

