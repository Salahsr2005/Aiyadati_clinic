import { prisma } from '../core/utils/prisma';

export class UserDeviceRepository {
  async findByUserId(userId: string) {
    return prisma.userDevice.findMany({
      where: { userId, isActive: true },
    });
  }

  async upsert(userId: string, deviceToken: string, platform: string) {
    return prisma.userDevice.upsert({
      where: { userId_deviceToken: { userId, deviceToken } },
      create: { userId, deviceToken, platform },
      update: { isActive: true, platform, updatedAt: new Date() },
    });
  }

  async deactivate(userId: string, deviceToken: string) {
    return prisma.userDevice.updateMany({
      where: { userId, deviceToken },
      data: { isActive: false },
    });
  }
}

export const userDeviceRepository = new UserDeviceRepository();

