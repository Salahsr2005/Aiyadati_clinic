import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateDoctorLogoDTO {
  doctorId: string;
  filePath: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
}

class DoctorLogoRepository extends BaseRepository<any> {
  protected modelName = 'doctorLogo';

  /**
   * Find logo by doctor ID (returns the most recent one)
   */
  async findByDoctorId(doctorId: string) {
    return this.prisma.doctorLogo.findFirst({
      where: { doctorId },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Find logo by fileId (for file service)
   */
  async findByFileId(fileId: string) {
    return this.prisma.doctorLogo.findUnique({
      where: { fileId },
    });
  }

  /**
   * Find logo by storageKey
   */
  async findByStorageKey(storageKey: string) {
    return this.prisma.doctorLogo.findUnique({
      where: { storageKey },
    });
  }

  /**
   * Create a new doctor logo
   */
  async create(data: CreateDoctorLogoDTO) {
    return this.prisma.doctorLogo.create({
      data: {
        doctorId: data.doctorId,
        filePath: data.filePath,
        fileName: data.fileName,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        storageType: 'public',
      },
    });
  }

  /**
   * Delete a logo
   */
  async delete(id: string) {
    return this.prisma.doctorLogo.delete({
      where: { id },
    });
  }

  /**
   * Delete logo by fileId
   */
  async deleteByFileId(fileId: string) {
    return this.prisma.doctorLogo.delete({
      where: { fileId },
    });
  }

  /**
   * Delete all logos for a doctor
   */
  async deleteByDoctorId(doctorId: string) {
    return this.prisma.doctorLogo.deleteMany({
      where: { doctorId },
    });
  }

  /**
   * Increment access count (for file service)
   */
  async incrementAccessCount(fileId: string): Promise<void> {
    await this.prisma.doctorLogo.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }
}

export const doctorLogoRepository = new DoctorLogoRepository();

