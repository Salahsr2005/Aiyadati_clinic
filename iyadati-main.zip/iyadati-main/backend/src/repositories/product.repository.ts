import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';
import { ProductStatus } from '@prisma/client';

interface CreateProductDTO {
  sellerId: string;
  categoryId: string;
  titleFr: string;
  titleAr: string;
  descriptionFr?: string;
  descriptionAr?: string;
  price: number;
  comparePrice?: number;
  stock: number;
  sku?: string;
}

interface UpdateProductDTO {
  titleFr?: string;
  titleAr?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  price?: number;
  comparePrice?: number | null;
  stock?: number;
  sku?: string;
  status?: ProductStatus;
  categoryId?: string;
}

interface ProductFilters {
  sellerId?: string;
  categoryId?: string;
  status?: ProductStatus;
  isApproved?: boolean;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

class ProductRepository extends BaseRepository<any> {
  protected modelName = 'product';

  async findAll(filters: ProductFilters) {
        const {
        sellerId,
        categoryId,
        status,
        isApproved,
        search,
        minPrice,
        maxPrice,
        inStock,
        page: rawPage = 1,
        limit: rawLimit = 20,
        sortBy = 'createdAt',
        sortOrder = 'desc',
        } = filters;

    const page = Number(rawPage);
    const limit = Number(rawLimit);
    const where: any = {};

    if (sellerId) where.sellerId = sellerId;
    if (categoryId) where.categoryId = categoryId;
    if (status) where.status = status;
    if (isApproved !== undefined) {
      where.isApproved = isApproved;
    } else {
      // By default, only show approved products to public
      where.isApproved = true;
    }

    // Include subcategories when filtering by category
    if (categoryId) {
      const subcategories = await this.getSubcategoryIds(categoryId);
      where.categoryId = { in: [categoryId, ...subcategories] };
    }

    if (search) {
      where.OR = [
        { titleFr: { contains: search, mode: 'insensitive' } },
        { titleAr: { contains: search, mode: 'insensitive' } },
        { descriptionFr: { contains: search, mode: 'insensitive' } },
        { descriptionAr: { contains: search, mode: 'insensitive' } },
        { sku: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (minPrice !== undefined || maxPrice !== undefined) {
      where.price = {};
      if (minPrice !== undefined) where.price.gte = minPrice;
      if (maxPrice !== undefined) where.price.lte = maxPrice;
    }

    if (inStock) {
      where.stock = { gt: 0 };
    }

    const skip = (page - 1) * limit;

    const [products, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: {
          category: {
            select: { id: true, nameFr: true, nameAr: true, slug: true },
          },
          seller: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
          images: {
            orderBy: [{ isPrimary: 'desc' }, { sortOrder: 'asc' }],
          },
          _count: {
            select: { orderItems: true },
          },
        },
      }),
      this.prisma.product.count({ where }),
    ]);

    return { products, total };
  }

  async findById(id: string) {
    return this.prisma.product.findUnique({
      where: { id },
      include: {
        category: {
          include: {
            parent: {
              select: { id: true, nameFr: true, nameAr: true, slug: true },
            },
          },
        },
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            phone: true,
            wilaya: { select: { id: true, nameFr: true, nameAr: true } },
          },
        },
        images: {
          orderBy: [{ isPrimary: 'desc' }, { sortOrder: 'asc' }],
        },
      },
    });
  }

  async findBySku(sku: string) {
    return this.prisma.product.findUnique({
      where: { sku },
    });
  }

  async create(data: CreateProductDTO) {
    return this.prisma.product.create({
      data: {
        sellerId: data.sellerId,
        categoryId: data.categoryId,
        titleFr: data.titleFr,
        titleAr: data.titleAr,
        descriptionFr: data.descriptionFr,
        descriptionAr: data.descriptionAr,
        price: data.price,
        comparePrice: data.comparePrice,
        stock: data.stock,
        sku: data.sku,
        status: data.stock > 0 ? 'ACTIVE' : 'OUT_OF_STOCK',
      },
      include: {
        category: true,
        images: true,
      },
    });
  }

  async update(id: string, data: UpdateProductDTO) {
    // If stock is being updated, auto-set status
    const updateData: any = { ...data };
    
    if (data.stock !== undefined) {
      if (data.stock === 0) {
        updateData.status = 'OUT_OF_STOCK';
      } else if (data.status !== 'INACTIVE') {
        updateData.status = 'ACTIVE';
      }
    }

    return this.prisma.product.update({
      where: { id },
      data: updateData,
      include: {
        category: true,
        images: {
          orderBy: [{ isPrimary: 'desc' }, { sortOrder: 'asc' }],
        },
      },
    });
  }

  async updateStock(id: string, quantity: number) {
    const product = await this.prisma.product.findUnique({ where: { id } });
    if (!product) throw new Error('Product not found');

    const newStock = product.stock + quantity;
    const newStatus = newStock <= 0 ? 'OUT_OF_STOCK' : product.status === 'OUT_OF_STOCK' ? 'ACTIVE' : product.status;

    return this.prisma.product.update({
      where: { id },
      data: {
        stock: newStock,
        status: newStatus as ProductStatus,
        saleCount: quantity < 0 ? { increment: Math.abs(quantity) } : undefined,
      },
    });
  }

  async approve(id: string, adminId: string) {
    return this.prisma.product.update({
      where: { id },
      data: {
        isApproved: true,
        approvedBy: adminId,
        approvedAt: new Date(),
      },
    });
  }

  async reject(id: string) {
    return this.prisma.product.update({
      where: { id },
      data: {
        isApproved: false,
        approvedBy: null,
        approvedAt: null,
      },
    });
  }

  async incrementViewCount(id: string) {
    return this.prisma.product.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    });
  }

  async findBySellerId(sellerId: string, page = 1, limit = 20) {
    const pageNum = Number(page);
    const limitNum = Number(limit);
    const skip = (pageNum - 1) * limitNum;
    const where = { sellerId };
    
    const [products, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: { createdAt: 'desc' },
        include: {
          category: { select: { id: true, nameFr: true, nameAr: true } },
          images: { take: 1, where: { isPrimary: true } },
        },
      }),
      this.prisma.product.count({ where }),
    ]);

    return { products, total };
  }

  async getLowStock(threshold: number = 5) {
    return this.prisma.product.findMany({
      where: {
        stock: { lte: threshold, gt: 0 },
        status: 'ACTIVE',
      },
      include: {
        seller: { select: { id: true, firstName: true, email: true } },
      },
      orderBy: { stock: 'asc' },
    });
  }

  // Helper: Get all subcategory IDs recursively
  private async getSubcategoryIds(categoryId: string): Promise<string[]> {
    const children = await this.prisma.category.findMany({
      where: { parentId: categoryId },
      select: { id: true },
    });

    const ids = children.map(c => c.id);
    
    for (const child of children) {
      const subIds = await this.getSubcategoryIds(child.id);
      ids.push(...subIds);
    }

    return ids;
  }
}

export const productRepository = new ProductRepository();

