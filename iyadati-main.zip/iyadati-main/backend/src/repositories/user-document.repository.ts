import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

// ============================================================
// ENUMS
// ============================================================

export enum DocumentVisibility {
  ACTIVE = 'active',
  DELETED = 'deleted',
  ALL = 'all',
}

// ============================================================
// DTOs
// ============================================================

interface CreateUserDocumentDTO {
  userId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  docType?: string;
  title?: string;
  description?: string;
  docDate?: Date;
  tags?: string[];
  storageType?: 'public' | 'private';
  category?: string;
  expiresAt?: Date;
  appointmentId?: string;
  isShared?: boolean;
  sharedWith?: string[];
}

interface UpdateUserDocumentDTO {
  title?: string;
  description?: string;
  docDate?: Date;
  tags?: string[];
  isShared?: boolean;
  sharedWith?: string[];
}

interface SoftDeleteUserDocumentDTO {
  deletedById: string;
  deletedByType: string; // 'patient', 'doctor', 'admin', 'system'
  reason?: string;
}

// ============================================================
// REPOSITORY
// ============================================================

class UserDocumentRepository extends BaseRepository<any> {
  protected modelName = 'userDocument';

  // ============================================================
  // READ OPERATIONS
  // ============================================================

  /**
   * Find documents by user ID with pagination and filters
   */
  async findByUserId(
    userId: string,
    page = 1,
    limit = 10,
    filters?: {
      docType?: string;
      storageType?: string;
      visibility?: DocumentVisibility;
      tag?: string;
    }
  ) {
    const skip = (page - 1) * limit;
    const where: any = { userId };

    // Filter by visibility (soft delete)
    if (filters?.visibility === DocumentVisibility.ACTIVE) {
      where.deletedAt = null;
    } else if (filters?.visibility === DocumentVisibility.DELETED) {
      where.deletedAt = { not: null };
    }
    // ALL = no filter

    if (filters?.docType) where.docType = filters.docType;
    if (filters?.storageType) where.storageType = filters.storageType;

    if (filters?.tag) {
      where.tags = { has: filters.tag };
    }

    const [documents, total] = await Promise.all([
      this.prisma.userDocument.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.userDocument.count({ where }),
    ]);

    return { documents, total };
  }

  /**
   * Find document by ID (only active/undeleted)
   */
  async findById(id: string) {
    return this.prisma.userDocument.findUnique({
      where: { id },
    });
  }

  /**
   * Find document by ID (including deleted)
   */
  async findByIdWithDeleted(id: string) {
    return this.prisma.userDocument.findUnique({
      where: { id },
    });
  }

  /**
   * Find document by fileId (UUID)
   */
  async findByFileId(fileId: string) {
    return this.prisma.userDocument.findUnique({
      where: { fileId },
    });
  }

  /**
   * Find document by storageKey
   */
  async findByStorageKey(storageKey: string) {
    return this.prisma.userDocument.findUnique({
      where: { storageKey },
    });
  }

  /**
   * Find documents by appointment ID
   */
  async findByAppointmentId(appointmentId: string) {
    return this.prisma.userDocument.findMany({
      where: {
        appointmentId,
        deletedAt: null,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Find documents by tags (PostgreSQL array contains)
   */
  async findByTags(userId: string, tags: string[]) {
    return this.prisma.userDocument.findMany({
      where: {
        userId,
        tags: { hasSome: tags },
        deletedAt: null,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  // ============================================================
  // SHARED DOCUMENTS
  // ============================================================

  /**
   * Find documents shared with a specific doctor
   */
  async findBySharedWithDoctor(patientId: string, doctorId: string) {
    return this.prisma.userDocument.findMany({
      where: {
        userId: patientId,
        sharedWith: { has: doctorId },
        deletedAt: null,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  // ============================================================
  // UPLOADER INFORMATION
  // ============================================================

  /**
   * Get documents with uploader info
   * Uses sharedWith to determine if a doctor uploaded it
   */
  async findWithUploaderInfo(userId: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;

    const [documents, total] = await Promise.all([
      this.prisma.userDocument.findMany({
        where: {
          userId,
          deletedAt: null,
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.userDocument.count({
        where: {
          userId,
          deletedAt: null,
        },
      }),
    ]);

    return { documents, total };
  }

  /**
   * Get all doctors who have access to a patient's documents
   * (This implies they either uploaded or were shared with)
   */
  async findAccessingDoctors(patientId: string) {
    const documents = await this.prisma.userDocument.findMany({
      where: {
        userId: patientId,
        sharedWith: { isEmpty: false },
        deletedAt: null,
      },
      select: {
        sharedWith: true,
      },
    });

    const doctorIds = new Set<string>();
    documents.forEach((doc) => {
      if (doc.sharedWith) {
        doc.sharedWith.forEach((id) => doctorIds.add(id));
      }
    });

    return Array.from(doctorIds);
  }

  /**
   * Count documents shared with a specific doctor
   */
  async countSharedWithDoctor(patientId: string, doctorId: string) {
    return this.prisma.userDocument.count({
      where: {
        userId: patientId,
        sharedWith: { has: doctorId },
        deletedAt: null,
      },
    });
  }

  // ============================================================
  // CREATE OPERATIONS
  // ============================================================

  /**
   * Create a new document
   */
  async create(data: CreateUserDocumentDTO) {
    return this.prisma.userDocument.create({
      data: {
        userId: data.userId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        docType: data.docType || 'other',
        title: data.title,
        description: data.description,
        docDate: data.docDate,
        tags: data.tags || [],
        storageType: data.storageType || 'private',
        category: data.category || 'document',
        expiresAt: data.expiresAt,
        appointmentId: data.appointmentId,
        isShared: data.isShared || false,
        sharedWith: data.sharedWith || [],
        // Soft delete fields (default to null)
        deletedAt: null,
        deletedById: null,
        deletedByType: null,
        deletedReason: null,
      },
    });
  }

  // ============================================================
  // UPDATE OPERATIONS
  // ============================================================

  /**
   * Update document metadata
   */
  async update(id: string, data: UpdateUserDocumentDTO) {
    const updateData: any = {};

    if (data.title !== undefined) updateData.title = data.title;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.docDate !== undefined) updateData.docDate = data.docDate;
    if (data.tags !== undefined) updateData.tags = data.tags;
    if (data.isShared !== undefined) updateData.isShared = data.isShared;
    if (data.sharedWith !== undefined) updateData.sharedWith = data.sharedWith;

    return this.prisma.userDocument.update({
      where: { id },
      data: updateData,
    });
  }

  // ============================================================
  // SOFT DELETE OPERATIONS
  // ============================================================

  /**
   * Soft delete a document (patient or admin only)
   */
  async softDelete(id: string, data: SoftDeleteUserDocumentDTO) {
    return this.prisma.userDocument.update({
      where: { id },
      data: {
        deletedAt: new Date(),
        deletedById: data.deletedById,
        deletedByType: data.deletedByType,
        deletedReason: data.reason || null,
        isShared: false, // Remove from sharing when deleted
      },
    });
  }

  /**
   * Restore a soft-deleted document (admin only)
   */
  async restore(id: string) {
    return this.prisma.userDocument.update({
      where: { id },
      data: {
        deletedAt: null,
        deletedById: null,
        deletedByType: null,
        deletedReason: null,
      },
    });
  }

  // ============================================================
  // HARD DELETE (Admin Only - Use with extreme caution)
  // ============================================================

  /**
   * Permanently delete a document (admin only)
   * WARNING: This cannot be undone!
   */
  async hardDelete(id: string) {
    return this.prisma.userDocument.delete({ where: { id } });
  }

  // ============================================================
  // SHARING OPERATIONS
  // ============================================================

  /**
   * Share a document with a doctor
   */
  async shareWithDoctor(documentId: string, doctorId: string) {
    const doc = await this.prisma.userDocument.findUnique({
      where: { id: documentId },
      select: { sharedWith: true },
    });

    if (!doc) throw new Error('Document not found');

    const sharedWith = doc.sharedWith || [];
    if (!sharedWith.includes(doctorId)) {
      sharedWith.push(doctorId);
    }

    return this.prisma.userDocument.update({
      where: { id: documentId },
      data: {
        sharedWith,
        isShared: true,
      },
    });
  }

  /**
   * Remove a doctor's access to a document
   */
  async unshareWithDoctor(documentId: string, doctorId: string) {
    const doc = await this.prisma.userDocument.findUnique({
      where: { id: documentId },
      select: { sharedWith: true },
    });

    if (!doc) throw new Error('Document not found');

    const sharedWith = (doc.sharedWith || []).filter((id) => id !== doctorId);

    return this.prisma.userDocument.update({
      where: { id: documentId },
      data: {
        sharedWith,
        isShared: sharedWith.length > 0,
      },
    });
  }

  // ============================================================
  // DOCUMENT COUNT
  // ============================================================

  /**
   * Count total active documents for a user
   */
  async countDocuments(userId: string) {
    return this.prisma.userDocument.count({
      where: {
        userId,
        deletedAt: null,
      },
    });
  }

  /**
   * Count documents by type for a user
   */
  async countDocumentsByType(userId: string, docType: string) {
    return this.prisma.userDocument.count({
      where: {
        userId,
        docType,
        deletedAt: null,
      },
    });
  }

  // ============================================================
  // BULK OPERATIONS (Use with caution)
  // ============================================================

  /**
   * Soft delete all documents for a user (account deletion)
   * WARNING: Use with caution
   */
  async softDeleteByUserId(userId: string, data: SoftDeleteUserDocumentDTO) {
    return this.prisma.userDocument.updateMany({
      where: {
        userId,
        deletedAt: null,
      },
      data: {
        deletedAt: new Date(),
        deletedById: data.deletedById,
        deletedByType: data.deletedByType,
        deletedReason: data.reason || 'Account deletion',
        isShared: false,
      },
    });
  }
}

export const userDocumentRepository = new UserDocumentRepository();

