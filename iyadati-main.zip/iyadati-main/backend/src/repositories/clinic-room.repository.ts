import { prisma } from '../core/utils/prisma';

export class ClinicRoomRepository {
  async findByClinicId(clinicId: string) {
    return prisma.clinicRoom.findMany({
      where: { clinicId, isActive: true },
      orderBy: { name: 'asc' },
    });
  }

  async findById(id: string) {
    return prisma.clinicRoom.findUnique({ where: { id } });
  }

  async create(data: { clinicId: string; name: string; specialtyId?: string }) {
    return prisma.clinicRoom.create({ data });
  }

  async update(id: string, data: { name?: string; specialtyId?: string | null; isActive?: boolean }) {
    return prisma.clinicRoom.update({ where: { id }, data });
  }

  async softDelete(id: string) {
    return prisma.clinicRoom.update({ where: { id }, data: { isActive: false } });
  }
}

export const clinicRoomRepository = new ClinicRoomRepository();

