import { prisma } from '../core/utils/prisma';

export class WalletRepository {
  async findByUserId(userId: string) {
    return prisma.userWallet.findUnique({
      where: { userId },
      include: { transactions: { orderBy: { createdAt: 'desc' }, take: 10 } },
    });
  }

  async findById(id: string) {
    return prisma.userWallet.findUnique({ where: { id } });
  }

  async create(userId: string) {
    return prisma.userWallet.create({ data: { userId, credits: 0 } });
  }

  async getOrCreate(userId: string) {
    const existing = await this.findByUserId(userId);
    if (existing) return existing;
    return this.create(userId);
  }

  async addCredits(walletId: string, amount: number) {
    return prisma.userWallet.update({
      where: { id: walletId },
      data: { credits: { increment: amount } },
    });
  }

  async deductCredits(walletId: string, amount: number) {
    return prisma.userWallet.update({
      where: { id: walletId },
      data: { credits: { decrement: amount } },
    });
  }

  async createTransaction(data: {
    walletId: string;
    amount: number;
    type: string;
    description?: string;
    referenceId?: string;
    senderId?: string;        // ← ADDED
    performedBy?: string;
  }) {
    return prisma.creditTransaction.create({ data });
  }

  // ADD THIS NEW METHOD — atomic P2P transfer
  async createTransfer(params: {
    senderWalletId: string;
    senderUserId: string;
    receiverWalletId: string;
    receiverUserId: string;
    amount: number;
  }) {
    const { senderWalletId, senderUserId, receiverWalletId, receiverUserId, amount } = params;
    const transferId = crypto.randomUUID(); // Links both transaction rows

    return prisma.$transaction(async (tx) => {
      // 1. Deduct from sender
      const senderWallet = await tx.userWallet.update({
        where: { id: senderWalletId },
        data: { credits: { decrement: amount } },
      });

      // 2. Fail if insufficient credits (shouldn't happen if validated before, but safety)
      if (senderWallet.credits < 0) {
        throw new Error('INSUFFICIENT_CREDITS');
      }

      // 3. Credit receiver
      await tx.userWallet.update({
        where: { id: receiverWalletId },
        data: { credits: { increment: amount } },
      });

      // 4. Create sender's transaction record
      const sentTx = await tx.creditTransaction.create({
        data: {
          walletId: senderWalletId,
          amount: -amount,
          type: 'transfer_sent',
          description: `Sent ${amount} credits`,
          referenceId: transferId,
          senderId: senderUserId,
        },
      });

      // 5. Create receiver's transaction record
      const receivedTx = await tx.creditTransaction.create({
        data: {
          walletId: receiverWalletId,
          amount: amount,
          type: 'transfer_received',
          description: `Received ${amount} credits`,
          referenceId: transferId,
          senderId: senderUserId,
        },
      });

      return { sentTx, receivedTx, transferId };
    });
  }


  async getTransactions(params: {
    page?: number;
    limit?: number;
    walletId?: string;
    type?: string;
  }) {
    const { page = 1, limit = 20, walletId, type } = params;
    const where: any = {};
    if (walletId) where.walletId = walletId;
    if (type) where.type = type;

    const skip = (page - 1) * limit;
    const [transactions, total] = await Promise.all([
      prisma.creditTransaction.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { wallet: { include: { user: { select: { id: true, email: true, firstName: true, lastName: true } } } } },
      }),
      prisma.creditTransaction.count({ where }),
    ]);

    return { transactions, total };
  }
}

export const walletRepository = new WalletRepository();

