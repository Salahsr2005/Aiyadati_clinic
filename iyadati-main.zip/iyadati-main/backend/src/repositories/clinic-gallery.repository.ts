import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateClinicGalleryDTO {
  clinicId: string;
  imagePath: string;
  filePath: string; 
  fileName: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  captionFr?: string;
  captionAr?: string;
  sortOrder?: number;
}

interface UpdateClinicGalleryDTO {
  captionFr?: string;
  captionAr?: string;
  sortOrder?: number;
  isActive?: boolean;
}

class ClinicGalleryRepository extends BaseRepository<any> {
  protected modelName = 'clinicGallery';

  async findByClinicId(clinicId: string, includeInactive = false) {
    const where: any = { clinicId };
    if (!includeInactive) where.isActive = true;

    return this.prisma.clinicGallery.findMany({
      where,
      orderBy: { sortOrder: 'asc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.clinicGallery.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.clinicGallery.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateClinicGalleryDTO) {
    return this.prisma.clinicGallery.create({
      data: {
        clinicId: data.clinicId,
        imagePath: data.imagePath,
        filePath: data.filePath,      // ✅ NEW: Store full relative path
        fileName: data.fileName,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        captionFr: data.captionFr,
        captionAr: data.captionAr,
        sortOrder: data.sortOrder || 0,
        storageType: 'public', // Gallery is always public
      },
    });
  }

  async update(id: string, data: UpdateClinicGalleryDTO) {
    return this.prisma.clinicGallery.update({
      where: { id },
      data,
    });
  }

  async softDelete(id: string) {
    return this.prisma.clinicGallery.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async delete(id: string) {
    return this.prisma.clinicGallery.delete({ where: { id } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.clinicGallery.delete({ where: { fileId } });
  }

  async getMaxSortOrder(clinicId: string): Promise<number> {
    const result = await this.prisma.clinicGallery.findFirst({
      where: { clinicId },
      orderBy: { sortOrder: 'desc' },
      select: { sortOrder: true },
    });
    return result?.sortOrder ?? 0;
  }

  async reorder(clinicId: string, orderedIds: string[]) {
    // Update sortOrder for each image
    const updates = orderedIds.map((id, index) =>
      this.prisma.clinicGallery.update({
        where: { id },
        data: { sortOrder: index },
      })
    );
    await this.prisma.$transaction(updates);
  }


  async incrementAccessCount(fileId: string): Promise<void> {
    await this.prisma.clinicGallery.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }
}

export const clinicGalleryRepository = new ClinicGalleryRepository();

