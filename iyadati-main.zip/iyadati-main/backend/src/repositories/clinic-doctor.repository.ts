import { prisma } from '../core/utils/prisma';

export class ClinicDoctorRepository {
  async findByClinicAndDoctor(clinicId: string, doctorId: string) {
    return prisma.clinicDoctor.findUnique({
      where: { clinicId_doctorId: { clinicId, doctorId } },
      include: { clinic: true, doctor: true },
    });
  }

  async findById(id: string) {
    return prisma.clinicDoctor.findUnique({
      where: { id },
      include: { clinic: true, doctor: true },
    });
  }

  async findByClinicId(clinicId: string, status?: string) {
    const where: any = { clinicId, isActive: true };
    if (status) where.status = status;
    
    return prisma.clinicDoctor.findMany({
      where,
      include: {
        doctor: {
          include: { specialties: { include: { specialty: true } }, wilaya: true },
        },
      },
      orderBy: { joinedAt: 'desc' },
    });
  }

  async findByDoctorId(doctorId: string, status?: string) {
    const where: any = { doctorId, isActive: true };
    if (status) where.status = status;
    
    return prisma.clinicDoctor.findMany({
      where,
      include: { clinic: true },
      orderBy: { joinedAt: 'desc' },
    });
  }

  async create(data: { clinicId: string; doctorId: string; invitedBy: string }) {
    return prisma.clinicDoctor.create({
      data: {
        ...data,
        status: 'PENDING',
      },
      include: { clinic: true, doctor: true },
    });
  }

  async updateStatus(id: string, status: string) {
    return prisma.clinicDoctor.update({
      where: { id },
      data: { status: status as any },
      include: { clinic: true, doctor: true },
    });
  }

  async remove(id: string) {
    return prisma.clinicDoctor.update({
      where: { id },
      data: { isActive: false },
    });
  }
}

export const clinicDoctorRepository = new ClinicDoctorRepository();

