import { prisma } from '../core/utils/prisma';

export class ClinicReviewRepository {
  async findByClinicId(clinicId: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [reviews, total] = await Promise.all([
      prisma.clinicReview.findMany({
        where: { clinicId },
        skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: { patient: { select: { id: true, firstName: true, lastName: true } } },
      }),
      prisma.clinicReview.count({ where: { clinicId } }),
    ]);
    return { reviews, total };
  }

  async findByClinicAndPatient(clinicId: string, patientId: string) {
    return prisma.clinicReview.findUnique({
      where: { clinicId_patientId: { clinicId, patientId } },
    });
  }

  async upsert(clinicId: string, patientId: string, data: { rating?: number; review?: string }) {
    return prisma.clinicReview.upsert({
      where: { clinicId_patientId: { clinicId, patientId } },
      create: { clinicId, patientId, ...data },
      update: data,
    });
  }

  async delete(clinicId: string, patientId: string) {
    return prisma.clinicReview.delete({
      where: { clinicId_patientId: { clinicId, patientId } },
    });
  }

  async updateAvgRating(clinicId: string) {
    const result = await prisma.clinicReview.aggregate({
      where: { clinicId, rating: { not: null } },
      _avg: { rating: true },
      _count: { rating: true },
    });

    const avgRating = result._avg.rating
      ? Math.round(result._avg.rating * 10) / 10
      : null;

    await prisma.clinic.update({
      where: { id: clinicId },
      data: {
        avgRating,
        totalReviews: result._count.rating,
      },
    });
  }
}

export const clinicReviewRepository = new ClinicReviewRepository();

