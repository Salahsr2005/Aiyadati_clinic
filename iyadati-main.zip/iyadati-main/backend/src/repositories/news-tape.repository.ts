// backend/src/repositories/news-tape.repository.ts
import { prisma } from '../core/utils/prisma';
import { Prisma, NewsStatus, NewsTargetAudience } from '@prisma/client';

export class NewsTapeRepository {
  /**
   * Find active news for a specific user
   * Logic: If target arrays are empty = ALL, else check specific targets
   */
  async findActiveForUser(params: {
    userId?: string;
    userType: 'PATIENT' | 'DOCTOR' | 'CLINIC' | 'ADMIN' | 'SUPER_ADMIN';
    wilayaId?: string;
    limit?: number;
    page?: number;
  }) {
    const { userId, userType, wilayaId, limit = 10, page = 1 } = params;
    const skip = (page - 1) * limit;

    // Map user type to enum
    const userTypeMap: Record<string, NewsTargetAudience> = {
      'PATIENT': NewsTargetAudience.PATIENTS,
      'DOCTOR': NewsTargetAudience.DOCTORS,
      'CLINIC': NewsTargetAudience.CLINICS,
      'ADMIN': NewsTargetAudience.ADMINS,
      'SUPER_ADMIN': NewsTargetAudience.SUPER_ADMINS,
    };

    // Map user type to ID field
    const userTypeFieldMap: Record<string, string> = {
      'PATIENT': 'targetUserIds',
      'DOCTOR': 'targetDoctorIds',
      'CLINIC': 'targetClinicIds',
      'ADMIN': 'targetUserIds',
      'SUPER_ADMIN': 'targetUserIds',
    };

    // Build targeting conditions
    const targetConditions: Prisma.NewsTapeWhereInput[] = [];

    // Condition 1: Empty targetAudience = ALL
    targetConditions.push({
      targetAudience: { isEmpty: true }
    });

    // Condition 2: Explicit ALL
    targetConditions.push({
      targetAudience: { has: NewsTargetAudience.ALL }
    });

    // Condition 3: Matches user type
    if (userTypeMap[userType]) {
      targetConditions.push({
        targetAudience: { has: userTypeMap[userType] }
      });
    }

    // Condition 4: Specific user ID targeting
    if (userId) {
      const field = userTypeFieldMap[userType];
      if (field) {
        targetConditions.push({
          [field]: { has: userId }
        });
      }
    }

    const where: Prisma.NewsTapeWhereInput = {
      isActive: true,
      status: NewsStatus.ACTIVE,
      deletedAt: null,
      AND: [
        {
          OR: [
            { startsAt: null },
            { startsAt: { lte: new Date() } }
          ]
        },
        {
          OR: [
            { expiresAt: null },
            { expiresAt: { gte: new Date() } }
          ]
        }
      ],
      OR: targetConditions
    };

    // Wilaya filtering: empty = ALL, otherwise check specific
    if (wilayaId) {
      where.AND = [
        ...(where.AND as any[] || []),
        {
          OR: [
            { targetWilayas: { isEmpty: true } },
            { targetWilayas: { has: wilayaId } }
          ]
        }
      ];
    }

    const [items, total] = await Promise.all([
      prisma.newsTape.findMany({
        where,
        orderBy: [
          { priority: 'desc' },
          { createdAt: 'desc' }
        ],
        skip,
        take: limit,
      }),
      prisma.newsTape.count({ where }),
    ]);

    return { items, total, page, limit };
  }

  async findById(id: string) {
    return prisma.newsTape.findUnique({
      where: { id },
    });
  }

  async create(data: Prisma.NewsTapeCreateInput) {
    return prisma.newsTape.create({ data });
  }

  async update(id: string, data: Prisma.NewsTapeUpdateInput) {
    return prisma.newsTape.update({
      where: { id },
      data,
    });
  }

  async softDelete(id: string, deletedBy: string) {
    return prisma.newsTape.update({
      where: { id },
      data: {
        isActive: false,
        status: NewsStatus.ARCHIVED,
        deletedAt: new Date(),
        deletedBy,
      },
    });
  }

  async incrementViewCount(id: string) {
    return prisma.newsTape.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    });
  }

  async findAll(params: {
    page?: number;
    limit?: number;
    status?: NewsStatus;
    search?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      page = 1,
      limit = 10,
      status,
      search,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    const skip = (page - 1) * limit;

    const where: Prisma.NewsTapeWhereInput = {};

    if (status) where.status = status;
    if (search) {
      where.OR = [
        { content: { contains: search, mode: 'insensitive' } },
        { contentAr: { contains: search, mode: 'insensitive' } },
        { contentFr: { contains: search, mode: 'insensitive' } },
        { contentEn: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [items, total] = await Promise.all([
      prisma.newsTape.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip,
        take: limit,
      }),
      prisma.newsTape.count({ where }),
    ]);

    return { items, total, page, limit };
  }

  async getStats() {
    const [total, active, scheduled, expired, archived, draft] = await Promise.all([
      prisma.newsTape.count(),
      prisma.newsTape.count({ 
        where: { 
          status: NewsStatus.ACTIVE, 
          isActive: true,
          deletedAt: null
        } 
      }),
      prisma.newsTape.count({ 
        where: { 
          status: NewsStatus.SCHEDULED,
          deletedAt: null
        } 
      }),
      prisma.newsTape.count({ 
        where: { 
          status: NewsStatus.EXPIRED,
          deletedAt: null
        } 
      }),
      prisma.newsTape.count({ 
        where: { 
          status: NewsStatus.ARCHIVED,
          deletedAt: null
        } 
      }),
      prisma.newsTape.count({ 
        where: { 
          status: NewsStatus.DRAFT,
          deletedAt: null
        } 
      }),
    ]);

    return { total, active, scheduled, expired, archived, draft };
  }

  async getExpiringSoon(days: number = 3) {
    const threshold = new Date();
    threshold.setDate(threshold.getDate() + days);

    return prisma.newsTape.findMany({
      where: {
        isActive: true,
        status: NewsStatus.ACTIVE,
        expiresAt: {
          lte: threshold,
          gte: new Date(),
        },
        deletedAt: null,
      },
      orderBy: { expiresAt: 'asc' },
    });
  }
}

export const newsTapeRepository = new NewsTapeRepository();

