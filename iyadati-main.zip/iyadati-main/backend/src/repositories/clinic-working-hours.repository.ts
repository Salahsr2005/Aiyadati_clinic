import { prisma } from '../core/utils/prisma';

export class ClinicWorkingHoursRepository {
  async findByClinicId(clinicId: string) {
    return prisma.clinicWorkingHours.findMany({
      where: { clinicId },
      orderBy: { dayOfWeek: 'asc' },
    });
  }

  async upsert(
    clinicId: string,
    dayOfWeek: 'SUNDAY' | 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY',
    data: { openTime: Date; closeTime: Date; isOpen: boolean }
  ) {
    return prisma.clinicWorkingHours.upsert({
      where: { clinicId_dayOfWeek: { clinicId, dayOfWeek } },
      create: { clinicId, dayOfWeek, ...data },
      update: data,
    });
  }

  async deleteByClinicId(clinicId: string) {
    return prisma.clinicWorkingHours.deleteMany({ where: { clinicId } });
  }
}

export const clinicWorkingHoursRepository = new ClinicWorkingHoursRepository();

