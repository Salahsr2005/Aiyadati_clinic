import { prisma } from '../core/utils/prisma';

export class PaymentRepository {
  async create(data: {
    userId: string;
    credits: number;
    amount: number;
  }) {
    return prisma.payment.create({ data });
  }

  async findById(id: string) {
    return prisma.payment.findUnique({ where: { id } });
  }

  async updateChargilyInfo(id: string, chargilyId: string, chargilyUrl: string) {
    return prisma.payment.update({
      where: { id },
      data: { chargilyId, chargilyUrl },
    });
  }

  async markAsPaid(id: string, metadata?: any) {
    return prisma.payment.update({
      where: { id },
      data: {
        status: 'PAID',
        metadata: metadata || undefined,
        completedAt: new Date(),
      },
    });
  }

  async markAsFailed(id: string, metadata?: any) {
    return prisma.payment.update({
      where: { id },
      data: {
        status: 'FAILED',
        metadata: metadata || undefined,
      },
    });
  }

  async findByChargilyId(chargilyId: string) {
    return prisma.payment.findFirst({ where: { chargilyId } });
  }

  async findByUserId(userId: string) {
    return prisma.payment.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const paymentRepository = new PaymentRepository();

