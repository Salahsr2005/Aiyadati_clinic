// src/repositories/specialty.repository.ts

import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

class SpecialtyRepository extends BaseRepository<any> {
  protected modelName = 'specialty';

  async findAll(params: {
    page?: number;
    limit?: number;
    search?: string;
    isActive?: boolean;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const { page = 1, limit = 10, search, isActive, sortBy = 'createdAt', sortOrder = 'desc' } = params;

    const where: any = {};
    if (isActive !== undefined) where.isActive = isActive;
    if (search) {
      where.OR = [
        { nameFr: { contains: search, mode: 'insensitive' } },
        { nameAr: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (page - 1) * limit;
    const [specialties, total] = await Promise.all([
      prisma.specialty.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
      }),
      prisma.specialty.count({ where }),
    ]);

    return { specialties, total };
  }

  async findById(id: string) {
    return prisma.specialty.findUnique({ where: { id } });
  }

  async create(data: { 
    nameFr: string; 
    nameAr: string; 
    descriptionFr?: string; 
    descriptionAr?: string;
    imagePath?: string;
    fileId?: string;
  }) {
    return prisma.specialty.create({ data });
  }

  async update(id: string, data: { 
    nameFr?: string; 
    nameAr?: string; 
    descriptionFr?: string; 
    descriptionAr?: string; 
    imagePath?: string;
    fileId?: string;
    isActive?: boolean;
  }) {
    return prisma.specialty.update({ where: { id }, data });
  }

  async softDelete(id: string) {
    return prisma.specialty.update({ where: { id }, data: { isActive: false } });
  }

  async restore(id: string) {
    return prisma.specialty.update({ where: { id }, data: { isActive: true } });
  }
}

export const specialtyRepository = new SpecialtyRepository();

