import { prisma } from '../core/utils/prisma';
import { ConsentLevel } from '@prisma/client';

export class ConsentRepository {
  /**
   * Check if a doctor has consent to access a patient's document
   */
  async checkDocumentAccess(
    patientId: string,
    doctorId: string,
    documentId: string
  ): Promise<{ hasAccess: boolean; level: ConsentLevel | null; reason?: string }> {
    const consent = await prisma.patientDoctorConsent.findUnique({
      where: {
        patientId_doctorId: { patientId, doctorId }
      }
    });

    if (!consent) {
      return { hasAccess: false, level: null, reason: 'No consent found' };
    }

    if (!consent.isActive) {
      return { hasAccess: false, level: null, reason: 'Consent is not active' };
    }

    if (consent.expiresAt && consent.expiresAt < new Date()) {
      return { hasAccess: false, level: null, reason: 'Consent has expired' };
    }

    switch (consent.level) {
      case 'FULL':
        return { hasAccess: true, level: 'FULL' };

      case 'APPOINTMENT_ONLY':
        // Check if document is linked to an appointment with this doctor
        const document = await prisma.userDocument.findUnique({
          where: { id: documentId },
          select: { appointmentId: true }
        });

        if (!document || !document.appointmentId) {
          return { 
            hasAccess: false, 
            level: 'APPOINTMENT_ONLY', 
            reason: 'Document not linked to an appointment' 
          };
        }

        const appointment = await prisma.appointment.findFirst({
          where: {
            id: document.appointmentId,
            doctorId,
            patientId,
            status: { in: ['CONFIRMED', 'COMPLETED'] }
          }
        });

        return {
          hasAccess: !!appointment,
          level: 'APPOINTMENT_ONLY',
          reason: appointment ? undefined : 'No valid appointment found'
        };

      case 'CUSTOM':
        const hasAccess = consent.customDocumentIds.includes(documentId);
        return {
          hasAccess,
          level: 'CUSTOM',
          reason: hasAccess ? undefined : 'Document not in custom list'
        };

      case 'NONE':
        return { hasAccess: false, level: 'NONE', reason: 'Access explicitly denied' };

      default:
        return { hasAccess: false, level: null, reason: 'Unknown consent level' };
    }
  }

  /**
   * Get all consents for a patient (for cache or batch operations)
   */
  async getPatientConsents(patientId: string) {
    return prisma.patientDoctorConsent.findMany({
      where: {
        patientId,
        isActive: true,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      }
    });
  }
}

export const consentRepository = new ConsentRepository();

