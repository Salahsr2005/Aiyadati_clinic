import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateDoctorDocumentDTO {
  doctorId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  docType?: string;
  storageType?: 'public' | 'private';
  category?: string;
  expiresAt?: Date;
}

interface UpdateDoctorDocumentDTO {
  docType?: string;
}

class DoctorDocumentRepository extends BaseRepository<any> {
  protected modelName = 'doctorDocument';

  async findByDoctorId(doctorId: string, filters?: { docType?: string; storageType?: string }) {
    const where: any = { doctorId };

    if (filters?.docType) where.docType = filters.docType;
    if (filters?.storageType) where.storageType = filters.storageType;

    return this.prisma.doctorDocument.findMany({
      where,
      orderBy: { uploadedAt: 'desc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.doctorDocument.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.doctorDocument.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateDoctorDocumentDTO) {
    return this.prisma.doctorDocument.create({
      data: {
        doctorId: data.doctorId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        docType: data.docType || 'other',
        storageType: data.storageType || 'private',
        category: data.category || 'document',
        expiresAt: data.expiresAt,
      },
    });
  }

  async update(id: string, data: UpdateDoctorDocumentDTO) {
    return this.prisma.doctorDocument.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    return this.prisma.doctorDocument.delete({ where: { id } });
  }

  async deleteByDoctorId(doctorId: string) {
    return this.prisma.doctorDocument.deleteMany({ where: { doctorId } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.doctorDocument.delete({ where: { fileId } });
  }

  async findByDocType(doctorId: string, docType: string) {
    return this.prisma.doctorDocument.findMany({
      where: {
        doctorId,
        docType,
      },
      orderBy: { uploadedAt: 'desc' },
    });
  }
}

export const doctorDocumentRepository = new DoctorDocumentRepository();

