import { prisma } from '../core/utils/prisma';

export class ProviderBalanceRepository {
  /**
   * Get or create balance for a provider
   */
  async getOrCreate(providerId: string, providerType: 'DOCTOR' | 'CLINIC') {
    let balance = await prisma.providerBalance.findUnique({
      where: { providerId },
    });

    if (!balance) {
      balance = await prisma.providerBalance.create({
        data: {
          providerId,
          providerType,
          totalEarned: 0,
          totalPaid: 0,
          pendingBalance: 0,
        },
      });
    }

    return balance;
  }

  /**
   * Get balance by provider ID
   */
  async getBalance(providerId: string) {
    return await prisma.providerBalance.findUnique({
      where: { providerId },
    });
  }

  /**
   * Add earnings to provider balance (atomic update)
   */
  async addEarnings(providerId: string, providerType: 'DOCTOR' | 'CLINIC', amount: number) {
    return await prisma.$executeRaw`
      INSERT INTO provider_balances (provider_id, provider_type, total_earned, pending_balance, last_updated)
      VALUES (
        ${providerId}, 
        ${providerType}, 
        ${amount}, 
        ${amount},
        NOW()
      )
      ON CONFLICT (provider_id) DO UPDATE
      SET 
        total_earned = provider_balances.total_earned + ${amount},
        pending_balance = provider_balances.pending_balance + ${amount},
        last_updated = NOW(),
        updated_at = NOW()
    `;
  }

  /**
   * Deduct from pending balance (when paid out)
   */
  async deductPendingBalance(providerId: string, amount: number) {
    const balance = await prisma.providerBalance.findUnique({
      where: { providerId },
    });

    if (!balance) {
      throw new Error('Provider balance not found');
    }

    if (balance.pendingBalance < amount) {
      throw new Error(`Insufficient pending balance. Available: ${balance.pendingBalance}, Requested: ${amount}`);
    }

    return await prisma.providerBalance.update({
      where: { providerId },
      data: {
        pendingBalance: {
          decrement: amount,
        },
        totalPaid: {
          increment: amount,
        },
        lastUpdated: new Date(),
      },
    });
  }

  /**
   * Get all balances (for admin)
   */
  async getAllBalances(options?: {
    providerType?: 'DOCTOR' | 'CLINIC';
    page?: number;
    limit?: number;
  }) {
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (options?.providerType) {
      where.providerType = options.providerType;
    }

    const [items, total] = await Promise.all([
      prisma.providerBalance.findMany({
        where,
        orderBy: { pendingBalance: 'desc' },
        skip,
        take: limit,
      }),
      prisma.providerBalance.count({ where }),
    ]);

    return { items, total, page, limit };
  }

  /**
   * Get total summary (for admin dashboard)
   */
  async getTotalSummary() {
    const summary = await prisma.providerBalance.aggregate({
      _sum: {
        totalEarned: true,
        totalPaid: true,
        pendingBalance: true,
      },
      _count: {
        id: true,
      },
    });

    return {
      totalProviders: summary._count.id || 0,
      totalEarned: summary._sum.totalEarned || 0,
      totalPaid: summary._sum.totalPaid || 0,
      totalPending: summary._sum.pendingBalance || 0,
    };
  }
}

export const providerBalanceRepository = new ProviderBalanceRepository();

