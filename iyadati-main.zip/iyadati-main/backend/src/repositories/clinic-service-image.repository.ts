import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateClinicServiceImageDTO {
  serviceId: string;
  imagePath: string;
  filePath: string;      
  fileName: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  captionFr?: string;
  captionAr?: string;
  sortOrder?: number;
}

interface UpdateClinicServiceImageDTO {
  captionFr?: string;
  captionAr?: string;
  sortOrder?: number;
  isActive?: boolean;
}

class ClinicServiceImageRepository extends BaseRepository<any> {
  protected modelName = 'clinicServiceImage';

  async findByServiceId(serviceId: string, includeInactive = false) {
    const where: any = { serviceId };
    if (!includeInactive) where.isActive = true;

    return this.prisma.clinicServiceImage.findMany({
      where,
      orderBy: { sortOrder: 'asc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.clinicServiceImage.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.clinicServiceImage.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateClinicServiceImageDTO) {
    return this.prisma.clinicServiceImage.create({
      data: {
        serviceId: data.serviceId,
        filePath: data.filePath,
        imagePath: data.imagePath,
        fileName: data.fileName,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        captionFr: data.captionFr,
        captionAr: data.captionAr,
        sortOrder: data.sortOrder || 0,
        storageType: 'public', // Service images are always public
      },
    });
  }

  async update(id: string, data: UpdateClinicServiceImageDTO) {
    return this.prisma.clinicServiceImage.update({
      where: { id },
      data,
    });
  }

  async softDelete(id: string) {
    return this.prisma.clinicServiceImage.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async delete(id: string) {
    return this.prisma.clinicServiceImage.delete({ where: { id } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.clinicServiceImage.delete({ where: { fileId } });
  }

  async deleteByServiceId(serviceId: string) {
    return this.prisma.clinicServiceImage.deleteMany({ where: { serviceId } });
  }

  async getMaxSortOrder(serviceId: string): Promise<number> {
    const result = await this.prisma.clinicServiceImage.findFirst({
      where: { serviceId },
      orderBy: { sortOrder: 'desc' },
      select: { sortOrder: true },
    });
    return result?.sortOrder ?? 0;
  }

  async incrementAccessCount(fileId: string): Promise<void> {
    await this.prisma.clinicServiceImage.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }

}

export const clinicServiceImageRepository = new ClinicServiceImageRepository();

