import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';

export class UserRepository {
  async findById(id: string) {
    return prisma.user.findUnique({
      where: { id },
      include: { wilaya: true },
    });
  }

  async findByEmail(email: string) {
    return prisma.user.findUnique({ where: { email } });
  }

  async findByPhone(phone: string) {
    return prisma.user.findUnique({ where: { phone } });
  }

  async create(data: Prisma.UserCreateInput) {
    return prisma.user.create({ data });
  }

  async update(id: string, data: Prisma.UserUpdateInput) {
    return prisma.user.update({ where: { id }, data });
  }

  async delete(id: string) {
    return prisma.user.delete({ where: { id } });
  }

  async findAllWithFilters(params: {
    search?: string;
    email?: string;
    phone?: string;
    firstName?: string;
    lastName?: string;
    wilayaId?: string;
    isVerified?: boolean;
    isSuspended?: boolean;
    dateOfBirthFrom?: string;
    dateOfBirthTo?: string;
    createdAtFrom?: string;
    createdAtTo?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
      search, email, phone, firstName, lastName, wilayaId,
      isVerified, isSuspended, dateOfBirthFrom, dateOfBirthTo,
      createdAtFrom, createdAtTo, page = 1, limit = 10,
      sortBy = 'createdAt', sortOrder = 'desc',
    } = params;

    const where: any = {};

    // Search by name, email, or phone
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    // Exact filters
    if (email) where.email = { contains: email, mode: 'insensitive' };
    if (phone) where.phone = { contains: phone };
    if (firstName) where.firstName = { contains: firstName, mode: 'insensitive' };
    if (lastName) where.lastName = { contains: lastName, mode: 'insensitive' };
    if (wilayaId) where.wilayaId = wilayaId;
    if (isVerified !== undefined) where.isVerified = isVerified;
    if (isSuspended !== undefined) where.isSuspended = isSuspended;

    // Date range filters
    if (dateOfBirthFrom || dateOfBirthTo) {
      where.dateOfBirth = {};
      if (dateOfBirthFrom) where.dateOfBirth.gte = new Date(dateOfBirthFrom);
      if (dateOfBirthTo) where.dateOfBirth.lte = new Date(dateOfBirthTo);
    }

    if (createdAtFrom || createdAtTo) {
      where.createdAt = {};
      if (createdAtFrom) where.createdAt.gte = new Date(createdAtFrom);
      if (createdAtTo) where.createdAt.lte = new Date(createdAtTo);
    }

    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: { wilaya: true },
      }),
      prisma.user.count({ where }),
    ]);

    return { users, total };
  }

  async emailExists(email: string, excludeId?: string): Promise<boolean> {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return false;
    if (excludeId && user.id === excludeId) return false;
    return true;
  }

  async phoneExists(phone: string, excludeId?: string): Promise<boolean> {
    const user = await prisma.user.findUnique({ where: { phone } });
    if (!user) return false;
    if (excludeId && user.id === excludeId) return false;
    return true;
  }

  async updatePassword(id: string, hashedPassword: string) {
    return prisma.user.update({ where: { id }, data: { password: hashedPassword } });
  }

  async setVerificationCode(id: string, code: string, expiresAt: Date) {
    return prisma.user.update({
      where: { id },
      data: { verificationCode: code, otpExpiresAt: expiresAt },
    });
  }

  async verifyUser(id: string) {
    return prisma.user.update({
      where: { id },
      data: { isVerified: true, verificationCode: null, otpExpiresAt: null },
    });
  }

  async suspend(id: string, reason: string) {
    return prisma.user.update({
      where: { id },
      data: { isSuspended: true, suspensionReason: reason },
    });
  }

  async unsuspend(id: string) {
    return prisma.user.update({
      where: { id },
      data: { isSuspended: false, suspensionReason: null },
    });
  }

  async findByQrCode(qrCode: string) {
    return prisma.user.findUnique({
      where: { qrCode },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        trustLevel: true,
        trustPoints: true,
        isSuspended: true,
        wallet: {
          select: { id: true, credits: true },
        },
      },
    });
  }

  async regenerateQrCode(id: string) {
    const user = await prisma.user.update({
      where: { id },
      data: { qrCode: crypto.randomUUID() },
      select: { qrCode: true },
    });
    return { qrCode: user.qrCode as string };
  }


}

export const userRepository = new UserRepository();

