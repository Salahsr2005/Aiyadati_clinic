import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';
import { Prisma } from '@prisma/client';

interface CreateCategoryDTO {
  nameFr: string;
  nameAr: string;
  slug: string;
  descriptionFr?: string;
  descriptionAr?: string;
  imagePath?: string;
  parentId?: string;
  sortOrder?: number;
}

interface UpdateCategoryDTO {
  nameFr?: string;
  nameAr?: string;
  slug?: string;
  descriptionFr?: string;
  descriptionAr?: string;
  imagePath?: string;
  parentId?: string | null;
  sortOrder?: number;
  isActive?: boolean;
}

class CategoryRepository extends BaseRepository<any> {
  protected modelName = 'category';

  async findAll(params: {
    parentId?: string | null;
    isActive?: boolean;
    search?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }) {
    const {
    parentId,
    isActive,
    search,
    page: rawPage = 1,
    limit: rawLimit = 50,
    sortBy = 'sortOrder',
    sortOrder = 'asc',
    } = params;

    const page = Number(rawPage);
    const limit = Number(rawLimit);

    const where: any = {};

    if (parentId !== undefined) {
      where.parentId = parentId; // null = root categories, string = subcategories
    }

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (search) {
      where.OR = [
        { nameFr: { contains: search, mode: 'insensitive' } },
        { nameAr: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (page - 1) * limit;

    const [categories, total] = await Promise.all([
      this.prisma.category.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: {
          parent: {
            select: { id: true, nameFr: true, nameAr: true, slug: true },
          },
          children: {
            select: { id: true, nameFr: true, nameAr: true, slug: true, isActive: true },
            where: { isActive: true },
            orderBy: { sortOrder: 'asc' },
          },
          _count: {
            select: { products: true },
          },
        },
      }),
      this.prisma.category.count({ where }),
    ]);

    return { categories, total };
  }

  async findBySlug(slug: string) {
    return this.prisma.category.findUnique({
      where: { slug },
      include: {
        parent: true,
        children: {
          where: { isActive: true },
          orderBy: { sortOrder: 'asc' },
        },
      },
    });
  }

  async findTree() {
    // Get all root categories with nested children
    return this.prisma.category.findMany({
      where: { parentId: null, isActive: true },
      include: {
        children: {
          where: { isActive: true },
          include: {
            children: {
              where: { isActive: true },
              include: {
                children: true, // Up to 4 levels deep
              },
            },
          },
          orderBy: { sortOrder: 'asc' },
        },
      },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async create(data: CreateCategoryDTO) {
    return this.prisma.category.create({
      data: {
        nameFr: data.nameFr,
        nameAr: data.nameAr,
        slug: data.slug,
        descriptionFr: data.descriptionFr,
        descriptionAr: data.descriptionAr,
        imagePath: data.imagePath,
        parentId: data.parentId,
        sortOrder: data.sortOrder || 0,
      },
    });
  }

  async update(id: string, data: UpdateCategoryDTO) {
    return this.prisma.category.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    // Check for children first
    const children = await this.prisma.category.count({
      where: { parentId: id },
    });

    if (children > 0) {
      throw new Error('Cannot delete category with subcategories');
    }

    // Check for products
    const products = await this.prisma.product.count({
      where: { categoryId: id },
    });

    if (products > 0) {
      throw new Error('Cannot delete category with products');
    }

    return this.prisma.category.delete({ where: { id } });
  }

  async slugExists(slug: string, excludeId?: string): Promise<boolean> {
    const category = await this.prisma.category.findUnique({ where: { slug } });
    if (!category) return false;
    if (excludeId && category.id === excludeId) return false;
    return true;
  }
}

export const categoryRepository = new CategoryRepository();

