import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';

export class ClinicServiceRepository {
  async findById(id: string) {
    return prisma.clinicService.findUnique({
      where: { id },
      include: {
        clinic: { select: { id: true, nameFr: true, nameAr: true } },
        gallery: { orderBy: { sortOrder: 'asc' } },
        doctors: {
          include: {
            doctor: {
              select: {
                id: true,
                firstNameFr: true,
                firstNameAr: true,
                lastNameFr: true,
                lastNameAr: true,
                photoPath: true,
                specialties: {
                  include: { specialty: { select: { id: true, nameFr: true, nameAr: true } } },
                },
              },
            },
          },
        },
      },
    });
  }

  async findByClinicId(clinicId: string) {
    return prisma.clinicService.findMany({
      where: { clinicId, isActive: true },
      include: {
        gallery: { where: { isActive: true }, orderBy: { sortOrder: 'asc' }, take: 3 },
        doctors: {
          include: {
            doctor: {
              select: {
                id: true,
                firstNameFr: true,
                firstNameAr: true,
                lastNameFr: true,
                lastNameAr: true,
                photoPath: true,
              },
            },
          },
        },
      },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async create(data: Prisma.ClinicServiceCreateInput) {
    return prisma.clinicService.create({ data });
  }

  async update(id: string, data: Prisma.ClinicServiceUpdateInput) {
    return prisma.clinicService.update({ where: { id }, data });
  }

  async delete(id: string) {
    return prisma.clinicService.delete({ where: { id } });
  }

  async findAll(params: {
    clinicId: string;
    page?: number;
    limit?: number;
    search?: string;
    isActive?: boolean;
  }) {
    const { clinicId, page = 1, limit = 10, search, isActive } = params;

    const where: any = { clinicId };
    if (isActive !== undefined) where.isActive = isActive;

    if (search) {
      where.OR = [
        { nameFr: { contains: search, mode: 'insensitive' } },
        { nameAr: { contains: search, mode: 'insensitive' } },
        { descriptionFr: { contains: search, mode: 'insensitive' } },
        { descriptionAr: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (page - 1) * limit;

    const [services, total] = await Promise.all([
      prisma.clinicService.findMany({
        where,
        skip,
        take: limit,
        orderBy: { sortOrder: 'asc' },
        include: {
          gallery: { where: { isActive: true }, orderBy: { sortOrder: 'asc' }, take: 1 },
          doctors: {
            include: {
              doctor: {
                select: {
                  id: true,
                  firstNameFr: true,
                  firstNameAr: true,
                  lastNameFr: true,
                  lastNameAr: true,
                  photoPath: true,
                },
              },
            },
          },
        },
      }),
      prisma.clinicService.count({ where }),
    ]);

    return { services, total };
  }

  // Public search across all clinics
  async searchPublic(params: {
    query?: string;
    wilayaId?: string;
    clinicId?: string;
    page?: number;
    limit?: number;
  }) {
    const { query, wilayaId, clinicId, page = 1, limit = 10 } = params;

    const where: any = { isActive: true, clinic: { isVerified: true, isSuspended: false } };

    if (clinicId) where.clinicId = clinicId;
    if (wilayaId) where.clinic = { ...where.clinic, wilayaId };

    if (query) {
      where.OR = [
        { nameFr: { contains: query, mode: 'insensitive' } },
        { nameAr: { contains: query, mode: 'insensitive' } },
      ];
    }

    const skip = (page - 1) * limit;

    const [services, total] = await Promise.all([
      prisma.clinicService.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          clinic: {
            select: {
              id: true,
              nameFr: true,
              nameAr: true,
              logoPath: true,
              wilaya: { select: { id: true, nameFr: true, nameAr: true } },
              baladya: { select: { id: true, nameFr: true, nameAr: true } },
            },
          },
          gallery: { where: { isActive: true }, orderBy: { sortOrder: 'asc' }, take: 1 },
          doctors: {
            include: {
              doctor: {
                select: {
                  id: true,
                  firstNameFr: true,
                  firstNameAr: true,
                  lastNameFr: true,
                  lastNameAr: true,
                  photoPath: true,
                },
              },
            },
          },
        },
      }),
      prisma.clinicService.count({ where }),
    ]);

    return { services, total };
  }

  // === Gallery ===
  
  async findImageById(imageId: string) {
    return prisma.clinicServiceImage.findUnique({ where: { id: imageId } });
  }

  async addImage(data: Prisma.ClinicServiceImageCreateInput) {
    return prisma.clinicServiceImage.create({ data });
  }

  async deleteImage(imageId: string) {
    return prisma.clinicServiceImage.delete({ where: { id: imageId } });
  }

  async getMaxSortOrder(serviceId: string): Promise<number> {
    const result = await prisma.clinicServiceImage.aggregate({
      where: { serviceId },
      _max: { sortOrder: true },
    });
    return result._max.sortOrder ?? 0;
  }

  // === Doctors ===

  async findServiceDoctor(serviceId: string, doctorId: string) {
    return prisma.clinicServiceDoctor.findUnique({
      where: { serviceId_doctorId: { serviceId, doctorId } },
    });
  }

  async assignDoctor(data: Prisma.ClinicServiceDoctorCreateInput) {
    return prisma.clinicServiceDoctor.create({
      data,
      include: {
        doctor: {
          select: {
            id: true,
            firstNameFr: true,
            firstNameAr: true,
            lastNameFr: true,
            lastNameAr: true,
            photoPath: true,
          },
        },
      },
    });
  }

  async removeDoctor(serviceId: string, doctorId: string) {
    return prisma.clinicServiceDoctor.delete({
      where: { serviceId_doctorId: { serviceId, doctorId } },
    });
  }

  async getServiceDoctors(serviceId: string) {
    return prisma.clinicServiceDoctor.findMany({
      where: { serviceId },
      include: {
        doctor: {
          select: {
            id: true,
            firstNameFr: true,
            firstNameAr: true,
            lastNameFr: true,
            lastNameAr: true,
            photoPath: true,
            specialties: {
              include: { specialty: { select: { id: true, nameFr: true, nameAr: true } } },
            },
          },
        },
      },
    });
  }
}

export const clinicServiceRepository = new ClinicServiceRepository();

