// // src/repositories/specialty-image.repository.ts

// import { prisma } from '../core/utils/prisma';
// import { BaseRepository } from './base.repository';

// interface CreateSpecialtyImageDTO {
//   specialtyId: string;
//   filePath: string;
//   fileName: string;
//   fileType: string;
//   fileSize: number;
//   storageKey: string;
//   isPrimary?: boolean;
//   sortOrder?: number;
//   captionFr?: string;
//   captionAr?: string;
// }

// interface UpdateSpecialtyImageDTO {
//   isPrimary?: boolean;
//   sortOrder?: number;
//   captionFr?: string;
//   captionAr?: string;
// }

// class SpecialtyImageRepository extends BaseRepository<any> {
//   protected modelName = 'specialtyImage';

//   /**
//    * Find images by specialty ID
//    */
//   async findBySpecialtyId(specialtyId: string) {
//     return this.prisma.specialtyImage.findMany({
//       where: { specialtyId },
//       orderBy: [{ isPrimary: 'desc' }, { sortOrder: 'asc' }],
//     });
//   }

//   /**
//    * Find image by fileId (for file service)
//    */
//   async findByFileId(fileId: string) {
//     return this.prisma.specialtyImage.findUnique({
//       where: { fileId },
//     });
//   }

//   /**
//    * Find image by storageKey
//    */
//   async findByStorageKey(storageKey: string) {
//     return this.prisma.specialtyImage.findUnique({
//       where: { storageKey },
//     });
//   }

//   /**
//    * Create a new specialty image
//    */
//   async create(data: CreateSpecialtyImageDTO) {
//     // If this is the primary image, unset others
//     if (data.isPrimary) {
//       await this.prisma.specialtyImage.updateMany({
//         where: { specialtyId: data.specialtyId, isPrimary: true },
//         data: { isPrimary: false },
//       });
//     }

//     return this.prisma.specialtyImage.create({
//       data: {
//         specialtyId: data.specialtyId,
//         filePath: data.filePath,
//         fileName: data.fileName,
//         fileType: data.fileType,
//         fileSize: data.fileSize,
//         storageKey: data.storageKey,
//         isPrimary: data.isPrimary || false,
//         sortOrder: data.sortOrder || 0,
//         captionFr: data.captionFr,
//         captionAr: data.captionAr,
//         storageType: 'public',
//       },
//     });
//   }

//   /**
//    * Update an image
//    */
//   async update(id: string, data: UpdateSpecialtyImageDTO) {
//     // If setting as primary, unset others first
//     if (data.isPrimary) {
//       const image = await this.prisma.specialtyImage.findUnique({ where: { id } });
//       if (image) {
//         await this.prisma.specialtyImage.updateMany({
//           where: { specialtyId: image.specialtyId, isPrimary: true },
//           data: { isPrimary: false },
//         });
//       }
//     }

//     return this.prisma.specialtyImage.update({
//       where: { id },
//       data,
//     });
//   }

//   /**
//    * Delete an image
//    */
//   async delete(id: string) {
//     return this.prisma.specialtyImage.delete({ where: { id } });
//   }

//   /**
//    * Delete image by fileId
//    */
//   async deleteByFileId(fileId: string) {
//     return this.prisma.specialtyImage.delete({ where: { fileId } });
//   }

//   /**
//    * Delete all images for a specialty
//    */
//   async deleteBySpecialtyId(specialtyId: string) {
//     return this.prisma.specialtyImage.deleteMany({ where: { specialtyId } });
//   }

//   /**
//    * Increment access count (for file service)
//    */
//   async incrementAccessCount(fileId: string): Promise<void> {
//     await this.prisma.specialtyImage.update({
//       where: { fileId },
//       data: {
//         accessCount: { increment: 1 },
//         lastAccessed: new Date(),
//       },
//     });
//   }

//   /**
//    * Get the primary image for a specialty
//    */
//   async getPrimaryImage(specialtyId: string) {
//     return this.prisma.specialtyImage.findFirst({
//       where: { specialtyId, isPrimary: true },
//     });
//   }

//   /**
//    * Get max sort order for a specialty
//    */
//   async getMaxSortOrder(specialtyId: string): Promise<number> {
//     const result = await this.prisma.specialtyImage.aggregate({
//       where: { specialtyId },
//       _max: { sortOrder: true },
//     });
//     return result._max.sortOrder ?? 0;
//   }
// }

// export const specialtyImageRepository = new SpecialtyImageRepository();

