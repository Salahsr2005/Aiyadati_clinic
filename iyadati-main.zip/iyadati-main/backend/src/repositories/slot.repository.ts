import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';
import { nowAlgeria, isSlotInPastAlgeria } from '../core/utils/timezone';

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Generate a unique key for a slot
 * Respects clinicId and roomId properly
 */
function generateSlotKey(
  doctorId: string,
  date: Date,
  startTime: Date,
  clinicId?: string | null,
  roomId?: string | null
): string {
  const dateStr = date.toISOString().slice(0, 10);
  const timeStr = startTime.toISOString().slice(11, 16);
  
  // ALWAYS include clinicId if present, even if null
  const clinicPart = clinicId || 'none';
  const roomPart = roomId || 'none';
  
  return `${doctorId}:${dateStr}:${timeStr}:${clinicPart}:${roomPart}`;
}

// ============================================================
// REPOSITORY
// ============================================================

export class SlotRepository {
  
  // ======================== FINDERS ========================

  async findById(id: string) {
    return prisma.slot.findUnique({
      where: { id },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });
  }

  async findByDoctorAndDate(doctorId: string, date: string) {
    const targetDate = new Date(date);
    return prisma.slot.findMany({
      where: {
        doctorId,
        date: targetDate,
      },
      orderBy: {
        startTime: 'asc',
      },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });
  }

  /**
   * Get available slots for a doctor on a specific date
   * - Excludes cancelled slots
   * - Filters out slots that have already passed (using Algeria timezone)
   */
  async findAvailableByDoctorAndDate(
    doctorId: string,
    date: string,
  ) {
    const targetDate = new Date(date);

    const slots = await prisma.slot.findMany({
      where: {
        doctorId,
        date: targetDate,
        status: {
          not: 'cancelled',
        },
      },
      orderBy: {
        startTime: 'asc',
      },
      include: {
        doctor: true,
        clinic: true,
        room: true,
      },
    });

    const now = nowAlgeria();

    // Filter out slots that have already started/passed
    return slots.filter(
      (slot) => !isSlotInPastAlgeria(slot.date, slot.startTime, now),
    );
  }

  /**
   * Validates that a slot is bookable (exists, not cancelled, not expired)
   * Can be called inside a transaction by passing the transaction client
   * @throws Error with descriptive message if validation fails
   */
  async validateSlotIsBookable(
    slotId: string,
    now = nowAlgeria(),
    tx?: Prisma.TransactionClient,
  ) {
    const client = tx || prisma;

    const slot = await client.slot.findUnique({
      where: { id: slotId },
    });

    if (!slot) {
      throw new Error('Slot not found');
    }

    if (slot.status === 'cancelled') {
      throw new Error('This slot has been cancelled');
    }

    if (isSlotInPastAlgeria(slot.date, slot.startTime, now)) {
      throw new Error('This slot has already passed');
    }

    return slot;
  }

  /**
   * Refreshes the slot status based on active appointments
   * Should be called after booking or cancellation
   */
  async refreshSlotStatus(
    slotId: string,
    tx?: Prisma.TransactionClient,
  ) {
    const client = tx || prisma;

    const slot = await client.slot.findUnique({
      where: { id: slotId },
    });

    if (!slot) {
      return null;
    }

    const activeCount = await client.appointment.count({
      where: {
        slotId,
        status: {
          notIn: ['CANCELLED', 'NO_SHOW'],
        },
      },
    });

    const newStatus = activeCount >= slot.maxPatients ? 'full' : 'available';

    if (slot.status !== newStatus) {
      return client.slot.update({
        where: { id: slotId },
        data: { status: newStatus },
      });
    }

    return slot;
  }

  // ======================== CREATION ========================

  async create(data: {
    doctorId: string;
    clinicId?: string;
    roomId?: string;
    date: Date;
    startTime: Date;
    endTime: Date;
    maxPatients?: number;
  }) {
    const slotKey = generateSlotKey(
      data.doctorId,
      data.date,
      data.startTime,
      data.clinicId,
      data.roomId
    );

    return prisma.slot.create({
      data: {
        ...data,
        slotKey,
        maxPatients: data.maxPatients || 1,
      },
    });
  }

  async createMany(
    slots: Array<{
      doctorId: string;
      clinicId?: string;
      roomId?: string;
      date: Date;
      startTime: Date;
      endTime: Date;
      maxPatients: number;
    }>,
  ) {
    // Generate slotKey for each slot
    const slotsWithKeys = slots.map(slot => ({
      ...slot,
      slotKey: generateSlotKey(
        slot.doctorId,
        slot.date,
        slot.startTime,
        slot.clinicId,
        slot.roomId
      ),
    }));

    return prisma.slot.createMany({
      data: slotsWithKeys,
      skipDuplicates: true, // Handle concurrent generation
    });
  }

  // ======================== UPDATES ========================

  async updateStatus(id: string, status: string) {
    return prisma.slot.update({
      where: { id },
      data: { status },
    });
  }

  async cancelSlot(id: string) {
    return prisma.slot.update({
      where: { id },
      data: { status: 'cancelled' },
    });
  }

  async cancelByDoctorAndDate(doctorId: string, date: string) {
    return prisma.slot.updateMany({
      where: {
        doctorId,
        date: new Date(date),
        status: {
          in: ['available', 'full'],
        },
      },
      data: {
        status: 'cancelled',
      },
    });
  }

  // ======================== DELETION ========================

  /**
   * Delete slots by doctor and date range (NORMAL MODE)
   * @throws Error if any slot has active appointments
   * @returns Number of deleted slots
   */
  async deleteByDoctorAndDateRange(
    doctorId: string,
    startDate: Date,
    endDate: Date,
  ): Promise<number> {
    // First, find slots that have active appointments
    const slotsWithAppointments = await prisma.slot.findMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          some: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      select: {
        id: true,
        date: true,
        startTime: true,
        _count: {
          select: {
            appointments: {
              where: {
                status: {
                  notIn: ['CANCELLED', 'NO_SHOW'],
                },
              },
            },
          },
        },
      },
    });

    if (slotsWithAppointments.length > 0) {
      const slotDetails = slotsWithAppointments
        .map(s => {
          const dateStr = s.date.toISOString().slice(0, 10);
          const timeStr = s.startTime.toISOString().slice(11, 16);
          return `${dateStr} at ${timeStr} (${s._count.appointments} appointment${s._count.appointments > 1 ? 's' : ''})`;
        })
        .join('; ');
      
      throw new Error(
        `Cannot regenerate slots: ${slotsWithAppointments.length} slot(s) have active appointments (${slotDetails}). ` +
        `Please cancel or complete these appointments first.`
      );
    }

    // Only delete slots without active appointments
    const result = await prisma.slot.deleteMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          none: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
    });

    return result.count;
  }

  /**
   * Force delete slots by doctor and date range (ADMIN ONLY)
   * Cancels all active appointments and refunds credits before deleting
   * @returns Object with deleted slots count and cancelled appointments count
   */
  async forceDeleteByDoctorAndDateRange(
    doctorId: string,
    startDate: Date,
    endDate: Date,
    cancelledBy: string,
  ): Promise<{ deletedSlots: number; cancelledAppointments: number; refundedCredits: number }> {
    // Find all slots with active appointments in the range
    const slotsWithAppointments = await prisma.slot.findMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
        appointments: {
          some: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
        },
      },
      include: {
        appointments: {
          where: {
            status: {
              notIn: ['CANCELLED', 'NO_SHOW'],
            },
          },
          include: {
            patient: true,
            guestPatient: true,
          },
        },
      },
    });

    let cancelledAppointments = 0;
    let refundedCredits = 0;

    // Cancel all active appointments and refund credits
    for (const slot of slotsWithAppointments) {
      for (const appointment of slot.appointments) {
        // Only refund registered patients with credits
        if (appointment.patientType === 'REGISTERED' && appointment.paymentMethod === 'CREDIT' && appointment.patientId) {
          await prisma.$transaction(async (tx) => {
            const wallet = await tx.userWallet.upsert({
              where: { userId: appointment.patientId! },
              create: { userId: appointment.patientId!, credits: 1 },
              update: { credits: { increment: 1 } },
            });
            
            await tx.creditTransaction.create({
              data: {
                walletId: wallet.id,
                amount: 1,
                type: 'refund',
                description: 'Force regeneration - admin action',
                referenceId: appointment.id,
              },
            });
          });
          refundedCredits++;
        }

        // Cancel the appointment
        await prisma.appointment.update({
          where: { id: appointment.id },
          data: {
            status: 'CANCELLED',
            cancelledAt: new Date(),
            cancelledBy: cancelledBy,
            cancelReason: 'Force regeneration - admin action',
          },
        });
        cancelledAppointments++;
      }
    }

    // Now delete all slots in the range (including the ones we just cancelled)
    const result = await prisma.slot.deleteMany({
      where: {
        doctorId,
        date: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    return {
      deletedSlots: result.count,
      cancelledAppointments,
      refundedCredits,
    };
  }

  // ======================== BACKGROUND CLEANUP ========================

  /**
   * Mark expired slots as 'expired' for UI purposes
   * This runs as a background job - booking validation is the authoritative check
   * IMPROVED: Uses updateMany with a single query instead of iterating
   */
  async markExpiredSlots() {
    const now = nowAlgeria();
    
    // Get today's date at midnight for comparison
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    
    // Build the where condition
    const where: any = {
      status: {
        in: ['available', 'full'],
      },
    };
    
    // Slots where date is in the past (before today)
    // OR date is today but startTime has passed
    where.OR = [
      {
        date: {
          lt: today,
        },
      },
      {
        date: today,
        startTime: {
          lt: now,
        },
      },
    ];

    // Use updateMany for efficiency - single database query
    const result = await prisma.slot.updateMany({
      where,
      data: {
        status: 'expired',
      },
    });

    return result.count;
  }

  // ======================== IDEMPOTENT GENERATION (NEW) ========================

  /**
   * Generate missing slots idempotently
   * Will NEVER delete existing slots, only create new ones
   * @returns { created: number, existing: number, errors: number }
   */
  async generateMissingSlots(
    doctorId: string,
    slots: Array<{
      clinicId?: string;
      roomId?: string;
      date: Date;
      startTime: Date;
      endTime: Date;
      maxPatients: number;
    }>
  ): Promise<{ created: number; existing: number; errors: number }> {
    const result = { created: 0, existing: 0, errors: 0 };

    // Generate slotKey for each slot
    const slotsWithKeys = slots.map(slot => ({
      ...slot,
      slotKey: generateSlotKey(
        doctorId,
        slot.date,
        slot.startTime,
        slot.clinicId,
        slot.roomId
      ),
      doctorId,
    }));

    try {
      // Use createMany with skipDuplicates (idempotent)
      const createResult = await prisma.slot.createMany({
        data: slotsWithKeys,
        skipDuplicates: true,
      });

      result.created = createResult.count;
      result.existing = slots.length - createResult.count;
    } catch (error: any) {
      result.errors = slots.length;
      throw error;
    }

    return result;
  }

// ============================================================
// IDEMPOTENT GENERATION (UPDATED)
// ============================================================

/**
 * Get the current booking horizon for a doctor
 * Returns the farthest date that has slots generated
 * ✅ FIXED: Respects clinicId and roomId scope
 */
async getBookingHorizon(
  doctorId: string,
  clinicId?: string | null,
  roomId?: string | null
): Promise<Date | null> {
  const where: any = { doctorId };
  
  if (clinicId) {
    where.clinicId = clinicId;
  }
  
  if (roomId) {
    where.roomId = roomId;
  }

  const farthestSlot = await prisma.slot.findFirst({
    where,
    orderBy: { date: 'desc' },
    select: { date: true },
  });

  return farthestSlot?.date || null;
}

/**
 * Create or update automation rule (UPDATED)
 */
async upsertAutomationRule(
  doctorId: string,
  data: {
    frequency: string;
    bookingWindowDays: number; // ← RENAMED
    clinicId?: string;
    roomId?: string;
  }
) {
  const nextRunAt = this.calculateNextRun(data.frequency);

  return prisma.slotGenerationRule.upsert({
    where: { doctorId },
    update: {
      frequency: data.frequency as any,
      bookingWindowDays: data.bookingWindowDays, // ← RENAMED
      clinicId: data.clinicId,
      roomId: data.roomId,
      enabled: true,
      nextRunAt,
      errorCount: 0,
      lastError: null,
    },
    create: {
      doctorId,
      frequency: data.frequency as any,
      bookingWindowDays: data.bookingWindowDays, // ← RENAMED
      clinicId: data.clinicId,
      roomId: data.roomId,
      nextRunAt,
    },
  });
}

  /**
   * Disable automation rule
   */
  async disableAutomationRule(doctorId: string) {
    return prisma.slotGenerationRule.update({
      where: { doctorId },
      data: { enabled: false },
    });
  }

  /**
   * Calculate next run date based on frequency
   */
  private calculateNextRun(frequency: string): Date {
    const now = new Date();
    switch (frequency) {
      case 'DAILY':
        now.setDate(now.getDate() + 1);
        now.setHours(0, 0, 0, 0);
        break;
      case 'WEEKLY':
        now.setDate(now.getDate() + 7);
        now.setHours(0, 0, 0, 0);
        break;
      case 'MONTHLY':
        now.setMonth(now.getMonth() + 1);
        now.setDate(1);
        now.setHours(0, 0, 0, 0);
        break;
    }
    return now;
  }

  /**
   * Get automation rule for a doctor
   */
  async getAutomationRule(doctorId: string) {
    return prisma.slotGenerationRule.findUnique({
      where: { doctorId },
    });
  }
}

export const slotRepository = new SlotRepository();

