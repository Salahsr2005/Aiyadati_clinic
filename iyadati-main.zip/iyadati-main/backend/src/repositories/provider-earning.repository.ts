import { prisma } from '../core/utils/prisma';

export class ProviderEarningRepository {
  /**
   * Create an earning record for a completed appointment
   * ✅ PREVENTS DUPLICATES
   */
  async create(data: {
    providerId: string;
    providerType: 'DOCTOR' | 'CLINIC';
    amount: number;
    appointmentId: string;
    creditPriceId?: string;
    notes?: string;
  }) {
    return await prisma.providerEarning.create({
      data: {
        providerId: data.providerId,
        providerType: data.providerType,
        amount: data.amount,
        appointmentId: data.appointmentId,
        creditPriceId: data.creditPriceId,
        notes: data.notes,
        status: 'PENDING',
      },
    });
  }

  /**
   * ✅ ADD THIS: Check if earnings already exist for an appointment
   */
  async findByAppointmentId(appointmentId: string) {
    return await prisma.providerEarning.findMany({
      where: { appointmentId },
    });
  }

  /**
   * Get earnings for a provider with pagination
   */
  async findByProvider(
    providerId: string,
    providerType: 'DOCTOR' | 'CLINIC',
    options?: {
      status?: 'PENDING' | 'PAID' | 'FAILED';
      fromDate?: Date;
      toDate?: Date;
      page?: number;
      limit?: number;
    }
  ) {
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const skip = (page - 1) * limit;

    const where: any = {
      providerId,
      providerType,
    };

    if (options?.status) {
      where.status = options.status;
    }

    if (options?.fromDate || options?.toDate) {
      where.createdAt = {};
      if (options.fromDate) where.createdAt.gte = options.fromDate;
      if (options.toDate) where.createdAt.lte = options.toDate;
    }

    const [items, total] = await Promise.all([
      prisma.providerEarning.findMany({
        where,
        include: {
          appointment: {
            include: {
              patient: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  phone: true,
                },
              },
              slot: {
                select: {
                  date: true,
                  startTime: true,
                  endTime: true,
                },
              },
            },
          },
          creditPrice: true,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.providerEarning.count({ where }),
    ]);

    return { items, total, page, limit };
  }

  /**
   * Get earnings summary for a provider
   */
  async getSummary(providerId: string, providerType: 'DOCTOR' | 'CLINIC') {
    const [pending, paid] = await Promise.all([
      prisma.providerEarning.aggregate({
        where: {
          providerId,
          providerType,
          status: 'PENDING',
        },
        _sum: { amount: true },
        _count: { id: true },
      }),
      prisma.providerEarning.aggregate({
        where: {
          providerId,
          providerType,
          status: 'PAID',
        },
        _sum: { amount: true },
        _count: { id: true },
      }),
    ]);

    return {
      pending: {
        total: pending._sum.amount || 0,
        count: pending._count.id || 0,
      },
      paid: {
        total: paid._sum.amount || 0,
        count: paid._count.id || 0,
      },
    };
  }

  /**
   * Get all pending earnings grouped by provider (for admin)
   */
  async getPendingGroupedByProvider() {
    const results = await prisma.$queryRaw`
      SELECT 
        provider_id as "providerId",
        provider_type as "providerType",
        COUNT(*) as "count",
        SUM(amount) as "totalAmount",
        ARRAY_AGG(id) as "earningIds"
      FROM provider_earnings
      WHERE status = 'PENDING'
      GROUP BY provider_id, provider_type
      ORDER BY "totalAmount" DESC
    `;

    return results as Array<{
      providerId: string;
      providerType: string;
      count: number;
      totalAmount: number;
      earningIds: string[];
    }>;
  }

  /**
   * Mark earnings as collected/paid
   */
  async markAsPaid(earningIds: string[]) {
    return await prisma.$transaction(async (tx) => {
      const updated = await tx.providerEarning.updateMany({
        where: {
          id: { in: earningIds },
          status: 'PENDING',
        },
        data: {
          status: 'PAID',
          paidAt: new Date(),
        },
      });

      return updated;
    });
  }

  /**
   * Get earning by ID
   */
  async findById(id: string) {
    return await prisma.providerEarning.findUnique({
      where: { id },
      include: {
        appointment: {
          include: {
            patient: true,
            doctor: true,
            clinic: true,
            slot: true,
          },
        },
        creditPrice: true,
      },
    });
  }
}

export const providerEarningRepository = new ProviderEarningRepository();

