import { prisma } from '../core/utils/prisma';

export class DoctorBreakRepository {
  async findByDoctorId(doctorId: string) {
    return prisma.doctorBreak.findMany({
      where: { doctorId },
      orderBy: { startDate: 'asc' },
    });
  }

  async findByDoctorAndDateRange(doctorId: string, startDate: Date, endDate: Date) {
    return prisma.doctorBreak.findMany({
      where: {
        doctorId,
        OR: [
          { startDate: { lte: endDate }, endDate: { gte: startDate } },
        ],
      },
    });
  }

  async findById(id: string) {
    return prisma.doctorBreak.findUnique({ where: { id } });
  }

  async create(data: {
    doctorId: string;
    startDate: Date;
    endDate: Date;
    reason?: string;
    isAllDay?: boolean;
    startTime?: Date;
    endTime?: Date;
  }) {
    return prisma.doctorBreak.create({ data });
  }

  async update(id: string, data: {
    startDate?: Date;
    endDate?: Date;
    reason?: string;
    isAllDay?: boolean;
    startTime?: Date | null;
    endTime?: Date | null;
  }) {
    return prisma.doctorBreak.update({ where: { id }, data });
  }

  async delete(id: string) {
    return prisma.doctorBreak.delete({ where: { id } });
  }

  async getUpcomingBreaks(doctorId: string) {
    return prisma.doctorBreak.findMany({
      where: {
        doctorId,
        endDate: { gte: new Date() },
      },
      orderBy: { startDate: 'asc' },
    });
  }
}

export const doctorBreakRepository = new DoctorBreakRepository();

