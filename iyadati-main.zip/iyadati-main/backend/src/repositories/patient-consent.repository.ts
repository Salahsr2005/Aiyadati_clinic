import { prisma } from '../core/utils/prisma';
import { ConsentLevel, AccessType } from '@prisma/client';

export class PatientConsentRepository {
  /**
   * Get consent for a specific doctor-patient pair
   */
  async findConsent(patientId: string, doctorId: string) {
    return prisma.patientDoctorConsent.findUnique({
      where: {
        patientId_doctorId: { patientId, doctorId }
      }
    });
  }

  /**
   * Get all active consents for a patient
   */
  async findActiveByPatient(patientId: string) {
    return prisma.patientDoctorConsent.findMany({
      where: {
        patientId,
        isActive: true,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      },
      include: {
        doctor: {
          select: {
            id: true,
            firstNameFr: true,
            lastNameFr: true,
            email: true,
            phone: true,
            isVerified: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Get all active consents for a doctor
   */
  async findActiveByDoctor(doctorId: string) {
    return prisma.patientDoctorConsent.findMany({
      where: {
        doctorId,
        isActive: true,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      },
      include: {
        patient: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            phone: true,
            isSuspended: true,
            trustLevel: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Create or update consent
   */
  async upsertConsent(
    patientId: string,
    doctorId: string,
    data: {
      level: ConsentLevel;
      customDocumentIds?: string[];
      expiresInDays?: number;
    }
  ) {
    const expiresAt = data.expiresInDays 
      ? new Date(Date.now() + data.expiresInDays * 24 * 60 * 60 * 1000)
      : null;

    return prisma.patientDoctorConsent.upsert({
      where: {
        patientId_doctorId: { patientId, doctorId }
      },
      update: {
        level: data.level,
        customDocumentIds: data.customDocumentIds || [],
        expiresAt,
        isActive: true,
        revokedAt: null,
        updatedAt: new Date()
      },
      create: {
        patientId,
        doctorId,
        level: data.level,
        customDocumentIds: data.customDocumentIds || [],
        expiresAt,
        consentMethod: 'app'
      }
    });
  }

  /**
   * Revoke consent
   */
  async revokeConsent(patientId: string, doctorId: string) {
    return prisma.patientDoctorConsent.update({
      where: {
        patientId_doctorId: { patientId, doctorId }
      },
      data: {
        isActive: false,
        revokedAt: new Date(),
        updatedAt: new Date()
      }
    });
  }

  /**
   * Check if doctor has access to a specific document
   */
  async canDoctorAccessDocument(
    patientId: string,
    doctorId: string,
    documentId: string,
    appointmentId?: string
  ): Promise<{ access: boolean; level: ConsentLevel | null; reason?: string }> {
    const consent = await this.findConsent(patientId, doctorId);
    
    if (!consent) {
      return { access: false, level: null, reason: 'No consent found' };
    }

    if (!consent.isActive) {
      return { access: false, level: null, reason: 'Consent is not active' };
    }

    if (consent.expiresAt && consent.expiresAt < new Date()) {
      return { access: false, level: null, reason: 'Consent has expired' };
    }

    switch (consent.level) {
      case 'FULL':
        return { access: true, level: 'FULL' };

      case 'APPOINTMENT_ONLY':
        if (!appointmentId) {
          return { 
            access: false, 
            level: 'APPOINTMENT_ONLY', 
            reason: 'Appointment ID required for appointment-only access' 
          };
        }
        const appointment = await prisma.appointment.findFirst({
          where: {
            id: appointmentId,
            doctorId,
            patientId,
            status: { in: ['CONFIRMED', 'COMPLETED'] }
          }
        });
        return { 
          access: !!appointment, 
          level: 'APPOINTMENT_ONLY',
          reason: appointment ? undefined : 'No valid appointment found'
        };

      case 'CUSTOM':
        const hasAccess = consent.customDocumentIds.includes(documentId);
        return { 
          access: hasAccess, 
          level: 'CUSTOM',
          reason: hasAccess ? undefined : 'Document not in custom list'
        };

      case 'NONE':
        return { access: false, level: 'NONE', reason: 'Access explicitly denied' };

      default:
        return { access: false, level: null, reason: 'Unknown consent level' };
    }
  }

  /**
   * Get all documents a doctor can access for a patient
   */
  async getAccessibleDocumentIds(
    patientId: string,
    doctorId: string
  ): Promise<{ documentIds: string[]; level: ConsentLevel | null }> {
    const consent = await this.findConsent(patientId, doctorId);
    
    if (!consent || !consent.isActive || (consent.expiresAt && consent.expiresAt < new Date())) {
      return { documentIds: [], level: null };
    }

    switch (consent.level) {
      case 'FULL':
        // Get all documents for patient
        const allDocs = await prisma.userDocument.findMany({
          where: { userId: patientId },
          select: { id: true }
        });
        return { 
          documentIds: allDocs.map(d => d.id), 
          level: 'FULL' 
        };

      case 'APPOINTMENT_ONLY':
        // Get documents linked to appointments with this doctor
        const appointmentIds = await prisma.appointment.findMany({
          where: {
            patientId,
            doctorId,
            status: { in: ['CONFIRMED', 'COMPLETED'] }
          },
          select: { id: true }
        });
        const docs = await prisma.userDocument.findMany({
          where: {
            userId: patientId,
            appointmentId: { in: appointmentIds.map(a => a.id) }
          },
          select: { id: true }
        });
        return { 
          documentIds: docs.map(d => d.id), 
          level: 'APPOINTMENT_ONLY' 
        };

      case 'CUSTOM':
        return { 
          documentIds: consent.customDocumentIds, 
          level: 'CUSTOM' 
        };

      case 'NONE':
        return { documentIds: [], level: 'NONE' };

      default:
        return { documentIds: [], level: null };
    }
  }

  /**
   * Log document access
   * ✅ FIXED: Convert string to AccessType enum
   */
  async logAccess(
    documentId: string,
    patientId: string,
    doctorId: string,
    accessType: string,
    ipAddress?: string,
    userAgent?: string
  ) {
    // ✅ Convert string to AccessType enum
    const accessTypeEnum = accessType.toUpperCase() as AccessType;
    
    return prisma.documentAccessLog.create({
      data: {
        documentId,
        patientId,
        doctorId,
        accessType: accessTypeEnum,
        ipAddress,
        userAgent
      }
    });
  }

  /**
   * Get access logs for a patient
   */
  async getAccessLogs(
    patientId: string, 
    doctorId?: string,
    page: number = 1,
    limit: number = 10
  ) {
    const skip = (page - 1) * limit;
    
    const where: any = { patientId };
    if (doctorId) where.doctorId = doctorId;

    const [logs, total] = await Promise.all([
      prisma.documentAccessLog.findMany({
        where,
        skip,
        take: limit,
        orderBy: { accessedAt: 'desc' },
        include: {
          document: {
            select: {
              id: true,
              fileName: true,
              title: true,
              fileType: true
            }
          },
          doctor: {
            select: {
              id: true,
              firstNameFr: true,
              lastNameFr: true,
              email: true
            }
          }
        }
      }),
      prisma.documentAccessLog.count({ where })
    ]);

    return { logs, total };
  }

  /**
   * Get all consents (for admin)
   */
  async findAll(page: number = 1, limit: number = 10, filters?: {
    patientId?: string;
    doctorId?: string;
    level?: ConsentLevel;
    isActive?: boolean;
  }) {
    const skip = (page - 1) * limit;
    
    const where: any = {};
    if (filters?.patientId) where.patientId = filters.patientId;
    if (filters?.doctorId) where.doctorId = filters.doctorId;
    if (filters?.level) where.level = filters.level;
    if (filters?.isActive !== undefined) where.isActive = filters.isActive;

    const [consents, total] = await Promise.all([
      prisma.patientDoctorConsent.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          patient: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true
            }
          },
          doctor: {
            select: {
              id: true,
              firstNameFr: true,
              lastNameFr: true,
              email: true,
              phone: true
            }
          }
        }
      }),
      prisma.patientDoctorConsent.count({ where })
    ]);

    return { consents, total };
  }
}

export const patientConsentRepository = new PatientConsentRepository();

