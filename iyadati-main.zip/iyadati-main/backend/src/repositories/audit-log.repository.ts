import { prisma } from '../core/utils/prisma';
import { Prisma } from '@prisma/client';

export interface CreateAuditLogData {
  action: string;
  entity: string;
  entityId: string;
  performedBy: string;
  details?: any;
  ip?: string;
}

export interface AuditLogFilters {
  action?: string;
  entity?: string;
  entityId?: string;
  performedBy?: string;
  startDate?: Date;
  endDate?: Date;
  page?: number;
  limit?: number;
}

export class AuditLogRepository {
  /**
   * Create a new audit log entry
   */
  async create(data: CreateAuditLogData) {
    return await prisma.auditLog.create({
      data: {
        action: data.action,
        entity: data.entity,
        entityId: data.entityId,
        performedBy: data.performedBy,
        details: data.details || {},
        ip: data.ip || null
      }
    });
  }

  /**
   * Get audit log by ID
   */
  async findById(id: string) {
    return await prisma.auditLog.findUnique({
      where: { id }
    });
  }

  /**
   * Get audit logs by entity ID (with pagination)
   */
  async getByEntity(entityId: string, limit: number = 50, page: number = 1) {
    const skip = (page - 1) * limit;
    
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where: { entityId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.auditLog.count({
        where: { entityId }
      })
    ]);

    return {
      logs,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    };
  }

  /**
   * Get audit logs by action
   */
  async getByAction(action: string, limit: number = 50, page: number = 1) {
    const skip = (page - 1) * limit;
    
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where: { action },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.auditLog.count({
        where: { action }
      })
    ]);

    return {
      logs,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    };
  }

  /**
   * Get audit logs by performed by user
   */
  async getByPerformedBy(performedBy: string, limit: number = 50, page: number = 1) {
    const skip = (page - 1) * limit;
    
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where: { performedBy },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.auditLog.count({
        where: { performedBy }
      })
    ]);

    return {
      logs,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    };
  }

  /**
   * Get audit logs with filters
   */
  async getWithFilters(filters: AuditLogFilters) {
    const { 
      action, 
      entity, 
      entityId, 
      performedBy, 
      startDate, 
      endDate,
      page = 1,
      limit = 50
    } = filters;

    const skip = (page - 1) * limit;
    
    const where: Prisma.AuditLogWhereInput = {};

    if (action) where.action = action;
    if (entity) where.entity = entity;
    if (entityId) where.entityId = entityId;
    if (performedBy) where.performedBy = performedBy;
    
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = startDate;
      if (endDate) where.createdAt.lte = endDate;
    }

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.auditLog.count({ where })
    ]);

    return {
      logs,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    };
  }

  /**
   * Get recent audit logs (last 24 hours by default)
   */
  async getRecent(hours: number = 24, limit: number = 100) {
    const cutoffDate = new Date();
    cutoffDate.setHours(cutoffDate.getHours() - hours);

    return await prisma.auditLog.findMany({
      where: {
        createdAt: {
          gte: cutoffDate
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit
    });
  }

  /**
   * Get audit log summary by action type
   */
  async getSummaryByAction(startDate?: Date, endDate?: Date) {
    const where: Prisma.AuditLogWhereInput = {};
    
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = startDate;
      if (endDate) where.createdAt.lte = endDate;
    }

    const logs = await prisma.auditLog.groupBy({
      by: ['action'],
      where,
      _count: {
        action: true
      },
      orderBy: {
        _count: {
          action: 'desc'
        }
      }
    });

    return logs.map(item => ({
      action: item.action,
      count: item._count.action
    }));
  }

  /**
   * Get audit log summary by entity type
   */
  async getSummaryByEntity(startDate?: Date, endDate?: Date) {
    const where: Prisma.AuditLogWhereInput = {};
    
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = startDate;
      if (endDate) where.createdAt.lte = endDate;
    }

    const logs = await prisma.auditLog.groupBy({
      by: ['entity'],
      where,
      _count: {
        entity: true
      },
      orderBy: {
        _count: {
          entity: 'desc'
        }
      }
    });

    return logs.map(item => ({
      entity: item.entity,
      count: item._count.entity
    }));
  }

  /**
   * Delete audit logs older than specified days
   */
  async deleteOlderThan(days: number): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const result = await prisma.auditLog.deleteMany({
      where: {
        createdAt: {
          lt: cutoffDate
        }
      }
    });

    return result.count;
  }

  /**
   * Get audit log count
   */
  async count(filters?: Partial<AuditLogFilters>) {
    const where: Prisma.AuditLogWhereInput = {};
    
    if (filters?.action) where.action = filters.action;
    if (filters?.entity) where.entity = filters.entity;
    if (filters?.entityId) where.entityId = filters.entityId;
    if (filters?.performedBy) where.performedBy = filters.performedBy;
    
    if (filters?.startDate || filters?.endDate) {
      where.createdAt = {};
      if (filters?.startDate) where.createdAt.gte = filters.startDate;
      if (filters?.endDate) where.createdAt.lte = filters.endDate;
    }

    return await prisma.auditLog.count({ where });
  }

  /**
   * Get all distinct actions
   */
  async getDistinctActions() {
    const result = await prisma.auditLog.findMany({
      distinct: ['action'],
      select: {
        action: true
      },
      orderBy: {
        action: 'asc'
      }
    });

    return result.map(item => item.action);
  }

  /**
   * Get all distinct entities
   */
  async getDistinctEntities() {
    const result = await prisma.auditLog.findMany({
      distinct: ['entity'],
      select: {
        entity: true
      },
      orderBy: {
        entity: 'asc'
      }
    });

    return result.map(item => item.entity);
  }
}

export const auditLogRepository = new AuditLogRepository();

