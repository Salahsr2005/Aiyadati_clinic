import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';
import { OrderStatus, PaymentStatus, OrderPaymentMethod } from '@prisma/client';

interface CreateOrderDTO {
  buyerId: string;
  sellerId: string;
  paymentMethod: OrderPaymentMethod;
  shippingCompanyId?: string;
  subtotal: number;
  shippingCost: number;
  totalAmount: number;
  notes?: string;
  items: Array<{
    productId: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }>;
}

interface OrderFilters {
  buyerId?: string;
  sellerId?: string;
  status?: OrderStatus;
  paymentStatus?: PaymentStatus;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

class OrderRepository extends BaseRepository<any> {
  protected modelName = 'order';

  async findAll(filters: OrderFilters) {
const {
  buyerId,
  sellerId,
  status,
  paymentStatus,
  page: rawPage = 1,
  limit: rawLimit = 20,
  sortBy = 'createdAt',
  sortOrder = 'desc',
} = filters;

const page = Number(rawPage);
const limit = Number(rawLimit);

    const where: any = {};

    if (buyerId) where.buyerId = buyerId;
    if (sellerId) where.sellerId = sellerId;
    if (status) where.status = status;
    if (paymentStatus) where.paymentStatus = paymentStatus;

    const skip = (page - 1) * limit;

    const [orders, total] = await Promise.all([
      this.prisma.order.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: {
          buyer: {
            select: { id: true, firstName: true, lastName: true, email: true, phone: true },
          },
          seller: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
          shippingCompany: {
            select: { id: true, name: true, trackingUrl: true },
          },
          items: {
            include: {
              product: {
                select: {
                  id: true,
                  titleFr: true,
                  titleAr: true,
                  images: { take: 1, where: { isPrimary: true } },
                },
              },
            },
          },
          statusHistory: {
            orderBy: { createdAt: 'desc' },
            take: 5,
          },
        },
      }),
      this.prisma.order.count({ where }),
    ]);

    return { orders, total };
  }

  async findById(id: string) {
    return this.prisma.order.findUnique({
      where: { id },
      include: {
        buyer: {
          select: { id: true, firstName: true, lastName: true, email: true, phone: true },
        },
        seller: {
          select: { id: true, firstName: true, lastName: true, email: true, phone: true },
        },
        shippingCompany: true,
        items: {
          include: {
            product: {
              include: {
                images: { take: 1, where: { isPrimary: true } },
              },
            },
          },
        },
        statusHistory: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });
  }

  async create(data: CreateOrderDTO) {
    return this.prisma.$transaction(async (tx) => {
      // 1. Create the order
      const order = await tx.order.create({
        data: {
          buyerId: data.buyerId,
          sellerId: data.sellerId,
          paymentMethod: data.paymentMethod,
          shippingCompanyId: data.shippingCompanyId,
          subtotal: data.subtotal,
          shippingCost: data.shippingCost,
          totalAmount: data.totalAmount,
          notes: data.notes,
          items: {
            create: data.items.map(item => ({
              productId: item.productId,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              totalPrice: item.totalPrice,
            })),
          },
          statusHistory: {
            create: {
              status: 'PENDING',
              changedBy: data.buyerId,
              notes: 'Order placed',
            },
          },
        },
        include: {
          items: true,
          statusHistory: true,
        },
      });

      // 2. Decrease stock for each product
      for (const item of data.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stock: { decrement: item.quantity },
            saleCount: { increment: item.quantity },
          },
        });

        // Auto-set OUT_OF_STOCK if stock reaches 0
        const product = await tx.product.findUnique({
          where: { id: item.productId },
          select: { stock: true },
        });

        if (product && product.stock <= 0) {
          await tx.product.update({
            where: { id: item.productId },
            data: { status: 'OUT_OF_STOCK' },
          });
        }
      }

      return order;
    });
  }

  async updateStatus(
    id: string,
    status: OrderStatus,
    changedBy: string,
    notes?: string
  ) {
    const updateData: any = { status };

    // Set timestamps based on status
    if (status === 'DELIVERED') {
      updateData.deliveredAt = new Date();
    }

    if (status === 'CANCELLED') {
      updateData.cancelledAt = new Date();
      updateData.cancelledBy = changedBy;
    }

    return this.prisma.order.update({
      where: { id },
      data: {
        ...updateData,
        statusHistory: {
          create: {
            status,
            changedBy,
            notes,
          },
        },
      },
      include: {
        statusHistory: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
      },
    });
  }

  async updateTracking(id: string, shippingCompanyId: string, trackingNumber: string) {
    return this.prisma.order.update({
      where: { id },
      data: {
        shippingCompanyId,
        trackingNumber,
        status: 'SHIPPED',
        statusHistory: {
          create: {
            status: 'SHIPPED',
            changedBy: 'SYSTEM',
            notes: `Tracking: ${trackingNumber}`,
          },
        },
      },
    });
  }

  async cancelOrder(id: string, userId: string, reason: string) {
    const order = await this.findById(id);
    if (!order) throw new Error('Order not found');

    return this.prisma.$transaction(async (tx) => {
      // 1. Update order status
      const updatedOrder = await tx.order.update({
        where: { id },
        data: {
          status: 'CANCELLED',
          cancelledAt: new Date(),
          cancelledBy: userId,
          cancelReason: reason,
          statusHistory: {
            create: {
              status: 'CANCELLED',
              changedBy: userId,
              notes: reason,
            },
          },
        },
      });

      // 2. Restore stock
      for (const item of order.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stock: { increment: item.quantity },
          },
        });
      }

      return updatedOrder;
    });
  }

  async findByBuyerId(buyerId: string, page = 1, limit = 20) {
    return this.findAll({ buyerId, page, limit });
  }

  async findBySellerId(sellerId: string, page = 1, limit = 20) {
    return this.findAll({ sellerId, page, limit });
  }

  async getOrderStats(sellerId: string) {
    const stats = await this.prisma.order.groupBy({
      by: ['status'],
      where: { sellerId },
      _count: { id: true },
      _sum: { totalAmount: true },
    });

    const total = await this.prisma.order.count({
      where: { sellerId },
    });

    const revenue = await this.prisma.order.aggregate({
      where: {
        sellerId,
        status: { notIn: ['CANCELLED', 'RETURNED'] },
      },
      _sum: { totalAmount: true },
    });

    return { stats, total, revenue: revenue._sum.totalAmount || 0 };
  }
}

export const orderRepository = new OrderRepository();

