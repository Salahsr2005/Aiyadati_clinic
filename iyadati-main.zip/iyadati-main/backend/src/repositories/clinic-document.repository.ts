import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateClinicDocumentDTO {
  clinicId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  docType?: string;
  uploadedBy?: string;
  storageType?: 'public' | 'private';
  category?: string;
  expiresAt?: Date;
}

interface UpdateClinicDocumentDTO {
  docType?: string;
}

class ClinicDocumentRepository extends BaseRepository<any> {
  protected modelName = 'clinicDocument';

  async findByClinicId(clinicId: string, filters?: { docType?: string; storageType?: string }) {
    const where: any = { clinicId };

    if (filters?.docType) where.docType = filters.docType;
    if (filters?.storageType) where.storageType = filters.storageType;

    return this.prisma.clinicDocument.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.clinicDocument.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.clinicDocument.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateClinicDocumentDTO) {
    return this.prisma.clinicDocument.create({
      data: {
        clinicId: data.clinicId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        docType: data.docType || 'other',
        uploadedBy: data.uploadedBy,
        storageType: data.storageType || 'private',
        category: data.category || 'document',
        expiresAt: data.expiresAt,
      },
    });
  }

  async update(id: string, data: UpdateClinicDocumentDTO) {
    return this.prisma.clinicDocument.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    return this.prisma.clinicDocument.delete({ where: { id } });
  }

  async deleteByClinicId(clinicId: string) {
    return this.prisma.clinicDocument.deleteMany({ where: { clinicId } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.clinicDocument.delete({ where: { fileId } });
  }

  async findByDocType(clinicId: string, docType: string) {
    return this.prisma.clinicDocument.findMany({
      where: {
        clinicId,
        docType,
      },
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const clinicDocumentRepository = new ClinicDocumentRepository();

