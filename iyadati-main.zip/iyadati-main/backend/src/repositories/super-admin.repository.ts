import { prisma } from '../core/utils/prisma';
import { SuperAdmin } from '@prisma/client';

export class SuperAdminRepository {
  /**
   * Find super admin by email (for login)
   */
  async findByEmail(email: string): Promise<SuperAdmin | null> {
    return prisma.superAdmin.findUnique({
      where: { email },
    });
  }

  /**
   * Find super admin by ID (for JWT verification)
   */
  async findById(id: string): Promise<SuperAdmin | null> {
    return prisma.superAdmin.findUnique({
      where: { id },
    });
  }
}

export const superAdminRepository = new SuperAdminRepository();

