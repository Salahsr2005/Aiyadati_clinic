import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateShippingCompanyDTO {
  name: string;
  trackingUrl?: string;
  logoPath?: string;
}

interface UpdateShippingCompanyDTO {
  name?: string;
  trackingUrl?: string;
  logoPath?: string;
  isActive?: boolean;
}

class ShippingCompanyRepository extends BaseRepository<any> {
  protected modelName = 'shippingCompany';

  async findAll(isActive?: boolean) {
    const where: any = {};
    if (isActive !== undefined) where.isActive = isActive;

    return this.prisma.shippingCompany.findMany({
      where,
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { orders: true },
        },
      },
    });
  }

  async findByName(name: string) {
    return this.prisma.shippingCompany.findUnique({
      where: { name },
    });
  }

  async create(data: CreateShippingCompanyDTO) {
    return this.prisma.shippingCompany.create({
      data: {
        name: data.name,
        trackingUrl: data.trackingUrl,
        logoPath: data.logoPath,
      },
    });
  }

  async update(id: string, data: UpdateShippingCompanyDTO) {
    return this.prisma.shippingCompany.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    // Check if company has orders
    const orders = await this.prisma.order.count({
      where: { shippingCompanyId: id },
    });

    if (orders > 0) {
      // Soft delete instead
      return this.prisma.shippingCompany.update({
        where: { id },
        data: { isActive: false },
      });
    }

    return this.prisma.shippingCompany.delete({ where: { id } });
  }
}

export const shippingCompanyRepository = new ShippingCompanyRepository();

