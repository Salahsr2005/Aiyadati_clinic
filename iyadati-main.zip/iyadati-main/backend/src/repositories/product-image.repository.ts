import { prisma } from '../core/utils/prisma';
import { BaseRepository } from './base.repository';

interface CreateProductImageDTO {
  productId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  storageKey: string;
  isPrimary?: boolean;
  sortOrder?: number;
}

interface UpdateProductImageDTO {
  isPrimary?: boolean;
  sortOrder?: number;
}

class ProductImageRepository extends BaseRepository<any> {
  protected modelName = 'productImage';

  async findByProductId(productId: string) {
    return this.prisma.productImage.findMany({
      where: { productId },
      orderBy: [{ isPrimary: 'desc' }, { sortOrder: 'asc' }],
    });
  }

  async findByFileId(fileId: string) {
    return this.prisma.productImage.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string) {
    return this.prisma.productImage.findUnique({
      where: { storageKey },
    });
  }

  async create(data: CreateProductImageDTO) {
    // If this is the primary image, unset others
    if (data.isPrimary) {
      await this.prisma.productImage.updateMany({
        where: { productId: data.productId, isPrimary: true },
        data: { isPrimary: false },
      });
    }

    return this.prisma.productImage.create({
      data: {
        productId: data.productId,
        fileName: data.fileName,
        filePath: data.filePath,
        fileType: data.fileType,
        fileSize: data.fileSize,
        storageKey: data.storageKey,
        isPrimary: data.isPrimary || false,
        sortOrder: data.sortOrder || 0,
        storageType: 'public',
      },
    });
  }

  async update(id: string, data: UpdateProductImageDTO) {
    // If setting as primary, unset others first
    if (data.isPrimary) {
      const image = await this.prisma.productImage.findUnique({ where: { id } });
      if (image) {
        await this.prisma.productImage.updateMany({
          where: { productId: image.productId, isPrimary: true },
          data: { isPrimary: false },
        });
      }
    }

    return this.prisma.productImage.update({
      where: { id },
      data,
    });
  }

  async delete(id: string) {
    return this.prisma.productImage.delete({ where: { id } });
  }

  async deleteByProductId(productId: string) {
    return this.prisma.productImage.deleteMany({ where: { productId } });
  }

  async deleteByFileId(fileId: string) {
    return this.prisma.productImage.delete({ where: { fileId } });
  }

  async setPrimary(id: string) {
    const image = await this.findById(id);
    if (!image) throw new Error('Image not found');

    // Unset all primary for this product
    await this.prisma.productImage.updateMany({
      where: { productId: image.productId },
      data: { isPrimary: false },
    });

    // Set this one as primary
    return this.prisma.productImage.update({
      where: { id },
      data: { isPrimary: true },
    });
  }

  async getPrimaryImage(productId: string) {
    return this.prisma.productImage.findFirst({
      where: { productId, isPrimary: true },
    });
  }

  async reorder(productId: string, imageIds: string[]) {
    // Update sort order for each image
    const updates = imageIds.map((id, index) =>
      this.prisma.productImage.update({
        where: { id },
        data: { sortOrder: index },
      })
    );

    await Promise.all(updates);
  }
}

export const productImageRepository = new ProductImageRepository();

