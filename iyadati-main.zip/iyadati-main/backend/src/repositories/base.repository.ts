// src/repositories/base.repository.ts
import { prisma } from '../core/utils/prisma';

export abstract class BaseRepository<T> {
  protected prisma = prisma;
  protected abstract modelName: string;

  // Helper to get the model with proper typing
  private get model() {
    // Use type assertion to tell TypeScript this is valid
    return (this.prisma as any)[this.modelName];
  }

  async findById(id: string): Promise<T | null> {
    return this.model.findUnique({
      where: { id },
    });
  }

  async findByFileId(fileId: string): Promise<T | null> {
    return this.model.findUnique({
      where: { fileId },
    });
  }

  async findByStorageKey(storageKey: string): Promise<T | null> {
    return this.model.findUnique({
      where: { storageKey },
    });
  }

  async delete(id: string): Promise<T> {
    return this.model.delete({
      where: { id },
    });
  }

  async deleteByFileId(fileId: string): Promise<T> {
    return this.model.delete({
      where: { fileId },
    });
  }

  async exists(id: string): Promise<boolean> {
    const count = await this.model.count({
      where: { id },
    });
    return count > 0;
  }

  async existsByFileId(fileId: string): Promise<boolean> {
    const count = await this.model.count({
      where: { fileId },
    });
    return count > 0;
  }

  async incrementAccessCount(fileId: string): Promise<void> {
    await this.model.update({
      where: { fileId },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }

  async findExpiredDocuments(): Promise<T[]> {
    return this.model.findMany({
      where: {
        expiresAt: {
          lte: new Date(),
        },
      },
    });
  }
}

