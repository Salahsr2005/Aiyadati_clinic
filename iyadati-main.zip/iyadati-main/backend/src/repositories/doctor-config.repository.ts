import { prisma } from '../core/utils/prisma';

export class DoctorConfigRepository {
  async findByDoctorId(doctorId: string) {
    return prisma.doctorConfig.findUnique({ where: { doctorId } });
  }

  async upsert(doctorId: string, data: { slotDuration: number; bufferTime: number; maxPerSlot?: number }) {
    return prisma.doctorConfig.upsert({
      where: { doctorId },
      create: { 
        doctorId, 
        slotDuration: data.slotDuration, 
        bufferTime: data.bufferTime,
        maxPerSlot: data.maxPerSlot || 1,
      },
      update: { 
        slotDuration: data.slotDuration, 
        bufferTime: data.bufferTime,
        maxPerSlot: data.maxPerSlot || 1,
      },
    });
  }
}

export const doctorConfigRepository = new DoctorConfigRepository();

