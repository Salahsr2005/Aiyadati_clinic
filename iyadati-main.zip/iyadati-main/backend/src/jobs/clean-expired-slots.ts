import { slotRepository } from '../repositories/slot.repository';
import { logger } from '../core/utils/logger';

/**
 * Background job that runs every hour to mark expired slots
 * This is for UI purposes only - booking validation handles expired slots
 */
export async function cleanExpiredSlots() {
  try {
    const count = await slotRepository.markExpiredSlots();
    if (count > 0) {
      logger.info(`[Cleanup Job] Cleaned ${count} expired slots`);
    }
  } catch (error) {
    logger.error('[Cleanup Job] Failed to clean expired slots:', error);
  }
}

// Run every hour
const interval = setInterval(cleanExpiredSlots, 60 * 60 * 1000);

// Run on startup
cleanExpiredSlots();

// Graceful shutdown
process.on('SIGTERM', () => {
  clearInterval(interval);
  logger.info('[Cleanup Job] Stopped on SIGTERM');
});

process.on('SIGINT', () => {
  clearInterval(interval);
  logger.info('[Cleanup Job] Stopped on SIGINT');
});

