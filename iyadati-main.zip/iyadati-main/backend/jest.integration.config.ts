import type { Config } from 'jest';

const config: Config = {
  displayName: 'integration',

  preset: 'ts-jest',

  testEnvironment: 'node',

  rootDir: '.',

  testMatch: [
    '<rootDir>/tests/integration/**/*.test.ts',
  ],

  setupFilesAfterEnv: [
    '<rootDir>/tests/setup/setupAfterEnv.ts',
  ],

  // COMMENT OUT OR REMOVE THESE LINES:
  // globalSetup: '<rootDir>/tests/setup/setupDatabase.ts',
  // globalTeardown: '<rootDir>/tests/setup/teardownDatabase.ts',

  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },

  transform: {
    '^.+\\.tsx?$': [
      'ts-jest',
      {
        tsconfig: '<rootDir>/tsconfig.test.json',
      },
    ],
  },

  testTimeout: 180000,
  verbose: true,
};

export default config;

