// backend/tests/integration/repositories/super-admin.repository.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('SuperAdminRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let superAdminRepository: typeof import('../../../src/repositories/super-admin.repository')['superAdminRepository'];
  const superAdminIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ superAdminRepository } = await import('../../../src/repositories/super-admin.repository'));

    await prisma.$connect();
  }, 180000);

  afterEach(async () => {
    if (superAdminIds.length > 0) {
      await prisma.superAdmin.deleteMany({
        where: { id: { in: superAdminIds } },
      });
      superAdminIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createSuperAdminData = (
    overrides: Partial<Prisma.SuperAdminCreateInput> = {},
  ): Prisma.SuperAdminCreateInput => ({
    email: `superadmin-${crypto.randomUUID()}@example.com`,
    password: 'hashed-password',
    name: 'Super Admin',
    ...overrides,
  });

  // ============================================================
  // Tests
  // ============================================================

  describe('findByEmail', () => {
    it('should find a super admin by email', async () => {
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `find-email-${crypto.randomUUID()}@example.com`,
        }),
      });
      superAdminIds.push(superAdmin.id);

      const result = await superAdminRepository.findByEmail(superAdmin.email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(superAdmin.id);
      expect(result?.email).toBe(superAdmin.email);
      expect(result?.name).toBe(superAdmin.name);
    });

    it('should return null when email does not exist', async () => {
      const result = await superAdminRepository.findByEmail(
        'nonexistent@example.com',
      );
      expect(result).toBeNull();
    });

    it('should return the correct super admin when multiple exist', async () => {
      const admin1 = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `multi1-${crypto.randomUUID()}@example.com`,
          name: 'Admin One',
        }),
      });
      const admin2 = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `multi2-${crypto.randomUUID()}@example.com`,
          name: 'Admin Two',
        }),
      });
      superAdminIds.push(admin1.id, admin2.id);

      const result = await superAdminRepository.findByEmail(admin2.email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(admin2.id);
      expect(result?.name).toBe('Admin Two');
    });

    it('should handle case sensitivity correctly', async () => {
      const email = `case-${crypto.randomUUID()}@example.com`;
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData({ email }),
      });
      superAdminIds.push(superAdmin.id);

      // PostgreSQL is case-sensitive by default with Prisma
      const resultLower = await superAdminRepository.findByEmail(email.toLowerCase());
      expect(resultLower).not.toBeNull();

      // Should not find with different case
      const resultUpper = await superAdminRepository.findByEmail(email.toUpperCase());
      expect(resultUpper).toBeNull();
    });
  });

  describe('findById', () => {
    it('should find a super admin by id', async () => {
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData(),
      });
      superAdminIds.push(superAdmin.id);

      const result = await superAdminRepository.findById(superAdmin.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(superAdmin.id);
      expect(result?.email).toBe(superAdmin.email);
      expect(result?.name).toBe(superAdmin.name);
    });

    it('should return null when super admin does not exist', async () => {
      const result = await superAdminRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });

    it('should return the correct super admin when multiple exist', async () => {
      const admin1 = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `byid1-${crypto.randomUUID()}@example.com`,
        }),
      });
      const admin2 = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `byid2-${crypto.randomUUID()}@example.com`,
        }),
      });
      superAdminIds.push(admin1.id, admin2.id);

      const result = await superAdminRepository.findById(admin2.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(admin2.id);
      expect(result?.email).toBe(admin2.email);
    });
  });

  // Additional edge cases

  describe('Repository behavior', () => {
    it('should return all fields for a super admin', async () => {
      const now = new Date();
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData({
          email: `fields-${crypto.randomUUID()}@example.com`,
          password: 'super-secure-hash',
          name: 'Test Super Admin',
        }),
      });
      superAdminIds.push(superAdmin.id);

      const result = await superAdminRepository.findById(superAdmin.id);

      expect(result).toMatchObject({
        id: superAdmin.id,
        email: superAdmin.email,
        password: 'super-secure-hash',
        name: 'Test Super Admin',
      });
      expect(result?.createdAt).toBeInstanceOf(Date);
      expect(result?.updatedAt).toBeInstanceOf(Date);
      expect(result?.createdAt.getTime()).toBeCloseTo(now.getTime(), -1000);
    });

    it('should handle special characters in email', async () => {
      const email = `special+${crypto.randomUUID()}@example.com`;
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData({ email }),
      });
      superAdminIds.push(superAdmin.id);

      const result = await superAdminRepository.findByEmail(email);

      expect(result).not.toBeNull();
      expect(result?.email).toBe(email);
    });

    it('should handle very long email addresses', async () => {
      const longEmail = `very.long.email.address.${crypto.randomUUID()}@example.com`;
      const superAdmin = await prisma.superAdmin.create({
        data: createSuperAdminData({ email: longEmail }),
      });
      superAdminIds.push(superAdmin.id);

      const result = await superAdminRepository.findByEmail(longEmail);

      expect(result).not.toBeNull();
      expect(result?.email).toBe(longEmail);
    });
  });
});

