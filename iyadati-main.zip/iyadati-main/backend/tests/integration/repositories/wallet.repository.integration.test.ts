import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('WalletRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let walletRepository: typeof import('../../../src/repositories/wallet.repository')['walletRepository'];
  let wilayaId: string;
  const userIds: string[] = [];
  const walletIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ walletRepository } = await import('../../../src/repositories/wallet.repository'));

    await prisma.$connect();

    // Create test wilaya
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;
  }, 180000);

  afterEach(async () => {
    // Clean up transactions first
    if (walletIds.length > 0) {
      await prisma.creditTransaction.deleteMany({
        where: { walletId: { in: walletIds } },
      });
    }
    
    if (userIds.length > 0) {
      await prisma.userWallet.deleteMany({
        where: { userId: { in: userIds } },
      });
      await prisma.user.deleteMany({
        where: { id: { in: userIds } },
      });
      userIds.length = 0;
      walletIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createTestUser = async (overrides: Partial<Prisma.UserCreateInput> = {}) => {
    const user = await prisma.user.create({
      data: {
        email: `test-${crypto.randomUUID()}@example.com`,
        password: 'hashed-password',
        firstName: 'Test',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        wilaya: { connect: { id: wilayaId } },
        ...overrides,
      },
    });
    userIds.push(user.id);
    return user;
  };

  const createTestWallet = async (userId: string, credits: number = 0) => {
    const wallet = await prisma.userWallet.create({
      data: { userId, credits },
    });
    walletIds.push(wallet.id);
    return wallet;
  };

  // ============================================================
  // Tests
  // ============================================================

  describe('findByUserId', () => {
    it('should find a wallet by user id with latest transactions', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      // Create some transactions with explicit timestamps
      const now = new Date();
      
      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet.id, amount: 50, type: 'deposit', createdAt: new Date(now.getTime() - 1000) },
          { walletId: wallet.id, amount: -20, type: 'withdrawal', createdAt: new Date(now.getTime() - 2000) },
          { walletId: wallet.id, amount: 30, type: 'deposit', createdAt: new Date(now.getTime() - 3000) },
        ],
      });

      const result = await walletRepository.findByUserId(user.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(wallet.id);
      expect(result?.credits).toBe(100);
      
      const transactions = result?.transactions;
      expect(transactions).toBeDefined();
      expect(transactions?.length).toBe(3);
      
      // Verify transactions are ordered by createdAt desc (newest first)
      // The first transaction should be the newest (50), then -20, then 30
      expect(transactions?.[0]?.amount).toBe(50);
      expect(transactions?.[1]?.amount).toBe(-20);
      expect(transactions?.[2]?.amount).toBe(30);
      
      // Verify chronological order
      if (transactions && transactions.length >= 3) {
        expect(transactions[0].createdAt.getTime()).toBeGreaterThan(
          transactions[1].createdAt.getTime()
        );
        expect(transactions[1].createdAt.getTime()).toBeGreaterThan(
          transactions[2].createdAt.getTime()
        );
      }
    });

    it('should return null when user has no wallet', async () => {
      const user = await createTestUser();
      
      const result = await walletRepository.findByUserId(user.id);
      
      expect(result).toBeNull();
    });
  });

  describe('findById', () => {
    it('should find a wallet by id', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 50);

      const result = await walletRepository.findById(wallet.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(wallet.id);
      expect(result?.credits).toBe(50);
    });

    it('should return null when wallet does not exist', async () => {
      const result = await walletRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a wallet with zero credits', async () => {
      const user = await createTestUser();

      const result = await walletRepository.create(user.id);

      walletIds.push(result.id);

      expect(result).toMatchObject({
        userId: user.id,
        credits: 0,
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
      expect(result.updatedAt).toBeInstanceOf(Date);
    });

    it('should create a wallet with the correct user association', async () => {
      const user = await createTestUser();

      const result = await walletRepository.create(user.id);
      walletIds.push(result.id);

      const walletFromDb = await prisma.userWallet.findUnique({
        where: { id: result.id },
        include: { user: true },
      });

      expect(walletFromDb?.user.id).toBe(user.id);
      expect(walletFromDb?.user.email).toBe(user.email);
    });
  });

  describe('getOrCreate', () => {
    it('should return existing wallet when one exists', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 75);

      const result = await walletRepository.getOrCreate(user.id);

      expect(result.id).toBe(wallet.id);
      expect(result.credits).toBe(75);
      
      // Should not create a new wallet
      const allWallets = await prisma.userWallet.findMany({
        where: { userId: user.id },
      });
      expect(allWallets).toHaveLength(1);
    });

    it('should create a new wallet when none exists', async () => {
      const user = await createTestUser();

      const result = await walletRepository.getOrCreate(user.id);
      walletIds.push(result.id);

      expect(result.userId).toBe(user.id);
      expect(result.credits).toBe(0);
    });
  });

  describe('addCredits', () => {
    it('should increment wallet credits', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      const result = await walletRepository.addCredits(wallet.id, 50);

      expect(result.credits).toBe(150);
      
      const walletFromDb = await prisma.userWallet.findUnique({
        where: { id: wallet.id },
      });
      expect(walletFromDb?.credits).toBe(150);
    });

    it('should increment credits multiple times', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 0);

      await walletRepository.addCredits(wallet.id, 10);
      await walletRepository.addCredits(wallet.id, 20);
      await walletRepository.addCredits(wallet.id, 30);

      const result = await walletRepository.addCredits(wallet.id, 40);
      expect(result.credits).toBe(100);
    });
  });

  describe('deductCredits', () => {
    it('should decrement wallet credits', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      const result = await walletRepository.deductCredits(wallet.id, 30);

      expect(result.credits).toBe(70);
      
      const walletFromDb = await prisma.userWallet.findUnique({
        where: { id: wallet.id },
      });
      expect(walletFromDb?.credits).toBe(70);
    });

    it('should allow credits to go negative if not checked', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 10);

      const result = await walletRepository.deductCredits(wallet.id, 20);

      expect(result.credits).toBe(-10);
    });
  });

  describe('createTransaction', () => {
    it('should create a transaction with all fields', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      const result = await walletRepository.createTransaction({
        walletId: wallet.id,
        amount: 50,
        type: 'deposit',
        description: 'Test deposit',
        referenceId: 'ref-123',
        senderId: user.id,
        performedBy: 'admin-1',
      });

      expect(result).toMatchObject({
        walletId: wallet.id,
        amount: 50,
        type: 'deposit',
        description: 'Test deposit',
        referenceId: 'ref-123',
        senderId: user.id,
        performedBy: 'admin-1',
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
    });

    it('should create a transaction with minimal fields', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      const result = await walletRepository.createTransaction({
        walletId: wallet.id,
        amount: -25,
        type: 'withdrawal',
      });

      expect(result).toMatchObject({
        walletId: wallet.id,
        amount: -25,
        type: 'withdrawal',
        description: null,
        referenceId: null,
        senderId: null,
        performedBy: null,
      });
    });
  });

  describe('createTransfer', () => {
    it('should execute an atomic P2P transfer successfully', async () => {
      const sender = await createTestUser();
      const receiver = await createTestUser();
      const senderWallet = await createTestWallet(sender.id, 100);
      const receiverWallet = await createTestWallet(receiver.id, 50);

      const result = await walletRepository.createTransfer({
        senderWalletId: senderWallet.id,
        senderUserId: sender.id,
        receiverWalletId: receiverWallet.id,
        receiverUserId: receiver.id,
        amount: 30,
      });

      expect(result.transferId).toBeDefined();
      expect(result.sentTx).toMatchObject({
        walletId: senderWallet.id,
        amount: -30,
        type: 'transfer_sent',
        description: 'Sent 30 credits',
        senderId: sender.id,
      });
      expect(result.receivedTx).toMatchObject({
        walletId: receiverWallet.id,
        amount: 30,
        type: 'transfer_received',
        description: 'Received 30 credits',
        senderId: sender.id,
      });
      
      // Both transactions should share the same referenceId
      expect(result.sentTx.referenceId).toBe(result.receivedTx.referenceId);
      expect(result.sentTx.referenceId).toBe(result.transferId);

      // Verify wallet balances
      const senderWalletAfter = await prisma.userWallet.findUnique({
        where: { id: senderWallet.id },
      });
      const receiverWalletAfter = await prisma.userWallet.findUnique({
        where: { id: receiverWallet.id },
      });
      
      expect(senderWalletAfter?.credits).toBe(70); // 100 - 30
      expect(receiverWalletAfter?.credits).toBe(80); // 50 + 30
    });

    it('should fail when sender has insufficient credits', async () => {
      const sender = await createTestUser();
      const receiver = await createTestUser();
      const senderWallet = await createTestWallet(sender.id, 10);
      const receiverWallet = await createTestWallet(receiver.id, 50);

      await expect(
        walletRepository.createTransfer({
          senderWalletId: senderWallet.id,
          senderUserId: sender.id,
          receiverWalletId: receiverWallet.id,
          receiverUserId: receiver.id,
          amount: 20, // More than sender has
        })
      ).rejects.toThrow('INSUFFICIENT_CREDITS');

      // Verify no changes were made
      const senderWalletAfter = await prisma.userWallet.findUnique({
        where: { id: senderWallet.id },
      });
      const receiverWalletAfter = await prisma.userWallet.findUnique({
        where: { id: receiverWallet.id },
      });
      
      expect(senderWalletAfter?.credits).toBe(10);
      expect(receiverWalletAfter?.credits).toBe(50);

      // Verify no transactions were created
      const transactions = await prisma.creditTransaction.findMany({
        where: {
          OR: [
            { walletId: senderWallet.id },
            { walletId: receiverWallet.id },
          ],
        },
      });
      expect(transactions).toHaveLength(0);
    });

    it('should handle multiple transfers correctly', async () => {
      const sender = await createTestUser();
      const receiver = await createTestUser();
      const senderWallet = await createTestWallet(sender.id, 100);
      const receiverWallet = await createTestWallet(receiver.id, 0);

      // Perform multiple transfers
      await walletRepository.createTransfer({
        senderWalletId: senderWallet.id,
        senderUserId: sender.id,
        receiverWalletId: receiverWallet.id,
        receiverUserId: receiver.id,
        amount: 25,
      });

      await walletRepository.createTransfer({
        senderWalletId: senderWallet.id,
        senderUserId: sender.id,
        receiverWalletId: receiverWallet.id,
        receiverUserId: receiver.id,
        amount: 25,
      });

      const senderWalletAfter = await prisma.userWallet.findUnique({
        where: { id: senderWallet.id },
      });
      const receiverWalletAfter = await prisma.userWallet.findUnique({
        where: { id: receiverWallet.id },
      });

      expect(senderWalletAfter?.credits).toBe(50);
      expect(receiverWalletAfter?.credits).toBe(50);

      // Verify 4 transactions were created (2 sent, 2 received)
      const transactions = await prisma.creditTransaction.findMany({
        where: {
          OR: [
            { walletId: senderWallet.id },
            { walletId: receiverWallet.id },
          ],
        },
      });
      expect(transactions).toHaveLength(4);
    });

    it('should not partially complete a transfer on failure', async () => {
      const sender = await createTestUser();
      const receiver = await createTestUser();
      const senderWallet = await createTestWallet(sender.id, 5);
      const receiverWallet = await createTestWallet(receiver.id, 100);

      // This should fail atomically
      await expect(
        walletRepository.createTransfer({
          senderWalletId: senderWallet.id,
          senderUserId: sender.id,
          receiverWalletId: receiverWallet.id,
          receiverUserId: receiver.id,
          amount: 10,
        })
      ).rejects.toThrow();

      // Verify no partial updates
      const senderWalletAfter = await prisma.userWallet.findUnique({
        where: { id: senderWallet.id },
      });
      const receiverWalletAfter = await prisma.userWallet.findUnique({
        where: { id: receiverWallet.id },
      });

      expect(senderWalletAfter?.credits).toBe(5);
      expect(receiverWalletAfter?.credits).toBe(100);
    });
  });

  describe('getTransactions', () => {
    it('should return transactions with pagination', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet.id, amount: 10, type: 'deposit' },
          { walletId: wallet.id, amount: 20, type: 'deposit' },
          { walletId: wallet.id, amount: 30, type: 'deposit' },
          { walletId: wallet.id, amount: 40, type: 'deposit' },
          { walletId: wallet.id, amount: 50, type: 'deposit' },
        ],
      });

      const result = await walletRepository.getTransactions({
        page: 1,
        limit: 3,
      });

      expect(result.transactions).toHaveLength(3);
      expect(result.total).toBe(5);
    });

    it('should use default pagination', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet.id, amount: 10, type: 'deposit' },
          { walletId: wallet.id, amount: 20, type: 'deposit' },
        ],
      });

      const result = await walletRepository.getTransactions({});

      expect(result.transactions).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should filter by walletId', async () => {
      const user1 = await createTestUser();
      const user2 = await createTestUser();
      const wallet1 = await createTestWallet(user1.id, 100);
      const wallet2 = await createTestWallet(user2.id, 100);

      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet1.id, amount: 10, type: 'deposit' },
          { walletId: wallet2.id, amount: 20, type: 'deposit' },
          { walletId: wallet1.id, amount: 30, type: 'deposit' },
        ],
      });

      const result = await walletRepository.getTransactions({
        walletId: wallet1.id,
      });

      expect(result.transactions).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.transactions.every(t => t.walletId === wallet1.id)).toBe(true);
    });

    it('should filter by transaction type', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet.id, amount: 10, type: 'deposit' },
          { walletId: wallet.id, amount: -5, type: 'withdrawal' },
          { walletId: wallet.id, amount: 20, type: 'deposit' },
          { walletId: wallet.id, amount: -10, type: 'withdrawal' },
        ],
      });

      const result = await walletRepository.getTransactions({
        type: 'deposit',
      });

      expect(result.transactions).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.transactions.every(t => t.type === 'deposit')).toBe(true);
    });

    it('should filter by walletId and type combined', async () => {
      const user1 = await createTestUser();
      const user2 = await createTestUser();
      const wallet1 = await createTestWallet(user1.id, 100);
      const wallet2 = await createTestWallet(user2.id, 100);

      await prisma.creditTransaction.createMany({
        data: [
          { walletId: wallet1.id, amount: 10, type: 'deposit' },
          { walletId: wallet1.id, amount: -5, type: 'withdrawal' },
          { walletId: wallet2.id, amount: 20, type: 'deposit' },
          { walletId: wallet1.id, amount: 30, type: 'deposit' },
        ],
      });

      const result = await walletRepository.getTransactions({
        walletId: wallet1.id,
        type: 'deposit',
      });

      expect(result.transactions).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.transactions.every(t => 
        t.walletId === wallet1.id && t.type === 'deposit'
      )).toBe(true);
    });

    it('should include wallet and user details', async () => {
      const user = await createTestUser();
      const wallet = await createTestWallet(user.id, 100);

      await prisma.creditTransaction.create({
        data: {
          walletId: wallet.id,
          amount: 10,
          type: 'deposit',
        },
      });

      const result = await walletRepository.getTransactions({});

      expect(result.transactions[0].wallet).toBeDefined();
      expect(result.transactions[0].wallet.user).toBeDefined();
      expect(result.transactions[0].wallet.user.id).toBe(user.id);
      expect(result.transactions[0].wallet.user.email).toBe(user.email);
    });

    it('should handle empty result set', async () => {
      const result = await walletRepository.getTransactions({
        page: 999,
        limit: 10,
      });

      expect(result.transactions).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });
});

