import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma, FacilityType } from '@prisma/client';

describe('ClinicRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let clinicRepository: typeof import('../../../src/repositories/clinic.repository')['clinicRepository'];
  let wilayaId: string;
  let baladyaId: string;
  const clinicIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ clinicRepository } = await import('../../../src/repositories/clinic.repository'));

    await prisma.$connect();

    // Create test location data
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    const baladya = await prisma.baladya.create({
      data: {
        nameFr: `Test Baladya ${crypto.randomUUID()}`,
        nameAr: `بلدية اختبار ${crypto.randomUUID()}`,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    baladyaId = baladya.id;
  }, 180000);

  afterEach(async () => {
    if (clinicIds.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: clinicIds } },
      });
      clinicIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createClinicData = (
    overrides: Partial<Prisma.ClinicCreateInput> = {},
  ): Prisma.ClinicCreateInput => ({
    nameFr: `Clinic ${crypto.randomUUID()}`,
    nameAr: `عيادة ${crypto.randomUUID()}`,
    email: `clinic-${crypto.randomUUID()}@example.com`,
    password: 'hashed-password',
    phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
    facilityType: 'CLINIC' as FacilityType,
    wilaya: { connect: { id: wilayaId } },
    baladya: { connect: { id: baladyaId } },
    isVerified: false,
    isSuspended: false,
    isCompleted: false,
    ...overrides,
  });

  // ============================================================
  // Tests
  // ============================================================

  describe('findById', () => {
    it('should find a clinic by id with wilaya and baladya', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Find By Id Clinic',
          nameAr: 'عيادة البحث بالمعرف',
          email: `find-by-id-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findById(clinic.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(clinic.id);
      expect(result?.nameFr).toBe('Find By Id Clinic');
      expect(result?.nameAr).toBe('عيادة البحث بالمعرف');
      expect(result?.wilaya).toBeDefined();
      expect(result?.wilaya?.id).toBe(wilayaId);
      expect(result?.baladya).toBeDefined();
      expect(result?.baladya?.id).toBe(baladyaId);
    });

    it('should return null when clinic does not exist', async () => {
      const result = await clinicRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find a clinic by email', async () => {
      const email = `find-email-${crypto.randomUUID()}@example.com`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Email Clinic',
          nameAr: 'عيادة البريد',
          email,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findByEmail(email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(clinic.id);
      expect(result?.email).toBe(email);
    });

    it('should return null when email does not exist', async () => {
      const result = await clinicRepository.findByEmail(
        'nonexistent@example.com',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByPhone', () => {
    it('should find a clinic by phone', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Phone Clinic',
          nameAr: 'عيادة الهاتف',
          email: `phone-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findByPhone(phone);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(clinic.id);
      expect(result?.phone).toBe(phone);
    });

    it('should return null when phone does not exist', async () => {
      const result = await clinicRepository.findByPhone('0555555555');
      expect(result).toBeNull();
    });
  });

  describe('findByFileId', () => {
    it('should find a clinic by logo file id', async () => {
      const fileId = `file-${crypto.randomUUID()}`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'File Id Clinic',
          nameAr: 'عيادة معرف الملف',
          email: `file-id-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          logoFileId: fileId,
          logoPath: '/uploads/logo.png',
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findByFileId(fileId);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(clinic.id);
      expect(result?.logoFileId).toBe(fileId);
      expect(result?.logoPath).toBe('/uploads/logo.png');
      expect(result?.wilaya).toBeDefined();
      expect(result?.baladya).toBeDefined();
    });

    it('should return null when file id does not exist', async () => {
      const result = await clinicRepository.findByFileId(
        'nonexistent-file-id',
      );
      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a clinic with all data', async () => {
      const data = createClinicData({
        nameFr: 'New Clinic',
        nameAr: 'عيادة جديدة',
        descriptionFr: 'A great clinic',
        descriptionAr: 'عيادة رائعة',
      });

      const result = await clinicRepository.create(data);
      clinicIds.push(result.id);

      expect(result).toMatchObject({
        nameFr: 'New Clinic',
        nameAr: 'عيادة جديدة',
        email: data.email,
        phone: data.phone,
        facilityType: 'CLINIC',
        wilayaId,
        baladyaId,
        isVerified: false,
        isSuspended: false,
        isCompleted: false,
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
      expect(result.updatedAt).toBeInstanceOf(Date);
    });
  });

  describe('update', () => {
    it('should update a clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Original Clinic',
          nameAr: 'العيادة الأصلية',
          email: `update-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.update(clinic.id, {
        nameFr: 'Updated Clinic',
        nameAr: 'العيادة المحدثة',
        isVerified: true,
        descriptionFr: 'New description',
      });

      expect(result.id).toBe(clinic.id);
      expect(result.nameFr).toBe('Updated Clinic');
      expect(result.nameAr).toBe('العيادة المحدثة');
      expect(result.isVerified).toBe(true);
      expect(result.descriptionFr).toBe('New description');
    });

    it('should update logoFileId when provided', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Logo Clinic',
          nameAr: 'عيادة الشعار',
          email: `logo-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const fileId = `file-${crypto.randomUUID()}`;
      const result = await clinicRepository.update(clinic.id, {
        logoFileId: fileId,
        logoPath: '/uploads/new-logo.png',
      });

      expect(result.logoFileId).toBe(fileId);
      expect(result.logoPath).toBe('/uploads/new-logo.png');
    });
  });

  describe('delete', () => {
    it('should delete a clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Delete Clinic',
          nameAr: 'عيادة الحذف',
          email: `delete-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });

      const result = await clinicRepository.delete(clinic.id);
      expect(result.id).toBe(clinic.id);

      const deletedClinic = await prisma.clinic.findUnique({
        where: { id: clinic.id },
      });
      expect(deletedClinic).toBeNull();
    });
  });

  describe('deleteByFileId', () => {
    it('should clear logo fields when file id is found', async () => {
      const fileId = `file-${crypto.randomUUID()}`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Delete Logo Clinic',
          nameAr: 'عيادة حذف الشعار',
          email: `delete-logo-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          logoFileId: fileId,
          logoPath: '/uploads/logo.png',
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.deleteByFileId(fileId);

      expect(result).not.toBeNull();
      expect(result?.logoFileId).toBeNull();
      expect(result?.logoPath).toBeNull();
    });

    it('should return null when file id is not found', async () => {
      const result = await clinicRepository.deleteByFileId(
        'nonexistent-file-id',
      );
      expect(result).toBeNull();
    });
  });

  describe('incrementAccessCount', () => {
    it('should resolve successfully (no-op for now)', async () => {
      await expect(
        clinicRepository.incrementAccessCount('some-file-id'),
      ).resolves.toBeUndefined();
    });
  });

  describe('findAll', () => {
    it('should return clinics with pagination', async () => {
      const clinics = await Promise.all([
        prisma.clinic.create({
          data: {
            nameFr: 'Clinic A',
            nameAr: 'عيادة أ',
            email: `a-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
            baladya: { connect: { id: baladyaId } },
          },
        }),
        prisma.clinic.create({
          data: {
            nameFr: 'Clinic B',
            nameAr: 'عيادة ب',
            email: `b-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
            baladya: { connect: { id: baladyaId } },
          },
        }),
        prisma.clinic.create({
          data: {
            nameFr: 'Clinic C',
            nameAr: 'عيادة ج',
            email: `c-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
            baladya: { connect: { id: baladyaId } },
          },
        }),
      ]);
      clinicIds.push(...clinics.map((c) => c.id));

      const result = await clinicRepository.findAll({
        page: 1,
        limit: 2,
      });

      expect(result.clinics).toHaveLength(2);
      expect(result.total).toBe(3);
    });

    it('should use default pagination', async () => {
      const clinics = await Promise.all([
        prisma.clinic.create({
          data: {
            nameFr: 'Default 1',
            nameAr: 'افتراضي ١',
            email: `default1-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
            baladya: { connect: { id: baladyaId } },
          },
        }),
        prisma.clinic.create({
          data: {
            nameFr: 'Default 2',
            nameAr: 'افتراضي ٢',
            email: `default2-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
            baladya: { connect: { id: baladyaId } },
          },
        }),
      ]);
      clinicIds.push(...clinics.map((c) => c.id));

      const result = await clinicRepository.findAll({});

      expect(result.clinics).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should filter by wilayaId', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Wilaya Filter',
          nameAr: 'فلتر الولاية',
          email: `wilaya-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findAll({
        wilayaId,
      });

      expect(result.clinics.some((c) => c.id === clinic.id)).toBe(true);
      expect(result.total).toBeGreaterThan(0);
    });

    it('should filter by baladyaId', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Baladya Filter',
          nameAr: 'فلتر البلدية',
          email: `baladya-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findAll({
        baladyaId,
      });

      expect(result.clinics.some((c) => c.id === clinic.id)).toBe(true);
    });

    it('should filter by facilityType', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Type Filter',
          nameAr: 'فلتر النوع',
          email: `type-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          facilityType: 'CLINIC',
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findAll({
        facilityType: 'CLINIC',
      });

      expect(result.clinics.some((c) => c.id === clinic.id)).toBe(true);
      expect(result.clinics.every((c) => c.facilityType === 'CLINIC')).toBe(true);
    });

    it('should filter by isVerified', async () => {
      const verified = await prisma.clinic.create({
        data: {
          nameFr: 'Verified Clinic',
          nameAr: 'عيادة موثقة',
          email: `verified-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isVerified: true,
        },
      });
      const unverified = await prisma.clinic.create({
        data: {
          nameFr: 'Unverified Clinic',
          nameAr: 'عيادة غير موثقة',
          email: `unverified-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isVerified: false,
        },
      });
      clinicIds.push(verified.id, unverified.id);

      const result = await clinicRepository.findAll({
        isVerified: true,
      });

      expect(result.clinics.some((c) => c.id === verified.id)).toBe(true);
      expect(result.clinics.some((c) => c.id === unverified.id)).toBe(false);
    });

    it('should filter by isSuspended', async () => {
      const suspended = await prisma.clinic.create({
        data: {
          nameFr: 'Suspended Clinic',
          nameAr: 'عيادة موقوفة',
          email: `suspended-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isSuspended: true,
        },
      });
      const active = await prisma.clinic.create({
        data: {
          nameFr: 'Active Clinic',
          nameAr: 'عيادة نشطة',
          email: `active-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isSuspended: false,
        },
      });
      clinicIds.push(suspended.id, active.id);

      const result = await clinicRepository.findAll({
        isSuspended: true,
      });

      expect(result.clinics.some((c) => c.id === suspended.id)).toBe(true);
      expect(result.clinics.some((c) => c.id === active.id)).toBe(false);
    });

    it('should search across name, email, and phone', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Search Clinic Amal',
          nameAr: 'عيادة أمل',
          email: `search-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.findAll({
        search: 'Amal',
      });

      expect(result.clinics.some((c) => c.id === clinic.id)).toBe(true);
    });

    it('should support custom sorting', async () => {
      const clinic1 = await prisma.clinic.create({
        data: {
          nameFr: 'Z Clinic',
          nameAr: 'عيادة ز',
          email: `z-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      const clinic2 = await prisma.clinic.create({
        data: {
          nameFr: 'A Clinic',
          nameAr: 'عيادة أ',
          email: `a-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic1.id, clinic2.id);

      const result = await clinicRepository.findAll({
        sortBy: 'nameFr',
        sortOrder: 'asc',
      });

      // Should be sorted alphabetically by nameFr
      // 'A Clinic' should come before 'Z Clinic'
      const indexA = result.clinics.findIndex((c) => c.id === clinic2.id);
      const indexZ = result.clinics.findIndex((c) => c.id === clinic1.id);
      expect(indexA).toBeLessThan(indexZ);
    });
  });

  describe('emailExists', () => {
    it('should return true when email exists', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Email Exists',
          nameAr: 'البريد موجود',
          email: `exists-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.emailExists(clinic.email);
      expect(result).toBe(true);
    });

    it('should return false when email does not exist', async () => {
      const result = await clinicRepository.emailExists(
        'does-not-exist@example.com',
      );
      expect(result).toBe(false);
    });

    it('should return false when email belongs to excluded clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Email Exclude',
          nameAr: 'استثناء البريد',
          email: `exclude-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.emailExists(clinic.email, clinic.id);
      expect(result).toBe(false);
    });

    it('should return true when email belongs to a different clinic', async () => {
      const clinic1 = await prisma.clinic.create({
        data: {
          nameFr: 'Different 1',
          nameAr: 'مختلف ١',
          email: `diff1-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      const clinic2 = await prisma.clinic.create({
        data: {
          nameFr: 'Different 2',
          nameAr: 'مختلف ٢',
          email: `diff2-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic1.id, clinic2.id);

      const result = await clinicRepository.emailExists(clinic2.email, clinic1.id);
      expect(result).toBe(true);
    });
  });

  describe('phoneExists', () => {
    it('should return true when phone exists', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Phone Exists',
          nameAr: 'الهاتف موجود',
          email: `phone-exists-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.phoneExists(phone);
      expect(result).toBe(true);
    });

    it('should return false when phone does not exist', async () => {
      const result = await clinicRepository.phoneExists('0555555555');
      expect(result).toBe(false);
    });

    it('should return false when phone belongs to excluded clinic', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Phone Exclude',
          nameAr: 'استثناء الهاتف',
          email: `phone-exclude-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.phoneExists(phone, clinic.id);
      expect(result).toBe(false);
    });
  });

  describe('updateLogo', () => {
    it('should update clinic logo', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Logo Update',
          nameAr: 'تحديث الشعار',
          email: `logo-update-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.updateLogo(
        clinic.id,
        '/uploads/logo.jpg',
        'file-123',
      );

      expect(result.logoPath).toBe('/uploads/logo.jpg');
      expect(result.logoFileId).toBe('file-123');
    });
  });

  describe('verify', () => {
    it('should verify a clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Verify Clinic',
          nameAr: 'توثيق العيادة',
          email: `verify-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isVerified: false,
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.verify(clinic.id);

      expect(result.isVerified).toBe(true);
    });
  });

  describe('suspend and unsuspend', () => {
    it('should suspend a clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Suspend Clinic',
          nameAr: 'تعليق العيادة',
          email: `suspend-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isSuspended: false,
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.suspend(clinic.id);

      expect(result.isSuspended).toBe(true);
    });

    it('should unsuspend a clinic', async () => {
      const clinic = await prisma.clinic.create({
        data: {
          nameFr: 'Unsuspend Clinic',
          nameAr: 'إلغاء تعليق العيادة',
          email: `unsuspend-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          isSuspended: true,
        },
      });
      clinicIds.push(clinic.id);

      const result = await clinicRepository.unsuspend(clinic.id);

      expect(result.isSuspended).toBe(false);
    });
  });
});

