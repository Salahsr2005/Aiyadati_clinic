import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('DoctorRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let doctorRepository: typeof import('../../../src/repositories/doctor.repository')['doctorRepository'];
  let wilayaId: string;
  let specialtyId: string;
  const doctorIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ doctorRepository } = await import('../../../src/repositories/doctor.repository'));

    await prisma.$connect();

    // Create test data dependencies
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    const specialty = await prisma.specialty.create({
      data: {
        nameFr: `Test Specialty ${crypto.randomUUID()}`,
        nameAr: `تخصص اختبار ${crypto.randomUUID()}`,
        isActive: true,
      },
    });
    specialtyId = specialty.id;
  }, 180000);

  afterEach(async () => {
    if (doctorIds.length > 0) {
      // Delete doctor specialties first due to foreign key constraints
      await prisma.doctorSpecialty.deleteMany({
        where: { doctorId: { in: doctorIds } },
      });
      await prisma.doctor.deleteMany({
        where: { id: { in: doctorIds } },
      });
      doctorIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createDoctorData = (
    overrides: Partial<{
      email: string;
      password: string;
      firstNameFr: string;
      firstNameAr: string;
      lastNameFr: string;
      lastNameAr: string;
      phone: string;
      wilayaId: string;
      isRegistered?: boolean;
      isVerified?: boolean;
      isCompleted?: boolean;
    }> = {},
  ) => ({
    email: `doctor-${crypto.randomUUID()}@example.com`,
    password: 'hashed-password',
    firstNameFr: 'Test',
    firstNameAr: 'اختبار',
    lastNameFr: 'Doctor',
    lastNameAr: 'طبيب',
    phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
    wilayaId,
    isRegistered: true,
    isVerified: false,
    isCompleted: false,
    ...overrides,
  });

  // ============================================================
  // Tests
  // ============================================================

  describe('findById', () => {
    it('should find a doctor by id with all relations', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `find-by-id-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Find',
          firstNameAr: 'ابحث',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.findById(doctor.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(doctor.id);
      expect(result?.email).toBe(doctor.email);
      expect(result?.firstNameFr).toBe('Find');
      expect(result?.lastNameFr).toBe('Test');
      expect(result?.wilaya).toBeDefined();
      expect(result?.wilaya.id).toBe(wilayaId);
    });

    it('should return null when doctor does not exist', async () => {
      const result = await doctorRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find a doctor by email', async () => {
      const email = `find-email-${crypto.randomUUID()}@example.com`;
      const doctor = await prisma.doctor.create({
        data: {
          email,
          password: 'hashed-password',
          firstNameFr: 'Email',
          firstNameAr: 'البريد',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.findByEmail(email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(doctor.id);
      expect(result?.email).toBe(email);
    });

    it('should return null when email does not exist', async () => {
      const result = await doctorRepository.findByEmail(
        'nonexistent@example.com',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByPhone', () => {
    it('should find a doctor by phone', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const doctor = await prisma.doctor.create({
        data: {
          email: `phone-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Phone',
          firstNameAr: 'الهاتف',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.findByPhone(phone);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(doctor.id);
      expect(result?.phone).toBe(phone);
    });

    it('should return null when phone does not exist', async () => {
      const result = await doctorRepository.findByPhone('0555555555');
      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a doctor with default values', async () => {
      const data = createDoctorData({
        email: `create-${crypto.randomUUID()}@example.com`,
      });

      const result = await doctorRepository.create(data);

      doctorIds.push(result.id);

      expect(result).toMatchObject({
        email: data.email,
        firstNameFr: data.firstNameFr,
        lastNameFr: data.lastNameFr,
        phone: data.phone,
        wilayaId,
        isRegistered: true,
        isVerified: false,
        isCompleted: false,
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
      expect(result.updatedAt).toBeInstanceOf(Date);
    });

    it('should create a doctor with custom status values', async () => {
      const data = createDoctorData({
        email: `create-custom-${crypto.randomUUID()}@example.com`,
        isRegistered: false,
        isVerified: true,
        isCompleted: true,
      });

      const result = await doctorRepository.create(data);

      doctorIds.push(result.id);

      expect(result.isRegistered).toBe(false);
      expect(result.isVerified).toBe(true);
      expect(result.isCompleted).toBe(true);
    });
  });

  describe('update', () => {
    it('should update a doctor', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `update-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Original',
          firstNameAr: 'الأصلي',
          lastNameFr: 'Name',
          lastNameAr: 'الاسم',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.update(doctor.id, {
        firstNameFr: 'Updated',
        lastNameFr: 'Doctor',
        isVerified: true,
      });

      expect(result.id).toBe(doctor.id);
      expect(result.firstNameFr).toBe('Updated');
      expect(result.lastNameFr).toBe('Doctor');
      expect(result.isVerified).toBe(true);
    });

    it('should update photoFileId when provided', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `photo-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Photo',
          firstNameAr: 'الصورة',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.update(doctor.id, {
        photoFileId: 'file-123',
        firstNameFr: 'Photo Updated',
      });

      expect(result.photoFileId).toBe('file-123');
      expect(result.firstNameFr).toBe('Photo Updated');
    });
  });

  describe('findAll', () => {
    it('should return doctors with pagination', async () => {
      const doctors = await Promise.all([
        prisma.doctor.create({
          data: {
            email: `findall1-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            firstNameFr: 'Doctor A',
            firstNameAr: 'طبيب أ',
            lastNameFr: 'One',
            lastNameAr: 'واحد',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
          },
        }),
        prisma.doctor.create({
          data: {
            email: `findall2-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            firstNameFr: 'Doctor B',
            firstNameAr: 'طبيب ب',
            lastNameFr: 'Two',
            lastNameAr: 'اثنان',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
          },
        }),
        prisma.doctor.create({
          data: {
            email: `findall3-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            firstNameFr: 'Doctor C',
            firstNameAr: 'طبيب ج',
            lastNameFr: 'Three',
            lastNameAr: 'ثلاثة',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
          },
        }),
      ]);
      doctorIds.push(...doctors.map((d) => d.id));

      const result = await doctorRepository.findAll({
        page: 1,
        limit: 2,
      });

      expect(result.doctors).toHaveLength(2);
      expect(result.total).toBe(3);
    });

    it('should use default pagination', async () => {
      const doctors = await Promise.all([
        prisma.doctor.create({
          data: {
            email: `default1-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            firstNameFr: 'Default 1',
            firstNameAr: 'افتراضي ١',
            lastNameFr: 'Test',
            lastNameAr: 'اختبار',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
          },
        }),
        prisma.doctor.create({
          data: {
            email: `default2-${crypto.randomUUID()}@example.com`,
            password: 'hashed-password',
            firstNameFr: 'Default 2',
            firstNameAr: 'افتراضي ٢',
            lastNameFr: 'Test',
            lastNameAr: 'اختبار',
            phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
            wilaya: { connect: { id: wilayaId } },
          },
        }),
      ]);
      doctorIds.push(...doctors.map((d) => d.id));

      const result = await doctorRepository.findAll({});

      expect(result.doctors).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should filter by wilayaId', async () => {
      const doctor1 = await prisma.doctor.create({
        data: {
          email: `wilaya1-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Wilaya Test',
          firstNameAr: 'اختبار الولاية',
          lastNameFr: 'One',
          lastNameAr: 'واحد',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor1.id);

      const result = await doctorRepository.findAll({
        wilayaId,
      });

      expect(result.doctors.some((d) => d.id === doctor1.id)).toBe(true);
      expect(result.total).toBeGreaterThan(0);
    });

    it('should filter by specialtyId', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `specialty-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Specialty Test',
          firstNameAr: 'اختبار التخصص',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      await prisma.doctorSpecialty.create({
        data: {
          doctorId: doctor.id,
          specialtyId,
        },
      });

      const result = await doctorRepository.findAll({
        specialtyId,
      });

      expect(result.doctors.some((d) => d.id === doctor.id)).toBe(true);
    });

    it('should filter by isVerified', async () => {
      const verified = await prisma.doctor.create({
        data: {
          email: `verified-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Verified',
          firstNameAr: 'موثق',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isVerified: true,
        },
      });
      const unverified = await prisma.doctor.create({
        data: {
          email: `unverified-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Unverified',
          firstNameAr: 'غير موثق',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isVerified: false,
        },
      });
      doctorIds.push(verified.id, unverified.id);

      const result = await doctorRepository.findAll({
        isVerified: true,
      });

      expect(result.doctors.some((d) => d.id === verified.id)).toBe(true);
      expect(result.doctors.some((d) => d.id === unverified.id)).toBe(false);
    });

    it('should filter by isSuspended', async () => {
      const suspended = await prisma.doctor.create({
        data: {
          email: `suspended-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Suspended',
          firstNameAr: 'موقوف',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isSuspended: true,
        },
      });
      const active = await prisma.doctor.create({
        data: {
          email: `active-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Active',
          firstNameAr: 'نشط',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isSuspended: false,
        },
      });
      doctorIds.push(suspended.id, active.id);

      const result = await doctorRepository.findAll({
        isSuspended: true,
      });

      expect(result.doctors.some((d) => d.id === suspended.id)).toBe(true);
      expect(result.doctors.some((d) => d.id === active.id)).toBe(false);
    });

    it('should search across name fields', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `search-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Ahmed',
          firstNameAr: 'أحمد',
          lastNameFr: 'Benali',
          lastNameAr: 'بن علي',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.findAll({
        search: 'Ahmed',
      });

      expect(result.doctors.some((d) => d.id === doctor.id)).toBe(true);
    });
  });

  describe('emailExists', () => {
    it('should return true when email exists', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `exists-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Exists',
          firstNameAr: 'موجود',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.emailExists(doctor.email);
      expect(result).toBe(true);
    });

    it('should return false when email does not exist', async () => {
      const result = await doctorRepository.emailExists(
        'does-not-exist@example.com',
      );
      expect(result).toBe(false);
    });

    it('should return false when email belongs to excluded doctor', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `exclude-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Exclude',
          firstNameAr: 'استثناء',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.emailExists(doctor.email, doctor.id);
      expect(result).toBe(false);
    });

    it('should return true when email belongs to a different doctor', async () => {
      const doctor1 = await prisma.doctor.create({
        data: {
          email: `different1-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Different 1',
          firstNameAr: 'مختلف ١',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      const doctor2 = await prisma.doctor.create({
        data: {
          email: `different2-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Different 2',
          firstNameAr: 'مختلف ٢',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor1.id, doctor2.id);

      const result = await doctorRepository.emailExists(doctor2.email, doctor1.id);
      expect(result).toBe(true);
    });
  });

  describe('phoneExists', () => {
    it('should return true when phone exists', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const doctor = await prisma.doctor.create({
        data: {
          email: `phone-exists-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Phone Exists',
          firstNameAr: 'الهاتف موجود',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.phoneExists(phone);
      expect(result).toBe(true);
    });

    it('should return false when phone does not exist', async () => {
      const result = await doctorRepository.phoneExists('0555555555');
      expect(result).toBe(false);
    });

    it('should return false when phone belongs to excluded doctor', async () => {
      const phone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
      const doctor = await prisma.doctor.create({
        data: {
          email: `phone-exclude-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Phone Exclude',
          firstNameAr: 'استثناء الهاتف',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.phoneExists(phone, doctor.id);
      expect(result).toBe(false);
    });
  });

  describe('updatePhoto', () => {
    it('should update doctor photo', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `update-photo-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Photo Update',
          firstNameAr: 'تحديث الصورة',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.updatePhoto(
        doctor.id,
        '/uploads/photo.jpg',
        'file-123',
      );

      expect(result.photoPath).toBe('/uploads/photo.jpg');
      expect(result.photoFileId).toBe('file-123');
    });
  });

  describe('verify', () => {
    it('should verify a doctor and clear rejection reason', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `verify-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Verify',
          firstNameAr: 'توثيق',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isVerified: false,
          rejectionReason: 'Invalid documents',
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.verify(doctor.id);

      expect(result.isVerified).toBe(true);
      expect(result.rejectionReason).toBeNull();
    });
  });

  describe('reject', () => {
    it('should reject a doctor with a reason', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `reject-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Reject',
          firstNameAr: 'رفض',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isVerified: false,
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.reject(
        doctor.id,
        'Invalid documents provided',
      );

      expect(result.isVerified).toBe(false);
      expect(result.rejectionReason).toBe('Invalid documents provided');
    });
  });

  describe('suspend and unsuspend', () => {
    it('should suspend a doctor', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `suspend-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Suspend',
          firstNameAr: 'تعليق',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isSuspended: false,
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.suspend(doctor.id);

      expect(result.isSuspended).toBe(true);
    });

    it('should unsuspend a doctor', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `unsuspend-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Unsuspend',
          firstNameAr: 'إلغاء التعليق',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isSuspended: true,
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.unsuspend(doctor.id);

      expect(result.isSuspended).toBe(false);
    });
  });

  describe('setSpecialties', () => {
    it('should set specialties for a doctor', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `specialties-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Specialties',
          firstNameAr: 'التخصصات',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      // Create additional specialties
      const specialty2 = await prisma.specialty.create({
        data: {
          nameFr: `Specialty 2 ${crypto.randomUUID()}`,
          nameAr: `تخصص ٢ ${crypto.randomUUID()}`,
          isActive: true,
        },
      });

      await doctorRepository.setSpecialties(doctor.id, [
        specialtyId,
        specialty2.id,
      ]);

      const doctorWithSpecialties = await prisma.doctor.findUnique({
        where: { id: doctor.id },
        include: { specialties: true },
      });

      expect(doctorWithSpecialties?.specialties).toHaveLength(2);
      expect(
        doctorWithSpecialties?.specialties.some(
          (s) => s.specialtyId === specialtyId,
        ),
      ).toBe(true);
      expect(
        doctorWithSpecialties?.specialties.some(
          (s) => s.specialtyId === specialty2.id,
        ),
      ).toBe(true);
    });

    it('should clear specialties when empty array is passed', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `clear-specialties-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Clear Specialties',
          firstNameAr: 'مسح التخصصات',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      doctorIds.push(doctor.id);

      // First add a specialty
      await prisma.doctorSpecialty.create({
        data: {
          doctorId: doctor.id,
          specialtyId,
        },
      });

      // Then clear all specialties
      await doctorRepository.setSpecialties(doctor.id, []);

      const doctorWithSpecialties = await prisma.doctor.findUnique({
        where: { id: doctor.id },
        include: { specialties: true },
      });

      expect(doctorWithSpecialties?.specialties).toHaveLength(0);
    });
  });

  // ============================================================
  // NEW: updateBookingAvailability
  // ============================================================

  describe('updateBookingAvailability', () => {
    it('should update isAvailableForBooking and messageForUser', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `booking-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Booking',
          firstNameAr: 'حجز',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: false,
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.updateBookingAvailability(doctor.id, {
        isAvailableForBooking: true,
        messageForUser: 'Available for appointments',
      });

      expect(result.isAvailableForBooking).toBe(true);
      expect(result.messageForUser).toBe('Available for appointments');
    });

    it('should set messageForUser to null when not provided', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `booking-null-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Booking Null',
          firstNameAr: 'حجز فارغ',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: false,
          messageForUser: 'Old message',
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.updateBookingAvailability(doctor.id, {
        isAvailableForBooking: true,
      });

      expect(result.isAvailableForBooking).toBe(true);
      expect(result.messageForUser).toBeNull();
    });

    it('should clear messageForUser when setting unavailable', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `booking-unavailable-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Booking Unavailable',
          firstNameAr: 'حجز غير متاح',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: true,
          messageForUser: 'Currently available',
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.updateBookingAvailability(doctor.id, {
        isAvailableForBooking: false,
      });

      expect(result.isAvailableForBooking).toBe(false);
      expect(result.messageForUser).toBeNull();
    });
  });

  // ============================================================
  // NEW: findAll with isAvailableForBooking filter
  // ============================================================

  describe('findAll with isAvailableForBooking', () => {
    it('should filter doctors by isAvailableForBooking', async () => {
      const available = await prisma.doctor.create({
        data: {
          email: `available-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Available',
          firstNameAr: 'متاح',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: true,
          isVerified: true,
        },
      });
      const unavailable = await prisma.doctor.create({
        data: {
          email: `unavailable-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Unavailable',
          firstNameAr: 'غير متاح',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: false,
          isVerified: true,
        },
      });
      doctorIds.push(available.id, unavailable.id);

      const result = await doctorRepository.findAll({
        isAvailableForBooking: true,
      });

      expect(result.doctors.some((d) => d.id === available.id)).toBe(true);
      expect(result.doctors.some((d) => d.id === unavailable.id)).toBe(false);
    });

    it('should filter by isAvailableForBooking with other filters', async () => {
      const doctor = await prisma.doctor.create({
        data: {
          email: `filter-available-${crypto.randomUUID()}@example.com`,
          password: 'hashed-password',
          firstNameFr: 'Filter',
          firstNameAr: 'فلتر',
          lastNameFr: 'Available',
          lastNameAr: 'متاح',
          phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
          wilaya: { connect: { id: wilayaId } },
          isAvailableForBooking: true,
          isVerified: true,
          isCompleted: true,
          isSuspended: false,
        },
      });
      doctorIds.push(doctor.id);

      const result = await doctorRepository.findAll({
        isAvailableForBooking: true,
        isVerified: true,
        isCompleted: true,
      });

      expect(result.doctors.some((d) => d.id === doctor.id)).toBe(true);
      expect(result.total).toBeGreaterThan(0);
    });
  });
});

