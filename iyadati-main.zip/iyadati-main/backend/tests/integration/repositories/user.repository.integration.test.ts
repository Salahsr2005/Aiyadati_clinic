import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('UserRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let userRepository: typeof import('../../../src/repositories/user.repository')['userRepository'];
  let wilayaId: string;
  const userIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    // No pgbouncer in the test container — direct and pooled URL are identical.
    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    // CRITICAL: Prisma-touching modules are imported here, dynamically,
    // only after process.env points at the container. Do NOT move these
    // to static imports at the top of the file — that would construct
    // the Prisma client against whatever DATABASE_URL .env.test has.
    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ userRepository } = await import('../../../src/repositories/user.repository'));

    await prisma.$connect();

    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;
  }, 180000); // 3 minutes: container start + image pull + 66 migrations can be slow on first run

  afterEach(async () => {
    if (userIds.length > 0) {
      await prisma.user.deleteMany({
        where: { id: { in: userIds } },
      });
      userIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createUserData = (
    overrides: Partial<Prisma.UserCreateInput> = {},
  ): Prisma.UserCreateInput => ({
    email: `test-${crypto.randomUUID()}@example.com`,
    password: 'hashed-password',
    firstName: 'John',
    lastName: 'Doe',
    phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
    dateOfBirth: new Date('2000-01-15'),
    wilaya: {
      connect: { id: wilayaId },
    },
    ...overrides,
  });

  // ============================================================
  // Tests
  // ============================================================

  describe('findById', () => {
    it('should find a user by id and include wilaya', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.findById(user.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(user.id);
      expect(result?.email).toBe(user.email);
      expect(result?.wilaya).toBeDefined();
      expect(result?.wilaya.id).toBe(wilayaId);
    });

    it('should return null when user does not exist', async () => {
      const result = await userRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find a user by email', async () => {
      const user = await prisma.user.create({
        data: createUserData({
          email: `find-email-${crypto.randomUUID()}@example.com`,
        }),
      });
      userIds.push(user.id);

      const result = await userRepository.findByEmail(user.email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(user.id);
      expect(result?.email).toBe(user.email);
    });

    it('should return null when email does not exist', async () => {
      const result = await userRepository.findByEmail(
        'nonexistent@example.com',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByPhone', () => {
    it('should find a user by phone', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.findByPhone(user.phone);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(user.id);
      expect(result?.phone).toBe(user.phone);
    });

    it('should return null when phone does not exist', async () => {
      const result = await userRepository.findByPhone('0555555555');
      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a user', async () => {
      const data = createUserData({
        email: `create-${crypto.randomUUID()}@example.com`,
      });

      const result = await userRepository.create(data);
      userIds.push(result.id);

      expect(result).toMatchObject({
        email: data.email,
        firstName: 'John',
        lastName: 'Doe',
        phone: data.phone,
        wilayaId,
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
      expect(result.updatedAt).toBeInstanceOf(Date);
    });
  });

  describe('update', () => {
    it('should update a user', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.update(user.id, {
        firstName: 'Updated',
        lastName: 'User',
        isVerified: true,
      });

      expect(result.id).toBe(user.id);
      expect(result.firstName).toBe('Updated');
      expect(result.lastName).toBe('User');
      expect(result.isVerified).toBe(true);
    });
  });

  describe('delete', () => {
    it('should delete a user', async () => {
      const user = await prisma.user.create({ data: createUserData() });

      const result = await userRepository.delete(user.id);
      expect(result.id).toBe(user.id);

      const deletedUser = await prisma.user.findUnique({
        where: { id: user.id },
      });
      expect(deletedUser).toBeNull();
    });
  });

  describe('findAllWithFilters', () => {
    it('should return users with pagination', async () => {
      const users = await Promise.all([
        prisma.user.create({
          data: createUserData({
            firstName: 'Alice',
            email: `alice-${crypto.randomUUID()}@example.com`,
          }),
        }),
        prisma.user.create({
          data: createUserData({
            firstName: 'Bob',
            email: `bob-${crypto.randomUUID()}@example.com`,
          }),
        }),
        prisma.user.create({
          data: createUserData({
            firstName: 'Charlie',
            email: `charlie-${crypto.randomUUID()}@example.com`,
          }),
        }),
      ]);
      userIds.push(...users.map((user) => user.id));

      const result = await userRepository.findAllWithFilters({
        page: 1,
        limit: 2,
      });

      expect(result.users).toHaveLength(2);
      expect(result.total).toBe(3);
    });

    it('should filter by search', async () => {
      const john = await prisma.user.create({
        data: createUserData({
          firstName: 'Mohamed',
          lastName: 'Benali',
          email: `mohamed-${crypto.randomUUID()}@example.com`,
        }),
      });
      const other = await prisma.user.create({
        data: createUserData({
          firstName: 'Ahmed',
          lastName: 'Kaci',
          email: `ahmed-${crypto.randomUUID()}@example.com`,
        }),
      });
      userIds.push(john.id, other.id);

      const result = await userRepository.findAllWithFilters({
        search: 'mohamed',
      });

      expect(result.total).toBe(1);
      expect(result.users[0].id).toBe(john.id);
    });

    it('should filter by wilayaId', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.findAllWithFilters({ wilayaId });

      expect(result.users.some((u) => u.id === user.id)).toBe(true);
    });

    it('should filter by isVerified', async () => {
      const verifiedUser = await prisma.user.create({
        data: createUserData({ isVerified: true }),
      });
      const unverifiedUser = await prisma.user.create({
        data: createUserData({ isVerified: false }),
      });
      userIds.push(verifiedUser.id, unverifiedUser.id);

      const result = await userRepository.findAllWithFilters({
        isVerified: true,
      });

      expect(result.users.some((u) => u.id === verifiedUser.id)).toBe(true);
      expect(result.users.some((u) => u.id === unverifiedUser.id)).toBe(
        false,
      );
    });

    it('should filter by isSuspended', async () => {
      const suspendedUser = await prisma.user.create({
        data: createUserData({ isSuspended: true }),
      });
      const activeUser = await prisma.user.create({
        data: createUserData({ isSuspended: false }),
      });
      userIds.push(suspendedUser.id, activeUser.id);

      const result = await userRepository.findAllWithFilters({
        isSuspended: true,
      });

      expect(result.users.some((u) => u.id === suspendedUser.id)).toBe(true);
      expect(result.users.some((u) => u.id === activeUser.id)).toBe(false);
    });
  });

  describe('emailExists', () => {
    it('should return true when email exists', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.emailExists(user.email);
      expect(result).toBe(true);
    });

    it('should return false when email does not exist', async () => {
      const result = await userRepository.emailExists(
        'does-not-exist@example.com',
      );
      expect(result).toBe(false);
    });

    it('should return false when email belongs to excluded user', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.emailExists(user.email, user.id);
      expect(result).toBe(false);
    });
  });

  describe('phoneExists', () => {
    it('should return true when phone exists', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.phoneExists(user.phone);
      expect(result).toBe(true);
    });

    it('should return false when phone does not exist', async () => {
      const result = await userRepository.phoneExists('0555000000');
      expect(result).toBe(false);
    });

    it('should return false when phone belongs to excluded user', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const result = await userRepository.phoneExists(user.phone, user.id);
      expect(result).toBe(false);
    });
  });

  describe('updatePassword', () => {
    it('should update the password', async () => {
      const user = await prisma.user.create({
        data: createUserData({ password: 'old-password' }),
      });
      userIds.push(user.id);

      const result = await userRepository.updatePassword(
        user.id,
        'new-hashed-password',
      );

      expect(result.password).toBe('new-hashed-password');
    });
  });

  describe('setVerificationCode', () => {
    it('should set verification code and expiration date', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      const result = await userRepository.setVerificationCode(
        user.id,
        '123456',
        expiresAt,
      );

      expect(result.verificationCode).toBe('123456');
      expect(result.otpExpiresAt?.getTime()).toBe(expiresAt.getTime());
    });
  });

  describe('verifyUser', () => {
    it('should verify the user and clear verification data', async () => {
      const user = await prisma.user.create({
        data: createUserData({
          isVerified: false,
          verificationCode: '123456',
          otpExpiresAt: new Date(Date.now() + 10 * 60 * 1000),
        }),
      });
      userIds.push(user.id);

      const result = await userRepository.verifyUser(user.id);

      expect(result.isVerified).toBe(true);
      expect(result.verificationCode).toBeNull();
      expect(result.otpExpiresAt).toBeNull();
    });
  });

  describe('suspend and unsuspend', () => {
    it('should suspend a user with a reason', async () => {
      const user = await prisma.user.create({
        data: createUserData({ isSuspended: false }),
      });
      userIds.push(user.id);

      const result = await userRepository.suspend(
        user.id,
        'Violation of platform rules',
      );

      expect(result.isSuspended).toBe(true);
      expect(result.suspensionReason).toBe('Violation of platform rules');
    });

    it('should unsuspend a user and clear the reason', async () => {
      const user = await prisma.user.create({
        data: createUserData({
          isSuspended: true,
          suspensionReason: 'Temporary suspension',
        }),
      });
      userIds.push(user.id);

      const result = await userRepository.unsuspend(user.id);

      expect(result.isSuspended).toBe(false);
      expect(result.suspensionReason).toBeNull();
    });
  });

  describe('findByQrCode', () => {
    it('should find a user by QR code', async () => {
      const user = await prisma.user.create({
        data: createUserData({
          qrCode: crypto.randomUUID(),
          trustLevel: 3,
          trustPoints: 75,
          isSuspended: false,
        }),
      });
      userIds.push(user.id);

      const wallet = await prisma.userWallet.create({
        data: { userId: user.id, credits: 100 },
      });

      const result = await userRepository.findByQrCode(
        user.qrCode as string,
      );

      expect(result).not.toBeNull();
      expect(result).toMatchObject({
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        trustLevel: 3,
        trustPoints: 75,
        isSuspended: false,
        wallet: { id: wallet.id, credits: 100 },
      });
    });
  });

  describe('regenerateQrCode', () => {
    it('should generate a new QR code', async () => {
      const user = await prisma.user.create({ data: createUserData() });
      userIds.push(user.id);

      const oldQrCode = user.qrCode;

      const result = await userRepository.regenerateQrCode(user.id);

      expect(result.qrCode).toBeDefined();
      expect(result.qrCode).not.toBe(oldQrCode);

      const updatedUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { qrCode: true },
      });
      expect(updatedUser?.qrCode).toBe(result.qrCode);
    });
  });
});