import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import type { PrismaClient, Prisma } from '@prisma/client';

describe('AdminRepository - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let adminRepository: typeof import('../../../src/repositories/admin.repository')['adminRepository'];
  const adminIds: string[] = [];

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    ({ adminRepository } = await import('../../../src/repositories/admin.repository'));

    await prisma.$connect();
  }, 180000);

  afterEach(async () => {
    if (adminIds.length > 0) {
      await prisma.admin.deleteMany({
        where: { id: { in: adminIds } },
      });
      adminIds.length = 0;
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const createAdminData = (
    overrides: Partial<Prisma.AdminCreateInput> = {},
  ): Prisma.AdminCreateInput => ({
    email: `admin-${crypto.randomUUID()}@example.com`,
    password: 'hashed-password',
    name: 'Test Admin',
    ...overrides,
  });

  // ============================================================
  // Tests
  // ============================================================

  describe('findById', () => {
    it('should find an admin by id', async () => {
      const admin = await prisma.admin.create({ data: createAdminData() });
      adminIds.push(admin.id);

      const result = await adminRepository.findById(admin.id);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(admin.id);
      expect(result?.email).toBe(admin.email);
      expect(result?.name).toBe(admin.name);
    });

    it('should return null when admin does not exist', async () => {
      const result = await adminRepository.findById(
        '00000000-0000-0000-0000-000000000000',
      );
      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find an admin by email', async () => {
      const admin = await prisma.admin.create({
        data: createAdminData({
          email: `find-email-${crypto.randomUUID()}@example.com`,
        }),
      });
      adminIds.push(admin.id);

      const result = await adminRepository.findByEmail(admin.email);

      expect(result).not.toBeNull();
      expect(result?.id).toBe(admin.id);
      expect(result?.email).toBe(admin.email);
    });

    it('should return null when email does not exist', async () => {
      const result = await adminRepository.findByEmail(
        'nonexistent@example.com',
      );
      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create an admin', async () => {
      const data = createAdminData({
        email: `create-${crypto.randomUUID()}@example.com`,
        name: 'New Admin',
      });

      const result = await adminRepository.create(data);
      adminIds.push(result.id);

      expect(result).toMatchObject({
        email: data.email,
        name: data.name,
        password: data.password,
      });
      expect(result.id).toBeDefined();
      expect(result.createdAt).toBeInstanceOf(Date);
      expect(result.updatedAt).toBeInstanceOf(Date);
    });
  });

  describe('update', () => {
    it('should update an admin', async () => {
      const admin = await prisma.admin.create({
        data: createAdminData({
          name: 'Original Name',
          email: `update-${crypto.randomUUID()}@example.com`,
        }),
      });
      adminIds.push(admin.id);

      const result = await adminRepository.update(admin.id, {
        name: 'Updated Name',
        email: `updated-${crypto.randomUUID()}@example.com`,
      });

      expect(result.id).toBe(admin.id);
      expect(result.name).toBe('Updated Name');
      expect(result.email).not.toBe(admin.email);
    });
  });

  describe('delete', () => {
    it('should delete an admin', async () => {
      const admin = await prisma.admin.create({ data: createAdminData() });

      const result = await adminRepository.delete(admin.id);
      expect(result.id).toBe(admin.id);

      const deletedAdmin = await prisma.admin.findUnique({
        where: { id: admin.id },
      });
      expect(deletedAdmin).toBeNull();
    });
  });

  describe('findAll', () => {
    it('should return admins with pagination', async () => {
      const admins = await Promise.all([
        prisma.admin.create({
          data: createAdminData({
            name: 'Admin A',
            email: `a-${crypto.randomUUID()}@example.com`,
          }),
        }),
        prisma.admin.create({
          data: createAdminData({
            name: 'Admin B',
            email: `b-${crypto.randomUUID()}@example.com`,
          }),
        }),
        prisma.admin.create({
          data: createAdminData({
            name: 'Admin C',
            email: `c-${crypto.randomUUID()}@example.com`,
          }),
        }),
      ]);
      adminIds.push(...admins.map((admin) => admin.id));

      const result = await adminRepository.findAll(1, 2);

      expect(result.admins).toHaveLength(2);
      expect(result.total).toBe(3);
    });

    it('should use default pagination when not provided', async () => {
      const admins = await Promise.all([
        prisma.admin.create({
          data: createAdminData({ email: `default1-${crypto.randomUUID()}@example.com` }),
        }),
        prisma.admin.create({
          data: createAdminData({ email: `default2-${crypto.randomUUID()}@example.com` }),
        }),
      ]);
      adminIds.push(...admins.map((admin) => admin.id));

      const result = await adminRepository.findAll();

      expect(result.admins).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should return admins sorted by createdAt descending', async () => {
      const admin1 = await prisma.admin.create({
        data: createAdminData({ email: `sort1-${crypto.randomUUID()}@example.com` }),
      });
      // Wait a bit to ensure different timestamps
      await new Promise((resolve) => setTimeout(resolve, 10));
      const admin2 = await prisma.admin.create({
        data: createAdminData({ email: `sort2-${crypto.randomUUID()}@example.com` }),
      });
      adminIds.push(admin1.id, admin2.id);

      const result = await adminRepository.findAll(1, 10);

      expect(result.admins[0].id).toBe(admin2.id);
      expect(result.admins[1].id).toBe(admin1.id);
    });

    it('should handle empty result set', async () => {
      const result = await adminRepository.findAll(999, 10);

      expect(result.admins).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  describe('updatePassword', () => {
    it('should update the admin password', async () => {
      const admin = await prisma.admin.create({
        data: createAdminData({
          password: 'old-hashed-password',
        }),
      });
      adminIds.push(admin.id);

      const result = await adminRepository.updatePassword(
        admin.id,
        'new-hashed-password',
      );

      expect(result.password).toBe('new-hashed-password');
      expect(result.id).toBe(admin.id);
    });
  });

  describe('emailExists', () => {
    it('should return true when email exists', async () => {
      const admin = await prisma.admin.create({
        data: createAdminData({
          email: `exists-${crypto.randomUUID()}@example.com`,
        }),
      });
      adminIds.push(admin.id);

      const result = await adminRepository.emailExists(admin.email);
      expect(result).toBe(true);
    });

    it('should return false when email does not exist', async () => {
      const result = await adminRepository.emailExists(
        'does-not-exist@example.com',
      );
      expect(result).toBe(false);
    });

    it('should return false when email belongs to excluded admin', async () => {
      const admin = await prisma.admin.create({
        data: createAdminData({
          email: `exclude-${crypto.randomUUID()}@example.com`,
        }),
      });
      adminIds.push(admin.id);

      const result = await adminRepository.emailExists(admin.email, admin.id);
      expect(result).toBe(false);
    });

    it('should return true when email belongs to a different admin', async () => {
      const admin1 = await prisma.admin.create({
        data: createAdminData({
          email: `different1-${crypto.randomUUID()}@example.com`,
        }),
      });
      const admin2 = await prisma.admin.create({
        data: createAdminData({
          email: `different2-${crypto.randomUUID()}@example.com`,
        }),
      });
      adminIds.push(admin1.id, admin2.id);

      const result = await adminRepository.emailExists(admin2.email, admin1.id);
      expect(result).toBe(true);
    });
  });
});

