import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { PrismaClient } from '@prisma/client';

let app: any;
let prisma: PrismaClient;
let pgContainer: StartedPostgreSqlContainer;

// Test data
let wilayaId: string;

// Users and tokens
let adminToken: string;
let adminUser: any;
let userToken: string;
let userUser: any;
let regularUserToken: string;
let regularUser: any;

const JWT_SECRET = process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

// Cleanup tracking
const cleanupIds = {
  users: [] as string[],
  contacts: [] as string[],
  documents: [] as string[],
};

describe('User Module - Integration Tests', () => {
  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    await prisma.$connect();

    const appModule = await import('../../../../../src/app');
    app = appModule.default;

    // ============================================================
    // Create test data
    // ============================================================

    // 1. Create Wilaya
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // 2. Create Admin User
    const adminPassword = await bcrypt.hash('Admin123!', 12);
    adminUser = await prisma.admin.create({
      data: {
        email: `admin-${crypto.randomUUID()}@example.com`,
        password: adminPassword,
        name: 'Test Admin',
      },
    });
    cleanupIds.users.push(adminUser.id);

    adminToken = jwt.sign(
      { id: adminUser.id, email: adminUser.email, role: 'ADMIN', name: 'Test Admin' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 3. Create Regular User (for self-service tests)
    const userPassword = await bcrypt.hash('User123!', 12);
    userUser = await prisma.user.create({
      data: {
        email: `user-${crypto.randomUUID()}@example.com`,
        password: userPassword,
        firstName: 'Test',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    cleanupIds.users.push(userUser.id);

    userToken = jwt.sign(
      { id: userUser.id, email: userUser.email, role: 'USER', name: 'Test User' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 4. Create Another Regular User (for staff tests)
    const regularPassword = await bcrypt.hash('Regular123!', 12);
    regularUser = await prisma.user.create({
      data: {
        email: `regular-${crypto.randomUUID()}@example.com`,
        password: regularPassword,
        firstName: 'Regular',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1992-02-02'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    cleanupIds.users.push(regularUser.id);

    regularUserToken = jwt.sign(
      { id: regularUser.id, email: regularUser.email, role: 'USER', name: 'Regular User' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    if (cleanupIds.contacts.length > 0) {
      await prisma.contactUser.deleteMany({
        where: { id: { in: cleanupIds.contacts } },
      });
      cleanupIds.contacts = [];
    }
    if (cleanupIds.documents.length > 0) {
      await prisma.userDocument.deleteMany({
        where: { id: { in: cleanupIds.documents } },
      });
      cleanupIds.documents = [];
    }
  });

  afterAll(async () => {
    // Safety net - delete any remaining users that reference wilaya
    await prisma.user.deleteMany({ where: { wilayaId } });
    await prisma.admin.deleteMany({ where: { id: { in: cleanupIds.users } } });
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const generatePhone = (): string => {
    const prefixes = ['05', '06', '07'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const rest = Math.floor(10000000 + Math.random() * 89999999).toString();
    return prefix + rest;
  };

  // ============================================================
  // Tests - Staff: Get All Users
  // ============================================================

  describe('GET /api/v1/user/v1', () => {
    it('should return paginated users with default params', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeDefined();
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should filter by search', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1')
        .query({ search: 'Regular' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      // Should find the regular user
      const found = response.body.data.some((u: any) => u.email === regularUser.email);
      expect(found).toBe(true);
    });

    it('should filter by isVerified', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1')
        .query({ isVerified: 'true' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      response.body.data.forEach((user: any) => {
        expect(user.isVerified).toBe(true);
      });
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1');

      expect(response.status).toBe(401);
    });

    it('should return 403 for non-admin user', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1')
        .set('Authorization', `Bearer ${regularUserToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Staff: Get User by ID
  // ============================================================

  describe('GET /api/v1/user/v1/id/:id', () => {
    it('should get user by ID', async () => {
      const response = await request(app)
        .get(`/api/v1/user/v1/id/${userUser.id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(userUser.id);
      expect(response.body.data.email).toBe(userUser.email);
    });

    it('should return 404 for non-existent user', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/id/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Staff: Get User by Email
  // ============================================================

  describe('GET /api/v1/user/v1/email/:email', () => {
    it('should get user by email', async () => {
      const response = await request(app)
        .get(`/api/v1/user/v1/email/${userUser.email}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(userUser.id);
    });

    it('should return 404 for non-existent email', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/email/nonexistent@example.com')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Staff: Get User by Phone
  // ============================================================

  describe('GET /api/v1/user/v1/phone/:phone', () => {
    it('should get user by phone', async () => {
      const response = await request(app)
        .get(`/api/v1/user/v1/phone/${userUser.phone}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(userUser.id);
    });

    it('should return 404 for non-existent phone', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/phone/0000000000')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Staff: Suspend User
  // ============================================================

  describe('POST /api/v1/user/v1/:id/suspend', () => {
    it('should suspend a user', async () => {
      // Create a user to suspend
      const suspendUser = await prisma.user.create({
        data: {
          email: `suspend-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstName: 'Suspend',
          lastName: 'Test',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: true,
          isSuspended: false,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(suspendUser.id);

      const response = await request(app)
        .post(`/api/v1/user/v1/${suspendUser.id}/suspend`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ reason: 'Violation of platform rules' });

      expect(response.status).toBe(200);
      expect(response.body.data.isSuspended).toBe(true);
      expect(response.body.data.suspensionReason).toBe('Violation of platform rules');
    });

    it('should return 400 if already suspended', async () => {
      // Create a suspended user
      const suspendedUser = await prisma.user.create({
        data: {
          email: `already-suspended-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstName: 'Already',
          lastName: 'Suspended',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: true,
          isSuspended: true,
          suspensionReason: 'Previous violation',
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(suspendedUser.id);

      const response = await request(app)
        .post(`/api/v1/user/v1/${suspendedUser.id}/suspend`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ reason: 'Another violation' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('already suspended');
    });
  });

    // ============================================================
    // Tests - Staff: Unsuspend User
    // ============================================================

    describe('POST /api/v1/user/v1/:id/unsuspend', () => {
    // ✅ CHANGE: Update test description to match route method
    it('should unsuspend a user', async () => {
        // Create a suspended user
        const unsuspendUser = await prisma.user.create({
        data: {
            email: `unsuspend-${crypto.randomUUID()}@example.com`,
            password: await bcrypt.hash('Password123!', 12),
            firstName: 'Unsuspend',
            lastName: 'Test',
            phone: generatePhone(),
            dateOfBirth: new Date('1990-01-01'),
            isVerified: true,
            isSuspended: true,
            suspensionReason: 'Temporary suspension',
            wilaya: { connect: { id: wilayaId } },
        },
        });
        cleanupIds.users.push(unsuspendUser.id);

        // ✅ FIX: Use PATCH instead of POST
        const response = await request(app)
        .patch(`/api/v1/user/v1/${unsuspendUser.id}/unsuspend`)
        .set('Authorization', `Bearer ${adminToken}`);

        expect(response.status).toBe(200);
        expect(response.body.data.isSuspended).toBe(false);
        expect(response.body.data.suspensionReason).toBeNull();
    });

    it('should return 400 if not suspended', async () => {
        // ✅ FIX: Use PATCH instead of POST
        const response = await request(app)
        .patch(`/api/v1/user/v1/${userUser.id}/unsuspend`)
        .set('Authorization', `Bearer ${adminToken}`);

        expect(response.status).toBe(400);
        expect(response.body.message).toContain('not suspended');
    });
    });

  // ============================================================
  // Tests - Self-Service: Contacts
  // ============================================================

  describe('GET /api/v1/user/v1/me/contacts', () => {
    it('should get user contacts', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/me/contacts')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/me/contacts');

      expect(response.status).toBe(401);
    });
  });

  describe('POST /api/v1/user/v1/me/contacts', () => {
    it('should create a contact', async () => {
      const response = await request(app)
        .post('/api/v1/user/v1/me/contacts')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          firstName: 'Jane',
          lastName: 'Doe',
          phone: generatePhone(),
          dateOfBirth: '1992-02-02',
          relationship: 'sibling',
        });

      expect(response.status).toBe(201);
      expect(response.body.data.firstName).toBe('Jane');
      expect(response.body.data.lastName).toBe('Doe');
      expect(response.body.data.relationship).toBe('sibling');

      if (response.body.data.id) {
        cleanupIds.contacts.push(response.body.data.id);
      }
    });

    it('should reject without required fields', async () => {
      const response = await request(app)
        .post('/api/v1/user/v1/me/contacts')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ firstName: 'Jane' });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  describe('PATCH /api/v1/user/v1/me/contacts/:id', () => {
    it('should update a contact', async () => {
      // First create a contact
      const createResponse = await request(app)
        .post('/api/v1/user/v1/me/contacts')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          firstName: 'John',
          lastName: 'Doe',
          phone: generatePhone(),
          dateOfBirth: '1990-01-01',
          relationship: 'parent',
        });

      expect(createResponse.status).toBe(201);
      const contactId = createResponse.body.data.id;
      cleanupIds.contacts.push(contactId);

      const response = await request(app)
        .patch(`/api/v1/user/v1/me/contacts/${contactId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          firstName: 'John Updated',
          relationship: 'spouse',
        });

      expect(response.status).toBe(200);
      expect(response.body.data.firstName).toBe('John Updated');
      expect(response.body.data.relationship).toBe('spouse');
    });

    it('should return 404 for non-existent contact', async () => {
      const response = await request(app)
        .patch('/api/v1/user/v1/me/contacts/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ firstName: 'Updated' });

      expect(response.status).toBe(404);
    });
  });

  describe('DELETE /api/v1/user/v1/me/contacts/:id', () => {
    it('should delete a contact', async () => {
      // First create a contact
      const createResponse = await request(app)
        .post('/api/v1/user/v1/me/contacts')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          firstName: 'Delete',
          lastName: 'Me',
          phone: generatePhone(),
          dateOfBirth: '1995-01-01',
        });

      expect(createResponse.status).toBe(201);
      const contactId = createResponse.body.data.id;

      const response = await request(app)
        .delete(`/api/v1/user/v1/me/contacts/${contactId}`)
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should return 404 for non-existent contact', async () => {
      const response = await request(app)
        .delete('/api/v1/user/v1/me/contacts/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Self-Service: Documents
  // ============================================================

  describe('GET /api/v1/user/v1/me/documents', () => {
    it('should get user documents', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/me/documents')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/user/v1/me/documents');

      expect(response.status).toBe(401);
    });
  });

  describe('POST /api/v1/user/v1/me/documents', () => {
    it('should upload a document', async () => {
      const response = await request(app)
        .post('/api/v1/user/v1/me/documents')
        .set('Authorization', `Bearer ${userToken}`)
        .attach('document', Buffer.from('fake pdf data'), 'medical.pdf')
        .field('title', 'Medical Report')
        .field('description', 'Annual checkup')
        .field('docDate', '2026-07-15')
        .field('tags', 'checkup,annual');

      expect(response.status).toBe(201);
      expect(response.body.data.fileName).toBe('medical.pdf');
      expect(response.body.data.title).toBe('Medical Report');
      expect(response.body.data.tags).toBe('checkup, annual');
      expect(response.body.data.accessUrl).toBeDefined();

      if (response.body.data.id) {
        cleanupIds.documents.push(response.body.data.id);
      }
    });

    it('should return 400 without file', async () => {
      const response = await request(app)
        .post('/api/v1/user/v1/me/documents')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Test' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Document is required');
    });
  });

  describe('PATCH /api/v1/user/v1/me/documents/:id', () => {
    it('should update a document', async () => {
      // First upload a document
      const uploadResponse = await request(app)
        .post('/api/v1/user/v1/me/documents')
        .set('Authorization', `Bearer ${userToken}`)
        .attach('document', Buffer.from('fake pdf data'), 'update.pdf')
        .field('title', 'Original Title');

      expect(uploadResponse.status).toBe(201);
      const docId = uploadResponse.body.data.id;
      cleanupIds.documents.push(docId);

      const response = await request(app)
        .patch(`/api/v1/user/v1/me/documents/${docId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          title: 'Updated Title',
          tags: 'updated,new',
        });

      expect(response.status).toBe(200);
      expect(response.body.data.title).toBe('Updated Title');
      expect(response.body.data.tags).toBe('updated, new');
    });

    it('should return 404 for non-existent document', async () => {
      const response = await request(app)
        .patch('/api/v1/user/v1/me/documents/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Updated' });

      expect(response.status).toBe(404);
    });
  });

  describe('DELETE /api/v1/user/v1/me/documents/:id', () => {
    it('should delete a document', async () => {
      // First upload a document
      const uploadResponse = await request(app)
        .post('/api/v1/user/v1/me/documents')
        .set('Authorization', `Bearer ${userToken}`)
        .attach('document', Buffer.from('fake pdf data'), 'delete.pdf')
        .field('title', 'To Delete');

      expect(uploadResponse.status).toBe(201);
      const docId = uploadResponse.body.data.id;

      const response = await request(app)
        .delete(`/api/v1/user/v1/me/documents/${docId}`)
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should return 404 for non-existent document', async () => {
      const response = await request(app)
        .delete('/api/v1/user/v1/me/documents/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(404);
    });
  });
});

