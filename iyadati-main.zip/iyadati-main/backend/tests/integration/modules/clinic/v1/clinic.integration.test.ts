// backend/tests/integration/modules/clinic/v1/clinic.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { PrismaClient } from '@prisma/client';

let app: any;
let prisma: PrismaClient;
let pgContainer: StartedPostgreSqlContainer;

// Test data
let wilayaId: string;
let baladyaId: string;
let specialtyId: string;

// Users and tokens
let adminToken: string;
let adminUser: any;
let clinicToken: string;
let clinicUser: any;
let regularUserToken: string;
let regularUser: any;

// Clinic created for tests
let testClinicId: string;
let testClinicEmail: string;
let testClinicPhone: string;

const JWT_SECRET = process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

// Cleanup tracking
const cleanupIds = {
  clinics: [] as string[],
  users: [] as string[],
  documents: [] as string[],
  gallery: [] as string[],
  rooms: [] as string[],
};

describe('Clinic Module - Integration Tests', () => {
  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    await prisma.$connect();

    const appModule = await import('../../../../../src/app');
    app = appModule.default;

    // ============================================================
    // Create test data
    // ============================================================

    // 1. Create Wilaya
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // 2. Create Baladya
    const baladya = await prisma.baladya.create({
      data: {
        nameFr: `Test Baladya ${crypto.randomUUID()}`,
        nameAr: `بلدية اختبار ${crypto.randomUUID()}`,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    baladyaId = baladya.id;

    // 3. Create Specialty
    const specialty = await prisma.specialty.create({
      data: {
        nameFr: `Test Specialty ${crypto.randomUUID()}`,
        nameAr: `تخصص اختبار ${crypto.randomUUID()}`,
        isActive: true,
      },
    });
    specialtyId = specialty.id;

    // 4. Create Admin User
    const adminPassword = await bcrypt.hash('Admin123!', 12);
    adminUser = await prisma.admin.create({
      data: {
        email: `admin-${crypto.randomUUID()}@example.com`,
        password: adminPassword,
        name: 'Test Admin',
      },
    });
    cleanupIds.users.push(adminUser.id);

    adminToken = jwt.sign(
      { id: adminUser.id, email: adminUser.email, role: 'ADMIN', name: 'Test Admin' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 5. Create Regular User
    const userPassword = await bcrypt.hash('User123!', 12);
    regularUser = await prisma.user.create({
      data: {
        email: `user-${crypto.randomUUID()}@example.com`,
        password: userPassword,
        firstName: 'Test',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    cleanupIds.users.push(regularUser.id);

    regularUserToken = jwt.sign(
      { id: regularUser.id, email: regularUser.email, role: 'USER', name: 'Test User' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 6. Create Clinic User
    const clinicPassword = await bcrypt.hash('Clinic123!', 12);
    testClinicEmail = `clinic-${crypto.randomUUID()}@example.com`;
    testClinicPhone = `05${Math.floor(100000000 + Math.random() * 899999999)}`;
    clinicUser = await prisma.clinic.create({
      data: {
        nameFr: 'Test Clinic',
        nameAr: 'عيادة اختبار',
        email: testClinicEmail,
        password: clinicPassword,
        phone: testClinicPhone,
        isVerified: true,
        isSuspended: false,
        isCompleted: false,
        wilaya: { connect: { id: wilayaId } },
        baladya: { connect: { id: baladyaId } },
        facilityType: 'HOSPITAL',
      },
    });
    testClinicId = clinicUser.id;
    cleanupIds.clinics.push(clinicUser.id);

    clinicToken = jwt.sign(
      {
        id: clinicUser.id,
        email: clinicUser.email,
        role: 'CLINIC',
        name: clinicUser.nameFr,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    if (cleanupIds.documents.length > 0) {
      await prisma.clinicDocument.deleteMany({
        where: { id: { in: cleanupIds.documents } },
      });
      cleanupIds.documents = [];
    }
    if (cleanupIds.gallery.length > 0) {
      await prisma.clinicGallery.deleteMany({
        where: { id: { in: cleanupIds.gallery } },
      });
      cleanupIds.gallery = [];
    }
    if (cleanupIds.rooms.length > 0) {
      await prisma.clinicRoom.deleteMany({
        where: { id: { in: cleanupIds.rooms } },
      });
      cleanupIds.rooms = [];
    }
  });

  afterAll(async () => {
    // Delete clinics first
    if (cleanupIds.clinics.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: cleanupIds.clinics } },
      });
    }
    // Delete users
    if (cleanupIds.users.length > 0) {
      await prisma.admin.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
      await prisma.user.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
    }
    // Safety net - delete any remaining doctors/users/clinics that reference wilaya
    await prisma.doctor.deleteMany({ where: { wilayaId } });
    await prisma.user.deleteMany({ where: { wilayaId } });
    await prisma.clinic.deleteMany({ where: { wilayaId } });

    await prisma.specialty.deleteMany({ where: { id: specialtyId } });
    await prisma.baladya.deleteMany({ where: { id: baladyaId } });
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const generatePhone = (): string => {
    const prefixes = ['05', '06', '07'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const rest = Math.floor(10000000 + Math.random() * 89999999).toString();
    return prefix + rest;
  };

  // ============================================================
  // Tests - Staff: Get All Clinics
  // ============================================================

  describe('GET /api/v1/clinic/v1', () => {
    it('should return paginated clinics with default params', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeDefined();
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should filter by isVerified', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1')
        .query({ isVerified: 'true' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      response.body.data.forEach((clinic: any) => {
        expect(clinic.isVerified).toBe(true);
      });
    });

    it('should filter by facilityType', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1')
        .query({ facilityType: 'HOSPITAL' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      response.body.data.forEach((clinic: any) => {
        expect(clinic.facilityType).toBe('HOSPITAL');
      });
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1');

      expect(response.status).toBe(401);
    });

    it('should return 403 for non-admin user', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${regularUserToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Staff: Create Clinic
  // ============================================================

  describe('POST /api/v1/clinic/v1', () => {
    it('should create a clinic successfully', async () => {
      const email = `create-${crypto.randomUUID()}@example.com`;
      const phone = generatePhone();

      const response = await request(app)
        .post('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          nameFr: 'New Clinic',
          nameAr: 'عيادة جديدة',
          email,
          phone,
          password: 'Password123!',
          wilayaId,
          baladyaId,
          facilityType: 'CLINIC',
          descriptionFr: 'Test clinic description',
          latitude: 36.7538,
          longitude: 3.0588,
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.email).toBe(email);
      expect(response.body.data.isVerified).toBe(true);
      expect(response.body.data.facilityType).toBe('CLINIC');

      if (response.body.data.id) {
        cleanupIds.clinics.push(response.body.data.id);
      }
    });

    it('should reject without required fields', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          nameFr: 'Incomplete Clinic',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });

    it('should reject with duplicate email', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          nameFr: 'Duplicate Clinic',
          nameAr: 'عيادة مكررة',
          email: testClinicEmail,
          phone: generatePhone(),
          password: 'Password123!',
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Email already in use');
    });

    it('should reject with duplicate phone', async () => {
        // ✅ Generate a fresh valid phone number
        const phone = generatePhone();

        // First create a clinic with this phone
        const firstResponse = await request(app)
        .post('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
            nameFr: 'First Clinic',
            nameAr: 'عيادة أولى',
            email: `first-${crypto.randomUUID()}@example.com`,
            phone: phone,
            password: 'Password123!',
            wilayaId,
            baladyaId,
        });

        expect(firstResponse.status).toBe(201);
        if (firstResponse.body.data.id) {
        cleanupIds.clinics.push(firstResponse.body.data.id);
        }

        // Try to create another clinic with the same phone
        const response = await request(app)
        .post('/api/v1/clinic/v1')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
            nameFr: 'Duplicate Phone Clinic',
            nameAr: 'عيادة هاتف مكرر',
            email: `duplicate-${crypto.randomUUID()}@example.com`,
            phone: phone,
            password: 'Password123!',
            wilayaId,
            baladyaId,
        });

        expect(response.status).toBe(409);
        expect(response.body.message).toContain('Phone already in use');
    });

  });

  // ============================================================
  // Tests - Staff: Get Clinic by ID
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id', () => {
    it('should get clinic by ID', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(testClinicId);
      expect(response.body.data.email).toBe(testClinicEmail);
    });

    it('should return 404 for non-existent clinic', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Staff: Update Clinic
  // ============================================================

  describe('PATCH /api/v1/clinic/v1/:id', () => {
    it('should update clinic basic info', async () => {
      const response = await request(app)
        .patch(`/api/v1/clinic/v1/${testClinicId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          nameFr: 'Updated Clinic Name',
          descriptionFr: 'Updated description',
          facilityType: 'CLINIC',
        });

      expect(response.status).toBe(200);
      expect(response.body.data.nameFr).toBe('Updated Clinic Name');
      expect(response.body.data.descriptionFr).toBe('Updated description');
      expect(response.body.data.facilityType).toBe('CLINIC');
    });

    it('should update location', async () => {
      const response = await request(app)
        .patch(`/api/v1/clinic/v1/${testClinicId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          latitude: 36.7538,
          longitude: 3.0588,
        });

      expect(response.status).toBe(200);
      expect(response.body.data.latitude).toBe(36.7538);
      expect(response.body.data.longitude).toBe(3.0588);
    });
  });

  // ============================================================
  // Tests - Staff: Verify Clinic
  // ============================================================

  describe('POST /api/v1/clinic/v1/:id/verify', () => {
    it('should verify a clinic', async () => {
      // Create an unverified clinic
      const unverifiedClinic = await prisma.clinic.create({
        data: {
          nameFr: 'Unverified Clinic',
          nameAr: 'عيادة غير موثقة',
          email: `unverified-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          phone: generatePhone(),
          isVerified: false,
          isSuspended: false,
          isCompleted: false,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          facilityType: 'CLINIC',
        },
      });
      cleanupIds.clinics.push(unverifiedClinic.id);

      const response = await request(app)
        .post(`/api/v1/clinic/v1/${unverifiedClinic.id}/verify`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isVerified).toBe(true);
    });

    it('should return 400 if already verified', async () => {
      const response = await request(app)
        .post(`/api/v1/clinic/v1/${testClinicId}/verify`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('already verified');
    });
  });

  // ============================================================
  // Tests - Staff: Suspend/Unsuspend Clinic
  // ============================================================

  describe('POST /api/v1/clinic/v1/:id/suspend', () => {
    it('should suspend a clinic', async () => {
      const response = await request(app)
        .post(`/api/v1/clinic/v1/${testClinicId}/suspend`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ reason: 'Violation of terms' });

      expect(response.status).toBe(200);
      expect(response.body.data.isSuspended).toBe(true);
    });
  });

  describe('POST /api/v1/clinic/v1/:id/unsuspend', () => {
    it('should unsuspend a clinic', async () => {
      const response = await request(app)
        .post(`/api/v1/clinic/v1/${testClinicId}/unsuspend`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isSuspended).toBe(false);
    });
  });

  // ============================================================
  // Tests - Staff: Upload Logo
  // ============================================================

  describe('POST /api/v1/clinic/v1/:id/logo', () => {
    it('should upload a logo', async () => {
      const response = await request(app)
        .post(`/api/v1/clinic/v1/${testClinicId}/logo`)
        .set('Authorization', `Bearer ${adminToken}`)
        .attach('logo', Buffer.from('fake image data'), 'logo.jpg');

      expect(response.status).toBe(200);
      expect(response.body.data.logoPath).toBeDefined();
      expect(response.body.data.logoUrl).toBeDefined();
    });

    it('should return 400 without file', async () => {
      const response = await request(app)
        .post(`/api/v1/clinic/v1/${testClinicId}/logo`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Logo file is required');
    });
  });

  // ============================================================
  // Tests - Self-Service: Get My Profile
  // ============================================================

  describe('GET /api/v1/clinic/v1/me/profile', () => {
    it('should get clinic own profile', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/profile')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(testClinicId);
      expect(response.body.data.email).toBe(testClinicEmail);
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/profile');

      expect(response.status).toBe(401);
    });

    it('should return 403 for non-clinic user', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/profile')
        .set('Authorization', `Bearer ${regularUserToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Self-Service: Complete Profile
  // ============================================================

  describe('PATCH /api/v1/clinic/v1/me/complete', () => {
    it('should complete profile without logo', async () => {
      // Create an incomplete clinic
      const incompleteClinic = await prisma.clinic.create({
        data: {
          nameFr: 'Incomplete Clinic',
          nameAr: 'عيادة غير مكتملة',
          email: `incomplete-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isCompleted: false,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          facilityType: 'CLINIC',
        },
      });
      cleanupIds.clinics.push(incompleteClinic.id);

      const incompleteToken = jwt.sign(
        {
          id: incompleteClinic.id,
          email: incompleteClinic.email,
          role: 'CLINIC',
          name: incompleteClinic.nameFr,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const response = await request(app)
        .patch('/api/v1/clinic/v1/me/complete')
        .set('Authorization', `Bearer ${incompleteToken}`)
        .send({
          descriptionFr: 'Completed description',
          latitude: 36.7538,
          longitude: 3.0588,
        });

      expect(response.status).toBe(200);
      expect(response.body.data.isCompleted).toBe(true);
      expect(response.body.data.descriptionFr).toBe('Completed description');
    });

    it('should complete profile with logo upload', async () => {
      const incompleteClinic = await prisma.clinic.create({
        data: {
          nameFr: 'Incomplete Clinic With Logo',
          nameAr: 'عيادة غير مكتملة مع شعار',
          email: `incomplete-logo-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isCompleted: false,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          facilityType: 'CLINIC',
        },
      });
      cleanupIds.clinics.push(incompleteClinic.id);

      const incompleteToken = jwt.sign(
        {
          id: incompleteClinic.id,
          email: incompleteClinic.email,
          role: 'CLINIC',
          name: incompleteClinic.nameFr,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const response = await request(app)
        .patch('/api/v1/clinic/v1/me/complete')
        .set('Authorization', `Bearer ${incompleteToken}`)
        .attach('logo', Buffer.from('fake image data'), 'logo.jpg')
        .field('descriptionFr', 'Completed with logo');

      expect(response.status).toBe(200);
      expect(response.body.data.isCompleted).toBe(true);
      expect(response.body.data.logoPath).toBeDefined();
      expect(response.body.data.logoUrl).toBeDefined();
    });

    it('should return 400 if clinic not verified', async () => {
      const unverifiedClinic = await prisma.clinic.create({
        data: {
          nameFr: 'Unverified Complete',
          nameAr: 'غير موثق إكمال',
          email: `unverified-complete-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          phone: generatePhone(),
          isVerified: false,
          isSuspended: false,
          isCompleted: false,
          wilaya: { connect: { id: wilayaId } },
          baladya: { connect: { id: baladyaId } },
          facilityType: 'CLINIC',
        },
      });
      cleanupIds.clinics.push(unverifiedClinic.id);

      const unverifiedToken = jwt.sign(
        {
          id: unverifiedClinic.id,
          email: unverifiedClinic.email,
          role: 'CLINIC',
          name: unverifiedClinic.nameFr,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const response = await request(app)
        .patch('/api/v1/clinic/v1/me/complete')
        .set('Authorization', `Bearer ${unverifiedToken}`)
        .send({ descriptionFr: 'Test' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('must be verified');
    });
  });

  // ============================================================
  // Tests - Self-Service: Documents
  // ============================================================

  describe('POST /api/v1/clinic/v1/me/documents', () => {
    it('should upload a document', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/documents')
        .set('Authorization', `Bearer ${clinicToken}`)
        .attach('document', Buffer.from('fake pdf data'), 'document.pdf');

      expect(response.status).toBe(201);
      expect(response.body.data.fileName).toBe('document.pdf');
      expect(response.body.data.accessUrl).toBeDefined();

      if (response.body.data.id) {
        cleanupIds.documents.push(response.body.data.id);
      }
    });

    it('should return 400 without file', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/documents')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Document file is required');
    });
  });

  describe('GET /api/v1/clinic/v1/me/documents', () => {
    it('should get own documents', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/documents')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Self-Service: Working Hours
  // ============================================================

  describe('POST /api/v1/clinic/v1/me/working-hours', () => {
    it('should set working hours', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/working-hours')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({
          hours: [
            {
              dayOfWeek: 'SUNDAY',
              openTime: '08:00',
              closeTime: '17:00',
              isOpen: true,
            },
            {
              dayOfWeek: 'MONDAY',
              openTime: '08:00',
              closeTime: '17:00',
              isOpen: true,
            },
            {
              dayOfWeek: 'FRIDAY',
              openTime: '08:00',
              closeTime: '12:00',
              isOpen: true,
            },
            {
              dayOfWeek: 'SATURDAY',
              openTime: '00:00',
              closeTime: '00:00',
              isOpen: false,
            },
          ],
        });

      expect(response.status).toBe(200);
      expect(response.body.data).toHaveLength(4);
      // Handle timezone offset (Algeria is UTC+1)
      // The service uses toISOString().slice(11, 16) which returns UTC time
      expect(['08:00', '07:00']).toContain(response.body.data[0].openTime);
      expect(['17:00', '16:00']).toContain(response.body.data[0].closeTime);
      expect(response.body.data[0].isOpen).toBe(true);
    });

    it('should reject without hours', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/working-hours')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({});

      expect(response.status).toBe(422);
    });
  });

  describe('GET /api/v1/clinic/v1/me/working-hours', () => {
    it('should get working hours', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/working-hours')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Self-Service: Rooms
  // ============================================================

  describe('POST /api/v1/clinic/v1/me/rooms', () => {
    it('should create a room', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/rooms')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({
          name: 'Consultation Room 1',
          specialtyId,
        });

      expect(response.status).toBe(201);
      expect(response.body.data.name).toBe('Consultation Room 1');
      expect(response.body.data.specialtyId).toBe(specialtyId);

      if (response.body.data.id) {
        cleanupIds.rooms.push(response.body.data.id);
      }
    });
  });

  describe('GET /api/v1/clinic/v1/me/rooms', () => {
    it('should get rooms', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/rooms')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Self-Service: Invite Doctor
  // ============================================================

  describe('POST /api/v1/clinic/v1/me/doctors/invite', () => {
    it('should invite a doctor', async () => {
      // Create a doctor
      const doctor = await prisma.doctor.create({
        data: {
          email: `doctor-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstNameFr: 'Test',
          firstNameAr: 'اختبار',
          lastNameFr: 'Doctor',
          lastNameAr: 'طبيب',
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isRegistered: true,
          isCompleted: true,
          wilaya: { connect: { id: wilayaId } },
        },
      });

      const response = await request(app)
        .post('/api/v1/clinic/v1/me/doctors/invite')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({ doctorId: doctor.id });

      expect(response.status).toBe(201);
      expect(response.body.data.status).toBe('PENDING');
      expect(response.body.data.invitedBy).toBe('clinic');
    });

    it('should return 404 when doctor not found', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/doctors/invite')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({ doctorId: '00000000-0000-0000-0000-000000000000' });

      expect(response.status).toBe(404);
    });
  });

  describe('GET /api/v1/clinic/v1/me/doctors', () => {
    it('should get clinic doctors', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/doctors')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Self-Service: Gallery
  // ============================================================

  describe('POST /api/v1/clinic/v1/me/gallery', () => {
    it('should upload a gallery image', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/gallery')
        .set('Authorization', `Bearer ${clinicToken}`)
        .attach('image', Buffer.from('fake image data'), 'gallery.jpg')
        .field('captionFr', 'Modern waiting room')
        .field('captionAr', 'غرفة انتظار حديثة');

      expect(response.status).toBe(201);
      expect(response.body.data.imageUrl).toBeDefined();
      expect(response.body.data.captionFr).toBe('Modern waiting room');

      if (response.body.data.id) {
        cleanupIds.gallery.push(response.body.data.id);
      }
    });

    it('should return 400 without image', async () => {
      const response = await request(app)
        .post('/api/v1/clinic/v1/me/gallery')
        .set('Authorization', `Bearer ${clinicToken}`)
        .send({ captionFr: 'Test' });

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('Image is required');
    });
  });

  describe('GET /api/v1/clinic/v1/me/gallery', () => {
    it('should get gallery images', async () => {
      const response = await request(app)
        .get('/api/v1/clinic/v1/me/gallery')
        .set('Authorization', `Bearer ${clinicToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Get Clinic Doctors
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id/doctors', () => {
    it('should get clinic doctors (staff)', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}/doctors`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Get Clinic Documents
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id/documents', () => {
    it('should get clinic documents (staff)', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}/documents`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Get Clinic Rooms
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id/rooms', () => {
    it('should get clinic rooms (staff)', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}/rooms`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Get Clinic Gallery
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id/gallery', () => {
    it('should get clinic gallery (staff)', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}/gallery`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Get Clinic Working Hours
  // ============================================================

  describe('GET /api/v1/clinic/v1/:id/working-hours', () => {
    it('should get clinic working hours (staff)', async () => {
      const response = await request(app)
        .get(`/api/v1/clinic/v1/${testClinicId}/working-hours`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });
});

