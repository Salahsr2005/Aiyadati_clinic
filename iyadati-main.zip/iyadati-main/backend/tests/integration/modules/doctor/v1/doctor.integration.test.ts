// backend/tests/integration/modules/doctor/v1/doctor.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { PrismaClient } from '@prisma/client';

let app: any;
let prisma: PrismaClient;
let pgContainer: StartedPostgreSqlContainer;

// Test data
let wilayaId: string;
let baladyaId: string;
let specialtyId: string;
let specialtyId2: string;
let clinicId: string;

// Users and tokens
let adminToken: string;
let adminUser: any;
let doctorToken: string;
let doctorUser: any;
let regularUserToken: string;
let regularUser: any;

// Doctor created for tests
let testDoctorId: string;

const JWT_SECRET = process.env.JWT_SECRET || 'iyadati-secret-key-change-in-production';

// Cleanup tracking
const cleanupIds = {
  doctors: [] as string[],
  users: [] as string[],
  specialties: [] as string[],
  documents: [] as string[],
  availability: [] as string[],
  breaks: [] as string[],
};

describe('Doctor Module - Integration Tests', () => {
  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(`✅ Postgres container started`);

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    await prisma.$connect();

    const appModule = await import('../../../../../src/app');
    app = appModule.default;

    // ============================================================
    // Create test data
    // ============================================================

    // 1. Create Wilaya
    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    // 2. Create Baladya
    const baladya = await prisma.baladya.create({
      data: {
        nameFr: `Test Baladya ${crypto.randomUUID()}`,
        nameAr: `بلدية اختبار ${crypto.randomUUID()}`,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    baladyaId = baladya.id;

    // 3. Create Specialties
    const specialty = await prisma.specialty.create({
      data: {
        nameFr: `Cardiology ${crypto.randomUUID()}`,
        nameAr: `أمراض القلب ${crypto.randomUUID()}`,
        isActive: true,
      },
    });
    specialtyId = specialty.id;
    cleanupIds.specialties.push(specialty.id);

    const specialty2 = await prisma.specialty.create({
      data: {
        nameFr: `Dermatology ${crypto.randomUUID()}`,
        nameAr: `الأمراض الجلدية ${crypto.randomUUID()}`,
        isActive: true,
      },
    });
    specialtyId2 = specialty2.id;
    cleanupIds.specialties.push(specialty2.id);

    // 4. Create Clinic
    const clinic = await prisma.clinic.create({
      data: {
        nameFr: `Test Clinic ${crypto.randomUUID()}`,
        nameAr: `عيادة اختبار ${crypto.randomUUID()}`,
        email: `clinic-${crypto.randomUUID()}@example.com`,
        password: await bcrypt.hash('Password123!', 12),
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
        baladya: { connect: { id: baladyaId } },
      },
    });
    clinicId = clinic.id;

    // 5. Create Admin User
    const adminPassword = await bcrypt.hash('Admin123!', 12);
    adminUser = await prisma.admin.create({
      data: {
        email: `admin-${crypto.randomUUID()}@example.com`,
        password: adminPassword,
        name: 'Test Admin',
      },
    });
    cleanupIds.users.push(adminUser.id);

    adminToken = jwt.sign(
      { id: adminUser.id, email: adminUser.email, role: 'ADMIN', name: 'Test Admin' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 6. Create Regular User
    const userPassword = await bcrypt.hash('User123!', 12);
    regularUser = await prisma.user.create({
      data: {
        email: `user-${crypto.randomUUID()}@example.com`,
        password: userPassword,
        firstName: 'Test',
        lastName: 'User',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    cleanupIds.users.push(regularUser.id);

    regularUserToken = jwt.sign(
      { id: regularUser.id, email: regularUser.email, role: 'USER', name: 'Test User' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 7. Create Doctor User
    const doctorPassword = await bcrypt.hash('Doctor123!', 12);
    doctorUser = await prisma.doctor.create({
      data: {
        email: `doctor-${crypto.randomUUID()}@example.com`,
        password: doctorPassword,
        firstNameFr: 'Test',
        firstNameAr: 'اختبار',
        lastNameFr: 'Doctor',
        lastNameAr: 'طبيب',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        isVerified: true,
        isSuspended: false,
        isRegistered: true,
        isCompleted: true,
        isAvailableForBooking: true,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    cleanupIds.doctors.push(doctorUser.id);

    doctorToken = jwt.sign(
      {
        id: doctorUser.id,
        email: doctorUser.email,
        role: 'DOCTOR',
        name: `${doctorUser.firstNameFr} ${doctorUser.lastNameFr}`,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // 8. Create a test doctor for staff operations
    const testDoctor = await prisma.doctor.create({
      data: {
        email: `test-doctor-${crypto.randomUUID()}@example.com`,
        password: await bcrypt.hash('Password123!', 12),
        firstNameFr: 'Staff',
        firstNameAr: 'موظف',
        lastNameFr: 'Test',
        lastNameAr: 'اختبار',
        phone: `05${Math.floor(100000000 + Math.random() * 899999999)}`,
        isVerified: false,
        isSuspended: false,
        isRegistered: true,
        isCompleted: false,
        isAvailableForBooking: false,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    testDoctorId = testDoctor.id;
    cleanupIds.doctors.push(testDoctor.id);

    // Assign specialties to test doctor
    await prisma.doctorSpecialty.create({
      data: {
        doctorId: testDoctor.id,
        specialtyId: specialtyId,
      },
    });

    console.log('✅ Test data created successfully');
  }, 180000);

  afterEach(async () => {
    if (cleanupIds.documents.length > 0) {
      await prisma.doctorDocument.deleteMany({
        where: { id: { in: cleanupIds.documents } },
      });
      cleanupIds.documents = [];
    }
    if (cleanupIds.availability.length > 0) {
      await prisma.doctorAvailability.deleteMany({
        where: { id: { in: cleanupIds.availability } },
      });
      cleanupIds.availability = [];
    }
    if (cleanupIds.breaks.length > 0) {
      await prisma.doctorBreak.deleteMany({
        where: { id: { in: cleanupIds.breaks } },
      });
      cleanupIds.breaks = [];
    }
  });

  // ============================================================
  // ✅ CLEANUP - TOP LEVEL with safety net
  // ============================================================
  afterAll(async () => {
    // 1. Delete ALL doctor_specialties that reference our specialties
    if (cleanupIds.specialties.length > 0) {
      await prisma.doctorSpecialty.deleteMany({
        where: {
          specialtyId: { in: cleanupIds.specialties },
        },
      });
    }

    // 2. Delete doctors
    if (cleanupIds.doctors.length > 0) {
      await prisma.doctor.deleteMany({
        where: { id: { in: cleanupIds.doctors } },
      });
    }

    // 3. Delete users
    if (cleanupIds.users.length > 0) {
      await prisma.admin.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
      await prisma.user.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
    }

    // 4. Delete specialties (now safe because all references are gone)
    if (cleanupIds.specialties.length > 0) {
      await prisma.specialty.deleteMany({
        where: { id: { in: cleanupIds.specialties } },
      });
    }

    // 5. Safety net: delete any remaining doctors/users that reference wilayaId
    // (catches any rows that weren't tracked in cleanupIds)
    await prisma.doctor.deleteMany({ where: { wilayaId } });
    await prisma.user.deleteMany({ where: { wilayaId } });

    // 6. Delete clinic, baladya, wilaya
    await prisma.clinic.deleteMany({ where: { id: clinicId } });
    await prisma.baladya.deleteMany({ where: { id: baladyaId } });
    await prisma.wilaya.deleteMany({ where: { id: wilayaId } });

    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  const generatePhone = (): string => {
    const prefixes = ['05', '06', '07'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const rest = Math.floor(10000000 + Math.random() * 89999999).toString();
    return prefix + rest;
  };

  // ============================================================
  // Tests - Staff: Get All Doctors
  // ============================================================

  describe('GET /api/v1/doctor/v1', () => {
    it('should return paginated doctors with default params', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeDefined();
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.meta).toBeDefined();
    });

    it('should filter by isVerified', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1')
        .query({ isVerified: 'true' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      response.body.data.forEach((doctor: any) => {
        expect(doctor.isVerified).toBe(true);
      });
    });

    it('should filter by isAvailableForBooking', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1')
        .query({ isAvailableForBooking: 'true' })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      response.body.data.forEach((doctor: any) => {
        expect(doctor.isAvailableForBooking).toBe(true);
      });
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1');

      expect(response.status).toBe(401);
    });

    it('should return 403 for non-admin user', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1')
        .set('Authorization', `Bearer ${regularUserToken}`);

      expect(response.status).toBe(403);
    });
  });

  // ============================================================
  // Tests - Staff: Create Complete Doctor
  // ============================================================

  describe('POST /api/v1/doctor/v1/create-complete', () => {
    it('should create a complete doctor without logo', async () => {
      const email = `complete-${crypto.randomUUID()}@example.com`;
      const phone = generatePhone();

      const response = await request(app)
        .post('/api/v1/doctor/v1/create-complete')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('email', email)
        .field('password', 'Password123!')
        .field('firstNameFr', 'Complete')
        .field('firstNameAr', 'كامل')
        .field('lastNameFr', 'Test')
        .field('lastNameAr', 'اختبار')
        .field('phone', phone)
        .field('wilayaId', wilayaId)
        .field('specialtyIds', JSON.stringify([specialtyId, specialtyId2]))
        .field('bioFr', 'Test bio')
        .field('yearsOfExp', '15')
        .field('practiceType', 'BOTH');

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.email).toBe(email);
      expect(response.body.data.isVerified).toBe(true);
      expect(response.body.data.isCompleted).toBe(true);
      expect(response.body.data.specialties).toHaveLength(2);

      if (response.body.data.id) {
        cleanupIds.doctors.push(response.body.data.id);
      }
    });

    it('should create a complete doctor with logo upload', async () => {
      const email = `complete-logo-${crypto.randomUUID()}@example.com`;
      const phone = generatePhone();

      const response = await request(app)
        .post('/api/v1/doctor/v1/create-complete')
        .set('Authorization', `Bearer ${adminToken}`)
        .attach('logo', Buffer.from('fake image data'), 'photo.jpg')
        .field('email', email)
        .field('password', 'Password123!')
        .field('firstNameFr', 'Complete Logo')
        .field('firstNameAr', 'كامل مع شعار')
        .field('lastNameFr', 'Test')
        .field('lastNameAr', 'اختبار')
        .field('phone', phone)
        .field('wilayaId', wilayaId)
        .field('specialtyIds', JSON.stringify([specialtyId]));

      expect(response.status).toBe(201);
      expect(response.body.data.email).toBe(email);
      expect(response.body.data.isCompleted).toBe(true);
      expect(response.body.data.photoFileId).toBeDefined();

      if (response.body.data.id) {
        cleanupIds.doctors.push(response.body.data.id);
      }
    });

    it('should reject without specialties', async () => {
      const email = `no-specialty-${crypto.randomUUID()}@example.com`;
      const phone = generatePhone();

      const response = await request(app)
        .post('/api/v1/doctor/v1/create-complete')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('email', email)
        .field('password', 'Password123!')
        .field('firstNameFr', 'No Specialty')
        .field('firstNameAr', 'لا تخصص')
        .field('lastNameFr', 'Test')
        .field('lastNameAr', 'اختبار')
        .field('phone', phone)
        .field('wilayaId', wilayaId);

      expect(response.status).toBe(422);
    });

    it('should reject with duplicate email', async () => {
      const email = `duplicate-${crypto.randomUUID()}@example.com`;
      const phone = generatePhone();

      // ✅ FIX: Capture the first response and add the doctor to cleanup
      const firstResponse = await request(app)
        .post('/api/v1/doctor/v1/create-complete')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('email', email)
        .field('password', 'Password123!')
        .field('firstNameFr', 'First')
        .field('firstNameAr', 'أول')
        .field('lastNameFr', 'Test')
        .field('lastNameAr', 'اختبار')
        .field('phone', phone)
        .field('wilayaId', wilayaId)
        .field('specialtyIds', JSON.stringify([specialtyId]));

      // ✅ Add the created doctor to cleanup
      if (firstResponse.body?.data?.id) {
        cleanupIds.doctors.push(firstResponse.body.data.id);
      }

      const response = await request(app)
        .post('/api/v1/doctor/v1/create-complete')
        .set('Authorization', `Bearer ${adminToken}`)
        .field('email', email)
        .field('password', 'Password123!')
        .field('firstNameFr', 'Second')
        .field('firstNameAr', 'ثاني')
        .field('lastNameFr', 'Test')
        .field('lastNameAr', 'اختبار')
        .field('phone', generatePhone())
        .field('wilayaId', wilayaId)
        .field('specialtyIds', JSON.stringify([specialtyId]));

      expect(response.status).toBe(409);
    });
  });

  // ============================================================
  // Tests - Staff: Get Doctor by ID
  // ============================================================

  describe('GET /api/v1/doctor/v1/:id', () => {
    it('should get doctor by ID', async () => {
      const response = await request(app)
        .get(`/api/v1/doctor/v1/${testDoctorId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(testDoctorId);
    });

    it('should return 404 for non-existent doctor', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1/00000000-0000-0000-0000-000000000000')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(404);
    });
  });

  // ============================================================
  // Tests - Staff: Update Doctor
  // ============================================================

  describe('PATCH /api/v1/doctor/v1/:id', () => {
    it('should update doctor basic info', async () => {
      const response = await request(app)
        .patch(`/api/v1/doctor/v1/${testDoctorId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          firstNameFr: 'Updated Staff',
          bioFr: 'Updated bio',
          yearsOfExp: 20,
        });

      expect(response.status).toBe(200);
      expect(response.body.data.firstNameFr).toBe('Updated Staff');
      expect(response.body.data.bioFr).toBe('Updated bio');
      expect(response.body.data.yearsOfExp).toBe(20);
    });

    it('should update specialties', async () => {
      const response = await request(app)
        .patch(`/api/v1/doctor/v1/${testDoctorId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          specialtyIds: [specialtyId2],
        });

      expect(response.status).toBe(200);
      expect(response.body.data.specialties).toHaveLength(1);
      expect(response.body.data.specialties[0].id).toBe(specialtyId2);
    });
  });

  // ============================================================
  // Tests - Staff: Verify Doctor
  // ============================================================

  describe('POST /api/v1/doctor/v1/:id/verify', () => {
    it('should verify a doctor', async () => {
      const unverifiedDoctor = await prisma.doctor.create({
        data: {
          email: `unverified-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstNameFr: 'Unverified',
          firstNameAr: 'غير موثق',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: generatePhone(),
          isVerified: false,
          isSuspended: false,
          isRegistered: true,
          isCompleted: false,
          isAvailableForBooking: false,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.doctors.push(unverifiedDoctor.id);

      const response = await request(app)
        .post(`/api/v1/doctor/v1/${unverifiedDoctor.id}/verify`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isVerified).toBe(true);
    });
  });

  // ============================================================
  // Tests - Staff: Suspend/Unsuspend Doctor
  // ============================================================

  describe('POST /api/v1/doctor/v1/:id/suspend', () => {
    it('should suspend a doctor', async () => {
      const response = await request(app)
        .post(`/api/v1/doctor/v1/${testDoctorId}/suspend`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isSuspended).toBe(true);
    });
  });

  describe('POST /api/v1/doctor/v1/:id/unsuspend', () => {
    it('should unsuspend a doctor', async () => {
      const response = await request(app)
        .post(`/api/v1/doctor/v1/${testDoctorId}/unsuspend`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isSuspended).toBe(false);
    });
  });

  // ============================================================
  // Tests - Staff: Update Booking Availability
  // ============================================================

  describe('PATCH /api/v1/doctor/v1/:id/booking-availability', () => {
    it('should enable booking availability with message', async () => {
      const response = await request(app)
        .patch(`/api/v1/doctor/v1/${testDoctorId}/booking-availability`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          isAvailableForBooking: true,
          messageForUser: 'Available from September 2026',
        });

      expect(response.status).toBe(200);
      expect(response.body.data.isAvailableForBooking).toBe(true);
      expect(response.body.data.messageForUser).toBe('Available from September 2026');
    });

    it('should disable booking availability', async () => {
      const response = await request(app)
        .patch(`/api/v1/doctor/v1/${testDoctorId}/booking-availability`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          isAvailableForBooking: false,
        });

      expect(response.status).toBe(200);
      expect(response.body.data.isAvailableForBooking).toBe(false);
      expect(response.body.data.messageForUser).toBeNull();
    });
  });

  // ============================================================
  // Tests - Self-Service: Get My Profile
  // ============================================================

  describe('GET /api/v1/doctor/v1/me/profile', () => {
    it('should get doctor own profile', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1/me/profile')
        .set('Authorization', `Bearer ${doctorToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe(doctorUser.id);
    });

    it('should return 401 without token', async () => {
      const response = await request(app)
        .get('/api/v1/doctor/v1/me/profile');

      expect(response.status).toBe(401);
    });
  });

  // ============================================================
  // Tests - Self-Service: Complete My Profile
  // ============================================================

  describe('PATCH /api/v1/doctor/v1/me/complete', () => {
    it('should complete profile without photo', async () => {
      const incompleteDoctor = await prisma.doctor.create({
        data: {
          email: `incomplete-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstNameFr: 'Incomplete',
          firstNameAr: 'غير مكتمل',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isRegistered: true,
          isCompleted: false,
          isAvailableForBooking: false,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.doctors.push(incompleteDoctor.id);

      const incompleteToken = jwt.sign(
        {
          id: incompleteDoctor.id,
          email: incompleteDoctor.email,
          role: 'DOCTOR',
          name: `${incompleteDoctor.firstNameFr} ${incompleteDoctor.lastNameFr}`,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const response = await request(app)
        .patch('/api/v1/doctor/v1/me/complete')
        .set('Authorization', `Bearer ${incompleteToken}`)
        .send({
          bioFr: 'Completed bio',
          specialtyIds: [specialtyId],
          yearsOfExp: 10,
          practiceType: 'INDEPENDENT',
        });

      expect(response.status).toBe(200);
      expect(response.body.data.isCompleted).toBe(true);
    });

    it('should complete profile with photo upload', async () => {
      const incompleteDoctor = await prisma.doctor.create({
        data: {
          email: `incomplete-photo-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.hash('Password123!', 12),
          firstNameFr: 'Incomplete Photo',
          firstNameAr: 'غير مكتمل مع صورة',
          lastNameFr: 'Test',
          lastNameAr: 'اختبار',
          phone: generatePhone(),
          isVerified: true,
          isSuspended: false,
          isRegistered: true,
          isCompleted: false,
          isAvailableForBooking: false,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.doctors.push(incompleteDoctor.id);

      const incompleteToken = jwt.sign(
        {
          id: incompleteDoctor.id,
          email: incompleteDoctor.email,
          role: 'DOCTOR',
          name: `${incompleteDoctor.firstNameFr} ${incompleteDoctor.lastNameFr}`,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const response = await request(app)
        .patch('/api/v1/doctor/v1/me/complete')
        .set('Authorization', `Bearer ${incompleteToken}`)
        .attach('logo', Buffer.from('fake image data'), 'profile.jpg')
        .field('bioFr', 'Completed with photo')
        .field('specialtyIds', specialtyId);

      expect(response.status).toBe(200);
      expect(response.body.data.isCompleted).toBe(true);
      expect(response.body.data.photoFileId).toBeDefined();
    });
  });

  // ============================================================
  // Tests - Self-Service: Documents
  // ============================================================

  describe('POST /api/v1/doctor/v1/me/documents', () => {
    it('should upload a document', async () => {
      const response = await request(app)
        .post('/api/v1/doctor/v1/me/documents')
        .set('Authorization', `Bearer ${doctorToken}`)
        .attach('document', Buffer.from('fake pdf data'), 'degree.pdf')
        .field('docType', 'degree');

      expect(response.status).toBe(201);
      expect(response.body.data.fileName).toBe('degree.pdf');
      expect(response.body.data.docType).toBe('degree');

      if (response.body.data.id) {
        cleanupIds.documents.push(response.body.data.id);
      }
    });

    it('should return 400 without file', async () => {
      const response = await request(app)
        .post('/api/v1/doctor/v1/me/documents')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ docType: 'degree' });

      expect(response.status).toBe(400);
    });
  });

  // ============================================================
  // Tests - Self-Service: Availability
  // ============================================================

  describe('PUT /api/v1/doctor/v1/me/availability', () => {
    it('should set availability slots', async () => {
      const response = await request(app)
        .put('/api/v1/doctor/v1/me/availability')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          slots: [
            { dayOfWeek: 'MONDAY', startTime: '09:00', endTime: '12:00' },
            { dayOfWeek: 'MONDAY', startTime: '13:00', endTime: '17:00' },
          ],
        });

      expect(response.status).toBe(200);
      expect(response.body.data).toHaveLength(2);

      if (response.body.data.length > 0) {
        response.body.data.forEach((slot: any) => {
          cleanupIds.availability.push(slot.id);
        });
      }
    });
  });

  // ============================================================
  // Tests - Self-Service: Breaks
  // ============================================================

  describe('POST /api/v1/doctor/v1/me/breaks', () => {
    it('should create an all-day break', async () => {
      const response = await request(app)
        .post('/api/v1/doctor/v1/me/breaks')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({
          startDate: '2026-07-01',
          endDate: '2026-07-15',
          reason: 'Summer vacation',
          isAllDay: true,
        });

      expect(response.status).toBe(201);
      expect(response.body.data.isAllDay).toBe(true);

      if (response.body.data.id) {
        cleanupIds.breaks.push(response.body.data.id);
      }
    });
  });

  // ============================================================
  // Tests - Self-Service: Clinic Requests
  // ============================================================

  describe('POST /api/v1/doctor/v1/me/clinics/request', () => {
    it('should request to join a clinic', async () => {
      const response = await request(app)
        .post('/api/v1/doctor/v1/me/clinics/request')
        .set('Authorization', `Bearer ${doctorToken}`)
        .send({ clinicId });

      expect(response.status).toBe(201);
      expect(response.body.data.status).toBe('PENDING');
    });
  });
});

