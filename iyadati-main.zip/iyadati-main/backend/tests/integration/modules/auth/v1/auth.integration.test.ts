// backend/tests/integration/modules/auth/v1/auth.integration.test.ts

import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import request from 'supertest';
import type { PrismaClient } from '@prisma/client';

describe('Auth Module - Integration Tests', () => {
  let pgContainer: StartedPostgreSqlContainer;
  let prisma: PrismaClient;
  let app: any;
  let wilayaId: string;
  let baladyaId: string;
  const cleanupIds: { users: string[]; clinics: string[]; doctors: string[] } = {
    users: [],
    clinics: [],
    doctors: [],
  };

  beforeAll(async () => {
    console.log('🚀 Starting Postgres container...');

    pgContainer = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = pgContainer.getConnectionUri();

    process.env.DATABASE_URL = databaseUrl;
    process.env.DATABASE_URL_PGBOUNCER = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;
    process.env.USE_PGBOUNCER = 'false';

    console.log(
      `✅ Postgres container started on ${pgContainer.getHost()}:${pgContainer.getMappedPort(5432)}`,
    );

    console.log('🔄 Running migrations...');
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });
    console.log('✅ Migrations completed');

    const { PrismaClient: PrismaClientCtor } = await import('@prisma/client');
    prisma = new PrismaClientCtor();
    await prisma.$connect();

    const appModule = await import('../../../../../src/app');
    app = appModule.default;

    const wilaya = await prisma.wilaya.create({
      data: {
        code: Math.floor(100000 + Math.random() * 899999),
        nameFr: `Test Wilaya ${crypto.randomUUID()}`,
        nameAr: `ولاية اختبار ${crypto.randomUUID()}`,
      },
    });
    wilayaId = wilaya.id;

    const baladya = await prisma.baladya.create({
      data: {
        nameFr: `Test Baladya ${crypto.randomUUID()}`,
        nameAr: `بلدية اختبار ${crypto.randomUUID()}`,
        wilaya: { connect: { id: wilayaId } },
      },
    });
    baladyaId = baladya.id;
  }, 180000);

  afterEach(async () => {
    if (cleanupIds.doctors.length > 0) {
      await prisma.doctorSpecialty.deleteMany({
        where: { doctorId: { in: cleanupIds.doctors } },
      });
      await prisma.doctor.deleteMany({
        where: { id: { in: cleanupIds.doctors } },
      });
      cleanupIds.doctors = [];
    }
    if (cleanupIds.clinics.length > 0) {
      await prisma.clinic.deleteMany({
        where: { id: { in: cleanupIds.clinics } },
      });
      cleanupIds.clinics = [];
    }
    if (cleanupIds.users.length > 0) {
      await prisma.creditTransaction.deleteMany({
        where: { wallet: { userId: { in: cleanupIds.users } } },
      });
      await prisma.userWallet.deleteMany({
        where: { userId: { in: cleanupIds.users } },
      });
      await prisma.user.deleteMany({
        where: { id: { in: cleanupIds.users } },
      });
      cleanupIds.users = [];
    }
  });

  afterAll(async () => {
    await prisma.$disconnect();

    if (pgContainer) {
      console.log('🛑 Stopping Postgres container...');
      await pgContainer.stop();
      console.log('✅ Container stopped');
    }
    console.log('✅ Cleanup complete!');
  }, 60000);

  // ============================================================
  // Helper functions
  // ============================================================

  // Generate a valid 10-digit phone number
  const generatePhone = (): string => {
    // Start with 05, 06, or 07, then 8 random digits
    const prefixes = ['05', '06', '07'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const rest = Math.floor(10000000 + Math.random() * 89999999).toString();
    return prefix + rest;
  };

  const createTestUser = async (overrides: any = {}) => {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const user = await prisma.user.create({
      data: {
        email: `user-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        firstName: 'Test',
        lastName: 'User',
        phone: generatePhone(),
        dateOfBirth: new Date('1990-01-01'),
        isVerified: true,
        isSuspended: false,
        wilaya: { connect: { id: wilayaId } },
        ...overrides,
      },
    });
    cleanupIds.users.push(user.id);
    return user;
  };

  const createTestClinic = async (overrides: any = {}) => {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const clinic = await prisma.clinic.create({
      data: {
        nameFr: 'Test Clinic',
        nameAr: 'عيادة اختبار',
        email: `clinic-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        phone: generatePhone(),
        isVerified: true,
        isSuspended: false,
        isCompleted: false,
        wilaya: { connect: { id: wilayaId } },
        baladya: { connect: { id: baladyaId } },
        ...overrides,
      },
    });
    cleanupIds.clinics.push(clinic.id);
    return clinic;
  };

  const createTestDoctor = async (overrides: any = {}) => {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.default.hash('Password123!', 12);

    const doctor = await prisma.doctor.create({
      data: {
        email: `doctor-${crypto.randomUUID()}@example.com`,
        password: hashedPassword,
        firstNameFr: 'Test',
        firstNameAr: 'اختبار',
        lastNameFr: 'Doctor',
        lastNameAr: 'طبيب',
        phone: generatePhone(),
        isVerified: true,
        isSuspended: false,
        isRegistered: true,
        isCompleted: false,
        wilaya: { connect: { id: wilayaId } },
        ...overrides,
      },
    });
    cleanupIds.doctors.push(doctor.id);
    return doctor;
  };

  // ============================================================
  // Tests - User Registration
  // ============================================================

  describe('POST /api/v1/auth/v1/register', () => {
    it('should register a new user successfully', async () => {
      const email = `register-${crypto.randomUUID()}@example.com`;
      const response = await request(app)
        .post('/api/v1/auth/v1/register')
        .send({
          email,
          password: 'Password123!',
          firstName: 'John',
          lastName: 'Doe',
          phone: generatePhone(),
          dateOfBirth: '1995-01-01',
          wilayaId,
        });

      expect(response.status).toBe(201);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Registration successful. Please check your email for the verification code.',
      });
      expect(response.body.data).toHaveProperty('message');

      const user = await prisma.user.findUnique({
        where: { email },
      });
      expect(user).not.toBeNull();
      expect(user?.isVerified).toBe(false);
      expect(user?.verificationCode).not.toBeNull();
      expect(user?.otpExpiresAt).not.toBeNull();

      const wallet = await prisma.userWallet.findUnique({
        where: { userId: user?.id },
      });
      expect(wallet).not.toBeNull();
      expect(wallet?.credits).toBe(0);

      if (user) cleanupIds.users.push(user.id);
    });

    it('should reject registration with invalid data', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/register')
        .send({
          email: 'invalid-email',
          password: '123',
          firstName: '',
          lastName: '',
          phone: '123',
          dateOfBirth: 'invalid',
          wilayaId: 'invalid-uuid',
        });

      expect(response.status).toBe(422);
      expect(response.body.success).toBe(false);
      expect(response.body.errors).toBeDefined();
      expect(response.body.errors.length).toBeGreaterThan(0);
    });

    it('should reject registration with duplicate email', async () => {
      const user = await createTestUser();

      const response = await request(app)
        .post('/api/v1/auth/v1/register')
        .send({
          email: user.email,
          password: 'Password123!',
          firstName: 'John',
          lastName: 'Doe',
          phone: generatePhone(),
          dateOfBirth: '1995-01-01',
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Email already registered');
      expect(response.body.errors).toBeDefined();
      expect(response.body.errors[0].field).toBe('email');
    });

    it('should reject registration with duplicate phone', async () => {
      const user = await createTestUser();

      const response = await request(app)
        .post('/api/v1/auth/v1/register')
        .send({
          email: `new-${crypto.randomUUID()}@example.com`,
          password: 'Password123!',
          firstName: 'John',
          lastName: 'Doe',
          phone: user.phone,
          dateOfBirth: '1995-01-01',
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Phone already registered');
      expect(response.body.errors[0].field).toBe('phone');
    });
  });

  // ============================================================
  // Tests - User Login
  // ============================================================

  describe('POST /api/v1/auth/v1/user/login', () => {
    it('should login a verified user successfully', async () => {
      const password = 'Password123!';
      const user = await createTestUser({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password,
        });

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Login successful',
      });
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user).toMatchObject({
        id: user.id,
        email: user.email,
        name: 'Test User',
        role: 'USER',
      });
      expect(response.headers['set-cookie']).toBeDefined();
      expect(response.headers['set-cookie'][0]).toContain('token=');
    });

    it('should reject login for unverified user', async () => {
      const password = 'Password123!';
      const user = await createTestUser({ isVerified: false });

      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password,
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Please verify your email first');
    });

    it('should reject login for suspended user', async () => {
      const password = 'Password123!';
      const user = await createTestUser({ isVerified: true, isSuspended: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password,
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Your account has been suspended');
    });

    it('should reject login with incorrect password', async () => {
      const user = await createTestUser({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password: 'WrongPassword123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid email or password');
    });

    it('should reject login for non-existent user', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: 'nonexistent@example.com',
          password: 'Password123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid email or password');
    });

    it('should reject login with invalid payload', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: 'invalid-email',
          password: '123',
        });

      expect(response.status).toBe(422);
      expect(response.body.errors).toBeDefined();
    });
  });

  // ============================================================
  // Tests - OTP Verification
  // ============================================================

  describe('POST /api/v1/auth/v1/verify-otp', () => {
    it('should verify a valid OTP successfully', async () => {
      const bcrypt = await import('bcryptjs');
      const knownOtp = '123456';
      const hashedOtp = await bcrypt.default.hash(knownOtp, 10);
      const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

      const user = await prisma.user.create({
        data: {
          email: `verify-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.default.hash('Password123!', 12),
          firstName: 'Verify',
          lastName: 'Test',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: false,
          verificationCode: hashedOtp,
          otpExpiresAt,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(user.id);

      const response = await request(app)
        .post('/api/v1/auth/v1/verify-otp')
        .send({
          email: user.email,
          otp: knownOtp,
        });

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Email verified successfully. You can now login.',
      });

      const updatedUser = await prisma.user.findUnique({
        where: { id: user.id },
      });
      expect(updatedUser?.isVerified).toBe(true);
      expect(updatedUser?.verificationCode).toBeNull();
      expect(updatedUser?.otpExpiresAt).toBeNull();
    });

    it('should reject verification with invalid OTP', async () => {
      const bcrypt = await import('bcryptjs');
      const knownOtp = '123456';
      const hashedOtp = await bcrypt.default.hash(knownOtp, 10);
      const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

      const user = await prisma.user.create({
        data: {
          email: `invalid-otp-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.default.hash('Password123!', 12),
          firstName: 'Invalid',
          lastName: 'OTP',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: false,
          verificationCode: hashedOtp,
          otpExpiresAt,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(user.id);

      const response = await request(app)
        .post('/api/v1/auth/v1/verify-otp')
        .send({
          email: user.email,
          otp: '999999',
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid verification code');
    });

    it('should reject verification for already verified user', async () => {
      const user = await createTestUser({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/verify-otp')
        .send({
          email: user.email,
          otp: '123456',
        });

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Email already verified');
    });

    it('should reject verification for non-existent user', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/verify-otp')
        .send({
          email: 'nonexistent@example.com',
          otp: '123456',
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid email or verification code');
    });

    it('should reject verification with expired OTP', async () => {
      const bcrypt = await import('bcryptjs');
      const knownOtp = '123456';
      const hashedOtp = await bcrypt.default.hash(knownOtp, 10);
      const otpExpiresAt = new Date(Date.now() - 1000);

      const user = await prisma.user.create({
        data: {
          email: `expired-otp-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.default.hash('Password123!', 12),
          firstName: 'Expired',
          lastName: 'OTP',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: false,
          verificationCode: hashedOtp,
          otpExpiresAt,
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(user.id);

      const response = await request(app)
        .post('/api/v1/auth/v1/verify-otp')
        .send({
          email: user.email,
          otp: knownOtp,
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Verification code has expired. Please request a new one.');
    });
  });

  // ============================================================
  // Tests - Resend OTP
  // ============================================================

  describe('POST /api/v1/auth/v1/resend-otp', () => {
    it('should resend OTP for existing unverified user', async () => {
      const bcrypt = await import('bcryptjs');
      const user = await prisma.user.create({
        data: {
          email: `resend-${crypto.randomUUID()}@example.com`,
          password: await bcrypt.default.hash('Password123!', 12),
          firstName: 'Resend',
          lastName: 'Test',
          phone: generatePhone(),
          dateOfBirth: new Date('1990-01-01'),
          isVerified: false,
          verificationCode: await bcrypt.default.hash('123456', 10),
          otpExpiresAt: new Date(Date.now() + 10 * 60 * 1000),
          wilaya: { connect: { id: wilayaId } },
        },
      });
      cleanupIds.users.push(user.id);

      const response = await request(app)
        .post('/api/v1/auth/v1/resend-otp')
        .send({
          email: user.email,
        });

      expect(response.status).toBe(200);
      expect(response.body.message).toBe(
        'If your email is registered, a new verification code has been sent.'
      );
    });

    it('should return same message for non-existent email (security)', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/resend-otp')
        .send({
          email: 'nonexistent@example.com',
        });

      expect(response.status).toBe(200);
      expect(response.body.message).toBe(
        'If your email is registered, a new verification code has been sent.'
      );
    });

    it('should return appropriate message for already verified user', async () => {
      const user = await createTestUser({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/resend-otp')
        .send({
          email: user.email,
        });

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Email already verified. You can login now.');
    });
  });

  // ============================================================
  // Tests - Clinic Registration
  // ============================================================

  describe('POST /api/v1/auth/v1/clinic/register', () => {
    it('should register a clinic successfully', async () => {
      const email = `clinic-${crypto.randomUUID()}@example.com`;
      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/register')
        .send({
          nameFr: 'Clinique Test',
          nameAr: 'عيادة اختبار',
          email,
          password: 'Password123!',
          phone: generatePhone(),
          wilayaId,
        });

      expect(response.status).toBe(201);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Clinic registered successfully',
      });
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user).toMatchObject({
        email,
        role: 'CLINIC',
      });
      expect(response.headers['set-cookie']).toBeDefined();
      expect(response.headers['set-cookie'][0]).toContain('token=');

      const clinic = await prisma.clinic.findUnique({
        where: { email },
      });
      expect(clinic).not.toBeNull();
      expect(clinic?.isVerified).toBe(false);
      expect(clinic?.isSuspended).toBe(false);
      if (clinic) cleanupIds.clinics.push(clinic.id);
    });

    it('should reject clinic registration with duplicate email', async () => {
      const clinic = await createTestClinic();

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/register')
        .send({
          nameFr: 'Another Clinic',
          nameAr: 'عيادة أخرى',
          email: clinic.email,
          password: 'Password123!',
          phone: generatePhone(),
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Email already registered');
    });

    it('should reject clinic registration with duplicate phone', async () => {
      const clinic = await createTestClinic();

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/register')
        .send({
          nameFr: 'Another Clinic',
          nameAr: 'عيادة أخرى',
          email: `new-${crypto.randomUUID()}@example.com`,
          password: 'Password123!',
          phone: clinic.phone,
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Phone already registered');
    });
  });

  // ============================================================
  // Tests - Clinic Login
  // ============================================================

  describe('POST /api/v1/auth/v1/clinic/login', () => {
    it('should login a verified clinic successfully', async () => {
      const clinic = await createTestClinic({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/login')
        .send({
          email: clinic.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Login successful',
      });
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user).toMatchObject({
        id: clinic.id,
        email: clinic.email,
        role: 'CLINIC',
      });
      expect(response.headers['set-cookie']).toBeDefined();
    });

    it('should reject login for unverified clinic', async () => {
      const clinic = await createTestClinic({ isVerified: false });

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/login')
        .send({
          email: clinic.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Clinic is pending verification');
    });

    it('should reject login for suspended clinic', async () => {
      const clinic = await createTestClinic({ isVerified: true, isSuspended: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/login')
        .send({
          email: clinic.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Clinic has been suspended');
    });

    it('should reject login with incorrect password', async () => {
      const clinic = await createTestClinic({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/clinic/login')
        .send({
          email: clinic.email,
          password: 'WrongPassword123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid email or password');
    });
  });

  // ============================================================
  // Tests - Doctor Registration
  // ============================================================

  describe('POST /api/v1/auth/v1/doctor/register', () => {
    it('should register a doctor successfully', async () => {
      const email = `doctor-${crypto.randomUUID()}@example.com`;
      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/register')
        .send({
          email,
          password: 'Password123!',
          firstNameFr: 'Ahmed',
          firstNameAr: 'أحمد',
          lastNameFr: 'Benali',
          lastNameAr: 'بن علي',
          phone: generatePhone(),
          wilayaId,
        });

      expect(response.status).toBe(201);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Doctor registered successfully',
      });
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user).toMatchObject({
        email,
        role: 'DOCTOR',
      });
      expect(response.headers['set-cookie']).toBeDefined();

      const doctor = await prisma.doctor.findUnique({
        where: { email },
      });
      expect(doctor).not.toBeNull();
      expect(doctor?.isVerified).toBe(false);
      expect(doctor?.isSuspended).toBe(false);
      if (doctor) cleanupIds.doctors.push(doctor.id);
    });

    it('should reject doctor registration with duplicate email', async () => {
      const doctor = await createTestDoctor();

      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/register')
        .send({
          email: doctor.email,
          password: 'Password123!',
          firstNameFr: 'Ahmed',
          firstNameAr: 'أحمد',
          lastNameFr: 'Benali',
          lastNameAr: 'بن علي',
          phone: generatePhone(),
          wilayaId,
        });

      expect(response.status).toBe(409);
      expect(response.body.message).toContain('Email already registered');
    });
  });

  // ============================================================
  // Tests - Doctor Login
  // ============================================================

  describe('POST /api/v1/auth/v1/doctor/login', () => {
    it('should login a verified doctor successfully', async () => {
      const doctor = await createTestDoctor({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/login')
        .send({
          email: doctor.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Login successful',
      });
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user).toMatchObject({
        id: doctor.id,
        email: doctor.email,
        role: 'DOCTOR',
      });
      expect(response.headers['set-cookie']).toBeDefined();
    });

    it('should reject login for unverified doctor', async () => {
      const doctor = await createTestDoctor({ isVerified: false });

      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/login')
        .send({
          email: doctor.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Your account is pending verification');
    });

    it('should reject login for suspended doctor', async () => {
      const doctor = await createTestDoctor({ isVerified: true, isSuspended: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/login')
        .send({
          email: doctor.email,
          password: 'Password123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Your account has been suspended');
    });

    it('should reject login with incorrect password', async () => {
      const doctor = await createTestDoctor({ isVerified: true });

      const response = await request(app)
        .post('/api/v1/auth/v1/doctor/login')
        .send({
          email: doctor.email,
          password: 'WrongPassword123!',
        });

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid email or password');
    });
  });

  // ============================================================
  // Tests - Me Endpoint
  // ============================================================

  describe('GET /api/v1/auth/v1/me', () => {
    it('should return current user from cookie token', async () => {
      const user = await createTestUser({ isVerified: true });

      const loginResponse = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password: 'Password123!',
        });

      const cookie = loginResponse.headers['set-cookie'];

      const response = await request(app)
        .get('/api/v1/auth/v1/me')
        .set('Cookie', cookie);

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'User retrieved',
      });
      expect(response.body.data.user).toMatchObject({
        id: user.id,
        email: user.email,
        name: 'Test User',
        role: 'USER',
      });
    });

    it('should return current user from Authorization header', async () => {
      const user = await createTestUser({ isVerified: true });

      const loginResponse = await request(app)
        .post('/api/v1/auth/v1/user/login')
        .send({
          email: user.email,
          password: 'Password123!',
        });

      const token = loginResponse.body.data.token;

      const response = await request(app)
        .get('/api/v1/auth/v1/me')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.data.user).toMatchObject({
        id: user.id,
        email: user.email,
      });
    });

    it('should return 401 when no token provided', async () => {
      const response = await request(app)
        .get('/api/v1/auth/v1/me');

      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Not authenticated');
    });

    it('should return 401 when invalid token provided', async () => {
      const response = await request(app)
        .get('/api/v1/auth/v1/me')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
    });
  });

  // ============================================================
  // Tests - Logout
  // ============================================================

  describe('POST /api/v1/auth/v1/logout', () => {
    it('should clear the token cookie', async () => {
      const response = await request(app)
        .post('/api/v1/auth/v1/logout');

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Logged out successfully',
      });

      const cookieHeader = response.headers['set-cookie'];
      expect(cookieHeader).toBeDefined();
      expect(cookieHeader[0]).toContain('token=;');
      expect(cookieHeader[0]).toContain('Path=/');
    });
  });
});

