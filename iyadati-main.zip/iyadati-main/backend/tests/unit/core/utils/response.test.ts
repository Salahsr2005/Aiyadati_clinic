import { ResponseUtil } from '../../../../src/core/utils/response';

describe('ResponseUtil', () => {
  const createMockResponse = () => {
    const res: any = {
      status: jest.fn(),
      json: jest.fn(),
      send: jest.fn(),
      req: {
        id: 'test-request-id',
      },
    };

    res.status.mockReturnValue(res);
    res.json.mockReturnValue(res);
    res.send.mockReturnValue(res);

    return res;
  };

  describe('success', () => {
    it('should return a successful response', () => {
      const res = createMockResponse();

      ResponseUtil.success(
        res,
        { id: 1, name: 'Jalil' },
        'User fetched successfully',
      );

      expect(res.status).toHaveBeenCalledWith(200);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'User fetched successfully',
          data: { id: 1, name: 'Jalil' },
          meta: expect.objectContaining({
            requestId: 'test-request-id',
            timestamp: expect.any(String),
          }),
        }),
      );
    });

    it('should use default values', () => {
      const res = createMockResponse();

      ResponseUtil.success(res);

      expect(res.status).toHaveBeenCalledWith(200);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Success',
          data: undefined,
        }),
      );
    });

    it('should support a custom status code', () => {
      const res = createMockResponse();

      ResponseUtil.success(
        res,
        { created: true },
        'Created',
        201,
      );

      expect(res.status).toHaveBeenCalledWith(201);
    });

    it('should preserve custom metadata', () => {
      const res = createMockResponse();

      ResponseUtil.success(
        res,
        [],
        'Success',
        200,
        {
          page: 1,
          limit: 10,
        },
      );

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          meta: expect.objectContaining({
            page: 1,
            limit: 10,
            requestId: 'test-request-id',
          }),
        }),
      );
    });
  });

  describe('created', () => {
    it('should return a 201 response', () => {
      const res = createMockResponse();

      ResponseUtil.created(
        res,
        { id: '123' },
      );

      expect(res.status).toHaveBeenCalledWith(201);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Resource created successfully',
          data: { id: '123' },
        }),
      );
    });
  });

  describe('noContent', () => {
    it('should return a 204 response', () => {
      const res = createMockResponse();

      ResponseUtil.noContent(res);

      expect(res.status).toHaveBeenCalledWith(204);
      expect(res.send).toHaveBeenCalled();
    });
  });

  describe('error', () => {
    it('should return a failed response', () => {
      const res = createMockResponse();

      ResponseUtil.error(
        res,
        'Something went wrong',
        500,
      );

      expect(res.status).toHaveBeenCalledWith(500);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Something went wrong',
          error: 'Something went wrong',
          meta: expect.objectContaining({
            requestId: 'test-request-id',
            timestamp: expect.any(String),
          }),
        }),
      );
    });

    it('should include errors when provided', () => {
      const res = createMockResponse();

      const errors = [
        {
          field: 'email',
          message: 'Invalid email',
        },
      ];

      ResponseUtil.error(
        res,
        'Validation failed',
        422,
        errors,
      );

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          errors,
        }),
      );
    });
  });

  describe('shortcut methods', () => {
    it('should return 400 for badRequest', () => {
      const res = createMockResponse();

      ResponseUtil.badRequest(res, 'Invalid input');

      expect(res.status).toHaveBeenCalledWith(400);
    });

    it('should return 401 for unauthorized', () => {
      const res = createMockResponse();

      ResponseUtil.unauthorized(res, 'Invalid token');

      expect(res.status).toHaveBeenCalledWith(401);
    });

    it('should return 403 for forbidden', () => {
      const res = createMockResponse();

      ResponseUtil.forbidden(res, 'Access denied');

      expect(res.status).toHaveBeenCalledWith(403);
    });

    it('should return 404 for notFound', () => {
      const res = createMockResponse();

      ResponseUtil.notFound(res, 'User not found');

      expect(res.status).toHaveBeenCalledWith(404);
    });

    it('should return 409 for conflict', () => {
      const res = createMockResponse();

      ResponseUtil.conflict(res, 'Email already exists');

      expect(res.status).toHaveBeenCalledWith(409);
    });

    it('should return 429 for tooManyRequests', () => {
      const res = createMockResponse();

      ResponseUtil.tooManyRequests(res);

      expect(res.status).toHaveBeenCalledWith(429);
    });

    it('should return 422 for validationError', () => {
      const res = createMockResponse();

      ResponseUtil.validationError(
        res,
        'Validation failed',
      );

      expect(res.status).toHaveBeenCalledWith(422);
    });
  });

  describe('paginated', () => {
    it('should calculate pagination metadata correctly', () => {
      const res = createMockResponse();

      const items = [
        { id: 1 },
        { id: 2 },
      ];

      ResponseUtil.paginated(
        res,
        items,
        25,
        2,
        10,
      );

      expect(res.status).toHaveBeenCalledWith(200);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          data: items,
          meta: expect.objectContaining({
            page: 2,
            limit: 10,
            total: 25,
            totalPages: 3,
            hasNextPage: true,
            hasPreviousPage: true,
            requestId: 'test-request-id',
          }),
        }),
      );
    });

    it('should correctly identify the first page', () => {
      const res = createMockResponse();

      ResponseUtil.paginated(
        res,
        [],
        20,
        1,
        10,
      );

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          meta: expect.objectContaining({
            page: 1,
            totalPages: 2,
            hasNextPage: true,
            hasPreviousPage: false,
          }),
        }),
      );
    });

    it('should correctly identify the last page', () => {
      const res = createMockResponse();

      ResponseUtil.paginated(
        res,
        [],
        20,
        2,
        10,
      );

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          meta: expect.objectContaining({
            page: 2,
            totalPages: 2,
            hasNextPage: false,
            hasPreviousPage: true,
          }),
        }),
      );
    });
  });
});

