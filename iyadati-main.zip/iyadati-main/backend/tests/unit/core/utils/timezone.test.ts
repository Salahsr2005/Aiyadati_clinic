import {
  nowAlgeria,
  toAlgeriaTime,
  isSlotInPastAlgeria,
  getSlotStartDateTimeAlgeria,
} from '../../../../src/core/utils/timezone';

describe('timezone utilities', () => {
  describe('nowAlgeria', () => {
    it('should return a Date', () => {
      const result = nowAlgeria();

      expect(result).toBeInstanceOf(Date);
    });

    it('should be approximately one hour ahead of UTC instant', () => {
      const before = Date.now();

      const result = nowAlgeria();

      const after = Date.now();

      const resultTime = result.getTime();

      expect(resultTime).toBeGreaterThanOrEqual(
        before + 60 * 60 * 1000,
      );

      expect(resultTime).toBeLessThanOrEqual(
        after + 60 * 60 * 1000,
      );
    });
  });

  describe('toAlgeriaTime', () => {
    it('should add one hour', () => {
      const date = new Date('2026-08-11T10:00:00.000Z');

      const result = toAlgeriaTime(date);

      expect(result.getTime()).toBe(
        date.getTime() + 60 * 60 * 1000,
      );
    });

    it('should not mutate the original Date', () => {
      const date = new Date('2026-08-11T10:00:00.000Z');
      const originalTime = date.getTime();

      toAlgeriaTime(date);

      expect(date.getTime()).toBe(originalTime);
    });
  });

  describe('isSlotInPastAlgeria', () => {
    it('should return true when the slot has already passed', () => {
      const slotDate = new Date('2026-08-11T00:00:00.000Z');
      const startTime = new Date('1970-01-01T09:00:00.000Z');

      const now = new Date('2026-08-11T10:00:00.000Z');

      expect(
        isSlotInPastAlgeria(slotDate, startTime, now),
      ).toBe(true);
    });

    it('should return false when the slot is in the future', () => {
      const slotDate = new Date('2026-08-11T00:00:00.000Z');
      const startTime = new Date('1970-01-01T15:00:00.000Z');

      const now = new Date('2026-08-11T10:00:00.000Z');

      expect(
        isSlotInPastAlgeria(slotDate, startTime, now),
      ).toBe(false);
    });

    it('should return true when the slot starts exactly now', () => {
      const slotDate = new Date('2026-08-11T00:00:00.000Z');
      const startTime = new Date('1970-01-01T10:00:00.000Z');

      const now = new Date('2026-08-11T10:00:00.000Z');

      expect(
        isSlotInPastAlgeria(slotDate, startTime, now),
      ).toBe(true);
    });
  });

  describe('getSlotStartDateTimeAlgeria', () => {
    it('should combine the slot date and start time', () => {
      const slotDate = new Date('2026-08-11T00:00:00.000Z');
      const startTime = new Date('1970-01-01T14:30:00.000Z');

      const result = getSlotStartDateTimeAlgeria(
        slotDate,
        startTime,
      );

      expect(result.getHours()).toBe(14);
      expect(result.getMinutes()).toBe(30);
      expect(result.getSeconds()).toBe(0);
      expect(result.getMilliseconds()).toBe(0);
    });

    it('should not mutate the original slot date', () => {
      const slotDate = new Date('2026-08-11T00:00:00.000Z');
      const originalTime = slotDate.getTime();

      const startTime = new Date('1970-01-01T14:30:00.000Z');

      getSlotStartDateTimeAlgeria(
        slotDate,
        startTime,
      );

      expect(slotDate.getTime()).toBe(originalTime);
    });
  });
});

