import {
  AppError,
  ValidationError,
  BadRequestError,
  UnauthorizedError,
  ForbiddenError,
  NotFoundError,
  ConflictError,
  DatabaseError,
  RateLimitError,
} from '../../../../src/core/utils/error';

describe('AppError', () => {
  it('should create an AppError with default values', () => {
    const error = new AppError('Something went wrong');

    expect(error).toBeInstanceOf(Error);
    expect(error).toBeInstanceOf(AppError);

    expect(error.message).toBe('Something went wrong');
    expect(error.statusCode).toBe(500);
    expect(error.isOperational).toBe(true);
    expect(error.details).toBeUndefined();
  });

  it('should accept a custom status code', () => {
    const error = new AppError('Not found', 404);

    expect(error.statusCode).toBe(404);
  });

  it('should accept details', () => {
    const details = [
      { field: 'email', message: 'Invalid email' },
    ];

    const error = new AppError(
      'Validation failed',
      400,
      true,
      details,
    );

    expect(error.details).toEqual(details);
  });

  it('should support non-operational errors', () => {
    const error = new AppError(
      'Database crashed',
      500,
      false,
    );

    expect(error.isOperational).toBe(false);
  });
});

describe('ValidationError', () => {
  it('should create a 400 validation error', () => {
    const error = new ValidationError('Invalid input');

    expect(error).toBeInstanceOf(AppError);
    expect(error).toBeInstanceOf(ValidationError);
    expect(error.name).toBe('ValidationError');
    expect(error.message).toBe('Invalid input');
    expect(error.statusCode).toBe(400);
    expect(error.isOperational).toBe(true);
  });

  it('should accept validation details', () => {
    const details = [
      { field: 'email', message: 'Invalid email' },
    ];

    const error = new ValidationError('Validation failed', details);

    expect(error.details).toEqual(details);
  });
});

describe('BadRequestError', () => {
  it('should use the default message', () => {
    const error = new BadRequestError();

    expect(error.name).toBe('BadRequestError');
    expect(error.statusCode).toBe(400);
    expect(error.message).toBe('Bad request');
  });

  it('should accept a custom message', () => {
    const error = new BadRequestError('Invalid file type');

    expect(error.message).toBe('Invalid file type');
  });
});

describe('UnauthorizedError', () => {
  it('should create a 401 error', () => {
    const error = new UnauthorizedError();

    expect(error.name).toBe('UnauthorizedError');
    expect(error.statusCode).toBe(401);
    expect(error.message).toBe('Unauthorized access');
  });

  it('should accept a custom message', () => {
    const error = new UnauthorizedError('Invalid token');

    expect(error.message).toBe('Invalid token');
  });
});

describe('ForbiddenError', () => {
  it('should create a 403 error', () => {
    const error = new ForbiddenError();

    expect(error.name).toBe('ForbiddenError');
    expect(error.statusCode).toBe(403);
    expect(error.message).toBe('Access forbidden');
  });
});

describe('NotFoundError', () => {
  it('should create a 404 error using the resource name', () => {
    const error = new NotFoundError('User');

    expect(error.name).toBe('NotFoundError');
    expect(error.statusCode).toBe(404);
    expect(error.message).toBe('User not found');
  });
});

describe('ConflictError', () => {
  it('should create a 409 error', () => {
    const error = new ConflictError('Email already exists');

    expect(error.name).toBe('ConflictError');
    expect(error.statusCode).toBe(409);
    expect(error.message).toBe('Email already exists');
  });

  it('should accept details', () => {
    const details = [
      { field: 'email', message: 'Already exists' },
    ];

    const error = new ConflictError(
      'Conflict',
      details,
    );

    expect(error.details).toEqual(details);
  });
});

describe('DatabaseError', () => {
  it('should create a 500 database error', () => {
    const error = new DatabaseError('Database unavailable');

    expect(error.name).toBe('DatabaseError');
    expect(error.statusCode).toBe(500);
    expect(error.message).toBe('Database unavailable');
    expect(error.isOperational).toBe(true);
  });
});

describe('RateLimitError', () => {
  it('should create a 429 error with the default message', () => {
    const error = new RateLimitError();

    expect(error.name).toBe('RateLimitError');
    expect(error.statusCode).toBe(429);
    expect(error.message).toBe(
      'Too many requests, please try again later',
    );
  });

  it('should accept a custom message', () => {
    const error = new RateLimitError('Slow down');

    expect(error.message).toBe('Slow down');
  });
});

