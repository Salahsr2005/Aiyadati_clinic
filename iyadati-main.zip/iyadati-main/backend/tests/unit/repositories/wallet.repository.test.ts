import { walletRepository } from '../../../src/repositories/wallet.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    userWallet: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
    creditTransaction: {
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const mockPrisma = prisma as jest.Mocked<typeof prisma>;

describe('WalletRepository', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('findByUserId', () => {
    it('should find a wallet by user id with the latest 10 transactions', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 100,
        transactions: [],
      };

      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.findByUserId('user-1');

      expect(mockPrisma.userWallet.findUnique).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        include: {
          transactions: {
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
        },
      });

      expect(result).toEqual(wallet);
    });

    it('should return null when the wallet does not exist', async () => {
      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await walletRepository.findByUserId('missing-user');

      expect(result).toBeNull();
    });
  });

  describe('findById', () => {
    it('should find a wallet by id', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 100,
      };

      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.findById('wallet-1');

      expect(mockPrisma.userWallet.findUnique).toHaveBeenCalledWith({
        where: { id: 'wallet-1' },
      });

      expect(result).toEqual(wallet);
    });

    it('should return null when the wallet does not exist', async () => {
      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await walletRepository.findById('missing-wallet');

      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a wallet with zero credits', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 0,
      };

      (mockPrisma.userWallet.create as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.create('user-1');

      expect(mockPrisma.userWallet.create).toHaveBeenCalledWith({
        data: {
          userId: 'user-1',
          credits: 0,
        },
      });

      expect(result).toEqual(wallet);
    });
  });

  describe('getOrCreate', () => {
    it('should return the existing wallet when one exists', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 100,
      };

      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.getOrCreate('user-1');

      expect(result).toEqual(wallet);

      expect(mockPrisma.userWallet.findUnique).toHaveBeenCalledTimes(1);
      expect(mockPrisma.userWallet.create).not.toHaveBeenCalled();
    });

    it('should create a wallet when one does not exist', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 0,
      };

      (mockPrisma.userWallet.findUnique as jest.Mock).mockResolvedValue(null);
      (mockPrisma.userWallet.create as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.getOrCreate('user-1');

      expect(mockPrisma.userWallet.findUnique).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        include: {
          transactions: {
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
        },
      });

      expect(mockPrisma.userWallet.create).toHaveBeenCalledWith({
        data: {
          userId: 'user-1',
          credits: 0,
        },
      });

      expect(result).toEqual(wallet);
    });
  });

  describe('addCredits', () => {
    it('should increment wallet credits', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 150,
      };

      (mockPrisma.userWallet.update as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.addCredits('wallet-1', 50);

      expect(mockPrisma.userWallet.update).toHaveBeenCalledWith({
        where: { id: 'wallet-1' },
        data: {
          credits: {
            increment: 50,
          },
        },
      });

      expect(result).toEqual(wallet);
    });
  });

  describe('deductCredits', () => {
    it('should decrement wallet credits', async () => {
      const wallet = {
        id: 'wallet-1',
        userId: 'user-1',
        credits: 50,
      };

      (mockPrisma.userWallet.update as jest.Mock).mockResolvedValue(wallet);

      const result = await walletRepository.deductCredits('wallet-1', 50);

      expect(mockPrisma.userWallet.update).toHaveBeenCalledWith({
        where: { id: 'wallet-1' },
        data: {
          credits: {
            decrement: 50,
          },
        },
      });

      expect(result).toEqual(wallet);
    });
  });

  describe('createTransaction', () => {
    it('should create a credit transaction with the provided data', async () => {
      const data = {
        walletId: 'wallet-1',
        amount: 100,
        type: 'deposit',
        description: 'Wallet deposit',
        referenceId: 'ref-1',
        senderId: 'user-1',
        performedBy: 'admin-1',
      };

      const transaction = {
        id: 'transaction-1',
        ...data,
      };

      (mockPrisma.creditTransaction.create as jest.Mock).mockResolvedValue(
        transaction,
      );

      const result = await walletRepository.createTransaction(data);

      expect(mockPrisma.creditTransaction.create).toHaveBeenCalledWith({
        data,
      });

      expect(result).toEqual(transaction);
    });

    it('should create a transaction with optional fields omitted', async () => {
      const data = {
        walletId: 'wallet-1',
        amount: 50,
        type: 'deposit',
      };

      const transaction = {
        id: 'transaction-1',
        ...data,
      };

      (mockPrisma.creditTransaction.create as jest.Mock).mockResolvedValue(
        transaction,
      );

      const result = await walletRepository.createTransaction(data);

      expect(mockPrisma.creditTransaction.create).toHaveBeenCalledWith({
        data,
      });

      expect(result).toEqual(transaction);
    });
  });

  describe('createTransfer', () => {
    const params = {
      senderWalletId: 'sender-wallet',
      senderUserId: 'sender-user',
      receiverWalletId: 'receiver-wallet',
      receiverUserId: 'receiver-user',
      amount: 25,
    };

    it('should execute an atomic transfer and create both transaction records', async () => {
      const sentTx = {
        id: 'sent-tx',
        walletId: 'sender-wallet',
        amount: -25,
        type: 'transfer_sent',
      };

      const receivedTx = {
        id: 'received-tx',
        walletId: 'receiver-wallet',
        amount: 25,
        type: 'transfer_received',
      };

      const tx = {
        userWallet: {
          update: jest
            .fn()
            .mockResolvedValueOnce({
              id: 'sender-wallet',
              credits: 75,
            })
            .mockResolvedValueOnce({
              id: 'receiver-wallet',
              credits: 125,
            }),
        },
        creditTransaction: {
          create: jest
            .fn()
            .mockResolvedValueOnce(sentTx)
            .mockResolvedValueOnce(receivedTx),
        },
      };

      (mockPrisma.$transaction as jest.Mock).mockImplementation(
        async (callback) => callback(tx),
      );

      const result = await walletRepository.createTransfer(params);

      expect(mockPrisma.$transaction).toHaveBeenCalledTimes(1);

      expect(tx.userWallet.update).toHaveBeenNthCalledWith(1, {
        where: { id: 'sender-wallet' },
        data: {
          credits: {
            decrement: 25,
          },
        },
      });

      expect(tx.userWallet.update).toHaveBeenNthCalledWith(2, {
        where: { id: 'receiver-wallet' },
        data: {
          credits: {
            increment: 25,
          },
        },
      });

      expect(tx.creditTransaction.create).toHaveBeenNthCalledWith(1, {
        data: expect.objectContaining({
          walletId: 'sender-wallet',
          amount: -25,
          type: 'transfer_sent',
          description: 'Sent 25 credits',
          senderId: 'sender-user',
        }),
      });

      expect(tx.creditTransaction.create).toHaveBeenNthCalledWith(2, {
        data: expect.objectContaining({
          walletId: 'receiver-wallet',
          amount: 25,
          type: 'transfer_received',
          description: 'Received 25 credits',
          senderId: 'sender-user',
        }),
      });

      expect(result.sentTx).toBe(sentTx);
      expect(result.receivedTx).toBe(receivedTx);
      expect(result.transferId).toEqual(expect.any(String));

      const sentReferenceId =
        tx.creditTransaction.create.mock.calls[0][0].data.referenceId;

      const receivedReferenceId =
        tx.creditTransaction.create.mock.calls[1][0].data.referenceId;

      expect(sentReferenceId).toEqual(receivedReferenceId);
      expect(sentReferenceId).toEqual(result.transferId);
    });

    it('should throw INSUFFICIENT_CREDITS when the sender becomes negative', async () => {
      const tx = {
        userWallet: {
          update: jest.fn().mockResolvedValueOnce({
            id: 'sender-wallet',
            credits: -1,
          }),
        },
        creditTransaction: {
          create: jest.fn(),
        },
      };

      (mockPrisma.$transaction as jest.Mock).mockImplementation(
        async (callback) => callback(tx),
      );

      await expect(
        walletRepository.createTransfer(params),
      ).rejects.toThrow('INSUFFICIENT_CREDITS');

      expect(tx.userWallet.update).toHaveBeenCalledTimes(1);
      expect(tx.creditTransaction.create).not.toHaveBeenCalled();
    });

    it('should not credit the receiver when the sender has insufficient credits', async () => {
      const tx = {
        userWallet: {
          update: jest.fn().mockResolvedValueOnce({
            id: 'sender-wallet',
            credits: -10,
          }),
        },
        creditTransaction: {
          create: jest.fn(),
        },
      };

      (mockPrisma.$transaction as jest.Mock).mockImplementation(
        async (callback) => callback(tx),
      );

      await expect(
        walletRepository.createTransfer(params),
      ).rejects.toThrow('INSUFFICIENT_CREDITS');

      expect(tx.userWallet.update).toHaveBeenCalledTimes(1);
      expect(tx.userWallet.update).not.toHaveBeenNthCalledWith(2, {
        where: { id: 'receiver-wallet' },
        data: {
          credits: {
            increment: 25,
          },
        },
      });
    });

    it('should propagate transaction errors', async () => {
      const error = new Error('Database failure');

      (mockPrisma.$transaction as jest.Mock).mockRejectedValue(error);

      await expect(
        walletRepository.createTransfer(params),
      ).rejects.toThrow('Database failure');
    });
  });

  describe('getTransactions', () => {
    const transactions = [
      {
        id: 'transaction-1',
        walletId: 'wallet-1',
        amount: 100,
        type: 'deposit',
      },
    ];

    it('should use default pagination', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(1);

      const result = await walletRepository.getTransactions({});

      expect(mockPrisma.creditTransaction.findMany).toHaveBeenCalledWith({
        where: {},
        skip: 0,
        take: 20,
        orderBy: { createdAt: 'desc' },
        include: {
          wallet: {
            include: {
              user: {
                select: {
                  id: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
        },
      });

      expect(mockPrisma.creditTransaction.count).toHaveBeenCalledWith({
        where: {},
      });

      expect(result).toEqual({
        transactions,
        total: 1,
      });
    });

    it('should calculate pagination correctly', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(25);

      await walletRepository.getTransactions({
        page: 3,
        limit: 10,
      });

      expect(mockPrisma.creditTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          skip: 20,
          take: 10,
        }),
      );
    });

    it('should filter by wallet id', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(1);

      await walletRepository.getTransactions({
        walletId: 'wallet-1',
      });

      expect(mockPrisma.creditTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            walletId: 'wallet-1',
          },
        }),
      );

      expect(mockPrisma.creditTransaction.count).toHaveBeenCalledWith({
        where: {
          walletId: 'wallet-1',
        },
      });
    });

    it('should filter by transaction type', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(1);

      await walletRepository.getTransactions({
        type: 'deposit',
      });

      expect(mockPrisma.creditTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            type: 'deposit',
          },
        }),
      );
    });

    it('should apply wallet and type filters together', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(1);

      await walletRepository.getTransactions({
        walletId: 'wallet-1',
        type: 'deposit',
      });

      expect(mockPrisma.creditTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            walletId: 'wallet-1',
            type: 'deposit',
          },
        }),
      );

      expect(mockPrisma.creditTransaction.count).toHaveBeenCalledWith({
        where: {
          walletId: 'wallet-1',
          type: 'deposit',
        },
      });
    });

    it('should return transactions and total', async () => {
      (mockPrisma.creditTransaction.findMany as jest.Mock).mockResolvedValue(
        transactions,
      );
      (mockPrisma.creditTransaction.count as jest.Mock).mockResolvedValue(42);

      const result = await walletRepository.getTransactions({
        page: 2,
        limit: 10,
      });

      expect(result).toEqual({
        transactions,
        total: 42,
      });
    });
  });
});

