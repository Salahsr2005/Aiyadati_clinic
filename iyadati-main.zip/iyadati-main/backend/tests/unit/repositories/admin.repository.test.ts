import { AdminRepository } from '../../../src/repositories/admin.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    admin: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
  },
}));

describe('AdminRepository', () => {
  let repository: AdminRepository;

  beforeEach(() => {
    repository = new AdminRepository();
    jest.clearAllMocks();
  });

  describe('findById', () => {
    it('should find an admin by id', async () => {
      const admin = {
        id: 'admin-1',
        email: 'admin@example.com',
      };

      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(admin);

      const result = await repository.findById('admin-1');

      expect(prisma.admin.findUnique).toHaveBeenCalledWith({
        where: { id: 'admin-1' },
      });

      expect(result).toEqual(admin);
    });

    it('should return null when the admin does not exist', async () => {
      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('non-existent-id');

      expect(prisma.admin.findUnique).toHaveBeenCalledWith({
        where: { id: 'non-existent-id' },
      });

      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find an admin by email', async () => {
      const admin = {
        id: 'admin-1',
        email: 'admin@example.com',
      };

      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(admin);

      const result = await repository.findByEmail('admin@example.com');

      expect(prisma.admin.findUnique).toHaveBeenCalledWith({
        where: { email: 'admin@example.com' },
      });

      expect(result).toEqual(admin);
    });

    it('should return null when the email does not exist', async () => {
      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByEmail('unknown@example.com');

      expect(prisma.admin.findUnique).toHaveBeenCalledWith({
        where: { email: 'unknown@example.com' },
      });

      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create an admin with the provided data', async () => {
      const data = {
        email: 'admin@example.com',
        password: 'hashed-password',
      };

      const createdAdmin = {
        id: 'admin-1',
        ...data,
      };

      (prisma.admin.create as jest.Mock).mockResolvedValue(createdAdmin);

      const result = await repository.create(data as any);

      expect(prisma.admin.create).toHaveBeenCalledWith({
        data,
      });

      expect(result).toEqual(createdAdmin);
    });
  });

  describe('update', () => {
    it('should update an admin with the provided data', async () => {
      const data = {
        email: 'updated@example.com',
      };

      const updatedAdmin = {
        id: 'admin-1',
        email: 'updated@example.com',
      };

      (prisma.admin.update as jest.Mock).mockResolvedValue(updatedAdmin);

      const result = await repository.update('admin-1', data as any);

      expect(prisma.admin.update).toHaveBeenCalledWith({
        where: { id: 'admin-1' },
        data,
      });

      expect(result).toEqual(updatedAdmin);
    });
  });

  describe('delete', () => {
    it('should delete an admin by id', async () => {
      const deletedAdmin = {
        id: 'admin-1',
        email: 'admin@example.com',
      };

      (prisma.admin.delete as jest.Mock).mockResolvedValue(deletedAdmin);

      const result = await repository.delete('admin-1');

      expect(prisma.admin.delete).toHaveBeenCalledWith({
        where: { id: 'admin-1' },
      });

      expect(result).toEqual(deletedAdmin);
    });
  });

  describe('findAll', () => {
    it('should use default pagination', async () => {
      const admins = [
        {
          id: 'admin-1',
          email: 'admin1@example.com',
        },
        {
          id: 'admin-2',
          email: 'admin2@example.com',
        },
      ];

      (prisma.admin.findMany as jest.Mock).mockResolvedValue(admins);
      (prisma.admin.count as jest.Mock).mockResolvedValue(2);

      const result = await repository.findAll();

      expect(prisma.admin.findMany).toHaveBeenCalledWith({
        skip: 0,
        take: 10,
        orderBy: { createdAt: 'desc' },
      });

      expect(prisma.admin.count).toHaveBeenCalledWith();

      expect(result).toEqual({
        admins,
        total: 2,
      });
    });

    it('should calculate pagination correctly', async () => {
      const admins = [
        {
          id: 'admin-11',
          email: 'admin11@example.com',
        },
      ];

      (prisma.admin.findMany as jest.Mock).mockResolvedValue(admins);
      (prisma.admin.count as jest.Mock).mockResolvedValue(21);

      const result = await repository.findAll(3, 10);

      expect(prisma.admin.findMany).toHaveBeenCalledWith({
        skip: 20,
        take: 10,
        orderBy: { createdAt: 'desc' },
      });

      expect(prisma.admin.count).toHaveBeenCalledWith();

      expect(result).toEqual({
        admins,
        total: 21,
      });
    });

    it('should support custom page and limit', async () => {
      (prisma.admin.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.admin.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll(2, 25);

      expect(prisma.admin.findMany).toHaveBeenCalledWith({
        skip: 25,
        take: 25,
        orderBy: { createdAt: 'desc' },
      });
    });
  });

  describe('updatePassword', () => {
    it('should update the admin password', async () => {
      const updatedAdmin = {
        id: 'admin-1',
        email: 'admin@example.com',
        password: 'new-hashed-password',
      };

      (prisma.admin.update as jest.Mock).mockResolvedValue(updatedAdmin);

      const result = await repository.updatePassword(
        'admin-1',
        'new-hashed-password',
      );

      expect(prisma.admin.update).toHaveBeenCalledWith({
        where: { id: 'admin-1' },
        data: { password: 'new-hashed-password' },
      });

      expect(result).toEqual(updatedAdmin);
    });
  });

  describe('emailExists', () => {
    it('should return true when the email exists', async () => {
      const admin = {
        id: 'admin-1',
        email: 'admin@example.com',
      };

      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(admin);

      const result = await repository.emailExists('admin@example.com');

      expect(prisma.admin.findUnique).toHaveBeenCalledWith({
        where: { email: 'admin@example.com' },
      });

      expect(result).toBe(true);
    });

    it('should return false when the email does not exist', async () => {
      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.emailExists('unknown@example.com');

      expect(result).toBe(false);
    });

    it('should return false when the found admin is the excluded admin', async () => {
      const admin = {
        id: 'admin-1',
        email: 'admin@example.com',
      };

      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(admin);

      const result = await repository.emailExists(
        'admin@example.com',
        'admin-1',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found admin is different from the excluded admin', async () => {
      const admin = {
        id: 'admin-2',
        email: 'admin@example.com',
      };

      (prisma.admin.findUnique as jest.Mock).mockResolvedValue(admin);

      const result = await repository.emailExists(
        'admin@example.com',
        'admin-1',
      );

      expect(result).toBe(true);
    });
  });
});

