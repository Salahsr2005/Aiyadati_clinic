// backend/tests/unit/repositories/slot.repository.test.ts

import { SlotRepository } from '../../../src/repositories/slot.repository';
import { prisma } from '../../../src/core/utils/prisma';
import { nowAlgeria, isSlotInPastAlgeria } from '../../../src/core/utils/timezone';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    slot: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      createMany: jest.fn(),
      update: jest.fn(),
      updateMany: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
    appointment: {
      count: jest.fn(),
      update: jest.fn(),
      findMany: jest.fn(),
    },
    userWallet: {
      upsert: jest.fn(),
    },
    creditTransaction: {
      create: jest.fn(),
    },
    slotGenerationRule: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      upsert: jest.fn(),
      update: jest.fn(),
    },
    $transaction: jest.fn((callback) => callback({
      userWallet: {
        upsert: jest.fn().mockResolvedValue({ id: 'wallet-123' }),
      },
      creditTransaction: {
        create: jest.fn().mockResolvedValue({}),
      },
      appointment: {
        update: jest.fn().mockResolvedValue({}),
      },
    })),
  },
}));

jest.mock('../../../src/core/utils/timezone', () => ({
  nowAlgeria: jest.fn(),
  isSlotInPastAlgeria: jest.fn(),
}));

describe('SlotRepository', () => {
  let repository: SlotRepository;

  const mockSlot = {
    id: 'slot-123',
    doctorId: 'doctor-123',
    clinicId: null,
    roomId: null,
    date: new Date('2026-08-20'),
    startTime: new Date('1970-01-01T09:00:00.000Z'),
    endTime: new Date('1970-01-01T09:30:00.000Z'),
    slotKey: 'doctor-123:2026-08-20:09:00:none:none',
    maxPatients: 3,
    status: 'available',
    createdAt: new Date(),
  };

  const mockDoctor = {
    id: 'doctor-123',
    firstNameFr: 'Ahmed',
    lastNameFr: 'Benali',
  };

  const mockClinic = {
    id: 'clinic-123',
    nameFr: 'Test Clinic',
  };

  const mockRoom = {
    id: 'room-123',
    name: 'Room 1',
  };

  beforeEach(() => {
    repository = new SlotRepository();
    jest.clearAllMocks();
    (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));
    (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);

    // Reset $transaction mock
    (prisma.$transaction as jest.Mock).mockImplementation((callback) => callback({
      userWallet: {
        upsert: jest.fn().mockResolvedValue({ id: 'wallet-123' }),
      },
      creditTransaction: {
        create: jest.fn().mockResolvedValue({}),
      },
      appointment: {
        update: jest.fn().mockResolvedValue({}),
      },
    }));
  });

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find a slot by id with all relations', async () => {
      const slotWithRelations = {
        ...mockSlot,
        doctor: mockDoctor,
        clinic: mockClinic,
        room: mockRoom,
      };

      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(slotWithRelations);

      const result = await repository.findById('slot-123');

      expect(prisma.slot.findUnique).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
        include: {
          doctor: true,
          clinic: true,
          room: true,
        },
      });

      expect(result).toEqual(slotWithRelations);
      expect(result?.id).toBe('slot-123');
      expect(result?.doctor).toBeDefined();
    });

    it('should return null when slot does not exist', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('non-existent-id');

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // findByDoctorAndDate
  // ============================================================

  describe('findByDoctorAndDate', () => {
    const mockSlots = [
      { ...mockSlot, id: 'slot-1', startTime: new Date('1970-01-01T09:00:00.000Z') },
      { ...mockSlot, id: 'slot-2', startTime: new Date('1970-01-01T10:00:00.000Z') },
    ];

    beforeEach(() => {
      (prisma.slot.findMany as jest.Mock).mockResolvedValue(mockSlots);
    });

    it('should return slots for a doctor on a specific date', async () => {
      const result = await repository.findByDoctorAndDate('doctor-123', '2026-08-20');

      expect(prisma.slot.findMany).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          date: new Date('2026-08-20'),
        },
        orderBy: {
          startTime: 'asc',
        },
        include: {
          doctor: true,
          clinic: true,
          room: true,
        },
      });

      expect(result).toHaveLength(2);
      expect(result[0].id).toBe('slot-1');
      expect(result[1].id).toBe('slot-2');
    });

    it('should return empty array when no slots found', async () => {
      (prisma.slot.findMany as jest.Mock).mockResolvedValue([]);

      const result = await repository.findByDoctorAndDate('doctor-123', '2026-08-20');

      expect(result).toHaveLength(0);
    });
  });

    // ============================================================
    // findAvailableByDoctorAndDate - FIXED
    // ============================================================

    describe('findAvailableByDoctorAndDate', () => {
    // Only available slots - cancelled slots are filtered out by Prisma
    const mockSlots = [
        { ...mockSlot, id: 'slot-1', status: 'available' },
        { ...mockSlot, id: 'slot-2', status: 'available' },
    ];

    beforeEach(() => {
        // Mock findMany to return only non-cancelled slots (matches the Prisma query)
        (prisma.slot.findMany as jest.Mock).mockResolvedValue(mockSlots);
    });

    it('should return only available slots excluding cancelled', async () => {
        // Make all slots appear as NOT in the past
        (isSlotInPastAlgeria as jest.Mock)
        .mockReturnValueOnce(false) // slot-1
        .mockReturnValueOnce(false); // slot-2

        const result = await repository.findAvailableByDoctorAndDate('doctor-123', '2026-08-20');

        expect(prisma.slot.findMany).toHaveBeenCalledWith({
        where: {
            doctorId: 'doctor-123',
            date: new Date('2026-08-20'),
            status: {
            not: 'cancelled',
            },
        },
        orderBy: {
            startTime: 'asc',
        },
        include: {
            doctor: true,
            clinic: true,
            room: true,
        },
        });

        // Both slots are available and not in the past
        expect(result).toHaveLength(2);
        expect(result[0].status).toBe('available');
        expect(result[1].status).toBe('available');
    });

    it('should filter out slots that have already passed', async () => {
        // isSlotInPastAlgeria is called for each slot
        (isSlotInPastAlgeria as jest.Mock)
        .mockReturnValueOnce(false) // slot-1 is future → keep
        .mockReturnValueOnce(true);  // slot-2 is past → filter out

        const result = await repository.findAvailableByDoctorAndDate('doctor-123', '2026-08-20');

        // Should only keep slot-1 (future, available)
        expect(result).toHaveLength(1);
        expect(result[0].id).toBe('slot-1');
    });

    it('should return empty array when no available slots', async () => {
        (prisma.slot.findMany as jest.Mock).mockResolvedValue([]);

        const result = await repository.findAvailableByDoctorAndDate('doctor-123', '2026-08-20');

        expect(result).toHaveLength(0);
    });
    });

  // ============================================================
  // validateSlotIsBookable
  // ============================================================

  describe('validateSlotIsBookable', () => {
    it('should return slot when valid and bookable', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(mockSlot);
      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);

      const result = await repository.validateSlotIsBookable('slot-123');

      expect(prisma.slot.findUnique).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
      });

      expect(result).toEqual(mockSlot);
    });

    it('should throw error when slot not found', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(null);

      await expect(
        repository.validateSlotIsBookable('non-existent')
      ).rejects.toThrow('Slot not found');
    });

    it('should throw error when slot is cancelled', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'cancelled',
      });

      await expect(
        repository.validateSlotIsBookable('slot-123')
      ).rejects.toThrow('This slot has been cancelled');
    });

    it('should throw error when slot has already passed', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(mockSlot);
      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(true);

      await expect(
        repository.validateSlotIsBookable('slot-123')
      ).rejects.toThrow('This slot has already passed');
    });

    it('should use transaction client when provided', async () => {
      const tx = {
        slot: {
          findUnique: jest.fn().mockResolvedValue(mockSlot),
        },
      } as any;

      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);

      const result = await repository.validateSlotIsBookable('slot-123', new Date(), tx);

      expect(tx.slot.findUnique).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
      });

      expect(result).toEqual(mockSlot);
    });
  });

  // ============================================================
  // refreshSlotStatus
  // ============================================================

  describe('refreshSlotStatus', () => {
    it('should set status to full when active appointments >= maxPatients', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(mockSlot);
      (prisma.appointment.count as jest.Mock).mockResolvedValue(3);

      (prisma.slot.update as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'full',
      });

      const result = await repository.refreshSlotStatus('slot-123');

      expect(prisma.slot.update).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
        data: { status: 'full' },
      });

      expect(result?.status).toBe('full');
    });

    it('should set status to available when active appointments < maxPatients', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'full',
      });
      (prisma.appointment.count as jest.Mock).mockResolvedValue(1);

      (prisma.slot.update as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'available',
      });

      const result = await repository.refreshSlotStatus('slot-123');

      expect(prisma.slot.update).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
        data: { status: 'available' },
      });

      expect(result?.status).toBe('available');
    });

    it('should not update if status already correct', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'available',
      });
      (prisma.appointment.count as jest.Mock).mockResolvedValue(1);

      const result = await repository.refreshSlotStatus('slot-123');

      expect(prisma.slot.update).not.toHaveBeenCalled();
      expect(result?.status).toBe('available');
    });

    it('should return null when slot not found', async () => {
      (prisma.slot.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.refreshSlotStatus('non-existent');

      expect(result).toBeNull();
    });

    it('should use transaction client when provided', async () => {
      const tx = {
        slot: {
          findUnique: jest.fn().mockResolvedValue(mockSlot),
          update: jest.fn().mockResolvedValue({ ...mockSlot, status: 'full' }),
        },
        appointment: {
          count: jest.fn().mockResolvedValue(3),
        },
      } as any;

      const result = await repository.refreshSlotStatus('slot-123', tx);

      expect(tx.slot.update).toHaveBeenCalled();
      expect(result?.status).toBe('full');
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    const createData = {
      doctorId: 'doctor-123',
      clinicId: 'clinic-123',
      roomId: 'room-123',
      date: new Date('2026-08-20'),
      startTime: new Date('1970-01-01T09:00:00.000Z'),
      endTime: new Date('1970-01-01T09:30:00.000Z'),
      maxPatients: 2,
    };

    it('should create a slot with generated slotKey', async () => {
      const createdSlot = {
        ...mockSlot,
        ...createData,
        slotKey: 'doctor-123:2026-08-20:09:00:clinic-123:room-123',
      };

      (prisma.slot.create as jest.Mock).mockResolvedValue(createdSlot);

      const result = await repository.create(createData);

      expect(prisma.slot.create).toHaveBeenCalledWith({
        data: {
          ...createData,
          slotKey: expect.any(String),
          maxPatients: 2,
        },
      });

      expect(result.slotKey).toBeDefined();
      expect(result.maxPatients).toBe(2);
    });

    it('should use default maxPatients when not provided', async () => {
      const dataWithoutMax = {
        doctorId: 'doctor-123',
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        endTime: new Date('1970-01-01T09:30:00.000Z'),
      };

      (prisma.slot.create as jest.Mock).mockResolvedValue({
        ...mockSlot,
        ...dataWithoutMax,
        maxPatients: 1,
      });

      const result = await repository.create(dataWithoutMax as any);

      expect(prisma.slot.create).toHaveBeenCalledWith({
        data: {
          ...dataWithoutMax,
          slotKey: expect.any(String),
          maxPatients: 1,
        },
      });

      expect(result.maxPatients).toBe(1);
    });

    it('should handle null clinicId and roomId in slotKey', async () => {
      const dataWithoutClinic = {
        doctorId: 'doctor-123',
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        endTime: new Date('1970-01-01T09:30:00.000Z'),
      };

      (prisma.slot.create as jest.Mock).mockResolvedValue({
        ...mockSlot,
        ...dataWithoutClinic,
      });

      await repository.create(dataWithoutClinic as any);

      expect(prisma.slot.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          slotKey: expect.stringContaining('none:none'),
        }),
      });
    });
  });

  // ============================================================
  // createMany
  // ============================================================

  describe('createMany', () => {
    const slotsData = [
      {
        doctorId: 'doctor-123',
        clinicId: 'clinic-123',
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        endTime: new Date('1970-01-01T09:30:00.000Z'),
        maxPatients: 2,
      },
      {
        doctorId: 'doctor-123',
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T10:00:00.000Z'),
        endTime: new Date('1970-01-01T10:30:00.000Z'),
        maxPatients: 3,
      },
    ];

    it('should create multiple slots with generated slotKeys', async () => {
      (prisma.slot.createMany as jest.Mock).mockResolvedValue({ count: 2 });

      const result = await repository.createMany(slotsData);

      expect(prisma.slot.createMany).toHaveBeenCalledWith({
        data: slotsData.map(slot => ({
          ...slot,
          slotKey: expect.any(String),
        })),
        skipDuplicates: true,
      });

      expect(result.count).toBe(2);
    });

    it('should handle empty array', async () => {
      (prisma.slot.createMany as jest.Mock).mockResolvedValue({ count: 0 });

      const result = await repository.createMany([]);

      expect(prisma.slot.createMany).toHaveBeenCalledWith({
        data: [],
        skipDuplicates: true,
      });

      expect(result.count).toBe(0);
    });

    it('should generate unique slotKeys for each slot', async () => {
      (prisma.slot.createMany as jest.Mock).mockResolvedValue({ count: 2 });

      await repository.createMany(slotsData);

      const callData = (prisma.slot.createMany as jest.Mock).mock.calls[0][0].data;
      
      expect(callData[0].slotKey).not.toBe(callData[1].slotKey);
    });
  });

  // ============================================================
  // updateStatus
  // ============================================================

  describe('updateStatus', () => {
    it('should update slot status', async () => {
      (prisma.slot.update as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'cancelled',
      });

      const result = await repository.updateStatus('slot-123', 'cancelled');

      expect(prisma.slot.update).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
        data: { status: 'cancelled' },
      });

      expect(result.status).toBe('cancelled');
    });
  });

  // ============================================================
  // cancelSlot
  // ============================================================

  describe('cancelSlot', () => {
    it('should cancel a slot', async () => {
      (prisma.slot.update as jest.Mock).mockResolvedValue({
        ...mockSlot,
        status: 'cancelled',
      });

      const result = await repository.cancelSlot('slot-123');

      expect(prisma.slot.update).toHaveBeenCalledWith({
        where: { id: 'slot-123' },
        data: { status: 'cancelled' },
      });

      expect(result.status).toBe('cancelled');
    });
  });

  // ============================================================
  // cancelByDoctorAndDate
  // ============================================================

  describe('cancelByDoctorAndDate', () => {
    it('should cancel all slots for a doctor on a date', async () => {
      (prisma.slot.updateMany as jest.Mock).mockResolvedValue({ count: 3 });

      const result = await repository.cancelByDoctorAndDate('doctor-123', '2026-08-20');

      expect(prisma.slot.updateMany).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          date: new Date('2026-08-20'),
          status: {
            in: ['available', 'full'],
          },
        },
        data: {
          status: 'cancelled',
        },
      });

      expect(result.count).toBe(3);
    });

    it('should return 0 when no slots to cancel', async () => {
      (prisma.slot.updateMany as jest.Mock).mockResolvedValue({ count: 0 });

      const result = await repository.cancelByDoctorAndDate('doctor-123', '2026-08-20');

      expect(result.count).toBe(0);
    });
  });

  // ============================================================
  // deleteByDoctorAndDateRange
  // ============================================================

  describe('deleteByDoctorAndDateRange', () => {
    const startDate = new Date('2026-08-20');
    const endDate = new Date('2026-08-22');

    it('should delete slots without active appointments', async () => {
      (prisma.slot.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.slot.deleteMany as jest.Mock).mockResolvedValue({ count: 5 });

      const result = await repository.deleteByDoctorAndDateRange('doctor-123', startDate, endDate);

      expect(prisma.slot.deleteMany).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          date: {
            gte: startDate,
            lte: endDate,
          },
          appointments: {
            none: {
              status: {
                notIn: ['CANCELLED', 'NO_SHOW'],
              },
            },
          },
        },
      });

      expect(result).toBe(5);
    });

    it('should throw error when slots have active appointments', async () => {
      const slotsWithAppointments = [
        {
          id: 'slot-1',
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          _count: { appointments: 2 },
        },
        {
          id: 'slot-2',
          date: new Date('2026-08-21'),
          startTime: new Date('1970-01-01T14:00:00.000Z'),
          _count: { appointments: 1 },
        },
      ];

      (prisma.slot.findMany as jest.Mock).mockResolvedValue(slotsWithAppointments);

      await expect(
        repository.deleteByDoctorAndDateRange('doctor-123', startDate, endDate)
      ).rejects.toThrow('Cannot regenerate slots: 2 slot(s) have active appointments');
    });

    it('should include appointment details in error message', async () => {
      const slotsWithAppointments = [
        {
          id: 'slot-1',
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          _count: { appointments: 2 },
        },
      ];

      (prisma.slot.findMany as jest.Mock).mockResolvedValue(slotsWithAppointments);

      await expect(
        repository.deleteByDoctorAndDateRange('doctor-123', startDate, endDate)
      ).rejects.toThrow('2026-08-20 at 09:00 (2 appointments)');
    });
  });

  // ============================================================
  // forceDeleteByDoctorAndDateRange
  // ============================================================

  describe('forceDeleteByDoctorAndDateRange', () => {
    const startDate = new Date('2026-08-20');
    const endDate = new Date('2026-08-22');

    const mockAppointments = [
      {
        id: 'app-1',
        patientId: 'user-123',
        patientType: 'REGISTERED',
        paymentMethod: 'CREDIT',
      },
      {
        id: 'app-2',
        patientId: null,
        guestPatientId: 'guest-123',
        patientType: 'GUEST',
        paymentMethod: 'ON_SITE',
      },
    ];

    const slotsWithAppointments = [
      {
        id: 'slot-1',
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        appointments: mockAppointments,
      },
    ];

    beforeEach(() => {
      (prisma.slot.findMany as jest.Mock).mockResolvedValue(slotsWithAppointments);
      (prisma.slot.deleteMany as jest.Mock).mockResolvedValue({ count: 1 });
      (prisma.appointment.update as jest.Mock).mockResolvedValue({});
    });

    it('should cancel appointments and refund credits for registered patients', async () => {
      const result = await repository.forceDeleteByDoctorAndDateRange(
        'doctor-123',
        startDate,
        endDate,
        'admin-123'
      );

      expect(prisma.slot.deleteMany).toHaveBeenCalled();
      expect(result.deletedSlots).toBe(1);
      expect(result.cancelledAppointments).toBe(2);
      expect(result.refundedCredits).toBe(1);
    });

    it('should not refund credits for guest patients', async () => {
      const result = await repository.forceDeleteByDoctorAndDateRange(
        'doctor-123',
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.refundedCredits).toBe(1);
    });

    it('should handle slots without appointments', async () => {
      (prisma.slot.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.slot.deleteMany as jest.Mock).mockResolvedValue({ count: 3 });

      const result = await repository.forceDeleteByDoctorAndDateRange(
        'doctor-123',
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.deletedSlots).toBe(3);
      expect(result.cancelledAppointments).toBe(0);
      expect(result.refundedCredits).toBe(0);
    });

    it('should cancel appointments even without credits', async () => {
      const appointmentsWithoutCredits = [
        {
          id: 'app-1',
          patientId: 'user-123',
          patientType: 'REGISTERED',
          paymentMethod: 'ON_SITE',
        },
      ];

      (prisma.slot.findMany as jest.Mock).mockResolvedValue([
        {
          id: 'slot-1',
          date: new Date('2026-08-20'),
          startTime: new Date('1970-01-01T09:00:00.000Z'),
          appointments: appointmentsWithoutCredits,
        },
      ]);

      const result = await repository.forceDeleteByDoctorAndDateRange(
        'doctor-123',
        startDate,
        endDate,
        'admin-123'
      );

      expect(result.cancelledAppointments).toBe(1);
      expect(result.refundedCredits).toBe(0);
    });
  });

  // ============================================================
  // markExpiredSlots
  // ============================================================

  describe('markExpiredSlots', () => {
    it('should mark expired slots as expired', async () => {
      (prisma.slot.updateMany as jest.Mock).mockResolvedValue({ count: 5 });
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-20T10:00:00.000Z'));

      const result = await repository.markExpiredSlots();

      expect(prisma.slot.updateMany).toHaveBeenCalled();
      expect(result).toBe(5);
    });

    it('should return 0 when no expired slots', async () => {
      (prisma.slot.updateMany as jest.Mock).mockResolvedValue({ count: 0 });
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-20T10:00:00.000Z'));

      const result = await repository.markExpiredSlots();

      expect(result).toBe(0);
    });
  });

  // ============================================================
  // generateMissingSlots
  // ============================================================

  describe('generateMissingSlots', () => {
    const slots = [
      {
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T09:00:00.000Z'),
        endTime: new Date('1970-01-01T09:30:00.000Z'),
        maxPatients: 2,
      },
      {
        date: new Date('2026-08-20'),
        startTime: new Date('1970-01-01T10:00:00.000Z'),
        endTime: new Date('1970-01-01T10:30:00.000Z'),
        maxPatients: 3,
      },
    ];

    it('should create missing slots idempotently', async () => {
      (prisma.slot.createMany as jest.Mock).mockResolvedValue({ count: 1 });

      const result = await repository.generateMissingSlots('doctor-123', slots);

      expect(prisma.slot.createMany).toHaveBeenCalledWith({
        data: slots.map(slot => ({
          ...slot,
          doctorId: 'doctor-123',
          slotKey: expect.any(String),
        })),
        skipDuplicates: true,
      });

      expect(result.created).toBe(1);
      expect(result.existing).toBe(1);
      expect(result.errors).toBe(0);
    });

    it('should handle all slots already existing', async () => {
      (prisma.slot.createMany as jest.Mock).mockResolvedValue({ count: 0 });

      const result = await repository.generateMissingSlots('doctor-123', slots);

      expect(result.created).toBe(0);
      expect(result.existing).toBe(2);
      expect(result.errors).toBe(0);
    });

    it('should handle errors during creation', async () => {
      (prisma.slot.createMany as jest.Mock).mockRejectedValue(new Error('DB Error'));

      await expect(
        repository.generateMissingSlots('doctor-123', slots)
      ).rejects.toThrow('DB Error');
    });
  });

  // ============================================================
  // getBookingHorizon
  // ============================================================

  describe('getBookingHorizon', () => {
    it('should return farthest date with slots', async () => {
      (prisma.slot.findFirst as jest.Mock).mockResolvedValue({
        date: new Date('2026-09-20'),
      });

      const result = await repository.getBookingHorizon('doctor-123');

      expect(prisma.slot.findFirst).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
        orderBy: { date: 'desc' },
        select: { date: true },
      });

      expect(result).toEqual(new Date('2026-09-20'));
    });

    it('should filter by clinicId when provided', async () => {
      (prisma.slot.findFirst as jest.Mock).mockResolvedValue({
        date: new Date('2026-09-20'),
      });

      await repository.getBookingHorizon('doctor-123', 'clinic-123');

      expect(prisma.slot.findFirst).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          clinicId: 'clinic-123',
        },
        orderBy: { date: 'desc' },
        select: { date: true },
      });
    });

    it('should filter by roomId when provided', async () => {
      (prisma.slot.findFirst as jest.Mock).mockResolvedValue({
        date: new Date('2026-09-20'),
      });

      await repository.getBookingHorizon('doctor-123', 'clinic-123', 'room-123');

      expect(prisma.slot.findFirst).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-123',
          clinicId: 'clinic-123',
          roomId: 'room-123',
        },
        orderBy: { date: 'desc' },
        select: { date: true },
      });
    });

    it('should return null when no slots found', async () => {
      (prisma.slot.findFirst as jest.Mock).mockResolvedValue(null);

      const result = await repository.getBookingHorizon('doctor-123');

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // upsertAutomationRule
  // ============================================================

  describe('upsertAutomationRule', () => {
    const automationData = {
      frequency: 'WEEKLY',
      bookingWindowDays: 30,
      clinicId: 'clinic-123',
      roomId: 'room-123',
    };

    const mockRule = {
      id: 'rule-123',
      doctorId: 'doctor-123',
      frequency: 'WEEKLY',
      bookingWindowDays: 30,
      enabled: true,
      clinicId: 'clinic-123',
      roomId: 'room-123',
      lastRunAt: null,
      nextRunAt: expect.any(Date),
      errorCount: 0,
      lastError: null,
    };

    it('should create automation rule', async () => {
      (prisma.slotGenerationRule.upsert as jest.Mock).mockResolvedValue(mockRule);

      const result = await repository.upsertAutomationRule('doctor-123', automationData);

      expect(prisma.slotGenerationRule.upsert).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
        update: {
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          clinicId: 'clinic-123',
          roomId: 'room-123',
          enabled: true,
          nextRunAt: expect.any(Date),
          errorCount: 0,
          lastError: null,
        },
        create: {
          doctorId: 'doctor-123',
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          clinicId: 'clinic-123',
          roomId: 'room-123',
          nextRunAt: expect.any(Date),
        },
      });

      expect(result.enabled).toBe(true);
    });

    it('should update existing automation rule', async () => {
      const updateData = {
        frequency: 'DAILY',
        bookingWindowDays: 60,
      };

      const updatedRule = {
        ...mockRule,
        frequency: 'DAILY',
        bookingWindowDays: 60,
      };

      (prisma.slotGenerationRule.upsert as jest.Mock).mockResolvedValue(updatedRule);

      const result = await repository.upsertAutomationRule('doctor-123', updateData);

      expect(result.frequency).toBe('DAILY');
      expect(result.bookingWindowDays).toBe(60);
    });
  });

  // ============================================================
  // disableAutomationRule
  // ============================================================

  describe('disableAutomationRule', () => {
    it('should disable automation rule', async () => {
      (prisma.slotGenerationRule.update as jest.Mock).mockResolvedValue({
        ...mockSlot,
        enabled: false,
      });

      await repository.disableAutomationRule('doctor-123');

      expect(prisma.slotGenerationRule.update).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
        data: { enabled: false },
      });
    });
  });

  // ============================================================
  // getAutomationRule
  // ============================================================

  describe('getAutomationRule', () => {
    it('should return automation rule when exists', async () => {
      const mockRule = {
        id: 'rule-123',
        doctorId: 'doctor-123',
        frequency: 'WEEKLY',
        bookingWindowDays: 30,
        enabled: true,
      };

      (prisma.slotGenerationRule.findUnique as jest.Mock).mockResolvedValue(mockRule);

      const result = await repository.getAutomationRule('doctor-123');

      expect(prisma.slotGenerationRule.findUnique).toHaveBeenCalledWith({
        where: { doctorId: 'doctor-123' },
      });

      expect(result).toEqual(mockRule);
    });

    it('should return null when no rule exists', async () => {
      (prisma.slotGenerationRule.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.getAutomationRule('doctor-123');

      expect(result).toBeNull();
    });
  });
});

