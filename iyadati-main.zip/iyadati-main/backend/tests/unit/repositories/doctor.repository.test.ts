import { DoctorRepository } from '../../../src/repositories/doctor.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    doctor: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    doctorSpecialty: {
      deleteMany: jest.fn(),
      createMany: jest.fn(),
    },
  },
}));

describe('DoctorRepository', () => {
  let repository: DoctorRepository;

  beforeEach(() => {
    repository = new DoctorRepository();
    jest.clearAllMocks();
  });

  describe('findById', () => {
    it('should find a doctor by id with all expected relations', async () => {
      const doctor = {
        id: 'doctor-1',
        email: 'doctor@example.com',
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
        specialties: [],
        logos: [],
      };

      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.findById('doctor-1');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.findUnique).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        include: {
          wilaya: true,
          baladya: true,
          specialties: {
            include: {
              specialty: true,
            },
          },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });

    it('should return null when the doctor does not exist', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('missing-id');

      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find a doctor by email', async () => {
      const doctor = {
        id: 'doctor-1',
        email: 'doctor@example.com',
      };

      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.findByEmail('doctor@example.com');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.findUnique).toHaveBeenCalledWith({
        where: { email: 'doctor@example.com' },
      });
    });

    it('should return null when the email does not exist', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByEmail('missing@example.com');

      expect(result).toBeNull();
    });
  });

  describe('findByPhone', () => {
    it('should find a doctor by phone', async () => {
      const doctor = {
        id: 'doctor-1',
        phone: '0555123456',
      };

      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.findByPhone('0555123456');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.findUnique).toHaveBeenCalledWith({
        where: { phone: '0555123456' },
      });
    });

    it('should return null when the phone does not exist', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByPhone('0000000000');

      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    const createData = {
      email: 'doctor@example.com',
      password: 'hashed-password',
      firstNameFr: 'Ahmed',
      firstNameAr: 'أحمد',
      lastNameFr: 'Benali',
      lastNameAr: 'بن علي',
      phone: '0555123456',
      wilayaId: 'wilaya-1',
    };

    it('should create a doctor with the provided data', async () => {
      const doctor = {
        id: 'doctor-1',
        ...createData,
        isRegistered: true,
        isVerified: false,
        isCompleted: false,
      };

      (prisma.doctor.create as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.create(createData);

      expect(result).toEqual(doctor);

      expect(prisma.doctor.create).toHaveBeenCalledWith({
        data: {
          email: createData.email,
          password: createData.password,
          firstNameFr: createData.firstNameFr,
          firstNameAr: createData.firstNameAr,
          lastNameFr: createData.lastNameFr,
          lastNameAr: createData.lastNameAr,
          phone: createData.phone,
          wilaya: {
            connect: {
              id: createData.wilayaId,
            },
          },
          isRegistered: true,
          isVerified: false,
          isCompleted: false,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });

    it('should use provided status values instead of defaults', async () => {
      const data = {
        ...createData,
        isRegistered: false,
        isVerified: true,
        isCompleted: true,
      };

      const doctor = {
        id: 'doctor-1',
        ...data,
      };

      (prisma.doctor.create as jest.Mock).mockResolvedValue(doctor);

      await repository.create(data);

      expect(prisma.doctor.create).toHaveBeenCalledWith({
        data: {
          email: data.email,
          password: data.password,
          firstNameFr: data.firstNameFr,
          firstNameAr: data.firstNameAr,
          lastNameFr: data.lastNameFr,
          lastNameAr: data.lastNameAr,
          phone: data.phone,
          wilaya: {
            connect: {
              id: data.wilayaId,
            },
          },
          isRegistered: false,
          isVerified: true,
          isCompleted: true,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('update', () => {
    it('should update a doctor and include expected relations', async () => {
      const updateData = {
        firstNameFr: 'Mohamed',
        phone: '0666123456',
        photoFileId: 'file-1',
      };

      const doctor = {
        id: 'doctor-1',
        ...updateData,
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.update('doctor-1', updateData);

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          ...updateData,
          photoFileId: 'file-1',
        },
        include: {
          wilaya: true,
          baladya: true,
          specialties: {
            include: {
              specialty: true,
            },
          },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });
  });

  describe('findAll', () => {
    it('should use default pagination and sorting', async () => {
      const doctors = [{ id: 'doctor-1' }];

      (prisma.doctor.findMany as jest.Mock).mockResolvedValue(doctors);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(1);

      const result = await repository.findAll({});

      expect(result).toEqual({
        doctors,
        total: 1,
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {},
          skip: 0,
          take: 10,
          orderBy: {
            createdAt: 'desc',
          },
        }),
      );

      expect(prisma.doctor.count).toHaveBeenCalledWith({
        where: {},
      });
    });

    it('should calculate pagination correctly', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(25);

      await repository.findAll({
        page: 3,
        limit: 5,
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          skip: 10,
          take: 5,
          orderBy: {
            createdAt: 'desc',
          },
        }),
      );
    });

    it('should filter by wilaya, practice type, and status fields', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        wilayaId: 'wilaya-1',
        practiceType: 'PRIVATE',
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            wilayaId: 'wilaya-1',
            practiceType: 'PRIVATE',
            isVerified: true,
            isSuspended: false,
            isCompleted: true,
          },
        }),
      );
    });

    it('should filter by specialty', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        specialtyId: 'specialty-1',
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            specialties: {
              some: {
                specialtyId: 'specialty-1',
              },
            },
          },
        }),
      );
    });

    it('should search across French/Arabic names, email, and phone', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        search: 'Ahmed',
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            OR: [
              {
                firstNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                firstNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'Ahmed',
                },
              },
            ],
          },
        }),
      );
    });

    it('should support custom sorting', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        sortBy: 'firstNameFr',
        sortOrder: 'asc',
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          orderBy: {
            firstNameFr: 'asc',
          },
        }),
      );
    });

    it('should apply multiple filters together', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        page: 2,
        limit: 20,
        search: 'Ahmed',
        wilayaId: 'wilaya-1',
        specialtyId: 'specialty-1',
        practiceType: 'PRIVATE',
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
        sortBy: 'lastNameFr',
        sortOrder: 'asc',
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            wilayaId: 'wilaya-1',
            practiceType: 'PRIVATE',
            isVerified: true,
            isSuspended: false,
            isCompleted: true,
            specialties: {
              some: {
                specialtyId: 'specialty-1',
              },
            },
            OR: [
              {
                firstNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                firstNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'Ahmed',
                },
              },
            ],
          },
          skip: 20,
          take: 20,
          orderBy: {
            lastNameFr: 'asc',
          },
        }),
      );
    });

    it('should return doctors and total count', async () => {
      const doctors = [
        { id: 'doctor-1' },
        { id: 'doctor-2' },
      ];

      (prisma.doctor.findMany as jest.Mock).mockResolvedValue(doctors);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(15);

      const result = await repository.findAll({
        page: 1,
        limit: 10,
      });

      expect(result).toEqual({
        doctors,
        total: 15,
      });
    });

    it('should filter by isAvailableForBooking', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        isAvailableForBooking: true,
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            isAvailableForBooking: true,
          },
        }),
      );
    });

    // Update the multiple filters test to include isAvailableForBooking
    it('should apply multiple filters together including isAvailableForBooking', async () => {
      (prisma.doctor.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.doctor.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        page: 2,
        limit: 20,
        search: 'Ahmed',
        wilayaId: 'wilaya-1',
        specialtyId: 'specialty-1',
        practiceType: 'PRIVATE',
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
        isAvailableForBooking: true,
        sortBy: 'lastNameFr',
        sortOrder: 'asc',
      });

      expect(prisma.doctor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            wilayaId: 'wilaya-1',
            practiceType: 'PRIVATE',
            isVerified: true,
            isSuspended: false,
            isCompleted: true,
            isAvailableForBooking: true,
            specialties: {
              some: {
                specialtyId: 'specialty-1',
              },
            },
            OR: [
              {
                firstNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                firstNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameFr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                lastNameAr: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'Ahmed',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'Ahmed',
                },
              },
            ],
          },
          skip: 20,
          take: 20,
          orderBy: {
            lastNameFr: 'asc',
          },
        }),
      );
    });

  });

  describe('emailExists', () => {
    it('should return true when the email exists', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-1',
        email: 'doctor@example.com',
      });

      const result = await repository.emailExists('doctor@example.com');

      expect(result).toBe(true);
    });

    it('should return false when the email does not exist', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.emailExists('missing@example.com');

      expect(result).toBe(false);
    });

    it('should return false when the found doctor is the excluded doctor', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-1',
        email: 'doctor@example.com',
      });

      const result = await repository.emailExists(
        'doctor@example.com',
        'doctor-1',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found doctor is different from the excluded doctor', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-2',
        email: 'doctor@example.com',
      });

      const result = await repository.emailExists(
        'doctor@example.com',
        'doctor-1',
      );

      expect(result).toBe(true);
    });
  });

  describe('phoneExists', () => {
    it('should return true when the phone exists', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-1',
        phone: '0555123456',
      });

      const result = await repository.phoneExists('0555123456');

      expect(result).toBe(true);
    });

    it('should return false when the phone does not exist', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.phoneExists('0000000000');

      expect(result).toBe(false);
    });

    it('should return false when the found doctor is the excluded doctor', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-1',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'doctor-1',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found doctor is different from the excluded doctor', async () => {
      (prisma.doctor.findUnique as jest.Mock).mockResolvedValue({
        id: 'doctor-2',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'doctor-1',
      );

      expect(result).toBe(true);
    });
  });

  describe('updatePhoto', () => {
    it('should update photoPath and photoFileId', async () => {
      const doctor = {
        id: 'doctor-1',
        photoPath: '/uploads/photo.jpg',
        photoFileId: 'file-1',
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.updatePhoto(
        'doctor-1',
        '/uploads/photo.jpg',
        'file-1',
      );

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          photoPath: '/uploads/photo.jpg',
          photoFileId: 'file-1',
        },
        include: {
          wilaya: true,
          baladya: true,
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });
  });

  describe('verify', () => {
    it('should verify the doctor and clear rejection reason', async () => {
      const doctor = {
        id: 'doctor-1',
        isVerified: true,
        rejectionReason: null,
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.verify('doctor-1');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isVerified: true,
          rejectionReason: null,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('reject', () => {
    it('should reject the doctor with a reason', async () => {
      const doctor = {
        id: 'doctor-1',
        isVerified: false,
        rejectionReason: 'Invalid documents',
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.reject(
        'doctor-1',
        'Invalid documents',
      );

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          rejectionReason: 'Invalid documents',
          isVerified: false,
        },
      });
    });
  });

  describe('suspend', () => {
    it('should suspend the doctor', async () => {
      const doctor = {
        id: 'doctor-1',
        isSuspended: true,
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.suspend('doctor-1');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isSuspended: true,
        },
      });
    });
  });

  describe('unsuspend', () => {
    it('should unsuspend the doctor', async () => {
      const doctor = {
        id: 'doctor-1',
        isSuspended: false,
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.unsuspend('doctor-1');

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isSuspended: false,
        },
      });
    });
  });

  describe('setSpecialties', () => {
    it('should delete existing specialties and create new ones', async () => {
      (prisma.doctorSpecialty.deleteMany as jest.Mock).mockResolvedValue({
        count: 2,
      });

      (prisma.doctorSpecialty.createMany as jest.Mock).mockResolvedValue({
        count: 2,
      });

      await repository.setSpecialties('doctor-1', [
        'specialty-1',
        'specialty-2',
      ]);

      expect(prisma.doctorSpecialty.deleteMany).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-1',
        },
      });

      expect(prisma.doctorSpecialty.createMany).toHaveBeenCalledWith({
        data: [
          {
            doctorId: 'doctor-1',
            specialtyId: 'specialty-1',
          },
          {
            doctorId: 'doctor-1',
            specialtyId: 'specialty-2',
          },
        ],
      });
    });

    it('should only delete existing specialties when the new list is empty', async () => {
      (prisma.doctorSpecialty.deleteMany as jest.Mock).mockResolvedValue({
        count: 2,
      });

      await repository.setSpecialties('doctor-1', []);

      expect(prisma.doctorSpecialty.deleteMany).toHaveBeenCalledWith({
        where: {
          doctorId: 'doctor-1',
        },
      });

      expect(prisma.doctorSpecialty.createMany).not.toHaveBeenCalled();
    });
  });

  describe('updateBookingAvailability', () => {
    it('should update isAvailableForBooking and messageForUser', async () => {
      const doctor = {
        id: 'doctor-1',
        email: 'doctor@example.com',
        isAvailableForBooking: true,
        messageForUser: 'Available for bookings',
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
        specialties: [],
        logos: [],
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.updateBookingAvailability('doctor-1', {
        isAvailableForBooking: true,
        messageForUser: 'Available for bookings',
      });

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isAvailableForBooking: true,
          messageForUser: 'Available for bookings',
        },
        include: {
          wilaya: true,
          baladya: true,
          specialties: {
            include: {
              specialty: true,
            },
          },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });

    it('should set messageForUser to null when not provided', async () => {
      const doctor = {
        id: 'doctor-1',
        email: 'doctor@example.com',
        isAvailableForBooking: false,
        messageForUser: null,
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
        specialties: [],
        logos: [],
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.updateBookingAvailability('doctor-1', {
        isAvailableForBooking: false,
      });

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isAvailableForBooking: false,
          messageForUser: null,
        },
        include: {
          wilaya: true,
          baladya: true,
          specialties: {
            include: {
              specialty: true,
            },
          },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });

    it('should clear messageForUser when updating to unavailable', async () => {
      const doctor = {
        id: 'doctor-1',
        email: 'doctor@example.com',
        isAvailableForBooking: false,
        messageForUser: null,
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
        specialties: [],
        logos: [],
      };

      (prisma.doctor.update as jest.Mock).mockResolvedValue(doctor);

      const result = await repository.updateBookingAvailability('doctor-1', {
        isAvailableForBooking: false,
        messageForUser: null,
      });

      expect(result).toEqual(doctor);

      expect(prisma.doctor.update).toHaveBeenCalledWith({
        where: { id: 'doctor-1' },
        data: {
          isAvailableForBooking: false,
          messageForUser: null,
        },
        include: {
          wilaya: true,
          baladya: true,
          specialties: {
            include: {
              specialty: true,
            },
          },
          logos: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
    });
  });

});

