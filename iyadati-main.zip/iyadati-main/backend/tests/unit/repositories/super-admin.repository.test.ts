import { SuperAdminRepository } from '../../../src/repositories/super-admin.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    superAdmin: {
      findUnique: jest.fn(),
    },
  },
}));

describe('SuperAdminRepository', () => {
  let repository: SuperAdminRepository;

  beforeEach(() => {
    repository = new SuperAdminRepository();
    jest.clearAllMocks();
  });

  describe('findByEmail', () => {
    it('should find a super admin by email', async () => {
      const superAdmin = {
        id: 'super-admin-1',
        email: 'superadmin@example.com',
      };

      (prisma.superAdmin.findUnique as jest.Mock).mockResolvedValue(
        superAdmin,
      );

      const result = await repository.findByEmail(
        'superadmin@example.com',
      );

      expect(prisma.superAdmin.findUnique).toHaveBeenCalledWith({
        where: {
          email: 'superadmin@example.com',
        },
      });

      expect(result).toEqual(superAdmin);
    });

    it('should return null when the email does not exist', async () => {
      (prisma.superAdmin.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByEmail(
        'unknown@example.com',
      );

      expect(prisma.superAdmin.findUnique).toHaveBeenCalledWith({
        where: {
          email: 'unknown@example.com',
        },
      });

      expect(result).toBeNull();
    });
  });

  describe('findById', () => {
    it('should find a super admin by id', async () => {
      const superAdmin = {
        id: 'super-admin-1',
        email: 'superadmin@example.com',
      };

      (prisma.superAdmin.findUnique as jest.Mock).mockResolvedValue(
        superAdmin,
      );

      const result = await repository.findById('super-admin-1');

      expect(prisma.superAdmin.findUnique).toHaveBeenCalledWith({
        where: {
          id: 'super-admin-1',
        },
      });

      expect(result).toEqual(superAdmin);
    });

    it('should return null when the super admin does not exist', async () => {
      (prisma.superAdmin.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('non-existent-id');

      expect(prisma.superAdmin.findUnique).toHaveBeenCalledWith({
        where: {
          id: 'non-existent-id',
        },
      });

      expect(result).toBeNull();
    });
  });
});

