import { UserRepository } from '../../../src/repositories/user.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    user: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
  },
}));

describe('UserRepository', () => {
  let repository: UserRepository;

  beforeEach(() => {
    repository = new UserRepository();
    jest.clearAllMocks();
  });

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find a user by id and include wilaya', async () => {
      const user = {
        id: 'user-id',
        email: 'user@example.com',
        firstName: 'John',
        lastName: 'Doe',
        wilaya: {
          id: 'wilaya-id',
          name: 'Batna',
        },
      };

      (prisma.user.findUnique as jest.Mock).mockResolvedValue(user);

      const result = await repository.findById('user-id');

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        include: { wilaya: true },
      });

      expect(result).toEqual(user);
    });

    it('should return null when the user does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('non-existent-id');

      expect(result).toBeNull();

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { id: 'non-existent-id' },
        include: { wilaya: true },
      });
    });
  });

  // ============================================================
  // findByEmail
  // ============================================================

  describe('findByEmail', () => {
    it('should find a user by email', async () => {
      const user = {
        id: 'user-id',
        email: 'user@example.com',
      };

      (prisma.user.findUnique as jest.Mock).mockResolvedValue(user);

      const result = await repository.findByEmail(
        'user@example.com',
      );

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'user@example.com' },
      });

      expect(result).toEqual(user);
    });

    it('should return null when email does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByEmail(
        'unknown@example.com',
      );

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // findByPhone
  // ============================================================

  describe('findByPhone', () => {
    it('should find a user by phone', async () => {
      const user = {
        id: 'user-id',
        phone: '0555123456',
      };

      (prisma.user.findUnique as jest.Mock).mockResolvedValue(user);

      const result = await repository.findByPhone(
        '0555123456',
      );

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { phone: '0555123456' },
      });

      expect(result).toEqual(user);
    });

    it('should return null when phone does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByPhone(
        '0000000000',
      );

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    it('should create a user with the provided data', async () => {
      const data = {
        email: 'new@example.com',
        password: 'hashed-password',
        firstName: 'John',
        lastName: 'Doe',
        phone: '0555123456',
      };

      const createdUser = {
        id: 'new-user-id',
        ...data,
      };

      (prisma.user.create as jest.Mock).mockResolvedValue(
        createdUser,
      );

      const result = await repository.create(data as any);

      expect(prisma.user.create).toHaveBeenCalledWith({
        data,
      });

      expect(result).toEqual(createdUser);
    });
  });

  // ============================================================
  // update
  // ============================================================

  describe('update', () => {
    it('should update a user with the provided data', async () => {
      const data = {
        firstName: 'Jane',
      };

      const updatedUser = {
        id: 'user-id',
        firstName: 'Jane',
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.update(
        'user-id',
        data,
      );

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data,
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // delete
  // ============================================================

  describe('delete', () => {
    it('should delete a user by id', async () => {
      const deletedUser = {
        id: 'user-id',
        email: 'user@example.com',
      };

      (prisma.user.delete as jest.Mock).mockResolvedValue(
        deletedUser,
      );

      const result = await repository.delete('user-id');

      expect(prisma.user.delete).toHaveBeenCalledWith({
        where: { id: 'user-id' },
      });

      expect(result).toEqual(deletedUser);
    });
  });

  // ============================================================
  // findAllWithFilters
  // ============================================================

  describe('findAllWithFilters', () => {
    const users = [
      {
        id: 'user-1',
        firstName: 'John',
        lastName: 'Doe',
      },
      {
        id: 'user-2',
        firstName: 'Jane',
        lastName: 'Doe',
      },
    ];

    beforeEach(() => {
      (prisma.user.findMany as jest.Mock).mockResolvedValue(
        users,
      );

      (prisma.user.count as jest.Mock).mockResolvedValue(2);
    });

    it('should use default pagination and sorting', async () => {
      const result = await repository.findAllWithFilters({});

      expect(prisma.user.findMany).toHaveBeenCalledWith({
        where: {},
        skip: 0,
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { wilaya: true },
      });

      expect(prisma.user.count).toHaveBeenCalledWith({
        where: {},
      });

      expect(result).toEqual({
        users,
        total: 2,
      });
    });

    it('should calculate pagination correctly', async () => {
      await repository.findAllWithFilters({
        page: 3,
        limit: 20,
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          skip: 40,
          take: 20,
        }),
      );
    });

    it('should filter by search across name, email, and phone', async () => {
      await repository.findAllWithFilters({
        search: 'john',
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            OR: [
              {
                firstName: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                lastName: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'john',
                },
              },
            ],
          },
        }),
      );
    });

    it('should apply exact filters', async () => {
      await repository.findAllWithFilters({
        email: 'example.com',
        phone: '0555',
        firstName: 'John',
        lastName: 'Doe',
        wilayaId: 'wilaya-id',
        isVerified: true,
        isSuspended: false,
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            email: {
              contains: 'example.com',
              mode: 'insensitive',
            },
            phone: {
              contains: '0555',
            },
            firstName: {
              contains: 'John',
              mode: 'insensitive',
            },
            lastName: {
              contains: 'Doe',
              mode: 'insensitive',
            },
            wilayaId: 'wilaya-id',
            isVerified: true,
            isSuspended: false,
          },
        }),
      );
    });

    it('should apply date of birth range filters', async () => {
      await repository.findAllWithFilters({
        dateOfBirthFrom: '1990-01-01',
        dateOfBirthTo: '2000-12-31',
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            dateOfBirth: {
              gte: new Date('1990-01-01'),
              lte: new Date('2000-12-31'),
            },
          },
        }),
      );
    });

    it('should apply createdAt range filters', async () => {
      await repository.findAllWithFilters({
        createdAtFrom: '2026-01-01',
        createdAtTo: '2026-12-31',
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            createdAt: {
              gte: new Date('2026-01-01'),
              lte: new Date('2026-12-31'),
            },
          },
        }),
      );
    });

    it('should support custom sorting', async () => {
      await repository.findAllWithFilters({
        sortBy: 'firstName',
        sortOrder: 'asc',
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          orderBy: {
            firstName: 'asc',
          },
        }),
      );
    });

    it('should apply multiple filters together', async () => {
      await repository.findAllWithFilters({
        search: 'john',
        wilayaId: 'wilaya-id',
        isVerified: true,
        page: 2,
        limit: 5,
        sortBy: 'firstName',
        sortOrder: 'asc',
      });

      expect(prisma.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            OR: [
              {
                firstName: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                lastName: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'john',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'john',
                },
              },
            ],
            wilayaId: 'wilaya-id',
            isVerified: true,
          },
          skip: 5,
          take: 5,
          orderBy: {
            firstName: 'asc',
          },
          include: { wilaya: true },
        }),
      );
    });

    it('should return users and total count', async () => {
      (prisma.user.findMany as jest.Mock).mockResolvedValue(
        users,
      );

      (prisma.user.count as jest.Mock).mockResolvedValue(25);

      const result = await repository.findAllWithFilters({
        page: 2,
        limit: 10,
      });

      expect(result).toEqual({
        users,
        total: 25,
      });
    });
  });

  // ============================================================
  // emailExists
  // ============================================================

  describe('emailExists', () => {
    it('should return true when email exists', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'user-id',
        email: 'user@example.com',
      });

      const result = await repository.emailExists(
        'user@example.com',
      );

      expect(result).toBe(true);

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { email: 'user@example.com' },
      });
    });

    it('should return false when email does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.emailExists(
        'unknown@example.com',
      );

      expect(result).toBe(false);
    });

    it('should return false when the found user is the excluded user', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'user-id',
        email: 'user@example.com',
      });

      const result = await repository.emailExists(
        'user@example.com',
        'user-id',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found user is different from the excluded user', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'another-user-id',
        email: 'user@example.com',
      });

      const result = await repository.emailExists(
        'user@example.com',
        'user-id',
      );

      expect(result).toBe(true);
    });
  });

  // ============================================================
  // phoneExists
  // ============================================================

  describe('phoneExists', () => {
    it('should return true when phone exists', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'user-id',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
      );

      expect(result).toBe(true);

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: { phone: '0555123456' },
      });
    });

    it('should return false when phone does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.phoneExists(
        '0000000000',
      );

      expect(result).toBe(false);
    });

    it('should return false when the found user is the excluded user', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'user-id',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'user-id',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found user is different from the excluded user', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue({
        id: 'another-user-id',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'user-id',
      );

      expect(result).toBe(true);
    });
  });

  // ============================================================
  // updatePassword
  // ============================================================

  describe('updatePassword', () => {
    it('should update the user password', async () => {
      const updatedUser = {
        id: 'user-id',
        password: 'new-hashed-password',
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.updatePassword(
        'user-id',
        'new-hashed-password',
      );

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          password: 'new-hashed-password',
        },
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // setVerificationCode
  // ============================================================

  describe('setVerificationCode', () => {
    it('should set verification code and expiration date', async () => {
      const expiresAt = new Date('2026-08-11T14:00:00.000Z');

      const updatedUser = {
        id: 'user-id',
        verificationCode: 'hashed-otp',
        otpExpiresAt: expiresAt,
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.setVerificationCode(
        'user-id',
        'hashed-otp',
        expiresAt,
      );

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          verificationCode: 'hashed-otp',
          otpExpiresAt: expiresAt,
        },
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // verifyUser
  // ============================================================

  describe('verifyUser', () => {
    it('should verify the user and clear OTP data', async () => {
      const updatedUser = {
        id: 'user-id',
        isVerified: true,
        verificationCode: null,
        otpExpiresAt: null,
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.verifyUser('user-id');

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          isVerified: true,
          verificationCode: null,
          otpExpiresAt: null,
        },
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // suspend
  // ============================================================

  describe('suspend', () => {
    it('should suspend the user with a reason', async () => {
      const updatedUser = {
        id: 'user-id',
        isSuspended: true,
        suspensionReason: 'Suspicious activity',
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.suspend(
        'user-id',
        'Suspicious activity',
      );

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          isSuspended: true,
          suspensionReason: 'Suspicious activity',
        },
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // unsuspend
  // ============================================================

  describe('unsuspend', () => {
    it('should unsuspend the user and clear the reason', async () => {
      const updatedUser = {
        id: 'user-id',
        isSuspended: false,
        suspensionReason: null,
      };

      (prisma.user.update as jest.Mock).mockResolvedValue(
        updatedUser,
      );

      const result = await repository.unsuspend('user-id');

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          isSuspended: false,
          suspensionReason: null,
        },
      });

      expect(result).toEqual(updatedUser);
    });
  });

  // ============================================================
  // findByQrCode
  // ============================================================

  describe('findByQrCode', () => {
    it('should find a user by QR code with the expected selection', async () => {
      const user = {
        id: 'user-id',
        firstName: 'John',
        lastName: 'Doe',
        email: 'user@example.com',
        phone: '0555123456',
        trustLevel: 'HIGH',
        trustPoints: 100,
        isSuspended: false,
        wallet: {
          id: 'wallet-id',
          credits: 50,
        },
      };

      (prisma.user.findUnique as jest.Mock).mockResolvedValue(user);

      const result = await repository.findByQrCode(
        'qr-code-123',
      );

      expect(prisma.user.findUnique).toHaveBeenCalledWith({
        where: {
          qrCode: 'qr-code-123',
        },
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          phone: true,
          trustLevel: true,
          trustPoints: true,
          isSuspended: true,
          wallet: {
            select: {
              id: true,
              credits: true,
            },
          },
        },
      });

      expect(result).toEqual(user);
    });

    it('should return null when QR code does not exist', async () => {
      (prisma.user.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByQrCode(
        'unknown-qr-code',
      );

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // regenerateQrCode
  // ============================================================

  describe('regenerateQrCode', () => {
    it('should regenerate and return a new QR code', async () => {
      const randomUuid = '12345678-1234-1234-1234-123456789abc';

      const cryptoSpy = jest
        .spyOn(crypto, 'randomUUID')
        .mockReturnValue(randomUuid);

      (prisma.user.update as jest.Mock).mockResolvedValue({
        qrCode: randomUuid,
      });

      const result = await repository.regenerateQrCode(
        'user-id',
      );

      expect(cryptoSpy).toHaveBeenCalled();

      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-id' },
        data: {
          qrCode: randomUuid,
        },
        select: {
          qrCode: true,
        },
      });

      expect(result).toEqual({
        qrCode: randomUuid,
      });

      cryptoSpy.mockRestore();
    });
  });
});

