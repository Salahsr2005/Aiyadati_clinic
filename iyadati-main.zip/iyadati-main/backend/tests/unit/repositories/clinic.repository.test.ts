import { ClinicRepository } from '../../../src/repositories/clinic.repository';
import { prisma } from '../../../src/core/utils/prisma';

jest.mock('../../../src/core/utils/prisma', () => ({
  prisma: {
    clinic: {
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
  },
}));

describe('ClinicRepository', () => {
  let repository: ClinicRepository;

  beforeEach(() => {
    repository = new ClinicRepository();
    jest.clearAllMocks();
  });

  describe('findById', () => {
    it('should find a clinic by id with wilaya and baladya', async () => {
      const clinic = {
        id: 'clinic-1',
        nameFr: 'Clinique El Amal',
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
      };

      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.findById('clinic-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.findUnique).toHaveBeenCalledWith({
        where: { id: 'clinic-1' },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });

    it('should return null when the clinic does not exist', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findById('missing-id');

      expect(result).toBeNull();
    });
  });

  describe('findByEmail', () => {
    it('should find a clinic by email', async () => {
      const clinic = {
        id: 'clinic-1',
        email: 'clinic@example.com',
      };

      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.findByEmail('clinic@example.com');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.findUnique).toHaveBeenCalledWith({
        where: {
          email: 'clinic@example.com',
        },
      });
    });

    it('should return null when the email does not exist', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByEmail('missing@example.com');

      expect(result).toBeNull();
    });
  });

  describe('findByPhone', () => {
    it('should find a clinic by phone', async () => {
      const clinic = {
        id: 'clinic-1',
        phone: '0555123456',
      };

      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.findByPhone('0555123456');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.findUnique).toHaveBeenCalledWith({
        where: {
          phone: '0555123456',
        },
      });
    });

    it('should return null when the phone does not exist', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByPhone('0000000000');

      expect(result).toBeNull();
    });
  });

  describe('findByFileId', () => {
    it('should find a clinic by logo file id with wilaya and baladya', async () => {
      const clinic = {
        id: 'clinic-1',
        logoFileId: 'file-1',
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
      };

      (prisma.clinic.findFirst as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.findByFileId('file-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.findFirst).toHaveBeenCalledWith({
        where: {
          logoFileId: 'file-1',
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });

    it('should return null when no clinic uses the file id', async () => {
      (prisma.clinic.findFirst as jest.Mock).mockResolvedValue(null);

      const result = await repository.findByFileId('missing-file');

      expect(result).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a clinic with the provided data and include relations', async () => {
      const data = {
        email: 'clinic@example.com',
        password: 'hashed-password',
        nameFr: 'Clinique El Amal',
        nameAr: 'عيادة الأمل',
      } as any;

      const clinic = {
        id: 'clinic-1',
        ...data,
        wilaya: { id: 'wilaya-1' },
        baladya: { id: 'baladya-1' },
      };

      (prisma.clinic.create as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.create(data);

      expect(result).toEqual(clinic);

      expect(prisma.clinic.create).toHaveBeenCalledWith({
        data,
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('update', () => {
    it('should update a clinic and include wilaya and baladya', async () => {
      const data = {
        nameFr: 'Clinique Nouvelle',
        logoFileId: 'file-2',
      } as any;

      const clinic = {
        id: 'clinic-1',
        ...data,
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.update('clinic-1', data);

      expect(result).toEqual(clinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          ...data,
          logoFileId: 'file-2',
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('delete', () => {
    it('should delete a clinic by id', async () => {
      const clinic = {
        id: 'clinic-1',
        nameFr: 'Clinique El Amal',
      };

      (prisma.clinic.delete as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.delete('clinic-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.delete).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
      });
    });
  });

  describe('deleteByFileId', () => {
    it('should return null when no clinic uses the file id', async () => {
      jest.spyOn(repository, 'findByFileId').mockResolvedValue(null);

      const result = await repository.deleteByFileId('missing-file');

      expect(result).toBeNull();

      expect(prisma.clinic.update).not.toHaveBeenCalled();
    });

    it('should clear logo fields when the clinic is found', async () => {
      const clinic = {
        id: 'clinic-1',
        logoFileId: 'file-1',
      } as any;

      jest.spyOn(repository, 'findByFileId').mockResolvedValue(clinic);

      const updatedClinic = {
        id: 'clinic-1',
        logoPath: null,
        logoFileId: null,
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(updatedClinic);

      const result = await repository.deleteByFileId('file-1');

      expect(result).toEqual(updatedClinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          logoPath: null,
          logoFileId: null,
        },
      });
    });
  });

  describe('incrementAccessCount', () => {
    it('should resolve without performing a database operation', async () => {
      await expect(
        repository.incrementAccessCount('file-1'),
      ).resolves.toBeUndefined();

      expect(prisma.clinic.update).not.toHaveBeenCalled();
      expect(prisma.clinic.findUnique).not.toHaveBeenCalled();
      expect(prisma.clinic.findFirst).not.toHaveBeenCalled();
    });
  });

  describe('findAll', () => {
    it('should use default pagination and sorting', async () => {
      const clinics = [{ id: 'clinic-1' }];

      (prisma.clinic.findMany as jest.Mock).mockResolvedValue(clinics);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(1);

      const result = await repository.findAll({});

      expect(result).toEqual({
        clinics,
        total: 1,
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {},
          skip: 0,
          take: 10,
          orderBy: {
            createdAt: 'desc',
          },
          include: {
            wilaya: true,
            baladya: true,
          },
        }),
      );

      expect(prisma.clinic.count).toHaveBeenCalledWith({
        where: {},
      });
    });

    it('should calculate pagination correctly', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(25);

      await repository.findAll({
        page: 3,
        limit: 5,
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          skip: 10,
          take: 5,
        }),
      );
    });

    it('should filter by wilaya, baladya, and facility type', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        wilayaId: 'wilaya-1',
        baladyaId: 'baladya-1',
        facilityType: 'CLINIC' as any,
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            wilayaId: 'wilaya-1',
            baladyaId: 'baladya-1',
            facilityType: 'CLINIC',
          },
        }),
      );
    });

    it('should filter by verification, suspension, and completion status', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            isVerified: true,
            isSuspended: false,
            isCompleted: true,
          },
        }),
      );
    });

    it('should search across French name, Arabic name, email, and phone', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        search: 'Amal',
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            OR: [
              {
                nameFr: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                nameAr: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'Amal',
                },
              },
            ],
          },
        }),
      );
    });

    it('should support custom sorting', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        sortBy: 'nameFr',
        sortOrder: 'asc',
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          orderBy: {
            nameFr: 'asc',
          },
        }),
      );
    });

    it('should apply multiple filters together', async () => {
      (prisma.clinic.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(0);

      await repository.findAll({
        page: 2,
        limit: 20,
        wilayaId: 'wilaya-1',
        baladyaId: 'baladya-1',
        facilityType: 'CLINIC' as any,
        isVerified: true,
        isSuspended: false,
        isCompleted: true,
        search: 'Amal',
        sortBy: 'nameFr',
        sortOrder: 'asc',
      });

      expect(prisma.clinic.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            wilayaId: 'wilaya-1',
            baladyaId: 'baladya-1',
            facilityType: 'CLINIC',
            isVerified: true,
            isSuspended: false,
            isCompleted: true,
            OR: [
              {
                nameFr: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                nameAr: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: 'Amal',
                  mode: 'insensitive',
                },
              },
              {
                phone: {
                  contains: 'Amal',
                },
              },
            ],
          },
          skip: 20,
          take: 20,
          orderBy: {
            nameFr: 'asc',
          },
        }),
      );
    });

    it('should return clinics and total count', async () => {
      const clinics = [
        { id: 'clinic-1' },
        { id: 'clinic-2' },
      ];

      (prisma.clinic.findMany as jest.Mock).mockResolvedValue(clinics);
      (prisma.clinic.count as jest.Mock).mockResolvedValue(15);

      const result = await repository.findAll({
        page: 1,
        limit: 10,
      });

      expect(result).toEqual({
        clinics,
        total: 15,
      });
    });
  });

  describe('emailExists', () => {
    it('should return true when the email exists', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-1',
        email: 'clinic@example.com',
      });

      const result = await repository.emailExists('clinic@example.com');

      expect(result).toBe(true);
    });

    it('should return false when the email does not exist', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.emailExists('missing@example.com');

      expect(result).toBe(false);
    });

    it('should return false when the found clinic is the excluded clinic', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-1',
        email: 'clinic@example.com',
      });

      const result = await repository.emailExists(
        'clinic@example.com',
        'clinic-1',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found clinic is different from the excluded clinic', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-2',
        email: 'clinic@example.com',
      });

      const result = await repository.emailExists(
        'clinic@example.com',
        'clinic-1',
      );

      expect(result).toBe(true);
    });
  });

  describe('phoneExists', () => {
    it('should return true when the phone exists', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-1',
        phone: '0555123456',
      });

      const result = await repository.phoneExists('0555123456');

      expect(result).toBe(true);
    });

    it('should return false when the phone does not exist', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await repository.phoneExists('0000000000');

      expect(result).toBe(false);
    });

    it('should return false when the found clinic is the excluded clinic', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-1',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'clinic-1',
      );

      expect(result).toBe(false);
    });

    it('should return true when the found clinic is different from the excluded clinic', async () => {
      (prisma.clinic.findUnique as jest.Mock).mockResolvedValue({
        id: 'clinic-2',
        phone: '0555123456',
      });

      const result = await repository.phoneExists(
        '0555123456',
        'clinic-1',
      );

      expect(result).toBe(true);
    });
  });

  describe('updateLogo', () => {
    it('should update logo path and logo file id', async () => {
      const clinic = {
        id: 'clinic-1',
        logoPath: '/uploads/logo.png',
        logoFileId: 'file-1',
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.updateLogo(
        'clinic-1',
        '/uploads/logo.png',
        'file-1',
      );

      expect(result).toEqual(clinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          logoPath: '/uploads/logo.png',
          logoFileId: 'file-1',
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('verify', () => {
    it('should verify the clinic', async () => {
      const clinic = {
        id: 'clinic-1',
        isVerified: true,
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.verify('clinic-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          isVerified: true,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('suspend', () => {
    it('should suspend the clinic', async () => {
      const clinic = {
        id: 'clinic-1',
        isSuspended: true,
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.suspend('clinic-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          isSuspended: true,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });

  describe('unsuspend', () => {
    it('should unsuspend the clinic', async () => {
      const clinic = {
        id: 'clinic-1',
        isSuspended: false,
      };

      (prisma.clinic.update as jest.Mock).mockResolvedValue(clinic);

      const result = await repository.unsuspend('clinic-1');

      expect(result).toEqual(clinic);

      expect(prisma.clinic.update).toHaveBeenCalledWith({
        where: {
          id: 'clinic-1',
        },
        data: {
          isSuspended: false,
        },
        include: {
          wilaya: true,
          baladya: true,
        },
      });
    });
  });
});

