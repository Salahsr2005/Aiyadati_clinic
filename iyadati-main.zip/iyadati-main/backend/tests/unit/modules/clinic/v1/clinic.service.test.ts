import bcrypt from 'bcryptjs';
import { ClinicService } from '../../../../../src/modules/clinic/v1/clinic.service';
import { clinicRepository } from '../../../../../src/repositories/clinic.repository';
import { clinicDocumentRepository } from '../../../../../src/repositories/clinic-document.repository';
import { clinicGalleryRepository } from '../../../../../src/repositories/clinic-gallery.repository';
import { clinicWorkingHoursRepository } from '../../../../../src/repositories/clinic-working-hours.repository';
import { clinicRoomRepository } from '../../../../../src/repositories/clinic-room.repository';
import { clinicDoctorRepository } from '../../../../../src/repositories/clinic-doctor.repository';
import { doctorRepository } from '../../../../../src/repositories/doctor.repository';
import { fileService } from '../../../../../src/modules/file/v1/file.service';
import { eventEmitter } from '../../../../../src/core/events/event-emitter';
import {
  NotFoundError,
  ConflictError,
  BadRequestError,
  ForbiddenError,
} from '../../../../../src/core/utils/error';

// Mock all dependencies
jest.mock('../../../../../src/repositories/clinic.repository');
jest.mock('../../../../../src/repositories/clinic-document.repository');
jest.mock('../../../../../src/repositories/clinic-gallery.repository');
jest.mock('../../../../../src/repositories/clinic-working-hours.repository');
jest.mock('../../../../../src/repositories/clinic-room.repository');
jest.mock('../../../../../src/repositories/clinic-doctor.repository');
jest.mock('../../../../../src/repositories/doctor.repository');
jest.mock('../../../../../src/modules/file/v1/file.service');
jest.mock('../../../../../src/core/events/event-emitter');
jest.mock('bcryptjs');

describe('ClinicService', () => {
  let clinicService: ClinicService;

  beforeEach(() => {
    clinicService = new ClinicService();
    jest.clearAllMocks();
  });

  // ============================================================
  // Helper Mocks
  // ============================================================

  const mockClinic = {
    id: 'clinic-123',
    nameFr: 'Test Clinic',
    nameAr: 'عيادة اختبار',
    email: 'clinic@example.com',
    phone: '0555123456',
    password: 'hashed-password',
    wilayaId: 'wilaya-123',
    wilaya: { id: 'wilaya-123', code: 16, name: 'Alger' },
    baladyaId: null,
    baladya: null,
    descriptionAr: null,
    descriptionFr: null,
    latitude: null,
    longitude: null,
    logoPath: null,
    logoFileId: null,
    facilityType: 'HOSPITAL',
    isVerified: false,
    isSuspended: false,
    isCompleted: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockClinicVerified = {
    ...mockClinic,
    isVerified: true,
  };

  const mockFile: Express.Multer.File = {
    fieldname: 'logo',
    originalname: 'logo.jpg',
    encoding: '7bit',
    mimetype: 'image/jpeg',
    size: 1024 * 1024,
    destination: '/uploads',
    filename: 'logo-123.jpg',
    path: '/uploads/logo-123.jpg',
    buffer: Buffer.from('fake image data'),
    stream: null as any,
  };

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find a clinic by id', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);

      const result = await clinicService.findById('clinic-123');

      expect(clinicRepository.findById).toHaveBeenCalledWith('clinic-123');
      expect(result.id).toBe('clinic-123');
      expect(result.nameFr).toBe('Test Clinic');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(clinicService.findById('non-existent')).rejects.toThrow(
        NotFoundError
      );
    });
  });

  // ============================================================
  // findAll
  // ============================================================

  describe('findAll', () => {
    it('should return paginated clinics with default params', async () => {
      const mockClinics = [mockClinic, { ...mockClinic, id: 'clinic-456' }];
      (clinicRepository.findAll as jest.Mock).mockResolvedValue({
        clinics: mockClinics,
        total: 2,
      });

      const result = await clinicService.findAll({});

      expect(clinicRepository.findAll).toHaveBeenCalledWith({
        page: 1,
        limit: 10,
        wilayaId: undefined,
        baladyaId: undefined,
        facilityType: undefined,
        isVerified: undefined,
        isSuspended: undefined,
        isCompleted: undefined,
        search: undefined,
        sortBy: 'createdAt',
        sortOrder: 'desc',
      });
      expect(result.clinics).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should parse boolean filters correctly', async () => {
      (clinicRepository.findAll as jest.Mock).mockResolvedValue({
        clinics: [],
        total: 0,
      });

      await clinicService.findAll({
        isVerified: 'true',
        isSuspended: 'false',
        isCompleted: 'true',
      });

      expect(clinicRepository.findAll).toHaveBeenCalledWith(
        expect.objectContaining({
          isVerified: true,
          isSuspended: false,
          isCompleted: true,
        })
      );
    });

    it('should parse numeric params correctly', async () => {
      (clinicRepository.findAll as jest.Mock).mockResolvedValue({
        clinics: [],
        total: 0,
      });

      await clinicService.findAll({
        page: '2',
        limit: '20',
      });

      expect(clinicRepository.findAll).toHaveBeenCalledWith(
        expect.objectContaining({
          page: 2,
          limit: 20,
        })
      );
    });
  });

  // ============================================================
  // create
  // ============================================================

  describe('create', () => {
    const createData = {
      nameFr: 'New Clinic',
      nameAr: 'عيادة جديدة',
      email: 'newclinic@example.com',
      phone: '0665999999',
      password: 'Password123!',
      wilayaId: 'wilaya-123',
      facilityType: 'CLINIC' as const,
      descriptionFr: 'Test description',
      latitude: 36.7538,
      longitude: 3.0588,
    };

    const createdClinic = {
      ...mockClinic,
      ...createData,
      password: 'hashed-password',
      isVerified: true,
    };

    beforeEach(() => {
      (bcrypt.hash as jest.Mock).mockResolvedValue('hashed-password');
      (clinicRepository.emailExists as jest.Mock).mockResolvedValue(false);
      (clinicRepository.phoneExists as jest.Mock).mockResolvedValue(false);
      (clinicRepository.create as jest.Mock).mockResolvedValue(createdClinic);
    });

    it('should create a clinic successfully', async () => {
      const result = await clinicService.create(createData, 'admin-123', '127.0.0.1');

      expect(clinicRepository.emailExists).toHaveBeenCalledWith(createData.email);
      expect(clinicRepository.phoneExists).toHaveBeenCalledWith(createData.phone);
      expect(bcrypt.hash).toHaveBeenCalledWith(createData.password, 12);
      expect(clinicRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          nameFr: createData.nameFr,
          nameAr: createData.nameAr,
          email: createData.email,
          phone: createData.phone,
          password: 'hashed-password',
          isVerified: true,
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.created',
          entity: 'Clinic',
          entityId: createdClinic.id,
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: createdClinic.id,
          title: 'Welcome to Iyadati!',
        })
      );
      expect(result.isVerified).toBe(true);
    });

    it('should throw ConflictError when email already exists', async () => {
      (clinicRepository.emailExists as jest.Mock).mockResolvedValue(true);

      await expect(clinicService.create(createData, 'admin-123')).rejects.toThrow(
        ConflictError
      );
    });

    it('should throw ConflictError when phone already exists', async () => {
      (clinicRepository.phoneExists as jest.Mock).mockResolvedValue(true);

      await expect(clinicService.create(createData, 'admin-123')).rejects.toThrow(
        ConflictError
      );
    });
  });

  // ============================================================
  // update
  // ============================================================

  describe('update', () => {
    const updateData = {
      nameFr: 'Updated Clinic',
      descriptionFr: 'Updated description',
      phone: '0665998888',
      email: 'updated@example.com',
    };

    const updatedClinic = {
      ...mockClinic,
      ...updateData,
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicRepository.emailExists as jest.Mock).mockResolvedValue(false);
      (clinicRepository.phoneExists as jest.Mock).mockResolvedValue(false);
      (clinicRepository.update as jest.Mock).mockResolvedValue(updatedClinic);
    });

    it('should update a clinic successfully', async () => {
      const result = await clinicService.update(
        'clinic-123',
        updateData,
        'admin-123',
        '127.0.0.1'
      );

      expect(clinicRepository.findById).toHaveBeenCalledWith('clinic-123');
      expect(clinicRepository.update).toHaveBeenCalledWith(
        'clinic-123',
        expect.objectContaining({
          nameFr: 'Updated Clinic',
          descriptionFr: 'Updated description',
          phone: '0665998888',
          email: 'updated@example.com',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.updated',
          entity: 'Clinic',
          entityId: 'clinic-123',
          performedBy: 'admin-123',
        })
      );
      expect(result.nameFr).toBe('Updated Clinic');
    });

    it('should check email uniqueness when email is changed', async () => {
      await clinicService.update('clinic-123', { email: 'new@example.com' }, 'admin-123');

      expect(clinicRepository.emailExists).toHaveBeenCalledWith(
        'new@example.com',
        'clinic-123'
      );
    });

    it('should check phone uniqueness when phone is changed', async () => {
      await clinicService.update('clinic-123', { phone: '0665998888' }, 'admin-123');

      expect(clinicRepository.phoneExists).toHaveBeenCalledWith(
        '0665998888',
        'clinic-123'
      );
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.update('non-existent', {}, 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // verify
  // ============================================================

  describe('verify', () => {
    const verifiedClinic = {
      ...mockClinic,
      isVerified: true,
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicRepository.verify as jest.Mock).mockResolvedValue(verifiedClinic);
    });

    it('should verify a clinic successfully', async () => {
      const result = await clinicService.verify('clinic-123', 'admin-123', '127.0.0.1');

      expect(clinicRepository.findById).toHaveBeenCalledWith('clinic-123');
      expect(clinicRepository.verify).toHaveBeenCalledWith('clinic-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.verified',
          entity: 'Clinic',
          entityId: 'clinic-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'clinic-123',
          title: 'Clinic Verified!',
        })
      );
      expect(result.isVerified).toBe(true);
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.verify('non-existent', 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when already verified', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue({
        ...mockClinic,
        isVerified: true,
      });

      await expect(
        clinicService.verify('clinic-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // suspend / unsuspend
  // ============================================================

  describe('suspend', () => {
    const suspendedClinic = {
      ...mockClinic,
      isSuspended: true,
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicRepository.suspend as jest.Mock).mockResolvedValue(suspendedClinic);
    });

    it('should suspend a clinic with reason', async () => {
      const result = await clinicService.suspend(
        'clinic-123',
        { reason: 'Violation of terms' },
        'admin-123',
        '127.0.0.1'
      );

      expect(clinicRepository.suspend).toHaveBeenCalledWith('clinic-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.suspended',
          entity: 'Clinic',
          entityId: 'clinic-123',
          performedBy: 'admin-123',
          details: { reason: 'Violation of terms' },
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'clinic-123',
          title: 'Clinic Suspended',
          body: expect.stringContaining('Violation of terms'),
        })
      );
      expect(result.isSuspended).toBe(true);
    });

    it('should throw BadRequestError when already suspended', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue({
        ...mockClinic,
        isSuspended: true,
      });

      await expect(
        clinicService.suspend('clinic-123', { reason: 'test' }, 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('unsuspend', () => {
    const unsuspendedClinic = {
      ...mockClinic,
      isSuspended: false,
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue({
        ...mockClinic,
        isSuspended: true,
      });
      (clinicRepository.unsuspend as jest.Mock).mockResolvedValue(unsuspendedClinic);
    });

    it('should unsuspend a clinic successfully', async () => {
      const result = await clinicService.unsuspend('clinic-123', 'admin-123', '127.0.0.1');

      expect(clinicRepository.unsuspend).toHaveBeenCalledWith('clinic-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.unsuspended',
          entity: 'Clinic',
          entityId: 'clinic-123',
          performedBy: 'admin-123',
        })
      );
      expect(result.isSuspended).toBe(false);
    });

    it('should throw BadRequestError when not suspended', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);

      await expect(
        clinicService.unsuspend('clinic-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // uploadLogo
  // ============================================================

  describe('uploadLogo', () => {
    const clinicWithLogo = {
      ...mockClinic,
      logoPath: 'logo-123.jpg',
      logoFileId: 'file-123',
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicRepository.updateLogo as jest.Mock).mockResolvedValue(clinicWithLogo);
    });

    it('should upload a logo successfully', async () => {
      const result = await clinicService.uploadLogo('clinic-123', mockFile);

      expect(clinicRepository.findById).toHaveBeenCalledWith('clinic-123');
      expect(clinicRepository.updateLogo).toHaveBeenCalledWith(
        'clinic-123',
        'logo-123.jpg',
        expect.any(String)
      );
      expect(result.logoPath).toBe('logo-123.jpg');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(clinicService.uploadLogo('non-existent', mockFile)).rejects.toThrow(
        NotFoundError
      );
    });
  });

  // ============================================================
  // completeProfile
  // ============================================================

  describe('completeProfile', () => {
    const completedClinic = {
      ...mockClinicVerified,
      isCompleted: true,
      descriptionFr: 'Test description',
      logoPath: 'logo-123.jpg',
      logoFileId: 'file-123',
      latitude: 36.7538,
      longitude: 3.0588,
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinicVerified);
      (clinicRepository.update as jest.Mock).mockResolvedValue(completedClinic);
    });

    it('should complete profile without logo', async () => {
      const result = await clinicService.completeProfile(
        'clinic-123',
        { descriptionFr: 'Test description', latitude: 36.7538, longitude: 3.0588 },
        undefined
      );

      expect(clinicRepository.update).toHaveBeenCalledWith(
        'clinic-123',
        expect.objectContaining({
          isCompleted: true,
          descriptionFr: 'Test description',
          latitude: 36.7538,
          longitude: 3.0588,
        })
      );
      expect(result.isCompleted).toBe(true);
    });

    it('should complete profile with logo upload', async () => {
      const result = await clinicService.completeProfile(
        'clinic-123',
        { descriptionFr: 'Test description' },
        mockFile
      );

      expect(clinicRepository.update).toHaveBeenCalledWith(
        'clinic-123',
        expect.objectContaining({
          isCompleted: true,
          logoPath: 'logo-123.jpg',
          logoFileId: expect.any(String),
        })
      );
      expect(result.logoPath).toBe('logo-123.jpg');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.completeProfile('non-existent', {})
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when clinic is not verified', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);

      await expect(
        clinicService.completeProfile('clinic-123', {})
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when already completed', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue({
        ...mockClinicVerified,
        isCompleted: true,
      });

      await expect(
        clinicService.completeProfile('clinic-123', {})
      ).rejects.toThrow(BadRequestError);
    });

    it('should parse latitude and longitude from strings', async () => {
      await clinicService.completeProfile(
        'clinic-123',
        {
          latitude: '36.7538' as any,
          longitude: '3.0588' as any,
        },
        undefined
      );

      expect(clinicRepository.update).toHaveBeenCalledWith(
        'clinic-123',
        expect.objectContaining({
          latitude: 36.7538,
          longitude: 3.0588,
        })
      );
    });
  });

  // ============================================================
  // getDocuments / uploadDocument / deleteDocument
  // ============================================================

  describe('getDocuments', () => {
    const mockDocs = [
      {
        id: 'doc-1',
        clinicId: 'clinic-123',
        fileName: 'document.pdf',
        fileType: 'application/pdf',
        fileSize: 1024,
        fileId: 'file-1',
        createdAt: new Date(),
      },
    ];

    beforeEach(() => {
      (clinicDocumentRepository.findByClinicId as jest.Mock).mockResolvedValue(
        mockDocs
      );
    });

    it('should return documents with signed URLs', async () => {
      const result = await clinicService.getDocuments('clinic-123');

      expect(clinicDocumentRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123'
      );
      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        id: 'doc-1',
        fileName: 'document.pdf',
      });
      expect(result[0]).toHaveProperty('accessUrl');
    });
  });

  describe('uploadDocument', () => {
    const mockDoc = {
      id: 'doc-1',
      clinicId: 'clinic-123',
      fileName: 'document.pdf',
      fileType: 'application/pdf',
      fileSize: 1024,
      fileId: 'file-1',
      createdAt: new Date(),
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicDocumentRepository.create as jest.Mock).mockResolvedValue(mockDoc);
    });

    it('should upload a document successfully', async () => {
      const result = await clinicService.uploadDocument(
        'clinic-123',
        mockFile,
        'admin-123'
      );

      expect(clinicDocumentRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          clinicId: 'clinic-123',
          fileName: 'logo.jpg',
          fileType: 'image/jpeg',
          uploadedBy: 'admin-123',
        })
      );
      expect(result.fileName).toBe('document.pdf');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.uploadDocument('non-existent', mockFile, 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // Working Hours
  // ============================================================

  describe('setWorkingHours', () => {
    const hoursData = [
      {
        dayOfWeek: 'SUNDAY' as const,
        openTime: '08:00',
        closeTime: '17:00',
        isOpen: true,
      },
    ];

    const mockHours = [
      {
        id: 'hours-1',
        clinicId: 'clinic-123',
        dayOfWeek: 'SUNDAY',
        openTime: new Date('1970-01-01T08:00:00.000Z'),
        closeTime: new Date('1970-01-01T17:00:00.000Z'),
        isOpen: true,
      },
    ];

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (
        clinicWorkingHoursRepository.upsert as jest.Mock
      ).mockResolvedValue(mockHours[0]);
    });

    it('should set working hours successfully', async () => {
      const result = await clinicService.setWorkingHours('clinic-123', hoursData);

      expect(clinicWorkingHoursRepository.upsert).toHaveBeenCalledWith(
        'clinic-123',
        'SUNDAY',
        expect.objectContaining({
          openTime: expect.any(Date),
          closeTime: expect.any(Date),
          isOpen: true,
        })
      );
      expect(result).toHaveLength(1);
      expect(result[0].openTime).toBe('08:00');
      expect(result[0].closeTime).toBe('17:00');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.setWorkingHours('non-existent', hoursData)
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('getWorkingHours', () => {
    const mockHours = [
      {
        id: 'hours-1',
        clinicId: 'clinic-123',
        dayOfWeek: 'SUNDAY',
        openTime: new Date('1970-01-01T08:00:00.000Z'),
        closeTime: new Date('1970-01-01T17:00:00.000Z'),
        isOpen: true,
      },
    ];

    beforeEach(() => {
      (
        clinicWorkingHoursRepository.findByClinicId as jest.Mock
      ).mockResolvedValue(mockHours);
    });

    it('should get working hours', async () => {
      const result = await clinicService.getWorkingHours('clinic-123');

      expect(clinicWorkingHoursRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123'
      );
      expect(result).toHaveLength(1);
      expect(result[0].openTime).toBe('08:00');
    });
  });

  // ============================================================
  // Rooms
  // ============================================================

  describe('createRoom', () => {
    const roomData = {
      name: 'Consultation Room 1',
      specialtyId: 'specialty-123',
    };

    const mockRoom = {
      id: 'room-1',
      clinicId: 'clinic-123',
      name: 'Consultation Room 1',
      specialtyId: 'specialty-123',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicRoomRepository.create as jest.Mock).mockResolvedValue(mockRoom);
    });

    it('should create a room successfully', async () => {
      const result = await clinicService.createRoom('clinic-123', roomData);

      expect(clinicRoomRepository.create).toHaveBeenCalledWith({
        clinicId: 'clinic-123',
        name: 'Consultation Room 1',
        specialtyId: 'specialty-123',
      });
      expect(result.name).toBe('Consultation Room 1');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.createRoom('non-existent', roomData)
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('getRooms', () => {
    const mockRooms = [
      {
        id: 'room-1',
        clinicId: 'clinic-123',
        name: 'Room 1',
        specialtyId: null,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    beforeEach(() => {
      (clinicRoomRepository.findByClinicId as jest.Mock).mockResolvedValue(
        mockRooms
      );
    });

    it('should get rooms', async () => {
      const result = await clinicService.getRooms('clinic-123');

      expect(clinicRoomRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123'
      );
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('Room 1');
    });
  });

  describe('updateRoom', () => {
    const existingRoom = {
      id: 'room-1',
      clinicId: 'clinic-123',
      name: 'Old Room',
      specialtyId: null,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const updatedRoom = {
      ...existingRoom,
      name: 'Updated Room',
    };

    beforeEach(() => {
      (clinicRoomRepository.findById as jest.Mock).mockResolvedValue(existingRoom);
      (clinicRoomRepository.update as jest.Mock).mockResolvedValue(updatedRoom);
    });

    it('should update a room successfully', async () => {
      const result = await clinicService.updateRoom('room-1', {
        name: 'Updated Room',
      });

      expect(clinicRoomRepository.update).toHaveBeenCalledWith('room-1', {
        name: 'Updated Room',
      });
      expect(result.name).toBe('Updated Room');
    });

    it('should throw NotFoundError when room does not exist', async () => {
      (clinicRoomRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.updateRoom('non-existent', { name: 'New Name' })
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('deleteRoom', () => {
    const existingRoom = {
      id: 'room-1',
      clinicId: 'clinic-123',
      name: 'Room 1',
      specialtyId: null,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    beforeEach(() => {
      (clinicRoomRepository.findById as jest.Mock).mockResolvedValue(existingRoom);
      (clinicRoomRepository.softDelete as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete a room successfully', async () => {
      await clinicService.deleteRoom('room-1');

      expect(clinicRoomRepository.softDelete).toHaveBeenCalledWith('room-1');
    });

    it('should throw NotFoundError when room does not exist', async () => {
      (clinicRoomRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(clinicService.deleteRoom('non-existent')).rejects.toThrow(
        NotFoundError
      );
    });
  });

  // ============================================================
  // Gallery
  // ============================================================

  describe('getGallery', () => {
    const mockImages = [
      {
        id: 'img-1',
        clinicId: 'clinic-123',
        imagePath: 'gallery/img1.jpg',
        fileId: 'file-1',
        captionFr: 'Caption FR',
        captionAr: 'Caption AR',
        sortOrder: 0,
        isActive: true,
        createdAt: new Date(),
      },
    ];

    beforeEach(() => {
      (clinicGalleryRepository.findByClinicId as jest.Mock).mockResolvedValue(
        mockImages
      );
    });

    it('should get gallery images', async () => {
      const result = await clinicService.getGallery('clinic-123');

      expect(clinicGalleryRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123'
      );
      expect(result).toHaveLength(1);
      expect(result[0].captionFr).toBe('Caption FR');
      expect(result[0]).toHaveProperty('imageUrl');
    });
  });

  describe('uploadGalleryImage', () => {
    const mockImage = {
      id: 'img-1',
      clinicId: 'clinic-123',
      imagePath: 'public/gallery/img1.jpg',
      fileId: 'file-1',
      captionFr: 'Test',
      captionAr: 'اختبار',
      sortOrder: 0,
      isActive: true,
      createdAt: new Date(),
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicGalleryRepository.getMaxSortOrder as jest.Mock).mockResolvedValue(0);
      (clinicGalleryRepository.create as jest.Mock).mockResolvedValue(mockImage);
    });

    it('should upload a gallery image successfully', async () => {
      const result = await clinicService.uploadGalleryImage(
        'clinic-123',
        mockFile,
        'Test',
        'اختبار'
      );

      expect(clinicGalleryRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          clinicId: 'clinic-123',
          fileName: 'logo.jpg',
          captionFr: 'Test',
          captionAr: 'اختبار',
          sortOrder: 1,
        })
      );
      expect(result.captionFr).toBe('Test');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.uploadGalleryImage('non-existent', mockFile)
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('updateGalleryImage', () => {
    const existingImage = {
      id: 'img-1',
      clinicId: 'clinic-123',
      imagePath: 'gallery/img1.jpg',
      fileId: 'file-1',
      captionFr: 'Old',
      captionAr: 'قديم',
      sortOrder: 0,
      isActive: true,
      createdAt: new Date(),
    };

    const updatedImage = {
      ...existingImage,
      captionFr: 'New',
    };

    beforeEach(() => {
      (clinicGalleryRepository.findById as jest.Mock).mockResolvedValue(
        existingImage
      );
      (clinicGalleryRepository.update as jest.Mock).mockResolvedValue(updatedImage);
    });

    it('should update a gallery image successfully', async () => {
      const result = await clinicService.updateGalleryImage('img-1', {
        captionFr: 'New',
      });

      expect(clinicGalleryRepository.update).toHaveBeenCalledWith('img-1', {
        captionFr: 'New',
      });
      expect(result.captionFr).toBe('New');
    });

    it('should throw NotFoundError when image does not exist', async () => {
      (clinicGalleryRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.updateGalleryImage('non-existent', {})
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // Doctor Management
  // ============================================================

  describe('inviteDoctor', () => {
    const mockLink = {
      id: 'link-1',
      clinicId: 'clinic-123',
      doctorId: 'doctor-123',
      status: 'PENDING',
      invitedBy: 'clinic',
      isActive: true,
      joinedAt: new Date(),
    };

    beforeEach(() => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (doctorRepository.findById as jest.Mock).mockResolvedValue({ id: 'doctor-123' });
      (
        clinicDoctorRepository.findByClinicAndDoctor as jest.Mock
      ).mockResolvedValue(null);
      (clinicDoctorRepository.create as jest.Mock).mockResolvedValue(mockLink);
    });

    it('should invite a doctor successfully', async () => {
      const result = await clinicService.inviteDoctor(
        'clinic-123',
        'doctor-123',
        'admin-123'
      );

      expect(clinicDoctorRepository.create).toHaveBeenCalledWith({
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        invitedBy: 'clinic',
      });
      expect(result.status).toBe('PENDING');
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.inviteDoctor('non-existent', 'doctor-123', 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.inviteDoctor('clinic-123', 'doctor-123', 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when invitation already pending', async () => {
      (
        clinicDoctorRepository.findByClinicAndDoctor as jest.Mock
      ).mockResolvedValue({ status: 'PENDING' });

      await expect(
        clinicService.inviteDoctor('clinic-123', 'doctor-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when doctor already in clinic', async () => {
      (
        clinicDoctorRepository.findByClinicAndDoctor as jest.Mock
      ).mockResolvedValue({ status: 'ACCEPTED', isActive: true });

      await expect(
        clinicService.inviteDoctor('clinic-123', 'doctor-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('getClinicDoctors', () => {
    const mockLinks = [
      {
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        invitedBy: 'clinic',
        isActive: true,
        joinedAt: new Date(),
        doctor: {
          id: 'doctor-123',
          email: 'doctor@example.com',
          firstNameFr: 'Ahmed',
          firstNameAr: 'أحمد',
          lastNameFr: 'Benali',
          lastNameAr: 'بن علي',
          phone: '0665123456',
          photoPath: null,
          specialties: [],
          yearsOfExp: 10,
        },
      },
    ];

    beforeEach(() => {
      (clinicDoctorRepository.findByClinicId as jest.Mock).mockResolvedValue(
        mockLinks
      );
    });

    it('should get clinic doctors', async () => {
      const result = await clinicService.getClinicDoctors('clinic-123');

      expect(clinicDoctorRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123'
      );
      expect(result).toHaveLength(1);
      expect(result[0].doctor).toBeDefined();
      expect(result[0].doctor?.firstNameFr).toBe('Ahmed');
    });
  });

  describe('respondToDoctorRequest', () => {
    const mockLink = {
      id: 'link-1',
      clinicId: 'clinic-123',
      doctorId: 'doctor-123',
      status: 'PENDING',
      invitedBy: 'doctor',
      isActive: true,
      joinedAt: new Date(),
    };

    const acceptedLink = {
      ...mockLink,
      status: 'ACCEPTED',
    };

    beforeEach(() => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(mockLink);
      (clinicDoctorRepository.updateStatus as jest.Mock).mockResolvedValue(
        acceptedLink
      );
    });

    it('should accept a doctor request', async () => {
      const result = await clinicService.respondToDoctorRequest('link-1', 'ACCEPTED');

      expect(clinicDoctorRepository.updateStatus).toHaveBeenCalledWith(
        'link-1',
        'ACCEPTED'
      );
      expect(result.status).toBe('ACCEPTED');
    });

    it('should reject a doctor request', async () => {
      const rejectedLink = {
        ...mockLink,
        status: 'REJECTED',
      };
      (clinicDoctorRepository.updateStatus as jest.Mock).mockResolvedValue(
        rejectedLink
      );

      const result = await clinicService.respondToDoctorRequest('link-1', 'REJECTED');

      expect(result.status).toBe('REJECTED');
    });

    it('should throw NotFoundError when link does not exist', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.respondToDoctorRequest('non-existent', 'ACCEPTED')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when not pending', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockLink,
        status: 'ACCEPTED',
      });

      await expect(
        clinicService.respondToDoctorRequest('link-1', 'ACCEPTED')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when not from doctor', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockLink,
        invitedBy: 'clinic',
      });

      await expect(
        clinicService.respondToDoctorRequest('link-1', 'ACCEPTED')
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('removeDoctorFromClinic', () => {
    const mockLink = {
      id: 'link-1',
      clinicId: 'clinic-123',
      doctorId: 'doctor-123',
      status: 'ACCEPTED',
      invitedBy: 'clinic',
      isActive: true,
      joinedAt: new Date(),
    };

    beforeEach(() => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(mockLink);
      (clinicDoctorRepository.remove as jest.Mock).mockResolvedValue(undefined);
    });

    it('should remove a doctor from clinic', async () => {
      await clinicService.removeDoctorFromClinic('clinic-123', 'link-1');

      expect(clinicDoctorRepository.remove).toHaveBeenCalledWith('link-1');
    });

    it('should throw NotFoundError when link does not exist', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.removeDoctorFromClinic('clinic-123', 'non-existent')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when link does not belong to clinic', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockLink,
        clinicId: 'other-clinic',
      });

      await expect(
        clinicService.removeDoctorFromClinic('clinic-123', 'link-1')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // Delete Document (Staff)
  // ============================================================

  describe('deleteDocument', () => {
    const mockDoc = {
      id: 'doc-1',
      clinicId: 'clinic-123',
      fileName: 'document.pdf',
      fileId: 'file-1',
    };

    beforeEach(() => {
      (clinicDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDoc);
      (fileService.deleteFile as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete a document successfully', async () => {
      await clinicService.deleteDocument(
        'clinic-123',
        'doc-1',
        'admin-123',
        '127.0.0.1'
      );

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-1',
        'admin-123',
        'ADMIN',
        false
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'clinic.document_deleted_by_staff',
          entity: 'Clinic',
          entityId: 'clinic-123',
          performedBy: 'admin-123',
        })
      );
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (clinicDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.deleteDocument('clinic-123', 'non-existent', 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when document does not belong to clinic', async () => {
      (clinicDocumentRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoc,
        clinicId: 'other-clinic',
      });

      await expect(
        clinicService.deleteDocument('clinic-123', 'doc-1', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // Delete My Document (Self)
  // ============================================================

  describe('deleteMyDocument', () => {
    const mockDoc = {
      id: 'doc-1',
      clinicId: 'clinic-123',
      fileName: 'document.pdf',
      fileId: 'file-1',
    };

    beforeEach(() => {
      (clinicDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDoc);
      (fileService.deleteFile as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete a document as clinic self', async () => {
      await clinicService.deleteMyDocument('clinic-123', 'doc-1');

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-1',
        'clinic-123',
        'CLINIC',
        false
      );
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (clinicDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        clinicService.deleteMyDocument('clinic-123', 'non-existent')
      ).rejects.toThrow(NotFoundError);
    });
  });
});

