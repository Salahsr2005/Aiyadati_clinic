import { Request, Response, NextFunction } from 'express';
import { ClinicController } from '../../../../../src/modules/clinic/v1/clinic.controller';
import { clinicService } from '../../../../../src/modules/clinic/v1/clinic.service';
import { ResponseUtil } from '../../../../../src/core/utils/response';

// Mock the clinic service
jest.mock('../../../../../src/modules/clinic/v1/clinic.service', () => ({
  clinicService: {
    findAll: jest.fn(),
    create: jest.fn(),
    findById: jest.fn(),
    update: jest.fn(),
    verify: jest.fn(),
    suspend: jest.fn(),
    unsuspend: jest.fn(),
    uploadLogo: jest.fn(),
    getDocuments: jest.fn(),
    uploadDocument: jest.fn(),
    deleteDocument: jest.fn(),
    completeProfile: jest.fn(),
    setWorkingHours: jest.fn(),
    getWorkingHours: jest.fn(),
    createRoom: jest.fn(),
    getRooms: jest.fn(),
    updateRoom: jest.fn(),
    deleteRoom: jest.fn(),
    inviteDoctor: jest.fn(),
    getClinicDoctors: jest.fn(),
    respondToDoctorRequest: jest.fn(),
    removeDoctorFromClinic: jest.fn(),
    getGallery: jest.fn(),
    uploadGalleryImage: jest.fn(),
    updateGalleryImage: jest.fn(),
    deleteGalleryImage: jest.fn(),
    deleteMyDocument: jest.fn(),
  },
}));

// Mock ResponseUtil
jest.mock('../../../../../src/core/utils/response', () => ({
  ResponseUtil: {
    paginated: jest.fn(),
    success: jest.fn(),
    created: jest.fn(),
    badRequest: jest.fn(),
    unauthorized: jest.fn(),
  },
}));

describe('ClinicController', () => {
  let controller: ClinicController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    controller = new ClinicController();
    req = {
      params: {},
      query: {},
      body: {},
      user: { id: 'user-123', role: 'ADMIN' } as any,
      ip: '127.0.0.1',
      file: undefined,
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  // Helper to create request with ip
  const createRequestWithIp = (ip: string): Partial<Request> => ({
    ...req,
    get ip() { return ip; },
  });

  // ============================================================
  // Staff Routes
  // ============================================================

  describe('findAll', () => {
    it('should return paginated clinics', async () => {
      const mockResult = {
        clinics: [{ id: 'clinic-1' }, { id: 'clinic-2' }],
        total: 2,
      };
      (clinicService.findAll as jest.Mock).mockResolvedValue(mockResult);

      req.query = { page: '2', limit: '5' };

      await controller.findAll(req as Request, res as Response, next);

      expect(clinicService.findAll).toHaveBeenCalledWith(req.query);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.clinics,
        mockResult.total,
        2,
        5,
        'Clinics retrieved successfully'
      );
      expect(next).not.toHaveBeenCalled();
    });

    it('should use default pagination values', async () => {
      const mockResult = { clinics: [], total: 0 };
      (clinicService.findAll as jest.Mock).mockResolvedValue(mockResult);

      req.query = {};

      await controller.findAll(req as Request, res as Response, next);

      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        10,
        'Clinics retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Service error');
      (clinicService.findAll as jest.Mock).mockRejectedValue(error);

      await controller.findAll(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('create', () => {
    it('should create a clinic', async () => {
      const mockClinic = { id: 'clinic-123', nameFr: 'New Clinic' };
      (clinicService.create as jest.Mock).mockResolvedValue(mockClinic);

      req.body = { nameFr: 'New Clinic', email: 'clinic@example.com' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.create(reqWithIp as Request, res as Response, next);

      expect(clinicService.create).toHaveBeenCalledWith(
        req.body,
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic created successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Creation failed');
      (clinicService.create as jest.Mock).mockRejectedValue(error);

      await controller.create(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('findById', () => {
    it('should return a clinic by id', async () => {
      const mockClinic = { id: 'clinic-123', nameFr: 'Test Clinic' };
      (clinicService.findById as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };

      await controller.findById(req as Request, res as Response, next);

      expect(clinicService.findById).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Clinic not found');
      (clinicService.findById as jest.Mock).mockRejectedValue(error);

      req.params = { id: 'non-existent' };

      await controller.findById(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('update', () => {
    it('should update a clinic', async () => {
      const mockClinic = { id: 'clinic-123', nameFr: 'Updated' };
      (clinicService.update as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };
      req.body = { nameFr: 'Updated' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.update(reqWithIp as Request, res as Response, next);

      expect(clinicService.update).toHaveBeenCalledWith(
        'clinic-123',
        req.body,
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic updated successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Update failed');
      (clinicService.update as jest.Mock).mockRejectedValue(error);

      await controller.update(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('verify', () => {
    it('should verify a clinic', async () => {
      const mockClinic = { id: 'clinic-123', isVerified: true };
      (clinicService.verify as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.verify(reqWithIp as Request, res as Response, next);

      expect(clinicService.verify).toHaveBeenCalledWith(
        'clinic-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic verified successfully'
      );
    });
  });

  describe('suspend', () => {
    it('should suspend a clinic', async () => {
      const mockClinic = { id: 'clinic-123', isSuspended: true };
      (clinicService.suspend as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };
      req.body = { reason: 'Violation' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.suspend(reqWithIp as Request, res as Response, next);

      expect(clinicService.suspend).toHaveBeenCalledWith(
        'clinic-123',
        { reason: 'Violation' },
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic suspended successfully'
      );
    });
  });

  describe('unsuspend', () => {
    it('should unsuspend a clinic', async () => {
      const mockClinic = { id: 'clinic-123', isSuspended: false };
      (clinicService.unsuspend as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.unsuspend(reqWithIp as Request, res as Response, next);

      expect(clinicService.unsuspend).toHaveBeenCalledWith(
        'clinic-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic unsuspended successfully'
      );
    });
  });

  describe('uploadLogo', () => {
    it('should upload a logo', async () => {
      const mockClinic = { id: 'clinic-123', logoPath: 'logo.jpg' };
      (clinicService.uploadLogo as jest.Mock).mockResolvedValue(mockClinic);

      req.params = { id: 'clinic-123' };
      req.file = { originalname: 'logo.jpg' } as any;

      await controller.uploadLogo(req as Request, res as Response, next);

      expect(clinicService.uploadLogo).toHaveBeenCalledWith(
        'clinic-123',
        req.file
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Logo uploaded successfully'
      );
    });

    it('should return 400 without file', async () => {
      req.params = { id: 'clinic-123' };
      req.file = undefined;

      await controller.uploadLogo(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Logo file is required'
      );
      expect(clinicService.uploadLogo).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // Document Endpoints (Staff)
  // ============================================================

  describe('getDocuments', () => {
    it('should get clinic documents', async () => {
      const mockDocs = [{ id: 'doc-1', fileName: 'document.pdf' }];
      (clinicService.getDocuments as jest.Mock).mockResolvedValue(mockDocs);

      req.params = { id: 'clinic-123' };

      await controller.getDocuments(req as Request, res as Response, next);

      expect(clinicService.getDocuments).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDocs,
        'Documents retrieved successfully'
      );
    });
  });

  describe('uploadDocument', () => {
    it('should upload a document (staff)', async () => {
      const mockDoc = { id: 'doc-1', fileName: 'document.pdf' };
      (clinicService.uploadDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.params = { id: 'clinic-123' };
      req.file = { originalname: 'document.pdf' } as any;
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      await controller.uploadDocument(req as Request, res as Response, next);

      expect(clinicService.uploadDocument).toHaveBeenCalledWith(
        'clinic-123',
        req.file,
        'admin-123'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document uploaded successfully'
      );
    });

    it('should return 400 without file', async () => {
      req.params = { id: 'clinic-123' };
      req.file = undefined;

      await controller.uploadDocument(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Document file is required'
      );
    });
  });

  describe('deleteDocument', () => {
    it('should delete a document (staff)', async () => {
      (clinicService.deleteDocument as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'clinic-123', documentId: 'doc-1' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.deleteDocument(reqWithIp as Request, res as Response, next);

      expect(clinicService.deleteDocument).toHaveBeenCalledWith(
        'clinic-123',
        'doc-1',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Document deleted successfully'
      );
    });
  });

  // ============================================================
  // Self-Service Routes
  // ============================================================

  describe('getMyProfile', () => {
    it('should get clinic own profile', async () => {
      const mockClinic = { id: 'clinic-123', nameFr: 'My Clinic' };
      (clinicService.findById as jest.Mock).mockResolvedValue(mockClinic);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyProfile(req as Request, res as Response, next);

      expect(clinicService.findById).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Clinic profile retrieved successfully'
      );
    });
  });

  describe('completeMyProfile', () => {
    it('should complete profile without file', async () => {
      const mockClinic = { id: 'clinic-123', isCompleted: true };
      (clinicService.completeProfile as jest.Mock).mockResolvedValue(mockClinic);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.body = { descriptionFr: 'Test description' };
      req.file = undefined;

      await controller.completeMyProfile(req as Request, res as Response, next);

      expect(clinicService.completeProfile).toHaveBeenCalledWith(
        'clinic-123',
        { descriptionFr: 'Test description' },
        undefined
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Profile completed successfully'
      );
    });

    it('should complete profile with file', async () => {
      const mockClinic = { id: 'clinic-123', isCompleted: true };
      (clinicService.completeProfile as jest.Mock).mockResolvedValue(mockClinic);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.body = { descriptionFr: 'Test description' };
      req.file = { originalname: 'logo.jpg' } as any;

      await controller.completeMyProfile(req as Request, res as Response, next);

      expect(clinicService.completeProfile).toHaveBeenCalledWith(
        'clinic-123',
        { descriptionFr: 'Test description' },
        req.file
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockClinic,
        'Profile completed successfully'
      );
    });
  });

  describe('uploadMyDocument', () => {
    it('should upload document as clinic', async () => {
      const mockDoc = { id: 'doc-1', fileName: 'document.pdf' };
      (clinicService.uploadDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.file = { originalname: 'document.pdf' } as any;

      await controller.uploadMyDocument(req as Request, res as Response, next);

      expect(clinicService.uploadDocument).toHaveBeenCalledWith(
        'clinic-123',
        req.file,
        'clinic-123'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document uploaded successfully'
      );
    });

    it('should return 400 without file', async () => {
      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.file = undefined;

      await controller.uploadMyDocument(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Document file is required'
      );
    });
  });

  describe('getMyDocuments', () => {
    it('should get own documents', async () => {
      const mockDocs = [{ id: 'doc-1', fileName: 'document.pdf' }];
      (clinicService.getDocuments as jest.Mock).mockResolvedValue(mockDocs);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyDocuments(req as Request, res as Response, next);

      expect(clinicService.getDocuments).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDocs,
        'Documents retrieved successfully'
      );
    });
  });

  describe('deleteMyDocument', () => {
    it('should delete own document', async () => {
      (clinicService.deleteMyDocument as jest.Mock).mockResolvedValue(undefined);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.params = { id: 'doc-1' };

      await controller.deleteMyDocument(req as Request, res as Response, next);

      expect(clinicService.deleteMyDocument).toHaveBeenCalledWith(
        'clinic-123',
        'doc-1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Document deleted successfully'
      );
    });
  });

  // ============================================================
  // Working Hours
  // ============================================================

  describe('getWorkingHours', () => {
    it('should get working hours (staff)', async () => {
      const mockHours = [{ id: 'hours-1', dayOfWeek: 'MONDAY' }];
      (clinicService.getWorkingHours as jest.Mock).mockResolvedValue(mockHours);

      req.params = { id: 'clinic-123' };

      await controller.getWorkingHours(req as Request, res as Response, next);

      expect(clinicService.getWorkingHours).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockHours,
        'Working hours retrieved successfully'
      );
    });
  });

  describe('setWorkingHours', () => {
    it('should set working hours (staff)', async () => {
      const mockHours = [{ id: 'hours-1', dayOfWeek: 'MONDAY' }];
      (clinicService.setWorkingHours as jest.Mock).mockResolvedValue(mockHours);

      req.params = { id: 'clinic-123' };
      req.body = { hours: [{ dayOfWeek: 'MONDAY', openTime: '09:00', closeTime: '17:00' }] };

      await controller.setWorkingHours(req as Request, res as Response, next);

      expect(clinicService.setWorkingHours).toHaveBeenCalledWith(
        'clinic-123',
        req.body.hours
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockHours,
        'Working hours updated successfully'
      );
    });
  });

  describe('getMyWorkingHours', () => {
    it('should get own working hours', async () => {
      const mockHours = [{ id: 'hours-1', dayOfWeek: 'MONDAY' }];
      (clinicService.getWorkingHours as jest.Mock).mockResolvedValue(mockHours);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyWorkingHours(req as Request, res as Response, next);

      expect(clinicService.getWorkingHours).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockHours,
        'Working hours retrieved successfully'
      );
    });
  });

  describe('setMyWorkingHours', () => {
    it('should set own working hours', async () => {
      const mockHours = [{ id: 'hours-1', dayOfWeek: 'MONDAY' }];
      (clinicService.setWorkingHours as jest.Mock).mockResolvedValue(mockHours);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.body = { hours: [{ dayOfWeek: 'MONDAY', openTime: '09:00', closeTime: '17:00' }] };

      await controller.setMyWorkingHours(req as Request, res as Response, next);

      expect(clinicService.setWorkingHours).toHaveBeenCalledWith(
        'clinic-123',
        req.body.hours
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockHours,
        'Working hours updated successfully'
      );
    });
  });

  // ============================================================
  // Rooms
  // ============================================================

  describe('createRoom', () => {
    it('should create a room (staff)', async () => {
      const mockRoom = { id: 'room-1', name: 'Room 1' };
      (clinicService.createRoom as jest.Mock).mockResolvedValue(mockRoom);

      req.params = { id: 'clinic-123' };
      req.body = { name: 'Room 1' };

      await controller.createRoom(req as Request, res as Response, next);

      expect(clinicService.createRoom).toHaveBeenCalledWith('clinic-123', req.body);
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockRoom,
        'Room created successfully'
      );
    });
  });

  describe('getRooms', () => {
    it('should get rooms (staff)', async () => {
      const mockRooms = [{ id: 'room-1', name: 'Room 1' }];
      (clinicService.getRooms as jest.Mock).mockResolvedValue(mockRooms);

      req.params = { id: 'clinic-123' };

      await controller.getRooms(req as Request, res as Response, next);

      expect(clinicService.getRooms).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockRooms,
        'Rooms retrieved successfully'
      );
    });
  });

  describe('updateRoom', () => {
    it('should update a room', async () => {
      const mockRoom = { id: 'room-1', name: 'Updated Room' };
      (clinicService.updateRoom as jest.Mock).mockResolvedValue(mockRoom);

      req.params = { roomId: 'room-1' };
      req.body = { name: 'Updated Room' };

      await controller.updateRoom(req as Request, res as Response, next);

      expect(clinicService.updateRoom).toHaveBeenCalledWith('room-1', req.body);
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockRoom,
        'Room updated successfully'
      );
    });
  });

  describe('deleteRoom', () => {
    it('should delete a room', async () => {
      (clinicService.deleteRoom as jest.Mock).mockResolvedValue(undefined);

      req.params = { roomId: 'room-1' };

      await controller.deleteRoom(req as Request, res as Response, next);

      expect(clinicService.deleteRoom).toHaveBeenCalledWith('room-1');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Room deleted successfully'
      );
    });
  });

  describe('getMyRooms', () => {
    it('should get own rooms', async () => {
      const mockRooms = [{ id: 'room-1', name: 'Room 1' }];
      (clinicService.getRooms as jest.Mock).mockResolvedValue(mockRooms);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyRooms(req as Request, res as Response, next);

      expect(clinicService.getRooms).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockRooms,
        'Rooms retrieved successfully'
      );
    });
  });

  describe('createMyRoom', () => {
    it('should create own room', async () => {
      const mockRoom = { id: 'room-1', name: 'Room 1' };
      (clinicService.createRoom as jest.Mock).mockResolvedValue(mockRoom);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.body = { name: 'Room 1' };

      await controller.createMyRoom(req as Request, res as Response, next);

      expect(clinicService.createRoom).toHaveBeenCalledWith('clinic-123', req.body);
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockRoom,
        'Room created successfully'
      );
    });
  });

  // ============================================================
  // Doctor Management
  // ============================================================

  describe('inviteDoctor', () => {
    it('should invite a doctor', async () => {
      const mockResult = { id: 'link-1', status: 'PENDING' };
      (clinicService.inviteDoctor as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.body = { doctorId: 'doctor-123' };

      await controller.inviteDoctor(req as Request, res as Response, next);

      expect(clinicService.inviteDoctor).toHaveBeenCalledWith(
        'clinic-123',
        'doctor-123',
        'clinic-123'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockResult,
        'Doctor invited successfully'
      );
    });
  });

  describe('getMyClinicDoctors', () => {
    it('should get clinic doctors', async () => {
      const mockDoctors = [{ id: 'link-1', doctorId: 'doctor-123' }];
      (clinicService.getClinicDoctors as jest.Mock).mockResolvedValue(mockDoctors);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyClinicDoctors(req as Request, res as Response, next);

      expect(clinicService.getClinicDoctors).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctors,
        'Clinic doctors retrieved successfully'
      );
    });
  });

  describe('respondToDoctorRequest', () => {
    it('should accept a doctor request', async () => {
      const mockResult = { id: 'link-1', status: 'ACCEPTED' };
      (clinicService.respondToDoctorRequest as jest.Mock).mockResolvedValue(mockResult);

      req.params = { id: 'link-1', action: 'accept' };

      await controller.respondToDoctorRequest(req as Request, res as Response, next);

      expect(clinicService.respondToDoctorRequest).toHaveBeenCalledWith(
        'link-1',
        'ACCEPTED'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockResult,
        'Doctor request accepted'
      );
    });

    it('should reject a doctor request', async () => {
      const mockResult = { id: 'link-1', status: 'REJECTED' };
      (clinicService.respondToDoctorRequest as jest.Mock).mockResolvedValue(mockResult);

      req.params = { id: 'link-1', action: 'reject' };

      await controller.respondToDoctorRequest(req as Request, res as Response, next);

      expect(clinicService.respondToDoctorRequest).toHaveBeenCalledWith(
        'link-1',
        'REJECTED'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockResult,
        'Doctor request rejected'
      );
    });
  });

  describe('removeDoctor', () => {
    it('should remove a doctor from clinic', async () => {
      (clinicService.removeDoctorFromClinic as jest.Mock).mockResolvedValue(undefined);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.params = { id: 'link-1' };

      await controller.removeDoctor(req as Request, res as Response, next);

      expect(clinicService.removeDoctorFromClinic).toHaveBeenCalledWith(
        'clinic-123',
        'link-1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Doctor removed from clinic'
      );
    });
  });

  describe('getClinicDoctors', () => {
    it('should get clinic doctors (staff)', async () => {
      const mockDoctors = [{ id: 'link-1', doctorId: 'doctor-123' }];
      (clinicService.getClinicDoctors as jest.Mock).mockResolvedValue(mockDoctors);

      req.params = { id: 'clinic-123' };

      await controller.getClinicDoctors(req as Request, res as Response, next);

      expect(clinicService.getClinicDoctors).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctors,
        'Clinic doctors retrieved successfully'
      );
    });
  });

  // ============================================================
  // Gallery
  // ============================================================

  describe('getGallery', () => {
    it('should get gallery (staff)', async () => {
      const mockImages = [{ id: 'img-1', imageUrl: 'image.jpg' }];
      (clinicService.getGallery as jest.Mock).mockResolvedValue(mockImages);

      req.params = { id: 'clinic-123' };

      await controller.getGallery(req as Request, res as Response, next);

      expect(clinicService.getGallery).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockImages,
        'Gallery retrieved successfully'
      );
    });
  });

  describe('uploadGalleryImage', () => {
    it('should upload a gallery image (staff)', async () => {
      const mockImage = { id: 'img-1', imageUrl: 'image.jpg' };
      (clinicService.uploadGalleryImage as jest.Mock).mockResolvedValue(mockImage);

      req.params = { id: 'clinic-123' };
      req.file = { originalname: 'image.jpg' } as any;
      req.body = { captionFr: 'Test caption' };

      await controller.uploadGalleryImage(req as Request, res as Response, next);

      expect(clinicService.uploadGalleryImage).toHaveBeenCalledWith(
        'clinic-123',
        req.file,
        'Test caption',
        undefined
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockImage,
        'Gallery image uploaded'
      );
    });

    it('should return 400 without image', async () => {
      req.params = { id: 'clinic-123' };
      req.file = undefined;

      await controller.uploadGalleryImage(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Image is required'
      );
    });
  });

  describe('updateGalleryImage', () => {
    it('should update a gallery image', async () => {
      const mockImage = { id: 'img-1', captionFr: 'Updated' };
      (clinicService.updateGalleryImage as jest.Mock).mockResolvedValue(mockImage);

      req.params = { imageId: 'img-1' };
      req.body = { captionFr: 'Updated' };

      await controller.updateGalleryImage(req as Request, res as Response, next);

      expect(clinicService.updateGalleryImage).toHaveBeenCalledWith(
        'img-1',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockImage,
        'Gallery image updated'
      );
    });
  });

  describe('deleteGalleryImage', () => {
    it('should delete a gallery image', async () => {
      (clinicService.deleteGalleryImage as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'clinic-123', imageId: 'img-1' };

      await controller.deleteGalleryImage(req as Request, res as Response, next);

      expect(clinicService.deleteGalleryImage).toHaveBeenCalledWith(
        'img-1',
        'clinic-123'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Gallery image deleted'
      );
    });
  });

  describe('getMyGallery', () => {
    it('should get own gallery', async () => {
      const mockImages = [{ id: 'img-1', imageUrl: 'image.jpg' }];
      (clinicService.getGallery as jest.Mock).mockResolvedValue(mockImages);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.getMyGallery(req as Request, res as Response, next);

      expect(clinicService.getGallery).toHaveBeenCalledWith('clinic-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockImages,
        'Gallery retrieved successfully'
      );
    });
  });

  describe('uploadMyGalleryImage', () => {
    it('should upload own gallery image', async () => {
      const mockImage = { id: 'img-1', imageUrl: 'image.jpg' };
      (clinicService.uploadGalleryImage as jest.Mock).mockResolvedValue(mockImage);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.file = { originalname: 'image.jpg' } as any;
      req.body = { captionFr: 'Test' };

      await controller.uploadMyGalleryImage(req as Request, res as Response, next);

      expect(clinicService.uploadGalleryImage).toHaveBeenCalledWith(
        'clinic-123',
        req.file,
        'Test',
        undefined
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockImage,
        'Gallery image uploaded'
      );
    });

    it('should return 400 without image', async () => {
      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.file = undefined;

      await controller.uploadMyGalleryImage(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Image is required'
      );
    });
  });
});

