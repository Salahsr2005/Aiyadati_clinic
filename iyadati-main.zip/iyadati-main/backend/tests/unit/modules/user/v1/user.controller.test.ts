import { Request, Response, NextFunction } from 'express';
import { UserController } from '../../../../../src/modules/user/v1/user.controller';
import { userService } from '../../../../../src/modules/user/v1/user.service';
import { ResponseUtil } from '../../../../../src/core/utils/response';

// Mock the user service
jest.mock('../../../../../src/modules/user/v1/user.service', () => ({
  userService: {
    getUsers: jest.fn(),
    getUserById: jest.fn(),
    getUserByEmail: jest.fn(),
    getUserByPhone: jest.fn(),
    suspendUser: jest.fn(),
    unsuspendUser: jest.fn(),
    getMyContacts: jest.fn(),
    createContact: jest.fn(),
    updateContact: jest.fn(),
    deleteContact: jest.fn(),
    getMyDocuments: jest.fn(),
    uploadDocument: jest.fn(),
    updateDocument: jest.fn(),
    deleteDocument: jest.fn(),
  },
}));

// Mock ResponseUtil
jest.mock('../../../../../src/core/utils/response', () => ({
  ResponseUtil: {
    paginated: jest.fn(),
    success: jest.fn(),
    created: jest.fn(),
    badRequest: jest.fn(),
    unauthorized: jest.fn(),
  },
}));

describe('UserController', () => {
  let controller: UserController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    controller = new UserController();
    req = {
      params: {},
      query: {},
      body: {},
      user: { id: 'user-123', role: 'USER' } as any,
      ip: '127.0.0.1',
      file: undefined,
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  // Helper to create request with ip
  const createRequestWithIp = (ip: string): Partial<Request> => ({
    ...req,
    get ip() { return ip; },
  });

  // ============================================================
  // Staff Routes
  // ============================================================

  describe('getUsers', () => {
    it('should return paginated users', async () => {
      const mockResult = {
        users: [{ id: 'user-1' }, { id: 'user-2' }],
        total: 2,
      };
      (userService.getUsers as jest.Mock).mockResolvedValue(mockResult);

      req.query = { page: '2', limit: '5' };

      await controller.getUsers(req as Request, res as Response, next);

      expect(userService.getUsers).toHaveBeenCalledWith(req.query);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.users,
        mockResult.total,
        2,
        5,
        'Users retrieved successfully'
      );
      expect(next).not.toHaveBeenCalled();
    });

    it('should use default pagination values', async () => {
      const mockResult = { users: [], total: 0 };
      (userService.getUsers as jest.Mock).mockResolvedValue(mockResult);

      req.query = {};

      await controller.getUsers(req as Request, res as Response, next);

      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        10,
        'Users retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Service error');
      (userService.getUsers as jest.Mock).mockRejectedValue(error);

      await controller.getUsers(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getUserById', () => {
    it('should return a user by id', async () => {
      const mockUser = { id: 'user-123', email: 'user@example.com' };
      (userService.getUserById as jest.Mock).mockResolvedValue(mockUser);

      req.params = { id: 'user-123' };

      await controller.getUserById(req as Request, res as Response, next);

      expect(userService.getUserById).toHaveBeenCalledWith('user-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockUser,
        'User retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('User not found');
      (userService.getUserById as jest.Mock).mockRejectedValue(error);

      req.params = { id: 'non-existent' };

      await controller.getUserById(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getUserByEmail', () => {
    it('should return a user by email', async () => {
      const mockUser = { id: 'user-123', email: 'user@example.com' };
      (userService.getUserByEmail as jest.Mock).mockResolvedValue(mockUser);

      req.params = { email: 'user@example.com' };

      await controller.getUserByEmail(req as Request, res as Response, next);

      expect(userService.getUserByEmail).toHaveBeenCalledWith('user@example.com');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockUser,
        'User retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('User not found');
      (userService.getUserByEmail as jest.Mock).mockRejectedValue(error);

      req.params = { email: 'nonexistent@example.com' };

      await controller.getUserByEmail(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getUserByPhone', () => {
    it('should return a user by phone', async () => {
      const mockUser = { id: 'user-123', phone: '0555123456' };
      (userService.getUserByPhone as jest.Mock).mockResolvedValue(mockUser);

      req.params = { phone: '0555123456' };

      await controller.getUserByPhone(req as Request, res as Response, next);

      expect(userService.getUserByPhone).toHaveBeenCalledWith('0555123456');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockUser,
        'User retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('User not found');
      (userService.getUserByPhone as jest.Mock).mockRejectedValue(error);

      req.params = { phone: '0000000000' };

      await controller.getUserByPhone(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('suspendUser', () => {
    it('should suspend a user', async () => {
      const mockUser = { id: 'user-123', isSuspended: true };
      (userService.suspendUser as jest.Mock).mockResolvedValue(mockUser);

      req.params = { id: 'user-123' };
      req.body = { reason: 'Violation of terms' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.suspendUser(reqWithIp as Request, res as Response, next);

      expect(userService.suspendUser).toHaveBeenCalledWith(
        'user-123',
        { reason: 'Violation of terms' },
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockUser,
        'User suspended successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Already suspended');
      (userService.suspendUser as jest.Mock).mockRejectedValue(error);

      await controller.suspendUser(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('unsuspendUser', () => {
    it('should unsuspend a user', async () => {
      const mockUser = { id: 'user-123', isSuspended: false };
      (userService.unsuspendUser as jest.Mock).mockResolvedValue(mockUser);

      req.params = { id: 'user-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.unsuspendUser(reqWithIp as Request, res as Response, next);

      expect(userService.unsuspendUser).toHaveBeenCalledWith(
        'user-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockUser,
        'User unsuspended successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Not suspended');
      (userService.unsuspendUser as jest.Mock).mockRejectedValue(error);

      await controller.unsuspendUser(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // Self-Service: Contacts
  // ============================================================

  describe('getMyContacts', () => {
    it('should get user contacts', async () => {
      const mockContacts = [{ id: 'contact-1', firstName: 'Jane' }];
      (userService.getMyContacts as jest.Mock).mockResolvedValue(mockContacts);

      req.user = { id: 'user-123', role: 'USER' } as any;

      await controller.getMyContacts(req as Request, res as Response, next);

      expect(userService.getMyContacts).toHaveBeenCalledWith('user-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockContacts,
        'Contacts retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Service error');
      (userService.getMyContacts as jest.Mock).mockRejectedValue(error);

      await controller.getMyContacts(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('createContact', () => {
    it('should create a contact', async () => {
      const mockContact = { id: 'contact-1', firstName: 'Jane' };
      (userService.createContact as jest.Mock).mockResolvedValue(mockContact);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.body = { firstName: 'Jane', lastName: 'Doe', phone: '0555123457' };

      await controller.createContact(req as Request, res as Response, next);

      expect(userService.createContact).toHaveBeenCalledWith('user-123', req.body);
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockContact,
        'Contact created successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Validation error');
      (userService.createContact as jest.Mock).mockRejectedValue(error);

      await controller.createContact(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('updateContact', () => {
    it('should update a contact', async () => {
      const mockContact = { id: 'contact-1', firstName: 'Updated' };
      (userService.updateContact as jest.Mock).mockResolvedValue(mockContact);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.params = { id: 'contact-1' };
      req.body = { firstName: 'Updated' };

      await controller.updateContact(req as Request, res as Response, next);

      expect(userService.updateContact).toHaveBeenCalledWith(
        'user-123',
        'contact-1',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockContact,
        'Contact updated successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Contact not found');
      (userService.updateContact as jest.Mock).mockRejectedValue(error);

      await controller.updateContact(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('deleteContact', () => {
    it('should delete a contact', async () => {
      (userService.deleteContact as jest.Mock).mockResolvedValue(undefined);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.params = { id: 'contact-1' };

      await controller.deleteContact(req as Request, res as Response, next);

      expect(userService.deleteContact).toHaveBeenCalledWith('user-123', 'contact-1');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Contact deleted successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Contact not found');
      (userService.deleteContact as jest.Mock).mockRejectedValue(error);

      await controller.deleteContact(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // Self-Service: Documents
  // ============================================================

  describe('getMyDocuments', () => {
    it('should get user documents with pagination', async () => {
      const mockResult = {
        documents: [{ id: 'doc-1', title: 'Medical Report' }],
        total: 1,
      };
      (userService.getMyDocuments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.query = { page: '2', limit: '5' };

      await controller.getMyDocuments(req as Request, res as Response, next);

      expect(userService.getMyDocuments).toHaveBeenCalledWith('user-123', 2, 5);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.documents,
        mockResult.total,
        2,
        5,
        'Documents retrieved'
      );
    });

    it('should use default pagination', async () => {
      const mockResult = { documents: [], total: 0 };
      (userService.getMyDocuments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.query = {};

      await controller.getMyDocuments(req as Request, res as Response, next);

      expect(userService.getMyDocuments).toHaveBeenCalledWith('user-123', 1, 10);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        10,
        'Documents retrieved'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Service error');
      (userService.getMyDocuments as jest.Mock).mockRejectedValue(error);

      await controller.getMyDocuments(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('uploadDocument', () => {
    it('should upload a document', async () => {
      const mockDoc = { id: 'doc-1', title: 'Medical Report' };
      (userService.uploadDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.file = { originalname: 'medical.pdf' } as any;
      req.body = { title: 'Medical Report' };

      await controller.uploadDocument(req as Request, res as Response, next);

      expect(userService.uploadDocument).toHaveBeenCalledWith(
        'user-123',
        req.file,
        req.body
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document uploaded'
      );
    });

    it('should return 400 without file', async () => {
      req.user = { id: 'user-123', role: 'USER' } as any;
      req.file = undefined;

      await controller.uploadDocument(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Document is required'
      );
      expect(userService.uploadDocument).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Upload failed');
      (userService.uploadDocument as jest.Mock).mockRejectedValue(error);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.file = { originalname: 'medical.pdf' } as any;

      await controller.uploadDocument(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('updateDocument', () => {
    it('should update a document', async () => {
      const mockDoc = { id: 'doc-1', title: 'Updated' };
      (userService.updateDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.params = { id: 'doc-1' };
      req.body = { title: 'Updated' };

      await controller.updateDocument(req as Request, res as Response, next);

      expect(userService.updateDocument).toHaveBeenCalledWith(
        'user-123',
        'doc-1',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document updated'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Document not found');
      (userService.updateDocument as jest.Mock).mockRejectedValue(error);

      await controller.updateDocument(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('deleteDocument', () => {
    it('should delete a document', async () => {
      (userService.deleteDocument as jest.Mock).mockResolvedValue(undefined);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.params = { id: 'doc-1' };

      await controller.deleteDocument(req as Request, res as Response, next);

      expect(userService.deleteDocument).toHaveBeenCalledWith(
        'user-123',
        'doc-1',
        'USER'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Document deleted'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Document not found');
      (userService.deleteDocument as jest.Mock).mockRejectedValue(error);

      await controller.deleteDocument(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });
});


