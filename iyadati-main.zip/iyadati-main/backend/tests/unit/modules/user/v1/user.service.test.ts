import { UserService } from '../../../../../src/modules/user/v1/user.service';
import { userRepository } from '../../../../../src/repositories/user.repository';
import { contactUserRepository } from '../../../../../src/repositories/contact-user.repository';
import { userDocumentRepository } from '../../../../../src/repositories/user-document.repository';
import { fileService } from '../../../../../src/modules/file/v1/file.service';
import { eventEmitter } from '../../../../../src/core/events/event-emitter';
import {
  NotFoundError,
  BadRequestError,
  ForbiddenError,
} from '../../../../../src/core/utils/error';

// Mock all dependencies
jest.mock('../../../../../src/repositories/user.repository');
jest.mock('../../../../../src/repositories/contact-user.repository');
jest.mock('../../../../../src/repositories/user-document.repository');
jest.mock('../../../../../src/modules/file/v1/file.service');
jest.mock('../../../../../src/core/events/event-emitter');

describe('UserService', () => {
  let userService: UserService;

  beforeEach(() => {
    userService = new UserService();
    jest.clearAllMocks();
  });

  // ============================================================
  // Helper Mocks
  // ============================================================

  const mockUser = {
    id: 'user-123',
    email: 'user@example.com',
    password: 'hashed-password',
    firstName: 'John',
    lastName: 'Doe',
    phone: '0555123456',
    dateOfBirth: new Date('1990-01-01'),
    wilayaId: 'wilaya-123',
    wilaya: { id: 'wilaya-123', code: 16, name: 'Alger' },
    isVerified: true,
    isSuspended: false,
    suspensionReason: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    noShowCount: 0,
    trustPoints: 5,
    trustLevel: 2,
  };

  const mockContact = {
    id: 'contact-1',
    userId: 'user-123',
    firstName: 'Jane',
    lastName: 'Doe',
    phone: '0555123457',
    dateOfBirth: new Date('1992-02-02'),
    relationship: 'sibling',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockDocument = {
    id: 'doc-1',
    userId: 'user-123',
    fileName: 'medical.pdf',
    fileType: 'application/pdf',
    fileSize: 1024,
    fileId: 'file-123',
    title: 'Medical Report',
    description: 'Annual checkup',
    docDate: new Date('2026-07-15'),
    tags: ['checkup', 'annual'],
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockFile = {
    fieldname: 'document',
    originalname: 'medical.pdf',
    encoding: '7bit',
    mimetype: 'application/pdf',
    size: 1024,
    destination: '/uploads',
    filename: 'doc-123.pdf',
    path: '/uploads/doc-123.pdf',
    buffer: Buffer.from('fake pdf data'),
    stream: null as any,
  };

  // ============================================================
  // getUsers
  // ============================================================

  describe('getUsers', () => {
    it('should return paginated users with filters', async () => {
      const mockUsers = [mockUser, { ...mockUser, id: 'user-456' }];
      (userRepository.findAllWithFilters as jest.Mock).mockResolvedValue({
        users: mockUsers,
        total: 2,
      });

      const filters = { page: 1, limit: 10, search: 'John' };
      const result = await userService.getUsers(filters);

      expect(userRepository.findAllWithFilters).toHaveBeenCalledWith(filters);
      expect(result.users).toHaveLength(2);
      expect(result.total).toBe(2);
      expect(result.users[0]).toHaveProperty('id', 'user-123');
    });

    it('should handle empty results', async () => {
      (userRepository.findAllWithFilters as jest.Mock).mockResolvedValue({
        users: [],
        total: 0,
      });

      const result = await userService.getUsers({});

      expect(result.users).toHaveLength(0);
      expect(result.total).toBe(0);
    });
  });

  // ============================================================
  // getUserById
  // ============================================================

  describe('getUserById', () => {
    it('should return a user by id', async () => {
      (userRepository.findById as jest.Mock).mockResolvedValue(mockUser);

      const result = await userService.getUserById('user-123');

      expect(userRepository.findById).toHaveBeenCalledWith('user-123');
      expect(result.id).toBe('user-123');
      expect(result.email).toBe('user@example.com');
    });

    it('should throw NotFoundError when user does not exist', async () => {
      (userRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(userService.getUserById('non-existent')).rejects.toThrow(
        NotFoundError
      );
    });
  });

  // ============================================================
  // getUserByEmail
  // ============================================================

  describe('getUserByEmail', () => {
    it('should return a user by email', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(mockUser);

      const result = await userService.getUserByEmail('user@example.com');

      expect(userRepository.findByEmail).toHaveBeenCalledWith('user@example.com');
      expect(result.id).toBe('user-123');
    });

    it('should throw NotFoundError when email does not exist', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.getUserByEmail('nonexistent@example.com')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // getUserByPhone
  // ============================================================

  describe('getUserByPhone', () => {
    it('should return a user by phone', async () => {
      (userRepository.findByPhone as jest.Mock).mockResolvedValue(mockUser);

      const result = await userService.getUserByPhone('0555123456');

      expect(userRepository.findByPhone).toHaveBeenCalledWith('0555123456');
      expect(result.id).toBe('user-123');
    });

    it('should throw NotFoundError when phone does not exist', async () => {
      (userRepository.findByPhone as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.getUserByPhone('0000000000')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // suspendUser
  // ============================================================

  describe('suspendUser', () => {
    const suspendedUser = {
      ...mockUser,
      isSuspended: true,
      suspensionReason: 'Violation of terms',
    };

    beforeEach(() => {
      (userRepository.findById as jest.Mock).mockResolvedValue(mockUser);
      (userRepository.suspend as jest.Mock).mockResolvedValue(suspendedUser);
    });

    it('should suspend a user with reason', async () => {
      const result = await userService.suspendUser(
        'user-123',
        { reason: 'Violation of terms' },
        'admin-123',
        '127.0.0.1'
      );

      expect(userRepository.suspend).toHaveBeenCalledWith(
        'user-123',
        'Violation of terms'
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'user.suspended',
          entity: 'User',
          entityId: 'user-123',
          performedBy: 'admin-123',
          details: { reason: 'Violation of terms', userEmail: 'user@example.com' },
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '⚠️ Account Suspended',
          body: expect.stringContaining('Violation of terms'),
        })
      );
      expect(result.isSuspended).toBe(true);
      expect(result.suspensionReason).toBe('Violation of terms');
    });

    it('should throw NotFoundError when user does not exist', async () => {
      (userRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.suspendUser('non-existent', { reason: 'test' }, 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when already suspended', async () => {
      (userRepository.findById as jest.Mock).mockResolvedValue({
        ...mockUser,
        isSuspended: true,
      });

      await expect(
        userService.suspendUser('user-123', { reason: 'test' }, 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // unsuspendUser
  // ============================================================

  describe('unsuspendUser', () => {
    const unsuspendedUser = {
      ...mockUser,
      isSuspended: false,
      suspensionReason: null,
    };

    beforeEach(() => {
      (userRepository.findById as jest.Mock).mockResolvedValue({
        ...mockUser,
        isSuspended: true,
      });
      (userRepository.unsuspend as jest.Mock).mockResolvedValue(unsuspendedUser);
    });

    it('should unsuspend a user successfully', async () => {
      const result = await userService.unsuspendUser(
        'user-123',
        'admin-123',
        '127.0.0.1'
      );

      expect(userRepository.unsuspend).toHaveBeenCalledWith('user-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'user.unsuspended',
          entity: 'User',
          entityId: 'user-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '✅ Account Reinstated',
        })
      );
      expect(result.isSuspended).toBe(false);
    });

    it('should throw BadRequestError when not suspended', async () => {
      (userRepository.findById as jest.Mock).mockResolvedValue(mockUser);

      await expect(
        userService.unsuspendUser('user-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // Contacts
  // ============================================================

  describe('getMyContacts', () => {
    it('should return user contacts', async () => {
      (contactUserRepository.findByUserId as jest.Mock).mockResolvedValue([
        mockContact,
      ]);

      const result = await userService.getMyContacts('user-123');

      expect(contactUserRepository.findByUserId).toHaveBeenCalledWith('user-123');
      expect(result).toHaveLength(1);
      expect(result[0].firstName).toBe('Jane');
      expect(result[0].relationship).toBe('sibling');
    });

    it('should return empty array when no contacts', async () => {
      (contactUserRepository.findByUserId as jest.Mock).mockResolvedValue([]);

      const result = await userService.getMyContacts('user-123');

      expect(result).toHaveLength(0);
    });
  });

  describe('createContact', () => {
    const contactData = {
      firstName: 'Jane',
      lastName: 'Doe',
      phone: '0555123457',
      dateOfBirth: '1992-02-02',
      relationship: 'sibling',
    };

    beforeEach(() => {
      (contactUserRepository.create as jest.Mock).mockResolvedValue(mockContact);
    });

    it('should create a contact successfully', async () => {
      const result = await userService.createContact('user-123', contactData);

      expect(contactUserRepository.create).toHaveBeenCalledWith({
        userId: 'user-123',
        firstName: 'Jane',
        lastName: 'Doe',
        phone: '0555123457',
        dateOfBirth: expect.any(Date),
        relationship: 'sibling',
      });
      expect(result.firstName).toBe('Jane');
      expect(result.phone).toBe('0555123457');
    });
  });

  describe('updateContact', () => {
    const updateData = {
      firstName: 'Jane Updated',
      relationship: 'parent',
    };

    const updatedContact = {
      ...mockContact,
      firstName: 'Jane Updated',
      relationship: 'parent',
    };

    beforeEach(() => {
      (contactUserRepository.findById as jest.Mock).mockResolvedValue(mockContact);
      (contactUserRepository.update as jest.Mock).mockResolvedValue(updatedContact);
    });

    it('should update a contact successfully', async () => {
      const result = await userService.updateContact(
        'user-123',
        'contact-1',
        updateData
      );

      expect(contactUserRepository.update).toHaveBeenCalledWith('contact-1', {
        firstName: 'Jane Updated',
        relationship: 'parent',
      });
      expect(result.firstName).toBe('Jane Updated');
      expect(result.relationship).toBe('parent');
    });

    it('should throw NotFoundError when contact does not exist', async () => {
      (contactUserRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.updateContact('user-123', 'non-existent', {})
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when contact belongs to different user', async () => {
      (contactUserRepository.findById as jest.Mock).mockResolvedValue({
        ...mockContact,
        userId: 'other-user',
      });

      await expect(
        userService.updateContact('user-123', 'contact-1', {})
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('deleteContact', () => {
    beforeEach(() => {
      (contactUserRepository.findById as jest.Mock).mockResolvedValue(mockContact);
      (contactUserRepository.softDelete as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete a contact successfully', async () => {
      await userService.deleteContact('user-123', 'contact-1');

      expect(contactUserRepository.softDelete).toHaveBeenCalledWith('contact-1');
    });

    it('should throw NotFoundError when contact does not exist', async () => {
      (contactUserRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.deleteContact('user-123', 'non-existent')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // Documents
  // ============================================================

  describe('getMyDocuments', () => {
    const mockDocs = [
      {
        ...mockDocument,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    beforeEach(() => {
      (userDocumentRepository.findByUserId as jest.Mock).mockResolvedValue({
        documents: mockDocs,
        total: 1,
      });
    });

    it('should return documents with pagination', async () => {
      const result = await userService.getMyDocuments('user-123', 1, 10);

      expect(userDocumentRepository.findByUserId).toHaveBeenCalledWith(
        'user-123',
        1,
        10
      );
      expect(result.documents).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(result.documents[0].title).toBe('Medical Report');
      expect(result.documents[0]).toHaveProperty('accessUrl');
    });

    it('should use default pagination', async () => {
      await userService.getMyDocuments('user-123');

      expect(userDocumentRepository.findByUserId).toHaveBeenCalledWith(
        'user-123',
        1,
        10
      );
    });
  });

  describe('uploadDocument', () => {
    const docData = {
      title: 'Medical Report',
      description: 'Annual checkup',
      docDate: '2026-07-15',
      tags: 'checkup,annual',
    };

    beforeEach(() => {
      (userDocumentRepository.create as jest.Mock).mockResolvedValue(mockDocument);
    });

    it('should upload a document successfully', async () => {
      const result = await userService.uploadDocument(
        'user-123',
        mockFile,
        docData
      );

      expect(userDocumentRepository.create).toHaveBeenCalledWith({
        userId: 'user-123',
        fileName: 'medical.pdf',
        filePath: 'private/user-documents/doc-123.pdf',
        fileType: 'application/pdf',
        fileSize: 1024,
        storageKey: 'doc-123.pdf',
        title: 'Medical Report',
        description: 'Annual checkup',
        docDate: expect.any(Date),
        tags: ['checkup', 'annual'],
        storageType: 'private',
        category: 'document',
      });
      expect(result.title).toBe('Medical Report');
      expect(result.tags).toBe('checkup, annual');
      expect(result).toHaveProperty('accessUrl');
    });

    it('should handle missing optional fields', async () => {
      const minimalData = {};
      await userService.uploadDocument('user-123', mockFile, minimalData);

      expect(userDocumentRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          title: undefined,
          description: undefined,
          docDate: undefined,
          tags: [],
        })
      );
    });
  });

  describe('updateDocument', () => {
    const updateData = {
      title: 'Updated Report',
      tags: 'checkup,annual,updated',
    };

    const updatedDocument = {
      ...mockDocument,
      title: 'Updated Report',
      tags: ['checkup', 'annual', 'updated'],
    };

    beforeEach(() => {
      (userDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDocument);
      (userDocumentRepository.update as jest.Mock).mockResolvedValue(updatedDocument);
    });

    it('should update a document successfully', async () => {
      const result = await userService.updateDocument(
        'user-123',
        'doc-1',
        updateData
      );

      expect(userDocumentRepository.update).toHaveBeenCalledWith('doc-1', {
        title: 'Updated Report',
        tags: ['checkup', 'annual', 'updated'],
        description: undefined,
        docDate: undefined,
      });
      expect(result.title).toBe('Updated Report');
      expect(result.tags).toBe('checkup, annual, updated');
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (userDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.updateDocument('user-123', 'non-existent', {})
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when document belongs to different user', async () => {
      (userDocumentRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDocument,
        userId: 'other-user',
      });

      await expect(
        userService.updateDocument('user-123', 'doc-1', {})
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('deleteDocument', () => {
    beforeEach(() => {
      (userDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDocument);
      (fileService.deleteFile as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete a document as owner', async () => {
      await userService.deleteDocument('user-123', 'doc-1', 'USER');

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-123',
        'user-123',
        'USER',
        false
      );
    });

    it('should allow admin to delete any document', async () => {
      await userService.deleteDocument('user-123', 'doc-1', 'ADMIN');

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-123',
        'user-123',
        'ADMIN',
        false
      );
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (userDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        userService.deleteDocument('user-123', 'non-existent', 'USER')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw ForbiddenError when not owner and not admin', async () => {
      await expect(
        userService.deleteDocument('other-user', 'doc-1', 'USER')
      ).rejects.toThrow(ForbiddenError);
    });
  });
});

