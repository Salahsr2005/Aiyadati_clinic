import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

import { AuthService } from '../../../../../src/modules/auth/v1/auth.service';

import { superAdminRepository } from '../../../../../src/repositories/super-admin.repository';
import { adminRepository } from '../../../../../src/repositories/admin.repository';
import { userRepository } from '../../../../../src/repositories/user.repository';
import { clinicRepository } from '../../../../../src/repositories/clinic.repository';
import { doctorRepository } from '../../../../../src/repositories/doctor.repository';
import { walletRepository } from '../../../../../src/repositories/wallet.repository';

import { eventEmitter } from '../../../../../src/core/events/event-emitter';

import {
  ConflictError,
  UnauthorizedError,
  BadRequestError,
} from '../../../../../src/core/utils/error';

jest.mock('../../../../../src/repositories/super-admin.repository');
jest.mock('../../../../../src/repositories/admin.repository');
jest.mock('../../../../../src/repositories/user.repository');
jest.mock('../../../../../src/repositories/clinic.repository');
jest.mock('../../../../../src/repositories/doctor.repository');
jest.mock('../../../../../src/repositories/wallet.repository');

jest.mock('../../../../../src/core/events/event-emitter');

jest.mock('bcryptjs', () => ({
  __esModule: true,
  default: {
    hash: jest.fn(),
    compare: jest.fn(),
  },
}));

jest.mock('jsonwebtoken', () => ({
  sign: jest.fn(),
  verify: jest.fn(),
}));

describe('AuthService', () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService();

    /*
     * IMPORTANT:
     * resetAllMocks() clears both:
     * - call history
     * - previous mock implementations/return values
     *
     * This prevents one test from affecting another test.
     */
    jest.resetAllMocks();
  });

  // ============================================================
  // login
  // ============================================================

  describe('login', () => {
    const credentials = {
      email: 'admin@example.com',
      password: 'password123',
    };

    it('should login a super admin successfully', async () => {
      const superAdmin = {
        id: 'super-admin-id',
        email: credentials.email,
        password: 'hashed-password',
        name: 'Super Admin',
      };

      (
        superAdminRepository.findByEmail as jest.Mock
      ).mockResolvedValue(superAdmin);

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (jwt.sign as jest.Mock).mockReturnValue('super-admin-jwt');

      const result = await authService.login(credentials);

      expect(superAdminRepository.findByEmail).toHaveBeenCalledWith(
        credentials.email,
      );

      expect(adminRepository.findByEmail).not.toHaveBeenCalled();

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        superAdmin.password,
      );

      expect(jwt.sign).toHaveBeenCalled();

      expect(result.user).toEqual({
        id: superAdmin.id,
        email: superAdmin.email,
        name: superAdmin.name,
        role: 'SUPER_ADMIN',
      });

      expect(result.token).toBeDefined();
      expect(typeof result.token).toBe('string');
      expect(result.token).toBe('super-admin-jwt');
    });

    it('should login an admin when super admin is not found', async () => {
      const admin = {
        id: 'admin-id',
        email: credentials.email,
        password: 'hashed-password',
        name: 'Admin',
      };

      (
        superAdminRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      (adminRepository.findByEmail as jest.Mock).mockResolvedValue(admin);

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (jwt.sign as jest.Mock).mockReturnValue('admin-jwt');

      const result = await authService.login(credentials);

      expect(superAdminRepository.findByEmail).toHaveBeenCalledWith(
        credentials.email,
      );

      expect(adminRepository.findByEmail).toHaveBeenCalledWith(
        credentials.email,
      );

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        admin.password,
      );

      expect(result.user).toEqual({
        id: admin.id,
        email: admin.email,
        name: admin.name,
        role: 'ADMIN',
      });

      expect(result.token).toBeDefined();
      expect(typeof result.token).toBe('string');
      expect(result.token).toBe('admin-jwt');
    });

    it('should reject an unknown email', async () => {
      (
        superAdminRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      (adminRepository.findByEmail as jest.Mock).mockResolvedValue(null);

      await expect(
        authService.login(credentials),
      ).rejects.toThrow(UnauthorizedError);

      await expect(
        authService.login(credentials),
      ).rejects.toThrow('Invalid email or password');

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an incorrect password', async () => {
      const superAdmin = {
        id: 'super-admin-id',
        email: credentials.email,
        password: 'hashed-password',
        name: 'Super Admin',
      };

      (
        superAdminRepository.findByEmail as jest.Mock
      ).mockResolvedValue(superAdmin);

      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      await expect(
        authService.login(credentials),
      ).rejects.toThrow(UnauthorizedError);

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        superAdmin.password,
      );

      expect(jwt.sign).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // loginUser
  // ============================================================

  describe('loginUser', () => {
    const credentials = {
      email: 'user@example.com',
      password: 'password123',
    };

    const user = {
      id: 'user-id',
      email: credentials.email,
      password: 'hashed-password',
      firstName: 'John',
      lastName: 'Doe',
      isVerified: true,
      isSuspended: false,
    };

    it('should login a verified user successfully', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(user);

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (jwt.sign as jest.Mock).mockReturnValue('user-jwt');

      const result = await authService.loginUser(credentials);

      expect(userRepository.findByEmail).toHaveBeenCalledWith(
        credentials.email,
      );

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        user.password,
      );

      expect(jwt.sign).toHaveBeenCalled();

      expect(result.user).toEqual({
        id: user.id,
        email: user.email,
        name: 'John Doe',
        role: 'USER',
      });

      expect(result.token).toBeDefined();
      expect(typeof result.token).toBe('string');
      expect(result.token).toBe('user-jwt');
    });

    it('should reject an unknown user', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(null);

      await expect(
        authService.loginUser(credentials),
      ).rejects.toThrow(UnauthorizedError);

      await expect(
        authService.loginUser(credentials),
      ).rejects.toThrow('Invalid email or password');

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an unverified user', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue({
        ...user,
        isVerified: false,
      });

      await expect(
        authService.loginUser(credentials),
      ).rejects.toThrow('Please verify your email first');

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject a suspended user', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue({
        ...user,
        isSuspended: true,
      });

      await expect(
        authService.loginUser(credentials),
      ).rejects.toThrow('Your account has been suspended');

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an incorrect password', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(user);

      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      await expect(
        authService.loginUser(credentials),
      ).rejects.toThrow('Invalid email or password');

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        user.password,
      );

      expect(jwt.sign).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // verifyToken
  // ============================================================

  describe('verifyToken', () => {
    const token = 'valid.jwt.token';

    const decodedUser = {
      id: 'user-id',
      email: 'user@example.com',
      role: 'USER' as const,
      name: 'John Doe',
    };

    it('should verify a valid token successfully', async () => {
      (jwt.verify as jest.Mock).mockReturnValue(decodedUser);

      const result = await authService.verifyToken(token);

      expect(jwt.verify).toHaveBeenCalledWith(
        token,
        expect.any(String),
      );

      expect(result).toEqual(decodedUser);
    });

    it('should reject an invalid token', async () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });

      await expect(
        authService.verifyToken(token),
      ).rejects.toThrow(UnauthorizedError);

      await expect(
        authService.verifyToken(token),
      ).rejects.toThrow('Invalid or expired token');
    });

    it('should reject an expired token', async () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('jwt expired');
      });

      await expect(
        authService.verifyToken(token),
      ).rejects.toThrow('Invalid or expired token');
    });
  });

  // ============================================================
  // registerUser
  // ============================================================

  describe('registerUser', () => {
    const registrationData = {
      email: 'newuser@example.com',
      password: 'password123',
      firstName: 'John',
      lastName: 'Doe',
      phone: '0555123456',
      dateOfBirth: '1995-01-01',
      wilayaId: 'wilaya-id',
    };

    const createdUser = {
      id: 'new-user-id',
      email: registrationData.email,
      firstName: registrationData.firstName,
      lastName: registrationData.lastName,
    };

    beforeEach(() => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      (
        userRepository.findByPhone as jest.Mock
      ).mockResolvedValue(null);

      (
        userRepository.create as jest.Mock
      ).mockResolvedValue(createdUser);

      (
        walletRepository.create as jest.Mock
      ).mockResolvedValue({
        id: 'wallet-id',
        userId: createdUser.id,
      });
    });

    it('should register a new user successfully', async () => {
      (bcrypt.hash as jest.Mock)
        .mockResolvedValueOnce('hashed-password')
        .mockResolvedValueOnce('hashed-otp');

      const result = await authService.registerUser(
        registrationData,
      );

      expect(result).toEqual({
        message:
          'Registration successful. Please check your email for the verification code.',
      });

      expect(userRepository.findByEmail).toHaveBeenCalledWith(
        registrationData.email,
      );

      expect(userRepository.findByPhone).toHaveBeenCalledWith(
        registrationData.phone,
      );

      expect(userRepository.create).toHaveBeenCalled();

      expect(walletRepository.create).toHaveBeenCalledWith(
        createdUser.id,
      );
    });

    it('should reject registration when email already exists', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        id: 'existing-user',
        email: registrationData.email,
      });

      await expect(
        authService.registerUser(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerUser(registrationData),
      ).rejects.toThrow('Email already registered');

      expect(userRepository.create).not.toHaveBeenCalled();
      expect(walletRepository.create).not.toHaveBeenCalled();
      expect(bcrypt.hash).not.toHaveBeenCalled();
    });

    it('should reject registration when phone already exists', async () => {
      (
        userRepository.findByPhone as jest.Mock
      ).mockResolvedValue({
        id: 'existing-user',
        phone: registrationData.phone,
      });

      await expect(
        authService.registerUser(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerUser(registrationData),
      ).rejects.toThrow('Phone already registered');

      expect(userRepository.create).not.toHaveBeenCalled();
      expect(walletRepository.create).not.toHaveBeenCalled();
      expect(bcrypt.hash).not.toHaveBeenCalled();
    });

    it('should hash the password before creating the user', async () => {
      (
        bcrypt.hash as jest.Mock
      )
        .mockResolvedValueOnce('hashed-password')
        .mockResolvedValueOnce('hashed-otp');

      await authService.registerUser(registrationData);

      expect(bcrypt.hash).toHaveBeenCalledWith(
        registrationData.password,
        12,
      );

      expect(userRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          password: 'hashed-password',
        }),
      );
    });

    it('should create a wallet for the new user', async () => {
      (
        bcrypt.hash as jest.Mock
      )
        .mockResolvedValueOnce('hashed-password')
        .mockResolvedValueOnce('hashed-otp');

      await authService.registerUser(registrationData);

      expect(walletRepository.create).toHaveBeenCalledWith(
        createdUser.id,
      );
    });

    it('should emit notification and OTP email events', async () => {
      (
        bcrypt.hash as jest.Mock
      )
        .mockResolvedValueOnce('hashed-password')
        .mockResolvedValueOnce('hashed-otp');

      await authService.registerUser(registrationData);

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: createdUser.id,
          type: 'system',
        }),
      );

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'send-otp-email',
        expect.objectContaining({
          email: createdUser.email,
          name: createdUser.firstName,
          otp: expect.any(String),
        }),
      );
    });
  });

  // ============================================================
  // verifyUserOtp
  // ============================================================

  describe('verifyUserOtp', () => {
    const otpData = {
      email: 'user@example.com',
      otp: '123456',
    };

    const user = {
      id: 'user-id',
      email: otpData.email,
      firstName: 'John',
      isVerified: false,
      verificationCode: 'hashed-otp',
      otpExpiresAt: new Date(Date.now() + 10 * 60 * 1000),
    };

    it('should verify a valid OTP successfully', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(
        user,
      );

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (
        userRepository.verifyUser as jest.Mock
      ).mockResolvedValue({
        ...user,
        isVerified: true,
      });

      const result = await authService.verifyUserOtp(otpData);

      expect(userRepository.findByEmail).toHaveBeenCalledWith(
        otpData.email,
      );

      expect(bcrypt.compare).toHaveBeenCalledWith(
        otpData.otp,
        user.verificationCode,
      );

      expect(userRepository.verifyUser).toHaveBeenCalledWith(
        user.id,
      );

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: user.id,
          type: 'system',
        }),
      );

      expect(result).toEqual({
        message:
          'Email verified successfully. You can now login.',
      });
    });

    it('should reject an unknown email', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(
        null,
      );

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow(BadRequestError);

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow(
        'Invalid email or verification code',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(userRepository.verifyUser).not.toHaveBeenCalled();
    });

    it('should return already verified when user is already verified', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...user,
        isVerified: true,
      });

      const result = await authService.verifyUserOtp(otpData);

      expect(result).toEqual({
        message: 'Email already verified',
      });

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(userRepository.verifyUser).not.toHaveBeenCalled();
    });

    it('should reject when verification code is missing', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...user,
        verificationCode: null,
      });

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow(
        'No verification code found. Please register again.',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
    });

    it('should reject when OTP expiry is missing', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...user,
        otpExpiresAt: null,
      });

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow(
        'No verification code found. Please register again.',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
    });

    it('should reject an expired OTP', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...user,
        otpExpiresAt: new Date(Date.now() - 1000),
      });

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow(
        'Verification code has expired. Please request a new one.',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
    });

    it('should reject an incorrect OTP', async () => {
      (userRepository.findByEmail as jest.Mock).mockResolvedValue(
        user,
      );

      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      await expect(
        authService.verifyUserOtp(otpData),
      ).rejects.toThrow('Invalid verification code');

      expect(bcrypt.compare).toHaveBeenCalledWith(
        otpData.otp,
        user.verificationCode,
      );

      expect(userRepository.verifyUser).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // resendOtp
  // ============================================================

  describe('resendOtp', () => {
    const resendData = {
      email: 'user@example.com',
    };

    const user = {
      id: 'user-id',
      email: resendData.email,
      firstName: 'John',
      isVerified: false,
      verificationCode: 'old-hashed-otp',
      otpExpiresAt: new Date(Date.now() + 10 * 60 * 1000),
    };

    it('should resend an OTP successfully', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue(user);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-new-otp',
      );

      (
        userRepository.setVerificationCode as jest.Mock
      ).mockResolvedValue({
        ...user,
        verificationCode: 'hashed-new-otp',
      });

      const result = await authService.resendOtp(resendData);

      expect(userRepository.findByEmail).toHaveBeenCalledWith(
        resendData.email,
      );

      expect(bcrypt.hash).toHaveBeenCalledWith(
        expect.any(String),
        10,
      );

      expect(
        userRepository.setVerificationCode,
      ).toHaveBeenCalledWith(
        user.id,
        'hashed-new-otp',
        expect.any(Date),
      );

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'send-otp-email',
        expect.objectContaining({
          email: user.email,
          name: user.firstName,
          otp: expect.any(String),
        }),
      );

      expect(result).toEqual({
        message:
          'If your email is registered, a new verification code has been sent.',
      });
    });

    it('should not reveal whether an unknown email exists', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      const result = await authService.resendOtp(resendData);

      expect(result).toEqual({
        message:
          'If your email is registered, a new verification code has been sent.',
      });

      expect(bcrypt.hash).not.toHaveBeenCalled();

      expect(
        userRepository.setVerificationCode,
      ).not.toHaveBeenCalled();

      expect(eventEmitter.emit).not.toHaveBeenCalled();
    });

    it('should not resend OTP to an already verified user', async () => {
      (
        userRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...user,
        isVerified: true,
      });

      const result = await authService.resendOtp(resendData);

      expect(result).toEqual({
        message:
          'Email already verified. You can login now.',
      });

      expect(bcrypt.hash).not.toHaveBeenCalled();

      expect(
        userRepository.setVerificationCode,
      ).not.toHaveBeenCalled();

      expect(eventEmitter.emit).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // registerClinic
  // ============================================================

  describe('registerClinic', () => {
    const registrationData = {
      nameFr: 'Clinique El Amal',
      nameAr: 'عيادة الأمل',
      password: 'password123',
      phone: '0555000000',
      email: 'clinic@example.com',
      wilayaId: 'wilaya-id',
    };

    const clinic = {
      id: 'clinic-id',
      nameFr: registrationData.nameFr,
      nameAr: registrationData.nameAr,
      email: registrationData.email,
      phone: registrationData.phone,
    };

    it('should register a clinic successfully', async () => {
      (
        clinicRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        clinicRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (clinicRepository.create as jest.Mock).mockResolvedValue(
        clinic,
      );

      (jwt.sign as jest.Mock).mockReturnValue('clinic-jwt');

      const result = await authService.registerClinic(
        registrationData,
      );

      expect(
        clinicRepository.emailExists,
      ).toHaveBeenCalledWith(registrationData.email);

      expect(
        clinicRepository.phoneExists,
      ).toHaveBeenCalledWith(registrationData.phone);

      expect(bcrypt.hash).toHaveBeenCalledWith(
        registrationData.password,
        12,
      );

      expect(clinicRepository.create).toHaveBeenCalledWith({
        nameFr: registrationData.nameFr,
        nameAr: registrationData.nameAr,
        password: 'hashed-password',
        phone: registrationData.phone,
        email: registrationData.email,
        wilaya: {
          connect: {
            id: registrationData.wilayaId,
          },
        },
      });

      expect(result).toEqual({
        token: 'clinic-jwt',
        user: {
          id: clinic.id,
          email: clinic.email,
          name: clinic.nameFr,
          role: 'CLINIC',
        },
      });
    });

    it('should reject when clinic email already exists', async () => {
      (
        clinicRepository.emailExists as jest.Mock
      ).mockResolvedValue(true);

      (
        clinicRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      await expect(
        authService.registerClinic(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerClinic(registrationData),
      ).rejects.toThrow('Email already registered');

      expect(bcrypt.hash).not.toHaveBeenCalled();
      expect(clinicRepository.create).not.toHaveBeenCalled();
    });

    it('should reject when clinic phone already exists', async () => {
      (
        clinicRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        clinicRepository.phoneExists as jest.Mock
      ).mockResolvedValue(true);

      await expect(
        authService.registerClinic(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerClinic(registrationData),
      ).rejects.toThrow('Phone already registered');

      expect(bcrypt.hash).not.toHaveBeenCalled();
      expect(clinicRepository.create).not.toHaveBeenCalled();
    });

    it('should emit a welcome notification', async () => {
      (
        clinicRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        clinicRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        clinicRepository.create as jest.Mock
      ).mockResolvedValue(clinic);

      (jwt.sign as jest.Mock).mockReturnValue('clinic-jwt');

      await authService.registerClinic(registrationData);

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: clinic.id,
          type: 'system',
        }),
      );
    });

    it('should create a clinic JWT with CLINIC role', async () => {
      (
        clinicRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        clinicRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        clinicRepository.create as jest.Mock
      ).mockResolvedValue(clinic);

      (jwt.sign as jest.Mock).mockReturnValue('clinic-jwt');

      const result = await authService.registerClinic(
        registrationData,
      );

      expect(jwt.sign).toHaveBeenCalledWith(
        {
          id: clinic.id,
          email: clinic.email,
          role: 'CLINIC',
          name: clinic.nameFr,
        },
        expect.any(String),
        { expiresIn: '7d' },
      );

      expect(result.token).toBe('clinic-jwt');
    });
  });

  // ============================================================
  // loginClinic
  // ============================================================

  describe('loginClinic', () => {
    const credentials = {
      email: 'clinic@example.com',
      password: 'password123',
    };

    const clinic = {
      id: 'clinic-id',
      email: credentials.email,
      password: 'hashed-password',
      nameFr: 'Clinique El Amal',
      isVerified: true,
      isSuspended: false,
    };

    it('should login a verified clinic successfully', async () => {
      (
        clinicRepository.findByEmail as jest.Mock
      ).mockResolvedValue(clinic);

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (jwt.sign as jest.Mock).mockReturnValue('clinic-jwt');

      const result = await authService.loginClinic(credentials);

      expect(
        clinicRepository.findByEmail,
      ).toHaveBeenCalledWith(credentials.email);

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        clinic.password,
      );

      expect(result).toEqual({
        token: 'clinic-jwt',
        user: {
          id: clinic.id,
          email: clinic.email,
          name: clinic.nameFr,
          role: 'CLINIC',
        },
      });
    });

    it('should reject an unknown clinic', async () => {
      (
        clinicRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      await expect(
        authService.loginClinic(credentials),
      ).rejects.toThrow('Clinic not found');

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an incorrect password', async () => {
      (
        clinicRepository.findByEmail as jest.Mock
      ).mockResolvedValue(clinic);

      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      await expect(
        authService.loginClinic(credentials),
      ).rejects.toThrow('Invalid email or password');

      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an unverified clinic', async () => {
      (
        clinicRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...clinic,
        isVerified: false,
      });

      await expect(
        authService.loginClinic(credentials),
      ).rejects.toThrow(
        'Clinic is pending verification',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject a suspended clinic', async () => {
      (
        clinicRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...clinic,
        isSuspended: true,
      });

      await expect(
        authService.loginClinic(credentials),
      ).rejects.toThrow(
        'Clinic has been suspended',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });
  });

  // ============================================================
  // registerDoctor
  // ============================================================

  describe('registerDoctor', () => {
    const registrationData = {
      email: 'doctor@example.com',
      password: 'password123',
      firstNameFr: 'Ahmed',
      firstNameAr: 'أحمد',
      lastNameFr: 'Benali',
      lastNameAr: 'بن علي',
      phone: '0555111111',
      wilayaId: 'wilaya-id',
    };

    const doctor = {
      id: 'doctor-id',
      email: registrationData.email,
      firstNameFr: registrationData.firstNameFr,
      firstNameAr: registrationData.firstNameAr,
      lastNameFr: registrationData.lastNameFr,
      lastNameAr: registrationData.lastNameAr,
      phone: registrationData.phone,
    };

    it('should register a doctor successfully', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        doctorRepository.create as jest.Mock
      ).mockResolvedValue(doctor);

      (jwt.sign as jest.Mock).mockReturnValue(
        'doctor-jwt',
      );

      const result = await authService.registerDoctor(
        registrationData,
      );

      expect(
        doctorRepository.emailExists,
      ).toHaveBeenCalledWith(registrationData.email);

      expect(
        doctorRepository.phoneExists,
      ).toHaveBeenCalledWith(registrationData.phone);

      expect(bcrypt.hash).toHaveBeenCalledWith(
        registrationData.password,
        12,
      );

      expect(doctorRepository.create).toHaveBeenCalledWith({
        email: registrationData.email,
        password: 'hashed-password',
        firstNameFr: registrationData.firstNameFr,
        firstNameAr: registrationData.firstNameAr,
        lastNameFr: registrationData.lastNameFr,
        lastNameAr: registrationData.lastNameAr,
        phone: registrationData.phone,
        wilayaId: registrationData.wilayaId,
      });

      expect(result).toEqual({
        token: 'doctor-jwt',
        user: {
          id: doctor.id,
          email: doctor.email,
          name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
          role: 'DOCTOR',
        },
      });
    });

    it('should reject when doctor email already exists', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(true);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      await expect(
        authService.registerDoctor(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerDoctor(registrationData),
      ).rejects.toThrow('Email already registered');

      expect(bcrypt.hash).not.toHaveBeenCalled();
      expect(doctorRepository.create).not.toHaveBeenCalled();
    });

    it('should reject when doctor phone already exists', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(true);

      await expect(
        authService.registerDoctor(registrationData),
      ).rejects.toThrow(ConflictError);

      await expect(
        authService.registerDoctor(registrationData),
      ).rejects.toThrow('Phone already registered');

      expect(bcrypt.hash).not.toHaveBeenCalled();
      expect(doctorRepository.create).not.toHaveBeenCalled();
    });

    it('should emit a welcome notification', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        doctorRepository.create as jest.Mock
      ).mockResolvedValue(doctor);

      (jwt.sign as jest.Mock).mockReturnValue(
        'doctor-jwt',
      );

      await authService.registerDoctor(registrationData);

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: doctor.id,
          type: 'system',
        }),
      );
    });

    it('should emit a doctor registration audit event', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        doctorRepository.create as jest.Mock
      ).mockResolvedValue(doctor);

      (jwt.sign as jest.Mock).mockReturnValue(
        'doctor-jwt',
      );

      await authService.registerDoctor(
        registrationData,
        '127.0.0.1',
      );

      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.registered',
          entity: 'Doctor',
          entityId: doctor.id,
          performedBy: doctor.id,
          ip: '127.0.0.1',
        }),
      );
    });

    it('should create a doctor JWT with DOCTOR role', async () => {
      (
        doctorRepository.emailExists as jest.Mock
      ).mockResolvedValue(false);

      (
        doctorRepository.phoneExists as jest.Mock
      ).mockResolvedValue(false);

      (bcrypt.hash as jest.Mock).mockResolvedValue(
        'hashed-password',
      );

      (
        doctorRepository.create as jest.Mock
      ).mockResolvedValue(doctor);

      (jwt.sign as jest.Mock).mockReturnValue(
        'doctor-jwt',
      );

      const result = await authService.registerDoctor(
        registrationData,
      );

      expect(jwt.sign).toHaveBeenCalledWith(
        {
          id: doctor.id,
          email: doctor.email,
          role: 'DOCTOR',
          name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
        },
        expect.any(String),
        { expiresIn: '7d' },
      );

      expect(result.token).toBe('doctor-jwt');
    });
  });

  // ============================================================
  // loginDoctor
  // ============================================================

  describe('loginDoctor', () => {
    const credentials = {
      email: 'doctor@example.com',
      password: 'password123',
    };

    const doctor = {
      id: 'doctor-id',
      email: credentials.email,
      password: 'hashed-password',
      firstNameFr: 'Ahmed',
      firstNameAr: 'أحمد',
      lastNameFr: 'Benali',
      lastNameAr: 'بن علي',
      isVerified: true,
      isSuspended: false,
    };

    it('should login a verified doctor successfully', async () => {
      (
        doctorRepository.findByEmail as jest.Mock
      ).mockResolvedValue(doctor);

      (bcrypt.compare as jest.Mock).mockResolvedValue(true);

      (jwt.sign as jest.Mock).mockReturnValue(
        'doctor-jwt',
      );

      const result = await authService.loginDoctor(
        credentials,
      );

      expect(
        doctorRepository.findByEmail,
      ).toHaveBeenCalledWith(credentials.email);

      expect(bcrypt.compare).toHaveBeenCalledWith(
        credentials.password,
        doctor.password,
      );

      expect(result).toEqual({
        token: 'doctor-jwt',
        user: {
          id: doctor.id,
          email: doctor.email,
          name: `${doctor.firstNameFr} ${doctor.lastNameFr}`,
          role: 'DOCTOR',
        },
      });
    });

    it('should reject an unknown doctor', async () => {
      (
        doctorRepository.findByEmail as jest.Mock
      ).mockResolvedValue(null);

      await expect(
        authService.loginDoctor(credentials),
      ).rejects.toThrow(
        'Invalid email or password',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an incorrect password', async () => {
      (
        doctorRepository.findByEmail as jest.Mock
      ).mockResolvedValue(doctor);

      (bcrypt.compare as jest.Mock).mockResolvedValue(false);

      await expect(
        authService.loginDoctor(credentials),
      ).rejects.toThrow(
        'Invalid email or password',
      );

      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject an unverified doctor', async () => {
      (
        doctorRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...doctor,
        isVerified: false,
      });

      await expect(
        authService.loginDoctor(credentials),
      ).rejects.toThrow(
        'Your account is pending verification',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });

    it('should reject a suspended doctor', async () => {
      (
        doctorRepository.findByEmail as jest.Mock
      ).mockResolvedValue({
        ...doctor,
        isSuspended: true,
      });

      await expect(
        authService.loginDoctor(credentials),
      ).rejects.toThrow(
        'Your account has been suspended',
      );

      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
    });
  });
});

