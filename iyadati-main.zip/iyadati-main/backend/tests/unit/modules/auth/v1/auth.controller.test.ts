import { Request, Response, NextFunction } from 'express';
import { AuthController } from '../../../../../src/modules/auth/v1/auth.controller';
import { authService } from '../../../../../src/modules/auth/v1/auth.service';
import { ResponseUtil } from '../../../../../src/core/utils/response';

jest.mock('../../../../../src/modules/auth/v1/auth.service', () => ({
  authService: {
    login: jest.fn(),
    loginUser: jest.fn(),
    verifyToken: jest.fn(),
    registerUser: jest.fn(),
    verifyUserOtp: jest.fn(),
    resendOtp: jest.fn(),
    registerClinic: jest.fn(),
    loginClinic: jest.fn(),
    registerDoctor: jest.fn(),
    loginDoctor: jest.fn(),
  },
}));

jest.mock('../../../../../src/core/utils/response', () => ({
  ResponseUtil: {
    success: jest.fn(),
    created: jest.fn(),
    unauthorized: jest.fn(),
  },
}));

describe('AuthController', () => {
  let controller: AuthController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    controller = new AuthController();

    req = {
      body: {},
      cookies: {},
      headers: {},
      ip: '127.0.0.1',
    };

    res = {
      cookie: jest.fn(),
      clearCookie: jest.fn(),
    };

    next = jest.fn();

    jest.clearAllMocks();
  });

  describe('login', () => {
    it('should login, set cookie, and return success response', async () => {
      const result = {
        token: 'login-token',
        user: { id: 'user-1', email: 'user@example.com' },
      };

      req.body = {
        email: 'user@example.com',
        password: 'password',
      };

      (authService.login as jest.Mock).mockResolvedValue(result);

      await controller.login(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.login).toHaveBeenCalledWith(req.body);

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'login-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
          maxAge: 7 * 24 * 60 * 60 * 1000,
        }),
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        'Login successful',
      );

      expect(next).not.toHaveBeenCalled();
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Login failed');

      (authService.login as jest.Mock).mockRejectedValue(error);

      await controller.login(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('logout', () => {
    it('should clear the token cookie and return success', async () => {
      await controller.logout(
        req as Request,
        res as Response,
        next,
      );

      expect(res.clearCookie).toHaveBeenCalledWith(
        'token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Logged out successfully',
      );

      expect(next).not.toHaveBeenCalled();
    });
  });

  describe('loginUser', () => {
    it('should login user, set cookie, and return success', async () => {
      const result = {
        token: 'user-token',
        user: { id: 'user-1' },
      };

      req.body = {
        email: 'user@example.com',
        password: 'password',
      };

      (authService.loginUser as jest.Mock).mockResolvedValue(result);

      await controller.loginUser(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.loginUser).toHaveBeenCalledWith(req.body);

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'user-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        'Login successful',
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('User login failed');

      (authService.loginUser as jest.Mock).mockRejectedValue(error);

      await controller.loginUser(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('me', () => {
    it('should get token from cookie and return the current user', async () => {
      const user = {
        id: 'user-1',
        email: 'user@example.com',
      };

      req.cookies = {
        token: 'cookie-token',
      };

      (authService.verifyToken as jest.Mock).mockResolvedValue(user);

      await controller.me(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.verifyToken).toHaveBeenCalledWith(
        'cookie-token',
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        { user },
        'User retrieved',
      );
    });

    it('should get token from Authorization header when cookie is absent', async () => {
      const user = {
        id: 'user-1',
        email: 'user@example.com',
      };

      req.cookies = {};

      req.headers = {
        authorization: 'Bearer header-token',
      };

      (authService.verifyToken as jest.Mock).mockResolvedValue(user);

      await controller.me(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.verifyToken).toHaveBeenCalledWith(
        'header-token',
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        { user },
        'User retrieved',
      );
    });

    it('should return unauthorized when no token exists', async () => {
      req.cookies = {};
      req.headers = {};

      await controller.me(
        req as Request,
        res as Response,
        next,
      );

      expect(ResponseUtil.unauthorized).toHaveBeenCalledWith(
        res,
        'Not authenticated',
      );

      expect(authService.verifyToken).not.toHaveBeenCalled();
      expect(next).not.toHaveBeenCalled();
    });

    it('should forward verification errors to next', async () => {
      const error = new Error('Invalid token');

      req.cookies = {
        token: 'invalid-token',
      };

      (authService.verifyToken as jest.Mock).mockRejectedValue(error);

      await controller.me(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('registerUser', () => {
    it('should register user and return created response', async () => {
      const result = {
        message: 'User registered successfully',
        user: { id: 'user-1' },
      };

      req.body = {
        email: 'user@example.com',
        password: 'password',
      };

      (authService.registerUser as jest.Mock).mockResolvedValue(result);

      await controller.registerUser(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.registerUser).toHaveBeenCalledWith(
        req.body,
      );

      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        result,
        result.message,
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Registration failed');

      (authService.registerUser as jest.Mock).mockRejectedValue(error);

      await controller.registerUser(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('verifyOtp', () => {
    it('should verify OTP and return success response', async () => {
      const result = {
        message: 'OTP verified successfully',
      };

      req.body = {
        email: 'user@example.com',
        code: '123456',
      };

      (authService.verifyUserOtp as jest.Mock).mockResolvedValue(result);

      await controller.verifyOtp(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.verifyUserOtp).toHaveBeenCalledWith(
        req.body,
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        result.message,
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Invalid OTP');

      (authService.verifyUserOtp as jest.Mock).mockRejectedValue(error);

      await controller.verifyOtp(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('resendOtp', () => {
    it('should resend OTP and return success response', async () => {
      const result = {
        message: 'OTP sent successfully',
      };

      req.body = {
        email: 'user@example.com',
      };

      (authService.resendOtp as jest.Mock).mockResolvedValue(result);

      await controller.resendOtp(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.resendOtp).toHaveBeenCalledWith(
        req.body,
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        result.message,
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Could not resend OTP');

      (authService.resendOtp as jest.Mock).mockRejectedValue(error);

      await controller.resendOtp(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('registerClinic', () => {
    it('should register clinic, set cookie, and return created response', async () => {
      const result = {
        token: 'clinic-token',
        user: { id: 'clinic-1' },
      };

      req.body = {
        email: 'clinic@example.com',
      };

      (authService.registerClinic as jest.Mock).mockResolvedValue(result);

      await controller.registerClinic(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.registerClinic).toHaveBeenCalledWith(
        req.body,
        req.ip,
      );

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'clinic-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        result,
        'Clinic registered successfully',
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Clinic registration failed');

      (authService.registerClinic as jest.Mock).mockRejectedValue(error);

      await controller.registerClinic(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('loginClinic', () => {
    it('should login clinic, set cookie, and return success', async () => {
      const result = {
        token: 'clinic-token',
        user: { id: 'clinic-1' },
      };

      req.body = {
        email: 'clinic@example.com',
        password: 'password',
      };

      (authService.loginClinic as jest.Mock).mockResolvedValue(result);

      await controller.loginClinic(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.loginClinic).toHaveBeenCalledWith(req.body);

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'clinic-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        'Login successful',
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Clinic login failed');

      (authService.loginClinic as jest.Mock).mockRejectedValue(error);

      await controller.loginClinic(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('registerDoctor', () => {
    it('should register doctor, set cookie, and return created response', async () => {
      const result = {
        token: 'doctor-token',
        user: { id: 'doctor-1' },
      };

      req.body = {
        email: 'doctor@example.com',
      };

      (authService.registerDoctor as jest.Mock).mockResolvedValue(result);

      await controller.registerDoctor(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.registerDoctor).toHaveBeenCalledWith(
        req.body,
        req.ip,
      );

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'doctor-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        result,
        'Doctor registered successfully',
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Doctor registration failed');

      (authService.registerDoctor as jest.Mock).mockRejectedValue(error);

      await controller.registerDoctor(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('loginDoctor', () => {
    it('should login doctor, set cookie, and return success', async () => {
      const result = {
        token: 'doctor-token',
        user: { id: 'doctor-1' },
      };

      req.body = {
        email: 'doctor@example.com',
        password: 'password',
      };

      (authService.loginDoctor as jest.Mock).mockResolvedValue(result);

      await controller.loginDoctor(
        req as Request,
        res as Response,
        next,
      );

      expect(authService.loginDoctor).toHaveBeenCalledWith(
        req.body,
      );

      expect(res.cookie).toHaveBeenCalledWith(
        'token',
        'doctor-token',
        expect.objectContaining({
          httpOnly: true,
          sameSite: 'strict',
          path: '/',
        }),
      );

      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        result,
        'Login successful',
      );
    });

    it('should forward service errors to next', async () => {
      const error = new Error('Doctor login failed');

      (authService.loginDoctor as jest.Mock).mockRejectedValue(error);

      await controller.loginDoctor(
        req as Request,
        res as Response,
        next,
      );

      expect(next).toHaveBeenCalledWith(error);
    });
  });
});

