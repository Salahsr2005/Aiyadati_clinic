import { AppointmentService } from '../../../../../src/modules/appointment/v1/appointment.service';
import { slotRepository } from '../../../../../src/repositories/slot.repository';
import { appointmentRepository } from '../../../../../src/repositories/appointment.repository';
import { doctorConfigRepository } from '../../../../../src/repositories/doctor-config.repository';
import { doctorRepository } from '../../../../../src/repositories/doctor.repository';
import { doctorAvailabilityRepository } from '../../../../../src/repositories/doctor-availability.repository';
import { doctorBreakRepository } from '../../../../../src/repositories/doctor-break.repository';
import { walletRepository } from '../../../../../src/repositories/wallet.repository';
import { creditPriceRepository } from '../../../../../src/repositories/credit-price.repository';
import { providerEarningRepository } from '../../../../../src/repositories/provider-earning.repository';
import { providerBalanceRepository } from '../../../../../src/repositories/provider-balance.repository';
import { guestPatientRepository } from '../../../../../src/repositories/guest-patient.repository';
import { eventEmitter } from '../../../../../src/core/events/event-emitter';
import { prisma } from '../../../../../src/core/utils/prisma';
import {
  NotFoundError,
  BadRequestError,
  ConflictError,
} from '../../../../../src/core/utils/error';
import { nowAlgeria, getSlotStartDateTimeAlgeria, isSlotInPastAlgeria } from '../../../../../src/core/utils/timezone';

// Mock all dependencies with correct paths
jest.mock('../../../../../src/repositories/slot.repository');
jest.mock('../../../../../src/repositories/appointment.repository');
jest.mock('../../../../../src/repositories/doctor-config.repository');
jest.mock('../../../../../src/repositories/doctor.repository');
jest.mock('../../../../../src/repositories/doctor-availability.repository');
jest.mock('../../../../../src/repositories/doctor-break.repository');
jest.mock('../../../../../src/repositories/wallet.repository');
jest.mock('../../../../../src/repositories/credit-price.repository');
jest.mock('../../../../../src/repositories/provider-earning.repository');
jest.mock('../../../../../src/repositories/provider-balance.repository');
jest.mock('../../../../../src/repositories/guest-patient.repository');
jest.mock('../../../../../src/core/events/event-emitter');

// Mock timezone functions individually so we can control them
jest.mock('../../../../../src/core/utils/timezone', () => ({
  nowAlgeria: jest.fn(),
  getSlotStartDateTimeAlgeria: jest.fn(),
  isSlotInPastAlgeria: jest.fn(),
  toAlgeriaTime: jest.fn(),
}));

// Type for the transaction callback
type TransactionCallback = (tx: any) => any;

// Create the transaction object that will be returned
const createTransactionMock = () => ({
  $queryRaw: jest.fn(),
  slot: {
    findUnique: jest.fn(),
    update: jest.fn(),
    findMany: jest.fn(),
  },
  appointment: {
    count: jest.fn().mockResolvedValue(0),
    create: jest.fn(),
    update: jest.fn(),
    findUnique: jest.fn(),
    findMany: jest.fn(),
  },
  doctor: {
    findUnique: jest.fn(),
  },
  user: {
    update: jest.fn(),
    findUnique: jest.fn(),
  },
  userWallet: {
    findUnique: jest.fn(),
    upsert: jest.fn(),
    update: jest.fn(),
  },
  creditTransaction: {
    create: jest.fn(),
  },
  providerEarning: {
    create: jest.fn(),
  },
  providerBalance: {
    upsert: jest.fn(),
  },
  guestPatient: {
    create: jest.fn(),
    findFirst: jest.fn(),
    findUnique: jest.fn(),
  },
});

// Mock the prisma module - define mockPrisma INSIDE the factory function
jest.mock('../../../../../src/core/utils/prisma', () => {
  const mockPrisma: any = {
    appointment: {
      count: jest.fn().mockResolvedValue(0),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    slot: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      createMany: jest.fn(),
      update: jest.fn(),
      updateMany: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
    clinicDoctor: {
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    clinicRoom: {
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
    },
    doctor: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    userWallet: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      upsert: jest.fn(),
    },
    creditTransaction: {
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    providerEarning: {
      create: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
    providerBalance: {
      upsert: jest.fn(),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    guestPatient: {
      create: jest.fn(),
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    slotGenerationRule: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      upsert: jest.fn(),
      update: jest.fn(),
    },
    $transaction: jest.fn((callback: TransactionCallback) => callback(createTransactionMock())),
  };

  return { prisma: mockPrisma };
});

// Now we can reference the mocked prisma in our tests
const mockPrisma = (prisma as any);

describe('AppointmentService', () => {
  let appointmentService: AppointmentService;

  // ============================================================
  // MOCK DATA
  // ============================================================

  const mockDoctor = {
    id: 'doctor-123',
    email: 'doctor@example.com',
    firstNameFr: 'Ahmed',
    lastNameFr: 'Benali',
    isVerified: true,
    isSuspended: false,
    isAvailableForBooking: true,
    messageForUser: null,
  };

  const mockDoctorNotAvailable = {
    ...mockDoctor,
    isAvailableForBooking: false,
    messageForUser: 'On vacation until September',
  };

  const mockSlot = {
    id: 'slot-123',
    doctorId: 'doctor-123',
    clinicId: null,
    roomId: null,
    date: new Date('2026-08-20'),
    startTime: new Date('1970-01-01T09:00:00.000Z'),
    endTime: new Date('1970-01-01T09:30:00.000Z'),
    status: 'available',
    maxPatients: 3,
    slotKey: 'doctor-123:2026-08-20:09:00:none:none',
  };

  const mockSlotWithClinic = {
    ...mockSlot,
    clinicId: 'clinic-123',
  };

  const mockConfig = {
    id: 'config-123',
    doctorId: 'doctor-123',
    slotDuration: 30,
    bufferTime: 5,
    maxPerSlot: 3,
  };

  const mockWallet = {
    id: 'wallet-123',
    userId: 'user-123',
    credits: 5,
  };

  const mockCreditPrice = {
    id: 'price-123',
    price: 10,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockUser = {
    id: 'user-123',
    email: 'user@example.com',
    firstName: 'John',
    lastName: 'Doe',
    phone: '0555123456',
    isVerified: true,
    isSuspended: false,
    trustPoints: 5,
    trustLevel: 2,
  };

  const mockGuestPatient = {
    id: 'guest-123',
    firstName: 'Guest',
    lastName: 'Patient',
    phone: '0555987654',
    email: 'guest@example.com',
    createdBy: 'doctor-123',
    createdByType: 'DOCTOR',
  };

  const mockAppointment = {
    id: 'appointment-123',
    slotId: 'slot-123',
    doctorId: 'doctor-123',
    patientId: 'user-123',
    guestPatientId: null,
    patientType: 'REGISTERED',
    clinicId: null,
    type: 'IN_PERSON',
    paymentMethod: 'CREDIT',
    status: 'PENDING',
    notes: null,
    createdBy: 'user-123',
    createdByType: 'user',
    creditPriceAtBooking: 10,
    creditPriceId: 'price-123',
    confirmedAt: null,
    confirmedBy: null,
    cancelledAt: null,
    cancelledBy: null,
    cancelReason: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    slot: mockSlot,
    doctor: mockDoctor,
    patient: mockUser,
    clinic: null,
    contactUser: null,
    guestPatient: null,
  };

  const mockAppointmentGuest = {
    ...mockAppointment,
    id: 'appointment-guest-123',
    patientId: null,
    guestPatientId: 'guest-123',
    patientType: 'GUEST',
    paymentMethod: 'ON_SITE',
    createdByType: 'doctor',
    guestPatient: mockGuestPatient,
  };

  const mockAppointmentClinicBooked = {
    ...mockAppointment,
    id: 'appointment-clinic-123',
    createdByType: 'clinic',
    clinicId: 'clinic-123',
  };

  const mockAvailability = [
    {
      id: 'avail-1',
      doctorId: 'doctor-123',
      dayOfWeek: 'THURSDAY',
      startTime: new Date('1970-01-01T08:00:00.000Z'),
      endTime: new Date('1970-01-01T17:00:00.000Z'),
      isActive: true,
      clinicId: null,
      roomId: null,
    },
  ];

  const mockBreak = {
    id: 'break-1',
    doctorId: 'doctor-123',
    startDate: new Date('2026-08-20'),
    endDate: new Date('2026-08-20'),
    reason: 'Lunch',
    isAllDay: false,
    startTime: new Date('1970-01-01T12:00:00.000Z'),
    endTime: new Date('1970-01-01T13:00:00.000Z'),
  };

  const mockBreakAllDay = {
    ...mockBreak,
    isAllDay: true,
    startTime: null,
    endTime: null,
  };

  beforeEach(() => {
    appointmentService = new AppointmentService();
    jest.clearAllMocks();
    jest.resetAllMocks();

    // Default mock for timezone functions
    (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));
    (getSlotStartDateTimeAlgeria as jest.Mock).mockImplementation((date, time) => {
      const result = new Date(date);
      result.setHours(time.getHours(), time.getMinutes(), 0, 0);
      return result;
    });
    (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);

    // Reset mock implementations for each test
    if (mockPrisma) {
      mockPrisma.appointment.count.mockResolvedValue(0);
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);
      mockPrisma.user.update.mockResolvedValue(mockUser);
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => callback(createTransactionMock()));
    }
  });

  // ============================================================
  // CONFIG TESTS
  // ============================================================

  describe('getDoctorConfig', () => {
    it('should return doctor config when it exists', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockConfig
      );

      const result = await appointmentService.getDoctorConfig('doctor-123');

      expect(doctorConfigRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(result).toEqual({
        id: mockConfig.id,
        doctorId: mockConfig.doctorId,
        slotDuration: mockConfig.slotDuration,
        bufferTime: mockConfig.bufferTime,
        maxPerSlot: mockConfig.maxPerSlot,
      });
    });

    it('should return null when config does not exist', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        null
      );

      const result = await appointmentService.getDoctorConfig('doctor-123');

      expect(result).toBeNull();
    });
  });

  describe('setDoctorConfig', () => {
    it('should set doctor config successfully', async () => {
      const configData = {
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      };

      (doctorConfigRepository.upsert as jest.Mock).mockResolvedValue({
        id: 'config-123',
        doctorId: 'doctor-123',
        ...configData,
      });

      const result = await appointmentService.setDoctorConfig(
        'doctor-123',
        configData
      );

      expect(doctorConfigRepository.upsert).toHaveBeenCalledWith('doctor-123', {
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      });
      expect(result).toEqual({
        id: 'config-123',
        doctorId: 'doctor-123',
        slotDuration: 45,
        bufferTime: 10,
        maxPerSlot: 2,
      });
    });

    it('should use default maxPerSlot when not provided', async () => {
      const configData = {
        slotDuration: 30,
        bufferTime: 5,
      };

      (doctorConfigRepository.upsert as jest.Mock).mockResolvedValue({
        id: 'config-123',
        doctorId: 'doctor-123',
        ...configData,
        maxPerSlot: 1,
      });

      await appointmentService.setDoctorConfig('doctor-123', configData);

      expect(doctorConfigRepository.upsert).toHaveBeenCalledWith('doctor-123', {
        slotDuration: 30,
        bufferTime: 5,
        maxPerSlot: 1,
      });
    });
  });

  // ============================================================
  // GENERATE SLOTS TESTS
  // ============================================================

  describe('generateSlots', () => {
    const generateData = {
      startDate: '2026-08-20',
      endDate: '2026-08-20',
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockConfig
      );
      (
        doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock
      ).mockResolvedValue(mockAvailability);
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue(
        []
      );
      (slotRepository.deleteByDoctorAndDateRange as jest.Mock).mockResolvedValue(
        5
      );
      (slotRepository.createMany as jest.Mock).mockResolvedValue({ count: 5 });
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([
        { ...mockSlot, status: 'available' },
      ]);
      if (mockPrisma) {
        mockPrisma.appointment.count.mockResolvedValue(0);
      }
    });

    it('should generate slots successfully for a doctor', async () => {
      const result = await appointmentService.generateSlots(
        'doctor-123',
        generateData,
        'doctor-123',
        'DOCTOR'
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorConfigRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(
        doctorAvailabilityRepository.findByDoctorAndDay
      ).toHaveBeenCalledWith('doctor-123', 'THURSDAY');
      expect(doctorBreakRepository.findByDoctorAndDateRange).toHaveBeenCalled();
      expect(slotRepository.deleteByDoctorAndDateRange).toHaveBeenCalled();
      expect(slotRepository.createMany).toHaveBeenCalled();
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });

    it('should throw error when doctor is not verified', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        appointmentService.generateSlots(
          'doctor-123',
          generateData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when doctor is suspended', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isSuspended: true,
      });

      await expect(
        appointmentService.generateSlots(
          'doctor-123',
          generateData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when clinic tries to generate for doctor not in clinic', async () => {
      if (mockPrisma) {
        mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);
      }

      await expect(
        appointmentService.generateSlots(
          'doctor-123',
          generateData,
          'clinic-123',
          'CLINIC'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should handle all-day breaks correctly', async () => {
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue([
        mockBreakAllDay,
      ]);
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([]);

      const result = await appointmentService.generateSlots(
        'doctor-123',
        generateData,
        'doctor-123',
        'DOCTOR'
      );

      expect(slotRepository.createMany).not.toHaveBeenCalled();
      expect(result).toHaveLength(0);
    });

    it('should respect buffer time between slots', async () => {
      await appointmentService.generateSlots(
        'doctor-123',
        generateData,
        'doctor-123',
        'DOCTOR'
      );

      expect(slotRepository.createMany).toHaveBeenCalled();
    });

    it('should use clinicId from request when user is clinic', async () => {
      if (mockPrisma) {
        mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
          id: 'link-1',
          clinicId: 'clinic-123',
          doctorId: 'doctor-123',
          status: 'ACCEPTED',
          isActive: true,
        });
      }

      await appointmentService.generateSlots(
        'doctor-123',
        { ...generateData, clinicId: 'clinic-123' },
        'clinic-123',
        'CLINIC'
      );

      expect(slotRepository.createMany).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({
            clinicId: 'clinic-123',
          }),
        ])
      );
    });

    it('should throw error when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        appointmentService.generateSlots(
          'non-existent',
          generateData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // GET SLOTS TESTS
  // ============================================================

  describe('getSlots', () => {
    it('should return slots for a doctor on a date', async () => {
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([
        mockSlot,
      ]);
      if (mockPrisma) {
        mockPrisma.appointment.count.mockResolvedValue(0);
      }

      const result = await appointmentService.getSlots(
        'doctor-123',
        '2026-08-20'
      );

      expect(slotRepository.findByDoctorAndDate).toHaveBeenCalledWith(
        'doctor-123',
        '2026-08-20'
      );
      expect(result).toHaveLength(1);
      expect(result[0].id).toBe('slot-123');
      expect(result[0].date).toBe('2026-08-20');
    });

    it('should return empty array when no slots', async () => {
      (slotRepository.findByDoctorAndDate as jest.Mock).mockResolvedValue([]);

      const result = await appointmentService.getSlots(
        'doctor-123',
        '2026-08-20'
      );

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // GET AVAILABLE SLOTS TESTS
  // ============================================================

  describe('getAvailableSlots', () => {
    it('should return only available slots for a doctor on a date', async () => {
      (slotRepository.findAvailableByDoctorAndDate as jest.Mock).mockResolvedValue([
        mockSlot,
      ]);
      if (mockPrisma) {
        mockPrisma.appointment.count.mockResolvedValue(0);
      }

      const result = await appointmentService.getAvailableSlots(
        'doctor-123',
        '2026-08-20'
      );

      expect(slotRepository.findAvailableByDoctorAndDate).toHaveBeenCalledWith(
        'doctor-123',
        '2026-08-20'
      );
      expect(result).toBeDefined();
      expect(result[0].id).toBe('slot-123');
    });

    it('should return empty array when no available slots', async () => {
      (slotRepository.findAvailableByDoctorAndDate as jest.Mock).mockResolvedValue(
        []
      );

      const result = await appointmentService.getAvailableSlots(
        'doctor-123',
        '2026-08-20'
      );

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // CANCEL SLOT TESTS
  // ============================================================

  describe('cancelSlot', () => {
    const slotWithAppointments = {
      ...mockSlot,
      date: new Date('2026-08-20'),
    };

    const mockAppointments = [
      {
        id: 'app-1',
        patientId: 'user-123',
        patientType: 'REGISTERED',
        paymentMethod: 'CREDIT',
        slot: slotWithAppointments,
        patient: mockUser,
        guestPatient: null,
      },
      {
        id: 'app-2',
        patientId: null,
        guestPatientId: 'guest-123',
        patientType: 'GUEST',
        paymentMethod: 'ON_SITE',
        slot: slotWithAppointments,
        patient: null,
        guestPatient: mockGuestPatient,
      },
    ];

    beforeEach(() => {
      (slotRepository.findById as jest.Mock).mockResolvedValue(slotWithAppointments);
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.update.mockResolvedValue({});
        tx.appointment.findMany.mockResolvedValue(mockAppointments);
        tx.appointment.update.mockResolvedValue({});
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });
    });

    it('should cancel slot as doctor successfully', async () => {
      await appointmentService.cancelSlot('slot-123', 'doctor-123', 'DOCTOR');

      expect(slotRepository.findById).toHaveBeenCalledWith('slot-123');
      expect(mockPrisma.$transaction).toHaveBeenCalled();
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: 'Appointment Cancelled',
        })
      );
    });

    it('should cancel slot as clinic successfully', async () => {
      const clinicSlot = { ...slotWithAppointments, clinicId: 'clinic-123' };
      (slotRepository.findById as jest.Mock).mockResolvedValue(clinicSlot);

      await appointmentService.cancelSlot('slot-123', 'clinic-123', 'CLINIC');

      expect(slotRepository.findById).toHaveBeenCalledWith('slot-123');
    });

    it('should refund credits for registered patients', async () => {
      await appointmentService.cancelSlot('slot-123', 'doctor-123', 'DOCTOR');

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should NOT refund credits for guest patients', async () => {
      await appointmentService.cancelSlot('slot-123', 'doctor-123', 'DOCTOR');
    });

    it('should throw NotFoundError when slot not found', async () => {
      (slotRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        appointmentService.cancelSlot('non-existent', 'doctor-123', 'DOCTOR')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor tries to cancel not their slot', async () => {
      const otherDoctorSlot = { ...slotWithAppointments, doctorId: 'doctor-456' };
      (slotRepository.findById as jest.Mock).mockResolvedValue(otherDoctorSlot);

      await expect(
        appointmentService.cancelSlot('slot-123', 'doctor-123', 'DOCTOR')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when clinic tries to cancel not their clinic slot', async () => {
      const otherClinicSlot = { ...slotWithAppointments, clinicId: 'clinic-456' };
      (slotRepository.findById as jest.Mock).mockResolvedValue(otherClinicSlot);

      await expect(
        appointmentService.cancelSlot('slot-123', 'clinic-123', 'CLINIC')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // CANCEL SLOTS BY DATE TESTS
  // ============================================================

  describe('cancelSlotsByDate', () => {
    const cancelData = {
      date: '2026-08-20',
      reason: 'Holiday',
    };

    const mockSlotsWithAppointments = [
      {
        ...mockSlot,
        date: new Date('2026-08-20'),
        appointments: [
          {
            id: 'app-1',
            patientId: 'user-123',
            patientType: 'REGISTERED',
            paymentMethod: 'CREDIT',
            patient: mockUser,
            guestPatient: null,
          },
        ],
      },
    ];

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.findMany.mockResolvedValue(mockSlotsWithAppointments);
        tx.slot.update.mockResolvedValue({});
        tx.appointment.update.mockResolvedValue({});
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });
    });

    it('should cancel slots by date as doctor', async () => {
      const result = await appointmentService.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'doctor-123',
        'DOCTOR'
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(result).toBe(1);
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: 'Appointment Cancelled',
        })
      );
    });

    it('should cancel slots by date as clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });

      const result = await appointmentService.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'clinic-123',
        'CLINIC'
      );

      expect(result).toBe(1);
    });

    it('should throw NotFoundError when doctor not found', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        appointmentService.cancelSlotsByDate(
          'non-existent',
          cancelData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor tries to cancel not their account', async () => {
      await expect(
        appointmentService.cancelSlotsByDate(
          'doctor-123',
          cancelData,
          'doctor-456',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when clinic tries to cancel for doctor not in clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);

      await expect(
        appointmentService.cancelSlotsByDate(
          'doctor-123',
          cancelData,
          'clinic-123',
          'CLINIC'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should return 0 when no slots found', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.slot.findMany.mockResolvedValue([]);
        tx.slot.update.mockResolvedValue({});
        tx.appointment.update.mockResolvedValue({});
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.cancelSlotsByDate(
        'doctor-123',
        cancelData,
        'doctor-123',
        'DOCTOR'
      );

      expect(result).toBe(0);
    });
  });

  // ============================================================
  // BOOK APPOINTMENT TESTS
  // ============================================================

  describe('bookAppointment', () => {
    const bookData = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      paymentMethod: 'CREDIT' as const,
      patientId: 'user-123',
      notes: 'First visit',
    };

    const bookDataGuest = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      paymentMethod: 'ON_SITE' as const,
      guestPatient: {
        firstName: 'Guest',
        lastName: 'Patient',
        phone: '0555987654',
        email: 'guest@example.com',
      },
      notes: 'Walk-in',
    };

    beforeEach(() => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue(
        mockSlot
      );
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (creditPriceRepository.getLatest as jest.Mock).mockResolvedValue(
        mockCreditPrice
      );
      (walletRepository.getOrCreate as jest.Mock).mockResolvedValue(mockWallet);

      // Default transaction mock for booking tests
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });
    });

    // ===== SUCCESS CASES =====

    it('should book an appointment successfully with credit payment', async () => {
      const result = await appointmentService.bookAppointment(
        bookData,
        'user-123',
        'USER'
      );

      expect(result).toBeDefined();
      expect(result.id).toBe('appointment-123');
      expect(result.status).toBe('PENDING');
      expect(result.patientType).toBe('REGISTERED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: '📋 Pending Appointment Request',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '⏳ Appointment Request Pending',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'appointment.created',
          entity: 'Appointment',
          entityId: 'appointment-123',
          performedBy: 'user-123',
        })
      );
    });

    it('should book an appointment with ON_SITE payment', async () => {
      const onSiteData = {
        ...bookData,
        paymentMethod: 'ON_SITE' as const,
      };

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointment,
          paymentMethod: 'ON_SITE',
        });
        tx.appointment.findUnique.mockResolvedValue({
          ...mockAppointment,
          paymentMethod: 'ON_SITE',
        });
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await appointmentService.bookAppointment(
        onSiteData,
        'user-123',
        'USER'
      );

      expect(result.paymentMethod).toBe('ON_SITE');
    });

    it('should book an appointment as DOCTOR role', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointment,
          createdBy: 'doctor-123',
          createdByType: 'doctor',
        });
        tx.appointment.findUnique.mockResolvedValue({
          ...mockAppointment,
          createdBy: 'doctor-123',
          createdByType: 'doctor',
        });
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await appointmentService.bookAppointment(
        bookData,
        'doctor-123',
        'DOCTOR'
      );

      expect(result.createdBy).toBe('doctor-123');
      expect(result.createdByType).toBe('doctor');
    });

    it('should create wallet transaction when using credits', async () => {
      await appointmentService.bookAppointment(bookData, 'user-123', 'USER');

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should update slot status to full when maxPatients reached', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue({ ...mockSlot, status: 'full' });
        tx.appointment.count.mockResolvedValue(2);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await appointmentService.bookAppointment(bookData, 'user-123', 'USER');

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    // ===== GUEST PATIENT TESTS =====

    it('should book an appointment with guest patient', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointmentGuest);
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null);
        tx.userWallet.findUnique.mockResolvedValue(null);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await appointmentService.bookAppointment(
        bookDataGuest,
        'doctor-123',
        'DOCTOR'
      );

      expect(result.patientType).toBe('GUEST');
      expect(result.paymentMethod).toBe('ON_SITE');
      expect(result.guestPatient).toBeDefined();
      expect(result.guestPatient?.firstName).toBe('Guest');
      expect(result.patientId).toBeNull();
    });

    it('should reuse existing guest patient by phone', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointmentGuest,
          guestPatient: mockGuestPatient,
        });
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null);
        tx.userWallet.findUnique.mockResolvedValue(null);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findUnique.mockResolvedValue(mockGuestPatient);
        return callback(tx);
      });

      const result = await appointmentService.bookAppointment(
        bookDataGuest,
        'doctor-123',
        'DOCTOR'
      );

      expect(result.guestPatientId).toBe('guest-123');
    });

    it('should use registered user if phone exists as registered user', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await appointmentService.bookAppointment(
        bookDataGuest,
        'doctor-123',
        'DOCTOR'
      );

      expect(result.patientType).toBe('REGISTERED');
      expect(result.patientId).toBe('user-123');
    });

    // ===== IDEMPOTENCY TESTS =====

    it('should handle idempotency key - return existing appointment', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue({
          ...mockAppointment,
          idempotencyKey: 'idempotent-key-123',
        });
        tx.appointment.findUnique.mockResolvedValue({
          ...mockAppointment,
          idempotencyKey: 'idempotent-key-123',
        });
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result1 = await appointmentService.bookAppointment(
        bookData,
        'user-123',
        'USER',
        'idempotent-key-123'
      );

      const result2 = await appointmentService.bookAppointment(
        bookData,
        'user-123',
        'USER',
        'idempotent-key-123'
      );

      expect(result1.id).toBe(result2.id);
    });

    // ===== ERROR CASES - WITH FIXED MOCKS =====

    it('should throw error when slot is full', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(3);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow(ConflictError);
    });

    // FIXED: Doctor availability - mock inside transaction
    it('should throw error when doctor is not available for booking', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctorNotAvailable);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow(BadRequestError);
    });

    // FIXED: Doctor with custom message - mock inside transaction
    it('should throw error with custom message when doctor has messageForUser', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue({
          ...mockDoctorNotAvailable,
          messageForUser: 'Returns from vacation on 1 September',
        });
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow(
        'Doctor is not currently accepting bookings. Returns from vacation on 1 September'
      );
    });

    it('should throw error when slot is cancelled', async () => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockRejectedValue(
        new Error('This slot has been cancelled')
      );

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow('This slot has been cancelled');
    });

    it('should throw error when slot has already passed', async () => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockRejectedValue(
        new Error('This slot has already passed')
      );

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow('This slot has already passed');
    });

    it('should throw error when slot is not found', async () => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockRejectedValue(
        new Error('Slot not found')
      );

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow('Slot not found');
    });

    it('should throw error when user has insufficient credits', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(null);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when patient is suspended', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123', credits: 4 }]);
        tx.slot.findUnique.mockResolvedValue(mockSlot);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointment);
        tx.appointment.findUnique.mockResolvedValue(mockAppointment);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue({
          ...mockUser,
          isSuspended: true,
        });
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      await expect(
        appointmentService.bookAppointment(bookData, 'user-123', 'USER')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when neither patientId nor guestPatient provided', async () => {
      const invalidData = {
        slotId: 'slot-123',
        type: 'IN_PERSON' as const,
      };

      await expect(
        appointmentService.bookAppointment(invalidData as any, 'user-123', 'USER')
      ).rejects.toThrow(BadRequestError);
    });

    // FIXED: Both patientId and guestPatient provided - now works with service guard
    it('should throw error when both patientId and guestPatient provided', async () => {
      const invalidData = {
        slotId: 'slot-123',
        patientId: 'user-123',
        guestPatient: {
          firstName: 'Guest',
          lastName: 'Patient',
          phone: '0555987654',
        },
      };

      await expect(
        appointmentService.bookAppointment(invalidData as any, 'user-123', 'USER')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // CLINIC BOOK APPOINTMENT TESTS - FIXED
  // ============================================================

  describe('clinicBookAppointment', () => {
    const clinicBookData = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      patientId: 'user-123',
      notes: 'Clinic booking',
    };

    const clinicBookDataGuest = {
      slotId: 'slot-123',
      type: 'IN_PERSON' as const,
      guestPatient: {
        firstName: 'Guest',
        lastName: 'Patient',
        phone: '0555987654',
      },
    };

    beforeEach(() => {
      // Mock validateSlotIsBookable for clinic tests
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue(mockSlotWithClinic);

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlotWithClinic);
        tx.slot.update.mockResolvedValue(mockSlotWithClinic);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointmentClinicBooked);
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentClinicBooked);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });
    });

    it('should book appointment for registered patient as clinic', async () => {
      const result = await appointmentService.clinicBookAppointment(
        clinicBookData,
        'clinic-123'
      );

      expect(result).toBeDefined();
      expect(result.createdByType).toBe('clinic');
      expect(result.clinicId).toBe('clinic-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: '📋 Pending Appointment Request',
        })
      );
    });

    it('should book appointment for guest patient as clinic', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.slot.findUnique.mockResolvedValue(mockSlotWithClinic);
        tx.slot.update.mockResolvedValue(mockSlotWithClinic);
        tx.appointment.count.mockResolvedValue(0);
        tx.appointment.create.mockResolvedValue(mockAppointmentGuest);
        tx.appointment.findUnique.mockResolvedValue(mockAppointmentGuest);
        tx.doctor.findUnique.mockResolvedValue(mockDoctor);
        tx.user.findUnique.mockResolvedValue(null);
        tx.userWallet.findUnique.mockResolvedValue(null);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.guestPatient.create.mockResolvedValue(mockGuestPatient);
        tx.guestPatient.findFirst.mockResolvedValue(null);
        tx.guestPatient.findUnique.mockResolvedValue(null);
        return callback(tx);
      });

      const result = await appointmentService.clinicBookAppointment(
        clinicBookDataGuest,
        'clinic-123'
      );

      expect(result.patientType).toBe('GUEST');
      expect(result.paymentMethod).toBe('ON_SITE');
    });

    it('should throw error when slot does not belong to clinic', async () => {
      (slotRepository.validateSlotIsBookable as jest.Mock).mockResolvedValue({
        ...mockSlot,
        clinicId: 'clinic-456',
      });

      await expect(
        appointmentService.clinicBookAppointment(clinicBookData, 'clinic-123')
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when slot is full', async () => {
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.$queryRaw.mockResolvedValue([{ id: 'slot-123' }]);
        tx.appointment.count.mockResolvedValue(3);
        return callback(tx);
      });

      await expect(
        appointmentService.clinicBookAppointment(clinicBookData, 'clinic-123')
      ).rejects.toThrow(ConflictError);
    });
  });

  // ============================================================
  // CONFIRM APPOINTMENT TESTS
  // ============================================================

  describe('confirmAppointment', () => {
    const pendingAppointment = {
      ...mockAppointment,
      status: 'PENDING',
    };

    beforeEach(() => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(
        pendingAppointment
      );
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({
          ...pendingAppointment,
          status: 'CONFIRMED',
          confirmedAt: new Date(),
          confirmedBy: 'doctor-123',
        });
        return callback(tx);
      });
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
    });

    it('should confirm appointment as doctor', async () => {
      const result = await appointmentService.confirmAppointment(
        'appointment-123',
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('CONFIRMED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '✅ Appointment Confirmed',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'appointment.confirmed',
          entity: 'Appointment',
          entityId: 'appointment-123',
          performedBy: 'doctor-123',
        })
      );
    });

    it('should confirm appointment as clinic', async () => {
      const clinicAppointment = {
        ...pendingAppointment,
        clinicId: 'clinic-123',
      };
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(
        clinicAppointment
      );

      const result = await appointmentService.confirmAppointment(
        'appointment-123',
        'clinic-123',
        'CLINIC'
      );

      expect(result.status).toBe('CONFIRMED');
    });

    it('should confirm guest appointment', async () => {
      const guestAppointment = {
        ...pendingAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      };
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(
        guestAppointment
      );

      const result = await appointmentService.confirmAppointment(
        'appointment-123',
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('CONFIRMED');
      const notificationCalls = (eventEmitter.emit as jest.Mock).mock.calls.filter(
        call => call[0] === 'notification'
      );
      expect(notificationCalls.length).toBe(0);
    });

    it('should throw error when appointment not found', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        appointmentService.confirmAppointment(
          'appointment-123',
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw error when user is not doctor or clinic', async () => {
      await expect(
        appointmentService.confirmAppointment(
          'appointment-123',
          'user-123',
          'USER'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when doctor tries to confirm not their appointment', async () => {
      const otherDoctorAppointment = {
        ...pendingAppointment,
        doctorId: 'doctor-456',
      };
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(
        otherDoctorAppointment
      );

      await expect(
        appointmentService.confirmAppointment(
          'appointment-123',
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when appointment is not PENDING', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        status: 'CONFIRMED',
      });

      await expect(
        appointmentService.confirmAppointment(
          'appointment-123',
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // UPDATE STATUS TESTS - COMPLETELY FIXED
  // ============================================================

  describe('updateStatus', () => {
    const pendingAppointment = {
      ...mockAppointment,
      status: 'PENDING',
      slot: mockSlot,
      doctor: mockDoctor,
    };
    const confirmedAppointment = {
      ...pendingAppointment,
      status: 'CONFIRMED',
    };

    beforeEach(() => {
      // Default transaction mock
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...pendingAppointment, status: 'CONFIRMED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.providerEarning.create.mockResolvedValue({});
        tx.providerBalance.upsert.mockResolvedValue({});
        return callback(tx);
      });

      // updateTrustPoints() calls prisma.user.update() directly, outside the transaction
      mockPrisma.user.update.mockResolvedValue({ ...mockUser, trustPoints: mockUser.trustPoints - 1, trustLevel: 1 });

      (walletRepository.getOrCreate as jest.Mock).mockResolvedValue(mockWallet);
    });

    // ===== CONFIRMED TESTS =====

    it('should confirm appointment via updateStatus', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(pendingAppointment)
        .mockResolvedValueOnce({ ...pendingAppointment, status: 'CONFIRMED', confirmedAt: new Date(), confirmedBy: 'doctor-123' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CONFIRMED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('CONFIRMED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '✅ Appointment Confirmed',
        })
      );
    });

    // ===== CANCELLATION TESTS =====

    it('should cancel appointment as patient (>= 3 days before - refund)', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 5);
      const futureAppointment = {
        ...pendingAppointment,
        slot: {
          ...mockSlot,
          date: appointmentDate,
          startTime: new Date('1970-01-01T09:00:00.000Z'),
        },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      // Override transaction for cancellation
      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...futureAppointment, status: 'CANCELLED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Patient request' },
        'user-123',
        'USER'
      );

      expect(result.status).toBe('CANCELLED');
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should cancel appointment as patient (< 3 days before - NO refund)', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 2);
      const futureAppointment = {
        ...pendingAppointment,
        slot: {
          ...mockSlot,
          date: appointmentDate,
          startTime: new Date('1970-01-01T09:00:00.000Z'),
        },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...futureAppointment, status: 'CANCELLED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Changed my mind' },
        'user-123',
        'USER'
      );

      expect(result.status).toBe('CANCELLED');
    });

    it('should cancel appointment exactly 3 days before (refund)', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 3);
      const futureAppointment = {
        ...pendingAppointment,
        slot: {
          ...mockSlot,
          date: appointmentDate,
          startTime: new Date('1970-01-01T09:00:00.000Z'),
        },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...futureAppointment, status: 'CANCELLED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Patient request' },
        'user-123',
        'USER'
      );

      expect(result.status).toBe('CANCELLED');
    });

    it('should cancel appointment as provider - always refund', async () => {
      const appointmentDate = new Date();
      appointmentDate.setDate(appointmentDate.getDate() + 1);
      const futureAppointment = {
        ...pendingAppointment,
        slot: {
          ...mockSlot,
          date: appointmentDate,
          startTime: new Date('1970-01-01T09:00:00.000Z'),
        },
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(futureAppointment)
        .mockResolvedValueOnce({ ...futureAppointment, status: 'CANCELLED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...futureAppointment, status: 'CANCELLED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Provider unavailable' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('CANCELLED');
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should cancel guest appointment (no refund, no trust points)', async () => {
      const guestAppointment = {
        ...pendingAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
        paymentMethod: 'ON_SITE',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(guestAppointment)
        .mockResolvedValueOnce({ ...guestAppointment, status: 'CANCELLED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...guestAppointment, status: 'CANCELLED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        return callback(tx);
      });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'CANCELLED', cancelReason: 'Cancelled' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('CANCELLED');
      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    // ===== NO_SHOW TESTS =====

    it('should mark appointment as NO_SHOW and update trust points', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(confirmedAppointment)
        .mockResolvedValueOnce({ ...confirmedAppointment, status: 'NO_SHOW' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('NO_SHOW');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '⚠️ Missed Appointment',
        })
      );
    });

    it('should suspend user after 3 no-shows', async () => {
      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(confirmedAppointment)
        .mockResolvedValueOnce({ ...confirmedAppointment, status: 'NO_SHOW' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...confirmedAppointment, status: 'NO_SHOW' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update
          .mockResolvedValueOnce({ ...mockUser, noShowCount: 3 })
          .mockResolvedValueOnce({ ...mockUser, noShowCount: 3, isSuspended: true, suspensionReason: '3 no-show appointments' });
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.providerEarning.create.mockResolvedValue({});
        tx.providerBalance.upsert.mockResolvedValue({});
        return callback(tx);
      });

      await appointmentService.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR'
      );

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should NOT update trust points for guest patient no-show', async () => {
      const guestAppointment = {
        ...confirmedAppointment,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(guestAppointment)
        .mockResolvedValueOnce({ ...guestAppointment, status: 'NO_SHOW' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'NO_SHOW' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('NO_SHOW');
      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    // ===== COMPLETED TESTS =====

    it('should mark appointment as COMPLETED and create earnings for doctor', async () => {
      const completedAppointment = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(completedAppointment)
        .mockResolvedValueOnce({ ...completedAppointment, status: 'COMPLETED' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('COMPLETED');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'user-123',
          title: '✅ Appointment Completed',
        })
      );
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should create clinic commission when clinic involved', async () => {
      const completedAppointment = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        clinicId: 'clinic-123',
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(completedAppointment)
        .mockResolvedValueOnce({ ...completedAppointment, status: 'COMPLETED' });

      await appointmentService.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should NOT create earnings for clinic-booked appointments', async () => {
      const completedAppointment = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'clinic',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
        clinicId: 'clinic-123',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(completedAppointment)
        .mockResolvedValueOnce({ ...completedAppointment, status: 'COMPLETED' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('COMPLETED');
    });

    it('should NOT create earnings for guest appointments', async () => {
      const completedAppointment = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'GUEST',
        patientId: null,
        guestPatientId: 'guest-123',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(completedAppointment)
        .mockResolvedValueOnce({ ...completedAppointment, status: 'COMPLETED' });

      const result = await appointmentService.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(result.status).toBe('COMPLETED');
      expect(mockPrisma.user.update).not.toHaveBeenCalled();
    });

    it('should handle duplicate earnings gracefully', async () => {
      const completedAppointment = {
        ...pendingAppointment,
        status: 'IN_PROGRESS',
        createdByType: 'user',
        creditPriceAtBooking: 10,
        patientType: 'REGISTERED',
      };

      (appointmentRepository.findById as jest.Mock)
        .mockResolvedValueOnce(completedAppointment)
        .mockResolvedValueOnce({ ...completedAppointment, status: 'COMPLETED' });

      mockPrisma.$transaction.mockImplementation((callback: TransactionCallback) => {
        const tx = createTransactionMock();
        tx.appointment.update.mockResolvedValue({ ...completedAppointment, status: 'COMPLETED' });
        tx.appointment.count.mockResolvedValue(0);
        tx.slot.update.mockResolvedValue(mockSlot);
        tx.user.update.mockResolvedValue(mockUser);
        tx.userWallet.findUnique.mockResolvedValue(mockWallet);
        tx.userWallet.upsert.mockResolvedValue(mockWallet);
        tx.userWallet.update.mockResolvedValue(mockWallet);
        tx.creditTransaction.create.mockResolvedValue({});
        tx.providerEarning.create.mockRejectedValue({ code: 'P2002' });
        tx.providerBalance.upsert.mockResolvedValue({});
        return callback(tx);
      });

      await appointmentService.updateStatus(
        'appointment-123',
        { status: 'COMPLETED' },
        'doctor-123',
        'DOCTOR'
      );

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    // ===== ERROR CASES =====

    it('should throw error when invalid status transition', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue({
        ...pendingAppointment,
        status: 'COMPLETED',
      });

      await expect(
        appointmentService.updateStatus(
          'appointment-123',
          { status: 'NO_SHOW' },
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when user tries to update not their appointment', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(pendingAppointment);

      await expect(
        appointmentService.updateStatus(
          'appointment-123',
          { status: 'CANCELLED' },
          'user-456',
          'USER'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when non-doctor/clinic tries to confirm', async () => {
      (appointmentRepository.findById as jest.Mock).mockResolvedValue(pendingAppointment);

      await expect(
        appointmentService.updateStatus(
          'appointment-123',
          { status: 'CONFIRMED' },
          'user-123',
          'USER'
        )
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // GET APPOINTMENTS TESTS
  // ============================================================

  describe('getMyAppointments', () => {
    it('should return patient appointments with pagination', async () => {
      (appointmentRepository.findByPatientId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      const result = await appointmentService.getMyAppointments('user-123', 1, 10);

      expect(appointmentRepository.findByPatientId).toHaveBeenCalledWith(
        'user-123',
        1,
        10
      );
      expect(result.appointments).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should use default pagination', async () => {
      (appointmentRepository.findByPatientId as jest.Mock).mockResolvedValue({
        appointments: [],
        total: 0,
      });

      await appointmentService.getMyAppointments('user-123');

      expect(appointmentRepository.findByPatientId).toHaveBeenCalledWith(
        'user-123',
        1,
        10
      );
    });

    it('should include guest patient data in response', async () => {
      (appointmentRepository.findByPatientId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointmentGuest],
        total: 1,
      });

      const result = await appointmentService.getMyAppointments('doctor-123', 1, 10);

      expect(result.appointments[0].patientType).toBe('GUEST');
      expect(result.appointments[0].guestPatient).toBeDefined();
      expect(result.appointments[0].patient).toBeNull();
    });
  });

  describe('getDoctorAppointments', () => {
    it('should return doctor appointments with date filter', async () => {
      (appointmentRepository.findByDoctorId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      const result = await appointmentService.getDoctorAppointments(
        'doctor-123',
        1,
        10,
        '2026-08-20'
      );

      expect(appointmentRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123',
        1,
        10,
        '2026-08-20'
      );
      expect(result.appointments).toHaveLength(1);
    });

    it('should include guest appointments in doctor appointments', async () => {
      (appointmentRepository.findByDoctorId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointmentGuest],
        total: 1,
      });

      const result = await appointmentService.getDoctorAppointments(
        'doctor-123',
        1,
        10
      );

      expect(result.appointments[0].patientType).toBe('GUEST');
    });
  });

  describe('getClinicAppointments', () => {
    it('should return clinic appointments with date filter', async () => {
      (appointmentRepository.findByClinicId as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      const result = await appointmentService.getClinicAppointments(
        'clinic-123',
        1,
        10,
        '2026-08-20'
      );

      expect(appointmentRepository.findByClinicId).toHaveBeenCalledWith(
        'clinic-123',
        1,
        10,
        '2026-08-20'
      );
      expect(result.appointments).toHaveLength(1);
    });
  });

  describe('getAllAppointments', () => {
    it('should return all appointments for admin', async () => {
      (appointmentRepository.findAll as jest.Mock).mockResolvedValue({
        appointments: [mockAppointment],
        total: 1,
      });

      const result = await appointmentService.getAllAppointments(1, 20, {});

      expect(appointmentRepository.findAll).toHaveBeenCalledWith(1, 20, {});
      expect(result.appointments).toHaveLength(1);
    });

    it('should apply filters', async () => {
      (appointmentRepository.findAll as jest.Mock).mockResolvedValue({
        appointments: [],
        total: 0,
      });

      const filters = {
        status: 'PENDING',
        date: '2026-08-20',
        doctorId: 'doctor-123',
      };

      await appointmentService.getAllAppointments(1, 20, filters);

      expect(appointmentRepository.findAll).toHaveBeenCalledWith(1, 20, filters);
    });
  });

  // ============================================================
  // QUICK SLOT TESTS
  // ============================================================

  describe('addQuickSlot', () => {
    const quickSlotData = {
      date: '2026-08-20',
      startTime: '09:30',
      endTime: '10:00',
      maxPatients: 2,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockConfig
      );
      (
        doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock
      ).mockResolvedValue(mockAvailability);
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue(
        []
      );
      (slotRepository.create as jest.Mock).mockResolvedValue(mockSlot);
      mockPrisma.slot.findFirst.mockResolvedValue(null);
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T10:00:00.000Z'));
      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(false);
    });

    it('should add a quick slot successfully', async () => {
      const result = await appointmentService.addQuickSlot(
        'doctor-123',
        quickSlotData,
        'doctor-123',
        'DOCTOR'
      );

      expect(slotRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          doctorId: 'doctor-123',
          date: expect.any(Date),
          startTime: expect.any(Date),
          endTime: expect.any(Date),
          maxPatients: 2,
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'slot.quick_added',
          entity: 'Slot',
          entityId: 'slot-123',
          performedBy: 'doctor-123',
        })
      );
      expect(result.id).toBe('slot-123');
    });

    it('should add quick slot as clinic', async () => {
      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });

      const result = await appointmentService.addQuickSlot(
        'doctor-123',
        quickSlotData,
        'clinic-123',
        'CLINIC'
      );

      expect(result.id).toBe('slot-123');
    });

    it('should validate against availability hours', async () => {
      const outsideAvailability = {
        ...quickSlotData,
        startTime: '07:00',
        endTime: '07:30',
      };

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          outsideAvailability,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should validate against breaks', async () => {
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue(
        [mockBreak]
      );

      const overlappingBreak = {
        ...quickSlotData,
        startTime: '12:15',
        endTime: '12:45',
      };

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          overlappingBreak,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should prevent duplicate slots', async () => {
      mockPrisma.slot.findFirst.mockResolvedValue(mockSlot);

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          quickSlotData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(ConflictError);
    });

    it('should prevent slots in the past', async () => {
      const pastDate = {
        ...quickSlotData,
        date: '2026-08-19',
        startTime: '08:00',
        endTime: '08:30',
      };

      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-19T09:00:00.000Z'));
      (isSlotInPastAlgeria as jest.Mock).mockReturnValue(true);

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          pastDate,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when start time >= end time', async () => {
      const invalidTime = {
        ...quickSlotData,
        startTime: '10:00',
        endTime: '09:30',
      };

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          invalidTime,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw error when doctor not verified', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        appointmentService.addQuickSlot(
          'doctor-123',
          quickSlotData,
          'doctor-123',
          'DOCTOR'
        )
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // SLOT AUTOMATION TESTS
  // ============================================================

  describe('setupAutomation', () => {
    const automationData = {
      frequency: 'WEEKLY' as const,
      bookingWindowDays: 30,
    };

    const mockRule = {
      id: 'rule-123',
      doctorId: 'doctor-123',
      frequency: 'WEEKLY',
      bookingWindowDays: 30,
      enabled: true,
      clinicId: null,
      roomId: null,
      lastRunAt: null,
      nextRunAt: new Date(),
      errorCount: 0,
      lastError: null,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (slotRepository.upsertAutomationRule as jest.Mock).mockResolvedValue(
        mockRule
      );
    });

    it('should enable automation successfully', async () => {
      const result = await appointmentService.setupAutomation(
        'doctor-123',
        automationData
      );

      expect(slotRepository.upsertAutomationRule).toHaveBeenCalledWith(
        'doctor-123',
        {
          frequency: 'WEEKLY',
          bookingWindowDays: 30,
          clinicId: undefined,
          roomId: undefined,
        }
      );
      expect(result.enabled).toBe(true);
    });

    it('should throw error when doctor not available', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: false,
      });

      await expect(
        appointmentService.setupAutomation('doctor-123', automationData)
      ).rejects.toThrow(BadRequestError);
    });

    it('should validate clinic link when clinicId provided', async () => {
      const dataWithClinic = {
        ...automationData,
        clinicId: 'clinic-123',
      };

      mockPrisma.clinicDoctor.findFirst.mockResolvedValue(null);

      await expect(
        appointmentService.setupAutomation('doctor-123', dataWithClinic)
      ).rejects.toThrow(BadRequestError);
    });

    it('should validate room belongs to clinic', async () => {
      const dataWithRoom = {
        ...automationData,
        clinicId: 'clinic-123',
        roomId: 'room-123',
      };

      mockPrisma.clinicDoctor.findFirst.mockResolvedValue({
        id: 'link-1',
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        isActive: true,
      });
      mockPrisma.clinicRoom.findFirst.mockResolvedValue(null);

      await expect(
        appointmentService.setupAutomation('doctor-123', dataWithRoom)
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('disableAutomation', () => {
    const mockRule = {
      id: 'rule-123',
      doctorId: 'doctor-123',
      frequency: 'WEEKLY',
      bookingWindowDays: 30,
      enabled: true,
      clinicId: null,
      roomId: null,
      lastRunAt: null,
      nextRunAt: new Date(),
      errorCount: 0,
      lastError: null,
    };

    beforeEach(() => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(mockRule);
      (slotRepository.disableAutomationRule as jest.Mock).mockResolvedValue({
        ...mockRule,
        enabled: false,
      });
    });

    it('should disable automation successfully', async () => {
      await appointmentService.disableAutomation('doctor-123');

      expect(slotRepository.disableAutomationRule).toHaveBeenCalledWith(
        'doctor-123'
      );
    });

    it('should throw NotFoundError when no rule exists', async () => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(null);

      await expect(
        appointmentService.disableAutomation('doctor-123')
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('getAutomationStatus', () => {
    it('should return automation rule when exists', async () => {
      const mockRule = {
        id: 'rule-123',
        doctorId: 'doctor-123',
        frequency: 'WEEKLY',
        bookingWindowDays: 30,
        enabled: true,
        clinicId: null,
        roomId: null,
        lastRunAt: null,
        nextRunAt: new Date(),
        errorCount: 0,
        lastError: null,
      };

      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(mockRule);

      const result = await appointmentService.getAutomationStatus('doctor-123');

      expect(result).toEqual(mockRule);
    });

    it('should return null when no rule exists', async () => {
      (slotRepository.getAutomationRule as jest.Mock).mockResolvedValue(null);

      const result = await appointmentService.getAutomationStatus('doctor-123');

      expect(result).toBeNull();
    });
  });

  // ============================================================
  // GENERATE AUTOMATION SLOTS (Worker function)
  // ============================================================

  describe('generateAutomationSlots', () => {
    const mockHorizon = new Date('2026-08-20');

    beforeEach(() => {
      (slotRepository.getBookingHorizon as jest.Mock).mockResolvedValue(
        mockHorizon
      );
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockConfig
      );
      (
        doctorAvailabilityRepository.findByDoctorAndDay as jest.Mock
      ).mockResolvedValue(mockAvailability);
      (doctorBreakRepository.findByDoctorAndDateRange as jest.Mock).mockResolvedValue(
        []
      );
      (slotRepository.generateMissingSlots as jest.Mock).mockResolvedValue({
        created: 10,
        existing: 5,
        errors: 0,
      });
      (nowAlgeria as jest.Mock).mockReturnValue(new Date('2026-08-20T10:00:00.000Z'));
    });

    it('should generate missing slots up to booking window', async () => {
      const result = await appointmentService.generateAutomationSlots(
        'doctor-123',
        30
      );

      expect(slotRepository.generateMissingSlots).toHaveBeenCalled();
      expect(result.created).toBe(10);
      expect(result.existing).toBe(5);
      expect(result.errors).toBe(0);
    });

    it('should skip when horizon already beyond target', async () => {
      const farHorizon = new Date('2026-09-20');
      (slotRepository.getBookingHorizon as jest.Mock).mockResolvedValue(
        farHorizon
      );

      const result = await appointmentService.generateAutomationSlots(
        'doctor-123',
        30
      );

      expect(slotRepository.generateMissingSlots).not.toHaveBeenCalled();
      expect(result.created).toBe(0);
      expect(result.existing).toBe(0);
      expect(result.errors).toBe(0);
    });

    it('should use default config when doctor has no config', async () => {
      (doctorConfigRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        null
      );

      const result = await appointmentService.generateAutomationSlots(
        'doctor-123',
        30
      );

      expect(result.created).toBe(10);
    });

    it('should handle clinicId and roomId scope', async () => {
      await appointmentService.generateAutomationSlots(
        'doctor-123',
        30,
        'clinic-123',
        'room-123'
      );

      expect(slotRepository.getBookingHorizon).toHaveBeenCalledWith(
        'doctor-123',
        'clinic-123',
        'room-123'
      );
    });
  });
});

