// backend/tests/unit/modules/appointment/v1/appointment.controller.test.ts

import { Request, Response, NextFunction } from 'express';
import { AppointmentController } from '../../../../../src/modules/appointment/v1/appointment.controller';
import { appointmentService } from '../../../../../src/modules/appointment/v1/appointment.service';
import { guestPatientRepository } from '../../../../../src/repositories/guest-patient.repository';
import { ResponseUtil } from '../../../../../src/core/utils/response';
import { NotFoundError } from '../../../../../src/core/utils/error';

// Mock the appointment service
jest.mock('../../../../../src/modules/appointment/v1/appointment.service', () => ({
  appointmentService: {
    getDoctorConfig: jest.fn(),
    setDoctorConfig: jest.fn(),
    getAvailableSlots: jest.fn(),
    getSlots: jest.fn(),
    generateSlots: jest.fn(),
    cancelSlot: jest.fn(),
    cancelSlotsByDate: jest.fn(),
    bookAppointment: jest.fn(),
    clinicBookAppointment: jest.fn(),
    confirmAppointment: jest.fn(),
    getMyAppointments: jest.fn(),
    getDoctorAppointments: jest.fn(),
    getClinicAppointments: jest.fn(),
    getAllAppointments: jest.fn(),
    updateStatus: jest.fn(),
    addQuickSlot: jest.fn(),
    setupAutomation: jest.fn(),
    disableAutomation: jest.fn(),
    getAutomationStatus: jest.fn(),
  },
}));

// Mock guest patient repository
jest.mock('../../../../../src/repositories/guest-patient.repository', () => ({
  guestPatientRepository: {
    findByCreator: jest.fn(),
    search: jest.fn(),
    findById: jest.fn(),
    update: jest.fn(),
    create: jest.fn(),
  },
}));

// Mock ResponseUtil
jest.mock('../../../../../src/core/utils/response', () => ({
  ResponseUtil: {
    success: jest.fn(),
    created: jest.fn(),
    paginated: jest.fn(),
    validationError: jest.fn(),
    badRequest: jest.fn(),
    unauthorized: jest.fn(),
  },
}));

describe('AppointmentController', () => {
  let controller: AppointmentController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    controller = new AppointmentController();
    req = {
      params: {},
      query: {},
      body: {},
      user: { id: 'user-123', role: 'USER' } as any,
      ip: '127.0.0.1',
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  // ============================================================
  // CONFIG TESTS
  // ============================================================

  describe('getMyConfig', () => {
    it('should get doctor config successfully', async () => {
      const mockConfig = { id: 'config-123', doctorId: 'doctor-123', slotDuration: 30 };
      (appointmentService.getDoctorConfig as jest.Mock).mockResolvedValue(mockConfig);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyConfig(req as Request, res as Response, next);

      expect(appointmentService.getDoctorConfig).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockConfig, 'Config retrieved');
      expect(next).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Config not found');
      (appointmentService.getDoctorConfig as jest.Mock).mockRejectedValue(error);

      await controller.getMyConfig(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('setMyConfig', () => {
    it('should set doctor config successfully', async () => {
      const mockConfig = { id: 'config-123', doctorId: 'doctor-123', slotDuration: 45 };
      (appointmentService.setDoctorConfig as jest.Mock).mockResolvedValue(mockConfig);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { slotDuration: 45, bufferTime: 10 };

      await controller.setMyConfig(req as Request, res as Response, next);

      expect(appointmentService.setDoctorConfig).toHaveBeenCalledWith('doctor-123', req.body);
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockConfig, 'Config updated');
      expect(next).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Invalid config');
      (appointmentService.setDoctorConfig as jest.Mock).mockRejectedValue(error);

      await controller.setMyConfig(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // SLOTS TESTS
  // ============================================================

  describe('getAvailableSlots', () => {
    it('should get available slots successfully', async () => {
      const mockSlots = [{ id: 'slot-1' }, { id: 'slot-2' }];
      (appointmentService.getAvailableSlots as jest.Mock).mockResolvedValue(mockSlots);

      req.params = { doctorId: 'doctor-123' };
      req.query = { date: '2026-08-20' };

      await controller.getAvailableSlots(req as Request, res as Response, next);

      expect(appointmentService.getAvailableSlots).toHaveBeenCalledWith('doctor-123', '2026-08-20');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockSlots, 'Slots retrieved');
      expect(next).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Doctor not found');
      (appointmentService.getAvailableSlots as jest.Mock).mockRejectedValue(error);

      await controller.getAvailableSlots(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getSlots', () => {
    it('should get slots for a doctor successfully', async () => {
      const mockSlots = [{ id: 'slot-1' }];
      (appointmentService.getSlots as jest.Mock).mockResolvedValue(mockSlots);

      req.params = { doctorId: 'doctor-123' };
      req.query = { date: '2026-08-20' };

      await controller.getSlots(req as Request, res as Response, next);

      expect(appointmentService.getSlots).toHaveBeenCalledWith('doctor-123', '2026-08-20');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockSlots, 'Slots retrieved');
    });

    it('should use user.id when doctorId not provided', async () => {
      const mockSlots = [{ id: 'slot-1' }];
      (appointmentService.getSlots as jest.Mock).mockResolvedValue(mockSlots);

      req.params = {};
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.query = { date: '2026-08-20' };

      await controller.getSlots(req as Request, res as Response, next);

      expect(appointmentService.getSlots).toHaveBeenCalledWith('doctor-123', '2026-08-20');
    });
  });

  describe('generateSlots', () => {
    it('should generate slots successfully', async () => {
      const mockSlots = [{ id: 'slot-1' }];
      (appointmentService.generateSlots as jest.Mock).mockResolvedValue(mockSlots);

      req.params = { doctorId: 'doctor-123' };
      req.body = { startDate: '2026-08-20', endDate: '2026-08-22' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.generateSlots(req as Request, res as Response, next);

      expect(appointmentService.generateSlots).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(res, mockSlots, 'Slots generated');
    });

    it('should use user.id when doctorId not provided', async () => {
      const mockSlots = [{ id: 'slot-1' }];
      (appointmentService.generateSlots as jest.Mock).mockResolvedValue(mockSlots);

      req.params = {};
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { startDate: '2026-08-20', endDate: '2026-08-22' };

      await controller.generateSlots(req as Request, res as Response, next);

      expect(appointmentService.generateSlots).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Generation failed');
      (appointmentService.generateSlots as jest.Mock).mockRejectedValue(error);

      await controller.generateSlots(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('cancelSlot', () => {
    it('should cancel a slot successfully', async () => {
      (appointmentService.cancelSlot as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'slot-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.cancelSlot(req as Request, res as Response, next);

      expect(appointmentService.cancelSlot).toHaveBeenCalledWith('slot-123', 'doctor-123', 'DOCTOR');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, null, 'Slot cancelled');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Slot not found');
      (appointmentService.cancelSlot as jest.Mock).mockRejectedValue(error);

      await controller.cancelSlot(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('cancelSlotsByDate', () => {
    it('should cancel slots by date successfully', async () => {
      (appointmentService.cancelSlotsByDate as jest.Mock).mockResolvedValue(5);

      req.params = { doctorId: 'doctor-123' };
      req.body = { date: '2026-08-20', reason: 'Holiday' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.cancelSlotsByDate(req as Request, res as Response, next);

      expect(appointmentService.cancelSlotsByDate).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        { cancelledCount: 5 },
        'Slots cancelled'
      );
    });

    it('should use user.id when doctorId not provided', async () => {
      (appointmentService.cancelSlotsByDate as jest.Mock).mockResolvedValue(3);

      req.params = {};
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { date: '2026-08-20' };

      await controller.cancelSlotsByDate(req as Request, res as Response, next);

      expect(appointmentService.cancelSlotsByDate).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
    });
  });

  // ============================================================
  // BOOK APPOINTMENT TESTS
  // ============================================================

  describe('bookAppointment', () => {
    it('should book an appointment successfully', async () => {
      const mockAppointment = { id: 'appointment-123', status: 'PENDING' };
      (appointmentService.bookAppointment as jest.Mock).mockResolvedValue(mockAppointment);

      req.body = { slotId: 'slot-123', patientId: 'user-123' };
      req.user = { id: 'user-123', role: 'USER' } as any;

      await controller.bookAppointment(req as Request, res as Response, next);

      expect(appointmentService.bookAppointment).toHaveBeenCalledWith(
        req.body,
        'user-123',
        'USER'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(res, mockAppointment, 'Appointment requested');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Slot full');
      (appointmentService.bookAppointment as jest.Mock).mockRejectedValue(error);

      await controller.bookAppointment(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('clinicBook', () => {
    it('should book an appointment as clinic successfully', async () => {
      const mockAppointment = { id: 'appointment-123', clinicId: 'clinic-123' };
      (appointmentService.clinicBookAppointment as jest.Mock).mockResolvedValue(mockAppointment);

      req.body = { slotId: 'slot-123', patientId: 'user-123' };
      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;

      await controller.clinicBook(req as Request, res as Response, next);

      expect(appointmentService.clinicBookAppointment).toHaveBeenCalledWith(
        req.body,
        'clinic-123'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(res, mockAppointment, 'Appointment requested');
    });
  });

  // ============================================================
  // CONFIRM APPOINTMENT TESTS
  // ============================================================

  describe('confirmAppointment', () => {
    it('should confirm an appointment successfully', async () => {
      const mockAppointment = { id: 'appointment-123', status: 'CONFIRMED' };
      (appointmentService.confirmAppointment as jest.Mock).mockResolvedValue(mockAppointment);

      req.params = { id: 'appointment-123' };
      req.body = { notes: 'Confirmed' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.confirmAppointment(req as Request, res as Response, next);

      expect(appointmentService.confirmAppointment).toHaveBeenCalledWith(
        'appointment-123',
        'doctor-123',
        'DOCTOR',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockAppointment, 'Appointment confirmed');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Not your appointment');
      (appointmentService.confirmAppointment as jest.Mock).mockRejectedValue(error);

      await controller.confirmAppointment(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // GET APPOINTMENTS TESTS
  // ============================================================

  describe('getMyAppointments', () => {
    it('should get user appointments with pagination', async () => {
      const mockResult = {
        appointments: [{ id: 'app-1' }, { id: 'app-2' }],
        total: 2,
      };
      (appointmentService.getMyAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.query = { page: '2', limit: '5' };

      await controller.getMyAppointments(req as Request, res as Response, next);

      expect(appointmentService.getMyAppointments).toHaveBeenCalledWith('user-123', 2, 5);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.appointments,
        mockResult.total,
        2,
        5,
        'Appointments retrieved'
      );
    });

    it('should use default pagination values', async () => {
      const mockResult = { appointments: [], total: 0 };
      (appointmentService.getMyAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'user-123', role: 'USER' } as any;
      req.query = {};

      await controller.getMyAppointments(req as Request, res as Response, next);

      expect(appointmentService.getMyAppointments).toHaveBeenCalledWith('user-123', 1, 10);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        10,
        'Appointments retrieved'
      );
    });
  });

  describe('getDoctorAppointments', () => {
    it('should get doctor appointments with pagination', async () => {
      const mockResult = {
        appointments: [{ id: 'app-1' }],
        total: 1,
      };
      (appointmentService.getDoctorAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.query = { page: '1', limit: '10', date: '2026-08-20' };

      await controller.getDoctorAppointments(req as Request, res as Response, next);

      expect(appointmentService.getDoctorAppointments).toHaveBeenCalledWith(
        'doctor-123',
        1,
        10,
        '2026-08-20'
      );
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.appointments,
        mockResult.total,
        1,
        10,
        'Appointments retrieved'
      );
    });

    it('should use default date when not provided', async () => {
      const mockResult = { appointments: [], total: 0 };
      (appointmentService.getDoctorAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.query = {};

      await controller.getDoctorAppointments(req as Request, res as Response, next);

      expect(appointmentService.getDoctorAppointments).toHaveBeenCalledWith(
        'doctor-123',
        1,
        10,
        undefined
      );
    });
  });

  describe('getClinicAppointments', () => {
    it('should get clinic appointments with pagination', async () => {
      const mockResult = {
        appointments: [{ id: 'app-1' }],
        total: 1,
      };
      (appointmentService.getClinicAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'clinic-123', role: 'CLINIC' } as any;
      req.query = { page: '1', limit: '10', date: '2026-08-20' };

      await controller.getClinicAppointments(req as Request, res as Response, next);

      expect(appointmentService.getClinicAppointments).toHaveBeenCalledWith(
        'clinic-123',
        1,
        10,
        '2026-08-20'
      );
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.appointments,
        mockResult.total,
        1,
        10,
        'Appointments retrieved'
      );
    });
  });

  describe('getAllAppointments', () => {
    it('should get all appointments for admin', async () => {
      const mockResult = {
        appointments: [{ id: 'app-1' }, { id: 'app-2' }],
        total: 2,
      };
      (appointmentService.getAllAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.query = { page: '2', limit: '20', status: 'PENDING' };

      await controller.getAllAppointments(req as Request, res as Response, next);

      expect(appointmentService.getAllAppointments).toHaveBeenCalledWith(2, 20, req.query);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.appointments,
        mockResult.total,
        2,
        20,
        'Appointments retrieved'
      );
    });

    it('should use default pagination values', async () => {
      const mockResult = { appointments: [], total: 0 };
      (appointmentService.getAllAppointments as jest.Mock).mockResolvedValue(mockResult);

      req.query = {};

      await controller.getAllAppointments(req as Request, res as Response, next);

      expect(appointmentService.getAllAppointments).toHaveBeenCalledWith(1, 20, {});
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        20,
        'Appointments retrieved'
      );
    });
  });

  // ============================================================
  // UPDATE STATUS TESTS
  // ============================================================

  describe('updateStatus', () => {
    it('should update appointment status successfully', async () => {
      const mockAppointment = { id: 'appointment-123', status: 'CONFIRMED' };
      (appointmentService.updateStatus as jest.Mock).mockResolvedValue(mockAppointment);

      req.params = { id: 'appointment-123' };
      req.body = { status: 'CONFIRMED' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.updateStatus(req as Request, res as Response, next);

      expect(appointmentService.updateStatus).toHaveBeenCalledWith(
        'appointment-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockAppointment, 'Status updated');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Invalid status transition');
      (appointmentService.updateStatus as jest.Mock).mockRejectedValue(error);

      await controller.updateStatus(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // GUEST PATIENT TESTS
  // ============================================================

  describe('getMyGuestPatients', () => {
    it('should get guest patients with pagination', async () => {
      const mockResult = {
        guests: [{ id: 'guest-1' }, { id: 'guest-2' }],
        total: 2,
      };
      (guestPatientRepository.findByCreator as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.query = { page: '2', limit: '5' };

      await controller.getMyGuestPatients(req as Request, res as Response, next);

      expect(guestPatientRepository.findByCreator).toHaveBeenCalledWith('doctor-123', 2, 5);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.guests,
        mockResult.total,
        2,
        5,
        'Guest patients retrieved'
      );
    });

    it('should use default pagination', async () => {
      const mockResult = { guests: [], total: 0 };
      (guestPatientRepository.findByCreator as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.query = {};

      await controller.getMyGuestPatients(req as Request, res as Response, next);

      expect(guestPatientRepository.findByCreator).toHaveBeenCalledWith('doctor-123', 1, 20);
    });
  });

  describe('searchGuestPatients', () => {
    it('should search guest patients successfully', async () => {
      const mockGuests = [{ id: 'guest-1' }, { id: 'guest-2' }];
      (guestPatientRepository.search as jest.Mock).mockResolvedValue(mockGuests);

      req.query = { q: 'John' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.searchGuestPatients(req as Request, res as Response, next);

      expect(guestPatientRepository.search).toHaveBeenCalledWith('John', 'doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockGuests, 'Guest patients found');
    });

    it('should return validation error when query is too short', async () => {
      req.query = { q: 'J' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.searchGuestPatients(req as Request, res as Response, next);

      expect(ResponseUtil.validationError).toHaveBeenCalledWith(
        res,
        'Search query must be at least 2 characters'
      );
      expect(guestPatientRepository.search).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Search failed');
      (guestPatientRepository.search as jest.Mock).mockRejectedValue(error);

      req.query = { q: 'John' };

      await controller.searchGuestPatients(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getGuestPatient', () => {
    it('should get a guest patient by id', async () => {
      const mockGuest = { id: 'guest-123', createdBy: 'doctor-123' };
      (guestPatientRepository.findById as jest.Mock).mockResolvedValue(mockGuest);

      req.params = { id: 'guest-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getGuestPatient(req as Request, res as Response, next);

      expect(guestPatientRepository.findById).toHaveBeenCalledWith('guest-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockGuest, 'Guest patient retrieved');
    });

    it('should throw NotFoundError when guest not found', async () => {
      (guestPatientRepository.findById as jest.Mock).mockResolvedValue(null);

      req.params = { id: 'guest-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getGuestPatient(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(expect.any(NotFoundError));
    });

    it('should throw NotFoundError when user does not own the guest', async () => {
      const mockGuest = { id: 'guest-123', createdBy: 'other-user' };
      (guestPatientRepository.findById as jest.Mock).mockResolvedValue(mockGuest);

      req.params = { id: 'guest-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getGuestPatient(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(expect.any(NotFoundError));
    });
  });

  describe('updateGuestPatient', () => {
    it('should update a guest patient successfully', async () => {
      const mockGuest = { id: 'guest-123', createdBy: 'doctor-123' };
      const mockUpdated = { id: 'guest-123', firstName: 'Updated' };
      (guestPatientRepository.findById as jest.Mock).mockResolvedValue(mockGuest);
      (guestPatientRepository.update as jest.Mock).mockResolvedValue(mockUpdated);

      req.params = { id: 'guest-123' };
      req.body = { firstName: 'Updated' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.updateGuestPatient(req as Request, res as Response, next);

      expect(guestPatientRepository.update).toHaveBeenCalledWith('guest-123', req.body);
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockUpdated, 'Guest patient updated');
    });

    it('should throw NotFoundError when guest not found', async () => {
      (guestPatientRepository.findById as jest.Mock).mockResolvedValue(null);

      req.params = { id: 'guest-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.updateGuestPatient(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(expect.any(NotFoundError));
    });
  });

  describe('createGuestPatient', () => {
    it('should create a guest patient successfully', async () => {
      const mockGuest = { id: 'guest-123', firstName: 'John', lastName: 'Doe' };
      (guestPatientRepository.create as jest.Mock).mockResolvedValue(mockGuest);

      req.body = {
        firstName: 'John',
        lastName: 'Doe',
        phone: '0555123456',
        email: 'john@example.com',
        dateOfBirth: '1990-01-01',
        wilayaId: 'wilaya-123',
        notes: 'Test',
      };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.createGuestPatient(req as Request, res as Response, next);

      expect(guestPatientRepository.create).toHaveBeenCalledWith({
        firstName: 'John',
        lastName: 'Doe',
        phone: '0555123456',
        email: 'john@example.com',
        dateOfBirth: expect.any(Date),
        wilayaId: 'wilaya-123',
        createdBy: 'doctor-123',
        createdByType: 'DOCTOR',
        notes: 'Test',
      });
      expect(ResponseUtil.created).toHaveBeenCalledWith(res, mockGuest, 'Guest patient created');
    });

    it('should handle missing optional fields', async () => {
      const mockGuest = { id: 'guest-123' };
      (guestPatientRepository.create as jest.Mock).mockResolvedValue(mockGuest);

      req.body = {
        firstName: 'John',
        lastName: 'Doe',
        phone: '0555123456',
      };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.createGuestPatient(req as Request, res as Response, next);

      expect(guestPatientRepository.create).toHaveBeenCalledWith({
        firstName: 'John',
        lastName: 'Doe',
        phone: '0555123456',
        email: undefined,
        dateOfBirth: undefined,
        wilayaId: undefined,
        createdBy: 'doctor-123',
        createdByType: 'DOCTOR',
        notes: undefined,
      });
    });

    it('should forward errors to next', async () => {
      const error = new Error('Phone already exists');
      (guestPatientRepository.create as jest.Mock).mockRejectedValue(error);

      req.body = { firstName: 'John', lastName: 'Doe', phone: '0555123456' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.createGuestPatient(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  // ============================================================
  // QUICK SLOT TESTS
  // ============================================================

  describe('addQuickSlot', () => {
    it('should add a quick slot successfully', async () => {
      const mockSlot = { id: 'slot-123' };
      (appointmentService.addQuickSlot as jest.Mock).mockResolvedValue(mockSlot);

      req.params = { doctorId: 'doctor-123' };
      req.body = { date: '2026-08-20', startTime: '09:00', endTime: '09:30' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.addQuickSlot(req as Request, res as Response, next);

      expect(appointmentService.addQuickSlot).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(res, mockSlot, 'Quick slot added successfully');
    });

    it('should use user.id when doctorId not provided', async () => {
      const mockSlot = { id: 'slot-123' };
      (appointmentService.addQuickSlot as jest.Mock).mockResolvedValue(mockSlot);

      req.params = {};
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { date: '2026-08-20', startTime: '09:00', endTime: '09:30' };

      await controller.addQuickSlot(req as Request, res as Response, next);

      expect(appointmentService.addQuickSlot).toHaveBeenCalledWith(
        'doctor-123',
        req.body,
        'doctor-123',
        'DOCTOR'
      );
    });
  });

  // ============================================================
  // SLOT AUTOMATION TESTS
  // ============================================================

  describe('enableAutomation', () => {
    it('should enable automation successfully', async () => {
      const mockRule = { id: 'rule-123', enabled: true };
      (appointmentService.setupAutomation as jest.Mock).mockResolvedValue(mockRule);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { frequency: 'WEEKLY', bookingWindowDays: 30 };

      await controller.enableAutomation(req as Request, res as Response, next);

      expect(appointmentService.setupAutomation).toHaveBeenCalledWith('doctor-123', req.body);
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockRule, 'Slot automation enabled');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Invalid frequency');
      (appointmentService.setupAutomation as jest.Mock).mockRejectedValue(error);

      await controller.enableAutomation(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('disableAutomation', () => {
    it('should disable automation successfully', async () => {
      (appointmentService.disableAutomation as jest.Mock).mockResolvedValue(undefined);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.disableAutomation(req as Request, res as Response, next);

      expect(appointmentService.disableAutomation).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, null, 'Slot automation disabled');
    });

    it('should forward errors to next', async () => {
      const error = new Error('No automation rule found');
      (appointmentService.disableAutomation as jest.Mock).mockRejectedValue(error);

      await controller.disableAutomation(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('getAutomation', () => {
    it('should get automation status successfully', async () => {
      const mockRule = { id: 'rule-123', enabled: true };
      (appointmentService.getAutomationStatus as jest.Mock).mockResolvedValue(mockRule);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getAutomation(req as Request, res as Response, next);

      expect(appointmentService.getAutomationStatus).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(res, mockRule, 'Automation status retrieved');
    });

    it('should handle null rule', async () => {
      (appointmentService.getAutomationStatus as jest.Mock).mockResolvedValue(null);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getAutomation(req as Request, res as Response, next);

      expect(ResponseUtil.success).toHaveBeenCalledWith(res, null, 'Automation status retrieved');
    });

    it('should forward errors to next', async () => {
      const error = new Error('Failed to get status');
      (appointmentService.getAutomationStatus as jest.Mock).mockRejectedValue(error);

      await controller.getAutomation(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });
});

