import { Request, Response, NextFunction } from 'express';
import { DoctorController } from '../../../../../src/modules/doctor/v1/doctor.controller';
import { doctorService } from '../../../../../src/modules/doctor/v1/doctor.service';
import { ResponseUtil } from '../../../../../src/core/utils/response';

// Mock the doctor service
jest.mock('../../../../../src/modules/doctor/v1/doctor.service', () => ({
  doctorService: {
    findAll: jest.fn(),
    findById: jest.fn(),
    update: jest.fn(),
    verify: jest.fn(),
    reject: jest.fn(),
    suspend: jest.fn(),
    unsuspend: jest.fn(),
    getDocuments: jest.fn(),
    getMyProfile: jest.fn(),
    completeProfile: jest.fn(),
    uploadDocument: jest.fn(),
    getMyDocuments: jest.fn(),
    deleteDocument: jest.fn(),
    requestToJoinClinic: jest.fn(),
    getMyInvitations: jest.fn(),
    respondToClinicInvitation: jest.fn(),
    getMyAvailability: jest.fn(),
    setMyAvailability: jest.fn(),
    deleteAvailabilitySlot: jest.fn(),
    getDoctorAvailability: jest.fn(),
    getMyBreaks: jest.fn(),
    createBreak: jest.fn(),
    updateBreak: jest.fn(),
    deleteBreak: jest.fn(),
    createDoctor: jest.fn(),
    uploadDocumentForDoctor: jest.fn(),
    deleteDoctorDocument: jest.fn(),
    createCompleteDoctor: jest.fn(),
    updateBookingAvailability: jest.fn(),
  },
}));

// Mock ResponseUtil
jest.mock('../../../../../src/core/utils/response', () => ({
  ResponseUtil: {
    paginated: jest.fn(),
    success: jest.fn(),
    created: jest.fn(),
    badRequest: jest.fn(),
    unauthorized: jest.fn(),
  },
}));

describe('DoctorController', () => {
  let controller: DoctorController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    controller = new DoctorController();
    req = {
      params: {},
      query: {},
      body: {},
      user: { id: 'user-123', role: 'ADMIN' } as any,
      // ✅ FIX: Use a getter for ip instead of assigning directly
      get ip() { return '127.0.0.1'; },
      file: undefined,
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  // ============================================================
  // Helper function to create a request with custom ip
  // ============================================================

  const createRequestWithIp = (ip: string): Partial<Request> => ({
    ...req,
    get ip() { return ip; },
  });

  // ============================================================
  // Staff Routes
  // ============================================================

  describe('findAll', () => {
    it('should return paginated doctors', async () => {
      const mockResult = {
        doctors: [{ id: 'doctor-1' }, { id: 'doctor-2' }],
        total: 2,
      };
      (doctorService.findAll as jest.Mock).mockResolvedValue(mockResult);

      req.query = { page: '2', limit: '5' };

      await controller.findAll(req as Request, res as Response, next);

      expect(doctorService.findAll).toHaveBeenCalledWith(req.query);
      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        mockResult.doctors,
        mockResult.total,
        2,
        5,
        'Doctors retrieved successfully'
      );
      expect(next).not.toHaveBeenCalled();
    });

    it('should use default pagination values', async () => {
      const mockResult = { doctors: [], total: 0 };
      (doctorService.findAll as jest.Mock).mockResolvedValue(mockResult);

      req.query = {};

      await controller.findAll(req as Request, res as Response, next);

      expect(ResponseUtil.paginated).toHaveBeenCalledWith(
        res,
        [],
        0,
        1,
        10,
        'Doctors retrieved successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Service error');
      (doctorService.findAll as jest.Mock).mockRejectedValue(error);

      await controller.findAll(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('findById', () => {
    it('should return a doctor by id', async () => {
      const mockDoctor = { id: 'doctor-123', name: 'Dr. Test' };
      (doctorService.findById as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };

      await controller.findById(req as Request, res as Response, next);

      expect(doctorService.findById).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor retrieved successfully'
      );
      expect(next).not.toHaveBeenCalled();
    });

    it('should forward errors to next', async () => {
      const error = new Error('Doctor not found');
      (doctorService.findById as jest.Mock).mockRejectedValue(error);

      req.params = { id: 'non-existent' };

      await controller.findById(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('update', () => {
    it('should update a doctor', async () => {
      const mockDoctor = { id: 'doctor-123', name: 'Updated' };
      (doctorService.update as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.body = { name: 'Updated' };

      await controller.update(req as Request, res as Response, next);

      expect(doctorService.update).toHaveBeenCalledWith('doctor-123', req.body);
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor updated successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Update failed');
      (doctorService.update as jest.Mock).mockRejectedValue(error);

      await controller.update(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('verify', () => {
    it('should verify a doctor', async () => {
      const mockDoctor = { id: 'doctor-123', isVerified: true };
      (doctorService.verify as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;
      // ✅ FIX: Use the helper to set ip
      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.verify(reqWithIp as Request, res as Response, next);

      expect(doctorService.verify).toHaveBeenCalledWith(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor verified successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Already verified');
      (doctorService.verify as jest.Mock).mockRejectedValue(error);

      await controller.verify(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });

  describe('reject', () => {
    it('should reject a doctor', async () => {
      const mockDoctor = { id: 'doctor-123', rejectionReason: 'Invalid docs' };
      (doctorService.reject as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.body = { reason: 'Invalid docs' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.reject(reqWithIp as Request, res as Response, next);

      expect(doctorService.reject).toHaveBeenCalledWith(
        'doctor-123',
        { reason: 'Invalid docs' },
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor rejected'
      );
    });
  });

  describe('suspend', () => {
    it('should suspend a doctor', async () => {
      const mockDoctor = { id: 'doctor-123', isSuspended: true };
      (doctorService.suspend as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.suspend(reqWithIp as Request, res as Response, next);

      expect(doctorService.suspend).toHaveBeenCalledWith(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor suspended successfully'
      );
    });
  });

  describe('unsuspend', () => {
    it('should unsuspend a doctor', async () => {
      const mockDoctor = { id: 'doctor-123', isSuspended: false };
      (doctorService.unsuspend as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.unsuspend(reqWithIp as Request, res as Response, next);

      expect(doctorService.unsuspend).toHaveBeenCalledWith(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor unsuspended successfully'
      );
    });
  });

  describe('getDocuments', () => {
    it('should get doctor documents', async () => {
      const mockDocs = [{ id: 'doc-1', fileName: 'degree.pdf' }];
      (doctorService.getDocuments as jest.Mock).mockResolvedValue(mockDocs);

      req.params = { id: 'doctor-123' };

      await controller.getDocuments(req as Request, res as Response, next);

      expect(doctorService.getDocuments).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDocs,
        'Documents retrieved successfully'
      );
    });
  });

  // ============================================================
  // Self-Service Routes
  // ============================================================

  describe('getMyProfile', () => {
    it('should return the current doctor profile', async () => {
      const mockDoctor = { id: 'doctor-123', name: 'Dr. Self' };
      (doctorService.findById as jest.Mock).mockResolvedValue(mockDoctor);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyProfile(req as Request, res as Response, next);

      expect(doctorService.findById).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Profile retrieved successfully'
      );
    });
  });

  describe('completeMyProfile', () => {
    it('should complete profile without file', async () => {
      const mockDoctor = { id: 'doctor-123', isCompleted: true };
      (doctorService.completeProfile as jest.Mock).mockResolvedValue(mockDoctor);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { bioFr: 'Test bio' };
      req.file = undefined;

      await controller.completeMyProfile(req as Request, res as Response, next);

      expect(doctorService.completeProfile).toHaveBeenCalledWith(
        'doctor-123',
        { bioFr: 'Test bio' },
        undefined
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Profile completed successfully'
      );
    });

    it('should complete profile with file', async () => {
      const mockDoctor = { id: 'doctor-123', isCompleted: true };
      (doctorService.completeProfile as jest.Mock).mockResolvedValue(mockDoctor);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { bioFr: 'Test bio' };
      req.file = { originalname: 'photo.jpg' } as any;

      await controller.completeMyProfile(req as Request, res as Response, next);

      expect(doctorService.completeProfile).toHaveBeenCalledWith(
        'doctor-123',
        { bioFr: 'Test bio' },
        req.file
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Profile completed successfully'
      );
    });
  });

  describe('uploadMyDocument', () => {
    it('should upload a document', async () => {
      const mockDoc = { id: 'doc-123', fileName: 'degree.pdf' };
      (doctorService.uploadDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.file = { originalname: 'degree.pdf' } as any;
      req.body = { docType: 'degree' };

      await controller.uploadMyDocument(req as Request, res as Response, next);

      expect(doctorService.uploadDocument).toHaveBeenCalledWith(
        'doctor-123',
        req.file,
        'degree'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document uploaded successfully'
      );
    });

    it('should use default docType', async () => {
      const mockDoc = { id: 'doc-123', fileName: 'file.pdf' };
      (doctorService.uploadDocument as jest.Mock).mockResolvedValue(mockDoc);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.file = { originalname: 'file.pdf' } as any;
      req.body = {};

      await controller.uploadMyDocument(req as Request, res as Response, next);

      expect(doctorService.uploadDocument).toHaveBeenCalledWith(
        'doctor-123',
        req.file,
        'other'
      );
    });

    it('should return 400 when no file provided', async () => {
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.file = undefined;

      await controller.uploadMyDocument(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Document file is required'
      );
      expect(doctorService.uploadDocument).not.toHaveBeenCalled();
    });
  });

  describe('getMyDocuments', () => {
    it('should get current doctor documents', async () => {
      const mockDocs = [{ id: 'doc-1', fileName: 'degree.pdf' }];
      (doctorService.getDocuments as jest.Mock).mockResolvedValue(mockDocs);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyDocuments(req as Request, res as Response, next);

      expect(doctorService.getDocuments).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDocs,
        'Documents retrieved successfully'
      );
    });
  });

  describe('deleteMyDocument', () => {
    it('should delete a document', async () => {
      (doctorService.deleteDocument as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'doc-123' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.deleteMyDocument(req as Request, res as Response, next);

      expect(doctorService.deleteDocument).toHaveBeenCalledWith(
        'doc-123',
        'doctor-123',
        'DOCTOR'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Document deleted successfully'
      );
    });
  });

  // ============================================================
  // Clinic Invitations
  // ============================================================

  describe('requestToJoinClinic', () => {
    it('should request to join a clinic', async () => {
      const mockResult = { id: 'link-123', status: 'PENDING' };
      (doctorService.requestToJoinClinic as jest.Mock).mockResolvedValue(mockResult);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { clinicId: 'clinic-123' };

      await controller.requestToJoinClinic(req as Request, res as Response, next);

      expect(doctorService.requestToJoinClinic).toHaveBeenCalledWith(
        'doctor-123',
        'clinic-123'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockResult,
        'Request sent to clinic'
      );
    });
  });

  describe('getMyInvitations', () => {
    it('should get invitations', async () => {
      const mockInvitations = [{ id: 'inv-1', status: 'PENDING' }];
      (doctorService.getMyInvitations as jest.Mock).mockResolvedValue(mockInvitations);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyInvitations(req as Request, res as Response, next);

      expect(doctorService.getMyInvitations).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockInvitations,
        'Invitations retrieved successfully'
      );
    });
  });

  describe('respondToInvitation', () => {
    it('should accept an invitation', async () => {
      const mockResult = { id: 'inv-123', status: 'ACCEPTED' };
      (doctorService.respondToClinicInvitation as jest.Mock).mockResolvedValue(mockResult);

      req.params = { id: 'inv-123', action: 'accept' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.respondToInvitation(req as Request, res as Response, next);

      expect(doctorService.respondToClinicInvitation).toHaveBeenCalledWith(
        'inv-123',
        'doctor-123',
        'ACCEPTED'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockResult,
        'Invitation accepted'
      );
    });

    it('should reject an invitation', async () => {
      const mockResult = { id: 'inv-123', status: 'REJECTED' };
      (doctorService.respondToClinicInvitation as jest.Mock).mockResolvedValue(mockResult);

      req.params = { id: 'inv-123', action: 'reject' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.respondToInvitation(req as Request, res as Response, next);

      expect(doctorService.respondToClinicInvitation).toHaveBeenCalledWith(
        'inv-123',
        'doctor-123',
        'REJECTED'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockResult,
        'Invitation rejected'
      );
    });
  });

  // ============================================================
  // Availability
  // ============================================================

  describe('getMyAvailability', () => {
    it('should get availability slots', async () => {
      const mockSlots = [{ id: 'slot-1', dayOfWeek: 'MONDAY' }];
      (doctorService.getMyAvailability as jest.Mock).mockResolvedValue(mockSlots);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyAvailability(req as Request, res as Response, next);

      expect(doctorService.getMyAvailability).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockSlots,
        'Availability retrieved successfully'
      );
    });
  });

  describe('setMyAvailability', () => {
    it('should set availability', async () => {
      const mockSlots = [{ id: 'slot-1', dayOfWeek: 'MONDAY' }];
      (doctorService.setMyAvailability as jest.Mock).mockResolvedValue(mockSlots);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { slots: [{ dayOfWeek: 'MONDAY', startTime: '09:00', endTime: '17:00' }] };

      await controller.setMyAvailability(req as Request, res as Response, next);

      expect(doctorService.setMyAvailability).toHaveBeenCalledWith(
        'doctor-123',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockSlots,
        'Availability updated successfully'
      );
    });
  });

  describe('deleteAvailabilitySlot', () => {
    it('should delete an availability slot', async () => {
      (doctorService.deleteAvailabilitySlot as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'slot-1' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.deleteAvailabilitySlot(req as Request, res as Response, next);

      expect(doctorService.deleteAvailabilitySlot).toHaveBeenCalledWith(
        'slot-1',
        'doctor-123'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Availability slot removed'
      );
    });
  });

  describe('getDoctorAvailability', () => {
    it('should get doctor availability (staff)', async () => {
      const mockSlots = [{ id: 'slot-1', dayOfWeek: 'MONDAY' }];
      (doctorService.getDoctorAvailability as jest.Mock).mockResolvedValue(mockSlots);

      req.params = { id: 'doctor-123' };

      await controller.getDoctorAvailability(req as Request, res as Response, next);

      expect(doctorService.getDoctorAvailability).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockSlots,
        'Doctor availability retrieved'
      );
    });
  });

  // ============================================================
  // Breaks
  // ============================================================

  describe('getMyBreaks', () => {
    it('should get breaks', async () => {
      const mockBreaks = [{ id: 'break-1', reason: 'Vacation' }];
      (doctorService.getMyBreaks as jest.Mock).mockResolvedValue(mockBreaks);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.getMyBreaks(req as Request, res as Response, next);

      expect(doctorService.getMyBreaks).toHaveBeenCalledWith('doctor-123');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockBreaks,
        'Breaks retrieved successfully'
      );
    });
  });

  describe('createBreak', () => {
    it('should create a break', async () => {
      const mockBreak = { id: 'break-1', reason: 'Vacation' };
      (doctorService.createBreak as jest.Mock).mockResolvedValue(mockBreak);

      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { startDate: '2026-07-01', endDate: '2026-07-15', reason: 'Vacation' };

      await controller.createBreak(req as Request, res as Response, next);

      expect(doctorService.createBreak).toHaveBeenCalledWith('doctor-123', req.body);
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockBreak,
        'Break created successfully'
      );
    });
  });

  describe('updateBreak', () => {
    it('should update a break', async () => {
      const mockBreak = { id: 'break-1', reason: 'Extended vacation' };
      (doctorService.updateBreak as jest.Mock).mockResolvedValue(mockBreak);

      req.params = { id: 'break-1' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;
      req.body = { reason: 'Extended vacation' };

      await controller.updateBreak(req as Request, res as Response, next);

      expect(doctorService.updateBreak).toHaveBeenCalledWith(
        'doctor-123',
        'break-1',
        req.body
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockBreak,
        'Break updated successfully'
      );
    });
  });

  describe('deleteBreak', () => {
    it('should delete a break', async () => {
      (doctorService.deleteBreak as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'break-1' };
      req.user = { id: 'doctor-123', role: 'DOCTOR' } as any;

      await controller.deleteBreak(req as Request, res as Response, next);

      expect(doctorService.deleteBreak).toHaveBeenCalledWith('doctor-123', 'break-1');
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Break deleted successfully'
      );
    });
  });

  // ============================================================
  // Additional Staff Routes
  // ============================================================

  describe('create', () => {
    it('should create a basic doctor', async () => {
      const mockDoctor = { id: 'doctor-123' };
      (doctorService.createDoctor as jest.Mock).mockResolvedValue(mockDoctor);

      req.body = { email: 'doctor@example.com', password: 'Password123!' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.create(reqWithIp as Request, res as Response, next);

      expect(doctorService.createDoctor).toHaveBeenCalledWith(
        req.body,
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor created successfully'
      );
    });
  });

  describe('createComplete', () => {
    it('should create a complete doctor without file', async () => {
      const mockDoctor = { id: 'doctor-123', isCompleted: true };
      (doctorService.createCompleteDoctor as jest.Mock).mockResolvedValue(mockDoctor);

      req.body = { email: 'doctor@example.com', password: 'Password123!' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;
      req.file = undefined;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;
      reqWithIp.file = req.file;

      await controller.createComplete(reqWithIp as Request, res as Response, next);

      expect(doctorService.createCompleteDoctor).toHaveBeenCalledWith(
        req.body,
        undefined,
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor created successfully'
      );
    });

    it('should create a complete doctor with file', async () => {
      const mockDoctor = { id: 'doctor-123', isCompleted: true };
      (doctorService.createCompleteDoctor as jest.Mock).mockResolvedValue(mockDoctor);

      req.body = { email: 'doctor@example.com', password: 'Password123!' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;
      req.file = { originalname: 'photo.jpg' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;
      reqWithIp.file = req.file;

      await controller.createComplete(reqWithIp as Request, res as Response, next);

      expect(doctorService.createCompleteDoctor).toHaveBeenCalledWith(
        req.body,
        req.file,
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Doctor created successfully'
      );
    });
  });

  describe('uploadDocumentForDoctor', () => {
    it('should upload document for a doctor (staff)', async () => {
      const mockDoc = { id: 'doc-123' };
      (doctorService.uploadDocumentForDoctor as jest.Mock).mockResolvedValue(mockDoc);

      req.params = { id: 'doctor-123' };
      req.file = { originalname: 'degree.pdf' } as any;
      req.body = { docType: 'degree' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.file = req.file;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.uploadDocumentForDoctor(reqWithIp as Request, res as Response, next);

      expect(doctorService.uploadDocumentForDoctor).toHaveBeenCalledWith(
        'doctor-123',
        req.file,
        'degree',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.created).toHaveBeenCalledWith(
        res,
        mockDoc,
        'Document uploaded successfully'
      );
    });

    it('should return 400 when no file provided', async () => {
      req.params = { id: 'doctor-123' };
      req.file = undefined;
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      await controller.uploadDocumentForDoctor(req as Request, res as Response, next);

      expect(ResponseUtil.badRequest).toHaveBeenCalledWith(
        res,
        'Document file is required'
      );
      expect(doctorService.uploadDocumentForDoctor).not.toHaveBeenCalled();
    });
  });

  describe('deleteDoctorDocument', () => {
    it('should delete a doctor document (staff)', async () => {
      (doctorService.deleteDoctorDocument as jest.Mock).mockResolvedValue(undefined);

      req.params = { id: 'doctor-123', documentId: 'doc-123' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.user = req.user;

      await controller.deleteDoctorDocument(reqWithIp as Request, res as Response, next);

      expect(doctorService.deleteDoctorDocument).toHaveBeenCalledWith(
        'doctor-123',
        'doc-123',
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        null,
        'Document deleted successfully'
      );
    });
  });

  // ============================================================
  // Update Booking Availability (NEW)
  // ============================================================

  describe('updateBookingAvailability', () => {
    it('should update booking availability', async () => {
      const mockDoctor = { id: 'doctor-123', isAvailableForBooking: true };
      (doctorService.updateBookingAvailability as jest.Mock).mockResolvedValue(mockDoctor);

      req.params = { id: 'doctor-123' };
      req.body = { isAvailableForBooking: true, messageForUser: 'Available now' };
      req.user = { id: 'admin-123', role: 'ADMIN' } as any;

      const reqWithIp = createRequestWithIp('127.0.0.1');
      reqWithIp.params = req.params;
      reqWithIp.body = req.body;
      reqWithIp.user = req.user;

      await controller.updateBookingAvailability(reqWithIp as Request, res as Response, next);

      expect(doctorService.updateBookingAvailability).toHaveBeenCalledWith(
        'doctor-123',
        { isAvailableForBooking: true, messageForUser: 'Available now' },
        'admin-123',
        '127.0.0.1'
      );
      expect(ResponseUtil.success).toHaveBeenCalledWith(
        res,
        mockDoctor,
        'Booking availability updated successfully'
      );
    });

    it('should forward errors to next', async () => {
      const error = new Error('Doctor not found');
      (doctorService.updateBookingAvailability as jest.Mock).mockRejectedValue(error);

      await controller.updateBookingAvailability(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledWith(error);
    });
  });
});

