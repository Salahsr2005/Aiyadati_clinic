// backend/tests/unit/modules/doctor/v1/doctor.service.test.ts

import bcrypt from 'bcryptjs';
import { DoctorService } from '../../../../../src/modules/doctor/v1/doctor.service';
import { doctorRepository } from '../../../../../src/repositories/doctor.repository';
import { doctorDocumentRepository } from '../../../../../src/repositories/doctor-document.repository';
import { doctorLogoRepository } from '../../../../../src/repositories/doctor-logo.repository';
import { doctorAvailabilityRepository } from '../../../../../src/repositories/doctor-availability.repository';
import { doctorBreakRepository } from '../../../../../src/repositories/doctor-break.repository';
import { clinicDoctorRepository } from '../../../../../src/repositories/clinic-doctor.repository';
import { clinicRepository } from '../../../../../src/repositories/clinic.repository';
import { fileService } from '../../../../../src/modules/file/v1/file.service';
import { eventEmitter } from '../../../../../src/core/events/event-emitter';
import {
  NotFoundError,
  ConflictError,
  BadRequestError,
  ForbiddenError,
} from '../../../../../src/core/utils/error';

// Mock all dependencies
jest.mock('../../../../../src/repositories/doctor.repository');
jest.mock('../../../../../src/repositories/doctor-document.repository');
jest.mock('../../../../../src/repositories/doctor-logo.repository');
jest.mock('../../../../../src/repositories/doctor-availability.repository');
jest.mock('../../../../../src/repositories/doctor-break.repository');
jest.mock('../../../../../src/repositories/clinic-doctor.repository');
jest.mock('../../../../../src/repositories/clinic.repository');
jest.mock('../../../../../src/modules/file/v1/file.service');
jest.mock('../../../../../src/core/events/event-emitter');
jest.mock('bcryptjs');

describe('DoctorService', () => {
  let doctorService: DoctorService;

  beforeEach(() => {
    doctorService = new DoctorService();
    jest.clearAllMocks();
  });

  // ============================================================
  // Helper Mocks
  // ============================================================

  const mockDoctor = {
    id: 'doctor-123',
    email: 'doctor@example.com',
    password: 'hashed-password',
    firstNameFr: 'Ahmed',
    firstNameAr: 'أحمد',
    lastNameFr: 'Benali',
    lastNameAr: 'بن علي',
    phone: '0665123456',
    wilayaId: 'wilaya-123',
    wilaya: { id: 'wilaya-123', code: 16, nameFr: 'Alger', nameAr: 'الجزائر' },
    baladyaId: null,
    baladya: null,
    bioFr: null,
    bioAr: null,
    photoPath: null,
    photoFileId: null,
    yearsOfExp: null,
    practiceType: 'INDEPENDENT',
    latitude: null,
    longitude: null,
    isVerified: false,
    isSuspended: false,
    rejectionReason: null,
    isCompleted: false,
    isRegistered: true,
    isAvailableForBooking: false,
    messageForUser: null,
    specialties: [],
    logos: [],
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockFile: Express.Multer.File = {
    fieldname: 'logo',
    originalname: 'photo.jpg',
    encoding: '7bit',
    mimetype: 'image/jpeg',
    size: 1024 * 1024,
    destination: '/uploads',
    filename: 'photo-123.jpg',
    path: '/uploads/photo-123.jpg',
    buffer: Buffer.from('fake image data'),
    stream: null as any,
  };

  // ============================================================
  // findById
  // ============================================================

  describe('findById', () => {
    it('should find a doctor by id successfully', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);

      const result = await doctorService.findById('doctor-123');

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(result.id).toBe('doctor-123');
      expect(result.email).toBe('doctor@example.com');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(doctorService.findById('non-existent')).rejects.toThrow(
        NotFoundError
      );
      await expect(doctorService.findById('non-existent')).rejects.toThrow(
        'Doctor not found'
      );
    });
  });

  // ============================================================
  // findAll
  // ============================================================

  describe('findAll', () => {
    it('should return paginated doctors with default params', async () => {
      const mockDoctors = [mockDoctor, { ...mockDoctor, id: 'doctor-456' }];
      (doctorRepository.findAll as jest.Mock).mockResolvedValue({
        doctors: mockDoctors,
        total: 2,
      });

      const result = await doctorService.findAll({});

      expect(doctorRepository.findAll).toHaveBeenCalledWith({
        page: 1,
        limit: 10,
        search: undefined,
        wilayaId: undefined,
        specialtyId: undefined,
        practiceType: undefined,
        isVerified: undefined,
        isSuspended: undefined,
        isCompleted: undefined,
        isAvailableForBooking: undefined,
        sortBy: 'createdAt',
        sortOrder: 'desc',
      });
      expect(result.doctors).toHaveLength(2);
      expect(result.total).toBe(2);
    });

    it('should parse boolean filters correctly', async () => {
      (doctorRepository.findAll as jest.Mock).mockResolvedValue({
        doctors: [],
        total: 0,
      });

      await doctorService.findAll({
        isVerified: 'true',
        isSuspended: 'false',
        isCompleted: 'true',
        isAvailableForBooking: 'true',
      });

      expect(doctorRepository.findAll).toHaveBeenCalledWith(
        expect.objectContaining({
          isVerified: true,
          isSuspended: false,
          isCompleted: true,
          isAvailableForBooking: true,
        })
      );
    });

    it('should parse numeric params correctly', async () => {
      (doctorRepository.findAll as jest.Mock).mockResolvedValue({
        doctors: [],
        total: 0,
      });

      await doctorService.findAll({
        page: '2',
        limit: '20',
      });

      expect(doctorRepository.findAll).toHaveBeenCalledWith(
        expect.objectContaining({
          page: 2,
          limit: 20,
        })
      );
    });
  });

  // ============================================================
  // createCompleteDoctor
  // ============================================================

  describe('createCompleteDoctor', () => {
    const createData = {
      email: 'newdoctor@example.com',
      password: 'Password123!',
      firstNameFr: 'Karim',
      firstNameAr: 'كريم',
      lastNameFr: 'Touati',
      lastNameAr: 'تواتي',
      phone: '0665999999',
      wilayaId: 'wilaya-123',
      specialtyIds: ['specialty-1', 'specialty-2'],
      bioFr: 'Cardiologue expert',
      bioAr: 'طبيب قلب خبير',
      yearsOfExp: 15,
      practiceType: 'BOTH' as const,
      latitude: 36.7538,
      longitude: 3.0588,
      baladyaId: 'baladya-123',
    };

    const createdDoctor = {
      ...mockDoctor,
      id: 'new-doctor-123',
      ...createData,
      password: 'hashed-password',
      isVerified: true,
      isCompleted: true,
      photoPath: null,
      photoFileId: null,
    };

    beforeEach(() => {
      (bcrypt.hash as jest.Mock).mockResolvedValue('hashed-password');
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.create as jest.Mock).mockResolvedValue(createdDoctor);
      (doctorRepository.setSpecialties as jest.Mock).mockResolvedValue(
        undefined
      );
      (doctorRepository.findById as jest.Mock).mockResolvedValue(createdDoctor);
    });

    it('should create a complete doctor without logo', async () => {
      const result = await doctorService.createCompleteDoctor(
        createData,
        undefined,
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.emailExists).toHaveBeenCalledWith(
        createData.email
      );
      expect(doctorRepository.phoneExists).toHaveBeenCalledWith(
        createData.phone
      );
      expect(bcrypt.hash).toHaveBeenCalledWith(createData.password, 12);
      expect(doctorRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          email: createData.email,
          firstNameFr: createData.firstNameFr,
          lastNameFr: createData.lastNameFr,
          phone: createData.phone,
          isVerified: true,
          isCompleted: true,
          isRegistered: false,
        })
      );
      expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'new-doctor-123',
        ['specialty-1', 'specialty-2']
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.complete_created_by_staff',
          entity: 'Doctor',
          entityId: 'new-doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'new-doctor-123',
          title: 'Welcome to Iyadati!',
        })
      );
      expect(result.isVerified).toBe(true);
      expect(result.isCompleted).toBe(true);
      expect(result.photoFileId).toBeNull();
    });

    it('should create a complete doctor with logo upload', async () => {
      const mockLogo = {
        id: 'logo-123',
        fileId: 'file-123',
        filePath: 'public/logos/photo-123.jpg',
        fileName: 'photo.jpg',
        fileType: 'image/jpeg',
        fileSize: 1024 * 1024,
      };

      const doctorWithLogo = {
        ...createdDoctor,
        photoPath: 'photo-123.jpg',
        photoFileId: 'file-123',
      };

      (doctorLogoRepository.create as jest.Mock).mockResolvedValue(mockLogo);
      (doctorRepository.update as jest.Mock).mockResolvedValue(doctorWithLogo);
      (doctorRepository.findById as jest.Mock).mockResolvedValue(doctorWithLogo);

      const result = await doctorService.createCompleteDoctor(
        createData,
        mockFile,
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorLogoRepository.create).toHaveBeenCalledWith({
        doctorId: 'new-doctor-123',
        filePath: 'public/logos/photo-123.jpg',
        fileName: 'photo.jpg',
        fileType: 'image/jpeg',
        fileSize: 1024 * 1024,
        storageKey: 'photo-123.jpg',
      });
      expect(doctorRepository.update).toHaveBeenCalledWith('new-doctor-123', {
        photoPath: 'photo-123.jpg',
        photoFileId: 'file-123',
      });
      expect(result.photoFileId).toBe('file-123');
    });

    it('should throw ConflictError when email already exists', async () => {
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(true);

      await expect(
        doctorService.createCompleteDoctor(createData, undefined)
      ).rejects.toThrow(ConflictError);
      await expect(
        doctorService.createCompleteDoctor(createData, undefined)
      ).rejects.toThrow('Email already exists');
    });

    it('should throw ConflictError when phone already exists', async () => {
      (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(true);

      await expect(
        doctorService.createCompleteDoctor(createData, undefined)
      ).rejects.toThrow(ConflictError);
      await expect(
        doctorService.createCompleteDoctor(createData, undefined)
      ).rejects.toThrow('Phone already exists');
    });

    it('should throw BadRequestError when no specialties provided', async () => {
      const dataWithoutSpecialties = {
        ...createData,
        specialtyIds: [],
      };

      await expect(
        doctorService.createCompleteDoctor(dataWithoutSpecialties, undefined)
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.createCompleteDoctor(dataWithoutSpecialties, undefined)
      ).rejects.toThrow('At least one specialty is required');
    });
  });

  // ============================================================
  // update
  // ============================================================

  describe('update', () => {
    const updateData = {
      firstNameFr: 'Karim',
      lastNameFr: 'Touati',
      phone: '0665999999',
      email: 'karim@example.com',
      bioFr: 'Updated bio',
      yearsOfExp: 20,
      practiceType: 'BOTH' as const,
      isVerified: true,
      specialtyIds: ['specialty-3'],
    };

    const updatedDoctor = {
      ...mockDoctor,
      ...updateData,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.update as jest.Mock).mockResolvedValue(updatedDoctor);
      (doctorRepository.setSpecialties as jest.Mock).mockResolvedValue(
        undefined
      );
      (doctorRepository.findById as jest.Mock).mockResolvedValue(updatedDoctor);
    });

    it('should update a doctor successfully', async () => {
      const result = await doctorService.update('doctor-123', updateData);

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorRepository.update).toHaveBeenCalledWith(
        'doctor-123',
        expect.objectContaining({
          firstNameFr: 'Karim',
          lastNameFr: 'Touati',
          bioFr: 'Updated bio',
          yearsOfExp: 20,
          isVerified: true,
        })
      );
      expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        ['specialty-3']
      );
      expect(result.firstNameFr).toBe('Karim');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(doctorService.update('non-existent', updateData)).rejects.toThrow(
        NotFoundError
      );
    });

    it('should check email uniqueness when email is changed', async () => {
      await doctorService.update('doctor-123', { email: 'new@example.com' });

      expect(doctorRepository.emailExists).toHaveBeenCalledWith(
        'new@example.com',
        'doctor-123'
      );
    });

    it('should throw ConflictError when email already exists', async () => {
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(true);

      await expect(
        doctorService.update('doctor-123', { email: 'exists@example.com' })
      ).rejects.toThrow(ConflictError);
    });

    it('should check phone uniqueness when phone is changed', async () => {
    // Mock the existing doctor with a different phone
    const existingDoctorWithDifferentPhone = {
        ...mockDoctor,
        phone: '0665000000',
    };
    
    (doctorRepository.findById as jest.Mock)
        .mockResolvedValueOnce(existingDoctorWithDifferentPhone)
        .mockResolvedValueOnce({
        ...existingDoctorWithDifferentPhone,
        phone: '0665999999',
        });
    
    (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(false);
    (doctorRepository.update as jest.Mock).mockResolvedValue({
        ...existingDoctorWithDifferentPhone,
        phone: '0665999999',
    });

    await doctorService.update('doctor-123', { phone: '0665999999' });

    expect(doctorRepository.phoneExists).toHaveBeenCalledWith(
        '0665999999',
        'doctor-123'
    );
    });

    it('should handle string specialtyIds', async () => {
      await doctorService.update('doctor-123', {
        specialtyIds: 'specialty-1,specialty-2,specialty-3' as any,
      });

      expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        ['specialty-1', 'specialty-2', 'specialty-3']
      );
    });

    it('should handle empty specialtyIds', async () => {
      await doctorService.update('doctor-123', { specialtyIds: '' as any });

      expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        []
      );
    });
  });

  // ============================================================
  // verify
  // ============================================================

  describe('verify', () => {
    const verifiedDoctor = {
      ...mockDoctor,
      isVerified: true,
      rejectionReason: null,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorRepository.verify as jest.Mock).mockResolvedValue(verifiedDoctor);
    });

    it('should verify a doctor successfully', async () => {
      const result = await doctorService.verify(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorRepository.verify).toHaveBeenCalledWith('doctor-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.verified',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: 'Account Verified!',
        })
      );
      expect(result.isVerified).toBe(true);
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.verify('non-existent', 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when already verified', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isVerified: true,
      });

      await expect(
        doctorService.verify('doctor-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.verify('doctor-123', 'admin-123')
      ).rejects.toThrow('Doctor is already verified');
    });
  });

  // ============================================================
  // reject
  // ============================================================

  describe('reject', () => {
    const rejectedDoctor = {
      ...mockDoctor,
      isVerified: false,
      rejectionReason: 'Invalid documents',
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorRepository.reject as jest.Mock).mockResolvedValue(rejectedDoctor);
    });

    it('should reject a doctor with reason', async () => {
      const result = await doctorService.reject(
        'doctor-123',
        { reason: 'Invalid documents' },
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.reject).toHaveBeenCalledWith(
        'doctor-123',
        'Invalid documents'
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.rejected',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: 'Account Not Approved',
        })
      );
      expect(result.rejectionReason).toBe('Invalid documents');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.reject('non-existent', { reason: 'test' }, 'admin-123')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // suspend / unsuspend
  // ============================================================

  describe('suspend', () => {
    const suspendedDoctor = {
      ...mockDoctor,
      isSuspended: true,
      isAvailableForBooking: false,
      messageForUser: 'Account suspended',
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorRepository.suspend as jest.Mock).mockResolvedValue(
        suspendedDoctor
      );
      (doctorRepository.updateBookingAvailability as jest.Mock).mockResolvedValue(
        suspendedDoctor
      );
    });

    it('should suspend a doctor and disable booking availability', async () => {
      const result = await doctorService.suspend(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.suspend).toHaveBeenCalledWith('doctor-123');
      expect(
        doctorRepository.updateBookingAvailability
      ).toHaveBeenCalledWith('doctor-123', {
        isAvailableForBooking: false,
        messageForUser: 'Account suspended',
      });
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.suspended',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: 'Account Suspended',
        })
      );
      expect(result.isSuspended).toBe(true);
    });

    it('should throw BadRequestError when already suspended', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isSuspended: true,
      });

      await expect(
        doctorService.suspend('doctor-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  describe('unsuspend', () => {
    const unsuspendedDoctor = {
      ...mockDoctor,
      isSuspended: false,
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isSuspended: true,
      });
      (doctorRepository.unsuspend as jest.Mock).mockResolvedValue(
        unsuspendedDoctor
      );
    });

    it('should unsuspend a doctor successfully', async () => {
      const result = await doctorService.unsuspend(
        'doctor-123',
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.unsuspend).toHaveBeenCalledWith('doctor-123');
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.unsuspended',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(result.isSuspended).toBe(false);
    });

    it('should throw BadRequestError when not suspended', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);

      await expect(
        doctorService.unsuspend('doctor-123', 'admin-123')
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // updateBookingAvailability
  // ============================================================

  describe('updateBookingAvailability', () => {
    const doctorWithBooking = {
      ...mockDoctor,
      isAvailableForBooking: true,
      messageForUser: 'Available now',
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
    });

    it('should enable booking availability with message', async () => {
      (doctorRepository.updateBookingAvailability as jest.Mock).mockResolvedValue(
        doctorWithBooking
      );
      (doctorRepository.findById as jest.Mock)
        .mockResolvedValueOnce(mockDoctor)
        .mockResolvedValueOnce(doctorWithBooking);

      const result = await doctorService.updateBookingAvailability(
        'doctor-123',
        { isAvailableForBooking: true, messageForUser: 'Available now' },
        'admin-123',
        '127.0.0.1'
      );

      expect(
        doctorRepository.updateBookingAvailability
      ).toHaveBeenCalledWith('doctor-123', {
        isAvailableForBooking: true,
        messageForUser: 'Available now',
      });
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.booking_enabled',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: '📅 Booking Availability Updated',
        })
      );
      expect(result.isAvailableForBooking).toBe(true);
      expect(result.messageForUser).toBe('Available now');
    });

    it('should enable booking availability without message', async () => {
      (doctorRepository.updateBookingAvailability as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isAvailableForBooking: true,
        messageForUser: null,
      });
      (doctorRepository.findById as jest.Mock)
        .mockResolvedValueOnce(mockDoctor)
        .mockResolvedValueOnce({
          ...mockDoctor,
          isAvailableForBooking: true,
          messageForUser: null,
        });

      const result = await doctorService.updateBookingAvailability(
        'doctor-123',
        { isAvailableForBooking: true },
        'admin-123',
        '127.0.0.1'
      );

      expect(
        doctorRepository.updateBookingAvailability
      ).toHaveBeenCalledWith('doctor-123', {
        isAvailableForBooking: true,
        messageForUser: null,
      });
      expect(result.isAvailableForBooking).toBe(true);
    });

    it('should disable booking availability and clear message', async () => {
      (doctorRepository.updateBookingAvailability as jest.Mock).mockResolvedValue({
        ...mockDoctor,
        isAvailableForBooking: false,
        messageForUser: null,
      });

      const result = await doctorService.updateBookingAvailability(
        'doctor-123',
        { isAvailableForBooking: false },
        'admin-123',
        '127.0.0.1'
      );

      expect(
        doctorRepository.updateBookingAvailability
      ).toHaveBeenCalledWith('doctor-123', {
        isAvailableForBooking: false,
        messageForUser: null,
      });
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.booking_disabled',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(result.isAvailableForBooking).toBe(false);
      expect(result.messageForUser).toBeNull();
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.updateBookingAvailability(
          'non-existent',
          { isAvailableForBooking: true },
          'admin-123'
        )
      ).rejects.toThrow(NotFoundError);
    });
  });

// ============================================================
// completeProfile
// ============================================================

    describe('completeProfile', () => {
    const verifiedDoctor = {
        ...mockDoctor,
        isVerified: true,
    };

    beforeEach(() => {
        (doctorRepository.findById as jest.Mock).mockResolvedValue(verifiedDoctor);
    });

    it('should complete profile without logo', async () => {
        const updatedDoctor = {
        ...verifiedDoctor,
        isCompleted: true,
        bioFr: 'Test bio',
        photoPath: null,
        photoFileId: null,
        };
        
        (doctorRepository.update as jest.Mock).mockResolvedValue(updatedDoctor);
        (doctorRepository.findById as jest.Mock).mockResolvedValue(updatedDoctor);
        (doctorRepository.setSpecialties as jest.Mock).mockResolvedValue(undefined);

        const result = await doctorService.completeProfile(
        'doctor-123',
        { bioFr: 'Test bio', specialtyIds: ['specialty-1'] },
        undefined
        );

        expect(doctorRepository.update).toHaveBeenCalledWith(
        'doctor-123',
        expect.objectContaining({
            isCompleted: true,
            bioFr: 'Test bio',
        })
        );
        expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        ['specialty-1']
        );
        expect(result.isCompleted).toBe(true);
    });

    it('should complete profile with logo upload', async () => {
        const mockLogo = {
        id: 'logo-123',
        fileId: 'file-123',
        filePath: 'public/logos/photo-123.jpg',
        fileName: 'photo.jpg',
        fileType: 'image/jpeg',
        fileSize: 1024 * 1024,
        };

        const updatedDoctorWithPhoto = {
        ...verifiedDoctor,
        isCompleted: true,
        photoPath: 'photo-123.jpg',
        photoFileId: 'file-123',
        bioFr: 'Test bio',
        };

        (doctorLogoRepository.create as jest.Mock).mockResolvedValue(mockLogo);
        (doctorRepository.update as jest.Mock).mockResolvedValue(updatedDoctorWithPhoto);
        (doctorRepository.findById as jest.Mock).mockResolvedValue(updatedDoctorWithPhoto);
        (doctorRepository.setSpecialties as jest.Mock).mockResolvedValue(undefined);

        const result = await doctorService.completeProfile(
        'doctor-123',
        { bioFr: 'Test bio' },
        mockFile
        );

        expect(doctorLogoRepository.create).toHaveBeenCalledWith({
        doctorId: 'doctor-123',
        filePath: 'public/logos/photo-123.jpg',
        fileName: 'photo.jpg',
        fileType: 'image/jpeg',
        fileSize: 1024 * 1024,
        storageKey: 'photo-123.jpg',
        });
        expect(doctorRepository.update).toHaveBeenCalledWith(
        'doctor-123',
        expect.objectContaining({
            photoPath: 'photo-123.jpg',
            photoFileId: 'file-123',
            isCompleted: true,
        })
        );
        expect(result.photoFileId).toBe('file-123');
    });

    it('should parse specialtyIds from string', async () => {
        const updatedDoctor = {
        ...verifiedDoctor,
        isCompleted: true,
        };
        
        (doctorRepository.update as jest.Mock).mockResolvedValue(updatedDoctor);
        (doctorRepository.findById as jest.Mock).mockResolvedValue(updatedDoctor);

        await doctorService.completeProfile(
        'doctor-123',
        { specialtyIds: 'specialty-1,specialty-2' as any },
        undefined
        );

        expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        ['specialty-1', 'specialty-2']
        );
    });

    it('should parse specialtyIds from JSON string', async () => {
        const updatedDoctor = {
        ...verifiedDoctor,
        isCompleted: true,
        };
        
        (doctorRepository.update as jest.Mock).mockResolvedValue(updatedDoctor);
        (doctorRepository.findById as jest.Mock).mockResolvedValue(updatedDoctor);

        await doctorService.completeProfile(
        'doctor-123',
        { specialtyIds: '["specialty-1","specialty-2"]' as any },
        undefined
        );

        expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'doctor-123',
        ['specialty-1', 'specialty-2']
        );
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
        (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

        await expect(
        doctorService.completeProfile('non-existent', {})
        ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor is not verified', async () => {
        (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);

        await expect(
        doctorService.completeProfile('doctor-123', {})
        ).rejects.toThrow(BadRequestError);
        await expect(
        doctorService.completeProfile('doctor-123', {})
        ).rejects.toThrow('Doctor must be verified before completing profile');
    });
    });
  // ============================================================
  // createDoctor (Basic doctor creation)
  // ============================================================

  describe('createDoctor', () => {
    const createData = {
      email: 'basicdoctor@example.com',
      password: 'Password123!',
      firstNameFr: 'Basic',
      firstNameAr: 'أساسي',
      lastNameFr: 'Doctor',
      lastNameAr: 'طبيب',
      phone: '0665888888',
      wilayaId: 'wilaya-123',
      specialtyIds: ['specialty-1'],
    };

    const createdDoctor = {
      ...mockDoctor,
      id: 'basic-doctor-123',
      ...createData,
      password: 'hashed-password',
      isVerified: true,
      isRegistered: false,
      isCompleted: false,
    };

    beforeEach(() => {
      (bcrypt.hash as jest.Mock).mockResolvedValue('hashed-password');
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(false);
      (doctorRepository.create as jest.Mock).mockResolvedValue(createdDoctor);
      (doctorRepository.setSpecialties as jest.Mock).mockResolvedValue(
        undefined
      );
      (doctorRepository.findById as jest.Mock).mockResolvedValue(createdDoctor);
    });

    it('should create a basic doctor successfully', async () => {
      const result = await doctorService.createDoctor(
        createData,
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.emailExists).toHaveBeenCalledWith(createData.email);
      expect(doctorRepository.phoneExists).toHaveBeenCalledWith(createData.phone);
      expect(bcrypt.hash).toHaveBeenCalledWith(createData.password, 12);
      expect(doctorRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          email: createData.email,
          firstNameFr: createData.firstNameFr,
          lastNameFr: createData.lastNameFr,
          phone: createData.phone,
          isVerified: true,
          isRegistered: false,
          isCompleted: false,
        })
      );
      expect(doctorRepository.setSpecialties).toHaveBeenCalledWith(
        'basic-doctor-123',
        ['specialty-1']
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.created_by_staff',
          entity: 'Doctor',
          entityId: 'basic-doctor-123',
          performedBy: 'admin-123',
        })
      );
      expect(result.isVerified).toBe(true);
      expect(result.isCompleted).toBe(false);
    });

    it('should create a doctor without specialties', async () => {
      const dataWithoutSpecialties = { ...createData, specialtyIds: undefined };
      
      (doctorRepository.create as jest.Mock).mockResolvedValue({
        ...createdDoctor,
        ...dataWithoutSpecialties,
      });

      const result = await doctorService.createDoctor(
        dataWithoutSpecialties,
        'admin-123'
      );

      expect(doctorRepository.setSpecialties).not.toHaveBeenCalled();
      expect(result.id).toBe('basic-doctor-123');
    });

    it('should throw ConflictError when email already exists', async () => {
      (doctorRepository.emailExists as jest.Mock).mockResolvedValue(true);

      await expect(
        doctorService.createDoctor(createData, 'admin-123')
      ).rejects.toThrow(ConflictError);
      await expect(
        doctorService.createDoctor(createData, 'admin-123')
      ).rejects.toThrow('Email already exists');
    });

    it('should throw ConflictError when phone already exists', async () => {
      (doctorRepository.phoneExists as jest.Mock).mockResolvedValue(true);

      await expect(
        doctorService.createDoctor(createData, 'admin-123')
      ).rejects.toThrow(ConflictError);
      await expect(
        doctorService.createDoctor(createData, 'admin-123')
      ).rejects.toThrow('Phone already exists');
    });
  });

  // ============================================================
  // uploadDocument & uploadDocumentForDoctor
  // ============================================================

  describe('uploadDocument', () => {
    const mockDoc = {
      id: 'doc-789',
      doctorId: 'doctor-123',
      fileName: 'medical-degree.pdf',
      filePath: 'private/doctor-documents/doc-789.pdf',
      fileType: 'application/pdf',
      fileSize: 2 * 1024 * 1024,
      storageKey: 'doc-789.pdf',
      docType: 'degree',
      storageType: 'private',
      category: 'document',
      fileId: 'file-789',
      uploadedAt: new Date(),
      createdAt: new Date(),
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorDocumentRepository.create as jest.Mock).mockResolvedValue(mockDoc);
    });

    it('should upload a document successfully', async () => {
      const result = await doctorService.uploadDocument(
        'doctor-123',
        mockFile,
        'degree'
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorDocumentRepository.create).toHaveBeenCalledWith({
        doctorId: 'doctor-123',
        fileName: 'photo.jpg',
        filePath: 'private/doctor-documents/photo-123.jpg',
        fileType: 'image/jpeg',
        fileSize: 1024 * 1024,
        storageKey: 'photo-123.jpg',
        docType: 'degree',
        storageType: 'private',
        category: 'document',
      });
      expect(result).toMatchObject({
        id: 'doc-789',
        fileName: 'medical-degree.pdf',
        docType: 'degree',
      });
    });

    it('should use default docType when not provided', async () => {
      await doctorService.uploadDocument('doctor-123', mockFile, undefined as any);

      expect(doctorDocumentRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          docType: 'other',
        })
      );
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.uploadDocument('non-existent', mockFile, 'degree')
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('uploadDocumentForDoctor', () => {
    const mockDoc = {
      id: 'doc-789',
      doctorId: 'doctor-123',
      fileName: 'medical-degree.pdf',
      filePath: 'private/doctor-documents/doc-789.pdf',
      fileType: 'application/pdf',
      fileSize: 2 * 1024 * 1024,
      storageKey: 'doc-789.pdf',
      docType: 'degree',
      storageType: 'private',
      category: 'document',
      fileId: 'file-789',
      uploadedAt: new Date(),
      createdAt: new Date(),
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorDocumentRepository.create as jest.Mock).mockResolvedValue(mockDoc);
    });

    it('should upload a document for a doctor (staff)', async () => {
      const result = await doctorService.uploadDocumentForDoctor(
        'doctor-123',
        mockFile,
        'license',
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorDocumentRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          doctorId: 'doctor-123',
          docType: 'license',
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.document_uploaded_by_staff',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
          details: expect.objectContaining({
            documentId: 'doc-789',
            fileName: 'medical-degree.pdf',
            docType: 'license',
          }),
        })
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'notification',
        expect.objectContaining({
          userId: 'doctor-123',
          title: 'New Document Added',
        })
      );
      expect(result.id).toBe('doc-789');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.uploadDocumentForDoctor(
          'non-existent',
          mockFile,
          'degree',
          'admin-123'
        )
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // getDocuments
  // ============================================================

  describe('getDocuments', () => {
    const mockDocs = [
      {
        id: 'doc-1',
        doctorId: 'doctor-123',
        fileName: 'degree.pdf',
        fileType: 'application/pdf',
        fileSize: 1024,
        docType: 'degree',
        fileId: 'file-1',
        uploadedAt: new Date(),
        createdAt: new Date(),
      },
      {
        id: 'doc-2',
        doctorId: 'doctor-123',
        fileName: 'license.pdf',
        fileType: 'application/pdf',
        fileSize: 2048,
        docType: 'license',
        fileId: 'file-2',
        uploadedAt: new Date(),
        createdAt: new Date(),
      },
    ];

    beforeEach(() => {
      (doctorDocumentRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockDocs
      );
    });

    it('should return documents with signed URLs', async () => {
      const result = await doctorService.getDocuments('doctor-123');

      expect(doctorDocumentRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(result).toHaveLength(2);
      expect(result[0]).toMatchObject({
        id: 'doc-1',
        fileName: 'degree.pdf',
        docType: 'degree',
      });
      expect(result[0]).toHaveProperty('accessUrl');
      expect(typeof result[0].accessUrl).toBe('string');
    });

    it('should return empty array when no documents', async () => {
      (doctorDocumentRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        []
      );

      const result = await doctorService.getDocuments('doctor-123');

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // deleteDocument & deleteDoctorDocument
  // ============================================================

  describe('deleteDocument', () => {
    const mockDoc = {
      id: 'doc-789',
      doctorId: 'doctor-123',
      fileName: 'degree.pdf',
      fileId: 'file-789',
    };

    beforeEach(() => {
      (doctorDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDoc);
      (fileService.deleteFile as jest.Mock).mockResolvedValue(undefined);
      // Note: doctorDocumentRepository.delete is called inside fileService.deleteFile
      // So we don't need to mock it here - we just verify fileService was called
    });

    it('should delete document successfully (doctor owns it)', async () => {
      await doctorService.deleteDocument('doc-789', 'doctor-123', 'DOCTOR');

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-789',
        'doctor-123',
        'DOCTOR',
        false
      );
    });

    it('should allow admin to delete any document', async () => {
      await doctorService.deleteDocument('doc-789', 'admin-123', 'ADMIN');

      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-789',
        'admin-123',
        'ADMIN',
        false
      );
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (doctorDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.deleteDocument('non-existent', 'doctor-123', 'DOCTOR')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw ForbiddenError when not owner and not admin', async () => {
      await expect(
        doctorService.deleteDocument('doc-789', 'doctor-456', 'DOCTOR')
      ).rejects.toThrow(ForbiddenError);
      await expect(
        doctorService.deleteDocument('doc-789', 'doctor-456', 'DOCTOR')
      ).rejects.toThrow('You can only delete your own documents');
    });
  });

  describe('deleteDoctorDocument', () => {
    const mockDoc = {
      id: 'doc-789',
      doctorId: 'doctor-123',
      fileName: 'degree.pdf',
      fileId: 'file-789',
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorDocumentRepository.findById as jest.Mock).mockResolvedValue(mockDoc);
      (fileService.deleteFile as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete doctor document (staff)', async () => {
      await doctorService.deleteDoctorDocument(
        'doctor-123',
        'doc-789',
        'admin-123',
        '127.0.0.1'
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorDocumentRepository.findById).toHaveBeenCalledWith('doc-789');
      expect(fileService.deleteFile).toHaveBeenCalledWith(
        'file-789',
        'admin-123',
        'ADMIN',
        false
      );
      expect(eventEmitter.emit).toHaveBeenCalledWith(
        'audit',
        expect.objectContaining({
          action: 'doctor.document_deleted_by_staff',
          entity: 'Doctor',
          entityId: 'doctor-123',
          performedBy: 'admin-123',
        })
      );
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.deleteDoctorDocument(
          'non-existent',
          'doc-789',
          'admin-123'
        )
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when document does not exist', async () => {
      (doctorDocumentRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.deleteDoctorDocument(
          'doctor-123',
          'non-existent',
          'admin-123'
        )
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when document does not belong to doctor', async () => {
      const mockDocOther = {
        ...mockDoc,
        doctorId: 'doctor-456',
      };
      (doctorDocumentRepository.findById as jest.Mock).mockResolvedValue(
        mockDocOther
      );

      await expect(
        doctorService.deleteDoctorDocument(
          'doctor-123',
          'doc-789',
          'admin-123'
        )
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.deleteDoctorDocument(
          'doctor-123',
          'doc-789',
          'admin-123'
        )
      ).rejects.toThrow('Document does not belong to this doctor');
    });
  });

  // ============================================================
  // requestToJoinClinic
  // ============================================================

  describe('requestToJoinClinic', () => {
    const mockClinic = {
      id: 'clinic-123',
      nameFr: 'Test Clinic',
      nameAr: 'عيادة اختبار',
    };

    const mockLink = {
      id: 'link-123',
      clinicId: 'clinic-123',
      doctorId: 'doctor-123',
      status: 'PENDING',
      invitedBy: 'doctor',
      isActive: true,
      joinedAt: new Date(),
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (clinicRepository.findById as jest.Mock).mockResolvedValue(mockClinic);
      (clinicDoctorRepository.findByClinicAndDoctor as jest.Mock).mockResolvedValue(
        null
      );
      (clinicDoctorRepository.create as jest.Mock).mockResolvedValue(mockLink);
    });

    it('should request to join clinic successfully', async () => {
      const result = await doctorService.requestToJoinClinic(
        'doctor-123',
        'clinic-123'
      );

      expect(clinicRepository.findById).toHaveBeenCalledWith('clinic-123');
      expect(
        clinicDoctorRepository.findByClinicAndDoctor
      ).toHaveBeenCalledWith('clinic-123', 'doctor-123');
      expect(clinicDoctorRepository.create).toHaveBeenCalledWith({
        clinicId: 'clinic-123',
        doctorId: 'doctor-123',
        invitedBy: 'doctor',
      });
      expect(result.status).toBe('PENDING');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.requestToJoinClinic('non-existent', 'clinic-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when clinic does not exist', async () => {
      (clinicRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.requestToJoinClinic('doctor-123', 'non-existent')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when request already pending', async () => {
      (clinicDoctorRepository.findByClinicAndDoctor as jest.Mock).mockResolvedValue({
        status: 'PENDING',
      });

      await expect(
        doctorService.requestToJoinClinic('doctor-123', 'clinic-123')
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.requestToJoinClinic('doctor-123', 'clinic-123')
      ).rejects.toThrow('A request is already pending');
    });

    it('should throw BadRequestError when already in clinic', async () => {
      (clinicDoctorRepository.findByClinicAndDoctor as jest.Mock).mockResolvedValue({
        status: 'ACCEPTED',
        isActive: true,
      });

      await expect(
        doctorService.requestToJoinClinic('doctor-123', 'clinic-123')
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.requestToJoinClinic('doctor-123', 'clinic-123')
      ).rejects.toThrow('You are already in this clinic');
    });
  });

  // ============================================================
  // getMyInvitations
  // ============================================================

  describe('getMyInvitations', () => {
    const mockInvitations = [
      {
        id: 'link-1',
        clinicId: 'clinic-1',
        doctorId: 'doctor-123',
        status: 'PENDING',
        invitedBy: 'clinic',
        isActive: true,
        joinedAt: new Date(),
        clinic: {
          id: 'clinic-1',
          nameFr: 'Clinic One',
          nameAr: 'عيادة واحد',
          email: 'clinic1@example.com',
          phone: '0555000001',
          logoPath: null,
        },
      },
      {
        id: 'link-2',
        clinicId: 'clinic-2',
        doctorId: 'doctor-123',
        status: 'ACCEPTED',
        invitedBy: 'doctor',
        isActive: true,
        joinedAt: new Date(),
        clinic: {
          id: 'clinic-2',
          nameFr: 'Clinic Two',
          nameAr: 'عيادة اثنان',
          email: 'clinic2@example.com',
          phone: '0555000002',
          logoPath: 'logo.png',
        },
      },
    ];

    beforeEach(() => {
      (clinicDoctorRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockInvitations
      );
    });

    it('should return invitations with clinic details', async () => {
      const result = await doctorService.getMyInvitations('doctor-123');

      expect(clinicDoctorRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(result).toHaveLength(2);
      expect(result[0]).toMatchObject({
        id: 'link-1',
        status: 'PENDING',
        invitedBy: 'clinic',
        clinic: {
          id: 'clinic-1',
          nameFr: 'Clinic One',
        },
      });
      expect(result[1].clinic?.logoUrl).toBeDefined();
    });

    it('should return empty array when no invitations', async () => {
      (clinicDoctorRepository.findByDoctorId as jest.Mock).mockResolvedValue([]);

      const result = await doctorService.getMyInvitations('doctor-123');

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // respondToClinicInvitation
  // ============================================================

  describe('respondToClinicInvitation', () => {
    const mockLink = {
      id: 'link-123',
      clinicId: 'clinic-123',
      doctorId: 'doctor-123',
      status: 'PENDING',
      invitedBy: 'clinic',
      isActive: true,
      joinedAt: new Date(),
    };

    beforeEach(() => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(mockLink);
    });

    it('should accept invitation successfully', async () => {
      (clinicDoctorRepository.updateStatus as jest.Mock).mockResolvedValue({
        ...mockLink,
        status: 'ACCEPTED',
      });

      const result = await doctorService.respondToClinicInvitation(
        'link-123',
        'doctor-123',
        'ACCEPTED'
      );

      expect(clinicDoctorRepository.updateStatus).toHaveBeenCalledWith(
        'link-123',
        'ACCEPTED'
      );
      expect(result.status).toBe('ACCEPTED');
    });

    it('should reject invitation successfully', async () => {
      (clinicDoctorRepository.updateStatus as jest.Mock).mockResolvedValue({
        ...mockLink,
        status: 'REJECTED',
      });

      const result = await doctorService.respondToClinicInvitation(
        'link-123',
        'doctor-123',
        'REJECTED'
      );

      expect(clinicDoctorRepository.updateStatus).toHaveBeenCalledWith(
        'link-123',
        'REJECTED'
      );
      expect(result.status).toBe('REJECTED');
    });

    it('should throw NotFoundError when invitation not found', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.respondToClinicInvitation(
          'non-existent',
          'doctor-123',
          'ACCEPTED'
        )
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw BadRequestError when doctor does not match', async () => {
      await expect(
        doctorService.respondToClinicInvitation(
          'link-123',
          'doctor-456',
          'ACCEPTED'
        )
      ).rejects.toThrow(BadRequestError);
      await expect(
        doctorService.respondToClinicInvitation(
          'link-123',
          'doctor-456',
          'ACCEPTED'
        )
      ).rejects.toThrow('This invitation is not for you');
    });

    it('should throw BadRequestError when not pending', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockLink,
        status: 'ACCEPTED',
      });

      await expect(
        doctorService.respondToClinicInvitation(
          'link-123',
          'doctor-123',
          'ACCEPTED'
        )
      ).rejects.toThrow(BadRequestError);
    });

    it('should throw BadRequestError when not a clinic invitation', async () => {
      (clinicDoctorRepository.findById as jest.Mock).mockResolvedValue({
        ...mockLink,
        invitedBy: 'doctor',
      });

      await expect(
        doctorService.respondToClinicInvitation(
          'link-123',
          'doctor-123',
          'ACCEPTED'
        )
      ).rejects.toThrow(BadRequestError);
    });
  });

  // ============================================================
  // getMyAvailability & getDoctorAvailability
  // ============================================================

  describe('getMyAvailability', () => {
    const mockSlots = [
      {
        id: 'slot-1',
        doctorId: 'doctor-123',
        dayOfWeek: 'SUNDAY',
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        endTime: new Date('1970-01-01T12:00:00.000Z'),
        isActive: true,
        clinicId: null,
        roomId: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 'slot-2',
        doctorId: 'doctor-123',
        dayOfWeek: 'MONDAY',
        startTime: new Date('1970-01-01T14:00:00.000Z'),
        endTime: new Date('1970-01-01T17:00:00.000Z'),
        isActive: true,
        clinicId: 'clinic-1',
        roomId: 'room-1',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    beforeEach(() => {
      (doctorAvailabilityRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockSlots
      );
    });

    it('should return availability slots', async () => {
      const result = await doctorService.getMyAvailability('doctor-123');

      expect(doctorAvailabilityRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(result).toHaveLength(2);
      expect(result[0]).toMatchObject({
        id: 'slot-1',
        dayOfWeek: 'SUNDAY',
        startTime: '08:00',
        endTime: '12:00',
        clinicId: null,
      });
      expect(result[1]).toMatchObject({
        id: 'slot-2',
        dayOfWeek: 'MONDAY',
        startTime: '14:00',
        endTime: '17:00',
        clinicId: 'clinic-1',
        roomId: 'room-1',
      });
    });

    it('should return empty array when no slots', async () => {
      (doctorAvailabilityRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        []
      );

      const result = await doctorService.getMyAvailability('doctor-123');

      expect(result).toHaveLength(0);
    });
  });

  describe('getDoctorAvailability', () => {
    it('should call getMyAvailability with doctor id', async () => {
      const spy = jest.spyOn(doctorService, 'getMyAvailability');
      await doctorService.getDoctorAvailability('doctor-123');

      expect(spy).toHaveBeenCalledWith('doctor-123');
    });
  });

  // ============================================================
  // setMyAvailability
  // ============================================================

  describe('setMyAvailability', () => {
    const availabilityData = {
      slots: [
        {
          dayOfWeek: 'SUNDAY' as const,
          startTime: '08:00',
          endTime: '12:00',
          clinicId: undefined,
          roomId: undefined,
        },
        {
          dayOfWeek: 'MONDAY' as const,
          startTime: '14:00',
          endTime: '17:00',
          clinicId: 'clinic-1',
          roomId: 'room-1',
        },
      ],
    };

    const mockCreatedSlots = [
      {
        id: 'slot-1',
        doctorId: 'doctor-123',
        dayOfWeek: 'SUNDAY',
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        endTime: new Date('1970-01-01T12:00:00.000Z'),
        isActive: true,
        clinicId: null,
        roomId: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 'slot-2',
        doctorId: 'doctor-123',
        dayOfWeek: 'MONDAY',
        startTime: new Date('1970-01-01T14:00:00.000Z'),
        endTime: new Date('1970-01-01T17:00:00.000Z'),
        isActive: true,
        clinicId: 'clinic-1',
        roomId: 'room-1',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (
        doctorAvailabilityRepository.bulkCreate as jest.Mock
      ).mockResolvedValue(mockCreatedSlots);
    });

    it('should set availability successfully', async () => {
      const result = await doctorService.setMyAvailability(
        'doctor-123',
        availabilityData
      );

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorAvailabilityRepository.bulkCreate).toHaveBeenCalledWith(
        'doctor-123',
        expect.arrayContaining([
          expect.objectContaining({
            dayOfWeek: 'SUNDAY',
            startTime: expect.any(Date),
            endTime: expect.any(Date),
          }),
          expect.objectContaining({
            dayOfWeek: 'MONDAY',
            startTime: expect.any(Date),
            endTime: expect.any(Date),
            clinicId: 'clinic-1',
            roomId: 'room-1',
          }),
        ])
      );
      expect(result).toHaveLength(2);
      expect(result[0].dayOfWeek).toBe('SUNDAY');
      expect(result[0].startTime).toBe('08:00');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.setMyAvailability('non-existent', availabilityData)
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // deleteAvailabilitySlot
  // ============================================================

  describe('deleteAvailabilitySlot', () => {
    const mockSlot = {
      id: 'slot-1',
      doctorId: 'doctor-123',
      dayOfWeek: 'SUNDAY',
      startTime: new Date(),
      endTime: new Date(),
      isActive: true,
    };

    beforeEach(() => {
      (doctorAvailabilityRepository.findById as jest.Mock).mockResolvedValue(
        mockSlot
      );
      (doctorAvailabilityRepository.softDelete as jest.Mock).mockResolvedValue(
        undefined
      );
    });

    it('should delete availability slot successfully', async () => {
      await doctorService.deleteAvailabilitySlot('slot-1', 'doctor-123');

      expect(doctorAvailabilityRepository.findById).toHaveBeenCalledWith('slot-1');
      expect(doctorAvailabilityRepository.softDelete).toHaveBeenCalledWith(
        'slot-1'
      );
    });

    it('should throw NotFoundError when slot does not exist', async () => {
      (doctorAvailabilityRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.deleteAvailabilitySlot('non-existent', 'doctor-123')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when slot belongs to different doctor', async () => {
      (doctorAvailabilityRepository.findById as jest.Mock).mockResolvedValue({
        ...mockSlot,
        doctorId: 'doctor-456',
      });

      await expect(
        doctorService.deleteAvailabilitySlot('slot-1', 'doctor-123')
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // getMyBreaks
  // ============================================================

  describe('getMyBreaks', () => {
    const mockBreaks = [
      {
        id: 'break-1',
        doctorId: 'doctor-123',
        startDate: new Date('2026-07-01'),
        endDate: new Date('2026-07-15'),
        reason: 'Vacation',
        isAllDay: true,
        startTime: null,
        endTime: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 'break-2',
        doctorId: 'doctor-123',
        startDate: new Date('2026-08-25'),
        endDate: new Date('2026-08-25'),
        reason: 'Conference',
        isAllDay: false,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        endTime: new Date('1970-01-01T12:00:00.000Z'),
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    beforeEach(() => {
      (doctorBreakRepository.findByDoctorId as jest.Mock).mockResolvedValue(
        mockBreaks
      );
    });

    it('should return breaks', async () => {
      const result = await doctorService.getMyBreaks('doctor-123');

      expect(doctorBreakRepository.findByDoctorId).toHaveBeenCalledWith(
        'doctor-123'
      );
      expect(result).toHaveLength(2);
      expect(result[0]).toMatchObject({
        id: 'break-1',
        startDate: '2026-07-01',
        endDate: '2026-07-15',
        reason: 'Vacation',
        isAllDay: true,
        startTime: null,
        endTime: null,
      });
      expect(result[1]).toMatchObject({
        id: 'break-2',
        startDate: '2026-08-25',
        endDate: '2026-08-25',
        reason: 'Conference',
        isAllDay: false,
        startTime: '08:00',
        endTime: '12:00',
      });
    });

    it('should return empty array when no breaks', async () => {
      (doctorBreakRepository.findByDoctorId as jest.Mock).mockResolvedValue([]);

      const result = await doctorService.getMyBreaks('doctor-123');

      expect(result).toHaveLength(0);
    });
  });

  // ============================================================
  // createBreak
  // ============================================================

  describe('createBreak', () => {
    const breakData = {
      startDate: '2026-07-01',
      endDate: '2026-07-15',
      reason: 'Summer vacation',
      isAllDay: true,
    };

    const mockBreak = {
      id: 'break-1',
      doctorId: 'doctor-123',
      startDate: new Date('2026-07-01'),
      endDate: new Date('2026-07-15'),
      reason: 'Summer vacation',
      isAllDay: true,
      startTime: null,
      endTime: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    beforeEach(() => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(mockDoctor);
      (doctorBreakRepository.create as jest.Mock).mockResolvedValue(mockBreak);
    });

    it('should create an all-day break', async () => {
      const result = await doctorService.createBreak('doctor-123', breakData);

      expect(doctorRepository.findById).toHaveBeenCalledWith('doctor-123');
      expect(doctorBreakRepository.create).toHaveBeenCalledWith({
        doctorId: 'doctor-123',
        startDate: expect.any(Date),
        endDate: expect.any(Date),
        reason: 'Summer vacation',
        isAllDay: true,
        startTime: undefined,
        endTime: undefined,
      });
      expect(result).toMatchObject({
        id: 'break-1',
        startDate: '2026-07-01',
        endDate: '2026-07-15',
        reason: 'Summer vacation',
        isAllDay: true,
      });
    });

    it('should create a partial-day break with times', async () => {
      const partialBreakData = {
        startDate: '2026-08-25',
        endDate: '2026-08-25',
        reason: 'Conference',
        isAllDay: false,
        startTime: '08:00',
        endTime: '12:00',
      };

      const mockPartialBreak = {
        ...mockBreak,
        startDate: new Date('2026-08-25'),
        endDate: new Date('2026-08-25'),
        reason: 'Conference',
        isAllDay: false,
        startTime: new Date('1970-01-01T08:00:00.000Z'),
        endTime: new Date('1970-01-01T12:00:00.000Z'),
      };

      (doctorBreakRepository.create as jest.Mock).mockResolvedValue(
        mockPartialBreak
      );

      const result = await doctorService.createBreak(
        'doctor-123',
        partialBreakData
      );

      expect(doctorBreakRepository.create).toHaveBeenCalledWith(
        expect.objectContaining({
          isAllDay: false,
          startTime: expect.any(Date),
          endTime: expect.any(Date),
        })
      );
      expect(result.startTime).toBe('08:00');
      expect(result.endTime).toBe('12:00');
    });

    it('should throw NotFoundError when doctor does not exist', async () => {
      (doctorRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.createBreak('non-existent', breakData)
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // updateBreak
  // ============================================================

  describe('updateBreak', () => {
    const existingBreak = {
      id: 'break-1',
      doctorId: 'doctor-123',
      startDate: new Date('2026-07-01'),
      endDate: new Date('2026-07-15'),
      reason: 'Vacation',
      isAllDay: true,
      startTime: null,
      endTime: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const updatedBreak = {
      ...existingBreak,
      reason: 'Extended vacation',
      endDate: new Date('2026-07-20'),
    };

    beforeEach(() => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue(
        existingBreak
      );
      (doctorBreakRepository.update as jest.Mock).mockResolvedValue(updatedBreak);
    });

    it('should update break successfully', async () => {
      const result = await doctorService.updateBreak('doctor-123', 'break-1', {
        reason: 'Extended vacation',
        endDate: '2026-07-20',
      });

      expect(doctorBreakRepository.findById).toHaveBeenCalledWith('break-1');
      expect(doctorBreakRepository.update).toHaveBeenCalledWith('break-1', {
        reason: 'Extended vacation',
        endDate: expect.any(Date),
      });
      expect(result.reason).toBe('Extended vacation');
      expect(result.endDate).toBe('2026-07-20');
    });

    it('should throw NotFoundError when break does not exist', async () => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.updateBreak('doctor-123', 'non-existent', {})
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when break belongs to different doctor', async () => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue({
        ...existingBreak,
        doctorId: 'doctor-456',
      });

      await expect(
        doctorService.updateBreak('doctor-123', 'break-1', {})
      ).rejects.toThrow(NotFoundError);
    });
  });

  // ============================================================
  // deleteBreak
  // ============================================================

  describe('deleteBreak', () => {
    const existingBreak = {
      id: 'break-1',
      doctorId: 'doctor-123',
      startDate: new Date('2026-07-01'),
      endDate: new Date('2026-07-15'),
      reason: 'Vacation',
      isAllDay: true,
      startTime: null,
      endTime: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    beforeEach(() => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue(
        existingBreak
      );
      (doctorBreakRepository.delete as jest.Mock).mockResolvedValue(undefined);
    });

    it('should delete break successfully', async () => {
      await doctorService.deleteBreak('doctor-123', 'break-1');

      expect(doctorBreakRepository.findById).toHaveBeenCalledWith('break-1');
      expect(doctorBreakRepository.delete).toHaveBeenCalledWith('break-1');
    });

    it('should throw NotFoundError when break does not exist', async () => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue(null);

      await expect(
        doctorService.deleteBreak('doctor-123', 'non-existent')
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NotFoundError when break belongs to different doctor', async () => {
      (doctorBreakRepository.findById as jest.Mock).mockResolvedValue({
        ...existingBreak,
        doctorId: 'doctor-456',
      });

      await expect(
        doctorService.deleteBreak('doctor-123', 'break-1')
      ).rejects.toThrow(NotFoundError);
    });
  });
});

