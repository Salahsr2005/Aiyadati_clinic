Unit Tests First (Fast, no DB containers)
1. Core Utilities
bash
npm test -- tests/unit/core/utils/error.test.ts
npm test -- tests/unit/core/utils/response.test.ts
npm test -- tests/unit/core/utils/timezone.test.ts
2. Repository Unit Tests
bash
npm test -- tests/unit/repositories/admin.repository.test.ts
npm test -- tests/unit/repositories/super-admin.repository.test.ts
npm test -- tests/unit/repositories/user.repository.test.ts
npm test -- tests/unit/repositories/clinic.repository.test.ts
npm test -- tests/unit/repositories/doctor.repository.test.ts
npm test -- tests/unit/repositories/wallet.repository.test.ts
3. Auth Module Unit Tests
bash
npm test -- tests/unit/modules/auth/v1/auth.service.test.ts
npm test -- tests/unit/modules/auth/v1/auth.controller.test.ts
4. Smoke Test
bash
npm test -- tests/unit/smoke/smoke.test.ts
Integration Tests (Slower, spin up containers)
5. Repository Integration Tests
bash
npm test -- tests/integration/repositories/admin.repository.integration.test.ts
npm test -- tests/integration/repositories/super-admin.repository.integration.test.ts
npm test -- tests/integration/repositories/user.repository.integration.test.ts
npm test -- tests/integration/repositories/clinic.repository.integration.test.ts
npm test -- tests/integration/repositories/doctor.repository.integration.test.ts
npm test -- tests/integration/repositories/wallet.repository.integration.test.ts
6. Auth Module Integration Tests
bash
npm test -- tests/integration/modules/auth/v1/auth.integration.test.ts
7. Integration Smoke
bash
npm test -- tests/integration/smoke/smoke.test.ts
Quick Way - Run All at Once (But Might Lag)
bash
npm test

