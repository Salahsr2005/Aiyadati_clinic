import fs from 'node:fs';
import path from 'node:path';

export default async function teardown() {
  try {
    console.log('🧹 Cleaning up...');
    
    const container = (global as any).__TEST_CONTAINER__;
    
    if (container) {
      console.log('🛑 Stopping PostgreSQL container...');
      await container.stop();
      console.log('✅ Container stopped');
    }
    
    const dbUrlPath = path.resolve('.test-database-url');
    if (fs.existsSync(dbUrlPath)) {
      fs.unlinkSync(dbUrlPath);
    }
    
    console.log('✅ Cleanup complete!');
  } catch (error) {
    console.error('❌ Teardown failed:', error);
  }
}

