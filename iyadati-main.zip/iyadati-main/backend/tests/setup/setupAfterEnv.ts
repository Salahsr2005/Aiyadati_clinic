import { closeRedis } from '../../src/infrastructure/redis/client';
import { closeBullMqConnection } from '../../src/infrastructure/queues/connection';
import { emailQueue } from '../../src/infrastructure/queues/email/email.queue';
import { notificationQueue } from '../../src/infrastructure/queues/notification/notification.queue';

beforeEach(() => {
  jest.clearAllMocks();
});

afterEach(() => {
  jest.restoreAllMocks();
});

afterAll(async () => {
  await Promise.all([
    emailQueue.close(),
    notificationQueue.close(),
    closeBullMqConnection(),
    closeRedis(),
  ]);
});

