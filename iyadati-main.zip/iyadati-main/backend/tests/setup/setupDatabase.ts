import { PostgreSqlContainer } from '@testcontainers/postgresql';
import { execSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import path from 'node:path';

let container: any;

export default async function setup() {
  try {
    console.log('🚀 Starting PostgreSQL container...');
    
    container = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('iyadati_test')
      .withUsername('test')
      .withPassword('test')
      .start();

    const databaseUrl = container.getConnectionUri();

    console.log(`✅ PostgreSQL container started`);

    process.env.DATABASE_URL = databaseUrl;
    process.env.DIRECT_DATABASE_URL = databaseUrl;

    console.log('🔄 Running migrations...');
    
    execSync('npx prisma migrate deploy', {
      stdio: 'inherit',
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        DIRECT_DATABASE_URL: databaseUrl,
      },
    });

    console.log('✅ Migrations completed');

    writeFileSync(
      path.resolve('.test-database-url'),
      databaseUrl,
      'utf8',
    );
    
    (global as any).__TEST_CONTAINER__ = container;
    
    console.log('✅ Setup complete!');
  } catch (error) {
    console.error('❌ Setup failed:', error);
    throw error;
  }
}

