
Event	Recipient	Title	Body
Appointment booked	Doctor	"New Appointment"	"Patient X booked for July 5 at 10:00"
Appointment confirmed	Patient	"Appointment Confirmed"	"Your appointment with Dr. X is confirmed"
Appointment reminder	Patient	"Reminder"	"You have an appointment tomorrow at 10:00"
Appointment cancelled	Patient/Doctor	"Cancelled"	"Appointment on July 5 has been cancelled"
New chat message	User/Doctor/Clinic	"New Message"	"Support: Hello, how can I help?"
Payment received	User	"Payment Confirmed"	"5 credits added to your wallet"
Credit refunded	User	"Refund"	"1 credit refunded to your wallet"
Account verified	Doctor/Clinic	"Verified!"	"Your account has been verified"
Account suspended	User/Doctor/Clinic	"Account Suspended"	"Reason: ..."
