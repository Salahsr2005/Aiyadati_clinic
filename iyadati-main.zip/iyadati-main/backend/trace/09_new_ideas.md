First, why does this work?

You asked an excellent question:

Why do we have

import './email/email.worker';

if we never use it?

This is actually a very common Node.js pattern called a side-effect import.

Normally, we import something because we want to use it:

import { sendEmail } from './email';

sendEmail(...);

But here we're importing the file because executing it is important.

When Node executes:

import './email/email.worker';

it loads the file.

At the bottom of the file, we have:

export const emailWorker = new EmailWorkerService();

So merely loading the file executes:

new EmailWorkerService();

which runs the constructor:

constructor() {
    this.worker = new Worker(...);

    this.registerEvents();
}

which tells BullMQ:

"Start listening to the email queue."

So the flow is:

app.ts

↓

import './infrastructure/queues/workers'

↓

workers.ts

↓

import './email/email.worker'

↓

new EmailWorkerService()

↓

new Worker()

↓

BullMQ starts listening

That's why we don't explicitly call anything.

It's the same idea as Express

When you write:

import express from 'express';

const app = express();

you create the Express application.

BullMQ is similar.

Creating the Worker is enough.

It immediately starts polling Redis for jobs.

Now let's verify the complete architecture
                 Register User
                       │
                       ▼
             eventEmitter.emit()
                       │


