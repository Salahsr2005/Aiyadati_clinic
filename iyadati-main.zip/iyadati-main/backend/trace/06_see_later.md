There is one thing I would eventually change

Not because it's wrong.

Because of performance.

For example

findByPatientId(...)

does

Promise.all([
    prisma.appointment.findMany(...),
    prisma.appointment.count(...)
])

This is good.

But later

include:{
    slot:true,
    doctor:true,
    clinic:true,
    contactUser:true
}

For an appointment list, that's potentially a lot of data.

If your mobile app only needs

doctor name
photo
date
status

I'd switch to

select:{
    id:true,
    status:true,
    doctor:{
        select:{
            firstNameFr:true,
            lastNameFr:true,
            photoPath:true
        }
    }
}

instead of loading entire records.

That reduces:

network traffic
PostgreSQL work
Prisma object creation
Node memory

It's a performance optimization, not a PgBouncer concern.



Yes — for reviewing the architecture you’ve shown, I have enough to start.

I can already see the main structure:

core/events/event-emitter.ts → in-process event bus
core/events/listeners/* → event consumers
register-listeners.ts → listener registration
infrastructure/queues/* → BullMQ/background processing
app.ts → application bootstrap and listener registration
Middleware → auth, authorization, errors, rate limiting, request IDs, uploads
Utilities → Prisma, logging, email, signed URLs, responses, timezone

However, there is one important issue I can already identify:

You currently have two listeners for the same event

You have:

// email.listener.ts
eventEmitter.on('send-otp-email', async (...) => {
    await sendEmail(...);
});

and:

// otp-email.listener.ts
eventEmitter.on('send-otp-email', async (...) => {
    await emailQueue.enqueueOtp(event);
});

And registerAllListeners() only explicitly registers:

registerAuditListener();
registerOtpEmailListener();
registerNotificationListener();

So the old email.listener.ts isn't currently registered, which means you're effectively using the queue-based version. That's good, but the old listener should probably be deleted to avoid confusion.

If your goal is to review/refactor the event-driven architecture

Then I would not ask for more files yet. We can start from what you've provided and systematically evaluate:

EventEmitter architecture
Event vs queue responsibilities
BullMQ integration
Listener registration
Error handling
Fire-and-forget behavior
Event reliability
Duplicate event processing
Graceful shutdown
Production/Docker behavior
Scaling to multiple Node.js instances
Whether RabbitMQ is actually necessary
What should remain synchronous vs asynchronous
How to structure events cleanly as the project grows

And there are already a few architectural concerns worth discussing, particularly the distinction between:

HTTP request
    ↓
Service
    ↓
EventEmitter
    ↓
Listener
    ↓
BullMQ
    ↓
Worker

versus:

HTTP request
    ↓
Service
    ↓
BullMQ
    ↓
Worker

Those are not equivalent, especially once you deploy multiple backend instances.

So yes: we can start now without more files. If you want a serious architecture review, I can go through this code file by file and explain what is good, what is redundant, what is dangerous in production, and what I would change for Iyadati.


One thing I'd improve

We don't really want our test output polluted by production logging. Later, we'll mock the logger in tests where appropriate.

For now, though: the test is valid.



One thing I want you to notice

There is a potentially important design issue in createTransfer():

const senderWallet = await tx.userWallet.update({
  where: { id: senderWalletId },
  data: { credits: { decrement: amount } },
});

if (senderWallet.credits < 0) {
  throw new Error('INSUFFICIENT_CREDITS');
}

This does protect the database transaction because throwing inside $transaction causes the transaction to roll back.

But it temporarily performs the decrement before discovering that the balance is insufficient. That's acceptable inside a transaction, but later we may want to consider a database-level conditional update such as "decrement only if credits >= amount" for stronger concurrency semantics.




Option A — proper architecture ⭐

Create worker.ts:

import './infrastructure/queues/workers';

Add:

{
  "scripts": {
    "dev": "tsx watch src/server.ts",
    "worker": "tsx watch src/worker.ts"
  }
}

Then Docker runs both separately.

Option B — minimal change for now

Keep this in server.ts:

import './infrastructure/queues/workers';

but make the workers disabled when NODE_ENV === 'test'.

For example:

if (process.env.NODE_ENV !== 'test') {
  await import('./infrastructure/queues/workers');
}

However, I prefer Option A for Iyadati because you're already building a production-oriented architecture with BullMQ, Redis, and separate queues.


