npm install -D \
jest \
ts-jest \
@types/jest \
tsx \
cross-env



Why each package?
Package	Purpose
jest	The test runner.
ts-jest	Lets Jest understand TypeScript.
@types/jest	TypeScript types for describe, it, expect, etc.
tsx	Useful for running TypeScript scripts directly (we'll likely use it later for setup/seed scripts).
cross-env	Makes environment variables work consistently across Linux, macOS, and Windows. Essential for CI/CD.

I intentionally did not install
supertest
because that's for integration/E2E tests.
We'll install it later when we actually test Express routes.

Likewise, we're not installing:
jest-extended
faker
testcontainers
Those are valuable, but they should be added when we have a concrete need rather than from day one.



npm ls jest
npm ls ts-jest // to confirm


mkdir -p tests/{unit,integration,e2e,builders,fixtures,helpers,mocks,setup}



This is where many tutorials go wrong.

They immediately create

jest.config.ts

and stuff everything inside it.

I'd rather design it like this:

jest.config.ts              <-- root

jest.unit.config.ts

jest.integration.config.ts

jest.e2e.config.ts

The root config only coordinates the projects.

Each project owns its own configuration.

This scales much better.





backend/jest.unit.config.ts

We'll build it piece by piece.

Start with this:

import type { Config } from "jest";

const config: Config = {
  displayName: "unit",

  preset: "ts-jest",

  testEnvironment: "node",

  rootDir: ".",

  testMatch: [
    "<rootDir>/tests/unit/**/*.test.ts",
  ],

  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
  },

  globals: {
    "ts-jest": {
      tsconfig: "<rootDir>/tsconfig.test.json",
    },
  },
};

export default config;
Let's review every property
displayName
displayName: "unit"

This labels the project.

Later, when you run all test suites, you'll see output like:

PASS unit
PASS integration
PASS e2e

instead of one long mixed list.

preset
preset: "ts-jest"

This tells Jest:

"You're going to execute TypeScript files."

Without it, Jest only understands JavaScript.

testEnvironment
testEnvironment: "node"

This is very important.

You're writing:

Express
Prisma
Redis
BullMQ

Not React.

So the runtime should be Node.js.

Many beginners accidentally use the browser environment (jsdom) because tutorials target frontend projects.

rootDir
rootDir: "."

This tells Jest that the project root is:

backend/

Now all <rootDir> references are relative to your backend folder.

testMatch
testMatch: [
  "<rootDir>/tests/unit/**/*.test.ts",
]

Only files matching that pattern are considered unit tests.

That means:

tests/unit/auth/auth.service.test.ts

✅ Runs.

But:

tests/integration/auth.test.ts

❌ Doesn't run in the unit suite.

This keeps the boundaries between test types clear.

moduleNameMapper

Your code imports like this:

import { AuthService } from "@/modules/auth/auth.service";

TypeScript understands @/.

Jest doesn't.

This line teaches Jest how to resolve that alias.

globals
globals: {
  "ts-jest": {
    tsconfig: "<rootDir>/tsconfig.test.json",
  },
}

This tells ts-jest which TypeScript configuration to use.

One improvement

Since Jest 29+, the globals.ts-jest configuration is considered legacy. I prefer using the newer transform syntax from the start:

transform: {
  "^.+\\.tsx?$": [
    "ts-jest",
    {
      tsconfig: "<rootDir>/tsconfig.test.json",
    },
  ],
},

