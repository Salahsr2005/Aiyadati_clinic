Iyadati Backend - Project Context
Tech Stack
Runtime: Node.js with TypeScript

Framework: Express.js

Database: PostgreSQL with Prisma ORM

Auth: JWT (HTTP-only cookies + Bearer tokens)

Validation: Joi

Logging: Winston

Email: Nodemailer (Gmail SMTP for dev)

File Upload: Multer with signed URLs

Docs: Swagger (swagger-jsdoc + swagger-ui-express)

Rate Limiting: express-rate-limit (dev: 100x multiplier)

Security: Helmet, CORS, Compression, cookie-parser

Project Structure
text
src/
├── app.ts                    # Express app, middleware, route registration
├── server.ts                 # Entry point
├── config/
│   ├── env.ts               # All env vars, isDevelopment/isProduction helpers
│   ├── swagger.ts           # OpenAPI spec definition
│   ├── swagger-ui.ts        # Swagger UI options
│   ├── swagger-theme.ts     # Custom CSS (sidebar, purple theme, dark mode)
│   └── swagger-custom-js.ts # Sidebar navigation + export buttons JS
├── core/
│   ├── events/
│   │   ├── event-emitter.ts          # Singleton EventEmitter
│   │   ├── register-listeners.ts     # Register all listeners on startup
│   │   └── listeners/
│   │       ├── audit.listener.ts     # Audit logging (writes to DB)
│   │       └── otp-email.listener.ts # OTP email sending
│   ├── middleware/
│   │   ├── auth.middleware.ts        # JWT verify (cookie then Bearer header)
│   │   ├── authorize.middleware.ts   # Role check (SUPER_ADMIN, ADMIN, USER, CLINIC)
│   │   ├── errorHandler.middleware.ts # Global error handler (logs only in dev)
│   │   ├── rateLimit.middleware.ts   # createRateLimiter({ windowMinutes, maxRequests })
│   │   └── upload.middleware.ts      # Multer configs: uploadLogo, uploadDocument, uploadMultipleDocuments
│   ├── types/
│   │   ├── response.types.ts
│   │   └── express.d.ts
│   └── utils/
│       ├── error.ts          # AppError + subclasses (NotFoundError, ConflictError, etc.)
│       ├── logger.ts         # Winston (debug in dev, info in prod)
│       ├── prisma.ts         # Prisma client singleton
│       ├── response.ts       # ResponseUtil (success, created, paginated, error, etc.)
│       ├── email.ts          # sendEmail() using nodemailer with Gmail
│       └── signed-url.ts     # generateSignedUrl(), verifySignedUrl(), getFilePath()
├── repositories/              # Data access layer (Prisma queries only)
│   ├── super-admin.repository.ts
│   ├── admin.repository.ts
│   ├── user.repository.ts
│   ├── clinic.repository.ts
│   ├── clinic-document.repository.ts
│   └── wilaya.repository.ts
└── modules/
    ├── health/
    ├── auth/
    ├── admin/
    ├── user/
    ├── clinic/
    ├── location/
    └── file/
Key Conventions
No any types
All repositories, services, controllers use proper typing. Use Prisma.ClinicCreateInput etc. from @prisma/client.

Module Structure (double versioning)
text
modules/[name]/
├── [name].module.ts         # Router setup: router.use('/v1', routes)
└── v1/
    ├── [name].controller.ts # Class-based, methods = async (req, res, next)
    ├── [name].service.ts    # Business logic, calls repositories
    ├── [name].routes.ts     # Route definitions with middleware chain
    ├── [name].validation.ts # Joi schemas + middleware functions
    ├── [name].types.ts      # DTOs and response interfaces
    └── [name].swagger.ts    # JSDoc swagger documentation
URL pattern: /api/v1/[module]/v1/[endpoint]

Controllers
Class-based (your preference)

Methods use bind or arrow functions

Call ResponseUtil methods for responses

Call next(error) for errors

Get user from req.user!.id, IP from req.ip

Services
Business logic only

Call repositories for data

Throw AppError subclasses

Emit events for audit logging: eventEmitter.emit('audit', {...})

Emit events for emails: eventEmitter.emit('send-otp-email', {...})

Repositories
Prisma queries only, no business logic

Export singleton instance

Named exports: export const clinicRepository = new ClinicRepository()

Response Format
typescript
// Success
ResponseUtil.success(res, data, 'Message');
ResponseUtil.created(res, data, 'Message');
ResponseUtil.paginated(res, items, total, page, limit, 'Message');

// Errors
ResponseUtil.badRequest(res, 'Message', errors);
ResponseUtil.unauthorized(res, 'Message');
ResponseUtil.forbidden(res, 'Message');
ResponseUtil.notFound(res, 'Message');
ResponseUtil.conflict(res, 'Message', errors);
ResponseUtil.validationError(res, 'Message', errors);
ResponseUtil.tooManyRequests(res, 'Message');
Error Classes
typescript
throw new NotFoundError('Resource');
throw new ConflictError('Message', [{ field, message }]);
throw new BadRequestError('Message');
throw new UnauthorizedError('Message');
throw new ForbiddenError('Message');
throw new DatabaseError('Message');
throw new ValidationError('Message', details);
throw new RateLimitError('Message');
Rate Limiting
typescript
// In routes:
router.post('/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many' }),
  controller.login
);
// Dev: limit × 100, Prod: exact limit
Auth Middleware Chain
typescript
// No auth
router.get('/public', controller.method);

// Any authenticated user
router.get('/profile', authenticate, controller.method);

// Specific roles
router.get('/admin', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.method);
router.get('/clinic', authenticate, authorize('CLINIC'), controller.method);
Roles
SUPER_ADMIN | ADMIN | USER | CLINIC

Audit Events
Emitted in services for important actions:

typescript
eventEmitter.emit('audit', {
  action: 'clinic.verified',
  entity: 'Clinic',
  entityId: id,
  performedBy: userId,
  details: { ... },
  ip: requestIp,
});
File Upload
Logo: uploadLogo middleware → field name logo, max 2MB, images only

Document: uploadDocument middleware → field name document, max 20MB, PDF/images

Files stored in uploads/ directory

Access via signed URLs (30 min expiry): generateSignedUrl(filePath)

File access route: GET /api/v1/files/:fileName?expires=...&signature=...

Environment
typescript
import { env } from '../config/env';
env.isDevelopment  // boolean
env.isProduction   // boolean
env.PORT           // number
env.BASE_URL       // http://localhost:3975 or https://...
env.MAILTRAP_USER  // Gmail email
env.MAILTRAP_PASS  // Gmail app password
Logging
typescript
import { logger } from '../core/utils/logger';
logger.debug('Dev only');
logger.info('Always');
logger.warn('Warning');
logger.error('Error', { details });
Current Models (Prisma)
SuperAdmin: id, email, password, name, role

Admin: id, email, password, name, role, adminRole, createdBy

User: id, email, password, firstName, lastName, phone, dateOfBirth, wilayaId, isVerified, verificationCode, otpExpiresAt, isSuspended, suspensionReason

Clinic: id, nameFr, nameAr, password, descriptionAr, descriptionFr, wilayaId, baladyaId, latitude, longitude, phone, email, logoPath, isVerified, isSuspended, isCompleted

ClinicDocument: id, clinicId, fileName, filePath, fileType, fileSize, uploadedBy

Wilaya: id, code, nameFr, nameAr (mapped to name_fr, name_ar)

Baladya: id, nameFr, nameAr, wilayaId (mapped to name_fr, name_ar, wilaya_id)

AuditLog: id, action, entity, entityId, performedBy, details (JSON), ip

HealthCheck: id, status, checkedAt

Swagger
UI at /api/docs

JSON at /api/docs.json

Custom sidebar with module navigation, search, export buttons

Purple theme (#6B21A8)

Dark/light mode

Cookie auth + Bearer auth schemes






Iyadati Backend - Project Context
Tech Stack
Runtime: Node.js with TypeScript

Framework: Express.js

Database: PostgreSQL with Prisma ORM

Auth: JWT (HTTP-only cookies + Bearer tokens)

Validation: Joi

Logging: Winston

Email: Nodemailer (Gmail SMTP for dev)

File Upload: Multer with signed URLs

Docs: Swagger (swagger-jsdoc + swagger-ui-express)

Rate Limiting: express-rate-limit (dev: 100x multiplier)

Security: Helmet, CORS, Compression, cookie-parser

Project Structure
text
src/
├── app.ts                    # Express app, middleware, route registration
├── server.ts                 # Entry point
├── config/
│   ├── env.ts               # All env vars, isDevelopment/isProduction helpers
│   ├── swagger.ts           # OpenAPI spec definition
│   ├── swagger-ui.ts        # Swagger UI options
│   ├── swagger-theme.ts     # Custom CSS (sidebar, purple theme, dark mode)
│   └── swagger-custom-js.ts # Sidebar navigation + export buttons JS
├── core/
│   ├── events/
│   │   ├── event-emitter.ts          # Singleton EventEmitter
│   │   ├── register-listeners.ts     # Register all listeners on startup
│   │   └── listeners/
│   │       ├── audit.listener.ts     # Audit logging (writes to DB)
│   │       └── otp-email.listener.ts # OTP email sending
│   ├── middleware/
│   │   ├── auth.middleware.ts        # JWT verify (cookie then Bearer header)
│   │   ├── authorize.middleware.ts   # Role check (SUPER_ADMIN, ADMIN, USER, CLINIC)
│   │   ├── errorHandler.middleware.ts # Global error handler (logs only in dev)
│   │   ├── rateLimit.middleware.ts   # createRateLimiter({ windowMinutes, maxRequests })
│   │   └── upload.middleware.ts      # Multer configs: uploadLogo, uploadDocument, uploadMultipleDocuments
│   ├── types/
│   │   ├── response.types.ts
│   │   └── express.d.ts
│   └── utils/
│       ├── error.ts          # AppError + subclasses (NotFoundError, ConflictError, etc.)
│       ├── logger.ts         # Winston (debug in dev, info in prod)
│       ├── prisma.ts         # Prisma client singleton
│       ├── response.ts       # ResponseUtil (success, created, paginated, error, etc.)
│       ├── email.ts          # sendEmail() using nodemailer with Gmail
│       └── signed-url.ts     # generateSignedUrl(), verifySignedUrl(), getFilePath()
├── repositories/              # Data access layer (Prisma queries only)
│   ├── super-admin.repository.ts
│   ├── admin.repository.ts
│   ├── user.repository.ts
│   ├── clinic.repository.ts
│   ├── clinic-document.repository.ts
│   └── wilaya.repository.ts
└── modules/
    ├── health/
    ├── auth/
    ├── admin/
    ├── user/
    ├── clinic/
    ├── location/
    └── file/
Key Conventions
No any types
All repositories, services, controllers use proper typing. Use Prisma.ClinicCreateInput etc. from @prisma/client.

Module Structure (double versioning)
text
modules/[name]/
├── [name].module.ts         # Router setup: router.use('/v1', routes)
└── v1/
    ├── [name].controller.ts # Class-based, methods = async (req, res, next)
    ├── [name].service.ts    # Business logic, calls repositories
    ├── [name].routes.ts     # Route definitions with middleware chain
    ├── [name].validation.ts # Joi schemas + middleware functions
    ├── [name].types.ts      # DTOs and response interfaces
    └── [name].swagger.ts    # JSDoc swagger documentation
URL pattern: /api/v1/[module]/v1/[endpoint]

Controllers
Class-based (your preference)

Methods use bind or arrow functions

Call ResponseUtil methods for responses

Call next(error) for errors

Get user from req.user!.id, IP from req.ip

Services
Business logic only

Call repositories for data

Throw AppError subclasses

Emit events for audit logging: eventEmitter.emit('audit', {...})

Emit events for emails: eventEmitter.emit('send-otp-email', {...})

Repositories
Prisma queries only, no business logic

Export singleton instance

Named exports: export const clinicRepository = new ClinicRepository()

Response Format
typescript
// Success
ResponseUtil.success(res, data, 'Message');
ResponseUtil.created(res, data, 'Message');
ResponseUtil.paginated(res, items, total, page, limit, 'Message');

// Errors
ResponseUtil.badRequest(res, 'Message', errors);
ResponseUtil.unauthorized(res, 'Message');
ResponseUtil.forbidden(res, 'Message');
ResponseUtil.notFound(res, 'Message');
ResponseUtil.conflict(res, 'Message', errors);
ResponseUtil.validationError(res, 'Message', errors);
ResponseUtil.tooManyRequests(res, 'Message');
Error Classes
typescript
throw new NotFoundError('Resource');
throw new ConflictError('Message', [{ field, message }]);
throw new BadRequestError('Message');
throw new UnauthorizedError('Message');
throw new ForbiddenError('Message');
throw new DatabaseError('Message');
throw new ValidationError('Message', details);
throw new RateLimitError('Message');
Rate Limiting
typescript
// In routes:
router.post('/login',
  createRateLimiter({ windowMinutes: 15, maxRequests: 10, message: 'Too many' }),
  controller.login
);
// Dev: limit × 100, Prod: exact limit
Auth Middleware Chain
typescript
// No auth
router.get('/public', controller.method);

// Any authenticated user
router.get('/profile', authenticate, controller.method);

// Specific roles
router.get('/admin', authenticate, authorize('SUPER_ADMIN', 'ADMIN'), controller.method);
router.get('/clinic', authenticate, authorize('CLINIC'), controller.method);
Roles
SUPER_ADMIN | ADMIN | USER | CLINIC

Audit Events
Emitted in services for important actions:

typescript
eventEmitter.emit('audit', {
  action: 'clinic.verified',
  entity: 'Clinic',
  entityId: id,
  performedBy: userId,
  details: { ... },
  ip: requestIp,
});
File Upload
Logo: uploadLogo middleware → field name logo, max 2MB, images only

Document: uploadDocument middleware → field name document, max 20MB, PDF/images

Files stored in uploads/ directory

Access via signed URLs (30 min expiry): generateSignedUrl(filePath)

File access route: GET /api/v1/files/:fileName?expires=...&signature=...

Environment
typescript
import { env } from '../config/env';
env.isDevelopment  // boolean
env.isProduction   // boolean
env.PORT           // number
env.BASE_URL       // http://localhost:3975 or https://...
env.MAILTRAP_USER  // Gmail email
env.MAILTRAP_PASS  // Gmail app password
Logging
typescript
import { logger } from '../core/utils/logger';
logger.debug('Dev only');
logger.info('Always');
logger.warn('Warning');
logger.error('Error', { details });
Current Models (Prisma)
SuperAdmin: id, email, password, name, role

Admin: id, email, password, name, role, adminRole, createdBy

User: id, email, password, firstName, lastName, phone, dateOfBirth, wilayaId, isVerified, verificationCode, otpExpiresAt, isSuspended, suspensionReason

Clinic: id, nameFr, nameAr, password, descriptionAr, descriptionFr, wilayaId, baladyaId, latitude, longitude, phone, email, logoPath, isVerified, isSuspended, isCompleted

ClinicDocument: id, clinicId, fileName, filePath, fileType, fileSize, uploadedBy

Wilaya: id, code, nameFr, nameAr (mapped to name_fr, name_ar)

Baladya: id, nameFr, nameAr, wilayaId (mapped to name_fr, name_ar, wilaya_id)

AuditLog: id, action, entity, entityId, performedBy, details (JSON), ip

HealthCheck: id, status, checkedAt

Swagger
UI at /api/docs

JSON at /api/docs.json

Custom sidebar with module navigation, search, export buttons

Purple theme (#6B21A8)

Dark/light mode

Cookie auth + Bearer auth schemes



ok look now we have
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// **************************************************** Health

model HealthCheck {
  id        Int      @id @default(autoincrement())
  status    String
  checkedAt DateTime @default(now())
}


// **************************************************** Enums

enum Role {
  SUPER_ADMIN
  ADMIN
}


// **************************************************** Schemas

model SuperAdmin {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String
  name      String
  role      Role     @default(SUPER_ADMIN)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Admin {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String
  name      String
  role      Role     @default(ADMIN)
  adminRole String?
  createdBy String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}


model User {
  id               String    @id @default(uuid())
  email            String    @unique
  password         String
  firstName        String
  lastName         String
  phone            String    @unique
  dateOfBirth      DateTime
  wilayaId         String
  wilaya           Wilaya    @relation(fields: [wilayaId], references: [id])
  isVerified       Boolean   @default(false)
  verificationCode String?   // Hashed OTP
  otpExpiresAt     DateTime? // OTP expiry
  isSuspended      Boolean   @default(false)
  suspensionReason String?
  createdAt        DateTime  @default(now())
  updatedAt        DateTime  @updatedAt
}


model Clinic {
  id            String    @id @default(uuid())
  nameFr        String
  nameAr        String
  password      String
  descriptionAr String?
  descriptionFr String?
  wilayaId      String
  wilaya        Wilaya    @relation(fields: [wilayaId], references: [id])
  baladyaId     String?
  baladya       Baladya?  @relation(fields: [baladyaId], references: [id])
  latitude      Float?
  longitude     Float?
  phone         String    @unique
  email         String    @unique
  logoPath      String?   
  isVerified    Boolean   @default(false)
  isSuspended   Boolean   @default(false)
  isCompleted   Boolean   @default(false)
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  documents     ClinicDocument[]
}

model ClinicDocument {
  id        String   @id @default(uuid())
  clinicId  String
  clinic    Clinic   @relation(fields: [clinicId], references: [id], onDelete: Cascade)
  fileName  String   // Original file name
  filePath  String   // Path on disk
  fileType  String   // mime type
  fileSize  Int      // bytes
  uploadedBy String? // Admin/SuperAdmin ID who uploaded
  createdAt DateTime @default(now())
}



// **************************************************** Location
model Wilaya {
  id       String    @id @default(uuid())
  code     Int       @unique
  nameFr   String    @map("name_fr")
  nameAr   String    @map("name_ar")
  baladyat Baladya[]
  users    User[]
  clinics  Clinic[]
  
  @@unique([nameFr])
  @@unique([nameAr])
  @@map("wilayas")
}

model Baladya {
  id       String @id @default(uuid())
  nameFr   String @map("name_fr")
  nameAr   String @map("name_ar")
  wilayaId String @map("wilaya_id")
  wilaya   Wilaya @relation(fields: [wilayaId], references: [id], onDelete: Cascade)
  clinics  Clinic[]

  @@unique([nameFr, wilayaId])
  @@unique([nameAr, wilayaId])
  @@map("baladyat")
}



// **************************************************** Audit logs

model AuditLog {
  id        String   @id @default(uuid())
  action    String   // 'admin.created', 'admin.deleted', 'admin.updated', etc.
  entity    String   // 'Admin', 'SuperAdmin', etc.
  entityId  String   // ID of the affected record
  performedBy String // User ID who did the action
  details   Json?    // Extra data about what changed
  ip        String?  // Request IP
  createdAt DateTime @default(now())
}


but I wanna add for the clinic itself roles
the clinic itself which get the token when it login with it's password and email no problem
doctors which may be a lot in the clinic
receptionist which may be a lot in the clinic

now what will we do is two schemas one for receptionist one for doctor and both are linked to their only clinic
