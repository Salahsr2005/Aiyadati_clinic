npm init -y && npm install express dotenv cors body-parser && npm install prisma@6.5.0 @prisma/client@6.5.0 && npm install -D nodemon eslint prettier && npm install -D typescript ts-node @types/node @types/express @types/cors && npx tsc --init

npx prisma init
npx prisma generate

npx tsc --init

npx prisma init

npm uninstall express body-parser cors dotenv @types/node @types/express @types/cors typescript

npm install express@4.21.2 body-parser@1.20.2 cors@2.8.5 dotenv@16.4.5

npm install -D typescript@5.7.3 @types/node@20.17.24 @types/express@4.17.21 @types/cors@2.8.17

npm install prisma@6.5.0 @prisma/client@6.5.0



###
 ~  sudo -u postgres psql                                                   ok 

[sudo] password for jalil:     
psql (16.11 (Ubuntu 16.11-0ubuntu0.24.04.1))
Type "help" for help.

postgres=# CREATE DATABASE iyadati_db;
CREATE DATABASE
postgres=# CREATE USER iyadati_user WITH ENCRYPTED PASSWORD 'your_password';
CREATE ROLE
postgres=# GRANT ALL PRIVILEGES ON DATABASE iyadati_db TO iyadati_user;
GRANT
postgres=# \q

 ~  sudo -u postgres psql                                             ok | 26s 
psql (16.11 (Ubuntu 16.11-0ubuntu0.24.04.1))
Type "help" for help.

postgres=# ALTER USER iyadati_user CREATEDB;
ALTER ROLE
postgres=# \du iyadati_user
       List of roles
  Role name   | Attributes 
--------------+------------
 iyadati_user | Create DB

postgres=# \q

 ~  sudo -u postgres psql -d iyadati_db                               ok | 18s 
psql (16.11 (Ubuntu 16.11-0ubuntu0.24.04.1))
Type "help" for help.

iyadati_db=# GRANT ALL ON SCHEMA public TO iyadati_user;
GRANT
iyadati_db=# ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO iyadati_user;
ALTER DEFAULT PRIVILEGES
iyadati_db=# ALTER SCHEMA public OWNER TO iyadati_user;
ALTER SCHEMA
iyadati_db=# \q

###


npm install helmet compression express-rate-limit uuid

npm install winston winston-daily-rotate-file

npm install -D @types/compression @types/uuid

npm install bcryptjs jsonwebtoken joi
npm install -D @types/bcryptjs @types/jsonwebtoken

npm install swagger-jsdoc swagger-ui-express
npm install -D @types/swagger-jsdoc @types/swagger-ui-express