Chargebacks/reversals — If someone buys credits with a card, transfers them, then disputes the charge, who loses? The receiver or the platform?

