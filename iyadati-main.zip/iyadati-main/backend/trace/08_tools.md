Bull Board

Install it:

npm install @bull-board/api @bull-board/express

Later, we'll expose something like:

http://localhost:3975/admin/queues

You'll see:

🟢 Waiting jobs
🔵 Active jobs
✅ Completed jobs
❌ Failed jobs
⏰ Delayed jobs
🔄 Retries

It's one of the first things senior teams add because it's invaluable for debugging.





Tool	Purpose	Production?
Bull Board	Inspect queues, retry failed jobs, see waiting/active/completed jobs	✅ Yes
Prometheus	Collect metrics	✅ Yes
Grafana	Dashboards and alerts	✅ Yes
Loki	Log aggregation	✅ Yes
Sentry	Error tracking	✅ Yes
OpenTelemetry + Jaeger	Distributed tracing	✅ Yes

http://localhost:3974/admin/queues

