import { PrismaClient } from '@prisma/client';

const globalForPrisma = global as typeof globalThis & {
    prisma?: PrismaClient;
};

export const prisma =
    globalForPrisma.prisma ??
    new PrismaClient();

if (process.env.NODE_ENV !== 'production') {
    globalForPrisma.prisma = prisma;
}

////////////////////////////////////////////////////////////////////////


process.on('SIGTERM', async () => {
    logger.info('SIGTERM received');

    server.close(async () => {
        await prisma.$disconnect();

        logger.info('Server closed');

        process.exit(0);
    });
});


/////////////////////////////////////////////////
{
Minor Improvements 🟡
Clinic.logoPath - Should we add fileId/storageKey here too? Or keep as-is since it's a direct reference?

prisma
// Option: Keep as-is or enhance
model Clinic {
  // ... existing fields ...
  logoPath    String?   // Keep simple, just store the path
  // OR enhance:
  logoFileId  String?   @map("logo_file_id")  // Reference to file registry
}
Doctor.photoPath - Same consideration

prisma
model Doctor {
  // ... existing fields ...
  photoPath   String?   // Keep simple
  // OR:
  photoFileId String?   @map("photo_file_id")
}
Specialty.imagePath - Same consideration

I'd suggest keeping them as simple paths for now, then later migrating to fileId references if needed.
// Add to UserDocument
@@index([userId])
@@index([storageType])
@@index([category])
@@index([docType])
@@index([fileId]) // For faster lookups

// Add to DoctorDocument  
@@index([doctorId])
@@index([storageType])
@@index([category])
@@index([docType])
@@index([fileId])

// Add to ClinicDocument
@@index([clinicId])
@@index([storageType])
@@index([category])
@@index([docType])
@@index([fileId])

// Add to ClinicGallery
@@index([clinicId])
@@index([fileId])

// Add to ClinicServiceImage
@@index([serviceId])
@@index([fileId])

// Add to FileRegistry
@@index([fileId])
@@index([storageKey])
@@index([ownerId, ownerType])
@@index([storageType])
@@index([category])

Duplicate Constraint Names: You removed the map from @@unique but kept it on @unique. This is actually fine since Prisma handles it differently. The @unique on individual fields creates unique constraints, and @@unique on combinations creates composite unique constraints. They don't conflict.

FileRegistry is Optional: Since you have individual document tables, FileRegistry can be populated later via a trigger or migration script.
}


Best Practice for Production
In production, you should:

Run your Node.js app as a specific user (not root)

Ensure that user has write permissions to the uploads directory

Use proper permission settings:

Directories: 755 (rwx r-x r-x)

Files: 644 (rw- r-- r--)

Try Solution 2 first as it will give you full control over the uploads directory.


Later, when you move closer to production, I'd add:

redis:
  image: redis:7-alpine

  command: >
    redis-server
    --appendonly yes

That enables AOF persistence, so queued jobs survive Redis restarts much more reliably.

For learning and development, your current configuration is perfectly fine.


Step 3: Environment variables

If you don't already have them, add:

REDIS_HOST=redis
REDIS_PORT=6379

Notice it's redis, not localhost.

Why?

Your API runs inside Docker.

API Container
      │
      ▼
redis:6379

Docker's internal DNS resolves the service name redis automatically.

If you used localhost, the API container would try to connect to itself instead of the Redis container.


One thing we're intentionally not adding

You may see tutorials with:

retryStrategy(times) {
    ...
}

I'm intentionally leaving that out.

ioredis already has a sensible retry strategy, and unless you have specific operational requirements (backoff tuning, maximum retry duration, etc.), the default behavior is perfectly acceptable. We can revisit it if your deployment environment demands it.



in send email
One thing I would improve later (not now)

Instead of

service: 'gmail',

I'd make it configurable because one day you may use:

Gmail
Mailtrap
SendGrid
Amazon SES
Resend

without changing code.















4. Your scripts need improvement

Right now you have

"scripts": {
    "build:dev": "...",
    ...
}

I'd eventually transform them into something like

"scripts": {
  "dev": "...",

  "build:dev": "...",
  "build:prod": "...",

  "test": "jest",

  "test:unit": "jest --selectProjects unit",

  "test:integration": "jest --selectProjects integration",

  "test:e2e": "jest --selectProjects e2e",

  "test:watch": "jest --watch",

  "test:coverage": "jest --coverage"
}

Notice something.

We don't have

jest tests/unit

We use Jest Projects, because that's how large codebases stay organized.