for generate
npx prisma generate
for migration
npx prisma migrate dev --name init
npx prisma studio
npm run prisma:seed
tree -I "node_modules|dist|.git|.next|coverage|logs|tmp|build|.cache|.idea|.vscode"
docker compose config
docker compose exec api npx prisma migrate dev --name changing_booking_workflow_to_confirming
docker logs -f  iyadati-api
docker compose exec api npx prisma migrate reset
docker compose down
docker exec -it iyadati-api npm run prisma:seed
docker exec -it iyadati-api sh
docker exec -it iyadati-api npx prisma studio but you have to     - "5555:5555" in compose 
docker compose down
docker compose up -d
docker exec -it iyadati-api npx prisma generate
docker exec -it iyadati-api npm run prisma:prepare
docker exec -it iyadati-api npm run prisma:seed
docker exec -it iyadati-api npm run prisma:seed:doctors

docker compose build --no-cache api
grep -R "OTP email sent to" src
docker exec -it iyadati-postgres psql -U iyadati_user -d iyadati_db -c "UPDATE specialties SET file_id = gen_random_uuid()::text WHERE file_id IS NULL;"


# Resolve the failed migration
docker compose run --rm api npx prisma migrate resolve --applied 20260804001344_fix_specialty_file_id_default

# Apply remaining migrations
docker compose run --rm api npx prisma migrate deploy

# Restart everything
docker compose up -d

# Check logs to verify it's running
docker compose logs -f api

git pull
docker compose down
docker compose build
docker compose up -d


git switch feature/refactoring-improvements
git push --set-upstream origin feature/refactoring-improvements
add_doctor_booking_availability

docker cp backend/prisma/data/doctors.csv iyadati-api:/app/prisma/data/doctors.csv

docker exec -it iyadati-api npm run prisma:seed
docker exec -it iyadati-api npm run prisma:seed:doctors
