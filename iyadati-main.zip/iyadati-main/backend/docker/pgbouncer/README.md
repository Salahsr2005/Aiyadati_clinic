pool_mode = transaction: this is exactly what Prisma recommends.
max_client_conn = 1000: PgBouncer can accept up to 1000 client connections.
default_pool_size = 50: only 50 actual PostgreSQL connections are kept open.
reserve_pool_size = 10: temporary extra connections during traffic spikes.
server_idle_timeout = 300: close unused PostgreSQL connections after 5 minutes.
idle_transaction_timeout = 60: kill transactions left open for over a minute.


I don't recommend leaving:

auth_type = scram-sha-256

yet.

Why?

The official PgBouncer image expects the authentication data to match the authentication method. For scram-sha-256, the userlist.txt typically needs the SCRAM secret, not just the plain password. A plain entry like:

"iyadati_user" "your_password"

often leads to authentication failures.

For a first integration, it's much simpler to use:

auth_type = md5

Once everything is working, we can switch to SCRAM properly by generating the correct SCRAM secret (or using PostgreSQL's auth_query approach).

