import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const wilayas = [
  { code: 1, nameFr: 'Adrar', nameAr: 'أدرار' },
  { code: 2, nameFr: 'Chlef', nameAr: 'الشلف' },
  { code: 3, nameFr: 'Laghouat', nameAr: 'الأغواط' },
  { code: 4, nameFr: 'Oum El Bouaghi', nameAr: 'أم البواقي' },
  { code: 5, nameFr: 'Batna', nameAr: 'باتنة' },
  { code: 6, nameFr: 'Béjaïa', nameAr: 'بجاية' },
  { code: 7, nameFr: 'Biskra', nameAr: 'بسكرة' },
  { code: 8, nameFr: 'Béchar', nameAr: 'بشار' },
  { code: 9, nameFr: 'Blida', nameAr: 'البليدة' },
  { code: 10, nameFr: 'Bouïra', nameAr: 'البويرة' },
  { code: 11, nameFr: 'Tamanrasset', nameAr: 'تمنراست' },
  { code: 12, nameFr: 'Tébessa', nameAr: 'تبسة' },
  { code: 13, nameFr: 'Tlemcen', nameAr: 'تلمسان' },
  { code: 14, nameFr: 'Tiaret', nameAr: 'تيارت' },
  { code: 15, nameFr: 'Tizi Ouzou', nameAr: 'تيزي وزو' },
  { code: 16, nameFr: 'Algiers', nameAr: 'الجزائر' },
  { code: 17, nameFr: 'Djelfa', nameAr: 'الجلفة' },
  { code: 18, nameFr: 'Jijel', nameAr: 'جيجل' },
  { code: 19, nameFr: 'Sétif', nameAr: 'سطيف' },
  { code: 20, nameFr: 'Saïda', nameAr: 'سعيدة' },
  { code: 21, nameFr: 'Skikda', nameAr: 'سكيكدة' },
  { code: 22, nameFr: 'Sidi Bel Abbès', nameAr: 'سيدي بلعباس' },
  { code: 23, nameFr: 'Annaba', nameAr: 'عنابة' },
  { code: 24, nameFr: 'Guelma', nameAr: 'قالمة' },
  { code: 25, nameFr: 'Constantine', nameAr: 'قسنطينة' },
  { code: 26, nameFr: 'Médéa', nameAr: 'المدية' },
  { code: 27, nameFr: 'Mostaganem', nameAr: 'مستغانم' },
  { code: 28, nameFr: "M'Sila", nameAr: 'المسيلة' },
  { code: 29, nameFr: 'Mascara', nameAr: 'معسكر' },
  { code: 30, nameFr: 'Ouargla', nameAr: 'ورقلة' },
  { code: 31, nameFr: 'Oran', nameAr: 'وهران' },
  { code: 32, nameFr: 'El Bayadh', nameAr: 'البيض' },
  { code: 33, nameFr: 'Illizi', nameAr: 'إليزي' },
  { code: 34, nameFr: 'Bordj Bou Arréridj', nameAr: 'برج بوعريريج' },
  { code: 35, nameFr: 'Boumerdès', nameAr: 'بومرداس' },
  { code: 36, nameFr: 'El Tarf', nameAr: 'الطارف' },
  { code: 37, nameFr: 'Tindouf', nameAr: 'تندوف' },
  { code: 38, nameFr: 'Tissemsilt', nameAr: 'تيسمسيلت' },
  { code: 39, nameFr: 'El Oued', nameAr: 'الوادي' },
  { code: 40, nameFr: 'Khenchela', nameAr: 'خنشلة' },
  { code: 41, nameFr: 'Souk Ahras', nameAr: 'سوق أهراس' },
  { code: 42, nameFr: 'Tipaza', nameAr: 'تيبازة' },
  { code: 43, nameFr: 'Mila', nameAr: 'ميلة' },
  { code: 44, nameFr: "Aïn Defla", nameAr: 'عين الدفلى' },
  { code: 45, nameFr: 'Naâma', nameAr: 'النعامة' },
  { code: 46, nameFr: "Aïn Témouchent", nameAr: 'عين تموشنت' },
  { code: 47, nameFr: 'Ghardaïa', nameAr: 'غرداية' },
  { code: 48, nameFr: 'Relizane', nameAr: 'غليزان' },
  { code: 49, nameFr: 'Timimoun', nameAr: 'تيميمون' },
  { code: 50, nameFr: 'Bordj Badji Mokhtar', nameAr: 'برج باجي مختار' },
  { code: 51, nameFr: 'Ouled Djellal', nameAr: 'أولاد جلال' },
  { code: 52, nameFr: 'Béni Abbès', nameAr: 'بني عباس' },
  { code: 53, nameFr: 'Ain Salah', nameAr: 'عين صالح' },
  { code: 54, nameFr: 'Ain Guezzam', nameAr: 'عين قزام' },
  { code: 55, nameFr: 'Touggourt', nameAr: 'تقرت' },
  { code: 56, nameFr: 'Djanet', nameAr: 'جانت' },
  { code: 57, nameFr: "El M'Ghair", nameAr: 'المغير' },
  { code: 58, nameFr: 'El Menia', nameAr: 'المنيعة' },
  { code: 59, nameFr: 'Aflou', nameAr: 'أفلو' },
];

// Optional: Add Baladya seed data if you have it
const baladyat = [
  // Example for Algiers (code 16)
  { nameFr: 'Sidi M\'hamed', nameAr: 'سيدي امحمد', wilayaCode: 16 },
  { nameFr: 'Bab El Oued', nameAr: 'باب الوادي', wilayaCode: 16 },
  { nameFr: 'Hussein Dey', nameAr: 'حسين داي', wilayaCode: 16 },
  // Add more baladyat as needed...
];

async function seedSuperAdmin() {
  const existingAdmin = await prisma.superAdmin.findUnique({
    where: { email: 'superadmin@gmail.com' },
  });

  if (existingAdmin) {
    console.log('Super admin already exists, skipping...');
    return;
  }

  const hashedPassword = await bcrypt.hash('kolnhbdasgjejoefskn', 12);

  await prisma.superAdmin.create({
    data: {
      email: 'superadmin@gmail.com',
      name: 'superadmin',
      password: hashedPassword,
      role: Role.SUPER_ADMIN,
    },
  });

  console.log('Super admin created: superadmin@gmail.com');
}

async function seedWilayas() {
  console.log('Seeding wilayas...');
  
  for (const w of wilayas) {
    await prisma.wilaya.upsert({
      where: { code: w.code },
      update: { 
        nameFr: w.nameFr,
        nameAr: w.nameAr,
      },
      create: { 
        nameFr: w.nameFr,
        nameAr: w.nameAr,
        code: w.code,
      },
    });
  }

  const count = await prisma.wilaya.count();
  console.log(`Wilayas seeded successfully! (${count} total)`);
}

async function seedBaladyat() {
  console.log('Seeding baladyat...');
  
  for (const b of baladyat) {
    // Find the wilaya by code
    const wilaya = await prisma.wilaya.findUnique({
      where: { code: b.wilayaCode },
    });
    
    if (wilaya) {
      await prisma.baladya.upsert({
        where: {
          nameFr_wilayaId: {
            nameFr: b.nameFr,
            wilayaId: wilaya.id,
          },
        },
        update: {
          nameAr: b.nameAr,
        },
        create: {
          nameFr: b.nameFr,
          nameAr: b.nameAr,
          wilayaId: wilaya.id,
        },
      });
    }
  }
  
  const count = await prisma.baladya.count();
  console.log(`Baladyat seeded successfully! (${count} total)`);
}

async function main() {
  console.log('🌱 Seeding database...\n');

  await seedSuperAdmin();
  await seedWilayas();
  await seedBaladyat();

  console.log('\n✅ Seed completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

