// prisma/seed.doctors.ts
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import crypto from 'crypto';

const prisma = new PrismaClient();

// ============================================================
// CONSTANTS
// ============================================================

const UPLOAD_ROOT = path.join(__dirname, '..', 'uploads');
const PUBLIC_LOGOS_DIR = path.join(UPLOAD_ROOT, 'public', 'logos');

const DOCTOR_PHOTOS = [
  'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&h=400&fit=crop',
];

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function ensureDirectory(dir: string) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

async function downloadFile(url: string, retries = 3): Promise<Buffer | null> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const buffer = await new Promise<Buffer>((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        
        const req = client.get(url, { timeout: 30000 }, (response: any) => {
          if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
            const redirectUrl = response.headers.location;
            const fullUrl = redirectUrl.startsWith('http') ? redirectUrl : new URL(redirectUrl, url).toString();
            downloadFile(fullUrl).then((result) => {
              if (result) {
                resolve(result);
              } else {
                reject(new Error('Redirect failed'));
              }
            }).catch(reject);
            return;
          }
          
          if (response.statusCode !== 200) {
            reject(new Error(`Status ${response.statusCode}`));
            return;
          }
          
          const chunks: Buffer[] = [];
          response.on('data', (chunk: Buffer) => chunks.push(chunk));
          response.on('end', () => {
            const buffer = Buffer.concat(chunks);
            if (buffer.length === 0) {
              reject(new Error('Empty response'));
            } else {
              resolve(buffer);
            }
          });
          response.on('error', reject);
        });
        
        req.on('error', reject);
        req.on('timeout', () => {
          req.destroy();
          reject(new Error('Timeout'));
        });
        req.end();
      });
      
      if (buffer && buffer.length > 0) {
        return buffer;
      }
    } catch (error) {
      if (attempt === retries) {
        console.warn(`  ⚠️  Failed to download ${url} after ${retries} attempts: ${error}`);
        return null;
      }
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
  return null;
}

async function saveFile(buffer: Buffer, dir: string, ext: string): Promise<string | null> {
  try {
    if (!buffer || buffer.length === 0) {
      return null;
    }
    
    const filename = `${uuidv4()}.${ext}`;
    const filepath = path.join(dir, filename);
    
    ensureDirectory(dir);
    await fs.promises.writeFile(filepath, buffer);
    
    return filename;
  } catch (error) {
    console.warn(`  ⚠️  Failed to save file: ${error}`);
    return null;
  }
}

async function getPlaceholderBuffer(): Promise<Buffer> {
  const minimalPNG = Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
    0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41,
    0x54, 0x78, 0x9C, 0x63, 0x00, 0x00, 0x00, 0x02,
    0x00, 0x01, 0x5B, 0x7B, 0xBC, 0xFE, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42,
    0x60, 0x82
  ]);
  return minimalPNG;
}

function slugify(text: string): string {
  if (!text) return 'doctor';
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function extractNameParts(name: string): { firstName: string; lastName: string } {
  if (!name || name.trim() === '') {
    return { firstName: 'Unknown', lastName: 'Doctor' };
  }
  
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return { firstName: parts[0], lastName: 'Doctor' };
  }
  return { firstName: parts[0], lastName: parts.slice(1).join(' ') };
}

function mapSpecialtyToName(specialty: string): string {
  if (!specialty) return 'Médecine Générale';
  
  const specialtyMap: Record<string, string> = {
    'Medical clinic': 'Médecine Générale',
    'Medical office': 'Médecine Générale',
    'Dental clinic': 'Chirurgie Dentaire',
    'Free clinic': 'Médecine Générale',
    'Hospital': 'Médecine Générale',
    'Medical diagnostic imaging center': 'Radiologie',
    'Medical Center': 'Médecine Générale',
    'Ophthalmology clinic': 'Ophtalmologie',
    'Otolaryngology clinic': 'ORL',
    'Dermatologist': 'Dermatologie',
    'Cardiologist': 'Cardiologie',
    'Cardiology Clinic': 'Cardiologie',
    'Gastroenterologist': 'Gastro-entérologie',
    'Neurologist': 'Neurologie',
    'Neurosurgeon': 'Neurologie',
    'Psychiatrist': 'Psychiatrie',
    'Psychologist': 'Psychiatrie',
    'Psychotherapist': 'Psychiatrie',
    'Pulmonologist': 'Pneumologie',
    'Rheumatologist': 'Rhumatologie',
    'Urologist': 'Urologie',
    'Nephrologist': 'Urologie',
    'Obstetrician-gynecologist': 'Gynécologie',
    'Gynecologist': 'Gynécologie',
    'Orthopedic surgeon': 'Orthopédie',
    'Orthopedic clinic': 'Orthopédie',
    'Surgeon': 'Chirurgie Générale',
    'Pediatrician': 'Pédiatrie',
    'Endocrinologist': 'Endocrinologie',
    'Diabetologist': 'Endocrinologie',
    'Allergist': 'Pneumologie',
    'Radiologist': 'Radiologie',
    'Optometrist': 'Ophtalmologie',
    'Ophthalmologist': 'Ophtalmologie',
    'Optician': 'Ophtalmologie',
    'Dentist': 'Chirurgie Dentaire',
    'General practitioner': 'Médecine Générale',
    'Family practice physician': 'Médecine Générale',
    'Oral and maxillofacial surgeon': 'Chirurgie Dentaire',
    'Cosmetic dentist': 'Chirurgie Dentaire',
    'Orthodontist': 'Chirurgie Dentaire',
    'Urology clinic': 'Urologie',
    'Dialysis center': 'Urologie',
    'Women\'s health clinic': 'Gynécologie',
  };
  
  const lower = specialty.toLowerCase();
  for (const [key, value] of Object.entries(specialtyMap)) {
    if (lower.includes(key.toLowerCase())) {
      return value;
    }
  }
  
  return 'Médecine Générale';
}

function cleanPhone(phone: string): string | null {
  if (!phone) return null;
  
  // Remove spaces, dashes, parentheses, dots
  let cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
  
  // If starts with 0, keep as is
  if (cleaned.startsWith('0')) {
    // If length is less than 10, pad with 5s
    if (cleaned.length < 10) {
      cleaned = cleaned.padEnd(10, '5');
    }
    return cleaned;
  }
  
  // If starts with +213, convert to 0
  if (cleaned.startsWith('+213')) {
    cleaned = '0' + cleaned.slice(4);
    if (cleaned.length < 10) {
      cleaned = cleaned.padEnd(10, '5');
    }
    return cleaned;
  }
  
  // If it's a number without country code, add 0
  if (/^\d+$/.test(cleaned)) {
    cleaned = '0' + cleaned;
    if (cleaned.length < 10) {
      cleaned = cleaned.padEnd(10, '5');
    }
    return cleaned;
  }
  
  return null;
}

function generateRandomPhone(): string {
  const prefixes = ['05', '06', '07'];
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const rest = String(Math.floor(Math.random() * 100000000)).padStart(8, '0');
  return prefix + rest;
}

function cleanEmail(name: string, phone: string): string {
  if (name && name.trim() !== '') {
    const slug = slugify(name);
    // Make sure email is unique
    return `${slug}${phone.slice(-4)}@iyadati.dz`;
  }
  return `doctor_${phone.slice(-4)}@iyadati.dz`;
}

// ============================================================
// PARSE CSV MANUALLY
// ============================================================

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

function parseCSV(content: string): { headers: string[]; rows: string[][] } {
  const lines = content.split('\n').filter(line => line.trim() !== '');
  if (lines.length === 0) {
    return { headers: [], rows: [] };
  }
  
  const headers = parseCSVLine(lines[0]);
  const rows = lines.slice(1).map(line => parseCSVLine(line));
  
  return { headers, rows };
}

function getColumnIndex(headers: string[], columnName: string): number {
  // Try exact match first
  let index = headers.indexOf(columnName);
  if (index !== -1) return index;
  
  // Try case-insensitive match
  const lowerHeaders = headers.map(h => h.toLowerCase());
  const lowerName = columnName.toLowerCase();
  index = lowerHeaders.indexOf(lowerName);
  if (index !== -1) return index;
  
  // Try partial match
  for (let i = 0; i < headers.length; i++) {
    if (headers[i].toLowerCase().includes(lowerName) || lowerName.includes(headers[i].toLowerCase())) {
      return i;
    }
  }
  
  return -1;
}

// ============================================================
// MAIN SEED FUNCTION
// ============================================================

async function seedRealDoctors() {
  console.log('🚀 Starting REAL DOCTORS seed from CSV!\n');
  
  ensureDirectory(PUBLIC_LOGOS_DIR);
  
  // Read the CSV
  const csvPath = path.join(__dirname, 'data', 'doctors.csv');
  console.log(`📄 Reading CSV from: ${csvPath}`);
  
  if (!fs.existsSync(csvPath)) {
    console.error(`❌ CSV file not found: ${csvPath}`);
    console.log('📁 Please place the doctors.csv file in prisma/data/');
    process.exit(1);
  }
  
  const csvContent = fs.readFileSync(csvPath, 'utf-8');
  const { headers, rows } = parseCSV(csvContent);
  
  console.log(`📊 Found ${rows.length} records in CSV\n`);
  console.log(`📋 Headers: ${headers.join(', ')}\n`);
  
  // Get column indices
  const nameIdx = getColumnIndex(headers, 'Name');
  const firstNameIdx = getColumnIndex(headers, 'First Name');
  const lastNameIdx = getColumnIndex(headers, 'Last Name');
  const specialtyIdx = getColumnIndex(headers, 'Specialty');
  const phoneIdx = getColumnIndex(headers, 'Phone');
  const emailIdx = getColumnIndex(headers, 'Email');
  const latIdx = getColumnIndex(headers, 'Latitude');
  const lngIdx = getColumnIndex(headers, 'Longitude');
  const mapsIdx = getColumnIndex(headers, 'Google Maps');
  
  console.log(`📍 Column mapping:`);
  console.log(`   Name: ${nameIdx >= 0 ? headers[nameIdx] : 'NOT FOUND'}`);
  console.log(`   First Name: ${firstNameIdx >= 0 ? headers[firstNameIdx] : 'NOT FOUND'}`);
  console.log(`   Last Name: ${lastNameIdx >= 0 ? headers[lastNameIdx] : 'NOT FOUND'}`);
  console.log(`   Specialty: ${specialtyIdx >= 0 ? headers[specialtyIdx] : 'NOT FOUND'}`);
  console.log(`   Phone: ${phoneIdx >= 0 ? headers[phoneIdx] : 'NOT FOUND'}`);
  console.log(`   Email: ${emailIdx >= 0 ? headers[emailIdx] : 'NOT FOUND'}`);
  console.log(`   Latitude: ${latIdx >= 0 ? headers[latIdx] : 'NOT FOUND'}`);
  console.log(`   Longitude: ${lngIdx >= 0 ? headers[lngIdx] : 'NOT FOUND'}\n`);
  
  // Get specialties from database
  const specialties = await prisma.specialty.findMany();
  const specialtyMap: Record<string, string> = {};
  for (const spec of specialties) {
    specialtyMap[spec.nameFr] = spec.id;
  }
  
  // Get wilayas from database
  const wilayas = await prisma.wilaya.findMany();
  
  // Find Batna wilaya (most entries are in Batna)
  const batnaWilaya = wilayas.find(w => w.nameFr === 'Batna');
  if (!batnaWilaya) {
    console.error('❌ Batna wilaya not found!');
    process.exit(1);
  }
  
  console.log('📥 Downloading doctor photos...');
  const photoBuffers: (Buffer | null)[] = [];
  for (let i = 0; i < Math.min(rows.length, DOCTOR_PHOTOS.length); i++) {
    const buffer = await downloadFile(DOCTOR_PHOTOS[i % DOCTOR_PHOTOS.length]);
    photoBuffers.push(buffer);
  }
  const placeholderBuffer = await getPlaceholderBuffer();
  
  const hashedPassword = await bcrypt.hash('doctor123456', 12);
  
  let successCount = 0;
  let errorCount = 0;
  const errors: string[] = [];
  const usedPhones = new Set<string>();
  
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    
    try {
      // Get values from row
      const fullName = nameIdx >= 0 ? row[nameIdx] || '' : '';
      let firstName = firstNameIdx >= 0 ? row[firstNameIdx] || '' : '';
      let lastName = lastNameIdx >= 0 ? row[lastNameIdx] || '' : '';
      const specialty = specialtyIdx >= 0 ? row[specialtyIdx] || '' : '';
      const phoneRaw = phoneIdx >= 0 ? row[phoneIdx] || '' : '';
      const latRaw = latIdx >= 0 ? row[latIdx] || '' : '';
      const lngRaw = lngIdx >= 0 ? row[lngIdx] || '' : '';
      
      // If we have a name but no first/last, parse it
      if (fullName && (!firstName || !lastName)) {
        const parts = extractNameParts(fullName);
        if (!firstName) firstName = parts.firstName;
        if (!lastName) lastName = parts.lastName;
      }
      
      // If still no name, use fallback
      if (!firstName && !lastName) {
        firstName = 'Clinic';
        lastName = `Doctor_${i + 1}`;
      }
      
      // If only firstName exists, use it for both
      if (firstName && !lastName) {
        lastName = firstName;
      }
      if (lastName && !firstName) {
        firstName = lastName;
      }
      
      // Clean phone - if invalid or duplicate, generate random
      let phone = cleanPhone(phoneRaw);
      
      // If phone is invalid or duplicate, generate a random one
      if (!phone || usedPhones.has(phone)) {
        let attempts = 0;
        do {
          phone = generateRandomPhone();
          attempts++;
        } while (usedPhones.has(phone) && attempts < 100);
      }
      usedPhones.add(phone);
      
      // Create email
      let baseEmail = cleanEmail(fullName || `${firstName} ${lastName}`, phone);
      let email = baseEmail;
      let emailCounter = 0;
      // Check if email exists in database (we can't easily track in memory for 600+ records)
      // So we'll use a simple approach with counter
      while (emailCounter < 10) {
        const existing = await prisma.doctor.findUnique({
          where: { email }
        });
        if (!existing) break;
        emailCounter++;
        const slug = slugify(fullName || `${firstName} ${lastName}`);
        email = `${slug}${emailCounter}${phone.slice(-4)}@iyadati.dz`;
      }
      
      // Determine specialty
      const specialtyName = mapSpecialtyToName(specialty);
      const specialtyId = specialtyMap[specialtyName] || specialties[0]?.id;
      
      // Get coordinates
      const lat = parseFloat(latRaw);
      const lng = parseFloat(lngRaw);
      
      // Download and save photo
      const photoBuffer = photoBuffers[i % photoBuffers.length] || placeholderBuffer;
      const photoFilename = await saveFile(photoBuffer, PUBLIC_LOGOS_DIR, 'jpg');
      const photoPath = photoFilename ? `public/logos/${photoFilename}` : null;
      const photoFileId = photoFilename ? crypto.randomUUID() : null;
      
      // Create doctor
      const doctor = await prisma.doctor.create({
        data: {
          email,
          password: hashedPassword,
          firstNameFr: firstName.slice(0, 100),
          firstNameAr: firstName.slice(0, 100),
          lastNameFr: lastName.slice(0, 100),
          lastNameAr: lastName.slice(0, 100),
          phone,
          wilayaId: batnaWilaya.id,
          practiceType: 'INDEPENDENT' as any,
          isVerified: true,
          isCompleted: true,
          isSuspended: false,
          isRegistered: true,
          isAvailableForBooking: false,
          messageForUser: "En attente jusqu'au lancement d'Iyadati",
          latitude: !isNaN(lat) && lat !== 0 ? lat : null,
          longitude: !isNaN(lng) && lng !== 0 ? lng : null,
          photoPath,
          photoFileId,
          yearsOfExp: null,
          bioFr: fullName ? `Dr. ${fullName}` : `Dr. ${firstName} ${lastName}`,
          bioAr: `دكتور ${firstName} ${lastName}`,
          reviewVisibility: 'BOTH' as any,
          avgRating: null,
          totalReviews: 0,
        },
      });
      
      // Add specialty if available
      if (specialtyId) {
        await prisma.doctorSpecialty.create({
          data: {
            doctorId: doctor.id,
            specialtyId: specialtyId,
          },
        });
      }
      
      // Save logo if photo was saved
      if (photoFilename) {
        await prisma.doctorLogo.create({
          data: {
            doctorId: doctor.id,
            fileId: crypto.randomUUID(),
            storageKey: crypto.randomUUID(),
            fileName: `logo_${firstName}_${lastName}.jpg`,
            fileType: 'image/jpeg',
            fileSize: photoBuffer.length,
            filePath: photoPath || `public/logos/${photoFilename}`,
            storageType: 'public',
          },
        });
      }
      
      // Create doctor config
      await prisma.doctorConfig.create({
        data: {
          doctorId: doctor.id,
          slotDuration: 30,
          bufferTime: 5,
          maxPerSlot: 1,
        },
      });
      
      successCount++;
      
      if ((i + 1) % 50 === 0 || i === rows.length - 1) {
        console.log(`  📊 Created ${i + 1}/${rows.length} doctors`);
      }
      
    } catch (error) {
      errorCount++;
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push(`Row ${i + 1}: ${errorMsg}`);
      if (errorCount <= 10) {
        console.error(`  ❌ Failed to create doctor at row ${i + 1}:`, errorMsg);
      }
    }
  }
  
  console.log(`\n✅ Successfully created ${successCount} doctors`);
  if (errorCount > 0) {
    console.log(`⚠️ Failed to create ${errorCount} doctors`);
    if (errors.length > 0) {
      console.log('\n📋 First 10 errors:');
      errors.slice(0, 10).forEach(err => console.log(`   ${err}`));
    }
  }
  
  console.log('\n📊 FINAL DOCTOR SUMMARY:');
  console.log(`  👨‍⚕️ Total Doctors: ${await prisma.doctor.count()}`);
  console.log(`  📄 Doctor Documents: ${await prisma.doctorDocument.count()}`);
  console.log(`  🖼️ Doctor Logos: ${await prisma.doctorLogo.count()}`);
  console.log(`  🔗 Doctor Specialties: ${await prisma.doctorSpecialty.count()}`);
  console.log(`  ⚙️ Doctor Configs: ${await prisma.doctorConfig.count()}`);
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  try {
    await seedRealDoctors();
  } catch (error) {
    console.error('❌ SEED ERROR:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
    console.log('\n👋 Database connection closed. Goodbye!');
  }
}

main();

