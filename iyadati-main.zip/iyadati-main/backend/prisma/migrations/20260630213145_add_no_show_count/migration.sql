-- AlterTable
ALTER TABLE "User" ADD COLUMN     "no_show_count" INTEGER NOT NULL DEFAULT 0;
