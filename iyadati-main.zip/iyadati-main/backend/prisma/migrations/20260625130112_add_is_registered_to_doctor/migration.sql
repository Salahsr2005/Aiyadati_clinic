-- AlterTable
ALTER TABLE "doctors" ADD COLUMN     "is_registered" BOOLEAN NOT NULL DEFAULT true;
