-- AlterTable
ALTER TABLE "appointments" ADD COLUMN     "confirmed_at" TIMESTAMP(3),
ADD COLUMN     "confirmed_by" TEXT;
