-- CreateTable
CREATE TABLE "clinic_services" (
    "id" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "name_fr" VARCHAR(200) NOT NULL,
    "name_ar" VARCHAR(200) NOT NULL,
    "description_fr" TEXT,
    "description_ar" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clinic_services_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clinic_service_images" (
    "id" TEXT NOT NULL,
    "service_id" TEXT NOT NULL,
    "image_path" TEXT NOT NULL,
    "caption_fr" TEXT,
    "caption_ar" TEXT,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "clinic_service_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clinic_service_doctors" (
    "id" TEXT NOT NULL,
    "service_id" TEXT NOT NULL,
    "doctor_id" TEXT NOT NULL,
    "is_primary" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "clinic_service_doctors_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "clinic_services_clinic_id_name_fr_key" ON "clinic_services"("clinic_id", "name_fr");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_services_clinic_id_name_ar_key" ON "clinic_services"("clinic_id", "name_ar");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_service_doctors_service_id_doctor_id_key" ON "clinic_service_doctors"("service_id", "doctor_id");

-- AddForeignKey
ALTER TABLE "clinic_services" ADD CONSTRAINT "clinic_services_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "Clinic"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_service_images" ADD CONSTRAINT "clinic_service_images_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "clinic_services"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_service_doctors" ADD CONSTRAINT "clinic_service_doctors_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "clinic_services"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_service_doctors" ADD CONSTRAINT "clinic_service_doctors_doctor_id_fkey" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("id") ON DELETE CASCADE ON UPDATE CASCADE;
