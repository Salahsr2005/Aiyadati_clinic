-- AlterTable
ALTER TABLE "specialties" ADD COLUMN     "image_file_id" TEXT;
