/*
  Warnings:

  - You are about to drop the column `image_file_id` on the `specialties` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[file_id]` on the table `specialties` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "specialties" DROP COLUMN "image_file_id",
ADD COLUMN     "file_id" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "specialties_file_id_key" ON "specialties"("file_id");
