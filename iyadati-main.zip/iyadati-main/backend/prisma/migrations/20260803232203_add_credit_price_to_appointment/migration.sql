-- AlterTable
ALTER TABLE "appointments" ADD COLUMN     "credit_price_at_booking" DOUBLE PRECISION,
ADD COLUMN     "credit_price_id" TEXT;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_credit_price_id_fkey" FOREIGN KEY ("credit_price_id") REFERENCES "credit_prices"("id") ON DELETE SET NULL ON UPDATE CASCADE;
