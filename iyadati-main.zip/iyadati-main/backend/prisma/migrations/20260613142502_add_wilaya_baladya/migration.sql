-- CreateTable
CREATE TABLE "Wilaya" (
    "id" TEXT NOT NULL,
    "code" INTEGER NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Wilaya_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Baladya" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "wilayaId" TEXT NOT NULL,

    CONSTRAINT "Baladya_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Wilaya_code_key" ON "Wilaya"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Wilaya_name_key" ON "Wilaya"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Baladya_name_wilayaId_key" ON "Baladya"("name", "wilayaId");

-- AddForeignKey
ALTER TABLE "Baladya" ADD CONSTRAINT "Baladya_wilayaId_fkey" FOREIGN KEY ("wilayaId") REFERENCES "Wilaya"("id") ON DELETE CASCADE ON UPDATE CASCADE;
