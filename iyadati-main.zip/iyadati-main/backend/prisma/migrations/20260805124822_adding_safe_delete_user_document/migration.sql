/*
  Warnings:

  - The `tags` column on the `user_documents` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "user_documents" ADD COLUMN     "deleted_at" TIMESTAMP(3),
ADD COLUMN     "deleted_by_id" TEXT,
ADD COLUMN     "deleted_by_type" TEXT,
ADD COLUMN     "deleted_reason" TEXT,
DROP COLUMN "tags",
ADD COLUMN     "tags" TEXT[];
