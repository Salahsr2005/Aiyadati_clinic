-- CreateEnum
CREATE TYPE "AdStatus" AS ENUM ('DRAFT', 'ACTIVE', 'SCHEDULED', 'EXPIRED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "AdPosition" AS ENUM ('HOME_TOP', 'HOME_MIDDLE', 'HOME_BOTTOM', 'DOCTOR_LIST', 'CLINIC_LIST', 'APPOINTMENT_SUCCESS', 'CUSTOM');

-- CreateTable
CREATE TABLE "advertisements" (
    "id" TEXT NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "description" TEXT,
    "link" VARCHAR(500),
    "file_id" TEXT NOT NULL,
    "storage_key" TEXT NOT NULL,
    "file_path" TEXT NOT NULL,
    "file_name" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "storage_type" TEXT NOT NULL DEFAULT 'public',
    "position" "AdPosition" NOT NULL DEFAULT 'HOME_TOP',
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "status" "AdStatus" NOT NULL DEFAULT 'DRAFT',
    "starts_at" TIMESTAMP(3),
    "expires_at" TIMESTAMP(3),
    "target_audience" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "target_wilayas" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "view_count" INTEGER NOT NULL DEFAULT 0,
    "click_count" INTEGER NOT NULL DEFAULT 0,
    "created_by" TEXT NOT NULL,
    "updated_by" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "deleted_by" TEXT,

    CONSTRAINT "advertisements_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "advertisements_file_id_key" ON "advertisements"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "advertisements_storage_key_key" ON "advertisements"("storage_key");

-- CreateIndex
CREATE INDEX "advertisements_is_active_status_idx" ON "advertisements"("is_active", "status");

-- CreateIndex
CREATE INDEX "advertisements_starts_at_expires_at_idx" ON "advertisements"("starts_at", "expires_at");

-- CreateIndex
CREATE INDEX "advertisements_position_is_active_idx" ON "advertisements"("position", "is_active");
