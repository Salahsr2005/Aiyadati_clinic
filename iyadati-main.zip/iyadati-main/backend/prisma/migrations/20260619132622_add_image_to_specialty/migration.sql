-- AlterTable
ALTER TABLE "specialties" ADD COLUMN     "image_path" TEXT;
