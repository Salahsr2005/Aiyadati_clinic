-- CreateEnum
CREATE TYPE "NewsLanguage" AS ENUM ('ARABIC', 'FRENCH', 'ENGLISH');

-- AlterTable
ALTER TABLE "news_tapes" ADD COLUMN     "content_ar" TEXT,
ADD COLUMN     "content_en" TEXT,
ADD COLUMN     "content_fr" TEXT,
ADD COLUMN     "language" "NewsLanguage" NOT NULL DEFAULT 'FRENCH',
ADD COLUMN     "title_ar" VARCHAR(200),
ADD COLUMN     "title_en" VARCHAR(200),
ADD COLUMN     "title_fr" VARCHAR(200),
ALTER COLUMN "is_active" SET DEFAULT false;

-- CreateIndex
CREATE INDEX "news_tapes_language_idx" ON "news_tapes"("language");
