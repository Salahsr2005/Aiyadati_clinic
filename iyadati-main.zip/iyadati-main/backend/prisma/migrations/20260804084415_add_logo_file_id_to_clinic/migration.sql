-- AlterTable
ALTER TABLE "Clinic" ADD COLUMN     "logo_file_id" TEXT;
