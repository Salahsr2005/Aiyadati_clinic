/*
  Warnings:

  - You are about to drop the column `window_days` on the `slot_generation_rules` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "slot_generation_rules" DROP COLUMN "window_days",
ADD COLUMN     "booking_window_days" INTEGER NOT NULL DEFAULT 30;
