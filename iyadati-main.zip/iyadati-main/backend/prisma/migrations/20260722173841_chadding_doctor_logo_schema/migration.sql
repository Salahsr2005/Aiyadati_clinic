-- CreateTable
CREATE TABLE "doctor_logos" (
    "id" TEXT NOT NULL,
    "doctor_id" TEXT NOT NULL,
    "file_id" TEXT NOT NULL,
    "storage_key" TEXT NOT NULL,
    "file_name" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "file_path" TEXT NOT NULL,
    "storage_type" TEXT NOT NULL DEFAULT 'public',
    "access_count" INTEGER NOT NULL DEFAULT 0,
    "last_accessed" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "doctor_logos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "doctor_logo_doctor_id_idx" ON "doctor_logos"("doctor_id");

-- CreateIndex
CREATE UNIQUE INDEX "doctor_logo_file_id_unique" ON "doctor_logos"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "doctor_logo_storage_key_unique" ON "doctor_logos"("storage_key");

-- AddForeignKey
ALTER TABLE "doctor_logos" ADD CONSTRAINT "doctor_logos_doctor_id_fkey" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("id") ON DELETE CASCADE ON UPDATE CASCADE;
