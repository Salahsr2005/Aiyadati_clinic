-- AlterTable
ALTER TABLE "news_tapes" ADD COLUMN     "content_ar" TEXT,
ADD COLUMN     "content_en" TEXT,
ADD COLUMN     "content_fr" TEXT;
