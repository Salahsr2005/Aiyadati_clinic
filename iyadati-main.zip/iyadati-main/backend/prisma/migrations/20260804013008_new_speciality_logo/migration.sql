/*
  Warnings:

  - You are about to drop the `specialty_images` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[file_id]` on the table `specialties` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "specialty_images" DROP CONSTRAINT "specialty_images_specialty_id_fkey";

-- AlterTable
ALTER TABLE "specialties" ADD COLUMN     "file_id" TEXT,
ADD COLUMN     "image_path" TEXT;

-- DropTable
DROP TABLE "specialty_images";

-- CreateIndex
CREATE UNIQUE INDEX "specialties_file_id_key" ON "specialties"("file_id");
