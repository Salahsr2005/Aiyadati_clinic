/*
  Warnings:

  - A unique constraint covering the columns `[slot_id,patient_id]` on the table `appointments` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "appointments_slot_id_patient_id_key" ON "appointments"("slot_id", "patient_id");
