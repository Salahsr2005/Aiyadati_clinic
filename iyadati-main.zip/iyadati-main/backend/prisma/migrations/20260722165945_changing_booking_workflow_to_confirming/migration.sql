-- AlterTable
ALTER TABLE "doctors" ADD COLUMN     "photo_file_id" TEXT;
