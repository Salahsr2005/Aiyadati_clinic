-- CreateEnum
CREATE TYPE "ReviewVisibility" AS ENUM ('BOTH', 'RATING_ONLY', 'REVIEW_ONLY', 'NONE');

-- AlterTable
ALTER TABLE "Clinic" ADD COLUMN     "avg_rating" DOUBLE PRECISION,
ADD COLUMN     "review_visibility" "ReviewVisibility" NOT NULL DEFAULT 'BOTH',
ADD COLUMN     "total_reviews" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "doctors" ADD COLUMN     "avg_rating" DOUBLE PRECISION,
ADD COLUMN     "review_visibility" "ReviewVisibility" NOT NULL DEFAULT 'BOTH',
ADD COLUMN     "total_reviews" INTEGER NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "doctor_reviews" (
    "id" TEXT NOT NULL,
    "doctor_id" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,
    "rating" INTEGER,
    "review" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "doctor_reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clinic_reviews" (
    "id" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,
    "rating" INTEGER,
    "review" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clinic_reviews_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "doctor_reviews_doctor_id_patient_id_key" ON "doctor_reviews"("doctor_id", "patient_id");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_reviews_clinic_id_patient_id_key" ON "clinic_reviews"("clinic_id", "patient_id");

-- AddForeignKey
ALTER TABLE "doctor_reviews" ADD CONSTRAINT "doctor_reviews_doctor_id_fkey" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "doctor_reviews" ADD CONSTRAINT "doctor_reviews_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_reviews" ADD CONSTRAINT "clinic_reviews_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "Clinic"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_reviews" ADD CONSTRAINT "clinic_reviews_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
