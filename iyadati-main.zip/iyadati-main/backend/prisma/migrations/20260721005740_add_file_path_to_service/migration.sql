-- AlterTable
ALTER TABLE "clinic_service_images" ADD COLUMN     "file_path" TEXT NOT NULL DEFAULT '';
