-- CreateEnum
CREATE TYPE "FacilityType" AS ENUM ('CLINIC', 'HOSPITAL');

-- AlterTable
ALTER TABLE "Clinic" ADD COLUMN     "facility_type" "FacilityType" NOT NULL DEFAULT 'CLINIC';
