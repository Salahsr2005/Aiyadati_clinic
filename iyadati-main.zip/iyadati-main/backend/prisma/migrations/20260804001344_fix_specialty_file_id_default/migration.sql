/*
  Warnings:

  - Made the column `file_id` on table `specialties` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "specialties" ALTER COLUMN "file_id" SET NOT NULL;
