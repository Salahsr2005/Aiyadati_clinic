-- AlterTable
ALTER TABLE "clinic_gallery" ADD COLUMN     "file_path" TEXT NOT NULL DEFAULT '';
