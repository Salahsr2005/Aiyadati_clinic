-- AlterTable
ALTER TABLE "specialties" ADD COLUMN     "file_path" TEXT;
