-- DropIndex
DROP INDEX "appointments_slot_id_key";

-- AlterTable
ALTER TABLE "doctor_configs" ADD COLUMN     "max_per_slot" INTEGER NOT NULL DEFAULT 1;

-- AlterTable
ALTER TABLE "slots" ADD COLUMN     "max_patients" INTEGER NOT NULL DEFAULT 1;
