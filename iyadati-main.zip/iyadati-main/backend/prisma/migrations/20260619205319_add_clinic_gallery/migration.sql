-- CreateTable
CREATE TABLE "clinic_gallery" (
    "id" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "image_path" TEXT NOT NULL,
    "caption_fr" TEXT,
    "caption_ar" TEXT,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "clinic_gallery_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "clinic_gallery" ADD CONSTRAINT "clinic_gallery_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "Clinic"("id") ON DELETE CASCADE ON UPDATE CASCADE;
