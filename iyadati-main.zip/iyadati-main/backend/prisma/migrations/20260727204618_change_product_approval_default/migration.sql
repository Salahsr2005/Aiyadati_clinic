-- AlterTable
ALTER TABLE "products" ALTER COLUMN "is_approved" SET DEFAULT false;
