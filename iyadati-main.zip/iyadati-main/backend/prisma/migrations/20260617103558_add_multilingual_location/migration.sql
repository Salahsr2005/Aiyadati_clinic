/*
  Warnings:

  - You are about to drop the `Baladya` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Wilaya` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `password` to the `Clinic` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Baladya" DROP CONSTRAINT "Baladya_wilayaId_fkey";

-- DropForeignKey
ALTER TABLE "Clinic" DROP CONSTRAINT "Clinic_baladyaId_fkey";

-- DropForeignKey
ALTER TABLE "Clinic" DROP CONSTRAINT "Clinic_wilayaId_fkey";

-- DropForeignKey
ALTER TABLE "User" DROP CONSTRAINT "User_wilayaId_fkey";

-- AlterTable
ALTER TABLE "Clinic" ADD COLUMN     "password" TEXT NOT NULL;

-- DropTable
DROP TABLE "Baladya";

-- DropTable
DROP TABLE "Wilaya";

-- CreateTable
CREATE TABLE "wilayas" (
    "id" TEXT NOT NULL,
    "code" INTEGER NOT NULL,
    "name_fr" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,

    CONSTRAINT "wilayas_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "baladyat" (
    "id" TEXT NOT NULL,
    "name_fr" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,
    "wilaya_id" TEXT NOT NULL,

    CONSTRAINT "baladyat_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "wilayas_code_key" ON "wilayas"("code");

-- CreateIndex
CREATE UNIQUE INDEX "wilayas_name_fr_key" ON "wilayas"("name_fr");

-- CreateIndex
CREATE UNIQUE INDEX "wilayas_name_ar_key" ON "wilayas"("name_ar");

-- CreateIndex
CREATE UNIQUE INDEX "baladyat_name_fr_wilaya_id_key" ON "baladyat"("name_fr", "wilaya_id");

-- CreateIndex
CREATE UNIQUE INDEX "baladyat_name_ar_wilaya_id_key" ON "baladyat"("name_ar", "wilaya_id");

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_wilayaId_fkey" FOREIGN KEY ("wilayaId") REFERENCES "wilayas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Clinic" ADD CONSTRAINT "Clinic_wilayaId_fkey" FOREIGN KEY ("wilayaId") REFERENCES "wilayas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Clinic" ADD CONSTRAINT "Clinic_baladyaId_fkey" FOREIGN KEY ("baladyaId") REFERENCES "baladyat"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "baladyat" ADD CONSTRAINT "baladyat_wilaya_id_fkey" FOREIGN KEY ("wilaya_id") REFERENCES "wilayas"("id") ON DELETE CASCADE ON UPDATE CASCADE;
