-- CreateEnum
CREATE TYPE "SlotGenerationFrequency" AS ENUM ('DAILY', 'WEEKLY', 'MONTHLY');

-- CreateTable
CREATE TABLE "slot_generation_rules" (
    "id" TEXT NOT NULL,
    "doctor_id" TEXT NOT NULL,
    "frequency" "SlotGenerationFrequency" NOT NULL,
    "window_days" INTEGER NOT NULL DEFAULT 30,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "clinic_id" TEXT,
    "room_id" TEXT,
    "last_run_at" TIMESTAMP(3),
    "next_run_at" TIMESTAMP(3) NOT NULL,
    "error_count" INTEGER NOT NULL DEFAULT 0,
    "last_error" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "slot_generation_rules_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "slot_generation_rules_enabled_next_run_at_idx" ON "slot_generation_rules"("enabled", "next_run_at");

-- CreateIndex
CREATE INDEX "slot_generation_rules_doctor_id_enabled_idx" ON "slot_generation_rules"("doctor_id", "enabled");

-- CreateIndex
CREATE UNIQUE INDEX "slot_generation_rules_doctor_id_key" ON "slot_generation_rules"("doctor_id");

-- AddForeignKey
ALTER TABLE "slot_generation_rules" ADD CONSTRAINT "slot_generation_rules_doctor_id_fkey" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "slot_generation_rules" ADD CONSTRAINT "slot_generation_rules_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "slot_generation_rules" ADD CONSTRAINT "slot_generation_rules_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "clinic_rooms"("id") ON DELETE SET NULL ON UPDATE CASCADE;
