-- AlterTable
ALTER TABLE "Clinic" ADD COLUMN     "isCompleted" BOOLEAN NOT NULL DEFAULT false;
