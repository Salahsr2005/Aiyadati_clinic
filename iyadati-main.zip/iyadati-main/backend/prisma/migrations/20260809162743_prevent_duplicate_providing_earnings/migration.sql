/*
  Warnings:

  - A unique constraint covering the columns `[appointment_id,provider_id,provider_type]` on the table `provider_earnings` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "provider_earnings_appointment_id_provider_id_provider_type_key" ON "provider_earnings"("appointment_id", "provider_id", "provider_type");
