/*
  Warnings:

  - You are about to drop the column `content_ar` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `content_en` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `content_fr` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `language` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `title_ar` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `title_en` on the `news_tapes` table. All the data in the column will be lost.
  - You are about to drop the column `title_fr` on the `news_tapes` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "news_tapes_language_idx";

-- AlterTable
ALTER TABLE "news_tapes" DROP COLUMN "content_ar",
DROP COLUMN "content_en",
DROP COLUMN "content_fr",
DROP COLUMN "language",
DROP COLUMN "title_ar",
DROP COLUMN "title_en",
DROP COLUMN "title_fr";

-- DropEnum
DROP TYPE "NewsLanguage";
