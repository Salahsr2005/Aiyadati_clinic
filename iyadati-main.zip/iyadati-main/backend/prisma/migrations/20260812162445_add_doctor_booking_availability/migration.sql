-- AlterTable
ALTER TABLE "doctors" ADD COLUMN     "is_available_for_booking" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "message_for_user" TEXT;
