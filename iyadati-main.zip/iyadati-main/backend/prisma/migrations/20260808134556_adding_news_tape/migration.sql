-- CreateEnum
CREATE TYPE "NewsStatus" AS ENUM ('DRAFT', 'ACTIVE', 'SCHEDULED', 'EXPIRED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "NewsTargetAudience" AS ENUM ('ALL', 'PATIENTS', 'DOCTORS', 'CLINICS', 'ADMINS', 'SUPER_ADMINS');

-- CreateTable
CREATE TABLE "news_tapes" (
    "id" TEXT NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "content" TEXT NOT NULL,
    "link" VARCHAR(500),
    "status" "NewsStatus" NOT NULL DEFAULT 'DRAFT',
    "starts_at" TIMESTAMP(3),
    "expires_at" TIMESTAMP(3),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "target_audience" "NewsTargetAudience"[] DEFAULT ARRAY[]::"NewsTargetAudience"[],
    "target_user_ids" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "target_doctor_ids" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "target_clinic_ids" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "target_wilayas" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "priority" INTEGER NOT NULL DEFAULT 0,
    "view_count" INTEGER NOT NULL DEFAULT 0,
    "created_by" TEXT NOT NULL,
    "created_by_type" TEXT NOT NULL,
    "updated_by" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "deleted_by" TEXT,

    CONSTRAINT "news_tapes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "news_tapes_is_active_status_idx" ON "news_tapes"("is_active", "status");

-- CreateIndex
CREATE INDEX "news_tapes_starts_at_expires_at_idx" ON "news_tapes"("starts_at", "expires_at");

-- CreateIndex
CREATE INDEX "news_tapes_target_audience_idx" ON "news_tapes"("target_audience");
