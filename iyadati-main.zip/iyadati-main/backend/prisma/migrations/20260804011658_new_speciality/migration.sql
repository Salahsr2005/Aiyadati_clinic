/*
  Warnings:

  - You are about to drop the column `file_id` on the `specialties` table. All the data in the column will be lost.
  - You are about to drop the column `file_path` on the `specialties` table. All the data in the column will be lost.
  - You are about to drop the column `image_path` on the `specialties` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "specialties_file_id_key";

-- AlterTable
ALTER TABLE "specialties" DROP COLUMN "file_id",
DROP COLUMN "file_path",
DROP COLUMN "image_path";

-- CreateTable
CREATE TABLE "specialty_images" (
    "id" TEXT NOT NULL,
    "specialty_id" TEXT NOT NULL,
    "file_id" TEXT NOT NULL,
    "storage_key" TEXT NOT NULL,
    "file_name" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "file_path" TEXT NOT NULL,
    "storage_type" TEXT NOT NULL DEFAULT 'public',
    "is_primary" BOOLEAN NOT NULL DEFAULT false,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "caption_fr" TEXT,
    "caption_ar" TEXT,
    "access_count" INTEGER NOT NULL DEFAULT 0,
    "last_accessed" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "specialty_images_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "specialty_images_file_id_unique" ON "specialty_images"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "specialty_images_storage_key_unique" ON "specialty_images"("storage_key");

-- CreateIndex
CREATE INDEX "specialty_images_specialty_id_idx" ON "specialty_images"("specialty_id");

-- AddForeignKey
ALTER TABLE "specialty_images" ADD CONSTRAINT "specialty_images_specialty_id_fkey" FOREIGN KEY ("specialty_id") REFERENCES "specialties"("id") ON DELETE CASCADE ON UPDATE CASCADE;
