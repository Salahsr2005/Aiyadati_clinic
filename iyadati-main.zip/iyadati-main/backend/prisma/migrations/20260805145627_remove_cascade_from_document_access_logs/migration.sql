-- DropForeignKey
ALTER TABLE "document_access_logs" DROP CONSTRAINT "document_access_logs_document_id_fkey";

-- AddForeignKey
ALTER TABLE "document_access_logs" ADD CONSTRAINT "document_access_logs_document_id_fkey" FOREIGN KEY ("document_id") REFERENCES "user_documents"("id") ON DELETE SET NULL ON UPDATE CASCADE;
