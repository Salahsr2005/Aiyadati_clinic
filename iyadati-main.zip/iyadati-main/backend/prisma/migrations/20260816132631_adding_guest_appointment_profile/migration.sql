/*
  Warnings:

  - A unique constraint covering the columns `[slot_id,guest_patient_id]` on the table `appointments` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_patient_id_fkey";

-- AlterTable
ALTER TABLE "appointments" ADD COLUMN     "guest_patient_id" TEXT,
ADD COLUMN     "patient_type" VARCHAR(20) NOT NULL DEFAULT 'REGISTERED',
ALTER COLUMN "patient_id" DROP NOT NULL;

-- CreateTable
CREATE TABLE "guest_patients" (
    "id" TEXT NOT NULL,
    "first_name" VARCHAR(100) NOT NULL,
    "last_name" VARCHAR(100) NOT NULL,
    "phone" VARCHAR(20) NOT NULL,
    "email" VARCHAR(255),
    "date_of_birth" DATE,
    "wilaya_id" TEXT,
    "created_by" TEXT NOT NULL,
    "created_by_type" VARCHAR(20) NOT NULL,
    "converted_to_user_id" TEXT,
    "converted_at" TIMESTAMP(3),
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "guest_patients_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "guest_patients_converted_to_user_id_key" ON "guest_patients"("converted_to_user_id");

-- CreateIndex
CREATE INDEX "guest_patients_phone_idx" ON "guest_patients"("phone");

-- CreateIndex
CREATE INDEX "guest_patients_created_by_created_at_idx" ON "guest_patients"("created_by", "created_at");

-- CreateIndex
CREATE INDEX "guest_patients_created_by_type_idx" ON "guest_patients"("created_by_type");

-- CreateIndex
CREATE INDEX "guest_patients_converted_to_user_id_idx" ON "guest_patients"("converted_to_user_id");

-- CreateIndex
CREATE INDEX "appointments_patient_id_idx" ON "appointments"("patient_id");

-- CreateIndex
CREATE INDEX "appointments_guest_patient_id_idx" ON "appointments"("guest_patient_id");

-- CreateIndex
CREATE INDEX "appointments_patient_type_idx" ON "appointments"("patient_type");

-- CreateIndex
CREATE UNIQUE INDEX "appointments_slot_id_guest_patient_id_key" ON "appointments"("slot_id", "guest_patient_id");

-- AddForeignKey
ALTER TABLE "guest_patients" ADD CONSTRAINT "guest_patients_wilaya_id_fkey" FOREIGN KEY ("wilaya_id") REFERENCES "wilayas"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_guest_patient_id_fkey" FOREIGN KEY ("guest_patient_id") REFERENCES "guest_patients"("id") ON DELETE SET NULL ON UPDATE CASCADE;
