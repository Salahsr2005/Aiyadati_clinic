-- AlterTable
ALTER TABLE "clinic_service_images" ALTER COLUMN "file_path" DROP DEFAULT;
