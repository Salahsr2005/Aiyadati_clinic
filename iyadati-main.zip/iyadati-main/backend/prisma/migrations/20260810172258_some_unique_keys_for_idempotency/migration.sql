/*
  Warnings:

  - You are about to alter the column `status` on the `HealthCheck` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(50)`.
  - You are about to alter the column `status` on the `chat_rooms` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(20)`.
  - You are about to drop the column `storage_key` on the `clinic_service_images` table. All the data in the column will be lost.
  - You are about to drop the column `firstName` on the `contact_users` table. All the data in the column will be lost.
  - You are about to drop the column `lastName` on the `contact_users` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `credit_prices` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `credit_prices` table. All the data in the column will be lost.
  - You are about to alter the column `type` on the `credit_transactions` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(50)`.
  - You are about to alter the column `status` on the `document_requests` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(30)`.
  - You are about to drop the column `accessCount` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `expiresAt` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `fileId` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `fileName` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `filePath` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `fileSize` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `fileType` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `lastAccessed` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `mimeType` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `ownerId` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `ownerType` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `storageKey` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `storageType` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `tableId` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `tableName` on the `file_registry` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `file_registry` table. All the data in the column will be lost.
  - You are about to alter the column `title` on the `notifications` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(255)`.
  - You are about to alter the column `type` on the `notifications` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(50)`.
  - You are about to alter the column `status` on the `slots` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(20)`.
  - You are about to alter the column `platform` on the `user_devices` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(20)`.
  - You are about to drop the `Admin` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `AuditLog` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Clinic` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `SuperAdmin` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `User` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[idempotency_key]` on the table `appointments` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storageKey]` on the table `clinic_service_images` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[file_id]` on the table `file_registry` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storage_key]` on the table `file_registry` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[chargily_id]` on the table `orders` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[chargily_id]` on the table `payments` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[slot_key]` on the table `slots` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[doctor_id,clinic_id,date,start_time]` on the table `slots` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `storageKey` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - Added the required column `first_name` to the `contact_users` table without a default value. This is not possible if the table is not empty.
  - Added the required column `last_name` to the `contact_users` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `credit_prices` table without a default value. This is not possible if the table is not empty.
  - Changed the type of `access_type` on the `document_access_logs` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.
  - Added the required column `file_id` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_name` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_path` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_size` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_type` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `mime_type` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `owner_id` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `owner_type` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `storage_key` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `storage_type` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `table_id` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `table_name` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `file_registry` table without a default value. This is not possible if the table is not empty.
  - Added the required column `slot_key` to the `slots` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Clinic" DROP CONSTRAINT "Clinic_baladyaId_fkey";

-- DropForeignKey
ALTER TABLE "Clinic" DROP CONSTRAINT "Clinic_wilayaId_fkey";

-- DropForeignKey
ALTER TABLE "User" DROP CONSTRAINT "User_wilayaId_fkey";

-- DropForeignKey
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_doctors" DROP CONSTRAINT "clinic_doctors_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_documents" DROP CONSTRAINT "clinic_documents_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_gallery" DROP CONSTRAINT "clinic_gallery_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_reviews" DROP CONSTRAINT "clinic_reviews_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_reviews" DROP CONSTRAINT "clinic_reviews_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_rooms" DROP CONSTRAINT "clinic_rooms_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_services" DROP CONSTRAINT "clinic_services_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "clinic_working_hours" DROP CONSTRAINT "clinic_working_hours_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "contact_users" DROP CONSTRAINT "contact_users_user_id_fkey";

-- DropForeignKey
ALTER TABLE "credit_transactions" DROP CONSTRAINT "credit_transactions_sender_id_fkey";

-- DropForeignKey
ALTER TABLE "credit_transactions" DROP CONSTRAINT "credit_transactions_wallet_id_fkey";

-- DropForeignKey
ALTER TABLE "doctor_availabilities" DROP CONSTRAINT "doctor_availabilities_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "doctor_reviews" DROP CONSTRAINT "doctor_reviews_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "document_access_logs" DROP CONSTRAINT "document_access_logs_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "document_requests" DROP CONSTRAINT "document_requests_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_user_id_fkey";

-- DropForeignKey
ALTER TABLE "orders" DROP CONSTRAINT "orders_buyer_id_fkey";

-- DropForeignKey
ALTER TABLE "orders" DROP CONSTRAINT "orders_seller_id_fkey";

-- DropForeignKey
ALTER TABLE "patient_doctor_consents" DROP CONSTRAINT "patient_doctor_consents_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "payments" DROP CONSTRAINT "payments_user_id_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_seller_id_fkey";

-- DropForeignKey
ALTER TABLE "seller_documents" DROP CONSTRAINT "seller_documents_user_id_fkey";

-- DropForeignKey
ALTER TABLE "slots" DROP CONSTRAINT "slots_clinic_id_fkey";

-- DropForeignKey
ALTER TABLE "user_devices" DROP CONSTRAINT "user_devices_user_id_fkey";

-- DropForeignKey
ALTER TABLE "user_documents" DROP CONSTRAINT "user_documents_user_id_fkey";

-- DropForeignKey
ALTER TABLE "user_wallets" DROP CONSTRAINT "user_wallets_user_id_fkey";

-- DropIndex
DROP INDEX "advertisements_position_is_active_idx";

-- DropIndex
DROP INDEX "clinic_service_images_storage_key_key";

-- DropIndex
DROP INDEX "document_access_logs_document_id_idx";

-- DropIndex
DROP INDEX "document_access_logs_patient_id_doctor_id_idx";

-- DropIndex
DROP INDEX "file_registry_fileId_key";

-- DropIndex
DROP INDEX "file_registry_storageKey_key";

-- DropIndex
DROP INDEX "news_tapes_target_audience_idx";

-- DropIndex
DROP INDEX "orders_buyer_id_idx";

-- DropIndex
DROP INDEX "orders_seller_id_idx";

-- DropIndex
DROP INDEX "orders_status_idx";

-- DropIndex
DROP INDEX "products_category_id_idx";

-- DropIndex
DROP INDEX "products_seller_id_idx";

-- DropIndex
DROP INDEX "products_status_idx";

-- DropIndex
DROP INDEX "provider_earnings_provider_id_provider_type_idx";

-- DropIndex
DROP INDEX "provider_earnings_status_idx";

-- DropIndex
DROP INDEX "settlement_batches_status_idx";

-- DropIndex
DROP INDEX "settlement_payments_provider_id_idx";

-- DropIndex
DROP INDEX "slots_doctor_id_date_idx";

-- AlterTable
ALTER TABLE "HealthCheck" ALTER COLUMN "status" SET DATA TYPE VARCHAR(50);

-- AlterTable
ALTER TABLE "appointments" ADD COLUMN     "idempotency_key" TEXT;

-- AlterTable
ALTER TABLE "chat_rooms" ALTER COLUMN "status" SET DATA TYPE VARCHAR(20);

-- AlterTable
ALTER TABLE "clinic_service_images" DROP COLUMN "storage_key",
ADD COLUMN     "storageKey" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "contact_users" DROP COLUMN "firstName",
DROP COLUMN "lastName",
ADD COLUMN     "first_name" TEXT NOT NULL,
ADD COLUMN     "last_name" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "credit_prices" DROP COLUMN "createdAt",
DROP COLUMN "updatedAt",
ADD COLUMN     "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "credit_transactions" ALTER COLUMN "type" SET DATA TYPE VARCHAR(50);

-- AlterTable
ALTER TABLE "document_access_logs" ALTER COLUMN "document_id" DROP NOT NULL,
DROP COLUMN "access_type",
ADD COLUMN     "access_type" "AccessType" NOT NULL;

-- AlterTable
ALTER TABLE "document_requests" ALTER COLUMN "document_ids" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "status" SET DATA TYPE VARCHAR(30);

-- AlterTable
ALTER TABLE "file_registry" DROP COLUMN "accessCount",
DROP COLUMN "createdAt",
DROP COLUMN "expiresAt",
DROP COLUMN "fileId",
DROP COLUMN "fileName",
DROP COLUMN "filePath",
DROP COLUMN "fileSize",
DROP COLUMN "fileType",
DROP COLUMN "lastAccessed",
DROP COLUMN "mimeType",
DROP COLUMN "ownerId",
DROP COLUMN "ownerType",
DROP COLUMN "storageKey",
DROP COLUMN "storageType",
DROP COLUMN "tableId",
DROP COLUMN "tableName",
DROP COLUMN "updatedAt",
ADD COLUMN     "access_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "expires_at" TIMESTAMP(3),
ADD COLUMN     "file_id" TEXT NOT NULL,
ADD COLUMN     "file_name" TEXT NOT NULL,
ADD COLUMN     "file_path" TEXT NOT NULL,
ADD COLUMN     "file_size" INTEGER NOT NULL,
ADD COLUMN     "file_type" TEXT NOT NULL,
ADD COLUMN     "last_accessed" TIMESTAMP(3),
ADD COLUMN     "mime_type" TEXT NOT NULL,
ADD COLUMN     "owner_id" TEXT NOT NULL,
ADD COLUMN     "owner_type" TEXT NOT NULL,
ADD COLUMN     "storage_key" TEXT NOT NULL,
ADD COLUMN     "storage_type" TEXT NOT NULL,
ADD COLUMN     "table_id" TEXT NOT NULL,
ADD COLUMN     "table_name" TEXT NOT NULL,
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "notifications" ALTER COLUMN "title" SET DATA TYPE VARCHAR(255),
ALTER COLUMN "type" SET DATA TYPE VARCHAR(50);

-- AlterTable
ALTER TABLE "patient_doctor_consents" ALTER COLUMN "custom_document_ids" SET DEFAULT ARRAY[]::TEXT[];

-- AlterTable
ALTER TABLE "settlement_batches" ALTER COLUMN "processed_at" DROP NOT NULL;

-- AlterTable
ALTER TABLE "slots" ADD COLUMN     "slot_key" TEXT NOT NULL,
ALTER COLUMN "status" SET DATA TYPE VARCHAR(20);

-- AlterTable
ALTER TABLE "user_devices" ALTER COLUMN "platform" SET DATA TYPE VARCHAR(20);

-- AlterTable
ALTER TABLE "user_documents" ALTER COLUMN "shared_with" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "tags" SET DEFAULT ARRAY[]::TEXT[];

-- DropTable
DROP TABLE "Admin";

-- DropTable
DROP TABLE "AuditLog";

-- DropTable
DROP TABLE "Clinic";

-- DropTable
DROP TABLE "SuperAdmin";

-- DropTable
DROP TABLE "User";

-- CreateTable
CREATE TABLE "super_admins" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" "Role" NOT NULL DEFAULT 'SUPER_ADMIN',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "super_admins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "admins" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" "Role" NOT NULL DEFAULT 'ADMIN',
    "adminRole" TEXT,
    "created_by" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "admins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "first_name" TEXT NOT NULL,
    "last_name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "date_of_birth" TIMESTAMP(3) NOT NULL,
    "wilaya_id" TEXT NOT NULL,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "can_post" BOOLEAN NOT NULL DEFAULT false,
    "verification_code" TEXT,
    "otp_expires_at" TIMESTAMP(3),
    "no_show_count" INTEGER NOT NULL DEFAULT 0,
    "is_suspended" BOOLEAN NOT NULL DEFAULT false,
    "suspension_reason" TEXT,
    "trust_points" INTEGER NOT NULL DEFAULT 0,
    "trust_level" INTEGER NOT NULL DEFAULT 1,
    "qr_code" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clinics" (
    "id" TEXT NOT NULL,
    "name_fr" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "description_ar" TEXT,
    "description_fr" TEXT,
    "wilaya_id" TEXT NOT NULL,
    "baladya_id" TEXT,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "phone" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "logo_path" TEXT,
    "logo_file_id" TEXT,
    "facility_type" "FacilityType" NOT NULL DEFAULT 'CLINIC',
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "is_suspended" BOOLEAN NOT NULL DEFAULT false,
    "is_completed" BOOLEAN NOT NULL DEFAULT false,
    "avg_rating" DOUBLE PRECISION,
    "total_reviews" INTEGER NOT NULL DEFAULT 0,
    "review_visibility" "ReviewVisibility" NOT NULL DEFAULT 'BOTH',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clinics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL,
    "action" VARCHAR(100) NOT NULL,
    "entity" VARCHAR(100) NOT NULL,
    "entity_id" TEXT NOT NULL,
    "performed_by" TEXT NOT NULL,
    "details" JSONB,
    "ip" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "super_admins_email_key" ON "super_admins"("email");

-- CreateIndex
CREATE INDEX "super_admins_createdAt_idx" ON "super_admins"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "admins_email_key" ON "admins"("email");

-- CreateIndex
CREATE INDEX "admins_role_idx" ON "admins"("role");

-- CreateIndex
CREATE INDEX "admins_created_at_idx" ON "admins"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_phone_key" ON "users"("phone");

-- CreateIndex
CREATE UNIQUE INDEX "users_qr_code_key" ON "users"("qr_code");

-- CreateIndex
CREATE INDEX "users_wilaya_id_idx" ON "users"("wilaya_id");

-- CreateIndex
CREATE INDEX "users_is_verified_is_suspended_idx" ON "users"("is_verified", "is_suspended");

-- CreateIndex
CREATE INDEX "users_created_at_idx" ON "users"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "clinics_phone_key" ON "clinics"("phone");

-- CreateIndex
CREATE UNIQUE INDEX "clinics_email_key" ON "clinics"("email");

-- CreateIndex
CREATE INDEX "clinics_wilaya_id_idx" ON "clinics"("wilaya_id");

-- CreateIndex
CREATE INDEX "clinics_baladya_id_idx" ON "clinics"("baladya_id");

-- CreateIndex
CREATE INDEX "clinics_is_verified_is_suspended_idx" ON "clinics"("is_verified", "is_suspended");

-- CreateIndex
CREATE INDEX "clinics_facility_type_idx" ON "clinics"("facility_type");

-- CreateIndex
CREATE INDEX "clinics_created_at_idx" ON "clinics"("created_at");

-- CreateIndex
CREATE INDEX "audit_logs_entity_entity_id_created_at_idx" ON "audit_logs"("entity", "entity_id", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_performed_by_created_at_idx" ON "audit_logs"("performed_by", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_action_created_at_idx" ON "audit_logs"("action", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_created_at_idx" ON "audit_logs"("created_at");

-- CreateIndex
CREATE INDEX "HealthCheck_checkedAt_idx" ON "HealthCheck"("checkedAt");

-- CreateIndex
CREATE INDEX "advertisements_position_is_active_sort_order_idx" ON "advertisements"("position", "is_active", "sort_order");

-- CreateIndex
CREATE INDEX "advertisements_deleted_at_idx" ON "advertisements"("deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "appointments_idempotency_key_key" ON "appointments"("idempotency_key");

-- CreateIndex
CREATE INDEX "appointments_patient_id_status_created_at_idx" ON "appointments"("patient_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "appointments_doctor_id_status_created_at_idx" ON "appointments"("doctor_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "appointments_clinic_id_status_created_at_idx" ON "appointments"("clinic_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "appointments_slot_id_status_idx" ON "appointments"("slot_id", "status");

-- CreateIndex
CREATE INDEX "appointments_status_created_at_idx" ON "appointments"("status", "created_at");

-- CreateIndex
CREATE INDEX "appointments_created_at_idx" ON "appointments"("created_at");

-- CreateIndex
CREATE INDEX "baladyat_wilaya_id_idx" ON "baladyat"("wilaya_id");

-- CreateIndex
CREATE INDEX "categories_parent_id_is_active_sort_order_idx" ON "categories"("parent_id", "is_active", "sort_order");

-- CreateIndex
CREATE INDEX "categories_is_active_idx" ON "categories"("is_active");

-- CreateIndex
CREATE INDEX "chat_messages_room_id_created_at_idx" ON "chat_messages"("room_id", "created_at");

-- CreateIndex
CREATE INDEX "chat_messages_sender_id_created_at_idx" ON "chat_messages"("sender_id", "created_at");

-- CreateIndex
CREATE INDEX "chat_rooms_user_id_status_idx" ON "chat_rooms"("user_id", "status");

-- CreateIndex
CREATE INDEX "chat_rooms_support_id_status_idx" ON "chat_rooms"("support_id", "status");

-- CreateIndex
CREATE INDEX "chat_rooms_status_updated_at_idx" ON "chat_rooms"("status", "updated_at");

-- CreateIndex
CREATE INDEX "clinic_doctors_doctor_id_status_is_active_idx" ON "clinic_doctors"("doctor_id", "status", "is_active");

-- CreateIndex
CREATE INDEX "clinic_doctors_clinic_id_status_is_active_idx" ON "clinic_doctors"("clinic_id", "status", "is_active");

-- CreateIndex
CREATE INDEX "clinic_documents_clinic_id_created_at_idx" ON "clinic_documents"("clinic_id", "created_at");

-- CreateIndex
CREATE INDEX "clinic_documents_doc_type_idx" ON "clinic_documents"("doc_type");

-- CreateIndex
CREATE INDEX "clinic_documents_expires_at_idx" ON "clinic_documents"("expires_at");

-- CreateIndex
CREATE INDEX "clinic_gallery_clinic_id_is_active_sort_order_idx" ON "clinic_gallery"("clinic_id", "is_active", "sort_order");

-- CreateIndex
CREATE INDEX "clinic_reviews_clinic_id_created_at_idx" ON "clinic_reviews"("clinic_id", "created_at");

-- CreateIndex
CREATE INDEX "clinic_reviews_patient_id_created_at_idx" ON "clinic_reviews"("patient_id", "created_at");

-- CreateIndex
CREATE INDEX "clinic_rooms_clinic_id_is_active_idx" ON "clinic_rooms"("clinic_id", "is_active");

-- CreateIndex
CREATE INDEX "clinic_rooms_specialty_id_idx" ON "clinic_rooms"("specialty_id");

-- CreateIndex
CREATE INDEX "clinic_service_doctors_doctor_id_idx" ON "clinic_service_doctors"("doctor_id");

-- CreateIndex
CREATE INDEX "clinic_service_doctors_service_id_is_primary_idx" ON "clinic_service_doctors"("service_id", "is_primary");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_service_images_storageKey_key" ON "clinic_service_images"("storageKey");

-- CreateIndex
CREATE INDEX "clinic_service_images_service_id_is_active_sort_order_idx" ON "clinic_service_images"("service_id", "is_active", "sort_order");

-- CreateIndex
CREATE INDEX "clinic_services_clinic_id_is_active_sort_order_idx" ON "clinic_services"("clinic_id", "is_active", "sort_order");

-- CreateIndex
CREATE INDEX "clinic_working_hours_clinic_id_is_open_idx" ON "clinic_working_hours"("clinic_id", "is_open");

-- CreateIndex
CREATE INDEX "contact_users_user_id_is_active_idx" ON "contact_users"("user_id", "is_active");

-- CreateIndex
CREATE INDEX "contact_users_phone_idx" ON "contact_users"("phone");

-- CreateIndex
CREATE INDEX "credit_prices_created_at_idx" ON "credit_prices"("created_at");

-- CreateIndex
CREATE INDEX "credit_transactions_wallet_id_created_at_idx" ON "credit_transactions"("wallet_id", "created_at");

-- CreateIndex
CREATE INDEX "credit_transactions_sender_id_created_at_idx" ON "credit_transactions"("sender_id", "created_at");

-- CreateIndex
CREATE INDEX "credit_transactions_reference_id_idx" ON "credit_transactions"("reference_id");

-- CreateIndex
CREATE INDEX "credit_transactions_type_idx" ON "credit_transactions"("type");

-- CreateIndex
CREATE INDEX "doctor_availabilities_doctor_id_day_of_week_is_active_idx" ON "doctor_availabilities"("doctor_id", "day_of_week", "is_active");

-- CreateIndex
CREATE INDEX "doctor_availabilities_clinic_id_day_of_week_is_active_idx" ON "doctor_availabilities"("clinic_id", "day_of_week", "is_active");

-- CreateIndex
CREATE INDEX "doctor_availabilities_room_id_idx" ON "doctor_availabilities"("room_id");

-- CreateIndex
CREATE INDEX "doctor_breaks_doctor_id_start_date_end_date_idx" ON "doctor_breaks"("doctor_id", "start_date", "end_date");

-- CreateIndex
CREATE INDEX "doctor_documents_doctor_id_uploaded_at_idx" ON "doctor_documents"("doctor_id", "uploaded_at");

-- CreateIndex
CREATE INDEX "doctor_documents_doc_type_idx" ON "doctor_documents"("doc_type");

-- CreateIndex
CREATE INDEX "doctor_documents_expires_at_idx" ON "doctor_documents"("expires_at");

-- CreateIndex
CREATE INDEX "doctor_reviews_doctor_id_created_at_idx" ON "doctor_reviews"("doctor_id", "created_at");

-- CreateIndex
CREATE INDEX "doctor_reviews_patient_id_created_at_idx" ON "doctor_reviews"("patient_id", "created_at");

-- CreateIndex
CREATE INDEX "doctor_specialties_specialty_id_idx" ON "doctor_specialties"("specialty_id");

-- CreateIndex
CREATE INDEX "doctors_wilaya_id_idx" ON "doctors"("wilaya_id");

-- CreateIndex
CREATE INDEX "doctors_baladya_id_idx" ON "doctors"("baladya_id");

-- CreateIndex
CREATE INDEX "doctors_is_verified_is_suspended_idx" ON "doctors"("is_verified", "is_suspended");

-- CreateIndex
CREATE INDEX "doctors_practice_type_idx" ON "doctors"("practice_type");

-- CreateIndex
CREATE INDEX "doctors_created_at_idx" ON "doctors"("created_at");

-- CreateIndex
CREATE INDEX "document_access_logs_document_id_accessed_at_idx" ON "document_access_logs"("document_id", "accessed_at");

-- CreateIndex
CREATE INDEX "document_access_logs_patient_id_doctor_id_accessed_at_idx" ON "document_access_logs"("patient_id", "doctor_id", "accessed_at");

-- CreateIndex
CREATE INDEX "document_access_logs_doctor_id_accessed_at_idx" ON "document_access_logs"("doctor_id", "accessed_at");

-- CreateIndex
CREATE INDEX "document_requests_doctor_id_status_requested_at_idx" ON "document_requests"("doctor_id", "status", "requested_at");

-- CreateIndex
CREATE INDEX "document_requests_appointment_id_idx" ON "document_requests"("appointment_id");

-- CreateIndex
CREATE UNIQUE INDEX "file_registry_file_id_key" ON "file_registry"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "file_registry_storage_key_key" ON "file_registry"("storage_key");

-- CreateIndex
CREATE INDEX "file_registry_owner_id_owner_type_idx" ON "file_registry"("owner_id", "owner_type");

-- CreateIndex
CREATE INDEX "file_registry_table_name_table_id_idx" ON "file_registry"("table_name", "table_id");

-- CreateIndex
CREATE INDEX "file_registry_category_idx" ON "file_registry"("category");

-- CreateIndex
CREATE INDEX "file_registry_expires_at_idx" ON "file_registry"("expires_at");

-- CreateIndex
CREATE INDEX "news_tapes_priority_created_at_idx" ON "news_tapes"("priority", "created_at");

-- CreateIndex
CREATE INDEX "news_tapes_deleted_at_idx" ON "news_tapes"("deleted_at");

-- CreateIndex
CREATE INDEX "notifications_user_id_is_read_created_at_idx" ON "notifications"("user_id", "is_read", "created_at");

-- CreateIndex
CREATE INDEX "notifications_type_created_at_idx" ON "notifications"("type", "created_at");

-- CreateIndex
CREATE INDEX "order_items_order_id_idx" ON "order_items"("order_id");

-- CreateIndex
CREATE INDEX "order_items_product_id_idx" ON "order_items"("product_id");

-- CreateIndex
CREATE INDEX "order_status_history_order_id_created_at_idx" ON "order_status_history"("order_id", "created_at");

-- CreateIndex
CREATE INDEX "order_status_history_status_created_at_idx" ON "order_status_history"("status", "created_at");

-- CreateIndex
CREATE UNIQUE INDEX "orders_chargily_id_key" ON "orders"("chargily_id");

-- CreateIndex
CREATE INDEX "orders_buyer_id_status_created_at_idx" ON "orders"("buyer_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "orders_seller_id_status_created_at_idx" ON "orders"("seller_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "orders_status_created_at_idx" ON "orders"("status", "created_at");

-- CreateIndex
CREATE INDEX "orders_payment_status_created_at_idx" ON "orders"("payment_status", "created_at");

-- CreateIndex
CREATE INDEX "orders_shipping_company_id_idx" ON "orders"("shipping_company_id");

-- CreateIndex
CREATE INDEX "orders_created_at_idx" ON "orders"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "payments_chargily_id_key" ON "payments"("chargily_id");

-- CreateIndex
CREATE INDEX "payments_user_id_created_at_idx" ON "payments"("user_id", "created_at");

-- CreateIndex
CREATE INDEX "payments_status_created_at_idx" ON "payments"("status", "created_at");

-- CreateIndex
CREATE INDEX "payments_chargily_id_idx" ON "payments"("chargily_id");

-- CreateIndex
CREATE INDEX "product_images_product_id_is_primary_sort_order_idx" ON "product_images"("product_id", "is_primary", "sort_order");

-- CreateIndex
CREATE INDEX "products_seller_id_status_idx" ON "products"("seller_id", "status");

-- CreateIndex
CREATE INDEX "products_category_id_status_idx" ON "products"("category_id", "status");

-- CreateIndex
CREATE INDEX "products_status_is_approved_idx" ON "products"("status", "is_approved");

-- CreateIndex
CREATE INDEX "products_created_at_idx" ON "products"("created_at");

-- CreateIndex
CREATE INDEX "provider_balances_provider_type_idx" ON "provider_balances"("provider_type");

-- CreateIndex
CREATE INDEX "provider_earnings_provider_id_provider_type_status_idx" ON "provider_earnings"("provider_id", "provider_type", "status");

-- CreateIndex
CREATE INDEX "provider_earnings_status_created_at_idx" ON "provider_earnings"("status", "created_at");

-- CreateIndex
CREATE INDEX "seller_documents_user_id_is_verified_idx" ON "seller_documents"("user_id", "is_verified");

-- CreateIndex
CREATE INDEX "seller_documents_doc_type_idx" ON "seller_documents"("doc_type");

-- CreateIndex
CREATE INDEX "settlement_batches_status_created_at_idx" ON "settlement_batches"("status", "created_at");

-- CreateIndex
CREATE INDEX "settlement_payments_provider_id_provider_type_idx" ON "settlement_payments"("provider_id", "provider_type");

-- CreateIndex
CREATE INDEX "settlement_payments_status_idx" ON "settlement_payments"("status");

-- CreateIndex
CREATE INDEX "shipping_companies_is_active_idx" ON "shipping_companies"("is_active");

-- CreateIndex
CREATE UNIQUE INDEX "slots_slot_key_key" ON "slots"("slot_key");

-- CreateIndex
CREATE INDEX "slots_doctor_id_date_start_time_idx" ON "slots"("doctor_id", "date", "start_time");

-- CreateIndex
CREATE INDEX "slots_clinic_id_date_status_idx" ON "slots"("clinic_id", "date", "status");

-- CreateIndex
CREATE INDEX "slots_room_id_date_start_time_idx" ON "slots"("room_id", "date", "start_time");

-- CreateIndex
CREATE UNIQUE INDEX "slots_doctor_id_clinic_id_date_start_time_key" ON "slots"("doctor_id", "clinic_id", "date", "start_time");

-- CreateIndex
CREATE INDEX "specialties_is_active_idx" ON "specialties"("is_active");

-- CreateIndex
CREATE INDEX "user_devices_user_id_is_active_idx" ON "user_devices"("user_id", "is_active");

-- CreateIndex
CREATE INDEX "user_documents_user_id_created_at_idx" ON "user_documents"("user_id", "created_at");

-- CreateIndex
CREATE INDEX "user_documents_appointment_id_idx" ON "user_documents"("appointment_id");

-- CreateIndex
CREATE INDEX "user_documents_doc_type_idx" ON "user_documents"("doc_type");

-- CreateIndex
CREATE INDEX "user_documents_deleted_at_idx" ON "user_documents"("deleted_at");

-- CreateIndex
CREATE INDEX "user_documents_expires_at_idx" ON "user_documents"("expires_at");

-- CreateIndex
CREATE INDEX "user_documents_is_shared_idx" ON "user_documents"("is_shared");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_wilaya_id_fkey" FOREIGN KEY ("wilaya_id") REFERENCES "wilayas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "contact_users" ADD CONSTRAINT "contact_users_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_wallets" ADD CONSTRAINT "user_wallets_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "credit_transactions" ADD CONSTRAINT "credit_transactions_wallet_id_fkey" FOREIGN KEY ("wallet_id") REFERENCES "user_wallets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "credit_transactions" ADD CONSTRAINT "credit_transactions_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payments" ADD CONSTRAINT "payments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinics" ADD CONSTRAINT "clinics_wilaya_id_fkey" FOREIGN KEY ("wilaya_id") REFERENCES "wilayas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinics" ADD CONSTRAINT "clinics_baladya_id_fkey" FOREIGN KEY ("baladya_id") REFERENCES "baladyat"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_working_hours" ADD CONSTRAINT "clinic_working_hours_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_rooms" ADD CONSTRAINT "clinic_rooms_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_services" ADD CONSTRAINT "clinic_services_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_doctors" ADD CONSTRAINT "clinic_doctors_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "doctor_availabilities" ADD CONSTRAINT "doctor_availabilities_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "slots" ADD CONSTRAINT "slots_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "doctor_reviews" ADD CONSTRAINT "doctor_reviews_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_reviews" ADD CONSTRAINT "clinic_reviews_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_reviews" ADD CONSTRAINT "clinic_reviews_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_devices" ADD CONSTRAINT "user_devices_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_documents" ADD CONSTRAINT "user_documents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_documents" ADD CONSTRAINT "clinic_documents_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clinic_gallery" ADD CONSTRAINT "clinic_gallery_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_doctor_consents" ADD CONSTRAINT "patient_doctor_consents_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "document_access_logs" ADD CONSTRAINT "document_access_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "document_requests" ADD CONSTRAINT "document_requests_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders" ADD CONSTRAINT "orders_buyer_id_fkey" FOREIGN KEY ("buyer_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders" ADD CONSTRAINT "orders_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "seller_documents" ADD CONSTRAINT "seller_documents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- RenameIndex
ALTER INDEX "doctor_logo_doctor_id_idx" RENAME TO "doctor_logos_doctor_id_idx";

-- RenameIndex
ALTER INDEX "doctor_logo_file_id_unique" RENAME TO "doctor_logos_file_id_key";

-- RenameIndex
ALTER INDEX "doctor_logo_storage_key_unique" RENAME TO "doctor_logos_storage_key_key";
