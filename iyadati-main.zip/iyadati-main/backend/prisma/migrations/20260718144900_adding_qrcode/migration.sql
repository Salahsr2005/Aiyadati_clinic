/*
  Warnings:

  - A unique constraint covering the columns `[qr_code]` on the table `User` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable: Add columns as nullable first
ALTER TABLE "User" ADD COLUMN "qr_code" TEXT;
ALTER TABLE "credit_transactions" ADD COLUMN "sender_id" TEXT;

-- Populate existing users with unique UUIDs
UPDATE "User" SET "qr_code" = gen_random_uuid()::text WHERE "qr_code" IS NULL;

-- Now make qr_code required
ALTER TABLE "User" ALTER COLUMN "qr_code" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "User_qr_code_key" ON "User"("qr_code");

-- AddForeignKey
ALTER TABLE "credit_transactions" ADD CONSTRAINT "credit_transactions_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

