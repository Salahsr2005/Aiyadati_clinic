-- CreateEnum
CREATE TYPE "SettlementStatus" AS ENUM ('PENDING', 'PROCESSING', 'PAID', 'FAILED');

-- CreateTable
CREATE TABLE "provider_earnings" (
    "id" TEXT NOT NULL,
    "provider_id" TEXT NOT NULL,
    "provider_type" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "appointment_id" TEXT NOT NULL,
    "credit_price_id" TEXT,
    "status" "SettlementStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "paid_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "provider_earnings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "provider_balances" (
    "id" TEXT NOT NULL,
    "provider_id" TEXT NOT NULL,
    "provider_type" TEXT NOT NULL,
    "total_earned" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "total_paid" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "pending_balance" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "last_updated" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "provider_balances_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "settlement_batches" (
    "id" TEXT NOT NULL,
    "reference" TEXT NOT NULL,
    "total_amount" DOUBLE PRECISION NOT NULL,
    "provider_count" INTEGER NOT NULL DEFAULT 0,
    "status" "SettlementStatus" NOT NULL DEFAULT 'PENDING',
    "processed_by" TEXT NOT NULL,
    "processed_at" TIMESTAMP(3) NOT NULL,
    "completed_at" TIMESTAMP(3),
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "settlement_batches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "settlement_payments" (
    "id" TEXT NOT NULL,
    "batch_id" TEXT NOT NULL,
    "provider_id" TEXT NOT NULL,
    "provider_type" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "status" "SettlementStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "earning_ids" TEXT[],

    CONSTRAINT "settlement_payments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "provider_earnings_provider_id_provider_type_idx" ON "provider_earnings"("provider_id", "provider_type");

-- CreateIndex
CREATE INDEX "provider_earnings_appointment_id_idx" ON "provider_earnings"("appointment_id");

-- CreateIndex
CREATE INDEX "provider_earnings_status_idx" ON "provider_earnings"("status");

-- CreateIndex
CREATE INDEX "provider_earnings_created_at_idx" ON "provider_earnings"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "provider_balances_provider_id_key" ON "provider_balances"("provider_id");

-- CreateIndex
CREATE UNIQUE INDEX "settlement_batches_reference_key" ON "settlement_batches"("reference");

-- CreateIndex
CREATE INDEX "settlement_batches_status_idx" ON "settlement_batches"("status");

-- CreateIndex
CREATE INDEX "settlement_payments_batch_id_idx" ON "settlement_payments"("batch_id");

-- CreateIndex
CREATE INDEX "settlement_payments_provider_id_idx" ON "settlement_payments"("provider_id");

-- AddForeignKey
ALTER TABLE "provider_earnings" ADD CONSTRAINT "provider_earnings_appointment_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "provider_earnings" ADD CONSTRAINT "provider_earnings_credit_price_id_fkey" FOREIGN KEY ("credit_price_id") REFERENCES "credit_prices"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "settlement_payments" ADD CONSTRAINT "settlement_payments_batch_id_fkey" FOREIGN KEY ("batch_id") REFERENCES "settlement_batches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
