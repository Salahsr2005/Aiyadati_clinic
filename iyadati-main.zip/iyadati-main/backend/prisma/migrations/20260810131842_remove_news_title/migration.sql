/*
  Warnings:

  - You are about to drop the column `title` on the `news_tapes` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "news_tapes" DROP COLUMN "title";
