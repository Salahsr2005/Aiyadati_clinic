-- AlterTable
ALTER TABLE "clinic_gallery" ALTER COLUMN "file_path" DROP DEFAULT;
