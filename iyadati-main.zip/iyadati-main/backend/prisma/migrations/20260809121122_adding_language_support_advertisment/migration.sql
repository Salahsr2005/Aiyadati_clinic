-- CreateEnum
CREATE TYPE "AdLanguage" AS ENUM ('ARABIC', 'FRENCH', 'ENGLISH');

-- AlterTable
ALTER TABLE "advertisements" ADD COLUMN     "description_ar" TEXT,
ADD COLUMN     "description_en" TEXT,
ADD COLUMN     "description_fr" TEXT,
ADD COLUMN     "language" "AdLanguage" NOT NULL DEFAULT 'FRENCH',
ADD COLUMN     "title_ar" VARCHAR(200),
ADD COLUMN     "title_en" VARCHAR(200),
ADD COLUMN     "title_fr" VARCHAR(200);

-- CreateIndex
CREATE INDEX "advertisements_language_idx" ON "advertisements"("language");
