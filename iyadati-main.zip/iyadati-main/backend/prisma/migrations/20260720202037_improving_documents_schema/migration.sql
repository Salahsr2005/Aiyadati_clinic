/*
  Warnings:

  - You are about to drop the `ClinicDocument` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[file_id]` on the table `clinic_gallery` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storage_key]` on the table `clinic_gallery` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[file_id]` on the table `clinic_service_images` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storage_key]` on the table `clinic_service_images` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[file_id]` on the table `doctor_documents` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storage_key]` on the table `doctor_documents` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[file_id]` on the table `user_documents` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[storage_key]` on the table `user_documents` will be added. If there are existing duplicate values, this will fail.
  - The required column `file_id` was added to the `clinic_gallery` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `file_name` to the `clinic_gallery` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_size` to the `clinic_gallery` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_type` to the `clinic_gallery` table without a default value. This is not possible if the table is not empty.
  - Added the required column `storage_key` to the `clinic_gallery` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `clinic_gallery` table without a default value. This is not possible if the table is not empty.
  - The required column `file_id` was added to the `clinic_service_images` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `file_name` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_size` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - Added the required column `file_type` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - Added the required column `storage_key` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `clinic_service_images` table without a default value. This is not possible if the table is not empty.
  - The required column `file_id` was added to the `doctor_documents` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `storage_key` to the `doctor_documents` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `doctor_documents` table without a default value. This is not possible if the table is not empty.
  - Added the required column `doc_type` to the `user_documents` table without a default value. This is not possible if the table is not empty.
  - The required column `file_id` was added to the `user_documents` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `storage_key` to the `user_documents` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "ClinicDocument" DROP CONSTRAINT "ClinicDocument_clinicId_fkey";

-- AlterTable
ALTER TABLE "User" ALTER COLUMN "qr_code" DROP NOT NULL;

-- AlterTable
ALTER TABLE "clinic_gallery" ADD COLUMN     "access_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "file_id" TEXT NOT NULL,
ADD COLUMN     "file_name" TEXT NOT NULL,
ADD COLUMN     "file_size" INTEGER NOT NULL,
ADD COLUMN     "file_type" TEXT NOT NULL,
ADD COLUMN     "last_accessed" TIMESTAMP(3),
ADD COLUMN     "storage_key" TEXT NOT NULL,
ADD COLUMN     "storage_type" TEXT NOT NULL DEFAULT 'public',
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "clinic_service_images" ADD COLUMN     "access_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "file_id" TEXT NOT NULL,
ADD COLUMN     "file_name" TEXT NOT NULL,
ADD COLUMN     "file_size" INTEGER NOT NULL,
ADD COLUMN     "file_type" TEXT NOT NULL,
ADD COLUMN     "last_accessed" TIMESTAMP(3),
ADD COLUMN     "storage_key" TEXT NOT NULL,
ADD COLUMN     "storage_type" TEXT NOT NULL DEFAULT 'public',
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "doctor_documents" ADD COLUMN     "access_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "category" TEXT NOT NULL DEFAULT 'document',
ADD COLUMN     "expires_at" TIMESTAMP(3),
ADD COLUMN     "file_id" TEXT NOT NULL,
ADD COLUMN     "last_accessed" TIMESTAMP(3),
ADD COLUMN     "storage_key" TEXT NOT NULL,
ADD COLUMN     "storage_type" TEXT NOT NULL DEFAULT 'private',
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "user_documents" ADD COLUMN     "access_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "category" TEXT NOT NULL DEFAULT 'document',
ADD COLUMN     "doc_type" TEXT NOT NULL,
ADD COLUMN     "expires_at" TIMESTAMP(3),
ADD COLUMN     "file_id" TEXT NOT NULL,
ADD COLUMN     "last_accessed" TIMESTAMP(3),
ADD COLUMN     "storage_key" TEXT NOT NULL,
ADD COLUMN     "storage_type" TEXT NOT NULL DEFAULT 'private';

-- DropTable
DROP TABLE "ClinicDocument";

-- CreateTable
CREATE TABLE "clinic_documents" (
    "id" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "file_id" TEXT NOT NULL,
    "storage_key" TEXT NOT NULL,
    "file_name" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "file_path" TEXT NOT NULL,
    "storage_type" TEXT NOT NULL DEFAULT 'private',
    "category" TEXT NOT NULL DEFAULT 'document',
    "doc_type" TEXT NOT NULL,
    "uploaded_by" TEXT,
    "access_count" INTEGER NOT NULL DEFAULT 0,
    "last_accessed" TIMESTAMP(3),
    "expires_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clinic_documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "file_registry" (
    "id" TEXT NOT NULL,
    "fileId" TEXT NOT NULL,
    "storageKey" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileType" TEXT NOT NULL,
    "fileSize" INTEGER NOT NULL,
    "filePath" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "storageType" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "ownerId" TEXT NOT NULL,
    "ownerType" TEXT NOT NULL,
    "tableName" TEXT NOT NULL,
    "tableId" TEXT NOT NULL,
    "metadata" JSONB,
    "accessCount" INTEGER NOT NULL DEFAULT 0,
    "lastAccessed" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "file_registry_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "clinic_documents_file_id_key" ON "clinic_documents"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_documents_storage_key_key" ON "clinic_documents"("storage_key");

-- CreateIndex
CREATE UNIQUE INDEX "file_registry_fileId_key" ON "file_registry"("fileId");

-- CreateIndex
CREATE UNIQUE INDEX "file_registry_storageKey_key" ON "file_registry"("storageKey");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_gallery_file_id_key" ON "clinic_gallery"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_gallery_storage_key_key" ON "clinic_gallery"("storage_key");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_service_images_file_id_key" ON "clinic_service_images"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "clinic_service_images_storage_key_key" ON "clinic_service_images"("storage_key");

-- CreateIndex
CREATE UNIQUE INDEX "doctor_documents_file_id_key" ON "doctor_documents"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "doctor_documents_storage_key_key" ON "doctor_documents"("storage_key");

-- CreateIndex
CREATE UNIQUE INDEX "user_documents_file_id_key" ON "user_documents"("file_id");

-- CreateIndex
CREATE UNIQUE INDEX "user_documents_storage_key_key" ON "user_documents"("storage_key");

-- AddForeignKey
ALTER TABLE "clinic_documents" ADD CONSTRAINT "clinic_documents_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "Clinic"("id") ON DELETE CASCADE ON UPDATE CASCADE;
